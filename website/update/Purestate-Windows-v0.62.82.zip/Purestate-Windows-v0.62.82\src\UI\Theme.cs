using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Purestate.App
{
    internal enum UiIcon
    {
        Home,
        Shield,
        Settings,
        More,
        Warning,
        Success,
        Information
    }

    // Central UI palette. Light/Dark share the same identity; Windows high
    // contrast falls back to system colors so user-chosen contrast themes win.
    internal sealed class UiTheme
    {
        public bool IsDark;
        public bool IsHighContrast;
        public Color WindowBackground;
        public Color SidebarBackground;
        public Color CardBackground;
        public Color InputBackground;
        public Color ButtonBackground;
        public Color TextPrimary;
        public Color TextSecondary;
        public Color Border;
        public Color Divider;
        public Color ControlBorder;
        public Color Accent;
        // Schrift auf Accent-Flaechen (ausgewaehlter Listeneintrag).
        public Color OnAccent;
        public Color AccentTint;
        // Website-Look: der Hauptknopf ist hell Navy, dunkel Teal. Accent bleibt
        // fuer Fokus, Links und Auswahl - beides teilte sich frueher Accent.
        public Color PrimaryFill;
        public Color PrimaryFillHover;
        public Color OnPrimary;
        public Color StatusActive;
        public Color StatusRestricted;
        public Color StatusRepair;
        public Color StatusPaused;
        public Color DangerRed;

        public static readonly UiTheme Light = new UiTheme
        {
            IsDark = false,
            // Website-Tokens aus website/src/styles/global.css (docs/WEB-DESIGN.md).
            WindowBackground = Color.FromArgb(243, 245, 245),
            SidebarBackground = Color.FromArgb(231, 238, 238),
            CardBackground = Color.FromArgb(250, 252, 252),
            InputBackground = Color.FromArgb(231, 238, 238),
            ButtonBackground = Color.FromArgb(250, 252, 252),
            TextPrimary = Color.FromArgb(10, 26, 49),
            TextSecondary = Color.FromArgb(65, 77, 94),
            Border = Color.FromArgb(213, 222, 234),
            Divider = Color.FromArgb(213, 222, 234),
            // THM-001: 2,91:1 gegen den Eingabefeldhintergrund war unter der
            // WCAG-Schwelle 1.4.11 (3:1) fuer Bedienelement-Begrenzungen. Gegen
            // die weisse Karte lag derselbe Wert bei 3,34:1 - der Bezug
            // entscheidet, und Eingabefelder sind der ungünstigere Fall.
            ControlBorder = Color.FromArgb(107, 118, 132),
            Accent = Color.FromArgb(14, 116, 114),
            OnAccent = Color.White,
            // Website-Tint #e5f0ef lag auf der Seitenleiste (#e7eeee) unsichtbar.
            // Kraeftiger geht nicht: Accent-Schrift darauf braucht 4,5:1 (hier 4,57).
            AccentTint = Color.FromArgb(209, 238, 236),
            PrimaryFill = Color.FromArgb(15, 30, 51),
            PrimaryFillHover = Color.FromArgb(28, 51, 87),
            OnPrimary = Color.White,
            StatusActive = Color.FromArgb(14, 116, 114),
            StatusRestricted = Color.FromArgb(138, 90, 0),
            StatusRepair = Color.FromArgb(176, 59, 11),
            StatusPaused = Color.FromArgb(65, 77, 94),
            DangerRed = Color.FromArgb(161, 51, 51)
        };

        public static readonly UiTheme Dark = new UiTheme
        {
            IsDark = true,
            WindowBackground = Color.FromArgb(10, 17, 29),
            SidebarBackground = Color.FromArgb(14, 22, 38),
            CardBackground = Color.FromArgb(17, 27, 44),
            InputBackground = Color.FromArgb(22, 34, 58),
            ButtonBackground = Color.FromArgb(17, 27, 44),
            TextPrimary = Color.FromArgb(232, 236, 241),
            TextSecondary = Color.FromArgb(168, 180, 198),
            Border = Color.FromArgb(32, 45, 67),
            Divider = Color.FromArgb(32, 45, 67),
            // THM-001, dunkle Seite: heller statt dunkler, aus demselben Grund.
            ControlBorder = Color.FromArgb(122, 135, 151),
            Accent = Color.FromArgb(73, 195, 189),
            OnAccent = Color.FromArgb(4, 18, 31),
            AccentTint = Color.FromArgb(25, 51, 64),
            PrimaryFill = Color.FromArgb(73, 195, 189),
            PrimaryFillHover = Color.FromArgb(99, 212, 206),
            OnPrimary = Color.FromArgb(4, 18, 31),
            StatusActive = Color.FromArgb(79, 199, 192),
            StatusRestricted = Color.FromArgb(217, 164, 65),
            StatusRepair = Color.FromArgb(228, 140, 92),
            StatusPaused = Color.FromArgb(168, 180, 198),
            DangerRed = Color.FromArgb(224, 127, 127)
        };

        // System colors only - never fights the user's chosen contrast theme.
        public static UiTheme HighContrast()
        {
            return new UiTheme
            {
                IsDark = false,
                IsHighContrast = true,
                WindowBackground = SystemColors.Window,
                SidebarBackground = SystemColors.Control,
                CardBackground = SystemColors.Window,
                InputBackground = SystemColors.Window,
                ButtonBackground = SystemColors.Control,
                TextPrimary = SystemColors.WindowText,
                TextSecondary = SystemColors.WindowText,
                Border = SystemColors.WindowFrame,
                Divider = SystemColors.WindowFrame,
                ControlBorder = SystemColors.WindowFrame,
                Accent = SystemColors.Highlight,
                OnAccent = SystemColors.HighlightText,
                AccentTint = SystemColors.Highlight,
                PrimaryFill = SystemColors.Highlight,
                PrimaryFillHover = SystemColors.Highlight,
                OnPrimary = SystemColors.HighlightText,
                StatusActive = SystemColors.WindowText,
                StatusRestricted = SystemColors.WindowText,
                StatusRepair = SystemColors.WindowText,
                StatusPaused = SystemColors.GrayText,
                DangerRed = SystemColors.WindowText
            };
        }
    }

    // Website-Look: Pillen-Buttons wie auf purestate-app.com. Bleibt ein echter
    // Button - Tastatur, Mnemonics, AutoSize und Screenreader wie vorher.
    // Farben kommen aus BackColor/ForeColor/FlatAppearance, damit StylePrimary,
    // StyleSecondary und ApplyHoverColors unveraendert die Quelle bleiben.
    internal sealed class RoundButton : Button
    {
        // -1 = Pille (halbe Hoehe der Flaeche).
        public int CornerRadius = -1;
        // Hochkontrast: eckig, ohne Glaettung, Systemfarben.
        public bool Square;
        public Color FocusRingColor = SystemColors.Highlight;
        public Color DisabledForeColor = SystemColors.GrayText;
        public UiIcon? Icon;

        // Platz fuer den Fokusring: 2 px Ring + 2 px Luft zur Pille. Intern
        // sichtbar fuer Ui.BaseButton, das die Mindestgroesse um denselben
        // Betrag aufschlaegt (F3) - sonst waere die sichtbare Pille kleiner
        // als die versprochenen 36 x 96 px.
        internal const int RingInset = 5;
        private bool hovered;
        private bool pressed;

        public RoundButton()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        public override Size GetPreferredSize(Size proposedSize)
        {
            // ButtonBase.GetPreferredSize vereinigt sein Ergebnis bei
            // AutoSizeMode.GrowOnly immer mit der AKTUELLEN Groesse DIESES
            // Buttons - ein Aufruf ueber "base" haette also bei jedem
            // weiteren Layout-Durchlauf unsere eigene Zugabe (2 * RingInset)
            // erneut draufaddiert und den Knopf immer weiter wachsen lassen.
            // Ein elternloser Wegwerf-Button liefert dieselbe natuerliche
            // Textgroesse ohne diesen Rueckbezug.
            using (Button probe = new Button
            {
                Text = Text,
                Font = Font,
                Padding = Padding,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowOnly,
                FlatStyle = FlatStyle.Flat
            })
            {
                Size size = probe.GetPreferredSize(Size.Empty);
                // Wie Control.GetPreferredSize nie unter MinimumSize: sonst legt ein
                // Flow-Layout einen kurzen Knopf ("OK") nach der kleineren Breite,
                // SetBounds streckt ihn danach auf die Mindestbreite und er ragt
                // rechts aus seinem Container.
                return new Size(Math.Max(size.Width + 2 * RingInset, MinimumSize.Width),
                    Math.Max(size.Height + 2 * RingInset, MinimumSize.Height));
            }
        }

        protected override void OnMouseEnter(EventArgs e) { hovered = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { hovered = false; pressed = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) { pressed = true; Invalidate(); }
            base.OnMouseDown(e);
        }
        protected override void OnMouseUp(MouseEventArgs e) { pressed = false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            Render(e.Graphics, hovered, pressed, Focused && ShowFocusCues);
        }

        internal void Render(Graphics g, bool hover, bool down, bool focusRing)
        {
            g.Clear(Ui.OpaqueBackColor(Parent));
            Color fill = BackColor;
            if (down && !FlatAppearance.MouseDownBackColor.IsEmpty)
            {
                fill = FlatAppearance.MouseDownBackColor;
            }
            else if (hover && !FlatAppearance.MouseOverBackColor.IsEmpty)
            {
                fill = FlatAppearance.MouseOverBackColor;
            }
            Color text = Enabled ? ForeColor : DisabledForeColor;
            int borderSize = FlatAppearance.BorderSize;
            Color border = FlatAppearance.BorderColor.IsEmpty ? fill : FlatAppearance.BorderColor;

            Rectangle body;
            if (Square)
            {
                body = new Rectangle(0, 0, Width, Height);
                g.SmoothingMode = SmoothingMode.None;
                using (SolidBrush brush = new SolidBrush(fill))
                {
                    g.FillRectangle(brush, body);
                }
                if (borderSize > 0)
                {
                    using (Pen pen = new Pen(border, borderSize))
                    {
                        g.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
                    }
                }
                if (focusRing)
                {
                    ControlPaint.DrawFocusRectangle(g, Rectangle.Inflate(body, -3, -3));
                }
            }
            else
            {
                body = Rectangle.Inflate(new Rectangle(0, 0, Width, Height), -RingInset, -RingInset);
                int radius = CornerRadius < 0 ? body.Height / 2 : CornerRadius;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (GraphicsPath path = Ui.RoundedRect(new Rectangle(body.X, body.Y, body.Width - 1, body.Height - 1), radius))
                using (SolidBrush brush = new SolidBrush(fill))
                {
                    g.FillPath(brush, path);
                    if (borderSize > 0)
                    {
                        using (Pen pen = new Pen(border, 1f))
                        {
                            g.DrawPath(pen, path);
                        }
                    }
                }
                if (focusRing)
                {
                    Rectangle ring = new Rectangle(1, 1, Width - 3, Height - 3);
                    using (GraphicsPath path = Ui.RoundedRect(ring, radius + RingInset - 1))
                    using (Pen pen = new Pen(FocusRingColor, 2f))
                    {
                        g.DrawPath(pen, path);
                    }
                }
            }

            if (Icon.HasValue)
            {
                Ui.DrawIcon(g, Icon.Value, new Rectangle(16, (Height - 20) / 2, 20, 20), text);
            }

            TextFormatFlags flags = TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis;
            flags |= TextAlign == ContentAlignment.MiddleLeft ? TextFormatFlags.Left : TextFormatFlags.HorizontalCenter;
            if (!ShowKeyboardCues)
            {
                flags |= TextFormatFlags.HidePrefix;
            }
            Rectangle textBounds = new Rectangle(
                body.X + Padding.Left, body.Y,
                Math.Max(0, body.Width - Padding.Horizontal), body.Height);
            TextRenderer.DrawText(g, Text, Font, textBounds, text, flags);
        }
    }

    // Website-Look: Karten mit 12 px Rundung und feinem Rahmen. Bleibt ein
    // TableLayoutPanel - Layout, AutoSize und Barrierefreiheit wie vorher.
    internal sealed class RoundCard : TableLayoutPanel
    {
        public int CornerRadius = 12;
        public Color BorderColor = Color.Empty;
        public bool Square;

        public RoundCard()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Render(e.Graphics);
        }

        internal void Render(Graphics g)
        {
            g.Clear(Ui.OpaqueBackColor(Parent));
            Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
            using (SolidBrush brush = new SolidBrush(BackColor))
            {
                if (Square)
                {
                    g.SmoothingMode = SmoothingMode.None;
                    g.FillRectangle(brush, 0, 0, Width, Height);
                    if (!BorderColor.IsEmpty)
                    {
                        using (Pen pen = new Pen(BorderColor))
                        {
                            g.DrawRectangle(pen, r);
                        }
                    }
                    return;
                }
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (GraphicsPath path = Ui.RoundedRect(r, CornerRadius))
                {
                    g.FillPath(brush, path);
                    if (!BorderColor.IsEmpty)
                    {
                        using (Pen pen = new Pen(BorderColor))
                        {
                            g.DrawPath(pen, path);
                        }
                    }
                }
            }
        }
    }

    // Shared fonts, spacing and control factories. Every page and dialog uses
    // these instead of defining its own sizes - see docs/UI-DESIGN.md.
    internal static class Ui
    {
        // Website-Look: leichte grosse Titel, Semibold statt Bold, Mono-Labels.
        // Fehlt eine Familie (Cascadia Mono erst ab Windows 11/Terminal), faellt
        // MakeFont auf die naechste sichere Schrift zurueck statt still auf
        // Microsoft Sans Serif.
        public static readonly Font FontPageTitle = MakeFont("Segoe UI Semilight", 20f, "Segoe UI", FontStyle.Regular);
        public static readonly Font FontStatus = MakeFont("Segoe UI Semibold", 16f, "Segoe UI", FontStyle.Bold);
        public static readonly Font FontSection = MakeFont("Segoe UI Semibold", 12f, "Segoe UI", FontStyle.Bold);
        public static readonly Font FontRowTitle = MakeFont("Segoe UI Semibold", 11f, "Segoe UI", FontStyle.Bold);
        public static readonly Font FontBody = new Font("Segoe UI", 10f);
        public static readonly Font FontBodyBold = MakeFont("Segoe UI Semibold", 10f, "Segoe UI", FontStyle.Bold);
        public static readonly Font FontHint = new Font("Segoe UI", 10f);
        public static readonly Font FontMono = MakeFont("Cascadia Mono", 10f, "Consolas", FontStyle.Regular);
        public static readonly Font FontLabel = MakeFont("Cascadia Mono", 10f, "Consolas", FontStyle.Regular);

        public static Font MakeFont(string family, float size, string fallbackFamily, FontStyle fallbackStyle)
        {
            // F5: existiert die Familie ohne Regular-Schnitt, wirft der
            // Konstruktor ArgumentException statt still zu ersetzen - bei den
            // static readonly Schriftrollen wuerde das sonst als
            // TypeInitializationException den App-Start verhindern.
            try
            {
                Font font = new Font(family, size);
                if (string.Equals(font.Name, family, StringComparison.OrdinalIgnoreCase))
                {
                    return font;
                }
                font.Dispose();
            }
            catch (ArgumentException)
            {
            }
            return new Font(fallbackFamily, size, fallbackStyle);
        }

        // Technisches Register der Website (.mono-label): Grossbuchstaben in der
        // Anzeige, normale Schreibweise fuer Screenreader.
        public static Label MonoLabel(UiTheme theme, string text)
        {
            Label label = new Label
            {
                Text = (text ?? string.Empty).ToUpper(new System.Globalization.CultureInfo("de-DE")),
                Font = FontLabel,
                ForeColor = theme.TextSecondary,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 2)
            };
            SetAccessibility(label, text, text, AccessibleRole.StaticText);
            return label;
        }

        public const int GapSmall = 8;
        public const int GapGroup = 16;
        public const int GapSection = 24;
        public const int PagePadding = 32;
        public const int ButtonHeight = 36;
        public const int ButtonMinWidth = 96;
        public const int ContentMaxWidth = 720;

        public static void SetAccessibility(Control control, string name, string description, AccessibleRole role)
        {
            control.AccessibleName = name;
            control.AccessibleDescription = description;
            control.AccessibleRole = role;
        }

        // DESK-05: Sichtbarer Text und Screenreader-Name aendern sich gemeinsam.
        // Ein beim Bau gesetzter AccessibleName blieb sonst stehen ("Frist
        // starten", obwohl der Knopf laengst "Frist abbrechen" zeigt).
        public static void SetDynamicText(Control control, string text, string accessiblePrefix)
        {
            string value = text ?? string.Empty;
            string clean = CleanMnemonic(value);
            string name = string.IsNullOrEmpty(accessiblePrefix)
                ? clean
                : (clean.Length == 0 ? accessiblePrefix : accessiblePrefix + ": " + clean);
            // Der Status wird alle vier Sekunden neu gesetzt. Ohne Aenderung kein
            // NameChange-Ereignis, sonst liest ein Screenreader ihn erneut vor.
            if (control.Text == value && control.AccessibleName == name)
            {
                return;
            }
            control.Text = value;
            control.AccessibleName = name;
            if (control.IsHandleCreated)
            {
                try
                {
                    NotifyWinEvent(EventObjectNameChange, control.Handle, ObjectIdClient, 0);
                }
                catch (EntryPointNotFoundException)
                {
                }
            }
        }

        public static string CleanMnemonic(string text)
        {
            return (text ?? string.Empty).Replace("&", string.Empty).Trim();
        }

        public static void PrepareForm(Form form, string name, string description)
        {
            form.AutoScaleMode = AutoScaleMode.Dpi;
            form.Font = FontBody;
            form.AccessibleName = name;
            form.AccessibleDescription = description;
            form.AccessibleRole = AccessibleRole.Window;
        }

        // Buttons auto-size horizontally so translated/long captions are never
        // cut off ("Abbreche" bug in the old fixed-width dialogs).
        private static Button BaseButton(string text, string description)
        {
            Button button = new RoundButton
            {
                Text = text,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowOnly,
                // F3: die sichtbare Pille bleibt 96 x 36 px - der Fokusring
                // (RingInset) braucht zusaetzlichen Platz aussen herum.
                MinimumSize = new Size(ButtonMinWidth + 2 * RoundButton.RingInset, ButtonHeight + 2 * RoundButton.RingInset),
                Padding = new Padding(12, 4, 12, 4),
                FlatStyle = FlatStyle.Flat,
                Font = FontBody,
                UseVisualStyleBackColor = false
            };
            SetAccessibility(button, CleanMnemonic(text), description, AccessibleRole.PushButton);
            return button;
        }

        public static Button PrimaryButton(UiTheme theme, string text, string description)
        {
            Button button = BaseButton(text, description);
            button.Font = FontBodyBold;
            StylePrimary(theme, button);
            return button;
        }

        public static Button SecondaryButton(UiTheme theme, string text, string description)
        {
            Button button = BaseButton(text, description);
            StyleSecondary(theme, button);
            return button;
        }

        public static void StylePrimary(UiTheme theme, Button button)
        {
            button.BackColor = theme.PrimaryFill;
            button.ForeColor = theme.OnPrimary;
            button.FlatAppearance.BorderSize = 1;
            button.FlatAppearance.BorderColor = theme.PrimaryFill;
            ApplyHoverColors(theme, button);
            // ApplyHoverColors mischt einen allgemeinen Hover-Ton; der
            // Hauptknopf ersetzt ihn durch den eigenen Palettenwert
            // (PrimaryFillHover). Im Hochkontrast-Modus ist PrimaryFillHover
            // gleich PrimaryFill (kein Hover-Unterschied) - dort bleibt
            // deshalb die gemischte Farbe stehen, damit Hover sichtbar bleibt.
            if (!theme.IsHighContrast)
            {
                button.FlatAppearance.MouseOverBackColor = theme.PrimaryFillHover;
            }
            StyleRound(theme, button);
        }

        public static void StyleSecondary(UiTheme theme, Button button)
        {
            button.BackColor = theme.ButtonBackground;
            button.ForeColor = theme.TextPrimary;
            button.FlatAppearance.BorderSize = 1;
            button.FlatAppearance.BorderColor = theme.ControlBorder;
            ApplyHoverColors(theme, button);
            StyleRound(theme, button);
        }

        // Hover/Druck passend zum aktuellen BackColor - muss bei jedem Restyle
        // (auch nach Theme-Wechsel) neu berechnet werden, sonst bleibt die
        // Hover-Farbe des alten Themes stehen.
        private static void ApplyHoverColors(UiTheme theme, Button button)
        {
            button.FlatAppearance.MouseOverBackColor = Mix(button.BackColor, theme.IsDark ? Color.White : Color.Black, theme.IsDark ? 12 : 8);
            button.FlatAppearance.MouseDownBackColor = Mix(button.BackColor, Color.Black, 14);
        }

        public static Color Mix(Color from, Color to, int percentTo)
        {
            int p = Math.Max(0, Math.Min(100, percentTo));
            return Color.FromArgb(
                from.R + ((to.R - from.R) * p / 100),
                from.G + ((to.G - from.G) * p / 100),
                from.B + ((to.B - from.B) * p / 100));
        }

        public static GraphicsPath RoundedRect(Rectangle r, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            int d = Math.Max(1, Math.Min(radius * 2, Math.Min(r.Width, r.Height)));
            path.AddArc(r.X, r.Y, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        // Runde Formen fuellen ihre Ecken mit der Flaeche dahinter.
        public static Color OpaqueBackColor(Control control)
        {
            Control current = control;
            while (current != null)
            {
                if (current.BackColor.A == 255)
                {
                    return current.BackColor;
                }
                current = current.Parent;
            }
            return SystemColors.Control;
        }

        // Theme-abhaengige Zeichenwerte eines RoundButton; bei jedem Restyle neu.
        private static void StyleRound(UiTheme theme, Button button)
        {
            RoundButton round = button as RoundButton;
            if (round == null)
            {
                return;
            }
            round.Square = theme.IsHighContrast;
            round.FocusRingColor = theme.Accent;
            // F1: aus dem eigenen Vordergrund/Hintergrund-Paar statt aus einer
            // Palettenkonstante - TextSecondary auf PrimaryFill lag bei 1,95:1
            // hell und 1,02:1 dunkel (fast unsichtbar). Hochkontrast bleibt bei
            // Systemfarben.
            round.DisabledForeColor = theme.IsHighContrast
                ? SystemColors.GrayText
                : Mix(button.ForeColor, button.BackColor, 40);
            round.Invalidate();
        }

        public static void StyleCard(UiTheme theme, RoundCard card)
        {
            card.BackColor = theme.CardBackground;
            card.BorderColor = theme.Border;
            card.Square = theme.IsHighContrast;
            card.Invalidate();
        }

        public static void DrawIcon(Graphics graphics, UiIcon icon, Rectangle bounds, Color color)
        {
            if (graphics == null || bounds.Width < 8 || bounds.Height < 8)
            {
                return;
            }

            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            float unit = Math.Min(bounds.Width, bounds.Height) / 20f;
            using (Pen pen = new Pen(color, Math.Max(1.4f, unit * 1.5f)))
            using (SolidBrush brush = new SolidBrush(color))
            {
                pen.StartCap = LineCap.Round;
                pen.EndCap = LineCap.Round;
                pen.LineJoin = LineJoin.Round;
                float x = bounds.Left;
                float y = bounds.Top;
                float w = bounds.Width;
                float h = bounds.Height;

                switch (icon)
                {
                    case UiIcon.Home:
                        graphics.DrawLines(pen, new[] { new PointF(x + w * .12f, y + h * .48f), new PointF(x + w * .5f, y + h * .14f), new PointF(x + w * .88f, y + h * .48f) });
                        graphics.DrawRectangle(pen, x + w * .23f, y + h * .43f, w * .54f, h * .43f);
                        break;
                    case UiIcon.Shield:
                        graphics.DrawPolygon(pen, new[] { new PointF(x + w * .5f, y + h * .1f), new PointF(x + w * .82f, y + h * .24f), new PointF(x + w * .75f, y + h * .7f), new PointF(x + w * .5f, y + h * .9f), new PointF(x + w * .25f, y + h * .7f), new PointF(x + w * .18f, y + h * .24f) });
                        break;
                    case UiIcon.Settings:
                        // Drei Schieberegler - liest sich klarer als "Einstellungen"
                        // als das alte strahlenfoermige Zahnrad.
                        graphics.DrawLine(pen, x + w * .15f, y + h * .25f, x + w * .85f, y + h * .25f);
                        graphics.DrawLine(pen, x + w * .15f, y + h * .5f, x + w * .85f, y + h * .5f);
                        graphics.DrawLine(pen, x + w * .15f, y + h * .75f, x + w * .85f, y + h * .75f);
                        graphics.FillEllipse(brush, x + w * .55f, y + h * .25f - w * .09f, w * .18f, w * .18f);
                        graphics.FillEllipse(brush, x + w * .27f, y + h * .5f - w * .09f, w * .18f, w * .18f);
                        graphics.FillEllipse(brush, x + w * .62f, y + h * .75f - w * .09f, w * .18f, w * .18f);
                        break;
                    case UiIcon.More:
                        graphics.FillEllipse(brush, x + w * .16f, y + h * .43f, w * .14f, h * .14f);
                        graphics.FillEllipse(brush, x + w * .43f, y + h * .43f, w * .14f, h * .14f);
                        graphics.FillEllipse(brush, x + w * .70f, y + h * .43f, w * .14f, h * .14f);
                        break;
                    case UiIcon.Warning:
                        graphics.DrawPolygon(pen, new[] { new PointF(x + w * .5f, y + h * .1f), new PointF(x + w * .9f, y + h * .84f), new PointF(x + w * .1f, y + h * .84f) });
                        graphics.DrawLine(pen, x + w * .5f, y + h * .34f, x + w * .5f, y + h * .58f);
                        graphics.FillEllipse(brush, x + w * .46f, y + h * .68f, w * .08f, h * .08f);
                        break;
                    case UiIcon.Success:
                        graphics.DrawEllipse(pen, x + w * .1f, y + h * .1f, w * .8f, h * .8f);
                        graphics.DrawLines(pen, new[] { new PointF(x + w * .28f, y + h * .52f), new PointF(x + w * .44f, y + h * .68f), new PointF(x + w * .74f, y + h * .34f) });
                        break;
                    case UiIcon.Information:
                        graphics.DrawEllipse(pen, x + w * .1f, y + h * .1f, w * .8f, h * .8f);
                        graphics.FillEllipse(brush, x + w * .45f, y + h * .26f, w * .1f, h * .1f);
                        graphics.DrawLine(pen, x + w * .5f, y + h * .46f, x + w * .5f, y + h * .72f);
                        break;
                }
            }
        }

        public static Control CommandRow(UiTheme theme, string title, string description,
            string actionText, string actionDescription, EventHandler onClick)
        {
            RoundCard row = new RoundCard
            {
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 2,
                Margin = new Padding(0, 0, 0, GapSmall),
                Padding = new Padding(GapGroup, 10, GapGroup, 10),
                RowCount = 1
            };
            StyleCard(theme, row);
            FitToPageColumn(row, 64);
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            row.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));

            TableLayoutPanel copy = new TableLayoutPanel { AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 1, Dock = DockStyle.Fill, Margin = new Padding(0) };
            copy.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            Label titleLabel = new Label { Text = title, AutoSize = true, Font = FontBodyBold, ForeColor = theme.TextPrimary, Margin = new Padding(0, 0, 0, 3), Anchor = AnchorStyles.Left | AnchorStyles.Right };
            Label descriptionLabel = WrapLabel(theme, description, 430, true);
            // Umbruch an der verfuegbaren Spaltenbreite statt fester 430 px.
            descriptionLabel.MaximumSize = Size.Empty;
            descriptionLabel.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            descriptionLabel.Margin = new Padding(0);
            copy.Controls.Add(titleLabel, 0, 0);
            copy.Controls.Add(descriptionLabel, 0, 1);
            row.Controls.Add(copy, 0, 0);

            Button action = SecondaryButton(theme, actionText, actionDescription);
            action.Anchor = AnchorStyles.Right;
            if (onClick != null)
            {
                action.Click += onClick;
            }
            row.Controls.Add(action, 1, 0);
            SetAccessibility(row, title, description, AccessibleRole.Grouping);
            return row;
        }

        // DESK-02: Seitenzeilen folgen der Spaltenbreite der Seite und werden
        // hoechstens ContentMaxWidth breit. Die fruehere feste Breite von
        // 720 px lief bei schmalem Fenster rechts aus dem sichtbaren Bereich.
        public static void FitToPageColumn(Control row, int minHeight)
        {
            row.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            row.MinimumSize = new Size(0, minHeight);
            row.MaximumSize = new Size(ContentMaxWidth, 0);
        }

        public static Control EmptyState(UiTheme theme, string title, string description, Button action)
        {
            RoundCard empty = new RoundCard
            {
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 1,
                Dock = DockStyle.Top,
                Margin = new Padding(0),
                Padding = new Padding(GapGroup),
                RowCount = 1
            };
            StyleCard(theme, empty);
            empty.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            TableLayoutPanel content = new TableLayoutPanel { AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 1, Dock = DockStyle.Fill, Margin = new Padding(0) };
            content.Controls.Add(new Label { Text = title, AutoSize = true, Font = FontRowTitle, ForeColor = theme.TextPrimary, Margin = new Padding(0, 0, 0, 4) });
            Label hint = WrapLabel(theme, description, 480, true);
            content.Controls.Add(hint);
            if (action != null)
            {
                action.Margin = new Padding(0, GapSmall, 0, 0);
                content.Controls.Add(action);
            }
            empty.Controls.Add(content, 0, 0);
            SetAccessibility(empty, title, description, AccessibleRole.Grouping);
            return empty;
        }

        // Wrapping label: fixed width, height grows with the text - long copy is
        // never cut off mid-sentence.
        public static Label WrapLabel(UiTheme theme, string text, int width, bool secondary)
        {
            Label label = new Label
            {
                Text = text,
                AutoSize = true,
                MaximumSize = new Size(width, 0),
                Font = secondary ? FontHint : FontBody,
                ForeColor = secondary ? theme.TextSecondary : theme.TextPrimary,
                Margin = new Padding(0, 0, 0, GapSmall)
            };
            SetAccessibility(label, text, text, AccessibleRole.StaticText);
            return label;
        }

        public static CheckBox Check(UiTheme theme, string text, bool isChecked, string description)
        {
            CheckBox box = new CheckBox
            {
                Text = text,
                Checked = isChecked,
                AutoSize = true,
                MinimumSize = new Size(0, 32),
                Font = FontBody,
                ForeColor = theme.TextPrimary,
                Margin = new Padding(0, 0, 0, 4)
            };
            if (!theme.IsHighContrast)
            {
                WireCheckGlyph(theme, box);
            }
            SetAccessibility(box, CleanMnemonic(text), description, AccessibleRole.CheckButton);
            return box;
        }

        // Eigengezeichnete Glyphen: Systemhaken/-kreis passen weder zum hellen
        // noch zum dunklen Purestate-Look. Hochkontrast behaelt die
        // Systemdarstellung (Aufrufer prueft das).
        private static Color ResolveBackground(Control control, UiTheme theme)
        {
            Color back = control.BackColor;
            Control parent = control.Parent;
            while (back == Color.Transparent && parent != null)
            {
                back = parent.BackColor;
                parent = parent.Parent;
            }
            return back == Color.Transparent ? theme.CardBackground : back;
        }

        private static void WireCheckGlyph(UiTheme theme, CheckBox box)
        {
            box.Paint += delegate (object sender, PaintEventArgs e)
            {
                CheckBox check = (CheckBox)sender;
                Rectangle glyph = new Rectangle(0, (check.Height - 14) / 2, 13, 13);
                using (SolidBrush clear = new SolidBrush(ResolveBackground(check, theme)))
                {
                    e.Graphics.FillRectangle(clear, new Rectangle(glyph.X - 1, glyph.Y - 1, glyph.Width + 3, glyph.Height + 3));
                }
                DrawCheckGlyph(e.Graphics, theme, glyph, check.Checked, check.Enabled);
            };
            box.CheckedChanged += delegate { box.Invalidate(); };
        }

        // Ein Haken-Glyph fuer Checkboxen UND die dunkle Spieleliste (DESK-01),
        // damit beide gleich aussehen. Koordinaten skalieren mit der Glyphgroesse.
        private static void DrawCheckGlyph(Graphics graphics, UiTheme theme, Rectangle glyph, bool isChecked, bool enabled)
        {
            SmoothingMode previous = graphics.SmoothingMode;
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            float unit = glyph.Width / 13f;
            if (isChecked)
            {
                Color fillColor = enabled ? theme.Accent : Mix(theme.Accent, theme.CardBackground, 45);
                using (SolidBrush fill = new SolidBrush(fillColor))
                {
                    graphics.FillRectangle(fill, glyph);
                }
                Color mark = theme.IsDark ? theme.WindowBackground : Color.White;
                using (Pen pen = new Pen(mark, 1.8f * unit))
                {
                    pen.StartCap = LineCap.Round;
                    pen.EndCap = LineCap.Round;
                    pen.LineJoin = LineJoin.Round;
                    graphics.DrawLines(pen, new[]
                    {
                        new PointF(glyph.X + 3f * unit, glyph.Y + 6.8f * unit),
                        new PointF(glyph.X + 5.4f * unit, glyph.Y + 9.4f * unit),
                        new PointF(glyph.X + 10f * unit, glyph.Y + 3.8f * unit)
                    });
                }
            }
            else
            {
                using (SolidBrush fill = new SolidBrush(theme.CardBackground))
                {
                    graphics.FillRectangle(fill, glyph);
                }
                Color border = enabled ? theme.ControlBorder : Mix(theme.ControlBorder, theme.CardBackground, 45);
                using (Pen pen = new Pen(border, 1.4f * unit))
                {
                    graphics.DrawRectangle(pen, glyph.X, glyph.Y, glyph.Width - 1, glyph.Height - 1);
                }
            }
            graphics.SmoothingMode = previous;
        }

        private static void WireRadioGlyph(UiTheme theme, RadioButton radio)
        {
            radio.Paint += delegate (object sender, PaintEventArgs e)
            {
                RadioButton button = (RadioButton)sender;
                Rectangle glyph = new Rectangle(0, (button.Height - 14) / 2, 13, 13);
                using (SolidBrush clear = new SolidBrush(ResolveBackground(button, theme)))
                {
                    e.Graphics.FillRectangle(clear, new Rectangle(glyph.X - 1, glyph.Y - 1, glyph.Width + 3, glyph.Height + 3));
                }
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using (SolidBrush fill = new SolidBrush(theme.CardBackground))
                {
                    e.Graphics.FillEllipse(fill, glyph);
                }
                using (Pen pen = new Pen(button.Checked ? theme.Accent : theme.ControlBorder, 1.4f))
                {
                    e.Graphics.DrawEllipse(pen, glyph.X, glyph.Y, glyph.Width - 1, glyph.Height - 1);
                }
                if (button.Checked)
                {
                    using (SolidBrush dot = new SolidBrush(theme.Accent))
                    {
                        e.Graphics.FillEllipse(dot, glyph.X + 3.5f, glyph.Y + 3.5f, glyph.Width - 8f, glyph.Height - 8f);
                    }
                }
            };
            radio.CheckedChanged += delegate { radio.Invalidate(); };
        }

        public static RadioButton Radio(UiTheme theme, string text, bool isChecked, string description)
        {
            RadioButton radio = new RadioButton
            {
                Text = text,
                Checked = isChecked,
                AutoSize = true,
                MinimumSize = new Size(0, 32),
                Font = FontBody,
                ForeColor = theme.TextPrimary,
                Margin = new Padding(0, 0, 0, 4)
            };
            if (!theme.IsHighContrast)
            {
                WireRadioGlyph(theme, radio);
            }
            SetAccessibility(radio, CleanMnemonic(text), description, AccessibleRole.RadioButton);
            return radio;
        }

        // Zahlenwerte als Stufenliste statt Zahlenfeld: praktische Vorgaben,
        // abweichende gespeicherte Werte werden einsortiert; Auslesen ueber
        // int.Parse(box.Text).
        public static ComboBox StepsCombo(int[] steps, int min, int max, int value, string name, string description)
        {
            ComboBox box = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Width = 88,
                Font = FontBody,
                Margin = new Padding(0, 2, 0, 2)
            };
            foreach (int step in steps)
            {
                if (step >= min && step <= max)
                {
                    box.Items.Add(step.ToString());
                }
            }
            int current = Math.Max(min, Math.Min(max, value));
            string currentText = current.ToString();
            if (!box.Items.Contains(currentText))
            {
                int index = 0;
                while (index < box.Items.Count && int.Parse((string)box.Items[index]) < current)
                {
                    index++;
                }
                box.Items.Insert(index, currentText);
            }
            box.SelectedItem = currentText;
            SetAccessibility(box, name, description, AccessibleRole.ComboBox);
            return box;
        }

        public static ComboBox MinutesCombo(int min, int max, int value, string name, string description)
        {
            return StepsCombo(new[] { 5, 10, 15, 20, 30, 45, 60, 90, 120, 180, 240, 300, 360, 480, 600 },
                min, max, value, name, description);
        }

        // Uhrzeit als Auswahlliste: halbe Stunden, kein Freitext, kein
        // Formatfehler. Abweichende gespeicherte Werte (Altbestand) werden
        // einsortiert und vorausgewaehlt; .Text liefert weiterhin "HH:mm".
        public static ComboBox TimeCombo(string value, string fallback, string name)
        {
            ComboBox box = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Width = 88,
                Font = FontBody,
                Margin = new Padding(0, 2, 0, 2)
            };
            for (int minutes = 0; minutes < 24 * 60; minutes += 30)
            {
                box.Items.Add(string.Format("{0:00}:{1:00}", minutes / 60, minutes % 60));
            }
            string current = string.IsNullOrWhiteSpace(value) ? fallback : value.Trim();
            if (!box.Items.Contains(current))
            {
                int index = 0;
                while (index < box.Items.Count && string.CompareOrdinal((string)box.Items[index], current) < 0)
                {
                    index++;
                }
                box.Items.Insert(index, current);
            }
            box.SelectedItem = current;
            SetAccessibility(box, name, name + " als Uhrzeit auswählen.", AccessibleRole.ComboBox);
            return box;
        }

        public static void StyleInput(UiTheme theme, TextBox box)
        {
            box.BackColor = theme.InputBackground;
            box.ForeColor = theme.TextPrimary;
            box.BorderStyle = BorderStyle.FixedSingle;
        }

        // Rahmen und Pfeilbereich eines Auswahlfelds in den App-Farben. Bei
        // FlatStyle.Flat malt Windows den Pfeilknopf sonst immer in der hellen
        // Systemfarbe - im Dunkelmodus ein weisses Kaestchen, und unten und
        // rechts fehlte der Rahmen. Hochkontrast behaelt die Systemdarstellung.
        internal static void PaintComboChrome(Graphics g, Rectangle client, Rectangle button, UiTheme theme, bool focused, bool enabled)
        {
            if (theme.IsHighContrast || client.Width < 4 || client.Height < 4)
            {
                return;
            }
            SmoothingMode previous = g.SmoothingMode;
            g.SmoothingMode = SmoothingMode.None;
            using (SolidBrush fill = new SolidBrush(theme.InputBackground))
            using (Pen ring = new Pen(theme.InputBackground))
            using (Pen border = new Pen(focused ? theme.Accent : theme.ControlBorder))
            {
                // Zwei Pixel links vom gemeldeten Knopf malt Windows eine helle
                // Trennlinie - die Flaeche deckt sie mit ab.
                Rectangle area = Rectangle.Intersect(
                    Rectangle.FromLTRB(button.Left - 2, button.Top, button.Right, button.Bottom),
                    Rectangle.Inflate(client, -2, -2));
                if (!area.IsEmpty)
                {
                    g.FillRectangle(fill, area);
                }
                g.DrawRectangle(ring, client.X + 1, client.Y + 1, client.Width - 3, client.Height - 3);
                g.DrawRectangle(border, client.X, client.Y, client.Width - 1, client.Height - 1);
            }
            if (!button.IsEmpty)
            {
                float cx = button.Left + button.Width / 2f;
                float cy = button.Top + button.Height / 2f;
                Color arrow = enabled ? theme.TextSecondary : Mix(theme.TextSecondary, theme.InputBackground, 50);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (Pen pen = new Pen(arrow, 1.6f) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
                {
                    g.DrawLines(pen, new[] { new PointF(cx - 4f, cy - 2f), new PointF(cx, cy + 2f), new PointF(cx + 4f, cy - 2f) });
                }
            }
            g.SmoothingMode = previous;
        }

        // Eingabeflaeche hebt sich von der Karte ab (hell: grau auf weiss,
        // dunkel: heller als die Karte). Liste per Owner-Draw, sonst malt
        // Windows sie hell - Hochkontrast behaelt die Systemdarstellung.
        public static void StyleInput(UiTheme theme, ComboBox box)
        {
            box.BackColor = theme.InputBackground;
            box.ForeColor = theme.TextPrimary;
            box.FlatStyle = FlatStyle.Flat;
            if (theme.IsHighContrast)
            {
                return;
            }
            if (!Equals(box.Tag, "purestate-owner-draw"))
            {
                box.Tag = "purestate-owner-draw";
                box.DrawMode = DrawMode.OwnerDrawFixed;
                // Selbstgezeichnet bildet Windows die Feldhoehe erst beim Anlegen
                // des Fensters (Eintragshoehe + 2 * (Kante + 1), hier 26 statt 21
                // px). Das Layout rechnet aber mit der angegebenen Hoehe - eine
                // vorher vermessene Zeile schnitt die unterste Reihe ab, den
                // Rahmen. Die Endhoehe hier angeben, dann stimmt jedes Layout.
                box.Height = box.ItemHeight + 2 * (SystemInformation.Border3DSize.Height + 1);
                box.DrawItem += delegate (object sender, DrawItemEventArgs e)
                {
                    ComboBox combo = (ComboBox)sender;
                    // Auswahl in der aufgeklappten Liste wie im System: volle
                    // Akzentflaeche. Das geschlossene Feld bleibt ruhig - seinen
                    // Fokus zeigt der Rahmen (PaintComboChrome).
                    bool closedField = (e.State & DrawItemState.ComboBoxEdit) == DrawItemState.ComboBoxEdit;
                    bool selected = !closedField && (e.State & DrawItemState.Selected) == DrawItemState.Selected;
                    bool disabled = (e.State & DrawItemState.Disabled) == DrawItemState.Disabled;
                    Color text = selected ? theme.OnAccent : (disabled ? theme.TextSecondary : theme.TextPrimary);
                    using (SolidBrush background = new SolidBrush(selected ? theme.Accent : theme.InputBackground))
                    using (SolidBrush foreground = new SolidBrush(text))
                    {
                        e.Graphics.FillRectangle(background, e.Bounds);
                        if (e.Index >= 0)
                        {
                            e.Graphics.DrawString(combo.Items[e.Index].ToString(), FontBody, foreground,
                                new RectangleF(e.Bounds.X + 4, e.Bounds.Y + 2, e.Bounds.Width - 8, e.Bounds.Height - 4));
                        }
                    }
                };
                // Erst nach DrawMode: das Umschalten erzeugt das Handle neu.
                ComboChrome chrome = new ComboChrome(box, theme);
                // Haelt den Aufsatz am Leben, solange das Feld lebt - WinForms
                // fuehrt NativeWindow nur schwach referenziert.
                box.Disposed += delegate { chrome.ReleaseHandle(); };
            }
        }

        // Faengt WM_PAINT und WM_PRINT eines Auswahlfelds ab und malt danach
        // Rahmen und Pfeilbereich neu (PaintComboChrome). WM_PRINT, damit auch
        // DrawToBitmap und PrintWindow das Ergebnis zeigen.
        private sealed class ComboChrome : NativeWindow
        {
            private const int WmPaint = 0x000F;
            private const int WmPrint = 0x0317;
            private const int WmPrintClient = 0x0318;
            private readonly ComboBox box;
            private readonly UiTheme theme;

            internal ComboChrome(ComboBox box, UiTheme theme)
            {
                this.box = box;
                this.theme = theme;
                box.HandleCreated += delegate { AssignHandle(box.Handle); };
                box.HandleDestroyed += delegate { ReleaseHandle(); };
                box.GotFocus += delegate { box.Invalidate(); };
                box.LostFocus += delegate { box.Invalidate(); };
                // Die aufgeklappte Liste ist ein eigenes Fenster; ohne das
                // Theme bekaeme sie im Dunkelmodus eine helle Bildlaufleiste.
                box.DropDown += delegate
                {
                    if (!theme.IsDark)
                    {
                        return;
                    }
                    ComboBoxInfo info;
                    if (TryGetComboBoxInfo(box, out info))
                    {
                        try
                        {
                            SetWindowTheme(info.hwndList, "DarkMode_Explorer", null);
                        }
                        catch
                        {
                        }
                    }
                };
                if (box.IsHandleCreated)
                {
                    AssignHandle(box.Handle);
                }
            }

            protected override void WndProc(ref Message m)
            {
                base.WndProc(ref m);
                if (m.Msg == WmPaint)
                {
                    using (Graphics g = Graphics.FromHwnd(m.HWnd))
                    {
                        Paint(g);
                    }
                }
                else if ((m.Msg == WmPrint || m.Msg == WmPrintClient) && m.WParam != IntPtr.Zero)
                {
                    using (Graphics g = Graphics.FromHdc(m.WParam))
                    {
                        Paint(g);
                    }
                }
            }

            private void Paint(Graphics g)
            {
                Rectangle client = box.ClientRectangle;
                ComboBoxInfo info;
                Rectangle button = TryGetComboBoxInfo(box, out info)
                    ? Rectangle.FromLTRB(info.rcButton.Left, info.rcButton.Top, info.rcButton.Right, info.rcButton.Bottom)
                    : new Rectangle(client.Right - SystemInformation.VerticalScrollBarWidth - 2, 2,
                        SystemInformation.VerticalScrollBarWidth, Math.Max(0, client.Height - 4));
                PaintComboChrome(g, client, button, theme, box.Focused, box.Enabled);
            }
        }

        private static bool TryGetComboBoxInfo(ComboBox box, out ComboBoxInfo info)
        {
            info = new ComboBoxInfo();
            info.cbSize = Marshal.SizeOf(typeof(ComboBoxInfo));
            try
            {
                return box.IsHandleCreated && GetComboBoxInfo(box.Handle, ref info);
            }
            catch (EntryPointNotFoundException)
            {
                return false;
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct NativeRect
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct ComboBoxInfo
        {
            public int cbSize;
            public NativeRect rcItem;
            public NativeRect rcButton;
            public int stateButton;
            public IntPtr hwndCombo;
            public IntPtr hwndItem;
            public IntPtr hwndList;
        }

        [DllImport("user32.dll")]
        private static extern bool GetComboBoxInfo(IntPtr hwndCombo, ref ComboBoxInfo info);

        public static void StyleInput(UiTheme theme, ListBox list)
        {
            list.BackColor = theme.CardBackground;
            list.ForeColor = theme.TextPrimary;
            list.BorderStyle = BorderStyle.FixedSingle;
            ApplyScrollbarTheme(list, theme.IsDark);
        }

        public static void StyleListView(UiTheme theme, ListView listView)
        {
            listView.BackColor = theme.CardBackground;
            listView.ForeColor = theme.TextPrimary;
            listView.BorderStyle = BorderStyle.FixedSingle;
            listView.OwnerDraw = theme.IsDark && listView.View == View.Details;
            ApplyScrollbarTheme(listView, theme.IsDark);

            if (!Equals(listView.Tag, "purestate-owner-draw"))
            {
                listView.Tag = "purestate-owner-draw";
                listView.DrawColumnHeader += delegate (object sender, DrawListViewColumnHeaderEventArgs e)
                {
                    ListView list = (ListView)sender;
                    using (SolidBrush background = new SolidBrush(list.BackColor))
                    using (SolidBrush foreground = new SolidBrush(list.ForeColor))
                    {
                        e.Graphics.FillRectangle(background, e.Bounds);
                        e.Graphics.DrawString(e.Header.Text, FontBody, foreground,
                            new RectangleF(e.Bounds.X + 6, e.Bounds.Y + 3, e.Bounds.Width - 8, e.Bounds.Height - 4));
                    }
                };
                listView.DrawItem += delegate (object sender, DrawListViewItemEventArgs e)
                {
                    if (((ListView)sender).View != View.Details)
                    {
                        e.DrawDefault = true;
                    }
                };
                listView.DrawSubItem += delegate (object sender, DrawListViewSubItemEventArgs e)
                {
                    ListView list = (ListView)sender;
                    bool selected = e.Item.Selected;
                    Color backgroundColor = selected ? SystemColors.Highlight : list.BackColor;
                    Color foregroundColor = !list.Enabled ? theme.TextSecondary : (selected ? SystemColors.HighlightText : list.ForeColor);
                    using (SolidBrush background = new SolidBrush(backgroundColor))
                    using (SolidBrush foreground = new SolidBrush(foregroundColor))
                    {
                        e.Graphics.FillRectangle(background, e.Bounds);
                        int textLeft = e.Bounds.X + 6;
                        // DESK-01: OwnerDraw ersetzt die native Zeile komplett -
                        // ohne diesen Glyph war der Haken unsichtbar. Der Zustand
                        // kommt allein aus ListViewItem.Checked; die Leertaste
                        // und der Klick auf das Kaestchen bleiben nativ.
                        if (e.ColumnIndex == 0 && list.CheckBoxes)
                        {
                            int size = Math.Max(13, (int)Math.Round(13 * e.Graphics.DpiX / 96f));
                            Rectangle glyph = new Rectangle(e.Bounds.X + 4, e.Bounds.Y + (e.Bounds.Height - size) / 2, size, size);
                            DrawCheckGlyph(e.Graphics, theme, glyph, e.Item.Checked, list.Enabled);
                            textLeft = glyph.Right + 6;
                        }
                        e.Graphics.DrawString(e.SubItem.Text, FontBody, foreground,
                            new RectangleF(textLeft, e.Bounds.Y + 2, e.Bounds.Right - textLeft - 2, e.Bounds.Height - 3));
                        if (e.ColumnIndex == 0 && e.Item.Focused && list.Focused)
                        {
                            ControlPaint.DrawFocusRectangle(e.Graphics, e.Item.Bounds, foregroundColor, backgroundColor);
                        }
                    }
                };
            }
        }

        // DESK-07: Die Haken schreiben sofort ins Modell. Vorher wurde die
        // Liste beim Hinzufuegen/Entfernen aus dem Modell neu gebaut, das erst
        // beim Speichern die Haken erfuhr - geaenderte Haken sprangen zurueck.
        // Rueckgabe: die Neuaufbau-Aktion; waehrend des Fuellens schweigt der
        // Handler.
        public static Action BindCheckList<T>(ListView list, System.Collections.Generic.IList<T> model,
            Func<T, bool> isChecked, Action<T, bool> setChecked, Func<T, ListViewItem> createItem)
        {
            bool filling = false;
            list.ItemChecked += delegate (object sender, ItemCheckedEventArgs e)
            {
                int index = e.Item.Index;
                if (!filling && index >= 0 && index < model.Count)
                {
                    setChecked(model[index], e.Item.Checked);
                }
            };
            return delegate
            {
                filling = true;
                list.BeginUpdate();
                try
                {
                    list.Items.Clear();
                    foreach (T entry in model)
                    {
                        ListViewItem item = createItem(entry);
                        item.Checked = isChecked(entry);
                        list.Items.Add(item);
                    }
                }
                finally
                {
                    list.EndUpdate();
                    filling = false;
                }
            };
        }

        // Shows/hides dependent controls with a toggle - progressive disclosure.
        public static void BindVisibility(CheckBox toggle, params Control[] dependents)
        {
            Action apply = delegate
            {
                foreach (Control control in dependents)
                {
                    control.Visible = toggle.Checked;
                }
            };
            toggle.CheckedChanged += delegate { apply(); };
            apply();
        }

        public static void BindVisibility(RadioButton toggle, params Control[] dependents)
        {
            Action apply = delegate
            {
                foreach (Control control in dependents)
                {
                    control.Visible = toggle.Checked;
                }
            };
            toggle.CheckedChanged += delegate { apply(); };
            apply();
        }

        [DllImport("dwmapi.dll", PreserveSig = true)]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);

        [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)]
        private static extern int SetWindowTheme(IntPtr hWnd, string subAppName, string subIdList);

        [DllImport("user32.dll")]
        private static extern void NotifyWinEvent(uint winEvent, IntPtr hwnd, int idObject, int idChild);

        private const uint EventObjectNameChange = 0x800C;
        private const int ObjectIdClient = -4;

        // Dunkle native Scrollbars (Win10 1809+). Schlaegt der Aufruf fehl,
        // bleibt die Systemdarstellung - kein Funktionsverlust.
        public static void ApplyScrollbarTheme(Control control, bool dark)
        {
            if (control == null)
            {
                return;
            }
            EventHandler apply = delegate
            {
                try
                {
                    SetWindowTheme(control.Handle, dark ? "DarkMode_Explorer" : "Explorer", null);
                }
                catch
                {
                }
            };
            if (control.IsHandleCreated)
            {
                apply(control, EventArgs.Empty);
            }
            else
            {
                control.HandleCreated += apply;
            }
        }

        private const int DwmwaUseImmersiveDarkMode = 20;

        public static void ApplyDarkTitleBar(IntPtr handle, bool dark)
        {
            try
            {
                int value = dark ? 1 : 0;
                DwmSetWindowAttribute(handle, DwmwaUseImmersiveDarkMode, ref value, sizeof(int));
            }
            catch
            {
            }
        }

        // Themed Ersatz fuer MessageBox in der Admin-UI. Nein/Escape/X = false.
        public static bool Confirm(IWin32Window owner, UiTheme theme, string title, string message, string yesText, string noText)
        {
            using (Form dialog = BuildMessageForm(theme, title, message))
            {
                FlowLayoutPanel bar = (FlowLayoutPanel)dialog.Controls.Find("actionBar", true)[0];
                Button yes = PrimaryButton(theme, yesText, "Bestätigt die Aktion.");
                yes.DialogResult = DialogResult.OK;
                Button no = SecondaryButton(theme, noText, "Bricht ab, ohne etwas zu ändern.");
                no.DialogResult = DialogResult.Cancel;
                no.Margin = new Padding(GapSmall, 0, 0, 0);
                bar.Controls.Add(no);
                bar.Controls.Add(yes);
                dialog.AcceptButton = yes;
                dialog.CancelButton = no;
                dialog.Shown += delegate { no.Focus(); };
                return dialog.ShowDialog(owner) == DialogResult.OK;
            }
        }

        public static void Inform(IWin32Window owner, UiTheme theme, string title, string message)
        {
            using (Form dialog = BuildMessageForm(theme, title, message))
            {
                FlowLayoutPanel bar = (FlowLayoutPanel)dialog.Controls.Find("actionBar", true)[0];
                Button ok = PrimaryButton(theme, "OK", "Schließt die Meldung.");
                ok.DialogResult = DialogResult.OK;
                bar.Controls.Add(ok);
                dialog.AcceptButton = ok;
                dialog.CancelButton = ok;
                dialog.ShowDialog(owner);
            }
        }

        private static Form BuildMessageForm(UiTheme theme, string title, string message)
        {
            Form dialog = new Form
            {
                Text = "Purestate - " + title,
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                ShowInTaskbar = false,
                BackColor = theme.WindowBackground,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(GapSection, GapGroup, GapSection, GapGroup)
            };
            PrepareForm(dialog, title, message);
            dialog.HandleCreated += delegate { ApplyDarkTitleBar(dialog.Handle, theme.IsDark); };

            TableLayoutPanel column = new TableLayoutPanel
            {
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 1,
                Dock = DockStyle.Fill
            };
            Label titleLabel = new Label
            {
                Text = title,
                Font = FontSection,
                ForeColor = theme.TextPrimary,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, GapSmall)
            };
            SetAccessibility(titleLabel, title, title, AccessibleRole.StaticText);
            column.Controls.Add(titleLabel);
            column.Controls.Add(WrapLabel(theme, message, 420, false));
            FlowLayoutPanel bar = new FlowLayoutPanel
            {
                Name = "actionBar",
                FlowDirection = FlowDirection.RightToLeft,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Dock = DockStyle.Bottom,
                Margin = new Padding(0, GapGroup, 0, 0)
            };
            column.Controls.Add(bar);
            dialog.Controls.Add(column);
            return dialog;
        }

        // Berichtsfenster (vorher AdminForm.ShowTextDialog). DESK-02: Knoepfe
        // in einer fliessenden Aktionsleiste statt fester x-Positionen, die
        // sich mit AutoSize schon in Standardgroesse ueberlappten.
        // UIX-003: offerSave=false heisst "Fliesstext, keine Datei wert", nicht
        // "vertraulich" - Kopieren bleibt deshalb immer moeglich. PRIV-009: der
        // Hinweis ueber dem Kopierknopf sagt, was im Bericht steht.
        public static Form BuildTextDialog(UiTheme theme, string title, string text, bool offerSave)
        {
            Form dialog = new Form
            {
                Text = "Purestate - " + title,
                StartPosition = FormStartPosition.CenterParent,
                Size = new Size(680, 500),
                MinimumSize = new Size(540, 360),
                BackColor = theme.WindowBackground,
                Padding = new Padding(GapGroup)
            };
            PrepareForm(dialog, title, "Zeigt einen kopierbaren Purestate-Bericht.");
            dialog.HandleCreated += delegate { ApplyDarkTitleBar(dialog.Handle, theme.IsDark); };

            TextBox box = new TextBox
            {
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                Font = FontMono,
                Text = text,
                BackColor = theme.CardBackground,
                ForeColor = theme.TextPrimary,
                Dock = DockStyle.Fill,
                TabIndex = 0
            };
            SetAccessibility(box, title + " Text", "Berichtstext zum Lesen und Kopieren.", AccessibleRole.Text);

            Label note = new Label
            {
                Text = "Der Bericht enthält den Zustand deines Geräts, Auszüge aus dem Protokoll " +
                    "sowie Programm- und Domainnamen. Lies ihn durch, bevor du ihn weitergibst.",
                AutoSize = false,
                Dock = DockStyle.Bottom,
                Padding = new Padding(0, GapSmall, 0, GapSmall),
                ForeColor = theme.TextSecondary
            };
            SetAccessibility(note, "Hinweis zum Inhalt", note.Text, AccessibleRole.StaticText);

            FlowLayoutPanel actions = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                FlowDirection = FlowDirection.RightToLeft,
                WrapContents = true,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink
            };

            Button close = SecondaryButton(theme, "Schließen", "Schließt den Bericht.");
            close.DialogResult = DialogResult.Cancel;
            close.TabIndex = 3;
            close.Margin = new Padding(GapSmall, 0, 0, 0);
            Button save = SecondaryButton(theme, "Als Datei speichern", "Speichert den Bericht als Textdatei.");
            save.Enabled = offerSave;
            save.TabIndex = 2;
            save.Margin = new Padding(GapSmall, 0, 0, 0);
            Button copy = SecondaryButton(theme, "Details kopieren", "Kopiert den Bericht in die Zwischenablage.");
            copy.TabIndex = 1;
            copy.Margin = new Padding(GapSmall, 0, 0, 0);
            actions.Controls.Add(close);
            actions.Controls.Add(save);
            actions.Controls.Add(copy);
            dialog.CancelButton = close;

            Action fitNote = delegate
            {
                int width = Math.Max(80, note.Width);
                note.Height = TextRenderer.MeasureText(note.Text, note.Font, new Size(width, 0), TextFormatFlags.WordBreak).Height + note.Padding.Vertical + 2;
            };
            Action<string> showNote = delegate (string message)
            {
                SetDynamicText(note, message, "Hinweis zum Inhalt");
                fitNote();
            };
            dialog.Resize += delegate { fitNote(); };
            dialog.Shown += delegate { fitNote(); box.Focus(); };

            copy.Click += delegate
            {
                string error;
                showNote(TryCopyToClipboard(text, out error)
                    ? "In die Zwischenablage kopiert. Bitte vor dem Weitergeben durchlesen."
                    : error);
            };
            save.Click += delegate
            {
                using (SaveFileDialog picker = new SaveFileDialog())
                {
                    picker.Title = "Bericht speichern";
                    picker.Filter = "Textdatei|*.txt|Alle Dateien|*.*";
                    picker.FileName = "Purestate-Bericht.txt";
                    if (picker.ShowDialog(dialog) != DialogResult.OK)
                    {
                        return;
                    }
                    string error;
                    showNote(TrySaveText(picker.FileName, text, out error)
                        ? "Gespeichert: " + System.IO.Path.GetFileName(picker.FileName) + ". Bitte vor dem Weitergeben durchlesen."
                        : error);
                }
            };

            // Andockreihenfolge: zuletzt hinzugefuegt = ganz unten.
            dialog.Controls.Add(box);
            dialog.Controls.Add(note);
            dialog.Controls.Add(actions);
            fitNote();
            return dialog;
        }

        // DESK-10: Zwischenablage kann von einem anderen Programm belegt sein.
        public static bool TryCopyToClipboard(string text, out string error)
        {
            error = string.Empty;
            if (string.IsNullOrEmpty(text))
            {
                error = "Der Bericht ist leer - es gibt nichts zu kopieren.";
                return false;
            }
            try
            {
                Clipboard.SetText(text);
                return true;
            }
            catch (ExternalException)
            {
                error = "Die Zwischenablage ist gerade von einem anderen Programm belegt. Bitte versuche es gleich noch einmal.";
            }
            catch (System.Threading.ThreadStateException)
            {
                error = "Die Zwischenablage ist gerade nicht erreichbar. Bitte versuche es gleich noch einmal.";
            }
            return false;
        }

        // DESK-10: Zieldatei gesperrt, schreibgeschuetzt oder ohne Rechte.
        public static bool TrySaveText(string path, string text, out string error)
        {
            error = string.Empty;
            try
            {
                System.IO.File.WriteAllText(path, text, System.Text.Encoding.UTF8);
                return true;
            }
            catch (Exception ex)
            {
                if (!(ex is System.IO.IOException || ex is UnauthorizedAccessException ||
                    ex is System.Security.SecurityException || ex is NotSupportedException || ex is ArgumentException))
                {
                    throw;
                }
                error = "Der Bericht konnte nicht gespeichert werden (Datei gesperrt, schreibgeschützt oder keine Berechtigung). Bitte wähle einen anderen Speicherort.";
                return false;
            }
        }

        // Middle-ellipsis for long file paths shown in lists.
        public static string ShortenPath(string path, int maxChars)
        {
            if (string.IsNullOrEmpty(path) || path.Length <= maxChars)
            {
                return path ?? string.Empty;
            }
            int keep = (maxChars - 3) / 2;
            return path.Substring(0, keep) + "..." + path.Substring(path.Length - keep);
        }
    }


}
