using System;
using System.IO;
using System.Text;
using Microsoft.Win32;
using ServiceControllerStatus = System.ServiceProcess.ServiceControllerStatus;

namespace Purestate.Native
{
    internal static partial class Support
    {
        public static void CreateService()
        {
            string serviceExe = Path.Combine(InstallDir, "PurestateGuard.exe");
            string sc = SystemToolPath("sc.exe");
            DeleteServiceIfExists();
            RunProcess(sc, "create " + ServiceName + " binPath= \"" + serviceExe + "\" start= auto DisplayName= \"" + DisplayName + "\"", true);
            RunProcess(sc, "config " + ServiceName + " start= delayed-auto", true);
            RunProcess(sc, "description " + ServiceName + " \"Haelt Purestate-Regeln im Hintergrund aktiv.\"", true);
            RunProcess(sc, "failure " + ServiceName + " reset= 60 actions= restart/60000/restart/60000/restart/60000", true);
        }

        public static void RegisterNativeMessagingHost()
        {
            string manifestPath = Path.Combine(InstallDir, "native-host", "com.purestate.companion.json");
            if (!File.Exists(manifestPath) || !File.Exists(Path.Combine(InstallDir, "PurestateNativeHost.exe")))
            {
                throw new InvalidOperationException("Der lokale Companion-Host fehlt.");
            }
            string manifestToRegister = GetNativeMessagingManifestPath(manifestPath);

            string[] keys =
            {
                @"SOFTWARE\Google\Chrome\NativeMessagingHosts\com.purestate.companion",
                @"SOFTWARE\Microsoft\Edge\NativeMessagingHosts\com.purestate.companion",
                @"SOFTWARE\WOW6432Node\Google\Chrome\NativeMessagingHosts\com.purestate.companion",
                @"SOFTWARE\WOW6432Node\Microsoft\Edge\NativeMessagingHosts\com.purestate.companion"
            };
            foreach (string keyPath in keys)
            {
                using (RegistryKey key = Registry.LocalMachine.CreateSubKey(keyPath))
                {
                    if (key != null) key.SetValue(string.Empty, manifestToRegister, RegistryValueKind.String);
                }
            }
        }

        public static void UnregisterNativeMessagingHost()
        {
            try { Registry.LocalMachine.DeleteSubKeyTree(@"SOFTWARE\Google\Chrome\NativeMessagingHosts\com.purestate.companion", false); } catch { }
            try { Registry.LocalMachine.DeleteSubKeyTree(@"SOFTWARE\Microsoft\Edge\NativeMessagingHosts\com.purestate.companion", false); } catch { }
            try { Registry.LocalMachine.DeleteSubKeyTree(@"SOFTWARE\WOW6432Node\Google\Chrome\NativeMessagingHosts\com.purestate.companion", false); } catch { }
            try { Registry.LocalMachine.DeleteSubKeyTree(@"SOFTWARE\WOW6432Node\Microsoft\Edge\NativeMessagingHosts\com.purestate.companion", false); } catch { }
        }

        private const string CompanionExtensionId = "gmldhenkcnghfoapdnhkikfpgdmmnlok";
        private const string CompanionExtensionUpdateUrl = "https://clients2.google.com/service/update2/crx";

        // Dev-only escape hatch (see scripts\Common.ps1: Get-DevCompanionExtensionId,
        // which this file mirrors) so the app UI can write the same override the
        // Guard's PowerShell enforcement loop reads - no separate mechanism, one
        // source of truth on disk. Absent by default; tools\Test-ReleasePreflight.ps1
        // hard-fails a release build if this file exists.
        public static string DevCompanionIdPath
        {
            get { return Path.Combine(InstallDir, "dev-companion-id.txt"); }
        }

        private static readonly System.Text.RegularExpressions.Regex DevCompanionIdPattern =
            new System.Text.RegularExpressions.Regex("^[a-p]{32}$", System.Text.RegularExpressions.RegexOptions.None);

        public static bool IsValidDevCompanionId(string candidate)
        {
            return !string.IsNullOrEmpty(candidate) && DevCompanionIdPattern.IsMatch(candidate);
        }

        public static string GetDevCompanionId()
        {
            return GetDevCompanionId(DevCompanionIdPath);
        }

        // Path-parameterized so tests can point at a temp file instead of the
        // real Program Files install directory.
        internal static string GetDevCompanionId(string path)
        {
            // ENS-001: Im ausgelieferten Bau bedeutet die Datei nichts. Sie
            // uebergibt die Companion-Vertrauensrolle an eine beliebige
            // entpackte Erweiterung und nimmt die Store-Erzwingung zurueck -
            // erreichbar mit dem Passwort allein, ohne Abschwaechungsfenster.
            // Gegen den Angreifer des Bedrohungsmodells (der Nutzer selbst, mit
            // Administratorrechten) traegt nur eine Bedingung, die nicht auf der
            // Platte steht: die Compilerkonstante PURESTATE_DEV.
            if (!DevBuild)
            {
                return null;
            }

            try
            {
                if (!File.Exists(path))
                {
                    return null;
                }
                string id = File.ReadAllText(path).Trim();
                return IsValidDevCompanionId(id) ? id : null;
            }
            catch
            {
                return null;
            }
        }

        public static void SetDevCompanionId(string id)
        {
            SetDevCompanionId(id, DevCompanionIdPath);
        }

        internal static void SetDevCompanionId(string id, string path)
        {
            if (!DevBuild)
            {
                throw new InvalidOperationException(
                    "Der Dev-Modus steht nur im Entwicklerbau zur Verfuegung.");
            }

            string trimmed = (id ?? string.Empty).Trim();
            if (!IsValidDevCompanionId(trimmed))
            {
                throw new ArgumentException("Ungueltige Erweiterungs-ID (erwartet: 32 Kleinbuchstaben a-p).");
            }
            string directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }
            File.WriteAllText(path, trimmed, Encoding.ASCII);
        }

        public static void ClearDevCompanionId()
        {
            ClearDevCompanionId(DevCompanionIdPath);
        }

        internal static void ClearDevCompanionId(string path)
        {
            try { File.Delete(path); } catch { }
        }

        internal static string GetNativeMessagingManifestPath(string baseManifestPath)
        {
            return GetNativeMessagingManifestPath(baseManifestPath, GetDevCompanionId());
        }

        internal static string GetNativeMessagingManifestPath(string baseManifestPath, string devCompanionId)
        {
            string devId = (devCompanionId ?? string.Empty).Trim();
            if (string.IsNullOrEmpty(devId))
            {
                return baseManifestPath;
            }
            if (!IsValidDevCompanionId(devId))
            {
                return baseManifestPath;
            }

            string devManifestPath = GetDevNativeMessagingManifestPath(baseManifestPath);
            WriteDevNativeMessagingManifest(devManifestPath, devId);
            return devManifestPath;
        }

        internal static string GetDevNativeMessagingManifestPath(string baseManifestPath)
        {
            string directory = Path.GetDirectoryName(baseManifestPath);
            if (string.IsNullOrEmpty(directory))
            {
                directory = Path.Combine(InstallDir, "native-host");
            }
            return Path.Combine(directory, "com.purestate.companion.dev.json");
        }

        private static void WriteDevNativeMessagingManifest(string manifestPath, string devCompanionId)
        {
            string directory = Path.GetDirectoryName(manifestPath);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }

            string hostPath = Path.Combine(InstallDir, "PurestateNativeHost.exe");
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("{");
            builder.AppendLine("  \"name\": \"com.purestate.companion\",");
            builder.AppendLine("  \"description\": \"Local Purestate Companion heartbeat\",");
            builder.AppendLine("  \"path\": \"" + EscapeJson(hostPath) + "\",");
            builder.AppendLine("  \"type\": \"stdio\",");
            builder.AppendLine("  \"allowed_origins\": [");
            builder.AppendLine("    \"chrome-extension://" + CompanionExtensionId + "/\",");
            builder.AppendLine("    \"chrome-extension://" + devCompanionId + "/\"");
            builder.AppendLine("  ]");
            builder.AppendLine("}");
            File.WriteAllText(manifestPath, builder.ToString(), new UTF8Encoding(false));
        }

        public static void UnregisterManagedCompanionPolicy()
        {
            string[] roots =
            {
                @"SOFTWARE\Policies\Google\Chrome",
                @"SOFTWARE\Policies\Microsoft\Edge"
            };
            foreach (string rootPath in roots)
            {
                try
                {
                    using (RegistryKey root = Registry.LocalMachine.OpenSubKey(rootPath, true))
                    {
                        if (root == null) continue;
                        // Remove only our own entries, so we never delete another
                        // organisation's extension policies on managed devices.
                        RemoveCompanionFromForcelist(root);
                        RemoveCompanionFromExtensionSettings(root);
                    }
                }
                catch
                {
                }
            }
        }

        private static void RemoveCompanionFromForcelist(RegistryKey root)
        {
            using (RegistryKey forceList = root.OpenSubKey("ExtensionInstallForcelist", true))
            {
                if (forceList == null)
                {
                    return;
                }

                foreach (string name in forceList.GetValueNames())
                {
                    string value = Convert.ToString(forceList.GetValue(name)) ?? string.Empty;
                    if (string.Equals(value, CompanionExtensionId, StringComparison.Ordinal) ||
                        value.StartsWith(CompanionExtensionId + ";", StringComparison.Ordinal))
                    {
                        forceList.DeleteValue(name, false);
                    }
                }

                if (forceList.GetValueNames().Length == 0 && forceList.GetSubKeyNames().Length == 0)
                {
                    root.DeleteSubKeyTree("ExtensionInstallForcelist", false);
                }
            }
        }

        private static void RemoveCompanionFromExtensionSettings(RegistryKey root)
        {
            string current = Convert.ToString(root.GetValue("ExtensionSettings")) ?? string.Empty;
            if (current.Trim().Length == 0)
            {
                return;
            }

            string remaining = RemoveCompanionKeyFromJson(current, CompanionExtensionId);
            if (remaining == null)
            {
                // Unparseable value: leave any third-party policy untouched.
                return;
            }

            string trimmed = remaining.Trim();
            if (trimmed.Length == 0 || trimmed == "{}")
            {
                root.DeleteValue("ExtensionSettings", false);
            }
            else if (!string.Equals(trimmed, current.Trim(), StringComparison.Ordinal))
            {
                root.SetValue("ExtensionSettings", trimmed, RegistryValueKind.String);
            }
        }

        // Returns the JSON object with our companion key (and one adjacent
        // comma) removed, the original text if the key is absent, or null if the
        // value is not a JSON object we can safely edit.
        internal static string RemoveCompanionKeyFromJson(string json, string key)
        {
            string trimmed = (json ?? string.Empty).Trim();
            if (!trimmed.StartsWith("{") || !trimmed.EndsWith("}"))
            {
                return null;
            }

            string entry = ExtractJsonObjectForProperty(trimmed, key);
            if (entry.Length == 0)
            {
                return trimmed;
            }

            int keyIdx = FindJsonPropertyIndex(trimmed, key);
            if (keyIdx < 0)
            {
                return trimmed;
            }
            int objStart = trimmed.IndexOf('{', keyIdx);
            if (objStart < 0)
            {
                return trimmed;
            }

            int removeStart = keyIdx;
            int removeEnd = objStart + entry.Length;

            int after = removeEnd;
            while (after < trimmed.Length && char.IsWhiteSpace(trimmed[after]))
            {
                after++;
            }
            if (after < trimmed.Length && trimmed[after] == ',')
            {
                removeEnd = after + 1;
            }
            else
            {
                int before = removeStart - 1;
                while (before >= 0 && char.IsWhiteSpace(trimmed[before]))
                {
                    before--;
                }
                if (before >= 0 && trimmed[before] == ',')
                {
                    removeStart = before;
                }
            }

            return (trimmed.Substring(0, removeStart) + trimmed.Substring(removeEnd)).Trim();
        }

        // Brace-matching extractor for the "{...}" object that follows a JSON
        // property. Mirrors the guard's copy (the guard compiles standalone, so
        // the two cannot share a file). String-based, no JSON dependency.
        // ENS-005: Ein IndexOf auf "<name>" trifft den Namen auch dann, wenn er
        // im WERT einer fremden Eigenschaft steht - etwa in einer
        // blocked_permissions-Liste oder einer override_update_url. Danach
        // entfernte der Aufrufer ein fremdes Objekt aus einer fremden
        // Richtlinie. Der Name zaehlt deshalb nur als Schluessel, wenn er eine
        // vollstaendige JSON-Zeichenkette ist, auf die ein ':' folgt.
        internal static int FindJsonPropertyIndex(string json, string propertyName)
        {
            if (string.IsNullOrEmpty(json) || string.IsNullOrEmpty(propertyName))
            {
                return -1;
            }

            for (int index = 0; index < json.Length; index++)
            {
                if (json[index] != '"')
                {
                    continue;
                }

                int start = index;
                int cursor = index + 1;
                bool escaped = false;
                while (cursor < json.Length)
                {
                    char current = json[cursor];
                    if (escaped)
                    {
                        escaped = false;
                    }
                    else if (current == '\\')
                    {
                        escaped = true;
                    }
                    else if (current == '"')
                    {
                        break;
                    }

                    cursor++;
                }

                if (cursor >= json.Length)
                {
                    return -1;
                }

                string name = json.Substring(start + 1, cursor - start - 1);
                int after = cursor + 1;
                while (after < json.Length && char.IsWhiteSpace(json[after]))
                {
                    after++;
                }

                if (after < json.Length && json[after] == ':' &&
                    string.Equals(name, propertyName, StringComparison.OrdinalIgnoreCase))
                {
                    return start;
                }

                index = cursor;
            }

            return -1;
        }

        internal static string ExtractJsonObjectForProperty(string json, string propertyName)
        {
            int property = FindJsonPropertyIndex(json, propertyName);
            if (property < 0)
            {
                return string.Empty;
            }
            int start = json.IndexOf('{', property + propertyName.Length + 2);
            if (start < 0)
            {
                return string.Empty;
            }

            int depth = 0;
            bool inString = false;
            bool escaped = false;
            for (int index = start; index < json.Length; index++)
            {
                char current = json[index];
                if (inString)
                {
                    if (escaped)
                    {
                        escaped = false;
                    }
                    else if (current == '\\')
                    {
                        escaped = true;
                    }
                    else if (current == '"')
                    {
                        inString = false;
                    }
                    continue;
                }
                if (current == '"')
                {
                    inString = true;
                }
                else if (current == '{')
                {
                    depth++;
                }
                else if (current == '}' && --depth == 0)
                {
                    return json.Substring(start, index - start + 1);
                }
            }
            return string.Empty;
        }

        public static void DeleteServiceIfExists()
        {
            StopService();

            try
            {
                RunProcess(SystemToolPath("sc.exe"), "delete " + ServiceName, true);
                System.Threading.Thread.Sleep(1000);
            }
            catch
            {
            }
        }

        public static void StartService()
        {
            RunProcess(SystemToolPath("sc.exe"), "start " + ServiceName, true);
        }

        // INS-007: "sc stop" kehrt sofort zurueck, waehrend der Dienst noch
        // STOP_PENDING ist. Der Waechterprozess haelt PurestateGuard.exe dann
        // weiter offen, und das Ersetzen der Datei scheitert mit IOException -
        // sichtbar vor allem bei offenem Browser, weil OnStop dort erst die
        // Herzschlagfaeden einsammelt. Gewartet wird auf den Prozess, nicht auf
        // die Statusmeldung des SCM: die Datei ist genau so lange belegt, wie
        // der Prozess lebt.
        public static void StopService()
        {
            try
            {
                RunProcess(SystemToolPath("sc.exe"), "stop " + ServiceName, true);
            }
            catch
            {
            }

            WaitForGuardProcessExit(30000);
        }

        public static void WaitForGuardProcessExit(int timeoutMilliseconds)
        {
            DateTime deadline = DateTime.UtcNow.AddMilliseconds(timeoutMilliseconds);

            while (true)
            {
                if (!GuardProcessRunning())
                {
                    return;
                }

                if (DateTime.UtcNow >= deadline)
                {
                    return;
                }

                System.Threading.Thread.Sleep(250);
            }
        }

        private static bool GuardProcessRunning()
        {
            string expectedPath = Path.GetFullPath(Path.Combine(InstallDir, "PurestateGuard.exe"));
            System.Diagnostics.Process[] processes;

            try
            {
                processes = System.Diagnostics.Process.GetProcessesByName("PurestateGuard");
            }
            catch
            {
                return false;
            }

            foreach (System.Diagnostics.Process process in processes)
            {
                try
                {
                    string processPath = SafeProcessPath(process);

                    // Ist der Pfad nicht lesbar, zaehlt der Prozess als laufend.
                    // Laenger warten kostet Sekunden, zu frueh kopieren kostet
                    // die ganze Aktualisierung.
                    if (string.IsNullOrEmpty(processPath) ||
                        string.Equals(Path.GetFullPath(processPath), expectedPath, StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
                catch
                {
                }
                finally
                {
                    process.Dispose();
                }
            }

            return false;
        }

        public static bool ServiceRunning()
        {
            try
            {
                using (System.ServiceProcess.ServiceController controller = new System.ServiceProcess.ServiceController(ServiceName))
                {
                    return controller.Status == System.ServiceProcess.ServiceControllerStatus.Running;
                }
            }
            catch
            {
                return false;
            }
        }

        // B-1: Das erste Einschalten nach einer Neuinstallation baut alles auf
        // einmal auf - hosts, DNS, Richtlinien, Browser-Neustart - und brauchte
        // live laenger als die allgemeinen 90 Sekunden je Hilfsprozess.
        private const int ReapplyProcessTimeoutMilliseconds = 180000;

        public static void EnforceProtection()
        {
            RunPowerShellFile(Path.Combine(InstallDir, "scripts", "Enforce-Protection.ps1"), "-Quiet");
        }

        // B-3: Ein langsamer Aufbau darf nach dem Kopieren nicht die restliche
        // Registrierung abbrechen. Der getoetete Helfer laeuft NICHT weiter:
        // erst der laufende Dienst kann den Aufbau erneut versuchen.
        public static bool ActivateInstalledProtection()
        {
            bool applied = ActivateInstalledProtection(
                delegate { RunPowerShellFile(Path.Combine(InstallDir, "scripts", "Enforce-Protection.ps1"), "-Quiet", 180000); },
                EnsureInstalledServiceRunning);
            if (!applied)
            {
                WriteActivityLog("Install protection helper timed out; the running guard will retry enforcement.");
            }
            return applied;
        }

        internal static bool ActivateInstalledProtection(Action enforce, Action ensureServiceRunning)
        {
            bool applied = true;
            try
            {
                enforce();
            }
            catch (TimeoutException)
            {
                applied = false;
            }

            // Dienstfehler bleiben Fehler, auch nach einem Aufbauzeitlimit.
            ensureServiceRunning();
            return applied;
        }

        private static void EnsureInstalledServiceRunning()
        {
            using (System.ServiceProcess.ServiceController controller = new System.ServiceProcess.ServiceController(ServiceName))
            {
                EnsureInstalledServiceRunning(
                    delegate { controller.Refresh(); return controller.Status; },
                    delegate { controller.Start(); },
                    delegate { controller.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(30)); });
            }
        }

        // Ein bereits vor dem Installationsmarker angelaufener Watchdog kann
        // den Dienst inzwischen gestartet haben, auch zwischen Status und Start.
        internal static void EnsureInstalledServiceRunning(Func<ServiceControllerStatus> status, Action start, Action waitForRunning)
        {
            ServiceControllerStatus current = status();
            if (current == ServiceControllerStatus.Running)
            {
                return;
            }
            if (current != ServiceControllerStatus.StartPending)
            {
                try
                {
                    start();
                }
                catch (InvalidOperationException)
                {
                    current = status();
                    if (current != ServiceControllerStatus.Running && current != ServiceControllerStatus.StartPending)
                    {
                        throw;
                    }
                }
            }
            waitForRunning();
            if (status() != ServiceControllerStatus.Running)
            {
                throw new InvalidOperationException("Der Purestate-Dienst konnte nicht gestartet werden.");
            }
        }

        // Wie EnforceProtection, baut ausgeschaltete Schichten aber zusaetzlich
        // ab (Enable-Protection -Reconcile). Nur fuer das Speichern.
        private static void ReconcileProtection(int timeoutMilliseconds)
        {
            RunPowerShellFile(Path.Combine(InstallDir, "scripts", "Enforce-Protection.ps1"), "-Quiet -Reconcile", timeoutMilliseconds);
        }

        public static void ClearProtection()
        {
            ClearProtection(DefaultProcessTimeoutMilliseconds);
        }

        private static void ClearProtection(int timeoutMilliseconds)
        {
            RunPowerShellFile(Path.Combine(InstallDir, "scripts", "Clear-Protection.ps1"), "-RestoreDns -Quiet", timeoutMilliseconds);
        }

        // Speichern gleicht ab statt abzureissen (INS-001 Fix 2, B-2): Soll der
        // Schutz an sein, laeuft ein einziger Durchlauf, der Eingeschaltetes
        // aufbaut und Ausgeschaltetes gezielt abbaut. Der fruehere Abriss vor
        // jedem Aufbau kostete in der VM Minuten und liess den Rechner dazwischen
        // ungeschuetzt. Soll der Schutz aus sein, baut Clear-Protection wie
        // bisher alles ab.
        public static void ReapplyProtection()
        {
            ReapplyProtection(
                delegate { ClearProtection(ReapplyProcessTimeoutMilliseconds); },
                delegate { return ProtectionShouldBeActive(LoadConfig()); },
                delegate { ReconcileProtection(ReapplyProcessTimeoutMilliseconds); });
            if (reapplyStillRunning)
            {
                WriteActivityLog("Protection reapply hit the helper time limit; the guard finishes it on its next pass.");
            }
        }

        // Nur fuer die Rueckmeldung: RunAction fragt direkt nach dem Speichern
        // auf demselben Thread nach. ThreadStatic, damit kein anderer Lauf die
        // Antwort setzt oder abholt.
        [ThreadStatic]
        private static bool reapplyStillRunning;

        public static bool TakeReapplyStillRunning()
        {
            bool stillRunning = reapplyStillRunning;
            reapplyStillRunning = false;
            return stillRunning;
        }

        // B-1: Ein Zeitlimit beim Abgleich ist kein Fehler. Gespeichert ist die
        // Einstellung schon, und der Waechter baut den Schutz in jedem Takt
        // (30 s) ohnehin auf. Abbauen tut der Waechter nie: ein abgebrochener
        // Abbau bleibt deshalb ein Fehler.
        internal static void ReapplyProtection(Action clear, Func<bool> shouldEnforce, Action enforce)
        {
            reapplyStillRunning = false;
            if (!shouldEnforce())
            {
                clear();
                return;
            }
            try
            {
                enforce();
            }
            catch (TimeoutException)
            {
                reapplyStillRunning = true;
            }
        }

        // true  = repariert.
        // false = Programmdateien oder Passwort fehlten, das
        //         Installationsprogramm wurde dafuer gestartet.
        //
        // Fehlende Programmdateien kann die Reparatur nicht aus dem Nichts
        // erzeugen - Installieren.exe liegt aber im Installationsordner und
        // bringt sie mit. Der Nutzer hat die Reparatur bereits mit Passwort
        // bestaetigt; ihn danach zu bitten, selbst ein Programm zu starten,
        // waere genau der Handgriff, den die App abnehmen kann.
        public static bool RepairInstalledApp()
        {
            string serviceExe = Path.Combine(InstallDir, "PurestateGuard.exe");
            string appExe = Path.Combine(InstallDir, "Purestate.exe");
            string enforceScript = Path.Combine(InstallDir, "scripts", "Enforce-Protection.ps1");
            string clearScript = Path.Combine(InstallDir, "scripts", "Clear-Protection.ps1");
            string watchdogScript = Path.Combine(InstallDir, "scripts", "Watchdog.ps1");

            if (!File.Exists(serviceExe) || !File.Exists(appExe) || !File.Exists(enforceScript) || !File.Exists(clearScript) || !File.Exists(watchdogScript))
            {
                if (TryStartInstaller())
                {
                    WriteActivityLog("Repair started the installer because installed files are missing.");
                    return false;
                }

                throw new InvalidOperationException(
                    "Die Installation ist unvollstaendig und Installieren.exe fehlt ebenfalls. Bitte das Purestate-Paket erneut entpacken.");
            }

            return RunRepairWithRestore(RunRepairSteps, TryRestoreProtectionAfterFailedInstall);
        }

        // ENS-003: Der erste wirksame Schritt der Reparatur loescht den Dienst,
        // gestartet wird er als letzter. Wirft irgendetwas dazwischen - am
        // wahrscheinlichsten "sc create" auf einen nur zur Loeschung
        // vorgemerkten Dienst -, blieb der Rechner ohne Dienst zurueck, und
        // zwar genau in der Lage, in der der Nutzer die Reparatur ein zweites
        // Mal drueckt. TryRestoreProtectionAfterFailedInstall war fuer diesen
        // Fall geschrieben, hing aber nur am Installationspfad. Der Fehler
        // geht trotzdem nicht verloren - die Meldung ist das, was der Nutzer
        // sehen muss.
        internal static bool RunRepairWithRestore(Func<bool> repair, Func<bool> restoreAfterFailure)
        {
            try
            {
                return repair();
            }
            catch
            {
                restoreAfterFailure();
                throw;
            }
        }

        private static bool RunRepairSteps()
        {
            EnsureDataDir();
            TightenDataFolderAcl();
            TightenInstallFolderAcl();
            CreateService();
            RegisterNativeMessagingHost();
            CreateShortcuts();
            RegisterAppEntry();
            RegisterUserStartupEntry();
            RegisterWatchdogTask();

            AppConfig config = LoadConfig();
            if (config.Password == null)
            {
                // Ein Passwort einzurichten ist Sache des Installationsprogramms;
                // es startet dafuer selbst.
                if (TryStartInstaller())
                {
                    WriteActivityLog("Repair started the installer because no password is set up.");
                    return false;
                }

                throw new InvalidOperationException(
                    "Es ist noch kein Passwort eingerichtet und Installieren.exe fehlt. Bitte das Purestate-Paket erneut entpacken.");
            }

            if (ProtectionShouldBeActive(config))
            {
                EnforceProtection();
                StartService();
            }
            else
            {
                StopService();
                ClearProtection();
            }

            WriteActivityLog("Repair completed.");
            return true;
        }

        private static bool TryStartInstaller()
        {
            string installer = Path.Combine(InstallDir, "Installieren.exe");
            if (!File.Exists(installer))
            {
                return false;
            }

            try
            {
                System.Diagnostics.ProcessStartInfo info = new System.Diagnostics.ProcessStartInfo();
                info.FileName = installer;
                info.UseShellExecute = true;
                info.WorkingDirectory = InstallDir;
                System.Diagnostics.Process.Start(info);
                return true;
            }
            catch
            {
                return false;
            }
        }

        // Confirms the package about to be installed actually contains its core
        // files (non-empty) before the caller tears down any running protection.
        // Throws if anything is missing so an incomplete/corrupt package can
        // never replace a working install.
        public static void VerifyInstallSource(string sourceDir)
        {
            string[] required =
            {
                "Purestate.exe",
                "PurestateGuard.exe",
                "PurestateNativeHost.exe",
                "PurestateUninstaller.exe",
                Path.Combine("native-host", "com.purestate.companion.json"),
                Path.Combine("scripts", "Common.ps1"),
                Path.Combine("scripts", "Enforce-Protection.ps1"),
                Path.Combine("scripts", "Clear-Protection.ps1"),
                Path.Combine("scripts", "Watchdog.ps1"),
                Path.Combine("extension", "purestate-companion", "manifest.json")
            };

            System.Collections.Generic.List<string> missing = new System.Collections.Generic.List<string>();
            foreach (string relative in required)
            {
                try
                {
                    FileInfo info = new FileInfo(Path.Combine(sourceDir, relative));
                    if (!info.Exists || info.Length == 0)
                    {
                        missing.Add(relative);
                    }
                }
                catch
                {
                    missing.Add(relative);
                }
            }

            if (missing.Count > 0)
            {
                throw new InvalidOperationException(
                    "Das Installationspaket ist unvollstaendig und wurde nicht angewendet (der bestehende Schutz bleibt unveraendert). Fehlende Dateien: " +
                    string.Join(", ", missing.ToArray()));
            }
        }

        // Best-effort recovery after a failed install/update: if a runnable
        // guard and the enforcement script are present, re-create the service
        // and re-enforce protection so the machine is not left unprotected.
        // Returns true only if protection was actively restored.
        public static bool TryRestoreProtectionAfterFailedInstall()
        {
            try
            {
                string guard = Path.Combine(InstallDir, "PurestateGuard.exe");
                string enforce = Path.Combine(InstallDir, "scripts", "Enforce-Protection.ps1");
                if (!File.Exists(guard) || !File.Exists(enforce))
                {
                    return false;
                }

                AppConfig config = LoadConfig();
                if (config == null || config.Password == null || !ProtectionShouldBeActive(config))
                {
                    return false;
                }

                CreateService();
                EnforceProtection();
                StartService();
                WriteSecurityLog("Protection restored after a failed install or update.");
                return true;
            }
            catch (Exception ex)
            {
                WriteSecurityLog("Protection restore after a failed install failed: " + ex.Message);
                return false;
            }
        }

        public static void RegisterWatchdogTask()
        {
            string powershell = PowerShellExecutablePath();
            string schtasks = SystemToolPath("schtasks.exe");
            string watchdog = Path.Combine(InstallDir, "scripts", "Watchdog.ps1");

            if (!File.Exists(watchdog))
            {
                throw new InvalidOperationException("Watchdog.ps1 wurde nicht gefunden.");
            }

            EnsureTaskSchedulerFolder(powershell);
            string taskRun = "\\\"" + powershell + "\\\" -NoProfile -ExecutionPolicy Bypass -File \\\"" + watchdog + "\\\"";
            string arguments = "/Create /TN \"" + WatchdogTaskName + "\" /SC MINUTE /MO 5 /RU SYSTEM /RL HIGHEST /TR \"" + taskRun + "\" /F";
            RunProcess(schtasks, arguments, true);
            string startupArguments = "/Create /TN \"" + StartupTaskName + "\" /SC ONSTART /DELAY 0000:20 /RU SYSTEM /RL HIGHEST /TR \"" + taskRun + "\" /F";
            RunProcess(schtasks, startupArguments, true);
            WriteActivityLog("Watchdog and startup tasks registered.");
        }

        private static void EnsureTaskSchedulerFolder(string powershell)
        {
            // Der innere catch faengt den verwaisten Ordner ab: nach einer
            // Deinstallation koennen die Aufgabendateien unter
            // %WINDIR%\System32\Tasks\Purestate liegenbleiben, waehrend der
            // Planer den Ordner nicht mehr kennt. Dann scheitert GetFolder
            // (kennt ihn nicht) UND CreateFolder (Verzeichnis existiert,
            // 0x800700B7), und die Installation bricht mit "Ein
            // Windows-Hilfsprozess konnte nicht erfolgreich abgeschlossen
            // werden" ab. Live am 2026-08-04 getroffen; eine Neuinstallation
            // nach einer Deinstallation ist ein normaler Weg, kein Sonderfall.
            string script =
                "$scheduler = New-Object -ComObject 'Schedule.Service'; " +
                "$scheduler.Connect(); " +
                "try { $null = $scheduler.GetFolder('\\Purestate') } " +
                "catch { $root = $scheduler.GetFolder('\\'); " +
                "try { $null = $root.CreateFolder('Purestate') } " +
                "catch { Remove-Item -LiteralPath (Join-Path $env:WINDIR 'System32\\Tasks\\Purestate') -Recurse -Force -ErrorAction SilentlyContinue; " +
                "$null = $root.CreateFolder('Purestate') } }";
            string encoded = Convert.ToBase64String(System.Text.Encoding.Unicode.GetBytes(script));
            RunProcess(
                powershell,
                "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + encoded,
                true);
        }

        public static void UnregisterWatchdogTask()
        {
            try
            {
                string schtasks = SystemToolPath("schtasks.exe");
                DeleteTaskIfPresent(schtasks, WatchdogTaskName);
                DeleteTaskIfPresent(schtasks, StartupTaskName);
                DeleteTaskIfPresent(schtasks, BadgeTaskName);
                DeleteTaskIfPresent(schtasks, TrayTaskName);
                DeleteTaskIfPresent(schtasks, OpenTaskName);
                RemoveTaskSchedulerFolder(PowerShellExecutablePath());
                WriteActivityLog("Watchdog, startup, badge, tray and open tasks removed.");
            }
            catch
            {
            }
        }

        // schtasks.exe meldet Exitcode 1, wenn die Aufgabe gar nicht existiert,
        // und RunProcess wirft darauf. Ohne eigene Kapselung haette eine
        // fehlende Aufgabe alle folgenden Schritte uebersprungen - auch das
        // Entfernen des Ordners. Die Abzeichen-Aufgabe fehlt im Normalfall
        // (sie entsteht nur, wenn das Videospiel-Abzeichen einmal lief).
        private static void DeleteTaskIfPresent(string schtasks, string taskName)
        {
            try
            {
                RunProcess(schtasks, "/Delete /TN \"" + taskName + "\" /F", true);
            }
            catch
            {
            }
        }

        // Removes the now-empty "\Purestate" Task Scheduler folder that
        // EnsureTaskSchedulerFolder created, so an uninstall leaves nothing
        // behind. schtasks.exe cannot delete folders, so this uses the same COM
        // service as EnsureTaskSchedulerFolder. Best-effort: DeleteFolder throws
        // if the folder is missing or still holds a task, which is fine.
        private static void RemoveTaskSchedulerFolder(string powershell)
        {
            string script =
                "$scheduler = New-Object -ComObject 'Schedule.Service'; " +
                "$scheduler.Connect(); " +
                "try { $root = $scheduler.GetFolder('\\'); $root.DeleteFolder('Purestate', 0) } catch { }";
            string encoded = Convert.ToBase64String(System.Text.Encoding.Unicode.GetBytes(script));
            RunProcess(
                powershell,
                "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + encoded,
                true);
        }

        // ENS-002: Frueher zaehlte nur, ob "schtasks /Query" ohne Fehler
        // durchlaeuft - also ob die Aufgabe EXISTIERT. Wer sie deaktiviert statt
        // sie zu loeschen, blieb unbemerkt: die Anzeige meldete sie als
        // eingerichtet, und Ensure-WatchdogTask legte sie nie neu an, weil die
        // Abfrage ja erfolgreich war. Der Angreifer des Bedrohungsmodells - der
        // Nutzer selbst mit Administratorrechten - kommt an diesen Schalter.
        public static bool WatchdogTaskRegistered()
        {
            // ENS-004: Jede Statusaktualisierung startete zwei schtasks-Prozesse,
            // nur um zu erfahren, ob zwei Aufgaben aktiviert sind. Der Planer
            // beantwortet dieselbe Frage ueber COM ohne einen einzigen
            // Prozessstart. Antwortet COM nicht, bleibt der alte Weg.
            bool watchdogEnabled;
            bool startupEnabled;
            if (ScheduledTasksEnabledViaCom(WatchdogTaskName, StartupTaskName, out watchdogEnabled, out startupEnabled))
            {
                return watchdogEnabled && startupEnabled;
            }

            return ScheduledTaskEnabled(WatchdogTaskName) && ScheduledTaskEnabled(StartupTaskName);
        }

        // Gibt false zurueck, wenn der Planer ueber COM nicht erreichbar ist -
        // dann sagen die Ausgabewerte nichts. Eine fehlende Aufgabe ist dagegen
        // eine gueltige Antwort: nicht aktiviert.
        internal static bool ScheduledTasksEnabledViaCom(string firstTask, string secondTask, out bool firstEnabled, out bool secondEnabled)
        {
            firstEnabled = false;
            secondEnabled = false;

            try
            {
                Type schedulerType = Type.GetTypeFromProgID("Schedule.Service");
                if (schedulerType == null)
                {
                    return false;
                }

                object scheduler = Activator.CreateInstance(schedulerType);
                schedulerType.InvokeMember("Connect", System.Reflection.BindingFlags.InvokeMethod, null, scheduler, new object[0]);
                object root = schedulerType.InvokeMember("GetFolder", System.Reflection.BindingFlags.InvokeMethod, null, scheduler, new object[] { "\\" });
                if (root == null)
                {
                    return false;
                }

                firstEnabled = ScheduledTaskEnabledInFolder(root, firstTask);
                secondEnabled = ScheduledTaskEnabledInFolder(root, secondTask);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private static bool ScheduledTaskEnabledInFolder(object folder, string taskName)
        {
            try
            {
                // GetTask wirft, wenn die Aufgabe fehlt - das ist der Normalfall
                // vor der Installation und heisst schlicht "nicht aktiviert".
                object task = folder.GetType().InvokeMember("GetTask", System.Reflection.BindingFlags.InvokeMethod, null, folder, new object[] { taskName });
                if (task == null)
                {
                    return false;
                }

                object enabled = task.GetType().InvokeMember("Enabled", System.Reflection.BindingFlags.GetProperty, null, task, null);
                return enabled is bool && (bool)enabled;
            }
            catch
            {
                return false;
            }
        }

        private static bool ScheduledTaskEnabled(string taskName)
        {
            try
            {
                string schtasks = SystemToolPath("schtasks.exe");
                string xml = RunProcess(schtasks, "/Query /TN \"" + taskName + "\" /XML ONE", true);
                return ScheduledTaskXmlIsEnabled(xml);
            }
            catch
            {
                return false;
            }
        }

        // Ausgewertet wird die XML-Ausgabe, nicht der Anzeigetext: "Deaktiviert",
        // "Disabled", "Desactivado" - die Textausgabe von schtasks ist
        // lokalisiert, das <Enabled>-Element nicht. Fehlt das Element, ist die
        // Aufgabe aktiviert; so legt Windows sie an.
        internal static bool ScheduledTaskXmlIsEnabled(string taskXml)
        {
            string xml = (taskXml ?? string.Empty).Trim();
            if (xml.Length == 0)
            {
                return false;
            }

            System.Text.RegularExpressions.Match match =
                System.Text.RegularExpressions.Regex.Match(
                    xml,
                    @"<Enabled\s*>\s*(?<value>true|false)\s*</Enabled\s*>",
                    System.Text.RegularExpressions.RegexOptions.IgnoreCase);

            return !match.Success ||
                string.Equals(match.Groups["value"].Value.Trim(), "true", StringComparison.OrdinalIgnoreCase);
        }

        public static void CreateShortcuts()
        {
            string programs = Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms);
            string folder = Path.Combine(programs, "Purestate");
            Directory.CreateDirectory(folder);

            CreateShortcut(Path.Combine(folder, "Purestate.lnk"), Path.Combine(InstallDir, "Purestate.exe"), InstallDir, "Purestate verwalten");
            CreateShortcut(Path.Combine(folder, "Purestate reparieren oder aktualisieren.lnk"), Path.Combine(InstallDir, "Installieren.exe"), InstallDir, "Purestate reparieren oder aktualisieren");
            CreateShortcut(Path.Combine(folder, "Purestate deinstallieren.lnk"), Path.Combine(InstallDir, "PurestateUninstaller.exe"), InstallDir, "Purestate entfernen");
        }

        public static void RemoveShortcuts()
        {
            string folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms), "Purestate");
            try
            {
                if (Directory.Exists(folder))
                {
                    Directory.Delete(folder, true);
                }
            }
            catch
            {
            }
        }

        public static void TightenDataFolderAcl()
        {
            try
            {
                EnsureDataDir();
                RunProcess(SystemToolPath("icacls.exe"), "\"" + DataDir + "\" /inheritance:r /grant:r \"*S-1-5-18:(OI)(CI)F\" \"*S-1-5-32-544:(OI)(CI)F\"", true);
            }
            catch (Exception ex)
            {
                // A failed hardening leaves config.json (password hash +
                // ProtectionEnabled) editable by standard users. That silently
                // defeats the whole protection, so it must never be swallowed:
                // log it and abort the calling install/repair so the UI reports
                // "not protected" instead of a false-secure state.
                WriteSecurityLog("Data folder ACL hardening failed: " + ex.Message);
                throw new InvalidOperationException(
                    "Der Datenordner konnte nicht abgesichert werden. Bitte starte die Installation als Administrator erneut.",
                    ex);
            }
        }

        public static void TightenInstallFolderAcl()
        {
            try
            {
                Directory.CreateDirectory(InstallDir);
                RunProcess(
                    SystemToolPath("icacls.exe"),
                    "\"" + InstallDir + "\" /inheritance:r /grant:r \"*S-1-5-18:(OI)(CI)F\" \"*S-1-5-32-544:(OI)(CI)F\" \"*S-1-5-32-545:(OI)(CI)RX\"",
                    true);
            }
            catch (Exception ex)
            {
                // A failed hardening leaves the install folder (guard exe,
                // scripts, rule files) writable by standard users, which lets
                // the protection be replaced. Do not swallow this: log it and
                // abort the calling install/repair so the UI reports the
                // failure instead of a false-secure state.
                WriteSecurityLog("Install folder ACL hardening failed: " + ex.Message);
                throw new InvalidOperationException(
                    "Der Installationsordner konnte nicht abgesichert werden. Bitte starte die Installation als Administrator erneut.",
                    ex);
            }
        }

        private static void CreateShortcut(string shortcutPath, string targetPath, string workingDirectory, string description)
        {
            Type shellType = Type.GetTypeFromProgID("WScript.Shell");
            object shell = Activator.CreateInstance(shellType);
            object shortcut = shellType.InvokeMember("CreateShortcut", System.Reflection.BindingFlags.InvokeMethod, null, shell, new object[] { shortcutPath });
            Type shortcutType = shortcut.GetType();
            shortcutType.InvokeMember("TargetPath", System.Reflection.BindingFlags.SetProperty, null, shortcut, new object[] { targetPath });
            shortcutType.InvokeMember("WorkingDirectory", System.Reflection.BindingFlags.SetProperty, null, shortcut, new object[] { workingDirectory });
            shortcutType.InvokeMember("Description", System.Reflection.BindingFlags.SetProperty, null, shortcut, new object[] { description });
            shortcutType.InvokeMember("IconLocation", System.Reflection.BindingFlags.SetProperty, null, shortcut, new object[] { targetPath + ",0" });
            shortcutType.InvokeMember("Save", System.Reflection.BindingFlags.InvokeMethod, null, shortcut, null);
        }
    }
}
