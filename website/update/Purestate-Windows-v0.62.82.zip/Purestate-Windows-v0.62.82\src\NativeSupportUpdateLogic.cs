using System;
using System.Collections.Generic;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace Purestate.Native
{
    // Ein gelesenes latest.json. Der Parser prueft die Form, nicht die Herkunft:
    // vertrauenswuerdig ist es erst, wenn VerifyUpdateSignature fuer dieselben
    // Bytes gelungen ist.
    internal sealed class UpdateManifest
    {
        public string Version = string.Empty;
        public string Date = string.Empty;
        public string ZipUrl = string.Empty;
        public long ZipSize;
        public string ZipSha256 = string.Empty;
        public string Notes = string.Empty;
    }

    // Zustand der Update-Suche je Windows-Profil (update-state.json unter
    // %LOCALAPPDATA%\Purestate). Nichts daran ist sicherheitsrelevant: ein
    // verfaelschter Zustand kann hoechstens eine Pruefung oder eine
    // Benachrichtigung auslassen oder wiederholen.
    internal sealed class UpdateState
    {
        public DateTime LastCheckUtc = DateTime.MinValue;
        public string LastSeenVersion = string.Empty;
        public string LastNotifiedVersion = string.Empty;
        public DateTime LastNotifiedUtc = DateTime.MinValue;
    }

    // Reine Logik der Update-Suche: Signatur, Manifest, Versionsvergleich, Takt.
    // Kein Netz, keine Dateien - Abruf und Ablage stehen in PurestateUpdate.cs,
    // das in keiner Compile-Liste des Guard steht. Der Guard bleibt netzfrei.
    internal static partial class Support
    {
        // Oeffentliche Update-Schluessel im Format "base64(Modulus).base64(Exponent)".
        // Leer = unbelegt: VerifyUpdateSignature nimmt dann nichts an, die
        // Update-Suche bleibt inert (wie AuthorityShutdownUrl). tools\New-UpdateKey.ps1
        // erzeugt beide Paare; Test-ReleasePreflight.ps1 lehnt ein Paket mit leerem
        // Hauptschluessel ab. Der Reserveschluessel liegt getrennt und signiert nur,
        // wenn der Hauptschluessel verloren ist.
        public const string UpdateSigningKeyPrimary = "5US29uTibO3TD1tAVF39kgAUIJrrL7n1TKhhkZ68ZGbNoNl7CgaJDyRYMr+Lq0BeXYkxOf655GiVljSJZe8rAcXb4dFwWdJGOKQYt1flP2nOHR92fxuA1HwOLeUsfrqzXN3jLlrJuRQt/HmouL2xx6CISDNF2QVLu/wWyC7M/H4I6DB6zuBTKBRHZAWf9nqob6IKqXPFKvADjFlSxZM0DJfqjJfhkc8wYBelQW+1ZWrkS2XptwZ5dC60OUgCPTIc2gWTZwxXYQuExDwur+AEFdzyaG5s60n1wb/o2Wj1e2h0+FjgLjAS9a16+g0DwXgqe1kSF9EZqEczn9Ju8tewzQ==.AQAB";
        public const string UpdateSigningKeySpare = "2+G92oTuDYsi9alixfrH9GwRk8sfKzDJGCXRoD6GPvqngwnqquIJpYN2VjfXxPJq9WwNY2ychXuTzX+8tVNX1NvaLna3GB/BtbwG5jE6QvG8uQiHDQ8Yom7IVOctWiEG8/UseM5CGduOMCpkbOHqjS/eUq8kq+TJwK9HJ6FAQoxhZUunCcvqh6YK4AbTO9oXfLtFSAu3bNYsZ9SpSSh4BWoWE3afbeFZVlRRuI34puSJsy21Q4J9eLiu7D6jvTnDPOCc1qlRmfibcVAkpH0bVx7tRIaBTzUb/3i8nGkHLZBNJVxe5w0Wqb2X1HvBVBi3+bq/EuLVER+Mitl22H0GAQ==.AQAB";

        // Nur unter dieser Adresse liegen Manifest, Signatur und ZIP.
        public const string UpdateBaseUrl = "https://purestate-app.com/update/";
        public const string UpdateManifestFile = "latest.json";
        public const string UpdateSignatureFile = "latest.sig";

        public const int UpdateManifestMaxBytes = 16 * 1024;
        public const long UpdateZipMaxBytes = 20L * 1024 * 1024;
        public const int UpdateNotesMaxChars = 800;
        public const int UpdateCheckIntervalHours = 24;
        public const int UpdateReminderDays = 3;
        public const int UpdateLaterHours = 24;

        // Im Entwicklerbau darf ein Test-Server die Adresse ersetzen und ein
        // zusaetzlicher Testschluessel mitpruefen. Im ausgelieferten Bau gibt es
        // diesen Zweig nicht (wie DevBuild); Test-ReleasePreflight.ps1 lehnt
        // Entwicklerbauten ab.
        internal static string UpdateBase()
        {
#if PURESTATE_DEV
            string overrideBase = Environment.GetEnvironmentVariable("PURESTATE_UPDATE_BASE");
            if (!string.IsNullOrEmpty(overrideBase))
            {
                return overrideBase.EndsWith("/", StringComparison.Ordinal) ? overrideBase : overrideBase + "/";
            }
#endif
            return UpdateBaseUrl;
        }

        private static string[] UpdateAcceptedKeys()
        {
#if PURESTATE_DEV
            string testKey = Environment.GetEnvironmentVariable("PURESTATE_UPDATE_TEST_KEY");
            if (!string.IsNullOrEmpty(testKey))
            {
                return new string[] { UpdateSigningKeyPrimary, UpdateSigningKeySpare, testKey };
            }
#endif
            return new string[] { UpdateSigningKeyPrimary, UpdateSigningKeySpare };
        }

        // ---- Signatur -------------------------------------------------------------

        public static bool VerifyUpdateSignature(byte[] manifestBytes, string signatureBase64)
        {
            return VerifyUpdateSignature(manifestBytes, signatureBase64, UpdateAcceptedKeys());
        }

        // Gueltig, wenn EINER der Schluessel passt. Ein leerer oder unlesbarer
        // Eintrag wird uebersprungen, nie als "passt" gewertet.
        internal static bool VerifyUpdateSignature(byte[] manifestBytes, string signatureBase64, string[] publicKeys)
        {
            if (manifestBytes == null || manifestBytes.Length == 0 || publicKeys == null ||
                string.IsNullOrWhiteSpace(signatureBase64))
            {
                return false;
            }

            byte[] signature;
            try
            {
                signature = Convert.FromBase64String(signatureBase64.Trim());
            }
            catch (FormatException)
            {
                return false;
            }

            foreach (string encoded in publicKeys)
            {
                RSA key;
                if (!TryParseDevicePublicKey(encoded, out key))
                {
                    continue;
                }

                using (key)
                {
                    try
                    {
                        if (key.VerifyData(manifestBytes, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1))
                        {
                            return true;
                        }
                    }
                    catch (CryptographicException)
                    {
                    }
                }
            }

            return false;
        }

        // ---- Manifest ---------------------------------------------------------------

        private static readonly Regex PlainVersionPattern = new Regex(@"^\d{1,4}\.\d{1,4}\.\d{1,4}$", RegexOptions.CultureInvariant);

        internal static bool IsPlainVersion(string version)
        {
            return version != null && PlainVersionPattern.IsMatch(version);
        }

        public static bool TryParseUpdateManifest(byte[] bytes, out UpdateManifest manifest)
        {
            return TryParseUpdateManifest(bytes, UpdateBase(), out manifest);
        }

        // Form pruefen, nicht Herkunft. Die ZIP-Adresse ist nicht frei waehlbar:
        // genau Basisadresse + "Purestate-Windows-v<Version>.zip", sonst nichts.
        internal static bool TryParseUpdateManifest(byte[] bytes, string baseUrl, out UpdateManifest manifest)
        {
            manifest = null;
            if (bytes == null || bytes.Length == 0 || bytes.Length > UpdateManifestMaxBytes)
            {
                return false;
            }

            string json;
            try
            {
                // Streng: ungueltiges UTF-8 wirft, statt Ersatzzeichen einzusetzen.
                json = new UTF8Encoding(false, true).GetString(bytes);
            }
            catch (ArgumentException)
            {
                return false;
            }

            List<TopLevelJsonProperty> properties;
            if (!TryReadTopLevelJsonProperties(json, out properties) || properties.Count == 0 ||
                HasDuplicateTopLevelJsonProperties(properties))
            {
                return false;
            }

            long schema;
            long zipSize;
            string version;
            string date;
            string zipUrl;
            string zipSha256;
            string notes;
            if (!TryReadTopLevelLong(json, properties, "schema", out schema) || schema != 1 ||
                !TryReadTopLevelString(json, properties, "version", out version) ||
                !TryReadTopLevelString(json, properties, "date", out date) ||
                !TryReadTopLevelString(json, properties, "zipUrl", out zipUrl) ||
                !TryReadTopLevelLong(json, properties, "zipSize", out zipSize) ||
                !TryReadTopLevelString(json, properties, "zipSha256", out zipSha256) ||
                !TryReadTopLevelString(json, properties, "notes", out notes))
            {
                return false;
            }

            if (!IsPlainVersion(version) ||
                !Regex.IsMatch(date, @"^\d{4}-\d{2}-\d{2}$", RegexOptions.CultureInvariant) ||
                !Regex.IsMatch(zipSha256, "^[0-9a-fA-F]{64}$", RegexOptions.CultureInvariant) ||
                zipSize <= 0 || zipSize > UpdateZipMaxBytes ||
                notes.Length > UpdateNotesMaxChars ||
                !string.Equals(zipUrl, baseUrl + "Purestate-Windows-v" + version + ".zip", StringComparison.Ordinal))
            {
                return false;
            }

            manifest = new UpdateManifest();
            manifest.Version = version;
            manifest.Date = date;
            manifest.ZipUrl = zipUrl;
            manifest.ZipSize = zipSize;
            manifest.ZipSha256 = zipSha256.ToLowerInvariant();
            manifest.Notes = notes;
            return true;
        }

        private static bool TryReadTopLevelString(string json, IList<TopLevelJsonProperty> properties, string name, out string value)
        {
            value = string.Empty;
            foreach (TopLevelJsonProperty property in properties)
            {
                if (!string.Equals(property.Name, name, StringComparison.Ordinal))
                {
                    continue;
                }

                int stringEnd;
                return property.ValueStart < json.Length && json[property.ValueStart] == '"' &&
                    TryReadJsonString(json, property.ValueStart, out value, out stringEnd);
            }

            return false;
        }

        private static bool TryReadTopLevelLong(string json, IList<TopLevelJsonProperty> properties, string name, out long value)
        {
            value = 0;
            foreach (TopLevelJsonProperty property in properties)
            {
                if (!string.Equals(property.Name, name, StringComparison.Ordinal))
                {
                    continue;
                }

                int start = property.ValueStart;
                int end = start;
                while (end < json.Length && json[end] >= '0' && json[end] <= '9')
                {
                    end++;
                }

                // "12abc" oder "1.5" sind keine ganze Zahl.
                int delimiter = end;
                while (delimiter < json.Length && char.IsWhiteSpace(json[delimiter]))
                {
                    delimiter++;
                }

                if (end == start || end - start > 12 || delimiter >= json.Length ||
                    (json[delimiter] != ',' && json[delimiter] != '}'))
                {
                    return false;
                }

                return long.TryParse(json.Substring(start, end - start), NumberStyles.None, CultureInfo.InvariantCulture, out value);
            }

            return false;
        }

        // ---- Version und Takt -------------------------------------------------------

        public static bool IsUpdateNewer(string version)
        {
            return IsUpdateNewer(version, AppVersion);
        }

        // Streng hoeher. Alles, was keine "x.y.z" ist, gilt nie als neuer - auch
        // dann nicht, wenn CompareVersionStrings Unsinn als 0 lesen wuerde.
        internal static bool IsUpdateNewer(string candidate, string installed)
        {
            return IsPlainVersion(candidate) && IsPlainVersion(installed) &&
                CompareVersionStrings(candidate, installed) > 0;
        }

        // Ein Zeitstempel aus der Zukunft (Uhr zurueckgestellt, Datei veraendert)
        // darf die Suche nicht auf Tage einfrieren.
        public static bool ShouldCheckForUpdate(DateTime nowUtc, UpdateState state)
        {
            if (state == null || state.LastCheckUtc == DateTime.MinValue || state.LastCheckUtc > nowUtc.AddMinutes(5))
            {
                return true;
            }

            return nowUtc - state.LastCheckUtc >= TimeSpan.FromHours(UpdateCheckIntervalHours);
        }

        public static bool ShouldNotifyForUpdate(string version, DateTime nowUtc, UpdateState state)
        {
            if (state == null || !IsPlainVersion(version))
            {
                return false;
            }

            if (!string.Equals(state.LastNotifiedVersion, version, StringComparison.Ordinal) ||
                state.LastNotifiedUtc > nowUtc.AddMinutes(5))
            {
                return true;
            }

            return nowUtc - state.LastNotifiedUtc >= TimeSpan.FromDays(UpdateReminderDays);
        }

        public static void MarkUpdateNotified(UpdateState state, string version, DateTime nowUtc)
        {
            state.LastNotifiedVersion = version;
            state.LastNotifiedUtc = nowUtc;
        }

        // "Spaeter": die Sprechblase kommt in 24 Stunden wieder, nicht erst nach
        // der ueblichen Erinnerungsfrist von drei Tagen.
        public static void MarkUpdateLater(UpdateState state, string version, DateTime nowUtc)
        {
            state.LastNotifiedVersion = version;
            state.LastNotifiedUtc = nowUtc.AddDays(-UpdateReminderDays).AddHours(UpdateLaterHours);
        }

        // ---- Zustandsdatei ----------------------------------------------------------

        public static string FormatUpdateState(UpdateState state)
        {
            UpdateState value = state ?? new UpdateState();
            return "{\n" +
                "  \"lastCheckUtc\": \"" + FormatUpdateTime(value.LastCheckUtc) + "\",\n" +
                "  \"lastSeenVersion\": \"" + EscapeJson(value.LastSeenVersion) + "\",\n" +
                "  \"lastNotifiedVersion\": \"" + EscapeJson(value.LastNotifiedVersion) + "\",\n" +
                "  \"lastNotifiedUtc\": \"" + FormatUpdateTime(value.LastNotifiedUtc) + "\"\n" +
                "}\n";
        }

        private static string FormatUpdateTime(DateTime utc)
        {
            return utc == DateTime.MinValue ? string.Empty : utc.ToUniversalTime().ToString("o", CultureInfo.InvariantCulture);
        }

        // Eine beschaedigte oder fremde Datei ergibt einen leeren Zustand: die
        // naechste Pruefung holt alles nach.
        public static UpdateState ParseUpdateState(string json)
        {
            UpdateState state = new UpdateState();
            if (string.IsNullOrWhiteSpace(json))
            {
                return state;
            }

            DateTime parsed;
            if (TryReadUtc(ReadString(json, "lastCheckUtc"), out parsed))
            {
                state.LastCheckUtc = parsed;
            }

            if (TryReadUtc(ReadString(json, "lastNotifiedUtc"), out parsed))
            {
                state.LastNotifiedUtc = parsed;
            }

            string seen = ReadString(json, "lastSeenVersion");
            string notified = ReadString(json, "lastNotifiedVersion");
            state.LastSeenVersion = IsPlainVersion(seen) ? seen : string.Empty;
            state.LastNotifiedVersion = IsPlainVersion(notified) ? notified : string.Empty;
            return state;
        }
    }
}
