using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Purestate.Native
{
    internal static partial class Support
    {
        // Uses the canonical NormalizeDomain/IsValidDomain parser (NativeSupportLogic.cs)
        // instead of an ad hoc regex, so a build-source line like "https://example.com."
        // is judged the same way here as everywhere else domain lists are read.
        internal static int CountDomainsInPackageFile(string path)
        {
            try
            {
                if (!File.Exists(path))
                {
                    return 0;
                }

                int count = 0;
                foreach (string raw in File.ReadAllLines(path))
                {
                    string trimmed = (raw ?? string.Empty).Trim();
                    if (trimmed.Length == 0 || trimmed.StartsWith("#"))
                    {
                        continue;
                    }

                    if (IsValidDomain(NormalizeDomain(trimmed)))
                    {
                        count++;
                    }
                }

                return count;
            }
            catch
            {
                return 0;
            }
        }

        // RGL-004: Die Musterdatei war in Get-MixedSiteUrlPatterns die erste
        // Quelle und durfte dort unbegrenzt und ungeprueft schoepfen, waehrend
        // dieser Spiegel dieselbe Datei schaerfer las. Zwei Leser mit
        // verschiedenen Regeln, und die massgebliche Seite war die laxere: 1000
        // Muellzeilen am Dateianfang haetten die Kernabdeckung verdraengt, und
        // der Zaehler hier haette einen plausiblen Wert gemeldet. Beide Seiten
        // pruefen jetzt gleich, samt Laengengrenze und Kontingent.
        // Die ausgelieferte Datei hat 144 Zeilen und besteht die Pruefung
        // vollstaendig; das Kontingent deckelt nur den Fall, dass sie entgleist.
        internal const int MaxAdultUrlKeywords = 300;
        internal const int MixedSiteFileQuota = 400;
        internal const int MixedSitePatternMaxLength = 200;

        internal static bool IsMixedSitePatternLine(string line)
        {
            string value = (line ?? string.Empty).Trim();
            if (value.Length == 0 || value.StartsWith("#"))
            {
                return false;
            }

            if (value.Length > MixedSitePatternMaxLength)
            {
                return false;
            }

            return value.IndexOf("://", StringComparison.OrdinalIgnoreCase) >= 0 ||
                value.StartsWith("<", StringComparison.OrdinalIgnoreCase);
        }

        internal static int CountUrlPatternsInPackageFile(string path)
        {
            try
            {
                if (!File.Exists(path))
                {
                    return 0;
                }

                System.Collections.Generic.HashSet<string> patterns = new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
                int fromFile = 0;
                foreach (string raw in File.ReadAllLines(path))
                {
                    string line = (raw ?? string.Empty).Trim();
                    if (!IsMixedSitePatternLine(line))
                    {
                        continue;
                    }

                    if (fromFile >= MixedSiteFileQuota)
                    {
                        break;
                    }

                    fromFile++;
                    patterns.Add(line);
                }

                return patterns.Count;
            }
            catch
            {
                return 0;
            }
        }

        internal static int CountAdultUrlKeywordsInPackageFile(string path)
        {
            return ReadAdultUrlKeywordsFromPath(path).Length;
        }

        internal static int CountNsfwSubredditsInPackageFile(string path)
        {
            return ReadNsfwSubredditsFromPath(path).Length;
        }

        private static int CountKeywordLinesInPackageFile(string path)
        {
            try
            {
                if (!File.Exists(path))
                {
                    return 0;
                }

                System.Collections.Generic.SortedSet<string> keywords = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (string raw in File.ReadAllLines(path))
                {
                    string line = (raw ?? string.Empty).Trim().ToLowerInvariant();
                    if (line.Length == 0 || line.StartsWith("#"))
                    {
                        continue;
                    }

                    if (Regex.IsMatch(line, @"^[a-z0-9-]{3,32}$", RegexOptions.IgnoreCase))
                    {
                        keywords.Add(line);
                    }
                }

                return keywords.Count;
            }
            catch
            {
                return 0;
            }
        }

        // RGL-007: Dieselbe Erzeugung, aber nur gezaehlt, was Chromium
        // uebersetzen kann. Firefox nimmt die Rohzahl, Chrome und Edge diese.
        internal static int CountChromiumTranslatableUrlPatterns(string patternPath, string keywordPath, string nsfwSubredditsPath)
        {
            System.Collections.Generic.SortedSet<string> filters =
                new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string pattern in BuildEffectiveUrlPatterns(patternPath, keywordPath, nsfwSubredditsPath))
            {
                if (IsChromiumTranslatableUrlPattern(pattern))
                {
                    filters.Add(pattern);
                }
            }
            return filters.Count;
        }

        private static System.Collections.Generic.SortedSet<string> BuildEffectiveUrlPatterns(string patternPath, string keywordPath, string nsfwSubredditsPath)
        {
            try
            {
                System.Collections.Generic.SortedSet<string> patterns = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (string pattern in ReadUrlPatternsFromPath(patternPath))
                {
                    patterns.Add(pattern);
                    if (patterns.Count >= 1000)
                    {
                        return patterns;
                    }
                }

                foreach (string keyword in CoreAdultUrlKeywords())
                {
                    foreach (string template in CoreAdultCoverageTemplates())
                    {
                        patterns.Add(template.Replace("{0}", keyword));
                        if (patterns.Count >= 1000)
                        {
                            return patterns;
                        }
                    }
                }

                foreach (string subreddit in ReadNsfwSubredditsFromPath(nsfwSubredditsPath))
                {
                    foreach (string template in RedditSubredditPatternTemplates())
                    {
                        patterns.Add(template.Replace("{0}", subreddit));
                        if (patterns.Count >= 1000)
                        {
                            return patterns;
                        }
                    }
                }

                foreach (string keyword in ReadAdultUrlKeywordsFromPath(keywordPath))
                {
                    foreach (string template in PriorityMixedSitePatternTemplates())
                    {
                        patterns.Add(template.Replace("{0}", keyword));
                        if (patterns.Count >= 1000)
                        {
                            return patterns;
                        }
                    }
                }

                foreach (string keyword in ReadAdultUrlKeywordsFromPath(keywordPath))
                {
                    foreach (string template in SecondaryMixedSitePatternTemplates())
                    {
                        patterns.Add(template.Replace("{0}", keyword));
                        if (patterns.Count >= 1000)
                        {
                            return patterns;
                        }
                    }
                }

                return patterns;
            }
            catch
            {
                return new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            }
        }

        // RGL-007: Der Zaehler ruft dieselbe Erzeugung wie der
        // Chromium-Zaehler - eine Quelle, zwei Sichten.
        private static int CountEffectiveUrlPatterns(string patternPath, string keywordPath, string nsfwSubredditsPath)
        {
            return BuildEffectiveUrlPatterns(patternPath, keywordPath, nsfwSubredditsPath).Count;
        }

        private static string[] ReadUrlPatternsFromPath(string path)
        {
            System.Collections.Generic.SortedSet<string> patterns = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                if (!File.Exists(path))
                {
                    return new string[0];
                }

                int fromFile = 0;
                foreach (string raw in File.ReadAllLines(path))
                {
                    string line = (raw ?? string.Empty).Trim();
                    if (!IsMixedSitePatternLine(line))
                    {
                        continue;
                    }

                    if (fromFile >= MixedSiteFileQuota)
                    {
                        break;
                    }

                    fromFile++;
                    patterns.Add(line);
                }
            }
            catch
            {
                return new string[0];
            }

            string[] result = new string[patterns.Count];
            patterns.CopyTo(result);
            return result;
        }

        private static string[] ReadAdultUrlKeywordsFromPath(string path)
        {
            System.Collections.Generic.SortedSet<string> keywords = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                if (!File.Exists(path))
                {
                    return new string[0];
                }

                foreach (string raw in File.ReadAllLines(path))
                {
                    string line = (raw ?? string.Empty).Trim().ToLowerInvariant();
                    if (line.Length == 0 || line.StartsWith("#"))
                    {
                        continue;
                    }

                    if (Regex.IsMatch(line, @"^[a-z0-9-]{3,32}$", RegexOptions.IgnoreCase))
                    {
                        keywords.Add(line);
                    }

                    // RGL-006: Spiegel des Deckels aus
                    // scripts\Common.ps1 ($script:MaxAdultUrlKeywords).
                    if (keywords.Count >= MaxAdultUrlKeywords)
                    {
                        break;
                    }
                }
            }
            catch
            {
                return new string[0];
            }

            string[] result = new string[keywords.Count];
            keywords.CopyTo(result);
            return result;
        }

        private static string[] ReadNsfwSubredditsFromPath(string path)
        {
            System.Collections.Generic.SortedSet<string> names = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                if (!File.Exists(path))
                {
                    return new string[0];
                }

                foreach (string raw in File.ReadAllLines(path))
                {
                    string line = (raw ?? string.Empty).Trim().ToLowerInvariant();
                    if (line.Length == 0 || line.StartsWith("#"))
                    {
                        continue;
                    }

                    line = Regex.Replace(line, @"^/r/", string.Empty, RegexOptions.IgnoreCase);
                    line = Regex.Replace(line, @"^r/", string.Empty, RegexOptions.IgnoreCase);
                    if (Regex.IsMatch(line, @"^[a-z0-9_]{2,32}$", RegexOptions.IgnoreCase))
                    {
                        names.Add(line);
                    }

                    if (names.Count >= 180)
                    {
                        break;
                    }
                }
            }
            catch
            {
                return new string[0];
            }

            string[] result = new string[names.Count];
            names.CopyTo(result);
            return result;
        }

        // Mirrors Add-RedditSubredditPatterns in scripts\Common.ps1 (0.61.42
        // dedupe): bare host for Chromium implicit subdomain matching plus the
        // *.reddit.com match pattern for the Firefox WebsiteFilter.
        private static string[] RedditSubredditPatternTemplates()
        {
            return new string[]
            {
                "*://reddit.com/r/{0}*",
                "*://*.reddit.com/r/{0}*"
            };
        }

        private static string[] CoreAdultUrlKeywords()
        {
            return new string[]
            {
                "nsfw",
                "porn",
                "porno",
                "hentai",
                "nude",
                "nudes",
                "naked",
                "onlyfans",
                "fansly",
                "redgifs",
                "rule34",
                "r34",
                "xxx",
                "xvideos",
                "xnxx",
                "blowjob",
                "boobs",
                "tits",
                "pussy",
                "cock",
                "dick",
                "cum",
                "milf",
                "gonewild"
            };
        }

        // Mirrors Get-CoreAdultCoverageTemplates in scripts\Common.ps1.
        private static string[] CoreAdultCoverageTemplates()
        {
            return new string[]
            {
                "*://www.google.*/search*{0}*",
                "*://www.bing.com/search*{0}*",
                "*://www.bing.com/images/search*{0}*",
                "*://www.bing.com/videos/search*{0}*",
                "*://duckduckgo.com/*q=*{0}*",
                "*://search.brave.com/search*{0}*",
                "*://search.yahoo.com/search*{0}*",
                "*://*.search.yahoo.com/search*{0}*",
                "*://yandex.com/search*{0}*",
                "*://yandex.com/images/search*{0}*",
                "*://www.ecosia.org/search*{0}*",
                "*://www.startpage.com/sp/search*{0}*",
                "*://www.qwant.com/*q=*{0}*",
                "*://metager.org/meta/*{0}*",
                "*://www.youtube.com/results*{0}*",
                "*://www.youtube.com/hashtag/*{0}*",
                "*://www.tiktok.com/search*{0}*",
                "*://www.tiktok.com/tag/*{0}*",
                "*://www.instagram.com/explore/tags/*{0}*",
                "*://*.pinterest.*/search/pins/*{0}*",
                "*://giphy.com/search/*{0}*"
            };
        }

        // Mirrors $priorityTemplates in Get-MixedSiteUrlPatterns (Common.ps1).
        private static string[] PriorityMixedSitePatternTemplates()
        {
            return new string[]
            {
                "*://reddit.com/r/*{0}*",
                "*://*.reddit.com/r/*{0}*",
                "*://reddit.com/search*{0}*",
                "*://*.reddit.com/search*{0}*",
                "*://twitter.com/search*{0}*",
                "*://*.twitter.com/search*{0}*",
                "*://twitter.com/hashtag/*{0}*",
                "*://*.twitter.com/hashtag/*{0}*",
                "*://x.com/search*{0}*",
                "*://*.x.com/search*{0}*",
                "*://x.com/hashtag/*{0}*",
                "*://*.x.com/hashtag/*{0}*",
                "*://bsky.app/search*{0}*",
                "*://bsky.app/hashtag/*{0}*"
            };
        }

        // Mirrors $secondaryTemplates in Get-MixedSiteUrlPatterns (Common.ps1).
        private static string[] SecondaryMixedSitePatternTemplates()
        {
            return new string[]
            {
                "*://*.tumblr.com/tagged/*{0}*",
                "*://*.tumblr.com/search/*{0}*",
                "*://www.google.*/search*{0}*",
                "*://www.bing.com/search*{0}*",
                "*://www.bing.com/images/search*{0}*",
                "*://www.bing.com/videos/search*{0}*",
                "*://duckduckgo.com/*q=*{0}*",
                "*://search.brave.com/search*{0}*",
                "*://search.yahoo.com/search*{0}*",
                "*://*.search.yahoo.com/search*{0}*",
                "*://yandex.com/search*{0}*",
                "*://yandex.com/images/search*{0}*",
                "*://www.ecosia.org/search*{0}*",
                "*://www.startpage.com/sp/search*{0}*",
                "*://www.qwant.com/*q=*{0}*",
                "*://metager.org/meta/*{0}*",
                "*://www.youtube.com/results*{0}*",
                "*://www.youtube.com/hashtag/*{0}*",
                "*://www.tiktok.com/search*{0}*",
                "*://www.tiktok.com/tag/*{0}*",
                "*://www.instagram.com/explore/tags/*{0}*",
                "*://www.instagram.com/explore/search*{0}*",
                "*://*.pinterest.*/search/pins/*{0}*",
                "*://imgur.com/search*{0}*",
                "*://imgur.com/t/*{0}*",
                "*://giphy.com/search/*{0}*"
            };
        }

        private static string[] FamilyDnsServersForProfile(string profile)
        {
            string normalized = NormalizeDnsProfile(profile);
            if (normalized == "CleanBrowsingFamily")
            {
                return new string[]
                {
                    "185.228.168.168",
                    "185.228.169.168",
                    "2a0d:2a00:1::",
                    "2a0d:2a00:2::"
                };
            }

            if (normalized == "OpenDnsFamilyShield")
            {
                return new string[]
                {
                    "208.67.222.123",
                    "208.67.220.123",
                    "2620:119:35::123",
                    "2620:119:53::123"
                };
            }

            return new string[]
            {
                "1.1.1.3",
                "1.0.0.3",
                "2606:4700:4700::1113",
                "2606:4700:4700::1003"
            };
        }

        private static string ReadInstalledVersion()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Purestate"))
                {
                    if (key == null)
                    {
                        return string.Empty;
                    }

                    object value = key.GetValue("DisplayVersion");
                    return value == null ? string.Empty : value.ToString();
                }
            }
            catch
            {
                return string.Empty;
            }
        }

        // Tiefe gedeckelt: ein Symlink-Ring waere sonst nur ueber das
        // Pfadlaengenlimit zu beenden.
        // RGL-007: Die Statuszeile "URL-Regeln fuer gemischte Webseiten" nannte
        // die ROHZAHL der erzeugten Muster. Alle Stichwort- und Suchrouten
        // tragen aber ein "*" IM PFAD und sind damit fuer Chromium nicht
        // uebersetzbar - sie werden dort still verworfen. Gemessen: von 1000
        // erzeugten Mustern bleiben 125 eindeutige Filter. Fuer Firefox stimmt
        // die Rohzahl, fuer Chrome und Edge nicht, und die Anzeige unterschied
        // die beiden nicht: 1000 gemeldet, 125 wirksam.
        //
        // Kein Verlust durch den 1000er-Deckel - die uebersetzbaren Muster
        // passen vollstaendig hinein. Der Befund ist die Fehlinformation.
        //
        // Diese Funktion spiegelt ConvertTo-ChromiumUrlFilter aus
        // scripts\Common.ps1. Ein Oracle-Test haelt beide Seiten gegeneinander -
        // sonst waere das die vierte Implementierung derselben Frage mit der
        // vierten Antwort.
        internal static bool IsChromiumTranslatableUrlPattern(string pattern)
        {
            string value = (pattern ?? string.Empty).Trim();
            if (value.Length == 0)
            {
                return false;
            }

            string rest = value;
            int separator = value.IndexOf("://", StringComparison.Ordinal);
            if (separator >= 0)
            {
                string scheme = value.Substring(0, separator);
                rest = value.Substring(separator + 3);
                if (scheme != "*" && scheme.IndexOf('*') >= 0)
                {
                    return false;
                }
            }

            string hostPart = rest;
            string pathPart = string.Empty;
            int slash = rest.IndexOf('/');
            if (slash >= 0)
            {
                hostPart = rest.Substring(0, slash);
                pathPart = rest.Substring(slash);
            }

            if (hostPart.StartsWith("*.", StringComparison.Ordinal))
            {
                hostPart = hostPart.Substring(2);
            }
            if (hostPart.Length == 0 || hostPart.IndexOf('*') >= 0)
            {
                return false;
            }

            pathPart = pathPart.TrimEnd('*').TrimEnd('/');
            return pathPart.IndexOf('*') < 0;
        }

        private static long SumFilesWithoutReparsePoints(string directory, int depth)
        {
            if (depth > 16 || !Directory.Exists(directory))
            {
                return 0;
            }

            try
            {
                if ((File.GetAttributes(directory) & FileAttributes.ReparsePoint) != 0)
                {
                    return 0;
                }
            }
            catch
            {
                return 0;
            }

            long total = 0;
            try
            {
                foreach (string file in Directory.GetFiles(directory, "*", SearchOption.TopDirectoryOnly))
                {
                    try
                    {
                        total += new FileInfo(file).Length;
                    }
                    catch
                    {
                    }
                }

                foreach (string child in Directory.GetDirectories(directory, "*", SearchOption.TopDirectoryOnly))
                {
                    total += SumFilesWithoutReparsePoints(child, depth + 1);
                }
            }
            catch
            {
            }

            return total;
        }

        private static int EstimateInstallSizeKb()
        {
            try
            {
                // PKG-004: SearchOption.AllDirectories folgt
                // Verzeichnis-Reparse-Points. Der Schutz davor deckte nur das
                // Datenverzeichnis ab, nicht den Installationsordner - ein
                // Verzeichnis-Symlink darunter liess diese Aufzaehlung in einen
                // fremden Baum laufen, bei einer Schleife bis zum
                // Pfadlaengenlimit. Der Wert landet als EstimatedSize in der
                // Deinstallationsregistrierung; der Schaden ist Laufzeit, nicht
                // Korrektheit - aber er trifft den Installationslauf.
                //
                // Deshalb eigene Rekursion mit TopDirectoryOnly, die
                // Reparse-Points ueberspringt, statt sie zu verbieten: ein
                // Symlink im Installationsbaum ist ungewoehnlich, aber kein
                // Grund, die Groessenschaetzung scheitern zu lassen.
                return Math.Max(1, (int)(SumFilesWithoutReparsePoints(InstallDir, 0) / 1024));
            }
            catch
            {
                return 1;
            }
        }

        private static string PowerShellExecutablePath()
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
        }

        private static string SystemToolPath(string toolName)
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), toolName);
        }

        private static bool SafeFileExists(string path)
        {
            try
            {
                return File.Exists(path);
            }
            catch
            {
                return false;
            }
        }

        private static bool SafeDirectoryExists(string path)
        {
            try
            {
                return Directory.Exists(path);
            }
            catch
            {
                return false;
            }
        }

        private static bool FileExistsAndNotEmpty(string path)
        {
            try
            {
                return File.Exists(path) && new FileInfo(path).Length > 0;
            }
            catch
            {
                return false;
            }
        }

        private static void AppendPreflightCheck(StringBuilder report, System.Collections.Generic.List<string> problems, string label, bool ok, string problem)
        {
            report.AppendLine("- " + label + ": " + (ok ? "OK" : "Problem"));
            if (!ok && !string.IsNullOrEmpty(problem))
            {
                problems.Add(problem);
            }
        }

        private static bool RunPackageScriptSelfTest(string packageDir, string relativeScriptPath)
        {
            try
            {
                string script = Path.Combine(packageDir, relativeScriptPath);
                if (!File.Exists(script))
                {
                    return false;
                }

                RunPowerShellFile(script, "-SelfTest", SelfTestProcessTimeoutMilliseconds);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private static bool PowerShellCommandAvailable(string commandName)
        {
            try
            {
                if (!File.Exists(PowerShellExecutablePath()))
                {
                    return false;
                }

                string command = "if (Get-Command " + commandName + " -ErrorAction SilentlyContinue) { 'true' } else { 'false' }";
                return RunPowerShellCommand(command).IndexOf("true", StringComparison.OrdinalIgnoreCase) >= 0;
            }
            catch
            {
                return false;
            }
        }
    }
}
