using System;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // Shopping protection, grouped into Kaufpause / Zeiten / Käufe. Number
    // fields only appear while their option is enabled. Config fields and
    // save calls are identical to the old dialog.
    internal sealed partial class AdminForm
    {
        private void ShowShoppingProtectionSettings()
        {
            AppConfig config = Support.LoadConfig();
            using (DialogShell shell = new DialogShell(theme, "Shopping-Schutz",
                "Purestate hilft mit Wartezeiten, ruhigeren Shop-Seiten und Zeitlimits gegen Impulskäufe. Bank- und Zahlungsdaten werden nicht gespeichert.",
                "Stellt Kaufbremsen, Sperrzeiten und Limits für Shop-Seiten ein.", true))
            {
                shell.Kicker = "Schutzbereich";
                CheckBox enabled = Ui.Check(theme, "Shopping-Schutz einschalten", config.ShoppingProtectionEnabled,
                    "Schaltet alle Shopping-Hilfen an oder aus.");
                shell.Add(enabled);

                shell.AddSection("Kaufpause");
                CheckBox checkoutDelay = Ui.Check(theme, "Kurze Wartezeit vor jedem Kauf", config.ShoppingCheckoutDelayEnabled,
                    "Vor der Kasse erscheint eine kurze Wartezeit mit einer Frage zum Nachdenken. Kaufen bleibt danach möglich.");
                shell.Add(checkoutDelay);
                CheckBox damping = Ui.Check(theme, "Kaufreize ausblenden (Countdowns, Deal-Banner)", config.ShoppingStimulusDampingEnabled,
                    "Blendet Countdown-Angebote, Knappheits-Hinweise und Deal-Banner auf Shop-Seiten aus.");
                shell.Add(damping);
                CheckBox dealSearch = Ui.Check(theme, "Suchen nach Deals und Gutscheinen blockieren", config.ShoppingDealSearchBlockEnabled,
                    "Blockiert Suchanfragen nach Gutscheinen, Rabattcodes und Aktionstagen.");
                shell.Add(dealSearch);

                shell.AddSection("Zeiten");
                CheckBox dailyLimit = Ui.Check(theme, "Tägliches Zeitlimit für Shop-Seiten", config.ShoppingDailyLimitEnabled,
                    "Begrenzt, wie lange Shop-Seiten pro Tag genutzt werden können.");
                shell.Add(dailyLimit);
                ComboBox dailyLimitMinutes = Ui.MinutesCombo(5, 240,
                    Support.NormalizeDailyLimitMinutes(config.ShoppingDailyLimitMinutes, 30),
                    "Zeitlimit in Minuten", "Wert zwischen 5 und 240 Minuten pro Tag.");
                FlowLayoutPanel dailyRow = shell.Row(dailyLimitMinutes, Ui.WrapLabel(theme, "Minuten pro Tag", 200, true));
                dailyRow.Padding = new Padding(24, 0, 0, 0);
                shell.Add(dailyRow);
                Ui.BindVisibility(dailyLimit, dailyRow);

                CheckBox curfew = Ui.Check(theme, "Feste Shopping-Pause (Sperrzeit)", config.ShoppingCurfewEnabled,
                    "In diesem Zeitfenster sind Shop-Seiten komplett gesperrt.");
                shell.Add(curfew);
                ComboBox curfewStart = Ui.TimeCombo(config.ShoppingCurfewStart, "22:00", "Beginn der Shopping-Pause");
                ComboBox curfewEnd = Ui.TimeCombo(config.ShoppingCurfewEnd, "06:00", "Ende der Shopping-Pause");
                FlowLayoutPanel curfewRow = shell.Row(Ui.WrapLabel(theme, "Von", 40, true), curfewStart, Ui.WrapLabel(theme, "bis", 40, true), curfewEnd, Ui.WrapLabel(theme, "Uhr (auch über Mitternacht möglich)", 260, true));
                curfewRow.Padding = new Padding(24, 0, 0, 0);
                shell.Add(curfewRow);
                Label curfewError = shell.AddErrorLine();
                Ui.BindVisibility(curfew, curfewRow);

                shell.AddSection("Käufe");
                // WS-03 / Vertrag V-2: Betraege werden nicht eingetragen, sondern
                // auf der Kassenseite abgelesen - schon bei aktivem Bestelllimit.
                shell.AddHint("Zählt Kaufversuche über den geschützten Kassen-Bereich auf diesem PC. Sobald Bestelllimit oder Monatsbudget aktiv ist, liest der Browser-Schutz den Betrag auf der Kassenseite ab und speichert ihn lokal. Echte Bestellungen, Zahlungs- oder Kontodaten sieht Purestate nicht.");
                CheckBox monthlyOrderLimit = Ui.Check(theme, "Höchstzahl Bestellungen pro Monat", config.ShoppingMonthlyOrderLimitEnabled,
                    "Begrenzt die Zahl der Kaufversuche über den geschützten Kassen-Bereich pro Monat.");
                shell.Add(monthlyOrderLimit);
                ComboBox monthlyOrderCount = Ui.StepsCombo(new[] { 1, 2, 3, 5, 8, 10, 15, 20, 30, 50, 99 }, 1, 99,
                    Support.NormalizeMonthlyOrderLimit(config.ShoppingMonthlyOrderLimit),
                    "Bestellungen pro Monat", "Wert zwischen 1 und 99 Bestellungen.");
                FlowLayoutPanel orderRow = shell.Row(monthlyOrderCount, Ui.WrapLabel(theme, "Bestellungen pro Monat", 240, true));
                orderRow.Padding = new Padding(24, 0, 0, 0);
                shell.Add(orderRow);
                Ui.BindVisibility(monthlyOrderLimit, orderRow);

                CheckBox monthlyBudget = Ui.Check(theme, "Monatsbudget", config.ShoppingMonthlyBudgetEnabled,
                    "Begrenzt die Summe der auf Kassenseiten abgelesenen Beträge pro Monat.");
                shell.Add(monthlyBudget);
                ComboBox monthlyBudgetEuro = Ui.StepsCombo(
                    new[] { 25, 50, 75, 100, 150, 200, 250, 300, 400, 500, 750, 1000, 1500, 2000, 3000, 5000, 10000 },
                    1, 99999,
                    Support.NormalizeMonthlyBudgetEuro(config.ShoppingMonthlyBudgetEuro),
                    "Monatsbudget in Euro", "Ganzzahliger Wert zwischen 1 und 99999 Euro.");
                FlowLayoutPanel budgetRow = shell.Row(monthlyBudgetEuro, Ui.WrapLabel(theme, "Euro pro Monat (auf Kassenseiten abgelesen)", 320, true));
                budgetRow.Padding = new Padding(24, 0, 0, 0);
                shell.Add(budgetRow);
                Ui.BindVisibility(monthlyBudget, budgetRow);

                shell.AddSection("Zusätzliche Webseite sperren");
                Button blockShop = Ui.SecondaryButton(theme, "Webseite zur Sperrliste hinzufügen", "Fügt eine weitere Shop-Webseite zur Sperrliste hinzu.");
                blockShop.Click += delegate { ShowAddCustomShoppingDomain(shell); };
                shell.Add(blockShop);

                shell.SaveButton.Click += delegate
                {
                    if (curfew.Checked &&
                        (!Support.IsValidScheduleTimeText(curfewStart.Text) || !Support.IsValidScheduleTimeText(curfewEnd.Text)))
                    {
                        shell.ShowError(curfewError, "Bitte gib die Shopping-Pause im Format 22:00 ein.",
                            Support.IsValidScheduleTimeText(curfewStart.Text) ? curfewEnd : curfewStart);
                        return;
                    }
                    shell.ClearError(curfewError);

                    bool enabledValue = enabled.Checked;
                    bool checkoutDelayValue = checkoutDelay.Checked;
                    bool dampingValue = damping.Checked;
                    bool dealSearchValue = dealSearch.Checked;
                    bool curfewValue = curfew.Checked;
                    string curfewStartValue = curfewStart.Text;
                    string curfewEndValue = curfewEnd.Text;
                    bool dailyLimitValue = dailyLimit.Checked;
                    int dailyLimitMinutesValue = int.Parse(dailyLimitMinutes.Text);
                    bool monthlyOrderLimitValue = monthlyOrderLimit.Checked;
                    int monthlyOrderLimitCountValue = int.Parse(monthlyOrderCount.Text);
                    bool monthlyBudgetValue = monthlyBudget.Checked;
                    int monthlyBudgetEuroValue = int.Parse(monthlyBudgetEuro.Text);

                    if (!ConfirmPassword("Shopping-Schutz speichern", shell))
                    {
                        return;
                    }

                    RunAction("Shopping-Schutz speichern", shell, delegate
                    {
                        Support.SetShoppingSettingsGuarded(
                            enabledValue,
                            checkoutDelayValue,
                            dampingValue,
                            dealSearchValue,
                            curfewValue,
                            curfewStartValue,
                            curfewEndValue,
                            dailyLimitValue,
                            dailyLimitMinutesValue,
                            monthlyOrderLimitValue,
                            monthlyOrderLimitCountValue,
                            monthlyBudgetValue,
                            monthlyBudgetEuroValue,
                            Support.TrustedLocalNow(),
                            false);
                        Support.ReapplyProtection();
                    }, "Shopping-Schutz: Änderungen gespeichert.");
                };

                shell.FinishLayout();
                shell.Shown += delegate { enabled.Focus(); };
                shell.ShowDialog(this);
            }
        }
    }
}
