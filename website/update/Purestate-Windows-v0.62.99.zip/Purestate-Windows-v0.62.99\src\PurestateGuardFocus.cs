using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace Purestate
{
    internal sealed class FocusState
    {
        public DateTime StartUtc;
        public int Minutes, Cycle, Pause;
        public List<string> Sites = new List<string>();
        public List<string> Programs = new List<string>();
    }

    // Ausgang von GuardService.AdoptFocusFromPeers (Spec 2026-11-20, Abschnitt 5.3).
    internal enum FocusAdoptionResult
    {
        None,
        Adopted,
        Replaced,
        NoCompanion
    }

    internal sealed class FocusProcessIdentity
    {
        internal Process Process;
        internal string Program;
        internal int SessionId;
        internal long StartUtcTicks;
    }

    internal sealed partial class GuardService
    {
        internal const string FocusPipeName = "PurestateFocus";
        internal const string FocusMinCompanionVersion = "0.62.98";
        private const int FocusMaxCommandBytes = 1024;
        internal const int FocusMinMinutes = 15, FocusMaxMinutes = 480, FocusStepMinutes = 15;
        internal const int FocusMaxSites = 100, FocusMaxPrograms = 50;
        internal const int FocusBrowserGraceSeconds = 90;
        private const int FocusMaxStateBytes = 65536;
        private static readonly object focusSync = new object();
        private static readonly object focusRunSync = new object();
        private static readonly object focusClockSync = new object();
        private static DateTime focusClockStartUtc;
        private static long focusClockStartTick;

        // Credit offline time at startup; later wall-clock changes cannot move Focus edges.
        internal static DateTime ReadFocusClockUtc()
        {
            lock (focusClockSync)
            {
                if (focusClockStartUtc == DateTime.MinValue)
                {
                    focusClockStartUtc = ReadClockAnchorUtc();
                    DateTime wallUtc = DateTime.UtcNow;
                    if (wallUtc > focusClockStartUtc) focusClockStartUtc = wallUtc;
                    focusClockStartTick = Stopwatch.GetTimestamp();
                }
                double seconds = Math.Max(0, (Stopwatch.GetTimestamp() - focusClockStartTick) / (double)Stopwatch.Frequency);
                return focusClockStartUtc.AddSeconds(Math.Min(seconds, (DateTime.MaxValue - focusClockStartUtc).TotalSeconds));
            }
        }

        private sealed class FocusCoverageReceipt
        {
            internal string Text;
            internal long Tick;
            internal double RemainingSeconds;
        }
        private static readonly object focusCoverageSync = new object();
        private static readonly Dictionary<string, FocusCoverageReceipt> focusCoverage =
            new Dictionary<string, FocusCoverageReceipt>(StringComparer.OrdinalIgnoreCase);

        // Only a validated exact receipt survives clock discontinuities, for its original remaining TTL.
        private static bool ObserveFocusHeartbeat(string path, string text, DateTime systemNowUtc)
        {
            lock (focusCoverageSync)
            {
                FocusCoverageReceipt receipt;
                long tick = Stopwatch.GetTimestamp();
                if (focusCoverage.TryGetValue(path, out receipt) && receipt.Text == text)
                    return (tick - receipt.Tick) / (double)Stopwatch.Frequency <= receipt.RemainingSeconds;
                focusCoverage.Remove(path);
                if (!IsFocusCoveredHeartbeat(text, systemNowUtc)) return false;
                DateTime stamp = DateTime.ParseExact(text.Split('|')[1], "o", CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind);
                focusCoverage[path] = new FocusCoverageReceipt { Text = text, Tick = tick,
                    RemainingSeconds = 24 * 3600 - (systemNowUtc - stamp).TotalSeconds };
                return true;
            }
        }

        private static void ForgetFocusHeartbeat(string path)
        {
            lock (focusCoverageSync) { focusCoverage.Remove(path); }
        }
        internal static readonly string[] FocusMusicPrograms = { "spotify.exe" };
        internal static readonly HashSet<string> FocusBrowserPrograms = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "chrome.exe", "msedge.exe", "firefox.exe"
        };
        private static string focusNotificationPhase = string.Empty;
        private static readonly HashSet<string> focusNotifiedPrograms = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private static FocusState focusState;
        private static bool focusStatePendingWrite;
        private static bool focusCorruptionLogged;
        private static bool focusCorruptionAuditPending;
        private static readonly HashSet<string> FocusProtectedPrograms = new HashSet<string>(StringComparer.Ordinal)
        {
            "explorer.exe", "winlogon.exe", "csrss.exe", "lsass.exe", "services.exe", "svchost.exe",
            "dwm.exe", "taskmgr.exe", "purestate.exe", "purestateguard.exe", "purestatenativehost.exe", "installieren.exe"
        };

        // Nur fuer Pruefungen: leert den Speicher des Lernmodus wie ein Neustart des Dienstes
        // (Vorbild ResetDeviceSyncStateForTests). Die Zustandsdatei bleibt, wie sie ist.
        internal static void ResetFocusStateForTests()
        {
            lock (focusSync)
            {
                focusState = null;
                focusStatePendingWrite = false;
                focusCorruptionLogged = false;
                focusCorruptionAuditPending = false;
                focusNotificationPhase = string.Empty;
                focusNotifiedPrograms.Clear();
                focusAdoptionNoticed.Clear();
            }
        }

        private static string FocusDataDirectory()
        {
            string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Purestate");
            EnsureDataDirectoryIsNotReparsePoint(dataDir);
            return dataDir;
        }

        private const int FocusVisibilityBatchSize = 30;
        private const int FocusVisibilityTimeoutMilliseconds = 5000;
        private delegate bool FocusEnumWindowProc(IntPtr window, IntPtr parameter);

        [DllImport("user32.dll", EntryPoint = "EnumWindows", SetLastError = true)]
        private static extern bool FocusEnumWindows(FocusEnumWindowProc callback, IntPtr parameter);
        [DllImport("user32.dll", EntryPoint = "IsWindowVisible")]
        private static extern bool FocusIsWindowVisible(IntPtr window);
        [DllImport("user32.dll", EntryPoint = "GetWindowThreadProcessId")]
        private static extern uint FocusWindowProcessId(IntPtr window, out uint processId);
        [DllImport("user32.dll", EntryPoint = "PostMessageW", SetLastError = true)]
        private static extern bool FocusPostMessage(IntPtr window, uint message, IntPtr command, IntPtr data);
        [DllImport("wtsapi32.dll", SetLastError = true)]
        private static extern bool WTSQueryUserToken(uint sessionId, out IntPtr token);
        [DllImport("advapi32.dll", EntryPoint = "CreateProcessAsUserW", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern bool FocusCreateProcessAsUser(IntPtr token, string application, StringBuilder command,
            IntPtr processAttributes, IntPtr threadAttributes, bool inheritHandles, uint flags, IntPtr environment,
            string directory, ref FocusStartupInfo startup, out FocusProcessInfo process);
        [DllImport("kernel32.dll", EntryPoint = "WaitForSingleObject")]
        private static extern uint FocusWaitForProcess(IntPtr process, uint milliseconds);
        [DllImport("kernel32.dll", EntryPoint = "GetExitCodeProcess")]
        private static extern bool FocusGetExitCode(IntPtr process, out uint code);
        [DllImport("kernel32.dll", EntryPoint = "TerminateProcess")]
        private static extern bool FocusTerminateProbe(IntPtr process, uint code);
        [DllImport("kernel32.dll", EntryPoint = "CloseHandle")]
        private static extern bool FocusCloseHandle(IntPtr handle);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct FocusStartupInfo
        {
            internal uint Size;
            internal string Reserved, Desktop, Title;
            internal uint X, Y, Width, Height, Columns, Rows, Fill, Flags;
            internal short ShowWindow, ReservedSize;
            internal IntPtr ReservedPointer, Input, Output, Error;
        }
        [StructLayout(LayoutKind.Sequential)]
        private struct FocusProcessInfo
        {
            internal IntPtr Process, Thread;
            internal uint ProcessId, ThreadId;
        }

        // Read-only helper: numeric identities in, visibility bits out; no config, files or closure.
        internal static int RunFocusVisibilityQuery(string request)
        {
            if (string.IsNullOrEmpty(request) || request.Length > 1024) return -1;
            string[] entries = request.Split(',');
            if (entries.Length > FocusVisibilityBatchSize) return -1;
            Process[] targets = new Process[entries.Length];
            Dictionary<uint, int> indexes = new Dictionary<uint, int>();
            uint mask = 0;
            try
            {
                int sessionId = Process.GetCurrentProcess().SessionId;
                for (int index = 0; index < entries.Length; index++)
                {
                    string[] identity = entries[index].Split(':');
                    int pid;
                    long ticks;
                    if (identity.Length != 2 || !int.TryParse(identity[0], NumberStyles.None, CultureInfo.InvariantCulture, out pid) || pid <= 0 ||
                        !long.TryParse(identity[1], NumberStyles.None, CultureInfo.InvariantCulture, out ticks) || ticks <= 0 || ticks > DateTime.MaxValue.Ticks ||
                        indexes.ContainsKey((uint)pid)) return -1;
                    indexes.Add((uint)pid, index);
                    try
                    {
                        Process target = Process.GetProcessById(pid);
                        targets[index] = target;
                        if (sessionId <= 0 || target.SessionId != sessionId || target.StartTime.ToUniversalTime().Ticks != ticks)
                        {
                            target.Dispose();
                            targets[index] = null;
                        }
                    }
                    catch
                    {
                        if (targets[index] != null) targets[index].Dispose();
                        targets[index] = null;
                    }
                }
                if (!FocusEnumWindows(delegate(IntPtr window, IntPtr parameter)
                {
                    uint pid;
                    int index;
                    FocusWindowProcessId(window, out pid);
                    if (indexes.TryGetValue(pid, out index) && targets[index] != null && FocusIsWindowVisible(window))
                        mask |= 1u << index;
                    return true;
                }, IntPtr.Zero)) return -1;
                for (int index = 0; index < targets.Length; index++)
                {
                    try { if (targets[index] == null || targets[index].HasExited) mask &= ~(1u << index); }
                    catch { mask &= ~(1u << index); }
                }
                return (int)mask;
            }
            catch { return -1; }
            finally { foreach (Process target in targets) { if (target != null) target.Dispose(); } }
        }

        private static uint RunFocusVisibilityProbe(int sessionId, string request, int timeoutMilliseconds)
        {
            return RunFocusUserSessionHelper(sessionId, "--focus-visible-windows", request, timeoutMilliseconds);
        }

        private static uint RunFocusUserSessionHelper(int sessionId, string mode, string request, int timeoutMilliseconds)
        {
            IntPtr token = IntPtr.Zero;
            FocusProcessInfo child = new FocusProcessInfo();
            try
            {
                string exe = typeof(GuardService).Assembly.Location;
                if (string.IsNullOrEmpty(exe) || !WTSQueryUserToken((uint)sessionId, out token)) return uint.MaxValue;
                FocusStartupInfo startup = new FocusStartupInfo();
                startup.Size = (uint)Marshal.SizeOf(typeof(FocusStartupInfo));
                startup.Desktop = @"winsta0\default";
                startup.Flags = 1;
                StringBuilder command = new StringBuilder("\"" + exe + "\" " + mode + " " + request);
                if (!FocusCreateProcessAsUser(token, exe, command, IntPtr.Zero, IntPtr.Zero, false,
                    0x08000000, IntPtr.Zero, Path.GetDirectoryName(exe), ref startup, out child)) return uint.MaxValue;
                if (FocusWaitForProcess(child.Process, (uint)timeoutMilliseconds) != 0)
                {
                    FocusTerminateProbe(child.Process, 1);
                    return uint.MaxValue;
                }
                uint code;
                return FocusGetExitCode(child.Process, out code) ? code : uint.MaxValue;
            }
            catch { return uint.MaxValue; }
            finally
            {
                if (child.Thread != IntPtr.Zero) FocusCloseHandle(child.Thread);
                if (child.Process != IntPtr.Zero) FocusCloseHandle(child.Process);
                if (token != IntPtr.Zero) FocusCloseHandle(token);
            }
        }

        internal static List<FocusProcessIdentity> FindFocusVisibleProcesses(List<Process> processes, Action<string> log)
        {
            List<FocusProcessIdentity> visible = new List<FocusProcessIdentity>();
            Dictionary<int, List<FocusProcessIdentity>> sessions = new Dictionary<int, List<FocusProcessIdentity>>();
            foreach (Process process in processes)
            {
                try
                {
                    FocusProcessIdentity identity = new FocusProcessIdentity
                    {
                        Process = process, Program = process.ProcessName, SessionId = process.SessionId,
                        StartUtcTicks = process.StartTime.ToUniversalTime().Ticks
                    };
                    if (identity.SessionId <= 0) continue;
                    List<FocusProcessIdentity> targets;
                    if (!sessions.TryGetValue(identity.SessionId, out targets)) sessions[identity.SessionId] = targets = new List<FocusProcessIdentity>();
                    targets.Add(identity);
                }
                catch { }
            }
            Stopwatch elapsed = Stopwatch.StartNew();
            foreach (KeyValuePair<int, List<FocusProcessIdentity>> session in sessions)
            {
                for (int offset = 0; offset < session.Value.Count; offset += FocusVisibilityBatchSize)
                {
                    int timeoutMilliseconds = FocusVisibilityTimeoutMilliseconds - (int)elapsed.ElapsedMilliseconds;
                    if (timeoutMilliseconds <= 0)
                    {
                        try { log("Lernmodus: Sichtbarkeitsabfrage hat ihr Zeitlimit erreicht; Schliessen bleibt aktiv."); } catch { }
                        return visible;
                    }
                    List<FocusProcessIdentity> batch = session.Value.GetRange(offset, Math.Min(FocusVisibilityBatchSize, session.Value.Count - offset));
                    StringBuilder payload = new StringBuilder();
                    foreach (FocusProcessIdentity identity in batch)
                    {
                        if (payload.Length > 0) payload.Append(',');
                        payload.Append(identity.Process.Id.ToString(CultureInfo.InvariantCulture)).Append(':').Append(identity.StartUtcTicks.ToString(CultureInfo.InvariantCulture));
                    }
                    int sessionId = session.Key;
                    string request = payload.ToString();
                    uint mask = sessionId == Process.GetCurrentProcess().SessionId
                        ? unchecked((uint)RunFocusVisibilityQuery(request))
                        : RunFocusVisibilityProbe(sessionId, request, timeoutMilliseconds);
                    uint allowed = (1u << batch.Count) - 1;
                    if ((mask & ~allowed) != 0)
                    {
                        try { log("Lernmodus: Sichtbare Fenster in Sitzung " + sessionId + " konnten nicht geprueft werden; Schliessen bleibt aktiv."); } catch { }
                        continue;
                    }
                    for (int index = 0; index < batch.Count; index++) { if ((mask & (1u << index)) != 0) visible.Add(batch[index]); }
                }
            }
            return visible;
        }

        private static FocusState LoadFocusLearnState(DateTime nowUtc)
        {
            if (IsBetaExpired()) return null;
            FocusState state = LoadFocusState(FocusDataDirectory(), nowUtc);
            int edge, end;
            return FocusPhaseAt(state.StartUtc, state.Minutes, state.Cycle, state.Pause, nowUtc, out edge, out end) == "learn" ? state : null;
        }

        internal static bool ShouldCloseFocusBrowser(string imageName, int coverage, double processAgeSeconds, IList<string> unsupportedKeywords)
        {
            if (coverage == -1 || string.IsNullOrEmpty(imageName)) return false;
            if (FocusBrowserPrograms.Contains(imageName)) return coverage == 0 && processAgeSeconds >= FocusBrowserGraceSeconds;
            string stem = Path.GetFileNameWithoutExtension(imageName);
            foreach (string keyword in unsupportedKeywords)
            {
                if (!string.IsNullOrEmpty(keyword) && Regex.IsMatch(stem, @"\b" + Regex.Escape(keyword) + @"\b", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)) return true;
            }
            return false;
        }

        private static List<string> ReadFocusBrowserKeywords()
        {
            List<string> keywords = new List<string>();
            foreach (string raw in File.ReadAllLines(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "unsupported-browser-keywords.txt"), Encoding.UTF8))
            {
                string line = raw.Trim();
                if (line.Length > 0 && !line.StartsWith("#", StringComparison.Ordinal)) keywords.Add(line);
            }
            return keywords;
        }

        // The parent owns policy; this user-session helper needs no private state or key access.
        internal static int RunFocusBrowserClose(string request)
        {
            return RunFocusWindowClose(request, true);
        }

        internal static int RunFocusProgramClose(string request)
        {
            return RunFocusWindowClose(request, false);
        }

        private static int RunFocusWindowClose(string request, bool browser)
        {
            if (string.IsNullOrEmpty(request) || request.Length > 64) return -1;
            string[] parts = request.Split(':');
            int pid;
            long ticks;
            if (parts.Length != 2 || !int.TryParse(parts[0], NumberStyles.None, CultureInfo.InvariantCulture, out pid) || pid <= 0 ||
                !long.TryParse(parts[1], NumberStyles.None, CultureInfo.InvariantCulture, out ticks) || ticks <= 0 || ticks > DateTime.MaxValue.Ticks) return -1;
            try
            {
                using (Process target = Process.GetProcessById(pid))
                {
                    int session = Process.GetCurrentProcess().SessionId;
                    if (session <= 0 || target.SessionId != session || target.StartTime.ToUniversalTime().Ticks != ticks || target.HasExited) return -1;
                    string name = target.ProcessName + ".exe";
                    if (browser)
                    {
                        List<string> keywords = FocusBrowserPrograms.Contains(name) ? new List<string>() : ReadFocusBrowserKeywords();
                        if (!ShouldCloseFocusBrowser(name, 0, FocusBrowserGraceSeconds, keywords)) return -1;
                    }
                    else if (FocusProtectedPrograms.Contains(name.ToLowerInvariant()) || FocusBrowserPrograms.Contains(name)) return -1;
                    bool firefox = name.Equals("firefox.exe", StringComparison.OrdinalIgnoreCase) ||
                        Regex.IsMatch(target.ProcessName, @"\b(firefoxportable|librewolf|waterfox|seamonkey|palemoon)\b", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
                    // Chromium application exit preserves all windows in the restorable session.
                    bool queried = FocusEnumWindows(delegate(IntPtr window, IntPtr parameter)
                    {
                        uint owner;
                        FocusWindowProcessId(window, out owner);
                        if (owner == (uint)pid && !target.HasExited)
                            FocusPostMessage(window, (!browser || firefox) ? 0x0010u : 0x0111u, (!browser || firefox) ? IntPtr.Zero : new IntPtr(34031), IntPtr.Zero);
                        return true;
                    }, IntPtr.Zero);
                    return queried ? 0 : -1;
                }
            }
            catch { return -1; }
        }

        private static bool IsFocusBrowserDue(Process process, IList<string> keywords)
        {
            string name = process.ProcessName + ".exe";
            string browser = name.Equals("chrome.exe", StringComparison.OrdinalIgnoreCase) ? "chrome" :
                name.Equals("msedge.exe", StringComparison.OrdinalIgnoreCase) ? "edge" : string.Empty;
            int coverage = browser.Length == 0 ? 0 : FocusBrowserCoverage(FocusDataDirectory(), browser, DateTime.UtcNow);
            return ShouldCloseFocusBrowser(name, coverage, (DateTime.UtcNow - process.StartTime.ToUniversalTime()).TotalSeconds, keywords);
        }

        internal static bool IsSameFocusProcess(FocusProcessIdentity identity)
        {
            try { return !identity.Process.HasExited && identity.Process.SessionId == identity.SessionId && identity.Process.StartTime.ToUniversalTime().Ticks == identity.StartUtcTicks; }
            catch { return false; }
        }

        internal static void RequestFocusProgramClose(FocusProcessIdentity identity)
        {
            if (!IsFocusLearnPhase(ReadFocusClockUtc()) || !IsSameFocusProcess(identity) || identity.SessionId <= 0) return;
            int sessionId = identity.SessionId;
            string request = identity.Process.Id.ToString(CultureInfo.InvariantCulture) + ":" + identity.StartUtcTicks.ToString(CultureInfo.InvariantCulture);
            int timeoutMilliseconds = FocusVisibilityTimeoutMilliseconds;
            uint result = sessionId == Process.GetCurrentProcess().SessionId ? unchecked((uint)RunFocusProgramClose(request)) :
                RunFocusUserSessionHelper(sessionId, "--focus-close-program", request, timeoutMilliseconds);
            if (result == uint.MaxValue && IsFocusLearnPhase(ReadFocusClockUtc()) && IsSameFocusProcess(identity))
                identity.Process.CloseMainWindow();
        }

        private static void StopFocusBrowsers(List<Process> processes, IList<string> keywords, DateTime nowUtc, Action<string> log)
        {
            List<FocusProcessIdentity> visible = FindFocusVisibleProcesses(processes, log);
            List<FocusProcessIdentity> targets = new List<FocusProcessIdentity>();
            foreach (Process process in processes)
            {
                try
                {
                    FocusProcessIdentity identity = new FocusProcessIdentity { Process = process, SessionId = process.SessionId, StartUtcTicks = process.StartTime.ToUniversalTime().Ticks };
                    if (identity.SessionId <= 0 || !IsSameFocusProcess(identity) || !IsFocusLearnPhase(ReadFocusClockUtc()) || !IsFocusBrowserDue(process, keywords)) continue;
                    targets.Add(identity);
                    int sessionId = identity.SessionId;
                    string request = process.Id.ToString(CultureInfo.InvariantCulture) + ":" + identity.StartUtcTicks.ToString(CultureInfo.InvariantCulture);
                    int timeoutMilliseconds = FocusVisibilityTimeoutMilliseconds;
                    if (sessionId == Process.GetCurrentProcess().SessionId) RunFocusBrowserClose(request);
                    else RunFocusUserSessionHelper(sessionId, "--focus-close-browser", request, timeoutMilliseconds);
                }
                catch { }
            }
            Stopwatch wait = Stopwatch.StartNew();
            while (wait.ElapsedMilliseconds < 8000 && targets.Exists(IsSameFocusProcess)) Thread.Sleep(100);
            foreach (FocusProcessIdentity identity in targets)
            {
                try
                {
                    if (IsSameFocusProcess(identity) && IsFocusLearnPhase(ReadFocusClockUtc()) && IsFocusBrowserDue(identity.Process, keywords)) identity.Process.Kill();
                    if (IsSameFocusProcess(identity)) identity.Process.WaitForExit(1000);
                }
                catch { }
            }
            foreach (FocusProcessIdentity window in visible)
            {
                try { if (window.Process.HasExited) NotifyFocusProgramClosed(window.Program, nowUtc, window.SessionId); }
                catch { }
            }
        }

        internal static bool IsFocusLearnPhase(DateTime nowUtc)
        {
            return LoadFocusLearnState(nowUtc) != null;
        }

        internal static bool ApplyFocusGameRules(VideoGamesGuardRules rules, DateTime nowUtc)
        {
            if (!IsFocusLearnPhase(nowUtc)) return false;
            if (!rules.Enabled) rules.HeuristicEnabled = false;
            rules.Enabled = true;
            rules.Mode = "strict";
            rules.AutoDetectEnabled = true;
            return true;
        }

        // Hinweise des Lernmodus beim Uebernehmen einer fremden Sitzung (Titel, Text). Die Vorgabe ist die
        // Meldung des Dienstes; die Pruefungen setzen hier einen Sammler.
        internal static Action<string, string> FocusNotifier = VideoGamesGuard.NotifyUser;
        private static readonly HashSet<string> focusAdoptionNoticed = new HashSet<string>(StringComparer.Ordinal);

        // Uebernimmt die beste laufende Sitzung der anderen Geraete (Spec 2026-11-20, Abschnitt 5.3). Ob der
        // Abgleich hier an ist, pruefen die Aufrufer. Alle Zeiten der Sitzung sind die der Uhr des Lernmodus
        // (focusNowUtc); systemNowUtc gilt nur fuer die Herzschlag-Dateien der Companions. Nicht unter
        // deviceSyncSync rufen (focusSync darf nicht darunter genommen werden).
        internal static FocusAdoptionResult AdoptFocusFromPeers(IList<DeviceSyncSnapshot> peers, DateTime focusNowUtc, DateTime systemNowUtc)
        {
            DeviceSyncSnapshot best = null;
            if (peers != null)
            {
                foreach (DeviceSyncSnapshot peer in peers)
                {
                    if (peer == null || !IsAdoptableFocusSession(peer.FocusStartUtc, peer.FocusMinutes, peer.FocusCycle, peer.FocusPause, focusNowUtc)) { continue; }
                    if (best == null || FocusSessionOutranks(peer.FocusStartUtc, peer.FocusMinutes, peer.FocusCycle, peer.FocusPause,
                        best.FocusStartUtc, best.FocusMinutes, best.FocusCycle, best.FocusPause)) { best = peer; }
                }
            }
            if (best == null || IsBetaExpired() || VideoGamesGuard.TryLoadUsageIntegrityKey() == null) { return FocusAdoptionResult.None; }

            string dataDir = FocusDataDirectory();
            FocusAdoptionResult result;
            lock (focusSync)
            {
                FocusState state = LoadFocusState(dataDir, focusNowUtc);
                int edge, end;
                bool running = FocusPhaseAt(state.StartUtc, state.Minutes, state.Cycle, state.Pause, focusNowUtc, out edge, out end) != "off";
                if (running && !FocusSessionOutranks(best.FocusStartUtc, best.FocusMinutes, best.FocusCycle, best.FocusPause,
                    state.StartUtc, state.Minutes, state.Cycle, state.Pause)) { return FocusAdoptionResult.None; }
                if (FocusBrowserCoverage(dataDir, "Chrome", systemNowUtc) != 1 && FocusBrowserCoverage(dataDir, "Edge", systemNowUtc) != 1)
                {
                    result = FocusAdoptionResult.NoCompanion;
                }
                else
                {
                    // Die eigenen Listen bleiben; nur die Sitzung wird die des anderen Geraets.
                    state.StartUtc = best.FocusStartUtc;
                    state.Minutes = best.FocusMinutes;
                    state.Cycle = best.FocusCycle;
                    state.Pause = best.FocusPause;
                    SaveFocusState(dataDir, state);
                    RefreshFocusMirror(dataDir, state, focusNowUtc);
                    result = running ? FocusAdoptionResult.Replaced : FocusAdoptionResult.Adopted;
                }
            }
            if (result != FocusAdoptionResult.NoCompanion) { QueueFocusEnforcement(); }
            NoticeFocusAdoption(result, best);
            return result;
        }

        // Je Sitzung und Art ein Hinweis im Speicher. Der Zustand ist zu diesem Zeitpunkt schon gespeichert: ein
        // Fehler im Hinweis macht die Uebernahme nicht rueckgaengig und wiederholt den Hinweis nicht.
        private static void NoticeFocusAdoption(FocusAdoptionResult result, DeviceSyncSnapshot peer)
        {
            string kind = result == FocusAdoptionResult.Adopted ? "adopted" : result == FocusAdoptionResult.Replaced ? "replaced" : "nocompanion";
            string key = kind + "|" + peer.FocusStartUtc.ToString("o", CultureInfo.InvariantCulture) + "," +
                peer.FocusMinutes.ToString(CultureInfo.InvariantCulture) + "," + peer.FocusCycle.ToString(CultureInfo.InvariantCulture) + "," + peer.FocusPause.ToString(CultureInfo.InvariantCulture);
            lock (focusSync)
            {
                if (!focusAdoptionNoticed.Add(key)) { return; }
            }
            string time = peer.FocusStartUtc.AddMinutes(peer.FocusMinutes).ToLocalTime().ToString("HH:mm", CultureInfo.InvariantCulture);
            string name = peer.Name ?? string.Empty;
            string text = result == FocusAdoptionResult.Adopted
                ? "Auf " + name + " läuft eine Lernsitzung bis " + time + " Uhr. Sie gilt jetzt auch hier."
                : result == FocusAdoptionResult.Replaced
                    ? "Die Lernsitzung läuft jetzt bis " + time + " Uhr (verlängert durch " + name + ")."
                    : "Die Lernsitzung von " + name + " läuft bis " + time + " Uhr, konnte hier aber nicht übernommen werden: Der Companion im Browser hat sich noch nicht gemeldet.";
            FocusNotifier("Purestate Lernmodus", text);
        }

        internal static void RunFocus(Action<string> log)
        {
            lock (focusRunSync)
            {
                try
                {
                    DateTime nowUtc = ReadFocusClockUtc();
                    FocusState state = LoadFocusLearnState(nowUtc);
                    if (state == null) return;
                    HashSet<string> names = new HashSet<string>(FocusMusicPrograms, StringComparer.OrdinalIgnoreCase);
                    names.UnionWith(state.Programs);
                    // Browser coverage and grace checks own these names, even on the private list.
                    names.ExceptWith(FocusBrowserPrograms);
                    List<string> browserKeywords = new List<string>();
                    try { browserKeywords = ReadFocusBrowserKeywords(); }
                    catch (Exception ex) { log("Lernmodus: Browserregeln konnten nicht gelesen werden: " + ex.Message); }
                    Process[] snapshot = Process.GetProcesses();
                    try
                    {
                        List<Process> running = new List<Process>();
                        List<Process> browsers = new List<Process>();
                        foreach (Process process in snapshot)
                        {
                            try
                            {
                                string name = process.ProcessName + ".exe";
                                if (ShouldCloseFocusBrowser(name, 0, FocusBrowserGraceSeconds, browserKeywords))
                                {
                                    if (IsFocusBrowserDue(process, browserKeywords)) browsers.Add(process);
                                }
                                else if (names.Contains(name)) running.Add(process);
                            }
                            catch { }
                        }
                        if (browsers.Count > 0) StopFocusBrowsers(browsers, browserKeywords, nowUtc, log);
                        if (running.Count > 0) VideoGamesGuard.StopFocusProcesses(running, nowUtc, log);
                    }
                    finally
                    {
                        foreach (Process process in snapshot) { try { process.Dispose(); } catch { } }
                    }
                }
                catch (Exception ex) { try { log("Lernmodus Fehler: " + ex.Message); } catch { } }
            }
        }

        internal static void NotifyFocusProgramClosed(string program, DateTime nowUtc, int sessionId)
        {
            lock (focusSync)
            {
                FocusState state = LoadFocusLearnState(nowUtc);
                if (state == null) return;
                int cycle = state.Cycle == 0 ? 0 : (int)(Math.Max(0, (nowUtc - state.StartUtc).TotalMinutes) / state.Cycle);
                string phase = state.StartUtc.ToString("o", CultureInfo.InvariantCulture) + "|" + cycle.ToString(CultureInfo.InvariantCulture);
                if (phase != focusNotificationPhase)
                {
                    focusNotificationPhase = phase;
                    focusNotifiedPrograms.Clear();
                }
                if (!focusNotifiedPrograms.Add(sessionId.ToString(CultureInfo.InvariantCulture) + "|" + program)) return;
            }
            VideoGamesGuard.NotifyUser(sessionId, "Purestate Lernmodus", "Der Lernmodus läuft. " + program + " wird geschlossen.");
        }

        private static void QueueFocusEnforcement()
        {
            // Graceful closure may wait 30 seconds; the command pipe has a 10-second deadline.
            ThreadPool.QueueUserWorkItem(delegate
            {
                try { RunFocus(Log); VideoGamesGuard.Run(Log); }
                catch (Exception ex) { Log("Lernmodus: Durchsetzung fehlgeschlagen: " + ex.Message); }
            });
        }

        internal static bool IsFocusCoveredHeartbeat(string heartbeatText, DateTime systemNowUtc)
        {
            string[] parts = (heartbeatText ?? string.Empty).Split('|');
            Version version;
            DateTime heartbeatUtc;
            if (parts.Length != 2 || !Regex.IsMatch(parts[0], @"^[0-9]+\.[0-9]+\.[0-9]+\z") ||
                !Version.TryParse(parts[0], out version) || version < new Version(FocusMinCompanionVersion) ||
                !DateTime.TryParseExact(parts[1], "o", CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out heartbeatUtc) ||
                heartbeatUtc.Kind != DateTimeKind.Utc) return false;
            double ageHours = (systemNowUtc - heartbeatUtc).TotalHours;
            return ageHours >= 0 && ageHours <= 24;
        }

        internal static int FocusBrowserCoverage(string dataDir, string browser, DateTime systemNowUtc)
        {
            if (!string.Equals(browser, "Chrome", StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(browser, "Edge", StringComparison.OrdinalIgnoreCase)) return 0;
            string path = Path.Combine(dataDir, browser.ToLowerInvariant() + "-companion-heartbeat.txt");
            lock (heartbeatFileSync)
            {
                try
                {
                    using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        if (stream.Length > 256) { ForgetFocusHeartbeat(path); return 0; }
                        using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                            return ObserveFocusHeartbeat(path, reader.ReadToEnd(), systemNowUtc) ? 1 : 0;
                    }
                }
                catch (FileNotFoundException) { ForgetFocusHeartbeat(path); return 0; }
                catch (DirectoryNotFoundException) { ForgetFocusHeartbeat(path); return 0; }
                catch (IOException) { return -1; }
                catch (UnauthorizedAccessException) { return -1; }
            }
        }

        internal static string HandleFocusMessage(string message, DateTime nowUtc)
        {
            bool enforce;
            lock (focusSync)
            {
                string[] parts = (message ?? string.Empty).Split('|');
                bool start = parts.Length == 4 && parts[0] == "start";
                bool entry = parts.Length == 3 && (parts[0] == "add" || parts[0] == "remove") && (parts[1] == "site" || parts[1] == "program");
                if (message != "status" && message != "list" && !start && !entry) return "ERROR|unknown-command";

                int minutes = 0, cycle = 0, pause = 0;
                if (start && (!int.TryParse(parts[1], NumberStyles.None, CultureInfo.InvariantCulture, out minutes) ||
                    !int.TryParse(parts[2], NumberStyles.None, CultureInfo.InvariantCulture, out cycle) ||
                    !int.TryParse(parts[3], NumberStyles.None, CultureInfo.InvariantCulture, out pause) ||
                    !IsValidFocusPlan(minutes, cycle, pause))) return "ERROR|invalid-plan";
                string normalized = null;
                if (entry && !(parts[1] == "site" ? TryNormalizeFocusSite(parts[2], out normalized) : TryNormalizeFocusProgram(parts[2], out normalized)))
                    return "ERROR|invalid-entry";

                string dataDir = FocusDataDirectory();
                FocusState state = LoadFocusState(dataDir, nowUtc);
                int edge, end;
                string phase = FocusPhaseAt(state.StartUtc, state.Minutes, state.Cycle, state.Pause, nowUtc, out edge, out end);
                if (message == "list")
                {
                    StringBuilder response = new StringBuilder("OK");
                    foreach (string site in state.Sites) response.Append("|site=").Append(site);
                    foreach (string program in state.Programs) response.Append("|program=").Append(program);
                    return response.ToString();
                }
                if (message == "status")
                {
                    DateTime systemNowUtc = DateTime.UtcNow;
                    bool covered = FocusBrowserCoverage(dataDir, "Chrome", systemNowUtc) == 1 || FocusBrowserCoverage(dataDir, "Edge", systemNowUtc) == 1;
                    return string.Format(CultureInfo.InvariantCulture,
                        "OK|phase={0}|edge={1}|end={2}|plan={3},{4},{5}|sites={6}|programs={7}|covered={8}|beta={9}",
                        phase, edge, end, state.Minutes, state.Cycle, state.Pause, state.Sites.Count, state.Programs.Count, covered ? 1 : 0, IsBetaExpired() ? 1 : 0);
                }
                if (VideoGamesGuard.TryLoadUsageIntegrityKey() == null) return "ERROR|no-key";
                if (start)
                {
                    if (phase != "off") return "ERROR|session-running";
                    if (IsBetaExpired()) return "ERROR|beta-expired";
                    DateTime systemNowUtc = DateTime.UtcNow;
                    if (FocusBrowserCoverage(dataDir, "Chrome", systemNowUtc) != 1 && FocusBrowserCoverage(dataDir, "Edge", systemNowUtc) != 1)
                        return "ERROR|no-companion";
                    state.StartUtc = nowUtc;
                    state.Minutes = minutes; state.Cycle = cycle; state.Pause = pause;
                }
                else
                {
                    List<string> list = parts[1] == "site" ? state.Sites : state.Programs;
                    if (parts[0] == "remove")
                    {
                        if (phase != "off") return "ERROR|session-running";
                        if (!list.Remove(normalized)) return "ERROR|not-found";
                    }
                    else
                    {
                        if (list.Contains(normalized)) return "OK";
                        if (list.Count >= (parts[1] == "site" ? FocusMaxSites : FocusMaxPrograms)) return "ERROR|list-full";
                        list.Add(normalized);
                    }
                }
                SaveFocusState(dataDir, state);
                RefreshFocusMirror(dataDir, state, nowUtc);
                enforce = start || (parts[0] == "add" && parts[1] == "program" && phase == "learn");
            }
            if (enforce) QueueFocusEnforcement();
            return "OK";
        }

        private void FocusServerLoop()
        {
            while (!stopping)
            {
                try { ServeFocusConnection(FocusPipeName); }
                catch (Exception ex)
                {
                    if (!stopping)
                    {
                        Log("Lernmodus: Pipe-Fehler: " + ex.Message);
                        Thread.Sleep(1000);
                    }
                }
            }
        }

        internal void ServeFocusConnection(string pipeName)
        {
            using (NamedPipeServerStream pipe = new NamedPipeServerStream(pipeName, PipeDirection.InOut, 1,
                PipeTransmissionMode.Byte, PipeOptions.Asynchronous, FocusMaxCommandBytes, MaxDeviceSyncMessageBytes, CreateGuardPipeSecurity()))
            {
                if (!WaitForHeartbeatConnection(pipe)) return;
                uint clientProcessId = GetHeartbeatClientProcessId(pipe);
                string message = null, tooLong = null;
                try { message = ReadPipeLine(pipe, FocusMaxCommandBytes); }
                catch (System.TimeoutException)
                {
                    Log("Lernmodus: Nachricht nicht rechtzeitig gelesen.");
                    return;
                }
                catch (InvalidDataException) { tooLong = "ERROR|too-long"; }
                string rejectionReason;
                if (!IsTrustedDeviceSyncClient(clientProcessId, out rejectionReason))
                {
                    Log("Lernmodus: Client abgewiesen: " + rejectionReason);
                    WriteDeviceSyncResponse(pipe, "ERROR|untrusted-client");
                    return;
                }
                WriteDeviceSyncResponse(pipe, tooLong ?? HandleFocusMessage(message, ReadFocusClockUtc()));
            }
        }

        internal static bool TryNormalizeFocusSite(string input, out string host)
        {
            host = null;
            if (input == null || input.IndexOfAny(new char[] { '\r', '\n' }) >= 0) return false;
            Match match = Regex.Match(input, @"^(?:[a-z][a-z0-9+.-]*://)?([^/?#]+)(?:[/?#].*)?\z", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
            if (!match.Success) return false;
            string value = match.Groups[1].Value.ToLowerInvariant();
            if (value.StartsWith("www.", StringComparison.Ordinal)) value = value.Substring(4);
            if (value.Length > 253 || value.IndexOf('.') < 0 || value.StartsWith(".", StringComparison.Ordinal) ||
                value.EndsWith(".", StringComparison.Ordinal) || value.Contains("..") || !Regex.IsMatch(value, @"^[a-z0-9.-]+\z")) return false;
            host = value;
            return true;
        }

        internal static bool TryNormalizeFocusProgram(string input, out string exe)
        {
            exe = null;
            if (input == null) return false;
            string value;
            try { value = Path.GetFileName(input).ToLowerInvariant(); }
            catch (ArgumentException) { return false; }
            if (!Regex.IsMatch(value, @"^[a-z0-9._ -]{1,60}\.exe\z") || FocusProtectedPrograms.Contains(value)) return false;
            exe = value;
            return true;
        }

        internal static string BuildFocusStateText(FocusState state, byte[] integrityKey)
        {
            if (state == null || integrityKey == null || integrityKey.Length < 32 || state.Sites == null || state.Programs == null ||
                state.Sites.Count > FocusMaxSites || state.Programs.Count > FocusMaxPrograms) return null;
            if (state.Minutes == 0)
            {
                if (state.StartUtc != DateTime.MinValue || state.Cycle != 0 || state.Pause != 0) return null;
            }
            else if (!IsValidFocusPlan(state.Minutes, state.Cycle, state.Pause) || state.StartUtc == DateTime.MinValue || state.StartUtc.Kind != DateTimeKind.Utc) return null;

            StringBuilder body = new StringBuilder("v=1\nstart=");
            body.Append(state.Minutes == 0 ? string.Empty : state.StartUtc.ToString("o", CultureInfo.InvariantCulture));
            body.Append("\nplan=").Append(state.Minutes.ToString(CultureInfo.InvariantCulture)).Append(',')
                .Append(state.Cycle.ToString(CultureInfo.InvariantCulture)).Append(',').Append(state.Pause.ToString(CultureInfo.InvariantCulture)).Append('\n');
            foreach (string site in state.Sites)
            {
                string normalized;
                if (!TryNormalizeFocusSite(site, out normalized) || normalized != site) return null;
                body.Append("site=").Append(site).Append('\n');
            }
            foreach (string program in state.Programs)
            {
                string normalized;
                if (!TryNormalizeFocusProgram(program, out normalized) || normalized != program) return null;
                body.Append("program=").Append(program).Append('\n');
            }
            string text = body.ToString();
            return text + "integrity=" + VideoGamesGuard.ComputeUsageIntegrity(text, integrityKey);
        }

        internal static int ReadFocusStateText(string text, byte[] integrityKey, out FocusState state)
        {
            state = null;
            if (text == null || text.Length > FocusMaxStateBytes || integrityKey == null || integrityKey.Length < 32) return 1;
            const string marker = "\nintegrity=";
            int split = text.LastIndexOf(marker, StringComparison.Ordinal);
            if (split < 0) return 1;
            string body = text.Substring(0, split + 1);
            string stored = text.Substring(split + marker.Length);
            if (!DeviceSyncFixedTimeEquals(Encoding.UTF8.GetBytes(stored), Encoding.UTF8.GetBytes(VideoGamesGuard.ComputeUsageIntegrity(body, integrityKey)))) return 1;

            string[] lines = body.Split('\n');
            if (lines.Length < 4 || lines[0] != "v=1" || !lines[1].StartsWith("start=", StringComparison.Ordinal) || !lines[2].StartsWith("plan=", StringComparison.Ordinal)) return 1;
            FocusState parsed = new FocusState();
            string start = lines[1].Substring(6);
            if (start.Length > 0 && !DateTime.TryParseExact(start, "o", CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out parsed.StartUtc)) return 1;
            string[] plan = lines[2].Substring(5).Split(',');
            if (plan.Length != 3 || !int.TryParse(plan[0], NumberStyles.None, CultureInfo.InvariantCulture, out parsed.Minutes) ||
                !int.TryParse(plan[1], NumberStyles.None, CultureInfo.InvariantCulture, out parsed.Cycle) ||
                !int.TryParse(plan[2], NumberStyles.None, CultureInfo.InvariantCulture, out parsed.Pause)) return 1;
            for (int i = 3; i < lines.Length - 1; i++)
            {
                if (lines[i].StartsWith("site=", StringComparison.Ordinal)) parsed.Sites.Add(lines[i].Substring(5));
                else if (lines[i].StartsWith("program=", StringComparison.Ordinal)) parsed.Programs.Add(lines[i].Substring(8));
                else return 1;
            }
            // Rebuilding also checks canonical names, field order, dates, plans and list limits.
            if (!string.Equals(text, BuildFocusStateText(parsed, integrityKey), StringComparison.Ordinal)) return 1;
            state = parsed;
            return 0;
        }

        private static FocusState CopyFocusState(FocusState state)
        {
            if (state == null) return new FocusState();
            return new FocusState { StartUtc = state.StartUtc, Minutes = state.Minutes, Cycle = state.Cycle, Pause = state.Pause,
                Sites = new List<string>(state.Sites), Programs = new List<string>(state.Programs) };
        }

        internal static FocusState LoadFocusState(string dataDir, DateTime nowUtc)
        {
            lock (focusSync)
            {
                byte[] key = VideoGamesGuard.TryLoadUsageIntegrityKey();
                if (key == null) return new FocusState();
                EnsureDataDirectoryIsNotReparsePoint(dataDir);
                if (focusCorruptionAuditPending) LogFocusCorruption(dataDir);
                // A failed replacement leaves older disk contents; the pending state remains authoritative.
                if (focusStatePendingWrite)
                {
                    SaveFocusState(dataDir, focusState);
                    return CopyFocusState(focusState);
                }
                string path = Path.Combine(dataDir, "focus-state.txt");
                FocusState loaded;
                try
                {
                    using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        if (stream.Length > FocusMaxStateBytes) loaded = null;
                        else
                        {
                            using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                            {
                                if (ReadFocusStateText(reader.ReadToEnd(), key, out loaded) != 0) loaded = null;
                            }
                        }
                    }
                }
                catch (FileNotFoundException)
                {
                    if (focusState != null) SaveFocusState(dataDir, focusState);
                    return CopyFocusState(focusState);
                }
                catch (DirectoryNotFoundException)
                {
                    if (focusState != null) SaveFocusState(dataDir, focusState);
                    return CopyFocusState(focusState);
                }
                catch (IOException) { return CopyFocusState(focusState); }
                catch (UnauthorizedAccessException) { return CopyFocusState(focusState); }

                if (loaded != null)
                {
                    focusState = loaded;
                    if (!focusCorruptionAuditPending) focusCorruptionLogged = false;
                }
                else
                {
                    focusState = new FocusState { StartUtc = nowUtc, Minutes = FocusMaxMinutes };
                    if (!focusCorruptionLogged)
                    {
                        LogFocusCorruption(dataDir);
                    }
                    SaveFocusState(dataDir, focusState);
                }
                return CopyFocusState(focusState);
            }
        }

        internal static string FocusHeartbeatToken(DateTime nowUtc)
        {
            lock (focusSync)
            {
                if (IsBetaExpired() || VideoGamesGuard.TryLoadUsageIntegrityKey() == null) return "focus=off";
                FocusState state = LoadFocusState(FocusDataDirectory(), nowUtc);
                int edge, end;
                string phase = FocusPhaseAt(state.StartUtc, state.Minutes, state.Cycle, state.Pause, nowUtc, out edge, out end);
                return phase == "off" ? "focus=off" : string.Format(CultureInfo.InvariantCulture,
                    "focus={0},{1},{2},{3}", phase, edge, end, state.Pause);
            }
        }

        internal static void ProbeFocusEdge()
        {
            try
            {
                lock (focusSync)
                {
                    string dataDir = FocusDataDirectory();
                    DateTime nowUtc = ReadFocusClockUtc();
                    RefreshFocusMirror(dataDir, LoadFocusState(dataDir, nowUtc), nowUtc);
                }
            }
            catch (Exception ex) { Log("Lernmodus: Spiegelpruefung fehlgeschlagen (" + ex.GetType().Name + ")."); }
        }

        // Keep snapshot and publication under focusSync so an older probe cannot win a race with start/add.
        private static void RefreshFocusMirror(string dataDir, FocusState state, DateTime nowUtc)
        {
            if (focusStatePendingWrite) return;
            int edge, end;
            string phase = IsBetaExpired() || VideoGamesGuard.TryLoadUsageIntegrityKey() == null ? "off" :
                FocusPhaseAt(state.StartUtc, state.Minutes, state.Cycle, state.Pause, nowUtc, out edge, out end);
            WriteFocusMirror(dataDir, phase, state.Sites);
        }

        internal static void WriteFocusMirror(string dataDir, string phase, IList<string> sites)
        {
            lock (focusSync)
            {
                try
                {
                    EnsureDataDirectoryIsNotReparsePoint(dataDir);
                    string publicDir = Path.Combine(dataDir, "public");
                    // The app provisions the public directory and its read-only user ACL.
                    if (!Directory.Exists(publicDir)) return;
                    EnsureDataDirectoryIsNotReparsePoint(publicDir);
                    StringBuilder json = new StringBuilder("{\"v\":1,\"phase\":\"").Append(phase).Append("\",\"sites\":[");
                    for (int index = 0; index < sites.Count; index++)
                    {
                        if (index > 0) json.Append(',');
                        json.Append('"').Append(sites[index]).Append('"');
                    }
                    string text = json.Append("]}").ToString();
                    string path = Path.Combine(publicDir, "focus-session.json");
                    if (File.Exists(path) && new FileInfo(path).Length <= FocusMaxStateBytes && File.ReadAllText(path, Encoding.UTF8) == text) return;
                    ReplaceFileAtomically(path, delegate(string temp) { File.WriteAllText(temp, text, new UTF8Encoding(false)); });
                }
                catch (Exception ex) { Log("Lernmodus: focus-session.json konnte nicht geschrieben werden (" + ex.GetType().Name + "); der naechste Takt versucht es erneut."); }
            }
        }

        internal static void SaveFocusState(string dataDir, FocusState state)
        {
            lock (focusSync)
            {
                byte[] key = VideoGamesGuard.TryLoadUsageIntegrityKey();
                if (key == null) return;
                string text = BuildFocusStateText(state, key);
                if (text == null) return;
                EnsureDataDirectoryIsNotReparsePoint(dataDir);
                focusState = CopyFocusState(state);
                focusStatePendingWrite = true;
                try
                {
                    ReplaceFileAtomically(Path.Combine(dataDir, "focus-state.txt"), delegate(string temp)
                    {
                        File.WriteAllText(temp, text, new UTF8Encoding(false));
                    });
                    focusStatePendingWrite = false;
                }
                catch (Exception ex)
                {
                    Log("Lernmodus: focus-state.txt konnte nicht geschrieben werden (" + ex.GetType().Name + "); der Stand bleibt im Speicher.");
                }
            }
        }

        private static void LogFocusCorruption(string dataDir)
        {
            const string message = "Lernmodus: focus-state.txt ist beschaedigt; Lernphase ohne Pausen fuer 480 Minuten.";
            if (!focusCorruptionLogged)
            {
                Log(message);
                focusCorruptionLogged = true;
            }
            focusCorruptionAuditPending = true;
            try
            {
                EnsureDataDirectoryIsNotReparsePoint(dataDir);
                string path = Path.Combine(dataDir, "security.log");
                string line = DateTime.Now.ToString("s") + " " + message + Environment.NewLine;
                if (new FileInfo(path).Exists && new FileInfo(path).Length > MaxServiceLogBytes)
                    File.WriteAllText(path, line, new UTF8Encoding(false));
                else File.AppendAllText(path, line, new UTF8Encoding(false));
                focusCorruptionAuditPending = false;
            }
            catch (Exception) { }
        }

        // Wie weit der Start einer fremden Sitzung nach der eigenen Uhr liegen darf (Uhrabweichung, Spec 7).
        internal const int FocusStartToleranceMinutes = 5;

        // Eine Sitzung, die ein anderes Geraet meldet, gilt nur, wenn der Plan stimmt, der Start hoechstens
        // FocusStartToleranceMinutes nach der eigenen Uhr liegt und das Ende noch nicht erreicht ist. So
        // sperrt eine falsch gehende Uhr nie lange: das Ende liegt nie spaeter als 8 Stunden und 5 Minuten voraus.
        internal static bool IsAdoptableFocusSession(DateTime startUtc, int minutes, int cycle, int pause, DateTime nowUtc)
        {
            return IsValidFocusPlan(minutes, cycle, pause) &&
                startUtc.Kind == DateTimeKind.Utc &&
                startUtc <= nowUtc.AddMinutes(FocusStartToleranceMinutes) &&
                startUtc.AddMinutes(minutes) > nowUtc;
        }

        // Pausenminuten einer Sitzung insgesamt: eine Pause je k >= 1 mit k * cycle < minutes (wie FocusPhaseAt).
        internal static int FocusBreakMinutesTotal(int minutes, int cycle, int pause)
        {
            int total = 0;
            if (cycle > 0)
            {
                for (int end = cycle; end < minutes; end += cycle) { total += pause; }
            }
            return total;
        }

        // A schlaegt B strikt (Spec 3.3): spaeter endende Sitzung, bei gleichem Ende der fruehere Start, bei
        // gleichem Start weniger Pausenminuten, dann der groessere Zyklus. Gleich ergibt false.
        internal static bool FocusSessionOutranks(DateTime startA, int minutesA, int cycleA, int pauseA,
            DateTime startB, int minutesB, int cycleB, int pauseB)
        {
            DateTime endA = startA.AddMinutes(minutesA);
            DateTime endB = startB.AddMinutes(minutesB);
            if (endA != endB) { return endA > endB; }
            if (startA != startB) { return startA < startB; }
            int breaksA = FocusBreakMinutesTotal(minutesA, cycleA, pauseA);
            int breaksB = FocusBreakMinutesTotal(minutesB, cycleB, pauseB);
            if (breaksA != breaksB) { return breaksA < breaksB; }
            return cycleA > cycleB;
        }

        internal static bool IsValidFocusPlan(int minutes, int cycle, int pause)
        {
            return minutes >= FocusMinMinutes && minutes <= FocusMaxMinutes && minutes % FocusStepMinutes == 0
                && ((cycle == 0 && pause == 0) || (cycle == 30 && pause == 5) || (cycle == 60 && pause == 15));
        }

        internal static string FocusPhaseAt(DateTime startUtc, int minutes, int cycle, int pause, DateTime nowUtc,
            out int secondsToEdge, out int secondsToEnd)
        {
            double elapsed = Math.Max(0, (nowUtc - startUtc).TotalSeconds);
            int duration = minutes * 60;
            secondsToEdge = secondsToEnd = (int)Math.Ceiling(Math.Max(0, duration - elapsed));
            if (elapsed >= duration) return "off";

            if (cycle > 0)
            {
                for (int breakEnd = cycle * 60; breakEnd < duration; breakEnd += cycle * 60)
                {
                    int breakStart = breakEnd - pause * 60;
                    if (elapsed < breakStart)
                    {
                        secondsToEdge = (int)Math.Ceiling(breakStart - elapsed);
                        return "learn";
                    }
                    if (elapsed < breakEnd)
                    {
                        secondsToEdge = (int)Math.Ceiling(breakEnd - elapsed);
                        return "break";
                    }
                }
            }
            return "learn";
        }
    }
}
