﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Text;
using System.Text.RegularExpressions;

namespace Purestate.NativeHost
{
    internal static class Program
    {
        private const string AllowedOrigin = "chrome-extension://gmldhenkcnghfoapdnhkikfpgdmmnlok/";
        private const string PipeName = "PurestateCompanionHeartbeat";
        private const int MaxRulesPerSection = 250;
        // GHX-001: Erwachsenen- und Gluecksspiel-Freigaben teilen dieselben
        // Grenzen. Der Name sagt es, statt die Erwachsenenkonstante fuer beides
        // zu benutzen und den naechsten Leser raten zu lassen.
        private const int TimedExemptionCapacity = 500;
        private const int TimedExemptionLifetimeDays = 30;
        private const int MaxNativeMessageBytes = 1024 * 1024;
        private const int SubscribeRetryMilliseconds = 30000;
        private const long MaxLogBytes = 262144;
        private const int MaxLogMessageChars = 2048;
        private sealed class UnsafeDataDirectoryException : InvalidOperationException
        {
            public UnsafeDataDirectoryException()
                : base("Das Purestate-Datenverzeichnis darf kein Verknuepfungs- oder Reparse-Punkt sein.")
            {
            }
        }
        private static readonly string[][] SiteProtectionFields =
        {
            new[] { "reddit", "SiteRedditEnabled" },
            new[] { "x", "SiteXEnabled" },
            new[] { "bluesky", "SiteBlueskyEnabled" },
            new[] { "tumblr", "SiteTumblrEnabled" },
            new[] { "deviantart", "SiteDeviantArtEnabled" },
            new[] { "pixiv", "SitePixivEnabled" },
            new[] { "newgrounds", "SiteNewgroundsEnabled" },
            new[] { "imgur", "SiteImgurEnabled" },
            new[] { "instagram", "SiteInstagramEnabled" },
            new[] { "tiktok", "SiteTikTokEnabled" },
            new[] { "pinterest", "SitePinterestEnabled" }
        };

        // Every non-OK exit used to be silent, which made the 0.61.32/0.61.33
        // heartbeat debugging cycles blind (the host aborted before the guard
        // pipe and left no trace anywhere). Each failure path now records its
        // reason via LogFailure; logPhase names the step for the catch-all.
        private static string logPhase = "startup";

        private static int Main(string[] args)
        {
            try
            {
                if (args.Length > 0 && args[0].Equals("--self-test", StringComparison.OrdinalIgnoreCase))
                {
                    logPhase = "self-test";
                    string rulePack = LoadBrowserRulePackJson();
                    if (rulePack.IndexOf("\"adultSearchTerms\"", StringComparison.Ordinal) < 0 ||
                        rulePack.IndexOf("\"adultHashtags\"", StringComparison.Ordinal) < 0)
                    {
                        Console.Error.WriteLine("Browser companion rule pack self-test failed.");
                        return 1;
                    }
                    Console.WriteLine("Self-test OK.");
                    return 0;
                }

                logPhase = "origin check";
                string origin = args.Length > 0 ? args[0] : string.Empty;
                if (!IsAllowedOrigin(origin, AppDomain.CurrentDomain.BaseDirectory))
                {
                    LogFailure("Origin rejected: not trusted");
                    WriteResponse(false);
                    return 2;
                }

                logPhase = "reading native message";
                string json = ReadMessage();

                // Gelernter Erwachsenen-Host (Task 3): { type:"learn", area:"adult",
                // host }. Traegt bewusst kein Browser/Version-Feld, deshalb kommt
                // diese Pruefung vor der sonst verpflichtenden Browser/Version-
                // Pruefung unten. Der Native Host reicht nie durch, was er nicht
                // selbst geprueft hat (Regel aus 0.62.33) - BuildGuardLearnMessage
                // ist diese zweite, unabhaengige Pruefung.
                string messageType = ReadMessageType(json);
                if (messageType == "learn")
                {
                    logPhase = "exchanging learn with guard";
                    Match hostMatch = Regex.Match(json, "\\\"host\\\"\\s*:\\s*\\\"([^\\\"]{0,300})\\\"", RegexOptions.IgnoreCase);
                    string learnPipeMessage = hostMatch.Success ? BuildGuardLearnMessage(hostMatch.Groups[1].Value) : null;
                    if (learnPipeMessage == null)
                    {
                        LogFailure("Learn message invalid: host missing or malformed");
                        WriteResponse(false);
                        return 7;
                    }
                    WriteResponse(ExchangeGuardLearn(learnPipeMessage).StartsWith("OK", StringComparison.Ordinal));
                    return 0;
                }

                Match browserMatch = Regex.Match(json, "\\\"browser\\\"\\s*:\\s*\\\"(Chrome|Edge)\\\"", RegexOptions.IgnoreCase);
                Match versionMatch = Regex.Match(json, "\\\"version\\\"\\s*:\\s*\\\"(\\d+\\.\\d+\\.\\d+)\\\"", RegexOptions.IgnoreCase);
                if (!browserMatch.Success || !versionMatch.Success)
                {
                    LogFailure("Heartbeat message invalid: browser/version fields missing (payload length " + json.Length + ")");
                    WriteResponse(false);
                    return 3;
                }

                string browser = browserMatch.Groups[1].Value;
                string version = versionMatch.Groups[1].Value;

                // Selector-canary report: the Companion found a protection
                // anchor missing on a page where it must exist (site redesign
                // risk). The check token is machine-readable (site:check);
                // free text, page URLs, and page content never reach this log
                // or the guard relay.
                if (messageType == "canary")
                {
                    logPhase = "writing canary log";
                    Match checkMatch = Regex.Match(json, "\\\"check\\\"\\s*:\\s*\\\"([a-z0-9][a-z0-9:._-]{0,79})\\\"", RegexOptions.IgnoreCase);
                    if (!checkMatch.Success)
                    {
                        LogFailure("Canary message invalid: check token missing or malformed");
                        WriteResponse(false);
                        return 5;
                    }
                    AppendCappedLogLine(
                        "companion-canary.log",
                        browser + " companion " + version + " reports missing protection anchors: " + checkMatch.Groups[1].Value.ToLowerInvariant());
                    string canaryPipeMessage = BuildGuardCanaryMessage(json, browser, version);
                    if (canaryPipeMessage.Length == 0)
                    {
                        LogFailure("Canary message invalid: check token missing or malformed");
                        WriteResponse(false);
                        return 5;
                    }
                    logPhase = "exchanging canary with guard";
                    ExchangeGuardCanary(canaryPipeMessage);
                    WriteResponse(true);
                    return 0;
                }

                // Web time-budget usage: relay a companion delta-report/query to
                // the guard, which owns the persistent per-day counters. Usage
                // messages carry no privileged capability (they can only spend
                // budget, never weaken protection), so no extra trust surface.
                if (messageType == "usage")
                {
                    logPhase = "exchanging usage with guard";
                    string usagePipeMessage = BuildGuardUsageMessage(json, browser, version);
                    if (usagePipeMessage.Length == 0)
                    {
                        LogFailure("Usage message invalid: action/area/delta/token fields missing or malformed");
                        WriteResponse(false);
                        return 6;
                    }
                    WriteNativePayload(Encoding.UTF8.GetBytes(BuildUsageResponseJson(ExchangeGuardUsage(usagePipeMessage))));
                    return 0;
                }

                bool rulesRequest = messageType == "rules";
                bool subscribeRequest = messageType == "subscribe";
                logPhase = "exchanging heartbeat with guard";
                Dictionary<string, string> guardAreaModes;
                bool ok = ExchangeGuardHeartbeat(browser, version, out guardAreaModes);
                if (!ok)
                {
                    LogFailure("Guard rejected heartbeat for " + browser + "|" + version + " (guard-side reason is in service.log)");
                }
                logPhase = "writing native response";
                if (rulesRequest || subscribeRequest)
                {
                    WriteRuleResponse(ok, ok ? LoadBrowserRulePackJson(guardAreaModes) : DefaultRulePackJson());
                }
                else
                {
                    WriteResponse(ok);
                }

                if (subscribeRequest && ok)
                {
                    logPhase = "subscribe push loop";
                    RunSubscribePushLoop(browser, version);
                    return 0;
                }

                return ok ? 0 : 4;
            }
            catch (Exception ex)
            {
                LogFailure("Abort during " + logPhase + ": " + ex.GetType().Name + ": " + Truncate(ex.Message, 200));
                try { WriteResponse(false); } catch { }
                return 1;
            }
        }

        internal static string BuildGuardCanaryMessage(string json, string browser, string version)
        {
            string payload = json ?? string.Empty;
            Match checkMatch = Regex.Match(payload, "\\\"check\\\"\\s*:\\s*\\\"([a-z0-9][a-z0-9._-]{0,39}):([a-z0-9][a-z0-9._-]{0,39})\\\"", RegexOptions.IgnoreCase);
            if (!checkMatch.Success)
            {
                return string.Empty;
            }
            return "CANARY|" + browser + "|" + version + "|" +
                checkMatch.Groups[1].Value.ToLowerInvariant() + "|" +
                checkMatch.Groups[2].Value.ToLowerInvariant();
        }

        // Dieselbe Hostform wie ADULT_HOST_SHAPE in background.js und LearnHostShape
        // im Guard - eine unabhaengige Kopie, weil Native Host und Guard getrennte
        // Programme sind. Der Native Host reicht nie durch, was er nicht selbst
        // geprueft hat (Regel aus 0.62.33).
        private static readonly Regex LearnHostShape =
            new Regex(@"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$");

        // Gelernter Host -> Pipe-Nachricht an den Guard. Gibt null zurueck, wenn der
        // Host die Form nicht besteht - dann wird nichts weitergereicht. Die
        // { type:"learn", ... }-Nachricht aus Task 3 traegt selbst kein
        // Browser/Version/Token-Feld, deshalb erzeugt diese Methode den Rest der
        // Grammatik selbst; der Guard wertet Browser/Version fuer learn-host
        // ohnehin nicht aus, das Token dient nur der eigenen Wiederholungssperre.
        internal static string BuildGuardLearnMessage(string host)
        {
            string candidate = (host ?? string.Empty).Trim().ToLowerInvariant();
            if (candidate.Length == 0 || candidate.Length > 253 || !LearnHostShape.IsMatch(candidate))
            {
                return null;
            }
            string token = Guid.NewGuid().ToString("N").Substring(0, 16);
            return "NativeHost|1.0|learn-host|adult|" + candidate + "|" + token;
        }

        // Companion usage JSON -> guard pipe line. Returns "" when any field
        // is missing or malformed so junk is never forwarded to the guard.
        //   report: <browser>|<version>|usage-report|<area>|<platform>|<delta>|<token>
        //   query:  <browser>|<version>|usage-query|<area>|<platform>
        private static string BuildGuardUsageMessage(string json, string browser, string version)
        {
            string payload = json ?? string.Empty;
            Match actionMatch = Regex.Match(payload, "\\\"action\\\"\\s*:\\s*\\\"(report|query|order|order-query|spend)\\\"");
            if (!actionMatch.Success)
            {
                return string.Empty;
            }

            // Shopping monthly order counter (area implicit): count one order,
            // optional self-reported euro estimate.
            if (actionMatch.Groups[1].Value == "order-query")
            {
                return browser + "|" + version + "|usage-order-query";
            }
            if (actionMatch.Groups[1].Value == "order")
            {
                Match orderTokenMatch = Regex.Match(payload, "\\\"token\\\"\\s*:\\s*\\\"([a-z0-9-]{8,40})\\\"");
                if (!orderTokenMatch.Success)
                {
                    return string.Empty;
                }
                Match amountMatch = Regex.Match(payload, "\\\"amountEuro\\\"\\s*:\\s*(\\d{1,5})\\b");
                if (Regex.IsMatch(payload, "\\\"amountEuro\\\"\\s*:\\s*\\d") && !Regex.IsMatch(payload, "\\\"amountEuro\\\"\\s*:\\s*\\d{1,5}\\b"))
                {
                    return string.Empty;
                }
                string amount = amountMatch.Success ? amountMatch.Groups[1].Value : string.Empty;
                return browser + "|" + version + "|usage-order|" + amount + "|" + orderTokenMatch.Groups[1].Value;
            }

            // Betrag zu einer schon gezaehlten Bestellung nachtragen. Anders als
            // bei "order" ist der Betrag Pflicht - ohne ihn gaebe es nichts
            // nachzutragen, und eine leere Nachricht soll gar nicht erst
            // entstehen.
            if (actionMatch.Groups[1].Value == "spend")
            {
                Match spendTokenMatch = Regex.Match(payload, "\\\"token\\\"\\s*:\\s*\\\"([a-z0-9-]{8,40})\\\"");
                Match spendAmountMatch = Regex.Match(payload, "\\\"amountEuro\\\"\\s*:\\s*(\\d{1,5})\\b");
                if (!spendTokenMatch.Success || !spendAmountMatch.Success)
                {
                    return string.Empty;
                }
                if (Regex.IsMatch(payload, "\\\"amountEuro\\\"\\s*:\\s*\\d") && !Regex.IsMatch(payload, "\\\"amountEuro\\\"\\s*:\\s*\\d{1,5}\\b"))
                {
                    return string.Empty;
                }
                return browser + "|" + version + "|usage-spend|" + spendAmountMatch.Groups[1].Value + "|" + spendTokenMatch.Groups[1].Value;
            }

            Match areaMatch = Regex.Match(payload, "\\\"area\\\"\\s*:\\s*\\\"(social|shopping|gambling)\\\"");
            if (!areaMatch.Success)
            {
                return string.Empty;
            }
            Match platformMatch = Regex.Match(payload, "\\\"platform\\\"\\s*:\\s*\\\"([a-z0-9-]{1,32})\\\"");
            string platform = platformMatch.Success ? platformMatch.Groups[1].Value : string.Empty;
            if (Regex.IsMatch(payload, "\\\"platform\\\"\\s*:\\s*\\\"") && !platformMatch.Success)
            {
                return string.Empty;
            }
            string area = areaMatch.Groups[1].Value;
            if (actionMatch.Groups[1].Value == "query")
            {
                return browser + "|" + version + "|usage-query|" + area + "|" + platform;
            }
            Match deltaMatch = Regex.Match(payload, "\\\"deltaSeconds\\\"\\s*:\\s*(\\d{1,6})\\b");
            Match tokenMatch = Regex.Match(payload, "\\\"token\\\"\\s*:\\s*\\\"([a-z0-9-]{8,40})\\\"");
            if (!deltaMatch.Success || !tokenMatch.Success)
            {
                return string.Empty;
            }
            return browser + "|" + version + "|usage-report|" + area + "|" + platform + "|" +
                deltaMatch.Groups[1].Value + "|" + tokenMatch.Groups[1].Value;
        }

        private static string BuildUsageResponseJson(string guardResponse)
        {
            string response = guardResponse ?? string.Empty;
            Match match = Regex.Match(response, "^OK\\|total=(\\d{1,9})\\|platform=(\\d{1,9})$");
            if (match.Success)
            {
                return "{\"ok\":true,\"usedSecondsTotal\":" + match.Groups[1].Value +
                    ",\"usedSecondsPlatform\":" + match.Groups[2].Value + "}";
            }
            Match orderMatch = Regex.Match(response, "^OK\\|orders=(\\d{1,9})\\|spend=(\\d{1,9})$");
            if (orderMatch.Success)
            {
                return "{\"ok\":true,\"monthOrders\":" + orderMatch.Groups[1].Value +
                    ",\"monthSpendEuro\":" + orderMatch.Groups[2].Value + "}";
            }
            return "{\"ok\":false}";
        }

        // NMH-001: Der Pipe-Namensraum \\.\pipe\ ist maschinenweit und fuer jeden
        // Benutzer beschreibbar - wer den Namen ZUERST belegt, ist aus Sicht des
        // Hosts der Guard. Dessen Antwort darf Schutzbereiche auf "off" setzen
        // (BuildHeartbeatResponse), und in seine Richtung fliessen gelernte
        // Erwachsenen-Hostnamen, Canary-Tokens und Nutzungsmeldungen. Fuer die
        // Gegenrichtung prueft der Guard den Client laengst
        // (IsTrustedHeartbeatClientProcess); hier fehlte jede Pruefung.
        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetNamedPipeServerProcessId(IntPtr pipe, out uint serverProcessId);

        [System.Runtime.InteropServices.DllImport("advapi32.dll", SetLastError = true, CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
        private static extern IntPtr OpenSCManager(string machineName, string databaseName, uint desiredAccess);

        [System.Runtime.InteropServices.DllImport("advapi32.dll", SetLastError = true, CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
        private static extern IntPtr OpenService(IntPtr manager, string serviceName, uint desiredAccess);

        [System.Runtime.InteropServices.DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool QueryServiceStatusEx(IntPtr service, int infoLevel, IntPtr buffer, uint bufferSize, out uint bytesNeeded);

        [System.Runtime.InteropServices.DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool CloseServiceHandle(IntPtr handle);

        private const uint ScManagerConnect = 0x0001;
        private const uint ServiceQueryStatus = 0x0004;
        private const int ScStatusProcessInfo = 0;
        private const string GuardServiceName = "PurestateGuard";

        // SERVICE_STATUS_PROCESS. Gebraucht wird nur dwProcessId; die uebrigen
        // Felder muessen trotzdem stehen, damit das Layout stimmt.
        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        private struct ServiceStatusProcess
        {
            public uint ServiceType;
            public uint CurrentState;
            public uint ControlsAccepted;
            public uint Win32ExitCode;
            public uint ServiceSpecificExitCode;
            public uint CheckPoint;
            public uint WaitHint;
            public uint ProcessId;
            public uint ServiceFlags;
        }

        // Reine Vergleichslogik, damit sie ohne laufenden Dienst pruefbar ist.
        // Beide Seiten muessen bekannt sein: eine unbekannte PID (0) ist nie
        // vertrauenswuerdig, sonst waere "nichts feststellbar" dasselbe wie
        // "stimmt ueberein".
        internal static bool IsTrustedGuardPipeServerProcess(uint serverProcessId, uint guardServiceProcessId)
        {
            return serverProcessId != 0 &&
                guardServiceProcessId != 0 &&
                serverProcessId == guardServiceProcessId;
        }

        // NMH-001 zweiter Anlauf, live gemessen am 2026-08-29: der erste Fix
        // verglich den BILDPFAD der Gegenstelle und holte ihn ueber OpenProcess
        // mit PROCESS_QUERY_LIMITED_INFORMATION. Die Annahme war, diese kleinere
        // Zugriffsmaske genuege einem Standardbenutzer gegenueber einem
        // LocalSystem-Prozess. Sie genuegt nicht: ein Dienstprozess erbt die
        // Standard-DACL des SYSTEM-Tokens, und die gewaehrt nur SYSTEM und
        // Administratoren. Gemessen kam nicht etwa ein leerer Pfad zurueck -
        // schon OpenProcess scheiterte mit ERROR_ACCESS_DENIED (5). Der Host
        // laeuft immer im Nutzerkontext, weil Chrome ihn startet; die Pruefung
        // konnte also auf keiner Maschine gelingen, und der Companion-Herzschlag
        // kam nie zustande.
        //
        // Die Dienststeuerung beantwortet dieselbe Frage ohne Erhoehung:
        // SERVICE_QUERY_STATUS steht Authentifizierten Benutzern offen, und
        // QueryServiceStatusEx liefert die PID des Dienstprozesses. Verglichen
        // wird damit PID gegen PID statt Pfad gegen Pfad - dieselbe Aussage
        // (die Gegenstelle IST der installierte Guard), nur ueber einen Weg,
        // den der Nutzerkontext auch gehen darf.
        private static uint GetGuardServiceProcessId()
        {
            IntPtr manager = OpenSCManager(null, null, ScManagerConnect);
            if (manager == IntPtr.Zero)
            {
                return 0;
            }

            try
            {
                IntPtr service = OpenService(manager, GuardServiceName, ServiceQueryStatus);
                if (service == IntPtr.Zero)
                {
                    return 0;
                }

                try
                {
                    uint size = (uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(ServiceStatusProcess));
                    IntPtr buffer = System.Runtime.InteropServices.Marshal.AllocHGlobal((int)size);
                    try
                    {
                        uint needed;
                        if (!QueryServiceStatusEx(service, ScStatusProcessInfo, buffer, size, out needed))
                        {
                            return 0;
                        }

                        ServiceStatusProcess status = (ServiceStatusProcess)
                            System.Runtime.InteropServices.Marshal.PtrToStructure(buffer, typeof(ServiceStatusProcess));
                        return status.ProcessId;
                    }
                    finally
                    {
                        System.Runtime.InteropServices.Marshal.FreeHGlobal(buffer);
                    }
                }
                finally
                {
                    CloseServiceHandle(service);
                }
            }
            finally
            {
                CloseServiceHandle(manager);
            }
        }

        // Fail-closed: laesst sich die Gegenstelle nicht bestimmen, gilt sie als
        // fremd. Der Companion faellt dann ueber den fehlenden Herzschlag in die
        // Vollsperre - das ist die gewollte Richtung.
        private static bool IsTrustedGuardPipe(NamedPipeClientStream pipe)
        {
            try
            {
                uint serverProcessId;
                if (!GetNamedPipeServerProcessId(pipe.SafePipeHandle.DangerousGetHandle(), out serverProcessId) ||
                    serverProcessId == 0)
                {
                    LogFailure("Guard pipe rejected: server process id unavailable.");
                    return false;
                }

                uint guardServiceProcessId = GetGuardServiceProcessId();
                if (!IsTrustedGuardPipeServerProcess(serverProcessId, guardServiceProcessId))
                {
                    LogFailure("Guard pipe rejected: server pid " + serverProcessId +
                        " is not the guard service (" +
                        (guardServiceProcessId == 0 ? "service pid unavailable" : "service pid " + guardServiceProcessId) + ").");
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                LogFailure("Guard pipe identity check failed: " + ex.Message);
                return false;
            }
        }

        private static string ExchangeGuardUsage(string pipeMessage)
        {
            try
            {
                using (NamedPipeClientStream pipe = new NamedPipeClientStream(".", PipeName, PipeDirection.InOut))
                {
                    pipe.Connect(3000);
                    if (!IsTrustedGuardPipe(pipe))
                    {
                        return string.Empty;
                    }
                    using (StreamWriter writer = new StreamWriter(pipe, new UTF8Encoding(false), 1024, true))
                    using (StreamReader reader = new StreamReader(pipe, Encoding.UTF8, false, 1024, true))
                    {
                        writer.AutoFlush = true;
                        writer.WriteLine(pipeMessage);
                        return reader.ReadLine() ?? string.Empty;
                    }
                }
            }
            catch (Exception ex)
            {
                LogFailure("Guard usage exchange failed: " + ex.GetType().Name + ": " + Truncate(ex.Message, 200));
                return string.Empty;
            }
        }

        private static string ExchangeGuardLearn(string pipeMessage)
        {
            try
            {
                using (NamedPipeClientStream pipe = new NamedPipeClientStream(".", PipeName, PipeDirection.InOut))
                {
                    pipe.Connect(3000);
                    if (!IsTrustedGuardPipe(pipe))
                    {
                        return string.Empty;
                    }
                    using (StreamWriter writer = new StreamWriter(pipe, new UTF8Encoding(false), 1024, true))
                    using (StreamReader reader = new StreamReader(pipe, Encoding.UTF8, false, 1024, true))
                    {
                        writer.AutoFlush = true;
                        writer.WriteLine(pipeMessage);
                        return reader.ReadLine() ?? string.Empty;
                    }
                }
            }
            catch (Exception ex)
            {
                LogFailure("Guard learn exchange failed: " + ex.GetType().Name + ": " + Truncate(ex.Message, 200));
                return string.Empty;
            }
        }

        private static string ExchangeGuardCanary(string pipeMessage)
        {
            try
            {
                using (NamedPipeClientStream pipe = new NamedPipeClientStream(".", PipeName, PipeDirection.Out))
                {
                    pipe.Connect(3000);
                    if (!IsTrustedGuardPipe(pipe))
                    {
                        return string.Empty;
                    }
                    using (StreamWriter writer = new StreamWriter(pipe, new UTF8Encoding(false), 1024, true))
                    {
                        writer.AutoFlush = true;
                        writer.WriteLine(pipeMessage);
                        return "OK";
                    }
                }
            }
            catch (Exception ex)
            {
                LogFailure("Guard canary exchange failed: " + ex.GetType().Name + ": " + Truncate(ex.Message, 200));
                return string.Empty;
            }
        }

        private static bool ExchangeGuardHeartbeat(string browser, string version, out Dictionary<string, string> guardAreaModes)
        {
            guardAreaModes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            using (NamedPipeClientStream pipe = new NamedPipeClientStream(".", PipeName, PipeDirection.InOut))
            {
                pipe.Connect(3000);
                if (!IsTrustedGuardPipe(pipe))
                {
                    return false;
                }
                using (StreamWriter writer = new StreamWriter(pipe, new UTF8Encoding(false), 1024, true))
                using (StreamReader reader = new StreamReader(pipe, Encoding.UTF8, false, 1024, true))
                {
                    writer.AutoFlush = true;
                    writer.WriteLine(browser + "|" + version);
                    string guardResponse = reader.ReadLine() ?? string.Empty;
                    guardAreaModes = ParseGuardAreaModes(guardResponse);
                    return guardResponse.StartsWith("OK", StringComparison.Ordinal);
                }
            }
        }

        // Long-lived push mode behind {type:"subscribe"}: the process stays
        // alive on the Chrome native-messaging port and pushes a fresh rule
        // pack whenever the protection config or a local rules file changes,
        // so app-side saves reach open tabs in seconds instead of after the
        // background cache TTL. A reader thread watches stdin only for EOF
        // (Chrome closed the port) and exits the process; only this loop's
        // thread ever writes stdout after the initial response. Metadata-only
        // logging, never page content (privacy boundary unchanged).
        private static void RunSubscribePushLoop(string browser, string version)
        {
            System.Threading.AutoResetEvent changed = new System.Threading.AutoResetEvent(false);

            System.Threading.Thread stdinMonitor = new System.Threading.Thread(delegate ()
            {
                try
                {
                    Stream input = Console.OpenStandardInput();
                    byte[] buffer = new byte[4096];
                    while (true)
                    {
                        int read = input.Read(buffer, 0, buffer.Length);
                        if (read <= 0)
                        {
                            break;
                        }
                    }
                }
                catch
                {
                }
                Environment.Exit(0);
            });
            stdinMonitor.IsBackground = true;
            stdinMonitor.Start();

            List<FileSystemWatcher> watchers = new List<FileSystemWatcher>();
            try
            {
                // Primary watch target: the world-readable mirror (the data
                // dir itself is ACL-locked to admins, so a user-context watch
                // there fails). The config watch stays as best effort for
                // elevated hosts / legacy setups.
                string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Purestate");
                EnsureDataDirectoryIsNotReparsePoint(dataDir);
                string publicDir = Path.Combine(dataDir, "public");
                if (Directory.Exists(publicDir))
                {
                    try
                    {
                        FileSystemWatcher stateWatcher = new FileSystemWatcher(publicDir, "*.json");
                        stateWatcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.Size;
                        stateWatcher.Changed += delegate { changed.Set(); };
                        stateWatcher.Created += delegate { changed.Set(); };
                        stateWatcher.Renamed += delegate { changed.Set(); };
                        stateWatcher.EnableRaisingEvents = true;
                        watchers.Add(stateWatcher);
                    }
                    catch
                    {
                    }
                }

                if (Directory.Exists(dataDir))
                {
                    try
                    {
                        FileSystemWatcher configWatcher = new FileSystemWatcher(dataDir, "config.json");
                        configWatcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.Size;
                        configWatcher.Changed += delegate { changed.Set(); };
                        configWatcher.Created += delegate { changed.Set(); };
                        configWatcher.Renamed += delegate { changed.Set(); };
                        configWatcher.EnableRaisingEvents = true;
                        watchers.Add(configWatcher);
                    }
                    catch
                    {
                    }
                }

                string rulesDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules");
                string adultExemptionsPath = Path.Combine(rulesDir, "adult-learned-exemptions.txt");
                if (Directory.Exists(rulesDir))
                {
                    FileSystemWatcher rulesWatcher = new FileSystemWatcher(rulesDir, "*.txt");
                    rulesWatcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.Size;
                    rulesWatcher.Changed += delegate { changed.Set(); };
                    rulesWatcher.Created += delegate { changed.Set(); };
                    rulesWatcher.Renamed += delegate { changed.Set(); };
                    rulesWatcher.EnableRaisingEvents = true;
                    watchers.Add(rulesWatcher);
                }

                bool retryGuardExchange = false;
                while (true)
                {
                    int transitionWait = GetNextAdultExemptionTransitionWaitMilliseconds(
                        adultExemptionsPath, DateTime.UtcNow);
                    int waitMilliseconds = transitionWait;
                    if (retryGuardExchange && (waitMilliseconds < 0 || waitMilliseconds > SubscribeRetryMilliseconds))
                    {
                        waitMilliseconds = SubscribeRetryMilliseconds;
                    }
                    bool fileChanged = changed.WaitOne(waitMilliseconds < 0
                        ? System.Threading.Timeout.Infinite
                        : waitMilliseconds);
                    if (fileChanged)
                    {
                        // Debounce bursts (atomic config writes fire several
                        // events), then drain whatever queued so one save = one
                        // push. Reine Uhrkanten duerfen diese 750 ms nicht
                        // bekommen: sie gelten exakt ab ihrem Zeitstempel.
                        System.Threading.Thread.Sleep(750);
                        changed.WaitOne(0);
                    }

                    Dictionary<string, string> guardAreaModes;
                    bool ok = false;
                    try
                    {
                        ok = ExchangeGuardHeartbeat(browser, version, out guardAreaModes);
                    }
                    catch (Exception ex)
                    {
                        guardAreaModes = null;
                        LogFailure("Subscribe push skipped guard exchange: " + ex.GetType().Name);
                    }
                    retryGuardExchange = !ok;

                    try
                    {
                        WriteRuleResponse(ok, ok ? LoadBrowserRulePackJson(guardAreaModes) : DefaultRulePackJson());
                    }
                    catch
                    {
                        // stdout gone means Chrome closed the port; leave.
                        Environment.Exit(0);
                    }
                }
            }
            finally
            {
                foreach (FileSystemWatcher watcher in watchers)
                {
                    try { watcher.Dispose(); } catch { }
                }
            }
        }

        private static string Truncate(string value, int maxLength)
        {
            string text = value ?? string.Empty;
            return text.Length <= maxLength ? text : text.Substring(0, maxLength) + "...";
        }

        private static bool IsAllowedOrigin(string origin, string baseDir)
        {
            if (origin.Equals(AllowedOrigin, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            string devId = GetDevCompanionId(baseDir);
            return devId.Length > 0 &&
                origin.Equals("chrome-extension://" + devId + "/", StringComparison.OrdinalIgnoreCase);
        }

        // NMH-002: Der Nachrichtentyp wird EINMAL bestimmt und danach verzweigt.
        // Vorher suchte jeder Zweig sein eigenes Muster irgendwo in der
        // Nutzlast, und die Reihenfolge der Pruefungen war die Semantik: stand
        // in irgendeinem Feld ein rohes "type":"learn", gewann der Lernpfad,
        // weil er zuerst geprueft wurde. Der Host parst kein JSON, ein Sender
        // muss also gar kein gueltiges schicken.
        //
        // Kein Parser-Umbau: der Host reicht weiterhin nichts durch, was er
        // nicht selbst geprueft hat (Regel aus 0.62.33).
        //
        // Grenze, ehrlich benannt: es gilt das ERSTE Vorkommen. Wer ungueltiges
        // JSON senden darf, kann einen Typ weiterhin vorziehen, indem er ihn vor
        // das echte Feld setzt. Dafuer braucht er bereits die vertrauenswuerdige
        // Herkunft, und der Lernpfad verschaerft nur (er sperrt einen Host).
        private static string ReadMessageType(string json)
        {
            Match match = Regex.Match(json, "\\\"type\\\"\\s*:\\s*\\\"([a-z-]{1,16})\\\"", RegexOptions.IgnoreCase);
            return match.Success ? match.Groups[1].Value.ToLowerInvariant() : string.Empty;
        }

        private static string GetDevCompanionId(string baseDir)
        {
            // ENS-001: siehe NativeSupportEnforcement.cs - im ausgelieferten Bau
            // ist dieser Zweig nicht vorhanden, nicht nur ausgeschaltet. Sonst
            // genuegt eine Datei in Program Files, damit eine beliebige
            // Erweiterung als vertrauenswuerdige Herkunft durchgeht.
#if !PURESTATE_DEV
            return string.Empty;
#else
            try
            {
                string root = string.IsNullOrWhiteSpace(baseDir) ? AppDomain.CurrentDomain.BaseDirectory : baseDir;
                string path = Path.Combine(root, "dev-companion-id.txt");
                if (!File.Exists(path))
                {
                    return string.Empty;
                }

                string id = File.ReadAllText(path).Trim();
                return Regex.IsMatch(id, "^[a-p]{32}$") ? id : string.Empty;
            }
            catch
            {
                return string.Empty;
            }
#endif
        }

        // Mirrors the guard's service.log line format. Contains only heartbeat
        // metadata and error text - never page content or the raw native
        // payload (privacy boundary, see docs\THREAT-MODEL.md). Must never
        // throw and must never touch stdout (stdout carries the native
        // messaging protocol; a stray byte there corrupts the response).
        private static void LogFailure(string message)
        {
            try { Console.Error.WriteLine(DateTime.Now.ToString("s") + " " + message); } catch { }
            AppendCappedLogLine("native-host.log", message);
        }

        // Size-capped, never-throwing local log writer shared by the failure
        // log and the selector-canary log. Same privacy boundary as above.
        private static void RotateLogFile(string path)
        {
            try
            {
                string previous = path + ".1";
                if (File.Exists(previous))
                {
                    File.Delete(previous);
                }
                File.Move(path, previous);
            }
            catch
            {
                // Haelt ein anderer Host-Prozess die Datei gerade offen, wird
                // weiter angehaengt: eine zu grosse Datei ist besser als eine
                // verlorene Zeile.
            }
        }

        private static void AppendSharedLine(string path, string text)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(text);
            for (int attempt = 0; attempt < 5; attempt++)
            {
                try
                {
                    using (FileStream stream = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                    {
                        stream.Write(bytes, 0, bytes.Length);
                    }
                    return;
                }
                catch (IOException)
                {
                    System.Threading.Thread.Sleep(20);
                }
            }
        }

        // NMH-004, live gemessen am 2026-08-29: geschrieben wurde ausschliesslich
        // nach %ProgramData%\Purestate. Dieses Verzeichnis ist absichtlich nur
        // fuer SYSTEM und Administratoren beschreibbar - der Host laeuft aber
        // IMMER im Nutzerkontext, weil Chrome ihn startet. Jeder Schreibversuch
        // endete also in UnauthorizedAccessException, und der leere catch hat
        // ihn verschluckt. Wirkung: das Fehlerprotokoll des Hosts existierte im
        // Betrieb nie. Ausgerechnet die Zeile, die NMH-001 sofort gezeigt haette
        // ("Guard pipe rejected: ..."), war deshalb nicht zu sehen, obwohl das
        // Runbook bei T-10 ausdruecklich nach ihr fragt.
        //
        // Der gemeinsame Ordner bleibt der erste Versuch: laeuft der Host doch
        // erhoeht, gehoeren die Zeilen weiter dorthin, wo auch service.log
        // liegt. Scheitert er, weicht das Protokoll in das Profil des Nutzers
        // aus, das er sicher beschreiben darf.
        //
        // Bewusst in Kauf genommen: ein Protokoll im Nutzerprofil ist vom Nutzer
        // aenderbar. Es ist ein Diagnoseprotokoll, keine Schutzgrenze - es traegt
        // keine Entscheidung, und ein Protokoll, das gar nicht erst entsteht, ist
        // die schlechtere Wahl. Die Sicherheitsspur bleibt in security.log unter
        // %ProgramData%, geschrieben vom Dienst.
        private static void AppendCappedLogLine(string fileName, string message)
        {
            string line = DateTime.Now.ToString("s") + " " + SanitizeLogMessage(message);
            string sharedDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "Purestate");
            if (TryAppendCappedLogLine(sharedDir, fileName, line, true))
            {
                return;
            }

            string userDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Purestate");
            TryAppendCappedLogLine(userDir, fileName, line, false);
        }

        private static bool TryAppendCappedLogLine(string dataDir, string fileName, string line, bool checkReparsePoint)
        {
            try
            {
                Directory.CreateDirectory(dataDir);
                if (checkReparsePoint)
                {
                    EnsureDataDirectoryIsNotReparsePoint(dataDir);
                }
                string path = Path.Combine(dataDir, fileName);
                FileInfo info = new FileInfo(path);
                // NMH-003: Eine Generation bleibt als ".1" liegen, statt die
                // ganze Vorgeschichte zu verwerfen; geschrieben wird geteilt,
                // weil mehrere Browserprofile mehrere Host-Prozesse starten.
                if (info.Exists && info.Length > MaxLogBytes)
                {
                    RotateLogFile(path);
                }

                AppendSharedLine(path, line + Environment.NewLine);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private static string SanitizeLogMessage(string message)
        {
            string sanitized = (message ?? string.Empty)
                .Replace('\r', ' ')
                .Replace('\n', ' ')
                .Replace('\t', ' ')
                .Trim();
            if (sanitized.Length > MaxLogMessageChars)
            {
                sanitized = sanitized.Substring(0, MaxLogMessageChars);
            }
            return sanitized;
        }

        private static string ReadMessage()
        {
            Stream input = Console.OpenStandardInput();
            byte[] lengthBytes = ReadExact(input, 4);
            int length = BitConverter.ToInt32(lengthBytes, 0);
            if (length < 2 || length > 65536)
            {
                throw new InvalidDataException("Invalid native message length.");
            }
            return Encoding.UTF8.GetString(ReadExact(input, length));
        }

        private static byte[] ReadExact(Stream stream, int length)
        {
            byte[] result = new byte[length];
            int offset = 0;
            while (offset < length)
            {
                int read = stream.Read(result, offset, length - offset);
                if (read <= 0) throw new EndOfStreamException();
                offset += read;
            }
            return result;
        }

        private static void WriteResponse(bool ok)
        {
            byte[] payload = Encoding.UTF8.GetBytes(ok ? "{\"ok\":true}" : "{\"ok\":false}");
            WriteNativePayload(payload);
        }

        private static void WriteRuleResponse(bool ok, string rulePackJson)
        {
            string payloadText = "{\"ok\":" + (ok ? "true" : "false") + ",\"rules\":" + rulePackJson + "}";
            byte[] payload = Encoding.UTF8.GetBytes(payloadText);
            if (payload.Length > MaxNativeMessageBytes)
            {
                LogFailure("Rule pack exceeds Chrome native-message byte limit: " + payload.Length.ToString());
                payload = Encoding.UTF8.GetBytes("{\"ok\":false}");
            }
            WriteNativePayload(payload);
        }

        private static void WriteNativePayload(byte[] payload)
        {
            Stream output = Console.OpenStandardOutput();
            byte[] length = BitConverter.GetBytes(payload.Length);
            output.Write(length, 0, length.Length);
            output.Write(payload, 0, payload.Length);
            output.Flush();
        }

        private static string LoadBrowserRulePackJson()
        {
            return LoadBrowserRulePackJson(null);
        }

        private static string LoadBrowserRulePackJson(Dictionary<string, string> guardAreaModes)
        {
            Dictionary<string, List<string>> sections = EmptyRuleSections();
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "browser-companion-rules.txt");
            if (File.Exists(path))
            {
                string currentSection = string.Empty;
                foreach (string rawLine in File.ReadAllLines(path, Encoding.UTF8))
                {
                    string line = (rawLine ?? string.Empty).Trim();
                    if (line.Length == 0 || line.StartsWith("#", StringComparison.Ordinal))
                    {
                        continue;
                    }

                    Match section = Regex.Match(line, "^\\[(?<name>[a-z0-9.]+)\\]$", RegexOptions.IgnoreCase);
                    if (section.Success)
                    {
                        string name = section.Groups["name"].Value;
                        currentSection = sections.ContainsKey(name) ? name : string.Empty;
                        continue;
                    }

                    if (currentSection.Length == 0 || sections[currentSection].Count >= MaxRulesPerSection)
                    {
                        continue;
                    }

                    string term = NormalizeRuleTerm(line);
                    if (term.Length > 0 && !sections[currentSection].Contains(term))
                    {
                        sections[currentSection].Add(term);
                    }
                }
            }

            LoadPlainRuleFileIntoSection(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "gambling-search-terms.txt"), sections["gambling.searchTerms"]);
            LoadPlainRuleFileIntoSection(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "gambling-url-keywords.txt"), sections["gambling.urlKeywords"]);
            LoadHostRuleFileIntoSection(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "gambling-domains.txt"), sections["gambling.linkDomains"]);
            LoadHostRuleFileIntoSection(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "offshore-gambling-domains.txt"), sections["gambling.linkDomains"]);
            LoadHostRuleFileIntoSection(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "gambling-affiliate-domains.txt"), sections["gambling.linkDomains"]);
            LoadHostRuleFileIntoSection(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "custom-gambling-domains.txt"), sections["gambling.linkDomains"]);
            LoadPlainRuleFileIntoSection(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "shopping-search-terms.txt"), sections["shopping.searchTerms"]);

            // Dynamic host lists for the broad-permission companion modules:
            // the same rules files the policy layer uses, so a domain added to
            // a custom list reaches both layers at once. Missing files simply
            // leave the arrays empty.
            LoadHostRuleFileIntoSection(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "gambling-domains.txt"), sections["gambling.hostDomains"]);
            LoadHostRuleFileIntoSection(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "offshore-gambling-domains.txt"), sections["gambling.hostDomains"]);
            LoadHostRuleFileIntoSection(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "custom-gambling-domains.txt"), sections["gambling.hostDomains"]);
            LoadHostRuleFileIntoSection(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "custom-shopping-domains.txt"), sections["shopping.hostDomains"]);

            // Vom Guard gelernte Erwachsenen-Hosts (Task 4): eine vom Guard
            // geschriebene Datei in ProgramData, nicht in den App-eigenen
            // "rules"-Dateien. Fehlt sie oder ist sie kaputt, bleibt der
            // Abschnitt einfach leer - kein Wurf, kein weiterer Effekt.
            try
            {
                string learnedAdultDomainsPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Purestate", "learned-adult-domains.txt");
                LoadHostRuleFileIntoSection(learnedAdultDomainsPath, sections["adult.hostDomains"]);
            }
            catch
            {
            }

            // Freigegebene Fehltreffer der Erwachsenen-Erkennung. exemptHosts
            // ist bewusst unabhaengig vom gekappten Hostabschnitt; das 30-Tage-
            // Zeitfenster verhindert, dass alte Freigaben spaeter wiederaufleben.
            // Der ausdrueckliche Vertrag erlaubt hoechstens 500 gleichzeitig
            // nicht abgelaufene Freigaben. Das bleibt weit unter Chromes
            // 1-MiB-Native-Messaging-Grenze, selbst bei 253-Zeichen-Hosts.
            LoadTimedExemptionFileIntoSection(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "adult-learned-exemptions.txt"), sections["adult.exemptHosts"], DateTime.UtcNow, ReadClockAnchorUtc(), TimedExemptionLifetimeDays, TimedExemptionCapacity);

            // Freigegebene Fehltreffer der Gluecksspiel-Inhaltserkennung. Nur
            // bereits aktivierte Eintraege - sonst waere die 15-Minuten-Frist
            // wirkungslos, die verhindert, dass eine frische Freigabe die
            // laufende Sitzung rettet.
            //
            // GHX-001: Hier stand als Lebensdauer eine 0 (kein Ablauf) und als
            // Deckel MaxRulesPerSection, waehrend der Erwachsenen-Zwilling eine
            // Zeile darueber mit 30 Tagen und 500 arbeitet. Eine im Impuls
            // erteilte Gluecksspiel-Freigabe galt damit fuer immer. Jetzt
            // dieselben Grenzen fuer beide.
            LoadTimedExemptionFileIntoSection(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "gambling-heuristic-exemptions.txt"), sections["gambling.exemptHosts"], DateTime.UtcNow, ReadClockAnchorUtc(), TimedExemptionLifetimeDays, TimedExemptionCapacity);

            return BuildRulePackJson(sections, guardAreaModes);
        }

        private static Dictionary<string, List<string>> EmptyRuleSections()
        {
            Dictionary<string, List<string>> sections = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
            sections["bluesky.adultSearchTerms"] = new List<string>();
            sections["bluesky.adultHashtags"] = new List<string>();
            sections["bluesky.adultTextTerms"] = new List<string>();
            sections["bluesky.adultLinkDomains"] = new List<string>();
            sections["bluesky.safeContextTerms"] = new List<string>();
            sections["adult.hostDomains"] = new List<string>();
            sections["adult.exemptHosts"] = new List<string>();
            sections["gambling.searchTerms"] = new List<string>();
            sections["gambling.urlKeywords"] = new List<string>();
            sections["gambling.linkDomains"] = new List<string>();
            sections["gambling.hostDomains"] = new List<string>();
            sections["gambling.exemptHosts"] = new List<string>();
            sections["shopping.searchTerms"] = new List<string>();
            sections["shopping.hostDomains"] = new List<string>();
            return sections;
        }

        private static string DefaultRulePackJson()
        {
            return BuildRulePackJson(EmptyRuleSections());
        }

        private static string NormalizeRuleTerm(string value)
        {
            string term = (value ?? string.Empty).Trim().TrimStart('#').ToLowerInvariant();
            if (term.Length == 0 || term.Length > 64)
            {
                return string.Empty;
            }
            return Regex.IsMatch(term, "^[a-z0-9][a-z0-9+._ -]*$") ? term : string.Empty;
        }

        private static string NormalizeHostTerm(string value)
        {
            string host = (value ?? string.Empty).Trim().ToLowerInvariant();
            if (host.Length == 0 || host.Length > 253)
            {
                return string.Empty;
            }
            return LearnHostShape.IsMatch(host) ? host : string.Empty;
        }

        private static void LoadPlainRuleFileIntoSection(string path, List<string> target)
        {
            if (target == null || !File.Exists(path))
            {
                return;
            }

            foreach (string rawLine in File.ReadAllLines(path, Encoding.UTF8))
            {
                string line = (rawLine ?? string.Empty).Trim();
                if (line.Length == 0 || line.StartsWith("#", StringComparison.Ordinal))
                {
                    continue;
                }

                if (target.Count >= MaxRulesPerSection)
                {
                    return;
                }

                string term = NormalizeRuleTerm(line);
                if (term.Length > 0 && !target.Contains(term))
                {
                    target.Add(term);
                }
            }
        }

        private static void LoadHostRuleFileIntoSection(string path, List<string> target)
        {
            if (target == null || !File.Exists(path))
            {
                return;
            }

            HashSet<string> seen = new HashSet<string>(target, StringComparer.OrdinalIgnoreCase);
            foreach (string rawLine in File.ReadAllLines(path, Encoding.UTF8))
            {
                string line = (rawLine ?? string.Empty).Trim();
                if (line.Length == 0 || line.StartsWith("#", StringComparison.Ordinal))
                {
                    continue;
                }
                if (target.Count >= MaxRulesPerSection)
                {
                    return;
                }

                string host = NormalizeHostTerm(line);
                if (host.Length > 0 && seen.Add(host))
                {
                    target.Add(host);
                }
            }
        }

        private static bool TryParseTimedExemptionLine(string rawLine, out DateTime activatesAtUtc, out string host)
        {
            activatesAtUtc = DateTime.MinValue;
            host = string.Empty;
            string line = (rawLine ?? string.Empty).Trim();
            if (line.Length == 0 || line.StartsWith("#", StringComparison.Ordinal))
            {
                return false;
            }
            string[] parts = line.Split(new[] { '|' }, 2);
            DateTime activatesAt;
            if (parts.Length != 2 || !DateTime.TryParse(parts[0].Trim(), null,
                    System.Globalization.DateTimeStyles.RoundtripKind, out activatesAt))
            {
                return false;
            }
            host = NormalizeHostTerm(parts[1]);
            if (host.Length == 0)
            {
                return false;
            }
            activatesAtUtc = activatesAt.ToUniversalTime();
            return true;
        }

        private static DateTime TimedExemptionExpiryUtc(DateTime activatesAtUtc, int lifetimeDays)
        {
            if (lifetimeDays <= 0)
            {
                return DateTime.MaxValue;
            }
            DateTime latestSafe = DateTime.MaxValue.AddDays(-lifetimeDays);
            return activatesAtUtc > latestSafe ? DateTime.MaxValue : activatesAtUtc.AddDays(lifetimeDays);
        }

        // Der Subscribe-Prozess wartet nicht nur auf Datei-Aenderungen: eine
        // reine Uhrkante aendert ebenfalls den Rule Pack. -1 bedeutet, dass
        // keine kuenftige Aktivierungs-/Ablaufkante vorhanden ist. Laengere
        // Strecken werden auf WaitHandle's int-Bereich geklemmt und danach
        // neu berechnet; dadurch gibt es weder einen ueberlaufenden Timer noch
        // einen unzuverlaessigen langen MV3-Service-Worker-Timeout.
        internal static int GetNextAdultExemptionTransitionWaitMilliseconds(string path, DateTime nowUtc)
        {
            if (!File.Exists(path))
            {
                return -1;
            }
            nowUtc = nowUtc.ToUniversalTime();
            DateTime nextUtc = DateTime.MaxValue;
            int accepted = 0;
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string rawLine in File.ReadAllLines(path, Encoding.UTF8))
            {
                DateTime activatesAtUtc;
                string host;
                if (!TryParseTimedExemptionLine(rawLine, out activatesAtUtc, out host))
                {
                    continue;
                }
                DateTime expiresAtUtc = TimedExemptionExpiryUtc(activatesAtUtc, TimedExemptionLifetimeDays);
                if (expiresAtUtc <= nowUtc || !seen.Add(host))
                {
                    continue;
                }
                if (accepted >= TimedExemptionCapacity)
                {
                    break;
                }
                accepted++;
                DateTime transitionUtc = activatesAtUtc > nowUtc ? activatesAtUtc : expiresAtUtc;
                if (transitionUtc > nowUtc && transitionUtc < nextUtc)
                {
                    nextUtc = transitionUtc;
                }
            }
            if (nextUtc == DateTime.MaxValue)
            {
                return -1;
            }
            double milliseconds = Math.Ceiling((nextUtc - nowUtc).TotalMilliseconds);
            return milliseconds >= int.MaxValue ? int.MaxValue : Math.Max(0, (int)milliseconds);
        }

        // Ausnahmedatei mit Zeitstempel: "<ISO-8601-UTC>|<hostname>". Ein
        // Eintrag, dessen Aktivierung noch nicht erreicht ist, gehoert NICHT
        // ins Pack - sonst waere die 15-Minuten-Verzoegerung wirkungslos, die
        // verhindert, dass eine frische Freigabe die laufende Sitzung rettet.
        // LoadPlainRuleFileIntoSection kann das nicht: es wuerde die ganze
        // Zeile inklusive Zeitstempel als Hostnamen normalisieren.
        // Zwei Uhren, zwei Regeln (Befund CLK-004): der Regelpaketbau ist der
        // ZWEITE Auswertungspfad derselben Freigabefristen - der erste ist die
        // hosts-Datei (CLK-001). Wirksam wird eine Freigabe nach der FRUEHEREN
        // der beiden Uhren, abgelaufen ist sie nach der SPAETEREN. Gesetzt
        // werden die Zeitpunkte mit der vertrauenswuerdigen Uhr
        // (NativeSupportDomains.cs:745, 779); ausgewertet wurden sie hier bisher
        // roh, womit die 15-Minuten-Frist auf BEIDEN Konsumpfaden umgehbar war.
        internal static void LoadTimedExemptionFileIntoSection(string path, List<string> target, DateTime systemUtc, DateTime anchorUtc, int lifetimeDays, int maximumRules)
        {
            if (target == null || !File.Exists(path))
            {
                return;
            }

            DateTime expiryNowUtc = anchorUtc > systemUtc ? anchorUtc : systemUtc;
            DateTime activationNowUtc = anchorUtc < systemUtc ? anchorUtc : systemUtc;

            HashSet<string> seen = new HashSet<string>(target, StringComparer.OrdinalIgnoreCase);
            int accepted = target.Count;
            foreach (string rawLine in File.ReadAllLines(path, Encoding.UTF8))
            {
                DateTime activatesAtUtc;
                string host;
                if (!TryParseTimedExemptionLine(rawLine, out activatesAtUtc, out host))
                {
                    continue;
                }
                DateTime expiresAtUtc = TimedExemptionExpiryUtc(activatesAtUtc, lifetimeDays);
                if (expiresAtUtc <= expiryNowUtc || !seen.Add(host))
                {
                    continue;
                }
                if (accepted >= maximumRules)
                {
                    return;
                }
                accepted++;
                if (activatesAtUtc <= activationNowUtc)
                {
                    target.Add(host);
                }
            }
        }

        private static string BuildRulePackJson(Dictionary<string, List<string>> sections)
        {
            return BuildRulePackJson(sections, null);
        }

        private static string BuildRulePackJson(Dictionary<string, List<string>> sections, Dictionary<string, string> guardAreaModes)
        {
            Dictionary<string, bool> siteProtection = LoadSiteProtectionSettings();
            Dictionary<string, string> areas = LoadProtectionAreaModes();
            ApplyProtectionAreaModeOverrides(areas, guardAreaModes);
            StringBuilder builder = new StringBuilder();
            builder.Append("{\"version\":2,\"areas\":{");
            builder.Append("\"adult-content\":{\"enabled\":").Append(areas["adult-content"] == "strict" ? "true" : "false").Append(",\"mode\":\"").Append(areas["adult-content"]).Append("\"},");
            builder.Append("\"gambling\":{\"enabled\":").Append(areas["gambling"] == "strict" ? "true" : "false").Append(",\"mode\":\"").Append(areas["gambling"]).Append("\"},");
            builder.Append("\"shopping\":{\"enabled\":").Append(areas["shopping"] == "gentle" ? "true" : "false").Append(",\"mode\":\"").Append(areas["shopping"]).Append("\"},");
            builder.Append("\"social-media\":{\"enabled\":").Append(areas["social-media"] == "gentle" ? "true" : "false").Append(",\"mode\":\"").Append(areas["social-media"]).Append("\"}");
            builder.Append("},\"siteProtection\":{");
            for (int index = 0; index < SiteProtectionFields.Length; index++)
            {
                if (index > 0)
                {
                    builder.Append(",");
                }
                string site = SiteProtectionFields[index][0];
                bool enabled = !siteProtection.ContainsKey(site) || siteProtection[site];
                builder.Append("\"").Append(site).Append("\":").Append(enabled ? "true" : "false");
            }
            builder.Append("},\"adult\":{\"hostDomains\":");
            AppendJsonArray(builder, sections["adult.hostDomains"]);
            builder.Append(",\"exemptHosts\":");
            AppendJsonArray(builder, sections["adult.exemptHosts"]);
            builder.Append("},\"bluesky\":{");
            builder.Append("\"adultSearchTerms\":");
            AppendJsonArray(builder, sections["bluesky.adultSearchTerms"]);
            builder.Append(",\"adultHashtags\":");
            AppendJsonArray(builder, sections["bluesky.adultHashtags"]);
            builder.Append(",\"adultTextTerms\":");
            AppendJsonArray(builder, sections["bluesky.adultTextTerms"]);
            builder.Append(",\"adultLinkDomains\":");
            AppendJsonArray(builder, sections["bluesky.adultLinkDomains"]);
            builder.Append(",\"safeContextTerms\":");
            AppendJsonArray(builder, sections["bluesky.safeContextTerms"]);
            builder.Append("},\"gambling\":{");
            builder.Append("\"searchTerms\":");
            AppendJsonArray(builder, sections["gambling.searchTerms"]);
            builder.Append(",\"urlKeywords\":");
            AppendJsonArray(builder, sections["gambling.urlKeywords"]);
            builder.Append(",\"linkDomains\":");
            AppendJsonArray(builder, sections["gambling.linkDomains"]);
            builder.Append(",\"hostDomains\":");
            AppendJsonArray(builder, sections["gambling.hostDomains"]);
            builder.Append(",\"exemptHosts\":");
            AppendJsonArray(builder, sections["gambling.exemptHosts"]);
            builder.Append("},\"shopping\":{");
            builder.Append("\"searchTerms\":");
            AppendJsonArray(builder, sections["shopping.searchTerms"]);
            builder.Append(",\"hostDomains\":");
            AppendJsonArray(builder, sections["shopping.hostDomains"]);
            ShoppingRuleSettings shopping = LoadShoppingSettings();
            builder.Append(",\"checkoutDelayEnabled\":").Append(shopping.CheckoutDelayEnabled ? "true" : "false");
            builder.Append(",\"stimulusDampingEnabled\":").Append(shopping.StimulusDampingEnabled ? "true" : "false");
            builder.Append(",\"dealSearchBlockEnabled\":").Append(shopping.DealSearchBlockEnabled ? "true" : "false");
            builder.Append(",\"curfewEnabled\":").Append(shopping.CurfewEnabled ? "true" : "false");
            builder.Append(",\"curfewStart\":\"").Append(EscapeJson(shopping.CurfewStart)).Append("\"");
            builder.Append(",\"curfewEnd\":\"").Append(EscapeJson(shopping.CurfewEnd)).Append("\"");
            builder.Append(",\"delayMinutes\":").Append(shopping.DelayMinutes.ToString());
            builder.Append(",\"dailyLimitEnabled\":").Append(shopping.DailyLimitEnabled ? "true" : "false");
            builder.Append(",\"dailyLimitMinutes\":").Append(shopping.DailyLimitMinutes.ToString());
            builder.Append(",\"monthlyOrderLimitEnabled\":").Append(shopping.MonthlyOrderLimitEnabled ? "true" : "false");
            builder.Append(",\"monthlyOrderLimit\":").Append(shopping.MonthlyOrderLimit.ToString());
            builder.Append(",\"monthlyBudgetEnabled\":").Append(shopping.MonthlyBudgetEnabled ? "true" : "false");
            builder.Append(",\"monthlyBudgetEuro\":").Append(shopping.MonthlyBudgetEuro.ToString());
            builder.Append("},\"gamblingLimits\":{");
            GamblingLimitSettings gamblingLimits = LoadGamblingLimitSettings();
            builder.Append("\"dailyLimitEnabled\":").Append(gamblingLimits.DailyLimitEnabled ? "true" : "false");
            builder.Append(",\"dailyLimitMinutes\":").Append(gamblingLimits.DailyLimitMinutes.ToString());
            builder.Append("},\"socialMediaLimits\":{");
            SocialMediaRuleSettings socialMedia = LoadSocialMediaSettings();
            builder.Append("\"budgetEnabled\":").Append(socialMedia.BudgetEnabled ? "true" : "false");
            builder.Append(",\"budgetMinutes\":").Append(socialMedia.BudgetMinutes.ToString());
            builder.Append(",\"platformLimits\":{");
            bool firstLimit = true;
            foreach (KeyValuePair<string, int> limit in socialMedia.PlatformLimits)
            {
                if (!firstLimit)
                {
                    builder.Append(",");
                }
                firstLimit = false;
                builder.Append("\"").Append(EscapeJson(limit.Key)).Append("\":").Append(limit.Value.ToString());
            }
            builder.Append("},\"blockedPlatforms\":");
            AppendJsonArray(builder, socialMedia.BlockedPlatforms);
            builder.Append(",\"feedBlockedPlatforms\":");
            AppendJsonArray(builder, socialMedia.FeedBlockedPlatforms);
            builder.Append(",\"curfewEnabled\":").Append(socialMedia.CurfewEnabled ? "true" : "false");
            builder.Append(",\"curfewStart\":\"").Append(EscapeJson(socialMedia.CurfewStart)).Append("\"");
            builder.Append(",\"curfewEnd\":\"").Append(EscapeJson(socialMedia.CurfewEnd)).Append("\"");
            builder.Append(",\"reflectionEnabled\":").Append(socialMedia.ReflectionEnabled ? "true" : "false");
            builder.Append(",\"feedDampingEnabled\":").Append(socialMedia.FeedDampingEnabled ? "true" : "false");
            builder.Append(",\"feedDampingScrolls\":").Append(socialMedia.FeedDampingScrolls.ToString());
            builder.Append("}}");
            return builder.ToString();
        }

        private static Dictionary<string, string> ParseGuardAreaModes(string response)
        {
            Dictionary<string, string> result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (Match match in Regex.Matches(response ?? string.Empty, "(adult-content|gambling)=(strict|off)", RegexOptions.IgnoreCase))
            {
                result[match.Groups[1].Value.ToLowerInvariant()] = match.Groups[2].Value.ToLowerInvariant();
            }
            return result;
        }

        private static void ApplyProtectionAreaModeOverrides(Dictionary<string, string> areas, Dictionary<string, string> overrides)
        {
            if (areas == null || overrides == null)
            {
                return;
            }

            foreach (string key in new[] { "adult-content", "gambling" })
            {
                string mode;
                if (overrides.TryGetValue(key, out mode) && (mode == "strict" || mode == "off"))
                {
                    areas[key] = mode;
                }
            }
        }

        private static Dictionary<string, string> LoadProtectionAreaModes()
        {
            Dictionary<string, string> result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            result["adult-content"] = "strict";
            result["gambling"] = "off";
            result["shopping"] = "off";
            result["social-media"] = "off";

            try
            {
                string json = ReadRuleSourceJson();
                if (json.Length == 0)
                {
                    return result;
                }

                bool adultEnabled = ReadConfigBool(json, "AdultContentProtectionEnabled", true);
                bool gamblingEnabled = ReadConfigBool(json, "GamblingSupportEnabled", false) || ReadConfigBool(json, "GamblingProtectionEnabled", false);
                bool shoppingEnabled = ReadConfigBool(json, "ShoppingProtectionEnabled", false);
                bool socialMediaEnabled = ReadConfigBool(json, "SocialMediaProtectionEnabled", false);
                result["adult-content"] = adultEnabled ? "strict" : "off";
                result["gambling"] = gamblingEnabled ? "strict" : "off";
                result["shopping"] = shoppingEnabled ? "gentle" : "off";
                result["social-media"] = socialMediaEnabled ? "gentle" : "off";
            }
            catch (UnsafeDataDirectoryException)
            {
                throw;
            }
            catch
            {
            }

            return result;
        }

        private static Dictionary<string, bool> LoadSiteProtectionSettings()
        {
            Dictionary<string, bool> result = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
            foreach (string[] field in SiteProtectionFields)
            {
                result[field[0]] = true;
            }

            try
            {
                string json = ReadRuleSourceJson();
                if (json.Length == 0)
                {
                    return result;
                }

                result = SiteProtectionFromJson(json);
            }
            catch (UnsafeDataDirectoryException)
            {
                throw;
            }
            catch
            {
            }

            return result;
        }

        // Feinfilter wirken nur bei eingeschaltetem Bereich Erwachseneninhalte.
        // Fehlt der Bereichsschluessel, gilt er als an (fail-closed).
        internal static Dictionary<string, bool> SiteProtectionFromJson(string json)
        {
            Dictionary<string, bool> result = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
            bool adultEnabled = ReadConfigBool(json, "AdultContentProtectionEnabled", true);
            foreach (string[] field in SiteProtectionFields)
            {
                result[field[0]] = adultEnabled && ReadConfigBool(json, field[1], true);
            }
            return result;
        }

        // config.json is readable by Administrators+SYSTEM only, but Chrome
        // starts this host as the signed-in user. The app therefore mirrors
        // the non-sensitive rule fields into a world-readable state file; it
        // is the primary source here, with the raw config as fallback for
        // installations that predate the mirror.
        private static string CompanionRuleStatePath()
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "Purestate", "public", "companion-rule-state.json");
        }

        // Die vertrauenswuerdige Uhr steht in config.json, und die darf dieser
        // Prozess nicht lesen (er laeuft im Nutzerkonto, NHR-001). Deshalb
        // spiegeln beide Schreiber den Anker in die oeffentlich lesbare
        // companion-rule-state.json - ein Zeitstempel ohne Frist und ohne
        // Geheimnis, anders als die Werte, die dort ausdruecklich nicht
        // hingehoeren (Passwort, HMAC, Sperrzeiten).
        //
        // Fehlt das Feld (Installation von vor dieser Version), bleibt es beim
        // bisherigen Verhalten: dann ist der Anker die Systemuhr.
        internal static DateTime ReadClockAnchorUtc()
        {
            try
            {
                Match match = Regex.Match(ReadRuleSourceJson() ?? string.Empty,
                    "\"ClockAnchorUtc\"\\s*:\\s*\"([^\"]+)\"");
                DateTime parsed;
                if (match.Success && DateTime.TryParse(match.Groups[1].Value, null,
                    System.Globalization.DateTimeStyles.RoundtripKind, out parsed))
                {
                    return parsed.ToUniversalTime();
                }
            }
            catch
            {
            }
            return DateTime.UtcNow;
        }

        private static void EnsureDataDirectoryIsNotReparsePoint(string path)
        {
            if (!Directory.Exists(path))
            {
                return;
            }
            FileAttributes attributes = File.GetAttributes(path);
            if ((attributes & FileAttributes.ReparsePoint) != 0)
            {
                throw new UnsafeDataDirectoryException();
            }
        }

        private static string ReadRuleSourceJson()
        {
            string dataDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "Purestate");
            EnsureDataDirectoryIsNotReparsePoint(dataDir);
            try
            {
                string statePath = CompanionRuleStatePath();
                if (File.Exists(statePath))
                {
                    return File.ReadAllText(statePath, Encoding.UTF8);
                }
            }
            catch
            {
            }

            try
            {
                string configPath = Path.Combine(dataDir, "config.json");
                if (File.Exists(configPath))
                {
                    return File.ReadAllText(configPath, Encoding.UTF8);
                }
            }
            catch
            {
            }

            return string.Empty;
        }

        private sealed class ShoppingRuleSettings
        {
            public bool CheckoutDelayEnabled = true;
            public bool StimulusDampingEnabled = true;
            public bool DealSearchBlockEnabled = true;
            public bool CurfewEnabled = true;
            public string CurfewStart = "22:00";
            public string CurfewEnd = "06:00";
            public int DelayMinutes = 10;
            public bool DailyLimitEnabled = true;
            public int DailyLimitMinutes = 30;
            public bool MonthlyOrderLimitEnabled = true;
            public int MonthlyOrderLimit = 10;
            public bool MonthlyBudgetEnabled = false;
            public int MonthlyBudgetEuro = 200;
        }

        private sealed class GamblingLimitSettings
        {
            public bool DailyLimitEnabled = true;
            public int DailyLimitMinutes = 15;
        }

        private static int ClampInt(int value, int min, int max, int fallback)
        {
            return (value >= min && value <= max) ? value : fallback;
        }

        private static ShoppingRuleSettings LoadShoppingSettings()
        {
            ShoppingRuleSettings settings = new ShoppingRuleSettings();
            try
            {
                string json = ReadRuleSourceJson();
                if (json.Length == 0)
                {
                    return settings;
                }

                settings.CheckoutDelayEnabled = ReadConfigBool(json, "ShoppingCheckoutDelayEnabled", true);
                settings.StimulusDampingEnabled = ReadConfigBool(json, "ShoppingStimulusDampingEnabled", true);
                settings.DealSearchBlockEnabled = ReadConfigBool(json, "ShoppingDealSearchBlockEnabled", true);
                settings.CurfewEnabled = ReadConfigBool(json, "ShoppingCurfewEnabled", true);
                settings.CurfewStart = ReadConfigTime(json, "ShoppingCurfewStart", "22:00");
                settings.CurfewEnd = ReadConfigTime(json, "ShoppingCurfewEnd", "06:00");
                settings.DelayMinutes = ReadConfigInt(json, "ShoppingDelayDefaultMinutes", 10);
                if (settings.DelayMinutes != 2 && settings.DelayMinutes != 5 && settings.DelayMinutes != 10 && settings.DelayMinutes != 15)
                {
                    settings.DelayMinutes = 10;
                }
                settings.DailyLimitEnabled = ReadConfigBool(json, "ShoppingDailyLimitEnabled", true);
                settings.DailyLimitMinutes = ClampInt(ReadConfigInt(json, "ShoppingDailyLimitMinutes", 30), 5, 240, 30);
                settings.MonthlyOrderLimitEnabled = ReadConfigBool(json, "ShoppingMonthlyOrderLimitEnabled", true);
                settings.MonthlyOrderLimit = ClampInt(ReadConfigInt(json, "ShoppingMonthlyOrderLimit", 10), 1, 99, 10);
                settings.MonthlyBudgetEnabled = ReadConfigBool(json, "ShoppingMonthlyBudgetEnabled", false);
                settings.MonthlyBudgetEuro = ClampInt(ReadConfigInt(json, "ShoppingMonthlyBudgetEuro", 200), 1, 99999, 200);
            }
            catch (UnsafeDataDirectoryException)
            {
                throw;
            }
            catch
            {
            }

            return settings;
        }

        private static GamblingLimitSettings LoadGamblingLimitSettings()
        {
            GamblingLimitSettings settings = new GamblingLimitSettings();
            try
            {
                string json = ReadRuleSourceJson();
                if (json.Length == 0)
                {
                    return settings;
                }

                settings.DailyLimitEnabled = ReadConfigBool(json, "GamblingDailyLimitEnabled", true);
                settings.DailyLimitMinutes = ClampInt(ReadConfigInt(json, "GamblingDailyLimitMinutes", 15), 5, 240, 15);
            }
            catch (UnsafeDataDirectoryException)
            {
                throw;
            }
            catch
            {
            }

            return settings;
        }

        private static readonly string[] SocialMediaPlatformIds = new[]
        {
            "x", "instagram", "tiktok", "pinterest", "tumblr", "bluesky", "reddit", "youtube", "streaming"
        };

        private sealed class SocialMediaRuleSettings
        {
            public bool BudgetEnabled = false;
            public int BudgetMinutes = 60;
            public Dictionary<string, int> PlatformLimits = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            public List<string> BlockedPlatforms = new List<string>();
            public List<string> FeedBlockedPlatforms = new List<string>();
            public bool CurfewEnabled = false;
            public string CurfewStart = "22:00";
            public string CurfewEnd = "06:00";
            public bool ReflectionEnabled = true;
            public bool FeedDampingEnabled = true;
            public int FeedDampingScrolls = 50;
        }

        private static bool IsKnownSocialMediaPlatform(string id)
        {
            foreach (string platform in SocialMediaPlatformIds)
            {
                if (string.Equals(platform, id, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        private static SocialMediaRuleSettings LoadSocialMediaSettings()
        {
            SocialMediaRuleSettings settings = new SocialMediaRuleSettings();
            try
            {
                string json = ReadRuleSourceJson();
                if (json.Length == 0)
                {
                    return settings;
                }

                settings.BudgetEnabled = ReadConfigBool(json, "SocialMediaDailyBudgetEnabled", false);
                settings.BudgetMinutes = ClampInt(ReadConfigInt(json, "SocialMediaDailyBudgetMinutes", 60), 5, 480, 60);
                settings.CurfewEnabled = ReadConfigBool(json, "SocialMediaCurfewEnabled", false);
                settings.CurfewStart = ReadConfigTime(json, "SocialMediaCurfewStart", "22:00");
                settings.CurfewEnd = ReadConfigTime(json, "SocialMediaCurfewEnd", "06:00");
                settings.ReflectionEnabled = ReadConfigBool(json, "SocialMediaReflectionEnabled", true);
                settings.FeedDampingEnabled = ReadConfigBool(json, "SocialMediaFeedDampingEnabled", true);
                settings.FeedDampingScrolls = ClampInt(ReadConfigInt(json, "SocialMediaFeedDampingScrolls", 50), 5, 500, 50);

                // CSV "platform=minutes,...": mirrors the app-side normalizer -
                // unknown platforms and out-of-range minutes are dropped, valid
                // values above an active budget are capped to it.
                foreach (string part in ReadConfigString(json, "SocialMediaPlatformLimits", string.Empty).Split(','))
                {
                    string[] pair = part.Split('=');
                    int minutes;
                    if (pair.Length != 2)
                    {
                        continue;
                    }
                    string platform = pair[0].Trim().ToLowerInvariant();
                    if (!IsKnownSocialMediaPlatform(platform) ||
                        !int.TryParse(pair[1].Trim(), out minutes) ||
                        minutes < 5 || minutes > 480 ||
                        settings.PlatformLimits.ContainsKey(platform))
                    {
                        continue;
                    }
                    // Streaming fuehrt ein eigenes Budget und bleibt davon unberuehrt
                    // (Spiegel von Support.IsSocialMediaOwnBudgetPlatform).
                    if (settings.BudgetEnabled && minutes > settings.BudgetMinutes && platform != "streaming")
                    {
                        minutes = settings.BudgetMinutes;
                    }
                    settings.PlatformLimits[platform] = minutes;
                }

                foreach (string part in ReadConfigString(json, "SocialMediaBlockedPlatforms", string.Empty).Split(','))
                {
                    string platform = part.Trim().ToLowerInvariant();
                    if (IsKnownSocialMediaPlatform(platform) && !settings.BlockedPlatforms.Contains(platform))
                    {
                        settings.BlockedPlatforms.Add(platform);
                    }
                }

                // Selective feed block: a fully blocked platform never stays
                // in the feed list - the full block wins.
                foreach (string part in ReadConfigString(json, "SocialMediaFeedBlockedPlatforms", string.Empty).Split(','))
                {
                    string platform = part.Trim().ToLowerInvariant();
                    if (IsKnownSocialMediaPlatform(platform) &&
                        !settings.BlockedPlatforms.Contains(platform) &&
                        !settings.FeedBlockedPlatforms.Contains(platform))
                    {
                        settings.FeedBlockedPlatforms.Add(platform);
                    }
                }
            }
            catch (UnsafeDataDirectoryException)
            {
                throw;
            }
            catch
            {
            }

            return settings;
        }

        private static string ReadConfigString(string json, string name, string fallback)
        {
            Match match = Regex.Match(json ?? string.Empty, "\\\"" + Regex.Escape(name) + "\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"");
            return match.Success ? match.Groups[1].Value : fallback;
        }

        private static string ReadConfigTime(string json, string name, string fallback)
        {
            Match match = Regex.Match(json ?? string.Empty, "\\\"" + Regex.Escape(name) + "\\\"\\s*:\\s*\\\"(\\d{1,2}:\\d{2})\\\"");
            return match.Success ? match.Groups[1].Value : fallback;
        }

        private static int ReadConfigInt(string json, string name, int fallback)
        {
            Match match = Regex.Match(json ?? string.Empty, "\\\"" + Regex.Escape(name) + "\\\"\\s*:\\s*(\\d{1,6})");
            int parsed;
            return match.Success && int.TryParse(match.Groups[1].Value, out parsed) ? parsed : fallback;
        }

        private static bool ReadConfigBool(string json, string name, bool fallback)
        {
            Match match = Regex.Match(json ?? string.Empty, "\\\"" + Regex.Escape(name) + "\\\"\\s*:\\s*(true|false)", RegexOptions.IgnoreCase);
            return match.Success ? bool.Parse(match.Groups[1].Value) : fallback;
        }

        private static void AppendJsonArray(StringBuilder builder, List<string> values)
        {
            builder.Append("[");
            for (int index = 0; index < values.Count; index++)
            {
                if (index > 0)
                {
                    builder.Append(",");
                }
                builder.Append("\"").Append(EscapeJson(values[index])).Append("\"");
            }
            builder.Append("]");
        }

        private static string EscapeJson(string value)
        {
            return (value ?? string.Empty).Replace("\\", "\\\\").Replace("\"", "\\\"");
        }
    }
}
