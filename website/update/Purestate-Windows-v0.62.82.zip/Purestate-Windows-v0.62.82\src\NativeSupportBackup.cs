using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Purestate.Native
{
    internal static partial class Support
    {
        public static void ExportBackup(string backupPath)
        {
            AppConfig config = LoadConfig();
            string text = BuildBackupText(config, ReadCustomDomains(), ReadAllowDomains(), ReadCustomGamblingDomains(), ReadCustomShoppingDomains(), ReadVideoGameTargets(), ReadVideoGameExemptions());
            File.WriteAllText(backupPath, text, Encoding.UTF8);
            WriteActivityLog("Backup exported.");
        }

        public static string BuildBackupText(
            AppConfig config,
            string[] customDomains,
            string[] allowDomains,
            string[] customGamblingDomains,
            string[] customShoppingDomains)
        {
            return BuildBackupText(config, customDomains, allowDomains, customGamblingDomains, customShoppingDomains, null, null);
        }

        public static string BuildBackupText(
            AppConfig config,
            string[] customDomains,
            string[] allowDomains,
            string[] customGamblingDomains,
            string[] customShoppingDomains,
            List<VideoGameTarget> videoGameTargets)
        {
            return BuildBackupText(config, customDomains, allowDomains, customGamblingDomains, customShoppingDomains, videoGameTargets, null);
        }

        public static string BuildBackupText(
            AppConfig config,
            string[] customDomains,
            string[] allowDomains,
            string[] customGamblingDomains,
            string[] customShoppingDomains,
            List<VideoGameTarget> videoGameTargets,
            List<VideoGameExemption> videoGameExemptions)
        {
            if (config == null)
            {
                config = new AppConfig();
            }

            StringBuilder builder = new StringBuilder();
            builder.AppendLine("PurestateBackup=1");
            builder.AppendLine("CreatedAt=" + DateTime.Now.ToString("s"));
            builder.AppendLine("AppVersion=" + AppVersion);
            builder.AppendLine("ProtectionEnabled=" + ToJsonBool(config.ProtectionEnabled));
            builder.AppendLine("HostsEnabled=" + ToJsonBool(config.HostsEnabled));
            builder.AppendLine("FamilyDnsEnabled=" + ToJsonBool(config.FamilyDnsEnabled));
            builder.AppendLine("DnsProfile=" + NormalizeDnsProfile(config.DnsProfile));
            builder.AppendLine("BypassBlockingEnabled=" + ToJsonBool(config.BypassBlockingEnabled));
            builder.AppendLine("UnsupportedBrowserBlockingEnabled=" + ToJsonBool(config.UnsupportedBrowserBlockingEnabled));
            builder.AppendLine("TamperProtectionEnabled=" + ToJsonBool(config.TamperProtectionEnabled));
            builder.AppendLine("YouTubeRestrictEnabled=" + ToJsonBool(config.YouTubeRestrictEnabled));
            builder.AppendLine("AdultHostsFollowArea=" + ToJsonBool(config.AdultHostsFollowArea));
            builder.AppendLine("SiteRedditEnabled=" + ToJsonBool(config.SiteRedditEnabled));
            builder.AppendLine("SiteXEnabled=" + ToJsonBool(config.SiteXEnabled));
            builder.AppendLine("SiteBlueskyEnabled=" + ToJsonBool(config.SiteBlueskyEnabled));
            builder.AppendLine("SiteTumblrEnabled=" + ToJsonBool(config.SiteTumblrEnabled));
            builder.AppendLine("SiteDeviantArtEnabled=" + ToJsonBool(config.SiteDeviantArtEnabled));
            builder.AppendLine("SitePixivEnabled=" + ToJsonBool(config.SitePixivEnabled));
            builder.AppendLine("SiteNewgroundsEnabled=" + ToJsonBool(config.SiteNewgroundsEnabled));
            builder.AppendLine("SiteImgurEnabled=" + ToJsonBool(config.SiteImgurEnabled));
            builder.AppendLine("SiteInstagramEnabled=" + ToJsonBool(config.SiteInstagramEnabled));
            builder.AppendLine("SiteTikTokEnabled=" + ToJsonBool(config.SiteTikTokEnabled));
            builder.AppendLine("SitePinterestEnabled=" + ToJsonBool(config.SitePinterestEnabled));
            builder.AppendLine("AdultContentProtectionEnabled=" + ToJsonBool(config.AdultContentProtectionEnabled));
            builder.AppendLine("AdultContentProtectionMode=" + NormalizeProtectionAreaMode(config.AdultContentProtectionMode, "strict"));
            builder.AppendLine("GamblingProtectionEnabled=" + ToJsonBool(config.GamblingProtectionEnabled || config.GamblingSupportEnabled));
            builder.AppendLine("GamblingProtectionMode=" + ((config.GamblingProtectionEnabled || config.GamblingSupportEnabled) ? "strict" : "off"));
            builder.AppendLine("ProtectionAreaRulePackVersion=" + (string.IsNullOrWhiteSpace(config.ProtectionAreaRulePackVersion) ? "1" : config.ProtectionAreaRulePackVersion.Trim()));
            builder.AppendLine("GamblingSupportEnabled=" + ToJsonBool(config.GamblingSupportEnabled));
            builder.AppendLine("GamblingSupportMode=" + NormalizeImpulseAreaMode(config.GamblingSupportMode, config.GamblingSupportEnabled ? "gentle" : "off"));
            builder.AppendLine("ShoppingProtectionEnabled=" + ToJsonBool(config.ShoppingProtectionEnabled));
            builder.AppendLine("ShoppingProtectionMode=" + NormalizeSoftProtectionAreaMode(config.ShoppingProtectionMode, "planned"));
            builder.AppendLine("ShoppingDelayDefaultMinutes=" + NormalizeGamblingDelayMinutes(config.ShoppingDelayDefaultMinutes));
            builder.AppendLine("ShoppingCheckoutDelayEnabled=" + ToJsonBool(config.ShoppingCheckoutDelayEnabled));
            builder.AppendLine("ShoppingStimulusDampingEnabled=" + ToJsonBool(config.ShoppingStimulusDampingEnabled));
            builder.AppendLine("ShoppingDealSearchBlockEnabled=" + ToJsonBool(config.ShoppingDealSearchBlockEnabled));
            builder.AppendLine("ShoppingCurfewEnabled=" + ToJsonBool(config.ShoppingCurfewEnabled));
            builder.AppendLine("ShoppingCurfewStart=" + NormalizeTimeText(config.ShoppingCurfewStart, "22:00"));
            builder.AppendLine("ShoppingCurfewEnd=" + NormalizeTimeText(config.ShoppingCurfewEnd, "06:00"));
            builder.AppendLine("ShoppingDailyLimitEnabled=" + ToJsonBool(config.ShoppingDailyLimitEnabled));
            builder.AppendLine("ShoppingDailyLimitMinutes=" + NormalizeDailyLimitMinutes(config.ShoppingDailyLimitMinutes, 30));
            builder.AppendLine("ShoppingMonthlyOrderLimitEnabled=" + ToJsonBool(config.ShoppingMonthlyOrderLimitEnabled));
            builder.AppendLine("ShoppingMonthlyOrderLimit=" + NormalizeMonthlyOrderLimit(config.ShoppingMonthlyOrderLimit));
            builder.AppendLine("ShoppingMonthlyBudgetEnabled=" + ToJsonBool(config.ShoppingMonthlyBudgetEnabled));
            builder.AppendLine("ShoppingMonthlyBudgetEuro=" + NormalizeMonthlyBudgetEuro(config.ShoppingMonthlyBudgetEuro));
            builder.AppendLine("GamblingDailyLimitEnabled=" + ToJsonBool(config.GamblingDailyLimitEnabled));
            builder.AppendLine("GamblingDailyLimitMinutes=" + NormalizeDailyLimitMinutes(config.GamblingDailyLimitMinutes, 15));
            builder.AppendLine("SocialMediaProtectionEnabled=" + ToJsonBool(config.SocialMediaProtectionEnabled));
            builder.AppendLine("SocialMediaProtectionMode=" + NormalizeSoftProtectionAreaMode(config.SocialMediaProtectionMode, "planned"));
            builder.AppendLine("SocialMediaDailyBudgetEnabled=" + ToJsonBool(config.SocialMediaDailyBudgetEnabled));
            builder.AppendLine("SocialMediaDailyBudgetMinutes=" + NormalizeSocialMediaBudgetMinutes(config.SocialMediaDailyBudgetMinutes));
            builder.AppendLine("SocialMediaPlatformLimits=" + NormalizeSocialMediaPlatformLimits(config.SocialMediaPlatformLimits, config.SocialMediaDailyBudgetEnabled, config.SocialMediaDailyBudgetMinutes));
            builder.AppendLine("SocialMediaBlockedPlatforms=" + NormalizeSocialMediaBlockedPlatforms(config.SocialMediaBlockedPlatforms));
            builder.AppendLine("SocialMediaFeedBlockedPlatforms=" + NormalizeSocialMediaFeedBlockedPlatforms(config.SocialMediaFeedBlockedPlatforms, config.SocialMediaBlockedPlatforms));
            builder.AppendLine("SocialMediaCurfewEnabled=" + ToJsonBool(config.SocialMediaCurfewEnabled));
            builder.AppendLine("SocialMediaCurfewStart=" + NormalizeTimeText(config.SocialMediaCurfewStart, "22:00"));
            builder.AppendLine("SocialMediaCurfewEnd=" + NormalizeTimeText(config.SocialMediaCurfewEnd, "06:00"));
            builder.AppendLine("SocialMediaReflectionEnabled=" + ToJsonBool(config.SocialMediaReflectionEnabled));
            builder.AppendLine("SocialMediaFeedDampingEnabled=" + ToJsonBool(config.SocialMediaFeedDampingEnabled));
            builder.AppendLine("SocialMediaFeedDampingScrolls=" + NormalizeSocialMediaFeedDampingScrolls(config.SocialMediaFeedDampingScrolls));
            builder.AppendLine("VideoGamesProtectionEnabled=" + ToJsonBool(config.VideoGamesProtectionEnabled));
            builder.AppendLine("VideoGamesProtectionMode=" + NormalizeProtectionAreaMode(config.VideoGamesProtectionMode, "planned"));
            builder.AppendLine("VideoGamesDailyLimitEnabled=" + ToJsonBool(config.VideoGamesDailyLimitEnabled));
            builder.AppendLine("VideoGamesDailyLimitMinutes=" + NormalizeVideoGamesDailyLimitMinutes(config.VideoGamesDailyLimitMinutes));
            builder.AppendLine("VideoGamesCurfewEnabled=" + ToJsonBool(config.VideoGamesCurfewEnabled));
            builder.AppendLine("VideoGamesCurfewStart=" + NormalizeTimeText(config.VideoGamesCurfewStart, "22:00"));
            builder.AppendLine("VideoGamesCurfewEnd=" + NormalizeTimeText(config.VideoGamesCurfewEnd, "06:00"));
            builder.AppendLine("VideoGamesAutoDetectEnabled=" + ToJsonBool(config.VideoGamesAutoDetectEnabled));
            builder.AppendLine("VideoGamesHeuristicEnabled=" + ToJsonBool(config.VideoGamesHeuristicEnabled));
            builder.AppendLine("LockdownModeEnabled=" + ToJsonBool(config.LockdownModeEnabled));
            builder.AppendLine("PauseCooldownEnabled=" + ToJsonBool(config.PauseCooldownEnabled));
            builder.AppendLine("ScheduleEnabled=" + ToJsonBool(config.ScheduleEnabled));
            builder.AppendLine("StrictModeEnabled=" + ToJsonBool(config.StrictModeEnabled));
            builder.AppendLine("ScheduleStart=" + NormalizeTimeText(config.ScheduleStart, "22:00"));
            builder.AppendLine("ScheduleEnd=" + NormalizeTimeText(config.ScheduleEnd, "06:00"));
            builder.AppendLine();
            builder.AppendLine("[CustomDomains]");

            foreach (string domain in customDomains ?? new string[0])
            {
                builder.AppendLine(domain);
            }

            builder.AppendLine();
            builder.AppendLine("[AllowDomains]");
            foreach (string domain in allowDomains ?? new string[0])
            {
                builder.AppendLine(domain);
            }

            builder.AppendLine();
            builder.AppendLine("[CustomGamblingDomains]");
            foreach (string domain in customGamblingDomains ?? new string[0])
            {
                builder.AppendLine(domain);
            }

            builder.AppendLine();
            builder.AppendLine("[CustomShoppingDomains]");
            foreach (string domain in customShoppingDomains ?? new string[0])
            {
                builder.AppendLine(domain);
            }

            // Technical target entries only (enabled|launcher|name|path). Full
            // local paths are exported on purpose - without them a restore
            // cannot re-address the games. Runtime usage counters are NEVER
            // exported, so restoring a backup cannot reset today's budget.
            builder.AppendLine();
            builder.AppendLine("[VideoGameTargets]");
            foreach (VideoGameTarget target in videoGameTargets ?? new List<VideoGameTarget>())
            {
                builder.AppendLine(FormatVideoGameTargetLine(target));
            }

            // Exemptions keep their original activation timestamps: the import
            // itself is password-gated, so restoring them never bypasses the
            // 15-minute delay of a FRESH exemption.
            builder.AppendLine();
            builder.AppendLine("[VideoGameExemptions]");
            foreach (VideoGameExemption exemption in videoGameExemptions ?? new List<VideoGameExemption>())
            {
                builder.AppendLine(FormatVideoGameExemptionLine(exemption));
            }

            return builder.ToString();
        }

        public static int ImportBackup(string backupPath)
        {
            if (!File.Exists(backupPath))
            {
                throw new InvalidOperationException("Die Sicherungsdatei wurde nicht gefunden.");
            }

            AppConfig config = LoadConfig();
            if (config.Password == null)
            {
                throw new InvalidOperationException("Es ist noch kein Passwort eingerichtet.");
            }

            bool protectionEnabled = config.ProtectionEnabled;
            bool hostsEnabled = config.HostsEnabled;
            bool familyDnsEnabled = config.FamilyDnsEnabled;
            string dnsProfile = NormalizeDnsProfile(config.DnsProfile);
            bool bypassBlockingEnabled = config.BypassBlockingEnabled;
            bool unsupportedBrowserBlockingEnabled = config.UnsupportedBrowserBlockingEnabled;
            bool tamperProtectionEnabled = config.TamperProtectionEnabled;
            bool youTubeRestrictEnabled = config.YouTubeRestrictEnabled;
            bool adultHostsFollowArea = config.AdultHostsFollowArea;
            bool siteRedditEnabled = config.SiteRedditEnabled;
            bool siteXEnabled = config.SiteXEnabled;
            bool siteBlueskyEnabled = config.SiteBlueskyEnabled;
            bool siteTumblrEnabled = config.SiteTumblrEnabled;
            bool siteDeviantArtEnabled = config.SiteDeviantArtEnabled;
            bool sitePixivEnabled = config.SitePixivEnabled;
            bool siteNewgroundsEnabled = config.SiteNewgroundsEnabled;
            bool siteImgurEnabled = config.SiteImgurEnabled;
            bool siteInstagramEnabled = config.SiteInstagramEnabled;
            bool siteTikTokEnabled = config.SiteTikTokEnabled;
            bool sitePinterestEnabled = config.SitePinterestEnabled;
            bool adultContentProtectionEnabled = config.AdultContentProtectionEnabled;
            string adultContentProtectionMode = NormalizeProtectionAreaMode(config.AdultContentProtectionMode, "strict");
            bool gamblingProtectionEnabled = config.GamblingProtectionEnabled || config.GamblingSupportEnabled;
            string gamblingProtectionMode = (config.GamblingProtectionEnabled || config.GamblingSupportEnabled) ? "strict" : "off";
            string protectionAreaRulePackVersion = string.IsNullOrWhiteSpace(config.ProtectionAreaRulePackVersion) ? "1" : config.ProtectionAreaRulePackVersion.Trim();
            bool gamblingSupportEnabled = config.GamblingSupportEnabled;
            string gamblingSupportMode = NormalizeImpulseAreaMode(config.GamblingSupportMode, config.GamblingSupportEnabled ? "gentle" : "off");
            bool shoppingProtectionEnabled = config.ShoppingProtectionEnabled;
            string shoppingProtectionMode = NormalizeSoftProtectionAreaMode(config.ShoppingProtectionMode, "planned");
            int shoppingDelayDefaultMinutes = NormalizeGamblingDelayMinutes(config.ShoppingDelayDefaultMinutes);
            bool shoppingCheckoutDelayEnabled = config.ShoppingCheckoutDelayEnabled;
            bool shoppingStimulusDampingEnabled = config.ShoppingStimulusDampingEnabled;
            bool shoppingDealSearchBlockEnabled = config.ShoppingDealSearchBlockEnabled;
            bool shoppingCurfewEnabled = config.ShoppingCurfewEnabled;
            string shoppingCurfewStart = NormalizeTimeText(config.ShoppingCurfewStart, "22:00");
            string shoppingCurfewEnd = NormalizeTimeText(config.ShoppingCurfewEnd, "06:00");
            bool shoppingDailyLimitEnabled = config.ShoppingDailyLimitEnabled;
            int shoppingDailyLimitMinutes = NormalizeDailyLimitMinutes(config.ShoppingDailyLimitMinutes, 30);
            bool shoppingMonthlyOrderLimitEnabled = config.ShoppingMonthlyOrderLimitEnabled;
            int shoppingMonthlyOrderLimit = NormalizeMonthlyOrderLimit(config.ShoppingMonthlyOrderLimit);
            bool shoppingMonthlyBudgetEnabled = config.ShoppingMonthlyBudgetEnabled;
            int shoppingMonthlyBudgetEuro = NormalizeMonthlyBudgetEuro(config.ShoppingMonthlyBudgetEuro);
            bool gamblingDailyLimitEnabled = config.GamblingDailyLimitEnabled;
            int gamblingDailyLimitMinutes = NormalizeDailyLimitMinutes(config.GamblingDailyLimitMinutes, 15);
            bool socialMediaProtectionEnabled = config.SocialMediaProtectionEnabled;
            string socialMediaProtectionMode = NormalizeSoftProtectionAreaMode(config.SocialMediaProtectionMode, "planned");
            bool socialMediaDailyBudgetEnabled = config.SocialMediaDailyBudgetEnabled;
            int socialMediaDailyBudgetMinutes = NormalizeSocialMediaBudgetMinutes(config.SocialMediaDailyBudgetMinutes);
            string socialMediaPlatformLimits = config.SocialMediaPlatformLimits ?? string.Empty;
            string socialMediaBlockedPlatforms = config.SocialMediaBlockedPlatforms ?? string.Empty;
            string socialMediaFeedBlockedPlatforms = config.SocialMediaFeedBlockedPlatforms ?? string.Empty;
            bool socialMediaCurfewEnabled = config.SocialMediaCurfewEnabled;
            string socialMediaCurfewStart = NormalizeTimeText(config.SocialMediaCurfewStart, "22:00");
            string socialMediaCurfewEnd = NormalizeTimeText(config.SocialMediaCurfewEnd, "06:00");
            bool socialMediaReflectionEnabled = config.SocialMediaReflectionEnabled;
            bool socialMediaFeedDampingEnabled = config.SocialMediaFeedDampingEnabled;
            int socialMediaFeedDampingScrolls = NormalizeSocialMediaFeedDampingScrolls(config.SocialMediaFeedDampingScrolls);
            bool videoGamesProtectionEnabled = config.VideoGamesProtectionEnabled;
            string videoGamesProtectionMode = NormalizeProtectionAreaMode(config.VideoGamesProtectionMode, "planned");
            bool videoGamesDailyLimitEnabled = config.VideoGamesDailyLimitEnabled;
            int videoGamesDailyLimitMinutes = NormalizeVideoGamesDailyLimitMinutes(config.VideoGamesDailyLimitMinutes);
            bool videoGamesCurfewEnabled = config.VideoGamesCurfewEnabled;
            string videoGamesCurfewStart = NormalizeTimeText(config.VideoGamesCurfewStart, "22:00");
            string videoGamesCurfewEnd = NormalizeTimeText(config.VideoGamesCurfewEnd, "06:00");
            bool videoGamesAutoDetectEnabled = config.VideoGamesAutoDetectEnabled;
            bool videoGamesHeuristicEnabled = config.VideoGamesHeuristicEnabled;
            bool lockdownModeEnabled = config.LockdownModeEnabled;
            bool pauseCooldownEnabled = config.PauseCooldownEnabled;
            bool scheduleEnabled = config.ScheduleEnabled;
            bool strictModeEnabled = config.StrictModeEnabled;
            string scheduleStart = NormalizeTimeText(config.ScheduleStart, "22:00");
            string scheduleEnd = NormalizeTimeText(config.ScheduleEnd, "06:00");
            bool inCustomDomains = false;
            bool inAllowDomains = false;
            bool inCustomGamblingDomains = false;
            bool inCustomShoppingDomains = false;
            bool inVideoGameTargets = false;
            bool videoGameTargetsSectionSeen = false;
            bool inVideoGameExemptions = false;
            bool videoGameExemptionsSectionSeen = false;
            SortedSet<string> domains = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            SortedSet<string> allowDomains = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            SortedSet<string> gamblingDomains = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            SortedSet<string> shoppingDomains = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            List<VideoGameTarget> videoGameTargets = new List<VideoGameTarget>();
            List<VideoGameExemption> videoGameExemptions = new List<VideoGameExemption>();

            foreach (string raw in FilterObsoletePersonalSupportBackupSections(File.ReadAllLines(backupPath)))
            {
                string line = raw.Trim();
                if (line.Length == 0 || line.StartsWith("#"))
                {
                    continue;
                }

                if (string.Equals(line, "[CustomDomains]", StringComparison.OrdinalIgnoreCase))
                {
                    inCustomDomains = true;
                    inAllowDomains = false;
                    inCustomGamblingDomains = false;
                    inCustomShoppingDomains = false;
                    continue;
                }

                if (string.Equals(line, "[AllowDomains]", StringComparison.OrdinalIgnoreCase))
                {
                    inCustomDomains = false;
                    inAllowDomains = true;
                    inCustomGamblingDomains = false;
                    inCustomShoppingDomains = false;
                    continue;
                }

                if (string.Equals(line, "[CustomGamblingDomains]", StringComparison.OrdinalIgnoreCase))
                {
                    inCustomDomains = false;
                    inAllowDomains = false;
                    inCustomGamblingDomains = true;
                    inCustomShoppingDomains = false;
                    continue;
                }

                if (string.Equals(line, "[CustomShoppingDomains]", StringComparison.OrdinalIgnoreCase))
                {
                    inCustomDomains = false;
                    inAllowDomains = false;
                    inCustomGamblingDomains = false;
                    inCustomShoppingDomains = true;
                    inVideoGameTargets = false;
                    continue;
                }

                if (string.Equals(line, "[VideoGameTargets]", StringComparison.OrdinalIgnoreCase))
                {
                    inCustomDomains = false;
                    inAllowDomains = false;
                    inCustomGamblingDomains = false;
                    inCustomShoppingDomains = false;
                    inVideoGameTargets = true;
                    inVideoGameExemptions = false;
                    videoGameTargetsSectionSeen = true;
                    continue;
                }

                if (string.Equals(line, "[VideoGameExemptions]", StringComparison.OrdinalIgnoreCase))
                {
                    inCustomDomains = false;
                    inAllowDomains = false;
                    inCustomGamblingDomains = false;
                    inCustomShoppingDomains = false;
                    inVideoGameTargets = false;
                    inVideoGameExemptions = true;
                    videoGameExemptionsSectionSeen = true;
                    continue;
                }

                if (line.StartsWith("[", StringComparison.Ordinal) && line.EndsWith("]", StringComparison.Ordinal))
                {
                    inCustomDomains = false;
                    inAllowDomains = false;
                    inCustomGamblingDomains = false;
                    inCustomShoppingDomains = false;
                    inVideoGameTargets = false;
                    inVideoGameExemptions = false;
                    continue;
                }

                if (inVideoGameTargets)
                {
                    // Restored targets are re-validated exactly like UI input;
                    // unsafe or malformed lines are dropped. Paths that do not
                    // exist on this machine are kept and shown as missing.
                    VideoGameTarget restoredTarget = ParseVideoGameTargetLine(line);
                    if (restoredTarget != null)
                    {
                        videoGameTargets.Add(restoredTarget);
                    }
                    continue;
                }

                if (inVideoGameExemptions)
                {
                    // Restored exemptions are re-validated; activation times
                    // travel with the backup (the import is password-gated).
                    VideoGameExemption restoredExemption = ParseVideoGameExemptionLine(line);
                    if (restoredExemption != null)
                    {
                        videoGameExemptions.Add(restoredExemption);
                    }
                    continue;
                }

                if (inCustomDomains || inAllowDomains || inCustomGamblingDomains || inCustomShoppingDomains)
                {
                    string domain = NormalizeDomain(line);
                    if (IsValidDomain(domain))
                    {
                        if (inCustomGamblingDomains)
                        {
                            gamblingDomains.Add(domain);
                        }
                        else if (inCustomShoppingDomains)
                        {
                            shoppingDomains.Add(domain);
                        }
                        else if (inAllowDomains)
                        {
                            allowDomains.Add(domain);
                        }
                        else
                        {
                            domains.Add(domain);
                        }
                    }

                    continue;
                }

                int equals = line.IndexOf('=');
                if (equals < 0)
                {
                    continue;
                }

                string name = line.Substring(0, equals).Trim();
                string value = line.Substring(equals + 1).Trim();

                if (string.Equals(name, "ProtectionEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    protectionEnabled = ParseBackupBool(value, protectionEnabled);
                }
                else if (string.Equals(name, "HostsEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    hostsEnabled = ParseBackupBool(value, hostsEnabled);
                }
                else if (string.Equals(name, "FamilyDnsEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    familyDnsEnabled = ParseBackupBool(value, familyDnsEnabled);
                }
                else if (string.Equals(name, "DnsProfile", StringComparison.OrdinalIgnoreCase))
                {
                    dnsProfile = NormalizeDnsProfile(value);
                }
                else if (string.Equals(name, "BypassBlockingEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    bypassBlockingEnabled = ParseBackupBool(value, bypassBlockingEnabled);
                }
                else if (string.Equals(name, "UnsupportedBrowserBlockingEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    unsupportedBrowserBlockingEnabled = ParseBackupBool(value, unsupportedBrowserBlockingEnabled);
                }
                else if (string.Equals(name, "TamperProtectionEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    tamperProtectionEnabled = ParseBackupBool(value, tamperProtectionEnabled);
                }
                else if (string.Equals(name, "YouTubeRestrictEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    youTubeRestrictEnabled = ParseBackupBool(value, youTubeRestrictEnabled);
                }
                else if (string.Equals(name, "AdultHostsFollowArea", StringComparison.OrdinalIgnoreCase))
                {
                    adultHostsFollowArea = ParseBackupBool(value, adultHostsFollowArea);
                }
                else if (string.Equals(name, "SiteRedditEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    siteRedditEnabled = ParseBackupBool(value, siteRedditEnabled);
                }
                else if (string.Equals(name, "SiteXEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    siteXEnabled = ParseBackupBool(value, siteXEnabled);
                }
                else if (string.Equals(name, "SiteBlueskyEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    siteBlueskyEnabled = ParseBackupBool(value, siteBlueskyEnabled);
                }
                else if (string.Equals(name, "SiteTumblrEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    siteTumblrEnabled = ParseBackupBool(value, siteTumblrEnabled);
                }
                else if (string.Equals(name, "SiteDeviantArtEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    siteDeviantArtEnabled = ParseBackupBool(value, siteDeviantArtEnabled);
                }
                else if (string.Equals(name, "SitePixivEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    sitePixivEnabled = ParseBackupBool(value, sitePixivEnabled);
                }
                else if (string.Equals(name, "SiteNewgroundsEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    siteNewgroundsEnabled = ParseBackupBool(value, siteNewgroundsEnabled);
                }
                else if (string.Equals(name, "SiteImgurEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    siteImgurEnabled = ParseBackupBool(value, siteImgurEnabled);
                }
                else if (string.Equals(name, "SiteInstagramEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    siteInstagramEnabled = ParseBackupBool(value, siteInstagramEnabled);
                }
                else if (string.Equals(name, "SiteTikTokEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    siteTikTokEnabled = ParseBackupBool(value, siteTikTokEnabled);
                }
                else if (string.Equals(name, "SitePinterestEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    sitePinterestEnabled = ParseBackupBool(value, sitePinterestEnabled);
                }
                else if (string.Equals(name, "AdultContentProtectionEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    adultContentProtectionEnabled = ParseBackupBool(value, adultContentProtectionEnabled);
                }
                else if (string.Equals(name, "AdultContentProtectionMode", StringComparison.OrdinalIgnoreCase))
                {
                    adultContentProtectionMode = NormalizeProtectionAreaMode(value, "strict");
                }
                else if (string.Equals(name, "GamblingProtectionEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    gamblingProtectionEnabled = ParseBackupBool(value, gamblingProtectionEnabled);
                }
                else if (string.Equals(name, "GamblingProtectionMode", StringComparison.OrdinalIgnoreCase))
                {
                    gamblingProtectionMode = NormalizeProtectionAreaMode(value, gamblingProtectionEnabled ? "strict" : "off");
                }
                else if (string.Equals(name, "ProtectionAreaRulePackVersion", StringComparison.OrdinalIgnoreCase))
                {
                    protectionAreaRulePackVersion = string.IsNullOrWhiteSpace(value) ? protectionAreaRulePackVersion : value.Trim();
                }
                else if (string.Equals(name, "GamblingSupportEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    gamblingSupportEnabled = ParseBackupBool(value, gamblingSupportEnabled);
                }
                else if (string.Equals(name, "GamblingSupportMode", StringComparison.OrdinalIgnoreCase))
                {
                    gamblingSupportMode = NormalizeImpulseAreaMode(value, gamblingSupportEnabled ? "gentle" : "off");
                }
                else if (string.Equals(name, "ShoppingProtectionEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    shoppingProtectionEnabled = ParseBackupBool(value, shoppingProtectionEnabled);
                }
                else if (string.Equals(name, "ShoppingProtectionMode", StringComparison.OrdinalIgnoreCase))
                {
                    shoppingProtectionMode = NormalizeSoftProtectionAreaMode(value, shoppingProtectionMode);
                }
                else if (string.Equals(name, "ShoppingDelayDefaultMinutes", StringComparison.OrdinalIgnoreCase))
                {
                    int parsedShoppingDelay;
                    shoppingDelayDefaultMinutes = int.TryParse(value, out parsedShoppingDelay) ? NormalizeGamblingDelayMinutes(parsedShoppingDelay) : shoppingDelayDefaultMinutes;
                }
                else if (string.Equals(name, "ShoppingCheckoutDelayEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    shoppingCheckoutDelayEnabled = ParseBackupBool(value, shoppingCheckoutDelayEnabled);
                }
                else if (string.Equals(name, "ShoppingStimulusDampingEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    shoppingStimulusDampingEnabled = ParseBackupBool(value, shoppingStimulusDampingEnabled);
                }
                else if (string.Equals(name, "ShoppingDealSearchBlockEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    shoppingDealSearchBlockEnabled = ParseBackupBool(value, shoppingDealSearchBlockEnabled);
                }
                else if (string.Equals(name, "ShoppingCurfewEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    shoppingCurfewEnabled = ParseBackupBool(value, shoppingCurfewEnabled);
                }
                else if (string.Equals(name, "ShoppingCurfewStart", StringComparison.OrdinalIgnoreCase))
                {
                    shoppingCurfewStart = NormalizeTimeText(value, shoppingCurfewStart);
                }
                else if (string.Equals(name, "ShoppingCurfewEnd", StringComparison.OrdinalIgnoreCase))
                {
                    shoppingCurfewEnd = NormalizeTimeText(value, shoppingCurfewEnd);
                }
                else if (string.Equals(name, "ShoppingDailyLimitEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    shoppingDailyLimitEnabled = ParseBackupBool(value, shoppingDailyLimitEnabled);
                }
                else if (string.Equals(name, "ShoppingDailyLimitMinutes", StringComparison.OrdinalIgnoreCase))
                {
                    int parsedShoppingDaily;
                    shoppingDailyLimitMinutes = int.TryParse(value, out parsedShoppingDaily) ? NormalizeDailyLimitMinutes(parsedShoppingDaily, shoppingDailyLimitMinutes) : shoppingDailyLimitMinutes;
                }
                else if (string.Equals(name, "ShoppingMonthlyOrderLimitEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    shoppingMonthlyOrderLimitEnabled = ParseBackupBool(value, shoppingMonthlyOrderLimitEnabled);
                }
                else if (string.Equals(name, "ShoppingMonthlyOrderLimit", StringComparison.OrdinalIgnoreCase))
                {
                    int parsedOrderLimit;
                    shoppingMonthlyOrderLimit = int.TryParse(value, out parsedOrderLimit) ? NormalizeMonthlyOrderLimit(parsedOrderLimit) : shoppingMonthlyOrderLimit;
                }
                else if (string.Equals(name, "ShoppingMonthlyBudgetEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    shoppingMonthlyBudgetEnabled = ParseBackupBool(value, shoppingMonthlyBudgetEnabled);
                }
                else if (string.Equals(name, "ShoppingMonthlyBudgetEuro", StringComparison.OrdinalIgnoreCase))
                {
                    int parsedBudget;
                    shoppingMonthlyBudgetEuro = int.TryParse(value, out parsedBudget) ? NormalizeMonthlyBudgetEuro(parsedBudget) : shoppingMonthlyBudgetEuro;
                }
                else if (string.Equals(name, "GamblingDailyLimitEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    gamblingDailyLimitEnabled = ParseBackupBool(value, gamblingDailyLimitEnabled);
                }
                else if (string.Equals(name, "GamblingDailyLimitMinutes", StringComparison.OrdinalIgnoreCase))
                {
                    int parsedGamblingDaily;
                    gamblingDailyLimitMinutes = int.TryParse(value, out parsedGamblingDaily) ? NormalizeDailyLimitMinutes(parsedGamblingDaily, gamblingDailyLimitMinutes) : gamblingDailyLimitMinutes;
                }
                else if (string.Equals(name, "SocialMediaProtectionEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    socialMediaProtectionEnabled = ParseBackupBool(value, socialMediaProtectionEnabled);
                }
                else if (string.Equals(name, "SocialMediaProtectionMode", StringComparison.OrdinalIgnoreCase))
                {
                    socialMediaProtectionMode = NormalizeSoftProtectionAreaMode(value, socialMediaProtectionMode);
                }
                else if (string.Equals(name, "SocialMediaDailyBudgetEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    socialMediaDailyBudgetEnabled = ParseBackupBool(value, socialMediaDailyBudgetEnabled);
                }
                else if (string.Equals(name, "SocialMediaDailyBudgetMinutes", StringComparison.OrdinalIgnoreCase))
                {
                    int parsedSocialBudget;
                    socialMediaDailyBudgetMinutes = int.TryParse(value, out parsedSocialBudget) ? NormalizeSocialMediaBudgetMinutes(parsedSocialBudget) : socialMediaDailyBudgetMinutes;
                }
                else if (string.Equals(name, "SocialMediaPlatformLimits", StringComparison.OrdinalIgnoreCase))
                {
                    socialMediaPlatformLimits = value;
                }
                else if (string.Equals(name, "SocialMediaBlockedPlatforms", StringComparison.OrdinalIgnoreCase))
                {
                    socialMediaBlockedPlatforms = NormalizeSocialMediaBlockedPlatforms(value);
                }
                else if (string.Equals(name, "SocialMediaFeedBlockedPlatforms", StringComparison.OrdinalIgnoreCase))
                {
                    socialMediaFeedBlockedPlatforms = value;
                }
                else if (string.Equals(name, "SocialMediaCurfewEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    socialMediaCurfewEnabled = ParseBackupBool(value, socialMediaCurfewEnabled);
                }
                else if (string.Equals(name, "SocialMediaCurfewStart", StringComparison.OrdinalIgnoreCase))
                {
                    socialMediaCurfewStart = NormalizeTimeText(value, socialMediaCurfewStart);
                }
                else if (string.Equals(name, "SocialMediaCurfewEnd", StringComparison.OrdinalIgnoreCase))
                {
                    socialMediaCurfewEnd = NormalizeTimeText(value, socialMediaCurfewEnd);
                }
                else if (string.Equals(name, "SocialMediaReflectionEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    socialMediaReflectionEnabled = ParseBackupBool(value, socialMediaReflectionEnabled);
                }
                else if (string.Equals(name, "SocialMediaFeedDampingEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    socialMediaFeedDampingEnabled = ParseBackupBool(value, socialMediaFeedDampingEnabled);
                }
                else if (string.Equals(name, "SocialMediaFeedDampingScrolls", StringComparison.OrdinalIgnoreCase))
                {
                    int parsedSocialDampingScrolls;
                    socialMediaFeedDampingScrolls = int.TryParse(value, out parsedSocialDampingScrolls) ? NormalizeSocialMediaFeedDampingScrolls(parsedSocialDampingScrolls) : socialMediaFeedDampingScrolls;
                }
                else if (string.Equals(name, "VideoGamesProtectionEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    videoGamesProtectionEnabled = ParseBackupBool(value, videoGamesProtectionEnabled);
                }
                else if (string.Equals(name, "VideoGamesProtectionMode", StringComparison.OrdinalIgnoreCase))
                {
                    videoGamesProtectionMode = NormalizeProtectionAreaMode(value, videoGamesProtectionMode);
                }
                else if (string.Equals(name, "VideoGamesDailyLimitEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    videoGamesDailyLimitEnabled = ParseBackupBool(value, videoGamesDailyLimitEnabled);
                }
                else if (string.Equals(name, "VideoGamesDailyLimitMinutes", StringComparison.OrdinalIgnoreCase))
                {
                    int parsedVideoGamesDaily;
                    videoGamesDailyLimitMinutes = int.TryParse(value, out parsedVideoGamesDaily) ? NormalizeVideoGamesDailyLimitMinutes(parsedVideoGamesDaily) : videoGamesDailyLimitMinutes;
                }
                else if (string.Equals(name, "VideoGamesCurfewEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    videoGamesCurfewEnabled = ParseBackupBool(value, videoGamesCurfewEnabled);
                }
                else if (string.Equals(name, "VideoGamesCurfewStart", StringComparison.OrdinalIgnoreCase))
                {
                    videoGamesCurfewStart = NormalizeTimeText(value, videoGamesCurfewStart);
                }
                else if (string.Equals(name, "VideoGamesCurfewEnd", StringComparison.OrdinalIgnoreCase))
                {
                    videoGamesCurfewEnd = NormalizeTimeText(value, videoGamesCurfewEnd);
                }
                else if (string.Equals(name, "VideoGamesAutoDetectEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    videoGamesAutoDetectEnabled = ParseBackupBool(value, videoGamesAutoDetectEnabled);
                }
                else if (string.Equals(name, "VideoGamesHeuristicEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    videoGamesHeuristicEnabled = ParseBackupBool(value, videoGamesHeuristicEnabled);
                }
                else if (string.Equals(name, "LockdownModeEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    lockdownModeEnabled = ParseBackupBool(value, lockdownModeEnabled);
                }
                else if (string.Equals(name, "PauseCooldownEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    pauseCooldownEnabled = ParseBackupBool(value, pauseCooldownEnabled);
                }
                else if (string.Equals(name, "ScheduleEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    scheduleEnabled = ParseBackupBool(value, scheduleEnabled);
                }
                else if (string.Equals(name, "StrictModeEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    strictModeEnabled = ParseBackupBool(value, strictModeEnabled);
                }
                else if (string.Equals(name, "ScheduleStart", StringComparison.OrdinalIgnoreCase))
                {
                    scheduleStart = NormalizeTimeText(value, scheduleStart);
                }
                else if (string.Equals(name, "ScheduleEnd", StringComparison.OrdinalIgnoreCase))
                {
                    scheduleEnd = NormalizeTimeText(value, scheduleEnd);
                }
            }

            // BKP-002: Die Konfiguration wird zuerst geschrieben, die
            // Domainlisten danach. Scheitert eine Liste, gilt die neue
            // Konfiguration bereits und die Listen dazu nicht - halb
            // wiederhergestellt, ohne dass der Nutzer sieht, was schon gilt.
            // Umdrehen laesst sich die Reihenfolge nicht: das
            // Abschwaechungsfenster haengt am Konfigurationsschreiben, und eine
            // abgelehnte Sicherung wuerde sonst die Freigabeliste schon
            // hinterlassen. Deshalb wird vorher geprueft, ob die Listen
            // ueberhaupt beschreibbar sind.
            // ponytail: schliesst den haeufigen Fall (schreibgeschuetzt, von
            // einem anderen Programm offen), nicht Absturz oder volle Platte
            // mitten in der Kette. Dafuer braeuchte es Temp-Dateien fuer alle
            // Listen mit einem gemeinsamen Umbenennen am Ende.
            System.Collections.Generic.List<string> importTargets = new System.Collections.Generic.List<string>();
            importTargets.Add(CustomDomainsPath());
            importTargets.Add(AllowDomainsPath());
            importTargets.Add(CustomGamblingDomainsPath());
            importTargets.Add(CustomShoppingDomainsPath());
            if (videoGameTargetsSectionSeen)
            {
                importTargets.Add(VideoGameTargetsPath());
            }
            if (videoGameExemptionsSectionSeen)
            {
                importTargets.Add(VideoGameExemptionsPath());
            }
            RequireImportTargetsWritable(importTargets.ToArray());

            // TGT-003: Die Zielliste ist kein Konfigurationsfeld und lief
            // deshalb am Abschwaechungsfenster vorbei - eine Sicherung mit
            // kuerzerer Zielliste nahm Spiele ohne Frist von der Sperre. Die
            // Pruefung steht VOR dem Konfigurationsschreiben, damit eine
            // abgelehnte Sicherung gar nichts veraendert.
            if (videoGameTargetsSectionSeen)
            {
                ThrowIfVideoGameTargetsWeakeningNotAllowed(
                    ReadVideoGameTargets(), videoGameTargets, TrustedLocalNow(), false);
            }

            // Der Import setzt praktisch jedes Schutzfeld aus einer frei
            // editierbaren Klartextdatei und gehoert deshalb hinter dasselbe
            // Fenster wie ein Einstellungsdialog (Befund BKP-001). Eine
            // Sicherung, die nichts abschwaecht - der Normalfall nach einer
            // Neuinstallation - laeuft weiterhin sofort durch: das Gate prueft
            // den Zustand DANACH und schweigt, wenn nichts schwaecher wird.
            UpdateConfigWithWeakeningGate(delegate (AppConfig lockedConfig)
            {
                if (lockedConfig.Password == null)
                {
                    throw new InvalidOperationException("Es ist noch kein Passwort eingerichtet.");
                }

                lockedConfig.ProtectionEnabled = protectionEnabled;
                lockedConfig.HostsEnabled = hostsEnabled;
                lockedConfig.FamilyDnsEnabled = familyDnsEnabled;
                lockedConfig.DnsProfile = NormalizeDnsProfile(dnsProfile);
                // INS-004: Fest an. Die Zeile stand frueher auch in der
                // Sicherung und wurde beim Import gelesen - nur um hier
                // ueberschrieben zu werden. Sie wird nicht mehr exportiert; in
                // ALTEN Sicherungen steht sie weiter, und die Schleife oben
                // ignoriert unbekannte Schluessel stillschweigend. Ein "false"
                // von damals schaltet die Browser-Richtlinien also nicht ab.
                lockedConfig.BrowserPoliciesEnabled = true;
                lockedConfig.BypassBlockingEnabled = bypassBlockingEnabled;
                lockedConfig.UnsupportedBrowserBlockingEnabled = unsupportedBrowserBlockingEnabled;
                lockedConfig.TamperProtectionEnabled = tamperProtectionEnabled;
                lockedConfig.YouTubeRestrictEnabled = youTubeRestrictEnabled;
                lockedConfig.AdultHostsFollowArea = adultHostsFollowArea;
                lockedConfig.SiteRedditEnabled = siteRedditEnabled;
                lockedConfig.SiteXEnabled = siteXEnabled;
                lockedConfig.SiteBlueskyEnabled = siteBlueskyEnabled;
                lockedConfig.SiteTumblrEnabled = siteTumblrEnabled;
                lockedConfig.SiteDeviantArtEnabled = siteDeviantArtEnabled;
                lockedConfig.SitePixivEnabled = sitePixivEnabled;
                lockedConfig.SiteNewgroundsEnabled = siteNewgroundsEnabled;
                lockedConfig.SiteImgurEnabled = siteImgurEnabled;
                lockedConfig.SiteInstagramEnabled = siteInstagramEnabled;
                lockedConfig.SiteTikTokEnabled = siteTikTokEnabled;
                lockedConfig.SitePinterestEnabled = sitePinterestEnabled;
                lockedConfig.AdultContentProtectionEnabled = adultContentProtectionEnabled;
                lockedConfig.AdultContentProtectionMode = NormalizeProtectionAreaMode(adultContentProtectionMode, "strict");
                lockedConfig.GamblingSupportEnabled = gamblingSupportEnabled;
                lockedConfig.GamblingSupportMode = gamblingSupportEnabled ? NormalizeImpulseAreaMode(gamblingSupportMode, "gentle") : "off";
                lockedConfig.GamblingProtectionEnabled = gamblingProtectionEnabled || gamblingSupportEnabled || string.Equals(gamblingProtectionMode, "strict", StringComparison.OrdinalIgnoreCase);
                lockedConfig.GamblingProtectionMode = lockedConfig.GamblingProtectionEnabled ? "strict" : "off";
                lockedConfig.ProtectionAreaRulePackVersion = string.IsNullOrWhiteSpace(protectionAreaRulePackVersion) ? "1" : protectionAreaRulePackVersion.Trim();
                lockedConfig.ShoppingProtectionEnabled = shoppingProtectionEnabled;
                lockedConfig.ShoppingProtectionMode = shoppingProtectionMode;
                lockedConfig.ShoppingDelayDefaultMinutes = shoppingDelayDefaultMinutes;
                lockedConfig.ShoppingCheckoutDelayEnabled = shoppingCheckoutDelayEnabled;
                lockedConfig.ShoppingStimulusDampingEnabled = shoppingStimulusDampingEnabled;
                lockedConfig.ShoppingDealSearchBlockEnabled = shoppingDealSearchBlockEnabled;
                lockedConfig.ShoppingCurfewEnabled = shoppingCurfewEnabled;
                lockedConfig.ShoppingCurfewStart = shoppingCurfewStart;
                lockedConfig.ShoppingCurfewEnd = shoppingCurfewEnd;
                lockedConfig.ShoppingDailyLimitEnabled = shoppingDailyLimitEnabled;
                lockedConfig.ShoppingDailyLimitMinutes = shoppingDailyLimitMinutes;
                lockedConfig.ShoppingMonthlyOrderLimitEnabled = shoppingMonthlyOrderLimitEnabled;
                lockedConfig.ShoppingMonthlyOrderLimit = shoppingMonthlyOrderLimit;
                lockedConfig.ShoppingMonthlyBudgetEnabled = shoppingMonthlyBudgetEnabled;
                lockedConfig.ShoppingMonthlyBudgetEuro = shoppingMonthlyBudgetEuro;
                lockedConfig.GamblingDailyLimitEnabled = gamblingDailyLimitEnabled;
                lockedConfig.GamblingDailyLimitMinutes = gamblingDailyLimitMinutes;
                lockedConfig.SocialMediaProtectionEnabled = socialMediaProtectionEnabled;
                lockedConfig.SocialMediaProtectionMode = socialMediaProtectionEnabled ? "gentle" : NormalizeSoftProtectionAreaMode(socialMediaProtectionMode, "planned");
                lockedConfig.SocialMediaDailyBudgetEnabled = socialMediaDailyBudgetEnabled;
                lockedConfig.SocialMediaDailyBudgetMinutes = socialMediaDailyBudgetMinutes;
                lockedConfig.SocialMediaPlatformLimits = NormalizeSocialMediaPlatformLimits(socialMediaPlatformLimits, socialMediaDailyBudgetEnabled, socialMediaDailyBudgetMinutes);
                lockedConfig.SocialMediaBlockedPlatforms = socialMediaBlockedPlatforms;
                lockedConfig.SocialMediaFeedBlockedPlatforms = NormalizeSocialMediaFeedBlockedPlatforms(socialMediaFeedBlockedPlatforms, socialMediaBlockedPlatforms);
                lockedConfig.SocialMediaCurfewEnabled = socialMediaCurfewEnabled;
                lockedConfig.SocialMediaCurfewStart = socialMediaCurfewStart;
                lockedConfig.SocialMediaCurfewEnd = socialMediaCurfewEnd;
                lockedConfig.SocialMediaReflectionEnabled = socialMediaReflectionEnabled;
                lockedConfig.SocialMediaFeedDampingEnabled = socialMediaFeedDampingEnabled;
                lockedConfig.SocialMediaFeedDampingScrolls = socialMediaFeedDampingScrolls;
                lockedConfig.VideoGamesProtectionEnabled = videoGamesProtectionEnabled;
                lockedConfig.VideoGamesProtectionMode = videoGamesProtectionEnabled
                    ? NormalizeVideoGamesMode(videoGamesProtectionMode, true)
                    : NormalizeProtectionAreaMode(videoGamesProtectionMode, "planned");
                lockedConfig.VideoGamesDailyLimitEnabled = videoGamesDailyLimitEnabled;
                lockedConfig.VideoGamesDailyLimitMinutes = videoGamesDailyLimitMinutes;
                lockedConfig.VideoGamesCurfewEnabled = videoGamesCurfewEnabled;
                lockedConfig.VideoGamesCurfewStart = videoGamesCurfewStart;
                lockedConfig.VideoGamesCurfewEnd = videoGamesCurfewEnd;
                lockedConfig.VideoGamesAutoDetectEnabled = videoGamesAutoDetectEnabled;
                lockedConfig.VideoGamesHeuristicEnabled = videoGamesAutoDetectEnabled && videoGamesHeuristicEnabled;
                lockedConfig.LockdownModeEnabled = lockdownModeEnabled;
                lockedConfig.PauseCooldownEnabled = pauseCooldownEnabled;
                lockedConfig.PendingPauseUntilUtc = string.Empty;
                lockedConfig.ScheduleEnabled = scheduleEnabled;
                lockedConfig.StrictModeEnabled = strictModeEnabled;
                lockedConfig.ScheduleStart = scheduleStart;
                lockedConfig.ScheduleEnd = scheduleEnd;
                lockedConfig.PauseUntilUtc = string.Empty;
            }, TrustedLocalNow(), false);
            WriteCustomDomains(domains);
            // RC-001: Eine offene Ruecknahme-Frist gehoert zur alten Liste. Nach
            // dem Import wuerde sie sonst eine Domain entfernen, die gerade erst
            // aus der Sicherung gekommen ist - fuer den Nutzer eine Sperre, die
            // sich Minuten spaeter von selbst aufloest.
            ClearCustomDomainRemovals();
            WriteAllowDomains(allowDomains);
            WriteCustomGamblingDomains(gamblingDomains);
            WriteCustomShoppingDomains(shoppingDomains);
            if (videoGameTargetsSectionSeen)
            {
                // Old backups without the section keep the current target list.
                WriteVideoGameTargets(videoGameTargets);
            }
            if (videoGameExemptionsSectionSeen)
            {
                // Old backups without the section keep the current exemptions.
                // TGT-003: Die Frist laeuft ab der Wiederherstellung.
                WriteVideoGameExemptions(
                    StampImportedVideoGameExemptions(videoGameExemptions, TrustedUtcNow()));
            }
            WriteActivityLog("Backup imported.");
            return domains.Count;
        }

        // Prueft vor dem ersten Schreibvorgang, ob die Regeldateien so
        // beschreibbar sind, wie WriteAllTextDurable sie oeffnet
        // (FileMode.Create, FileShare.None). Fehlende Dateien legen die
        // Schreibfunktionen selbst an.
        internal static void RequireImportTargetsWritable(string[] paths)
        {
            foreach (string path in paths)
            {
                if (string.IsNullOrEmpty(path) || !File.Exists(path))
                {
                    continue;
                }

                try
                {
                    using (new FileStream(path, FileMode.Open, FileAccess.Write, FileShare.None))
                    {
                    }
                }
                catch (Exception ex)
                {
                    throw new InvalidOperationException(
                        "Die Sicherung wurde nicht eingespielt: \"" + Path.GetFileName(path) +
                        "\" laesst sich nicht schreiben (" + ex.Message + "). Bitte die Datei schliessen oder den Schreibschutz entfernen.");
                }
            }
        }

        internal static bool IsObsoletePersonalSupportBackupSection(string line)
        {
            string value = (line ?? string.Empty).Trim();
            return string.Equals(value, "[GamblingSupportDataBase64]", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(value, "[ShoppingSupportDataBase64]", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(value, "[SocialMediaSupportDataBase64]", StringComparison.OrdinalIgnoreCase);
        }

        internal static string[] FilterObsoletePersonalSupportBackupSections(IEnumerable<string> lines)
        {
            List<string> kept = new List<string>();
            bool skipping = false;
            if (lines == null)
            {
                return kept.ToArray();
            }

            foreach (string raw in lines)
            {
                string line = (raw ?? string.Empty).Trim();
                if (IsObsoletePersonalSupportBackupSection(line))
                {
                    skipping = true;
                    continue;
                }

                bool sectionHeader = line.StartsWith("[", StringComparison.Ordinal) &&
                    line.EndsWith("]", StringComparison.Ordinal);
                if (skipping)
                {
                    if (!sectionHeader)
                    {
                        continue;
                    }
                    skipping = false;
                }
                kept.Add(raw ?? string.Empty);
            }
            return kept.ToArray();
        }
    }
}
