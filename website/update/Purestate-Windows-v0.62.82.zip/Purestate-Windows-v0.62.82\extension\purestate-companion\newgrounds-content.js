"use strict";

// Purestate Newgrounds companion.
//
// Newgrounds (www.newgrounds.com) is a mixed site: lots of all-ages art, games,
// movies and audio next to Mature (m) and Adult (a) content. We keep the safe
// content usable and force Newgrounds' own rating filter down so the site filters
// the restricted tiers server-side. Built from live real-DOM inspection of a
// logged-in account (2026-06-30). Per the user's decision we block BOTH Mature
// and Adult (only Everyone + Teen remain).
//
// Primary protection - rating filter (instant-save, server-side):
//   A `ul.suitability-checkboxes` widget exposes four native checkboxes that
//   appear on listing pages and on /account/content-settings:
//     input.suitable-e / .suitable-t / .suitable-m / .suitable-a
//     (all name="suitabilities[]", values e/t/m/a)
//   They auto-save via AJAX (there is NO Save button and no <form> ancestor):
//   toggling one updates the account's saved suitabilities preference and reloads
//   listings filtered server-side. We force `m` and `a` OFF and block turning
//   them back ON. Mirrors the pixiv/Tumblr settings model.
//
//   The /account page also has a `#play_adult` switch (data-pref
//   "save_portal_prefs", instant-save). We force it OFF and guard it too.
//
// Per-card backstop (Newgrounds DOES expose a stable per-thumbnail rating marker,
// unlike pixiv/DeviantArt):
//   every listing card carries a rating badge `div.nohue-ngicon-small-rated-{e,t,
//   m,a}` with `title="Rated E|T|M|A"`. We hide any card whose badge is Rated M or
//   Rated A, both from first paint via CSS :has and via a JS sweep, so a
//   restricted thumbnail never shows even if the server filter lags.
//
// Per-item age-gate on a single work above the allowed rating is NOT yet handled
// (could not reach one with adult disabled on the test account); add it once a
// live example is available.

// Suitability tiers we force off + guard (user decision: block Mature and Adult).
const NG_GUARDED_SUITABILITIES = ["m", "a"];
const NG_LOCK_STYLE_ID = "purestate-ng-lock-style";
const NG_INSTANT_STYLE_ID = "purestate-ng-instant-style";
const NG_SEARCH_OVERLAY_ID = "purestate-ng-search-overlay";
// Per-card rating badges we treat as restricted.
const NG_BLOCKED_RATING_TITLES = ["Rated M", "Rated A"];
// The per-item gate ("Content Filtered" page) renders a single bypass control:
// <a id="ignore-filter-link" href=".../age-verification/ignore-filter"
//    data-url="<the work>">show it to me anyway.</a>. It un-gates that one work
// without changing the account filter, so the filter lock alone does not stop it.
// Matched on the stable id/href (class is build-hashed); text is a fallback.
const NG_GATE_BYPASS_SELECTOR =
  'a#ignore-filter-link, a[href*="/age-verification/ignore-filter"]';
const NG_GATE_BYPASS_TEXT_PATTERN = /\bshow\b[\w\s]*\banyway\b/i;
// On a work-VIEW page the work's own content rating is a bare class token on the
// title <h2 itemprop="name"> and on `.item-suitability` divs: `rated-m`/`rated-a`.
// Distinct from the listing badges (single hyphenated token like
// nohue-...-rated-m), so a plain `.rated-m` class selector matches only the
// viewed work's rating. Lets us blank an M/A work even if it was reached by typing
// the /age-verification/ignore-filter bypass URL directly (a server redirect a
// content script cannot intercept).
const NG_RESTRICTED_WORK_SELECTOR =
  "h2.rated-m, h2.rated-a, .item-suitability.rated-m, .item-suitability.rated-a";

let ngObserver = null;
let ngScanTimer = 0;
const ngControlLastClick = new WeakMap();

// A CSS selector matching any per-thumbnail rating badge for a blocked tier.
// Newgrounds renders the badge with several class shapes across sections
// (nohue-ngicon-small-rated-m, ngicon-25-rated-m, background-color-rated-m, …),
// so match the stable `-rated-<tier>` class substring plus the `title="Rated X"`
// variant seen in the art portal.
function ngRatingMarkerSelector() {
  return NG_GUARDED_SUITABILITIES
    .map((tier) => '[class*="-rated-' + tier + '"]')
    .concat(NG_BLOCKED_RATING_TITLES.map((title) => '[title="' + title + '"]'))
    .join(",");
}

purestateRunWhenSiteProtectionEnabled("newgrounds", () => {
  installNgLockStyle();
  applyNgPageBlock();
  installNgSettingsGuard();
  installNgMonitoring();
});

// --- Adult search-query block ----------------------------------------------

// Extracts the user's search term from a Newgrounds search URL (the ?terms=/?q=
// query or a /search/<channel>/<term> path) and returns it if it is an adult
// search, else "".
function ngAdultSearchTerm() {
  try {
    const url = new URL(location.href);
    if (!/(^|\.)newgrounds\.com$/i.test(url.hostname)) {
      return "";
    }
    const candidates = [
      url.searchParams.get("terms") || "",
      url.searchParams.get("q") || ""
    ];
    const path = url.pathname.match(/\/search\/[^/]+\/([^/?#]+)/i);
    if (path) {
      candidates.push(decodeURIComponent(path[1]));
    }
    for (const value of candidates) {
      if (value && purestateIsAdultSearchText(value)) {
        return value;
      }
    }
  } catch {
  }
  return "";
}

// Returns the viewed work's own Mature/Adult rating marker, or null. A blocked
// work-view page is the last-resort backstop for the gate bypass: even if the
// /age-verification/ignore-filter cookie was set by typing that URL directly, the
// work itself is blanked.
function ngViewedWorkRestrictedMarker(root) {
  const doc = root || document;
  if (!doc || typeof doc.querySelector !== "function") {
    return null;
  }
  return doc.querySelector(NG_RESTRICTED_WORK_SELECTOR);
}

// Block the page with the shared full-page overlay when it is an adult search OR
// the view of a Mature/Adult work. Returns true when the page was blocked.
function applyNgPageBlock() {
  const searchTerm = ngAdultSearchTerm();
  const restrictedWork = !searchTerm && ngViewedWorkRestrictedMarker();
  if (searchTerm || restrictedWork) {
    purestateInstantHide(document, NG_INSTANT_STYLE_ID);
    purestateShowSearchOverlay(
      document,
      NG_SEARCH_OVERLAY_ID,
      searchTerm
        ? "Diese Newgrounds-Suche wurde durch Purestate blockiert."
        : "Dieser Newgrounds-Inhalt (Mature/Adult) wurde durch Purestate blockiert."
    );
    return true;
  }
  purestateHideSearchOverlay(document, NG_SEARCH_OVERLAY_ID, NG_INSTANT_STYLE_ID);
  return false;
}

// Hide restricted listing cards from first paint and make the guarded controls
// literally un-clickable. CSS :has lets us hide the whole card the moment its
// "Rated M"/"Rated A" badge exists in the DOM, so nothing flashes.
function installNgLockStyle() {
  // Hide the per-card view link whose thumbnail carries a Mature/Adult badge.
  // Scoped to the tight `a[href*="/view/"]` card link only: a loose wrapper like
  // a `*portalitem*` grid also matches :has() and would nuke every sibling card.
  const cardRules =
    'a[href*="/view/"]:has(' + ngRatingMarkerSelector() + ")";
  // PLT-003: Die einfachen Selektoren und die :has()-Form standen in EINER
  // Gruppe. CSS verwirft bei einem unbekannten Selektor in einer Gruppe die
  // GANZE Regel - ohne :has()-Unterstuetzung waere damit auch die einfache
  // Sperre der Checkboxen weg gewesen, nicht nur die der Listeneintraege. Die
  // staerkere Regel darf nicht an der schwaecheren haengen.
  const einfach = [];
  const mitHas = [];
  for (const tier of NG_GUARDED_SUITABILITIES) {
    einfach.push("input.suitable-" + tier);
    mitHas.push("li:has(input.suitable-" + tier + ")");
  }
  einfach.push("#play_adult");
  einfach.push('label[for="play_adult"]');
  const sperre = "{pointer-events:none !important;cursor:not-allowed !important;}";
  purestateInjectStyle(
    document,
    NG_LOCK_STYLE_ID,
    cardRules + "{display:none !important;}" +
      NG_GATE_BYPASS_SELECTOR + "{display:none !important;pointer-events:none !important;}" +
      einfach.join(",") + sperre +
      mitHas.join(",") + sperre
  );
}

function installNgMonitoring() {
  enforceNgSettings(document);
  neutralizeNgCards(document);
  neutralizeNgGate(document);
  ngObserver = new MutationObserver(() => scheduleNgScan());
  ngObserver.observe(document.documentElement, { childList: true, subtree: true });
  setInterval(() => {
    applyNgPageBlock();
    enforceNgSettings(document);
    neutralizeNgCards(document);
    neutralizeNgGate(document);
    observeNgCanary();
  }, 1000);
}

// Selector canary (diagnostics only, see purestateCanaryObserve): when this
// document IS the content-settings page, the suitability-filter checkboxes
// must exist (all four tiers render there even when m/a are unchecked).
// 15 consecutive 1s-tick misses report a selector break.
function observeNgCanary() {
  purestateCanaryObserve(
    "newgrounds",
    "suitability-checkboxes",
    /^\/account\/content-settings/i.test(location.pathname || ""),
    ["e", "t", "m", "a"].some((tier) => !!document.querySelector("input.suitable-" + tier))
  );
}

function scheduleNgScan() {
  clearTimeout(ngScanTimer);
  ngScanTimer = setTimeout(() => {
    applyNgPageBlock();
    enforceNgSettings(document);
    neutralizeNgCards(document);
    neutralizeNgGate(document);
  }, 80);
}

// --- Rating-filter + adult-switch enforcement ------------------------------

function ngControlChecked(control) {
  if (typeof control.checked === "boolean") {
    return control.checked;
  }
  const aria = String(control.getAttribute && control.getAttribute("aria-checked") || "").toLowerCase();
  return aria === "true";
}

// Force every guarded rating checkbox (suitable-m / suitable-a) and the
// #play_adult switch OFF if currently on. Throttled per control so Newgrounds'
// AJAX onChange can settle and we never fight our own click.
function enforceNgSettings(root) {
  if (!root || typeof root.querySelectorAll !== "function") {
    return;
  }
  const controls = [];
  for (const tier of NG_GUARDED_SUITABILITIES) {
    for (const box of root.querySelectorAll("input.suitable-" + tier)) {
      controls.push(box);
    }
  }
  const playAdult = root.querySelector("#play_adult");
  if (playAdult) {
    controls.push(playAdult);
  }
  for (const control of controls) {
    enforceNgControlOff(control);
  }
}

function enforceNgControlOff(control) {
  if (!control || !ngControlChecked(control)) {
    return;
  }
  const last = ngControlLastClick.get(control) || 0;
  if (Date.now() - last < 1000) {
    return;
  }
  ngControlLastClick.set(control, Date.now());
  try {
    control.click();
  } catch {
  }
}

// Returns the guarded control a click/keydown is targeting, or null. Accepts a
// hit on the control itself or on its wrapping <label> / <li>.
function ngGuardedControl(target) {
  if (!target || typeof target.closest !== "function") {
    return null;
  }
  if (typeof target.matches === "function") {
    for (const tier of NG_GUARDED_SUITABILITIES) {
      if (target.matches("input.suitable-" + tier)) {
        return target;
      }
    }
    if (target.matches("#play_adult")) {
      return target;
    }
  }
  const li = target.closest("li");
  if (li) {
    for (const tier of NG_GUARDED_SUITABILITIES) {
      const box = li.querySelector("input.suitable-" + tier);
      if (box) {
        return box;
      }
    }
  }
  const label = target.closest('label[for="play_adult"]');
  if (label) {
    const doc = label.ownerDocument || document;
    return doc.getElementById("play_adult");
  }
  return null;
}

function installNgSettingsGuard() {
  const guard = (event) => {
    guardNgSettingsClick(event);
    guardNgGateClick(event);
  };
  document.addEventListener("pointerdown", guard, true);
  document.addEventListener("click", guard, true);
  document.addEventListener("change", guardNgSettingsClick, true);
  document.addEventListener("keydown", (event) => {
    if (!event || (event.key !== " " && event.key !== "Enter")) {
      return;
    }
    guard(event);
  }, true);
}

function guardNgSettingsClick(event) {
  // Skip our own synthetic clicks so enforcement can flip controls off.
  if (event && event.isTrusted === false) {
    return;
  }
  const control = ngGuardedControl(event && event.target);
  if (!control) {
    return;
  }
  // Block only the unsafe direction: turning a restricted tier / adult ON (it is
  // currently off, so the activation would enable it).
  if (ngControlChecked(control)) {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  if (event.stopImmediatePropagation) {
    event.stopImmediatePropagation();
  }
  setTimeout(() => enforceNgSettings(document), 50);
}

// --- Per-card rating backstop ----------------------------------------------

// Climb from a rating badge to the card container that should be hidden: the
// nearest card link / list item / cell wrapper.
function ngCardContainerFor(marker) {
  if (!marker || typeof marker.closest !== "function") {
    return null;
  }
  return (
    marker.closest('a[href*="/view/"]') ||
    marker.closest('li.item, [class*="portalitem"], [class*="submission"], [class*="-cell"]') ||
    marker.parentElement
  );
}

// Hide every listing card whose rating badge is Rated M or Rated A. Backs up the
// CSS rule (covers AJAX-inserted cards and any markup the :has selector misses).
function neutralizeNgCards(root) {
  if (!root || typeof root.querySelectorAll !== "function") {
    return;
  }
  const markers = root.querySelectorAll(ngRatingMarkerSelector());
  for (const marker of markers) {
    const card = ngCardContainerFor(marker);
    if (card && card.style && card.style.setProperty) {
      card.style.setProperty("display", "none", "important");
    }
  }
}

// --- Per-item gate ("show it to me anyway") block --------------------------

function ngControlMatchesGateBypass(node) {
  if (!node || typeof node.matches !== "function") {
    return false;
  }
  if (node.matches(NG_GATE_BYPASS_SELECTOR)) {
    return true;
  }
  const tag = (node.tagName || "").toLowerCase();
  const role = node.getAttribute ? node.getAttribute("role") : null;
  if (tag !== "a" && role !== "button") {
    return false;
  }
  const text = (node.textContent || "").trim();
  return Boolean(text && text.length < 40 && NG_GATE_BYPASS_TEXT_PATTERN.test(text));
}

// Proactively remove the gate bypass link so a filtered work cannot be un-gated
// even if the click guard is bypassed.
function neutralizeNgGate(root) {
  if (!root || typeof root.querySelectorAll !== "function") {
    return;
  }
  for (const el of root.querySelectorAll(NG_GATE_BYPASS_SELECTOR)) {
    if (el.setAttribute) {
      el.setAttribute("disabled", "true");
    }
    if (el.style && el.style.setProperty) {
      el.style.setProperty("pointer-events", "none", "important");
      el.style.setProperty("display", "none", "important");
    }
  }
}

// composedPath() exposes the real innermost target even if the bypass link is
// wrapped, so a click is blocked before Newgrounds' handler ignores the filter.
function guardNgGateClick(event) {
  if (event && event.isTrusted === false) {
    return;
  }
  const path = event && typeof event.composedPath === "function"
    ? event.composedPath()
    : null;
  let control = null;
  if (path) {
    for (const node of path) {
      if (ngControlMatchesGateBypass(node)) {
        control = node;
        break;
      }
    }
  }
  if (!control && event && event.target && typeof event.target.closest === "function") {
    const hit = event.target.closest(NG_GATE_BYPASS_SELECTOR);
    if (hit && ngControlMatchesGateBypass(hit)) {
      control = hit;
    }
  }
  if (!control) {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  if (event.stopImmediatePropagation) {
    event.stopImmediatePropagation();
  }
}
