using System;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // Settings page: only settings that affect the whole app. There is no
    // second entry called "Einstellungen" anymore - the former kitchen-sink
    // dialog is split into two focused dialogs (Internetschutz, Zeitplan).
    internal sealed partial class AdminForm
    {
        private Button themeToggleButton;
        private TableLayoutPanel weakeningRow;
        private Label weakeningDescriptionLabel;
        private Button weakeningButton;
        private TableLayoutPanel authorityRow;
        private Label authorityTitleLabel;
        private Label authorityDescriptionLabel;
        private Button authorityButton;

        // Zeigt den Zustand der Abschwaechungsfrist. Wird beim Aufbau, beim
        // Wechsel auf die Seite und nach jeder Aktion aktualisiert - bewusst
        // nicht im Sekundentakt: die Anzeige nennt Tage und Stunden, und ein
        // Konfigurationslesen gehoert nicht in einen Dauertimer.
        private void UpdateWeakeningRow()
        {
            if (weakeningDescriptionLabel == null || weakeningButton == null)
            {
                return;
            }

            AppConfig config = Support.LoadConfig();
            DateTime opensAt;
            DateTime closesAt;

            UpdateAuthorityRow(config);

            // Im Servermodus misst der Client die Frist nicht selbst. Es gibt
            // nur zwei Zustaende: eine gueltige Freigabe liegt vor, oder nicht.
            if (Support.IsServerAuthorityMode(config))
            {
                UpdateServerWeakeningRow(config);
                return;
            }

            int state = Support.EvaluateWeakeningRequest(config, Support.TrustedUtcNow(config), out opensAt, out closesAt);

            if (state == 1)
            {
                TimeSpan remaining = opensAt - Support.TrustedUtcNow(config);
                int days = (int)remaining.TotalDays;
                int hours = remaining.Hours;
                // Die kleine Stufe muss hier stehen, sonst erfaehrt niemand,
                // dass kleinere Lockerungen schon nach 24 Stunden gehen.
                DateTime minorOpensAt = opensAt.AddDays(-Support.WeakeningWaitDays).AddHours(Support.WeakeningMinorWaitHours);
                string minorHint = Support.TrustedUtcNow(config) < minorOpensAt
                    ? " Kleinere Lockerungen ab " + minorOpensAt.ToLocalTime().ToString("g") + "."
                    : " Kleinere Lockerungen sind bereits moeglich.";
                SetWeakeningRow("Noch " + days + " Tage, " + hours + " Stunden. Danach kannst du einen Tag lang lockern." + minorHint,
                    "Frist abbrechen");
            }
            else if (state == 2)
            {
                SetWeakeningRow("Du kannst noch bis " + closesAt.ToLocalTime().ToString("g") + " Einstellungen lockern.",
                    "Frist abbrechen");
            }
            else
            {
                SetWeakeningRow("Einen Schutzbereich abschalten oder abschwächen braucht sieben Tage Vorlauf; danach steht ein Tag lang offen, in dem du lockern kannst. Kleinere Lockerungen innerhalb eines Bereichs - ein Zeitlimit, eine Sperrzeit - gehen schon 24 Stunden nach dem Start der Frist.",
                    "Frist starten");
            }
        }

        // Im Servermodus ersetzt diese Anzeige die lokale. Sie nennt keine
        // Restzeit: die kennt nur der Server, und eine hier gerechnete waere
        // genau die Zahl, die der Nutzer stellen koennte.
        private void UpdateServerWeakeningRow(AppConfig config)
        {
            if (Support.IsGrantValid(config, Support.TrustedUtcNow(config)))
            {
                SetWeakeningRow("Der Server hat eine Freigabe erteilt. Du kannst jetzt Einstellungen lockern.",
                    "Freigabe abrufen");
                return;
            }

            SetWeakeningRow("Abschwächungen brauchen 72 Stunden, gemessen vom Server. Starte die Frist und rufe danach die Freigabe ab.",
                "Frist starten");
        }

        // Wie SetAuthorityRow: WrapLabel und CommandRow setzen die Namen fuer
        // Bildschirmleser einmal beim Bau der Zeile. Ohne diesen Setzer liest
        // ein Bildschirmleser in jedem Zustand den Platzhalter "Wird beim
        // Öffnen der Seite aktualisiert." und den ersten Knopftext.
        private void SetWeakeningRow(string description, string action)
        {
            Ui.SetDynamicText(weakeningDescriptionLabel, description, null);
            Ui.SetDynamicText(weakeningButton, action, null);
            Ui.SetAccessibility(weakeningRow, "Frist für Lockerungen", description, AccessibleRole.Grouping);
            Ui.SetAccessibility(weakeningDescriptionLabel, description, description, AccessibleRole.StaticText);
            Ui.SetAccessibility(weakeningButton, action, description, AccessibleRole.PushButton);
        }

        // Servermodus: Frist starten und Freigabe abrufen sind derselbe Knopf.
        // Der Server sagt, was gerade dran ist - der Client raet nicht.
        // DESK-09: bis zu zwei HTTP-Aufrufe mit je 15 s Zeitlimit - im
        // Hintergrund, damit die Verwaltung während der Anfrage reagiert.
        private void ToggleServerWeakeningRequest()
        {
            string message = null;
            RunAction("Frist für Lockerungen", delegate
            {
                string error;
                DateTime opensAt;

                if (Support.FetchGrant(out error))
                {
                    message = "Freigabe erhalten. Du kannst jetzt einen Tag lang lockern.";
                }
                else if (Support.RequestWeakening(out opensAt, out error))
                {
                    message = "Frist läuft. Ab " + opensAt.ToLocalTime().ToString("g") + " kannst du die Freigabe abrufen.";
                }
                else
                {
                    // Kein Netz ist kein Fehlerzustand, sondern eine Meldung.
                    message = error;
                }
            }, delegate (bool success)
            {
                if (success)
                {
                    ShowSaveFeedback(message);
                }
                UpdateWeakeningRow();
            });
        }

        // Freischalten und Verlassen sind derselbe Knopf: welcher Weg ansteht,
        // sagt der Modus. Zwei feste Zeilen waeren nach dem Freischalten in
        // derselben Sitzung falsch beschriftet - die Seite wird einmal gebaut.
        //
        // Der Titel wechselt mit: "Servermodus" nur fuer ein Geraet, das
        // wirklich im Servermodus ist. Seit die Einloesung den Modus nicht mehr
        // umschaltet (Support.ApplyRedeemedEntitlement), loest der Knopf eines
        // lokalen Geraets nur noch den Code ein oder verlaengert ihn.
        private void UpdateAuthorityRow(AppConfig config)
        {
            if (authorityRow == null || authorityTitleLabel == null || authorityDescriptionLabel == null || authorityButton == null)
            {
                return;
            }

            if (Support.IsServerAuthorityMode(config))
            {
                // Liegt eine gueltige Abschaltdatei vor, ist der Dienst zu
                // Ende. Dann auf einer Frist zu bestehen, die niemand mehr
                // verkuerzen kann, waere reine Haerte.
                if (Support.HasValidShutdownFile())
                {
                    SetAuthorityRow("Servermodus",
                        "Der Betreiber hat den Dienst eingestellt und das mit einer signierten Abschaltdatei bestätigt. Dieses Gerät kann jetzt ohne Frist zurück in den lokalen Modus. Der Schutz bleibt dabei unverändert aktiv.",
                        "Abschaltung anwenden");
                    return;
                }

                SetAuthorityRow("Servermodus",
                    "Dieses Gerät ist freigeschaltet. Der Weg zurück in den lokalen Modus braucht eine Freigabe des Servers: der Wechsel ist selbst eine Lockerung.",
                    "Servermodus verlassen");
                return;
            }

            SetAuthorityRow("Freischaltung",
                "Löst deinen Freischaltcode ein oder verlängert ihn mit demselben Code. Der Beta-Zeitraum gilt danach bis zum neuen Datum. An der Frist für Lockerungen ändert sich nichts.",
                "Freischalten");
        }

        // Die Namen fuer Bildschirmleser stehen sonst fest auf den Werten beim
        // Bau der Zeile - Titel "Freischaltung", Knopf "Freischalten" und ein
        // Platzhaltertext - und sagen nach einem Wechsel etwas anderes als die
        // sichtbare Beschriftung.
        private void SetAuthorityRow(string title, string description, string action)
        {
            Ui.SetDynamicText(authorityTitleLabel, title, null);
            Ui.SetDynamicText(authorityDescriptionLabel, description, null);
            Ui.SetDynamicText(authorityButton, action, null);
            Ui.SetAccessibility(authorityRow, title, description, AccessibleRole.Grouping);
            Ui.SetAccessibility(authorityDescriptionLabel, description, description, AccessibleRole.StaticText);
            Ui.SetAccessibility(authorityButton, action, description, AccessibleRole.PushButton);
        }

        private void ToggleAuthorityMode()
        {
            if (Support.IsServerAuthorityMode(Support.LoadConfig()))
            {
                if (Support.HasValidShutdownFile())
                {
                    ApplyAuthorityShutdown();
                    return;
                }

                LeaveServerAuthorityMode();
                return;
            }

            EnrollAuthorityDevice();
        }

        // Beim Start einmal nachsehen, ob der Betrieb eingestellt wurde. Nur im
        // Servermodus, nur wenn eine Adresse eingetragen ist - solange keine
        // existiert, passiert hier gar nichts. Im Hintergrund, damit ein
        // stiller Host das Fenster nicht aufhaelt. Angewendet wird nichts:
        // das bleibt eine Aktion des Nutzers, mit Passwort.
        private void StartShutdownFileCheck()
        {
            if (!Support.IsServerAuthorityMode(Support.LoadConfig()))
            {
                return;
            }

            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                bool received = false;
                try
                {
                    received = Support.TryFetchShutdownFile();
                }
                catch
                {
                }

                if (!received || !IsHandleCreated || IsDisposed)
                {
                    return;
                }

                try
                {
                    BeginInvoke(new Action(delegate { UpdateWeakeningRow(); }));
                }
                catch
                {
                }
            });
        }

        // Kein Abschwaechungsfenster: die Signatur des Betreibers ersetzt es.
        // Das Passwort bleibt, wie bei jeder Einstellungsaenderung.
        private void ApplyAuthorityShutdown()
        {
            if (!ConfirmPassword("Abschaltung anwenden"))
            {
                return;
            }

            RunAction("Abschaltung anwenden", delegate
            {
                string error;
                if (!Support.ApplyStoredShutdownFile(out error))
                {
                    throw new InvalidOperationException(error);
                }
            }, delegate (bool success)
            {
                if (success)
                {
                    ShowSaveFeedback("Die Abschaltung wurde angewendet. Dieses Gerät ist wieder im lokalen Modus.");
                }

                UpdateWeakeningRow();
            });
        }

        // Der Weg fuer den Fall, dass die Adresse laengst weg ist und jemand
        // die Datei aus einem Archiv oder von einem Dritten hat. Das Programm
        // laeuft erhoeht und liest sie von ueberall; geprueft wird sie
        // trotzdem gegen den eingebetteten Serverschluessel.
        private void ImportShutdownFile()
        {
            if (!Support.IsServerAuthorityMode(Support.LoadConfig()))
            {
                Ui.Inform(this, theme, "Abschaltdatei",
                    "Dieses Gerät ist nicht im Servermodus. Es gibt nichts anzuwenden.");
                return;
            }

            if (!ConfirmPassword("Abschaltdatei einlesen"))
            {
                return;
            }

            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Abschaltdatei einlesen";
                dialog.Filter = "Purestate Abschaltdatei|*.json|Alle Dateien|*.*";
                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }

                string path = dialog.FileName;
                RunAction("Abschaltdatei einlesen", delegate
                {
                    string error;
                    if (!Support.ApplyShutdownFileFromPath(path, out error))
                    {
                        throw new InvalidOperationException(error);
                    }
                }, delegate (bool success)
                {
                    if (success)
                    {
                        ShowSaveFeedback("Die Abschaltdatei wurde geprüft und angewendet. Dieses Gerät ist wieder im lokalen Modus.");
                    }

                    UpdateWeakeningRow();
                });
            }
        }

        // Der Rueckwechsel laeuft durch das gewoehnliche Abschwaechungs-Gate:
        // ohne gueltige Serverfreigabe lehnt Support ihn ab, und zwar mit
        // derselben Meldung wie jede andere gesperrte Lockerung.
        private void LeaveServerAuthorityMode()
        {
            if (!ConfirmPassword("Servermodus verlassen"))
            {
                return;
            }

            if (!Ui.Confirm(this, theme, "Servermodus verlassen",
                "Danach misst dieser PC die Frist für Lockerungen wieder selbst: sieben Tage statt 72 Stunden vom Server. Der Schutz bleibt unverändert aktiv.",
                "Verlassen", "Abbrechen"))
            {
                return;
            }

            RunAction("Servermodus verlassen",
                delegate { Support.LeaveServerAuthority(Support.TrustedLocalNow()); },
                delegate (bool success)
                {
                    if (success)
                    {
                        ShowSaveFeedback("Dieses Gerät ist wieder im lokalen Modus.");
                    }

                    UpdateWeakeningRow();
                });
        }

        // Loest einen Freischaltcode ein oder verlaengert ihn. Der Modus des
        // Geraets bleibt dabei, wie er ist (Support.ApplyRedeemedEntitlement).
        private void EnrollAuthorityDevice()
        {
            // Nur die eingebaute Fassungsgrenze sperrt die Freischaltung, nicht
            // eine abgelaufene Berechtigung: die Verlaengerung loest denselben
            // Code nach dem alten Ablauf erneut ein, um das neue Datum vom
            // Server zu holen. Support.IsBuildExpired ist deshalb bewusst NICHT
            // Support.IsEntitlementExpired.
            if (Support.IsBuildExpired(Support.LoadConfig()))
            {
                Ui.Inform(this, theme, "Gerät freischalten",
                    "Diese Beta-Fassung ist beendet und lässt sich nicht mehr freischalten. " +
                    "Bitte lade die neue Fassung von purestate-app.com.");
                return;
            }

            string token;
            if (!PromptText("Gerät freischalten", "Freischaltcode eingeben:", out token))
            {
                return;
            }

            // DESK-09: HTTP-Aufruf im Hintergrund statt im Klickhandler.
            string message = null;
            bool redeemed = false;
            RunAction("Gerät freischalten", delegate
            {
                string error;
                if (Support.EnrollDevice(token, out error))
                {
                    redeemed = true;
                    DateTime endsAtUtc;
                    message = Support.TryEffectiveEntitlementEnd(Support.LoadConfig(), out endsAtUtc)
                        ? "Freischaltcode eingelöst. Der Beta-Zeitraum gilt bis " + endsAtUtc.ToLocalTime().ToString("g") + ". An der Frist für Lockerungen ändert sich nichts."
                        : "Freischaltcode eingelöst. An der Frist für Lockerungen ändert sich nichts.";
                }
                else
                {
                    message = error;
                }
            }, delegate (bool success)
            {
                if (success)
                {
                    // Der Ablaufbildschirm hat keine Statuskarte. Erst nach
                    // erfolgreicher asynchroner Verlängerung den Neustarthinweis
                    // zeigen; direkt nach dem Klick ist noch nichts eingelöst.
                    if (redeemed && statusCard == null && !Support.IsEntitlementExpired(Support.LoadConfig()))
                    {
                        message += " Bitte öffne die Verwaltung erneut.";
                    }
                    ShowSaveFeedback(message);
                }
                UpdateWeakeningRow();
            });
        }

        private void ToggleWeakeningRequest()
        {
            AppConfig current = Support.LoadConfig();
            if (Support.IsServerAuthorityMode(current))
            {
                ToggleServerWeakeningRequest();
                return;
            }

            try
            {
                AppConfig config = current;
                DateTime opensAt;
                DateTime closesAt;
                if (Support.EvaluateWeakeningRequest(config, Support.TrustedUtcNow(config), out opensAt, out closesAt) == 0)
                {
                    DateTime readyAt = Support.BeginWeakeningRequest();
                    // GAT-001: Die Meldung nannte nur die grosse Frist. Das Gate
                    // kennt zwei - kleinere Lockerungen gehen schon nach 24
                    // Stunden -, und die Statuszeile sagt das auch. Nur
                    // ausgerechnet der Moment, in dem der Nutzer die Frist
                    // startet, verschwieg es: er ging davon aus, sieben Tage
                    // lang gar nichts aendern zu koennen.
                    DateTime minorReadyAt = readyAt
                        .AddDays(-Support.WeakeningWaitDays)
                        .AddHours(Support.WeakeningMinorWaitHours);
                    ShowSaveFeedback("Frist gestartet. Kleinere Lockerungen ab " +
                        minorReadyAt.ToLocalTime().ToString("g") + ", ab " +
                        readyAt.ToLocalTime().ToString("g") + " kannst du einen Tag lang alles lockern.");
                }
                else
                {
                    Support.CancelWeakeningRequest();
                    ShowSaveFeedback("Frist abgebrochen.");
                }
            }
            catch (Exception ex)
            {
                ShowErrorDialog("Frist für Lockerungen", ex);
            }

            UpdateWeakeningRow();
        }

        private void BuildSettingsPage()
        {
            TableLayoutPanel page = CreatePage("settings");
            AddPageTitle(page, "Einstellungen");
            AddPageHint(page, "Allgemeine Einstellungen für ganz Purestate. Die Schutzbereiche stellst du auf der Seite „Schutzbereiche“ ein.");

            AddSectionTitle(page, "Sicherheit");
            AddActionRow(page, "Passwort ändern",
                "Legt ein neues Purestate-Passwort und einen optionalen Hinweis fest.",
                "Ändern", delegate { ChangePassword(); }, false);

            AddSectionTitle(page, "Schutz im Internet");
            AddActionRow(page, "Internetschutz einstellen",
                "Webseiten auf diesem PC blockieren, zusätzlicher Internetfilter, Umgehungsschutz.",
                "Einstellen", delegate { ShowInternetProtectionSettings(); }, false);

            AddSectionTitle(page, "Zeitplan und Pausen");
            AddActionRow(page, "Zeitplan und Pausenregeln einstellen",
                "Schutz jeden Tag automatisch aktivieren und festlegen, ob Pausieren erlaubt ist.",
                "Einstellen", delegate { ShowScheduleSettings(); }, false);

            AddSectionTitle(page, "Einstellungen lockern");
            weakeningRow = AddActionRow(page, "Frist für Lockerungen",
                "Wird beim Öffnen der Seite aktualisiert.",
                "Frist starten", delegate { ToggleWeakeningRequest(); }, false);
            TableLayoutPanel weakeningCopy = weakeningRow.GetControlFromPosition(0, 0) as TableLayoutPanel;
            weakeningDescriptionLabel = weakeningCopy == null ? null : weakeningCopy.GetControlFromPosition(0, 1) as Label;
            weakeningButton = weakeningRow.GetControlFromPosition(1, 0) as Button;
            UpdateWeakeningRow();

            // AUTH-001: Solange keine Serveradresse eingetragen ist, gibt es
            // keinen Freischaltcode und keine Abschaltdatei - beide Zeilen
            // koennten nur in einer Fehlermeldung enden. Ein freigeschaltetes
            // Geraet sieht sie weiterhin, sonst faende es nicht zurueck.
            if (Support.ServerAuthorityUiAvailable(Support.LoadConfig()))
            {
                authorityRow = AddActionRow(page, "Freischaltung",
                    "Wird beim Öffnen der Seite aktualisiert.",
                    "Freischalten", delegate { ToggleAuthorityMode(); }, false);
                TableLayoutPanel authorityCopy = authorityRow.GetControlFromPosition(0, 0) as TableLayoutPanel;
                authorityTitleLabel = authorityCopy == null ? null : authorityCopy.GetControlFromPosition(0, 0) as Label;
                authorityDescriptionLabel = authorityCopy == null ? null : authorityCopy.GetControlFromPosition(0, 1) as Label;
                authorityButton = authorityRow.GetControlFromPosition(1, 0) as Button;
                UpdateAuthorityRow(Support.LoadConfig());

                // Die Abschaltdatei holt nur ein Geraet im Servermodus zurueck.
                // Fuer jedes andere - also jedes Beta-Geraet im lokalen Modus -
                // endete die Zeile in "Es gibt nichts anzuwenden".
                if (Support.IsServerAuthorityMode(Support.LoadConfig()))
                {
                    AddActionRow(page, "Abschaltdatei einlesen",
                        "Falls Purestate als Dienst eingestellt wird, veröffentlicht der Betreiber eine signierte Abschaltdatei. Sie holt dieses Gerät ohne Frist zurück in den lokalen Modus.",
                        "Datei wählen", delegate { ImportShutdownFile(); }, false);
                }
                StartShutdownFileCheck();
            }

            AddSectionTitle(page, "Darstellung");
            themeToggleButton = Ui.SecondaryButton(theme,
                theme.IsDark ? "Helles Design einschalten" : "Dunkles Design einschalten",
                "Wechselt zwischen hellem und dunklem Purestate-Design.");
            themeToggleButton.Click += delegate { ToggleTheme(); };
            themeToggleButton.Enabled = !theme.IsHighContrast;
            page.Controls.Add(themeToggleButton);
            actionButtons.Add(themeToggleButton);
            if (theme.IsHighContrast)
            {
                AddPageHint(page, "Windows-Hochkontrast ist aktiv. Purestate verwendet dann automatisch deine Systemfarben.");
            }
            themeAppliers.Add(delegate
            {
                Ui.StyleSecondary(theme, themeToggleButton);
                Ui.SetDynamicText(themeToggleButton, theme.IsDark ? "Helles Design einschalten" : "Dunkles Design einschalten", null);
            });
        }
    }
}
