"""Copy and verify encrypted Authority snapshots, without writing plaintext.

Run on the authorized Windows administration computer. Does not delete backups.
"""
import hashlib
import importlib.util
import pathlib
import re
import subprocess
import sys
from datetime import datetime, timezone, timedelta

sys.dont_write_bytecode = True

ROOT = pathlib.Path.home() / "Purestate-Backups"
IDENTITY = pathlib.Path.home() / ".ssh" / "purestate_netcup"
REMOTE = "pureadmin@202.61.254.204"
SSH_OPTIONS = ["-o", "BatchMode=yes", "-o", "IdentitiesOnly=yes", "-o", "StrictHostKeyChecking=yes", "-o", "ConnectTimeout=15", "-i", str(IDENTITY)]


def main():
    if not ROOT.is_dir() or not IDENTITY.is_file():
        raise RuntimeError("Backup directory or administration identity is missing")
    verifier_path = pathlib.Path(__file__).with_name("Test-AuthorityBackup.py")
    spec = importlib.util.spec_from_file_location("authority_backup_verifier", verifier_path)
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    listing = subprocess.run(
        ["ssh", *SSH_OPTIONS, REMOTE, "find /var/backups/purestate -maxdepth 1 -type f -name 'authority-*.tar.gz.age' -exec sha256sum -- {} +"],
        capture_output=True, text=True, timeout=60, check=True,
    ).stdout
    newest = None
    copied = 0
    for line in listing.splitlines():
        match = re.fullmatch(r"([a-f0-9]{64})  (/var/backups/purestate/(authority-(\d{8}T\d{6}Z)-[A-Za-z0-9]{6}\.tar\.gz\.age))", line)
        if not match:
            raise RuntimeError("Unexpected remote snapshot filename or checksum")
        digest, remote_path, name, timestamp = match.groups()
        created = datetime.strptime(timestamp, "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc)
        if created > datetime.now(timezone.utc) + timedelta(minutes=10):
            raise RuntimeError("Snapshot timestamp is in the future")
        newest = created if newest is None else max(newest, created)
        destination = ROOT / name
        if destination.exists():
            if hashlib.sha256(destination.read_bytes()).hexdigest() != digest:
                raise RuntimeError("Existing local snapshot differs from server: " + name)
            continue
        partial = ROOT / (name + ".part")
        try:
            subprocess.run(["scp", *SSH_OPTIONS, REMOTE + ":" + remote_path, str(partial)], check=True, timeout=300)
            verifier.verify(str(partial), str(ROOT / "tools" / "age" / "age.exe"), str(IDENTITY), digest)
            partial.rename(destination)
            copied += 1
            print("Saved verified encrypted snapshot: " + name)
        finally:
            partial.unlink(missing_ok=True)
    if newest is None or datetime.now(timezone.utc) - newest > timedelta(hours=36):
        raise RuntimeError("No server snapshot newer than 36 hours")
    print("Sync successful; new snapshots: " + str(copied))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("Backup sync failed: " + str(error), file=sys.stderr)
        raise SystemExit(1)
