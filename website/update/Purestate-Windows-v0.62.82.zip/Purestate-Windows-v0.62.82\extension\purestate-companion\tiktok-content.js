"use strict";

// Purestate TikTok companion.
//
// TikTok prohibits explicit pornography under its own Terms of Service (like
// Instagram), so there is no "allow adult content" account toggle to enforce.
// The deterministic protection surface is URL-based: every content discovery
// route carries its term in the URL and is checked against the shared
// adult-term list, then blocked with the shared full-page overlay.
//
// Covered routes (moved here from the generic search module in 0.61.43 so
// TikTok participates in the per-site protection switch and fail-closed like
// every other site module):
// - /search, /search/video, /search/user, ... with ?q=<term>
// - /tag/<tag> hashtag pages
// - /discover/<term> discover pages
// - /music/<slug>-<id> sound pages (adult audio memes)
//
// Settings enforcement TODO (documented, same approach as the Newgrounds
// per-item gate in 0.61.27): TikTok's "Restricted Mode" lives behind a
// logged-in settings page - verified live 2026-07-04 that
// https://www.tiktok.com/setting redirects to /foryou without a session, so
// its DOM could not be captured. When a logged-in DOM snapshot is available,
// add Restricted-Mode enforcement plus a selector canary here.

const TIKTOK_INSTANT_STYLE_ID = "purestate-tiktok-instant-style";
const TIKTOK_SEARCH_OVERLAY_ID = "purestate-tiktok-search-overlay";

let tiktokObserver = null;
let tiktokScanTimer = 0;
let lastTiktokLocation = "";

purestateRunWhenSiteProtectionEnabled("tiktok", () => {
  installTiktokInstantHide();
  installTiktokMonitoring();
});

// At document_start: block an adult search/tag URL outright so nothing
// flashes before the overlay is built.
function installTiktokInstantHide() {
  if (!document.documentElement) {
    return;
  }
  if (tiktokAdultSearchTerm()) {
    purestateInstantHide(document, TIKTOK_INSTANT_STYLE_ID);
  }
}

// Extracts the adult term from a TikTok URL: the ?q= search query (all
// /search verticals) or the /tag/, /discover/, /music/ path segments.
// Returns "" when none is adult.
function tiktokAdultSearchTerm() {
  return tiktokAdultSearchTermFromUrl(location.href);
}

function tiktokAdultSearchTermFromUrl(urlString) {
  try {
    const url = new URL(urlString);
    if (!/(^|\.)tiktok\.com$/i.test(url.hostname)) {
      return "";
    }
    const path = url.pathname || "/";
    if (/^\/search(?:\/|$)/i.test(path)) {
      const adult = globalThis.purestateAdultSearchParam(url.href, ["q"]);
      if (adult) {
        return adult;
      }
    }
    const pathTerm =
      path.match(/^\/tag\/([^/?#]+)/i) ||
      path.match(/^\/discover\/([^/?#]+)/i) ||
      path.match(/^\/music\/([^/?#]+)/i);
    if (pathTerm) {
      const term = tiktokDecodeTerm(pathTerm[1]);
      if (term && purestateIsAdultSearchText(term)) {
        return term;
      }
    }
  } catch {
  }
  return "";
}

function tiktokDecodeTerm(value) {
  try {
    return decodeURIComponent(String(value || "")).replace(/[-_+]+/g, " ").trim();
  } catch {
    return String(value || "").replace(/[-_+]+/g, " ").trim();
  }
}

// Block an adult route with the shared full-page overlay. Returns true when
// the current URL is blocked.
function applyTiktokSearchBlock() {
  if (tiktokAdultSearchTerm()) {
    purestateInstantHide(document, TIKTOK_INSTANT_STYLE_ID);
    purestateShowSearchOverlay(
      document,
      TIKTOK_SEARCH_OVERLAY_ID,
      "Diese TikTok-Seite wurde durch Purestate blockiert."
    );
    return true;
  }
  purestateHideSearchOverlay(document, TIKTOK_SEARCH_OVERLAY_ID, TIKTOK_INSTANT_STYLE_ID);
  return false;
}

function installTiktokMonitoring() {
  applyTiktokSearchBlock();
  tiktokObserver = new MutationObserver(() => scheduleTiktokScan());
  tiktokObserver.observe(document.documentElement, { childList: true, subtree: true });
  setInterval(() => {
    // TikTok is a client-routed SPA: catch search/tag navigation that never
    // reloads the page.
    const current = location.href;
    if (current !== lastTiktokLocation) {
      lastTiktokLocation = current;
      applyTiktokSearchBlock();
    }
  }, 500);
}

function scheduleTiktokScan() {
  clearTimeout(tiktokScanTimer);
  tiktokScanTimer = setTimeout(() => applyTiktokSearchBlock(), 80);
}
