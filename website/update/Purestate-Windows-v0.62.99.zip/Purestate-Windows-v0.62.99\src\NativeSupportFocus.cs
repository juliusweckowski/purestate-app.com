using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace Purestate.Native
{
    public sealed class FocusStatus
    {
        public bool Available;
        public string Phase = "off";
        public int EdgeSeconds, EndSeconds, Minutes, Cycle, Pause, Sites, Programs;
        public bool Covered, BetaExpired;
    }

    internal static partial class Support
    {
        private const string FocusPipeName = "PurestateFocus";

        public static FocusStatus QueryFocusStatus()
        {
            return ParseFocusStatus(ExchangeDeviceSyncLine(FocusPipeName, "status"));
        }

        internal static FocusStatus ParseFocusStatus(string line)
        {
            Match match = Regex.Match(line ?? string.Empty,
                @"\AOK\|phase=(learn|break|off)\|edge=([0-9]+)\|end=([0-9]+)\|plan=([0-9]+),([0-9]+),([0-9]+)\|sites=([0-9]+)\|programs=([0-9]+)\|covered=([01])\|beta=([01])\z");
            if (!match.Success) return new FocusStatus();
            int[] values = new int[7];
            for (int index = 0; index < values.Length; index++)
                if (!int.TryParse(match.Groups[index + 2].Value, NumberStyles.None, CultureInfo.InvariantCulture, out values[index]))
                    return new FocusStatus();

            string phase = match.Groups[1].Value;
            bool plan = IsValidFocusAppPlan(values[2], values[3], values[4]);
            if (values[5] > 100 || values[6] > 50 ||
                (phase == "off" ? values[0] != 0 || values[1] != 0 || !(plan || (values[2] == 0 && values[3] == 0 && values[4] == 0)) :
                    !plan || values[0] == 0 || values[0] > values[1] || values[1] > values[2] * 60) ||
                (phase == "break" && (values[4] == 0 || values[0] > values[4] * 60))) return new FocusStatus();

            return new FocusStatus { Available = true, Phase = phase, EdgeSeconds = values[0], EndSeconds = values[1],
                Minutes = values[2], Cycle = values[3], Pause = values[4], Sites = values[5], Programs = values[6],
                Covered = match.Groups[9].Value == "1", BetaExpired = match.Groups[10].Value == "1" };
        }

        public static string StartFocusSession(int minutes, int cycle, int pause)
        {
            if (!IsValidFocusAppPlan(minutes, cycle, pause)) return "invalid-plan";
            return FocusCommandResult(string.Format(CultureInfo.InvariantCulture, "start|{0}|{1}|{2}", minutes, cycle, pause));
        }

        public static List<string> QueryFocusList()
        {
            string[] fields = (ExchangeDeviceSyncLine(FocusPipeName, "list") ?? string.Empty).Split('|');
            List<string> entries = new List<string>();
            if (fields[0] != "OK") return entries;
            for (int index = 1; index < fields.Length; index++)
            {
                if (!Regex.IsMatch(fields[index], @"\A(?:site=[a-z0-9.-]{1,253}|program=[a-z0-9._ -]{1,60}\.exe)\z"))
                    return new List<string>();
                entries.Add(fields[index]);
            }
            return entries;
        }

        public static string AddFocusEntry(string kind, string value)
        {
            return ChangeFocusEntry("add", kind, value);
        }

        public static string RemoveFocusEntry(string kind, string value)
        {
            return ChangeFocusEntry("remove", kind, value);
        }

        private static string ChangeFocusEntry(string command, string kind, string value)
        {
            if ((kind != "site" && kind != "program") || string.IsNullOrEmpty(value)) return "invalid-entry";
            foreach (char character in value)
                if (character == '|' || char.IsControl(character)) return "invalid-entry";
            string message = command + "|" + kind + "|" + value;
            if (Encoding.UTF8.GetByteCount(message) > 1024) return "invalid-entry";
            return FocusCommandResult(message);
        }

        private static string FocusCommandResult(string message)
        {
            string answer = ExchangeDeviceSyncLine(FocusPipeName, message);
            if (answer == "OK") return string.Empty;
            return Regex.IsMatch(answer ?? string.Empty, @"\AERROR\|[a-z][a-z0-9-]*\z") ? answer.Substring(6) : "unavailable";
        }

        private static bool IsValidFocusAppPlan(int minutes, int cycle, int pause)
        {
            return minutes >= 15 && minutes <= 480 && minutes % 15 == 0 &&
                ((cycle == 0 && pause == 0) || (cycle == 30 && pause == 5) || (cycle == 60 && pause == 15));
        }

        internal static List<int> FocusBreakStartMinutes(int minutes, int cycle, int pause)
        {
            List<int> starts = new List<int>();
            if (IsValidFocusAppPlan(minutes, cycle, pause) && cycle > 0)
                for (int end = cycle; end < minutes; end += cycle) starts.Add(end - pause);
            return starts;
        }

        internal static string FocusErrorText(string code)
        {
            switch (code)
            {
                case "no-companion": return "Der Companion im Browser hat diese Fassung noch nicht. Sobald er aktualisiert ist, lässt sich der Lernmodus starten.";
                case "session-running": return "Es läuft schon eine Sitzung.";
                case "beta-expired": return "Diese Fassung ist abgelaufen.";
                default: return "Purestate konnte den Lernmodus gerade nicht starten. Versuch es gleich noch einmal.";
            }
        }
    }
}
