using System;
using System.Drawing;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // Wochenplan der Sperrzeit (0.62.87), gemeinsam fuer Shopping, Social Media
    // und Videospiele: ein Kaestchen "An einzelnen Abenden anders" und sieben
    // Zeilen Montagabend bis Sonntagabend mit "Wie oben", "Eigene Zeit" oder
    // "Keine Sperre". Eine Zeile ist der Abend, an dem die Sperre beginnt; den
    // Plan baut Support.BuildCurfewWeek.
    internal sealed class CurfewWeekEditor
    {
        private static readonly string[] Evenings = { "Montagabend", "Dienstagabend", "Mittwochabend", "Donnerstagabend", "Freitagabend", "Samstagabend", "Sonntagabend" };
        private static readonly string[] ModeKeys = { "std", "own", "off" };
        private static readonly string[] ModeLabels = { "Wie oben", "Eigene Zeit", "Keine Sperre" };
        private const int OwnMode = 1;
        // Feste Breite: "Donnerstagabend" passt in eine Zeile, die Auswahlfelder
        // stehen buendig untereinander.
        private static readonly int EveningWidth = Dpi.Px(130);

        private readonly DialogShell shell;
        private readonly CheckBox curfew;
        private readonly ComboBox standardStart;
        private readonly ComboBox standardEnd;
        private readonly CheckBox differs;
        private readonly ComboBox[] modes = new ComboBox[7];
        private readonly ComboBox[] starts = new ComboBox[7];
        private readonly ComboBox[] ends = new ComboBox[7];
        private readonly Label error;

        private CurfewWeekEditor(DialogShell shell, UiTheme theme, CheckBox curfew, ComboBox standardStart, ComboBox standardEnd, string week)
        {
            this.shell = shell;
            this.curfew = curfew;
            this.standardStart = standardStart;
            this.standardEnd = standardEnd;

            string[] tokens = Support.NormalizeCurfewWeek(week).Split(',');
            bool custom = tokens.Length == 7;

            differs = Ui.Check(theme, "An einzelnen Abenden anders", custom,
                "Legt für einzelne Abende eine eigene Sperrzeit fest oder hebt sie für diesen Abend auf.");
            FlowLayoutPanel differsRow = shell.Row(differs);
            differsRow.Padding = Dpi.Padding(24, 0, 0, 0);
            shell.Add(differsRow);

            FlowLayoutPanel hintRow = shell.Row(Ui.WrapLabel(theme,
                "Ein Abend reicht bis 4 Uhr morgens: 00:30 in der Nacht auf Samstag gehört zum Freitagabend.",
                shell.InnerWidth - Dpi.Px(48), true));
            hintRow.Padding = Dpi.Padding(48, 0, 0, 0);
            shell.Add(hintRow);

            FlowLayoutPanel[] rows = new FlowLayoutPanel[7];
            for (int day = 0; day < 7; day++)
            {
                string token = custom ? tokens[day] : "std";
                int selected = token == "std" ? 0 : (token == "off" ? 2 : OwnMode);
                string[] own = selected == OwnMode ? token.Split('-') : new[] { standardStart.Text, standardEnd.Text };

                ComboBox mode = new ComboBox
                {
                    DropDownStyle = ComboBoxStyle.DropDownList,
                    Width = Dpi.Px(130),
                    Font = Ui.FontBody,
                    Margin = Dpi.Padding(0, 2, 8, 2)
                };
                Ui.StyleInput(theme, mode);
                mode.Items.AddRange(ModeLabels);
                mode.SelectedIndex = selected;
                Ui.SetAccessibility(mode, Evenings[day], "Wie oben, eigene Zeit oder keine Sperre an diesem Abend.", AccessibleRole.ComboBox);

                modes[day] = mode;
                starts[day] = Ui.TimeCombo(own[0], "22:00", Evenings[day] + ": Beginn der Sperre");
                ends[day] = Ui.TimeCombo(own[1], "06:00", Evenings[day] + ": Ende der Sperre");
                Label evening = Ui.WrapLabel(theme, Evenings[day], EveningWidth, false);
                evening.MinimumSize = new Size(EveningWidth, 0);
                rows[day] = shell.Row(evening, mode, starts[day],
                    Ui.WrapLabel(theme, "bis", Dpi.Px(30), true), ends[day]);
                rows[day].Padding = new Padding(48, 0, 0, 0);
                shell.Add(rows[day]);

                int index = day;
                mode.SelectedIndexChanged += delegate { ApplyRowState(index); };
                ApplyRowState(day);
            }
            error = shell.AddErrorLine();

            Action applyVisibility = delegate
            {
                differsRow.Visible = curfew.Checked;
                bool rowsShown = curfew.Checked && differs.Checked;
                hintRow.Visible = rowsShown;
                foreach (FlowLayoutPanel row in rows)
                {
                    row.Visible = rowsShown;
                }
            };
            curfew.CheckedChanged += delegate { applyVisibility(); };
            differs.CheckedChanged += delegate { applyVisibility(); };
            applyVisibility();

            // Abende auf "Wie oben" zeigen die obere Zeit an.
            standardStart.SelectedIndexChanged += delegate { RefreshStandardRows(); };
            standardEnd.SelectedIndexChanged += delegate { RefreshStandardRows(); };
        }

        internal static CurfewWeekEditor Add(DialogShell shell, UiTheme theme, CheckBox curfew, ComboBox standardStart, ComboBox standardEnd, string week)
        {
            return new CurfewWeekEditor(shell, theme, curfew, standardStart, standardEnd, week);
        }

        // "" ohne Sperrzeit oder ohne abweichende Abende; sonst die Normalform
        // aus Support.BuildCurfewWeek (null nur bei ungueltiger eigener Zeit,
        // die TryValidate vorher meldet).
        internal string WeekText
        {
            get
            {
                if (!curfew.Checked || !differs.Checked)
                {
                    return string.Empty;
                }

                string[] keys = new string[7];
                string[] startTexts = new string[7];
                string[] endTexts = new string[7];
                for (int day = 0; day < 7; day++)
                {
                    keys[day] = ModeKeys[Math.Max(0, modes[day].SelectedIndex)];
                    startTexts[day] = starts[day].Text;
                    endTexts[day] = ends[day].Text;
                }
                return Support.BuildCurfewWeek(keys, startTexts, endTexts);
            }
        }

        internal bool TryValidate(out Control invalid)
        {
            invalid = null;
            if (curfew.Checked && differs.Checked)
            {
                for (int day = 0; day < 7 && invalid == null; day++)
                {
                    if (modes[day].SelectedIndex != OwnMode)
                    {
                        continue;
                    }
                    if (!Support.IsValidScheduleTimeText(starts[day].Text))
                    {
                        invalid = starts[day];
                    }
                    else if (!Support.IsValidScheduleTimeText(ends[day].Text))
                    {
                        invalid = ends[day];
                    }
                }
            }

            if (invalid != null)
            {
                shell.ShowError(error, "Bitte gib die Zeiten im Format 22:00 ein.", invalid);
                return false;
            }
            shell.ClearError(error);
            return true;
        }

        private void ApplyRowState(int day)
        {
            bool own = modes[day].SelectedIndex == OwnMode;
            starts[day].Enabled = own;
            ends[day].Enabled = own;
            if (!own)
            {
                SelectTime(starts[day], standardStart.Text);
                SelectTime(ends[day], standardEnd.Text);
            }
        }

        private void RefreshStandardRows()
        {
            for (int day = 0; day < 7; day++)
            {
                ApplyRowState(day);
            }
        }

        private static void SelectTime(ComboBox box, string value)
        {
            if (!Support.IsValidScheduleTimeText(value))
            {
                return;
            }
            if (!box.Items.Contains(value))
            {
                int index = 0;
                while (index < box.Items.Count && string.CompareOrdinal((string)box.Items[index], value) < 0)
                {
                    index++;
                }
                box.Items.Insert(index, value);
            }
            box.SelectedItem = value;
        }
    }
}
