using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    internal static class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Das Restzeit-Abzeichen laeuft bewusst VOR der Rechtepruefung: es
            // zeigt nur an, aendert nichts und wird vom Dienst in der
            // Nutzersitzung gestartet - eine Rechteabfrage waere dort ein
            // Dialog mitten im Spiel.
            if (ShouldStartBadge(args))
            {
                Application.Run(new BadgeForm());
                return;
            }

            if (ShouldStartTray(args))
            {
                Application.Run(new TrayApplicationContext());
                return;
            }

            if (!Support.IsAdministrator())
            {
                // Zuerst der Aufgabenweg: erhoeht und ohne UAC-Dialog (Tester-Notiz
                // 2026-10-06). Nicht, wenn die Aufgabe uns selbst gestartet hat,
                // und ohne Aufgabe oder bei einem Standardnutzer bleibt es beim
                // gewohnten Weg mit Rueckfrage.
                if (!Support.IsOpenTaskLaunch(args) && Support.TryStartOpenTask())
                {
                    return;
                }

                try
                {
                    Support.RelaunchElevated(string.Empty);
                }
                catch
                {
                    MessageBox.Show("Bitte starte Purestate mit Administrator-Rechten.", "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                return;
            }

            AdminForm form = new AdminForm();
            form.OpenUpdateOnStart = Support.IsOpenUpdateLaunch(args);
            if (Support.IsOpenTaskLaunch(args))
            {
                // Von der Aufgabe gestartet: Windows setzt das Fenster sonst hinter das
                // aktive (in der VM gemessen). Der Starter hat den Vordergrund erlaubt;
                // kurz oben zu sein sichert die Sichtbarkeit auch dann, wenn nicht.
                form.Shown += delegate
                {
                    form.TopMost = true;
                    form.TopMost = false;
                    form.Activate();
                };
            }

            Application.Run(form);
        }

        // Restzeit-Abzeichen: ein randloses, klickdurchlaessiges Fenster oben
        // rechts, das nur liest, was der Dienst in video-games-badge.json legt.
        // Es rechnet bewusst nichts selbst - Budget, Sperrzeit und Ausnahmen
        // ein zweites Mal auszulegen waere die Doppelung, die frueher oder
        // spaeter auseinanderlaeuft.
        //
        // Es beendet sich selbst, sobald die Datei fehlt oder veraltet ist. Ein
        // Abzeichen, das nach einem Dienstabsturz stehenbleibt und eine falsche
        // Restzeit zeigt, waere schlimmer als gar keines.
        internal sealed class BadgeForm : Form
        {
            private const int StaleAfterSeconds = 90;
            private const int WarnBelowSeconds = 5 * 60;

            private readonly Label textLabel;
            private readonly Timer refreshTimer;

            internal static string BadgePath
            {
                get
                {
                    return Path.Combine(
                        Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                            "Purestate"),
                        "video-games-badge.json");
                }
            }

            public BadgeForm()
            {
                FormBorderStyle = FormBorderStyle.None;
                ShowInTaskbar = false;
                TopMost = true;
                StartPosition = FormStartPosition.Manual;
                BackColor = Color.FromArgb(18, 20, 26);
                Opacity = 0.85;
                Size = new Size(150, 38);

                textLabel = new Label();
                textLabel.Dock = DockStyle.Fill;
                textLabel.TextAlign = ContentAlignment.MiddleCenter;
                textLabel.ForeColor = Color.White;
                textLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
                Controls.Add(textLabel);

                Apply(ReadBadgeState());

                // Zwei Sekunden statt fuenf: der Hinweis des Dienstes steht nur
                // fuenfzehn Sekunden in der Datei und darf nicht verpasst werden.
                refreshTimer = new Timer();
                refreshTimer.Interval = 2000;
                refreshTimer.Tick += delegate { Apply(ReadBadgeState()); };
                refreshTimer.Start();
            }

            // Klickdurchlaessig und ohne Fokus: das Abzeichen darf einem Spiel
            // niemals einen Klick oder die Tastatur wegnehmen. WS_EX_TOOLWINDOW
            // haelt es zusaetzlich aus Alt-Tab heraus.
            protected override CreateParams CreateParams
            {
                get
                {
                    const int WS_EX_LAYERED = 0x00080000;
                    const int WS_EX_TRANSPARENT = 0x00000020;
                    const int WS_EX_NOACTIVATE = 0x08000000;
                    const int WS_EX_TOOLWINDOW = 0x00000080;

                    CreateParams parameters = base.CreateParams;
                    parameters.ExStyle |= WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW;
                    return parameters;
                }
            }

            private void PositionTopRight()
            {
                Rectangle area = Screen.PrimaryScreen.WorkingArea;
                Location = new Point(area.Right - Width - 16, area.Top + 16);
            }

            private void Apply(BadgeState state)
            {
                if (state == null)
                {
                    Close();
                    return;
                }

                // Der Hinweis bei 30, 15 und 5 Minuten laeuft ueber dasselbe
                // Fenster: kurz breiter und mit Text, danach wieder kompakt.
                // Frueher war das ein Windows-Meldefenster mit OK-Knopf mitten
                // im Bild - im Spiel abgelehnt (Befund V-6).
                bool showNotice = state.Notice.Length > 0;
                Size = showNotice ? new Size(340, 44) : new Size(150, 38);
                PositionTopRight();

                textLabel.Text = showNotice ? state.Notice : FormatRemaining(state.RemainingSeconds);
                textLabel.Font = new Font("Segoe UI", showNotice ? 11F : 12F, FontStyle.Bold);
                textLabel.ForeColor = state.RemainingSeconds <= WarnBelowSeconds
                    ? Color.FromArgb(255, 138, 128)
                    : Color.White;
            }

            private sealed class BadgeState
            {
                public int RemainingSeconds;
                public string Notice = string.Empty;
            }

            // null bedeutet: keine gueltige Anzeige mehr (Datei weg, unlesbar
            // oder veraltet).
            private static BadgeState ReadBadgeState()
            {
                try
                {
                    if (!File.Exists(BadgePath))
                    {
                        return null;
                    }
                    string json = File.ReadAllText(BadgePath, Encoding.UTF8);
                    Match updated = Regex.Match(json, "\"UpdatedUtc\"\\s*:\\s*\"([^\"]*)\"");
                    DateTime updatedUtc;
                    if (!updated.Success ||
                        !DateTime.TryParse(updated.Groups[1].Value, null,
                            System.Globalization.DateTimeStyles.RoundtripKind, out updatedUtc))
                    {
                        return null;
                    }
                    double age = (DateTime.UtcNow - updatedUtc).TotalSeconds;
                    if (age > StaleAfterSeconds)
                    {
                        return null;
                    }
                    Match remaining = Regex.Match(json, "\"RemainingSeconds\"\\s*:\\s*(-?\\d+)");
                    int seconds;
                    if (!remaining.Success || !int.TryParse(remaining.Groups[1].Value, out seconds))
                    {
                        return null;
                    }

                    BadgeState state = new BadgeState();
                    state.RemainingSeconds = Math.Max(0, seconds);

                    Match notice = Regex.Match(json, "\"Notice\"\\s*:\\s*\"([^\"]*)\"");
                    Match noticeSeconds = Regex.Match(json, "\"NoticeSeconds\"\\s*:\\s*(\\d+)");
                    int noticeWindow;
                    if (notice.Success && notice.Groups[1].Value.Length > 0 &&
                        noticeSeconds.Success && int.TryParse(noticeSeconds.Groups[1].Value, out noticeWindow) &&
                        age <= noticeWindow)
                    {
                        state.Notice = notice.Groups[1].Value;
                    }
                    return state;
                }
                catch
                {
                    return null;
                }
            }

            // Gleiche Aufrundung wie im Dienst: bei 30 Sekunden Rest ist
            // "Noch 1 min" ehrlicher als "Noch 0 min".
            internal static string FormatRemaining(int remainingSeconds)
            {
                int minutes = (Math.Max(0, remainingSeconds) + 59) / 60;
                return "Noch " + Math.Max(1, minutes) + " min";
            }
        }

        private static bool ShouldStartBadge(string[] args)
        {
            foreach (string arg in args ?? new string[0])
            {
                if (string.Equals(arg, "--badge", StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        private static bool ShouldStartTray(string[] args)
        {
            foreach (string arg in args ?? new string[0])
            {
                if (string.Equals(arg, "--tray", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(arg, "--startup-tray", StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        // Gemeinsam fuer Tray und Verwaltungsfenster, damit Abfrage und Text
        // nicht an zwei Stellen auseinanderlaufen koennen. Liefert die
        // faellige Schwelle (0 = keine) und die dazugehoerige Nachricht.
        // consume=false fuer die Sprechblase: sie kann unterdrueckt werden, und
        // eine verbrauchte Schwelle waere dann still verschwunden. Nur das
        // Verwaltungsfenster hakt sie ab.
        internal static int DueEntitlementWarningMessage(out string message, bool consume)
        {
            string warningKey;
            return DueEntitlementWarningMessage(out message, consume, out warningKey);
        }

        internal static int DueEntitlementWarningMessage(out string message, bool consume, out string warningKey)
        {
            message = string.Empty;
            warningKey = string.Empty;
            try
            {
                AppConfig config = Support.LoadConfig();
                DateTime nowUtc = Support.TrustedUtcNow(config);
                int faellig = Support.DueEntitlementWarning(
                    config, nowUtc, Support.EntitlementWarningMarkerPath, consume);
                DateTime effectiveEnd;
                if (faellig > 0 && Support.TryEffectiveEntitlementEnd(config, out effectiveEnd))
                {
                    int remainingDays = Math.Max(1, (int)Math.Ceiling((effectiveEnd - nowUtc).TotalDays));
                    warningKey = effectiveEnd.ToString("O", System.Globalization.CultureInfo.InvariantCulture) + ":" + faellig;
                    message =
                        "Dein Beta-Zeitraum endet in " + remainingDays + " Tag" + (remainingDays == 1 ? "" : "en") + "." + Environment.NewLine + Environment.NewLine +
                        "Danach schaltet sich der Schutz dieser Fassung ab. Melde dich, wenn du weitermachen möchtest.";
                }
                return faellig;
            }
            catch
            {
                return 0;
            }
        }
    }

    internal sealed class TrayApplicationContext : ApplicationContext
    {
        private readonly NotifyIcon notifyIcon;
        private readonly Icon icon;
        private readonly System.Windows.Forms.Timer entitlementWarningTimer;
        private readonly System.Windows.Forms.Timer updateTimer;
        // Nur fuer BeginInvoke aus dem Arbeitsthread; das Handle entsteht im Konstruktor.
        private readonly Control uiThread = new Control();
        private ToolStripMenuItem updateMenuItem;
        private string lastEntitlementWarningKey = string.Empty;
        private bool updateBalloonActive;
        private bool updateCheckRunning;

        public TrayApplicationContext()
        {
            icon = PurestateVisualIdentity.CreateIcon(32);
            notifyIcon = new NotifyIcon();
            notifyIcon.Icon = icon;
            notifyIcon.Text = "Purestate - Schutzstatus";
            notifyIcon.Visible = true;
            notifyIcon.ContextMenuStrip = BuildContextMenu();
            notifyIcon.DoubleClick += delegate { OpenAdminWindow(); };

            // Nur EINE Sprechblase pro Start: eine faellige Ablaufwarnung
            // wiegt schwerer als der allgemeine Statushinweis und ersetzt ihn,
            // statt zwei ShowBalloonTip-Aufrufe auf demselben Symbol wettlaufen
            // zu lassen - der zweite koennte den ersten sonst verdraengen,
            // waehrend der Merker die Warnung schon als gezeigt fuehrt.
            notifyIcon.BalloonTipTitle = "Purestate";
            notifyIcon.BalloonTipIcon = ToolTipIcon.Info;
            notifyIcon.BalloonTipClicked += delegate { OnBalloonClicked(); };
            if (!ShowDueEntitlementWarning())
            {
                ShowBalloon(StartupBalloonText(), false);
            }

            entitlementWarningTimer = new System.Windows.Forms.Timer();
            entitlementWarningTimer.Interval = 60 * 60 * 1000;
            entitlementWarningTimer.Tick += delegate { ShowDueEntitlementWarning(); };
            entitlementWarningTimer.Start();

            // Update-Suche: die erste Pruefung fruehestens eine Minute nach dem Start,
            // danach stuendlich; geprueft wird nur, wenn der 24-Stunden-Takt es erlaubt.
            // Der Tray laedt nie ein Paket herunter - das tut nur das erhoehte
            // Verwaltungsfenster.
            IntPtr handle = uiThread.Handle;
            updateTimer = new System.Windows.Forms.Timer();
            updateTimer.Interval = 60 * 1000;
            updateTimer.Tick += delegate
            {
                updateTimer.Interval = 60 * 60 * 1000;
                CheckForUpdateInBackground();
            };
            updateTimer.Start();
        }

        // Eine Sprechblase je Aufruf. BalloonTipClicked kommt fuer JEDE Sprechblase
        // dieses Symbols (Status, Ablaufwarnung, Update); nur die Update-Blase
        // darf den Dialog oeffnen, deshalb merkt sich dieser Helfer die Art.
        private void ShowBalloon(string text, bool forUpdate)
        {
            updateBalloonActive = forUpdate;
            notifyIcon.BalloonTipText = text;
            notifyIcon.ShowBalloonTip(forUpdate ? 15000 : 5000);
        }

        private void OnBalloonClicked()
        {
            if (updateBalloonActive)
            {
                OpenUpdateDialog();
            }
        }

        // Das Argument sagt dem Verwaltungsfenster, dass es den Update-Dialog von
        // sich aus oeffnen soll. Ein Argument statt einer Datei im Nutzerprofil: bei
        // einem Standardkonto laeuft das Fenster unter dem Administratorkonto und
        // sieht das Profil des Tray nicht.
        private void OpenUpdateDialog()
        {
            OpenAdminWindow(Support.OpenUpdateLaunchArgument);
        }

        private void CheckForUpdateInBackground()
        {
            if (updateCheckRunning)
            {
                return;
            }

            updateCheckRunning = true;
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    UpdateClient.CheckNow(UpdateClient.StatePath, Support.UpdateBase(), null, DateTime.UtcNow, false);
                }
                catch
                {
                }

                try
                {
                    uiThread.BeginInvoke(new Action(delegate
                    {
                        updateCheckRunning = false;
                        ApplyUpdateState();
                    }));
                }
                catch
                {
                    // Der Tray wird gerade beendet.
                }
            });
        }

        // Liest den Zustand: Menuepunkt zeigen und - einmal je Version, danach alle
        // drei Tage - die Sprechblase.
        private void ApplyUpdateState()
        {
            UpdateState state = UpdateClient.LoadState(UpdateClient.StatePath);
            if (!Support.IsUpdateNewer(state.LastSeenVersion))
            {
                updateMenuItem.Visible = false;
                return;
            }

            string version = state.LastSeenVersion;
            updateMenuItem.Text = "Update auf " + version + " installieren";
            updateMenuItem.Visible = true;

            DateTime now = DateTime.UtcNow;
            if (Support.ShouldNotifyForUpdate(version, now, state))
            {
                Support.MarkUpdateNotified(state, version, now);
                UpdateClient.SaveState(UpdateClient.StatePath, state);
                ShowBalloon("Purestate " + version + " ist verfügbar. Klicken zum Installieren.", true);
            }
        }

        private bool ShowDueEntitlementWarning()
        {
            string entitlementWarning;
            string warningKey;
            if (Program.DueEntitlementWarningMessage(out entitlementWarning, false, out warningKey) == 0
                || string.Equals(lastEntitlementWarningKey, warningKey, StringComparison.Ordinal))
            {
                return false;
            }

            // Nur im Speicher abhaken: eine unterdrueckte Sprechblase darf
            // die weiterhin faellige Warnung im Verwaltungsfenster nicht schlucken.
            lastEntitlementWarningKey = warningKey;
            ShowBalloon(entitlementWarning, false);
            return true;
        }

        private ContextMenuStrip BuildContextMenu()
        {
            ContextMenuStrip menu = new ContextMenuStrip();
            menu.Items.Add("Purestate oeffnen", null, delegate { OpenAdminWindow(); });
            updateMenuItem = new ToolStripMenuItem("Update installieren", null, delegate { OpenUpdateDialog(); });
            updateMenuItem.Visible = false;
            menu.Items.Add(updateMenuItem);
            menu.Items.Add("Tray beenden", null, delegate { ExitThread(); });
            return menu;
        }

        private static void OpenAdminWindow()
        {
            OpenAdminWindow(string.Empty);
        }

        private static void OpenAdminWindow(string argument)
        {
            try
            {
                Support.RelaunchElevated(argument);
            }
            catch
            {
                MessageBox.Show("Purestate konnte nicht mit Administrator-Rechten geoeffnet werden.", "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private static string StartupBalloonText()
        {
            try
            {
                AppConfig config = Support.LoadConfig();
                if (config.IntegrityCompromised)
                {
                    return "Purestate ist gestartet. Die Konfiguration ist gesperrt und braucht Reparatur.";
                }

                if (!Support.ProtectionShouldBeActive(config))
                {
                    return "Purestate ist gestartet. Der Schutz ist aktuell pausiert oder aus.";
                }

                // Befund #6: frische Installation, noch kein Schutzbereich
                // eingeschaltet - dieselbe Ansage wie im Statusbereich
                // (ProtectionStatusKind.NoAreas), nur als Kurzfassung fuer die
                // Sprechblase.
                if (!Support.AnyProtectionAreaActive(config))
                {
                    return "Purestate ist gestartet. Noch kein Schutzbereich eingeschaltet.";
                }

                return "Purestate ist aktiv und schuetzt dieses Windows-Profil.";
            }
            catch
            {
                return "Purestate ist gestartet.";
            }
        }

        protected override void ExitThreadCore()
        {
            entitlementWarningTimer.Stop();
            entitlementWarningTimer.Dispose();
            updateTimer.Stop();
            updateTimer.Dispose();
            uiThread.Dispose();
            notifyIcon.Visible = false;
            notifyIcon.Dispose();
            icon.Dispose();
            base.ExitThreadCore();
        }
    }

    // Main window shell: sidebar navigation (Start, Schutzbereiche,
    // Einstellungen, Mehr), the always-visible status card, background status
    // refresh and the shared RunAction plumbing. Pages live in
    // src/UI/Pages/*.cs and dialogs in src/UI/Dialogs/*.cs as partial parts of
    // this class; shared styling lives in src/UI/Theme.cs. No protection or
    // enforcement logic is defined here - everything goes through Support.*.
    internal sealed partial class AdminForm : Form
    {
        private const int SidebarWidth = 220;

        private UiTheme theme = UiTheme.Light;
        private readonly string themePreferencePath = Path.Combine(Support.DataDir, "ui-theme.txt");

        // Flat status area with a hand-drawn state glyph. Different SHAPES per
        // state (circle+check, triangle+!, circle+!, pause bars) so status is
        // never color-only information.
        private sealed class StatusPanel : Panel
        {
            public string GlyphKind = "active";
            public Color GlyphColor = Color.Black;
            public Rectangle GlyphBounds = Rectangle.Empty;

            public StatusPanel()
            {
                SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);
                if (!GlyphBounds.IsEmpty)
                {
                    DrawStatusGlyph(e.Graphics, GlyphBounds, GlyphKind, GlyphColor);
                }
            }

            private static void DrawStatusGlyph(Graphics g, Rectangle box, string kind, Color color)
            {
                System.Drawing.Drawing2D.SmoothingMode previous = g.SmoothingMode;
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using (Pen pen = new Pen(color, 2.2f)
                {
                    StartCap = System.Drawing.Drawing2D.LineCap.Round,
                    EndCap = System.Drawing.Drawing2D.LineCap.Round,
                    LineJoin = System.Drawing.Drawing2D.LineJoin.Round
                })
                using (Brush dotBrush = new SolidBrush(color))
                {
                    float cx = box.Left + box.Width / 2f;
                    switch (kind)
                    {
                        case "restricted":
                            PointF top = new PointF(cx, box.Top + box.Height * 0.06f);
                            PointF bl = new PointF(box.Left + box.Width * 0.06f, box.Bottom - box.Height * 0.10f);
                            PointF br = new PointF(box.Right - box.Width * 0.06f, box.Bottom - box.Height * 0.10f);
                            using (var triangle = new System.Drawing.Drawing2D.GraphicsPath())
                            {
                                triangle.AddPolygon(new[] { top, bl, br });
                                g.DrawPath(pen, triangle);
                            }
                            g.DrawLine(pen, cx, box.Top + box.Height * 0.38f, cx, box.Top + box.Height * 0.64f);
                            g.FillEllipse(dotBrush, cx - 1.4f, box.Top + box.Height * 0.74f, 2.8f, 2.8f);
                            break;
                        case "repair":
                            g.DrawEllipse(pen, box);
                            g.DrawLine(pen, cx, box.Top + box.Height * 0.28f, cx, box.Top + box.Height * 0.58f);
                            g.FillEllipse(dotBrush, cx - 1.4f, box.Top + box.Height * 0.70f, 2.8f, 2.8f);
                            break;
                        case "paused":
                            g.DrawEllipse(pen, box);
                            float pauseTop = box.Top + box.Height * 0.32f;
                            float pauseBottom = box.Bottom - box.Height * 0.32f;
                            float x1 = box.Left + box.Width * 0.38f;
                            float x2 = box.Right - box.Width * 0.38f;
                            g.DrawLine(pen, x1, pauseTop, x1, pauseBottom);
                            g.DrawLine(pen, x2, pauseTop, x2, pauseBottom);
                            break;
                        case "idle":
                            // Ruhiger Neutral-Zustand (noch kein Schutzbereich an):
                            // Kreis + "i" - Punkt oben, senkrechter Strich darunter,
                            // wie UiIcon.Information in Ui.DrawIcon (src/UI/Theme.cs).
                            g.DrawEllipse(pen, box);
                            g.FillEllipse(dotBrush, cx - 1.4f, box.Top + box.Height * 0.26f, 2.8f, 2.8f);
                            g.DrawLine(pen, cx, box.Top + box.Height * 0.46f, cx, box.Top + box.Height * 0.72f);
                            break;
                        default:
                            g.DrawEllipse(pen, box);
                            PointF p1 = new PointF(box.Left + box.Width * 0.27f, box.Top + box.Height * 0.52f);
                            PointF p2 = new PointF(box.Left + box.Width * 0.43f, box.Top + box.Height * 0.68f);
                            PointF p3 = new PointF(box.Left + box.Width * 0.76f, box.Top + box.Height * 0.33f);
                            g.DrawLines(pen, new[] { p1, p2, p3 });
                            break;
                    }
                }
                g.SmoothingMode = previous;
            }
        }

        private readonly Panel sidebarPanel;
        private readonly Panel mainPanel;
        private readonly StatusPanel statusCard;
        private readonly Label statusLabel;
        private readonly Label statusHintLabel;
        private readonly Label feedbackLabel;
        private readonly Timer feedbackTimer;
        private LinkLabel detailsLink;
        private string detailsText = "Der Schutzstatus wird noch ermittelt.";
        private readonly Panel pageHost;
        private Button activateButton;
        private Button pauseButton;
        private Button repairButton;
        private Button setupButton;
        private Label devModeSidebarLabel;
        private string currentPageKey = "start";
        private bool statusNeedsRepair;
        private bool statusNoAreas;

        private readonly List<Button> actionButtons = new List<Button>();
        private readonly Dictionary<string, Panel> pages = new Dictionary<string, Panel>();
        private readonly Dictionary<string, Button> navButtons = new Dictionary<string, Button>();
        private readonly Timer refreshTimer;
        private volatile bool refreshInFlight;

        private enum ProtectionStatusKind
        {
            Active,
            Restricted,
            NeedsRepair,
            Paused,
            NoAreas
        }

        private sealed class StatusSnapshot
        {
            public ProtectionStatusKind Kind;
            public string StatusText;
            public string HintText;
            public Color StatusColor;
            public string DetailsText;
            public string[] AreaStatusLines;
        }

        public AdminForm()
        {
            theme = LoadThemePreference();

            string productName = "Purestate " + Support.AppVersion;
            Text = productName;
            Icon = PurestateVisualIdentity.CreateIcon(32);
            Ui.PrepareForm(this, productName, "Purestate Verwaltungsfenster: Schutzstatus, Schutzbereiche, Einstellungen und Werkzeuge.");
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.Sizable;
            MaximizeBox = true;
            MinimumSize = new Size(900, 640);
            ClientSize = new Size(980, 720);
            // Wie DialogShell.FinishLayout: nicht groesser als der Arbeitsbereich.
            // Auf 1366x768 ragte das Fenster sonst unter die Taskleiste, und der
            // unten angedockte Datenschutzhinweis war abgeschnitten (VM 2026-09-28).
            Rectangle work = Screen.FromPoint(Cursor.Position).WorkingArea;
            Size = new Size(Math.Min(Width, work.Width), Math.Min(Height, work.Height));
            BackColor = theme.WindowBackground;
            HandleCreated += delegate { Ui.ApplyDarkTitleBar(Handle, theme.IsDark); };
            Shown += delegate { RunUpdateStartupTasks(); };

            // Die Durchsetzung hat den Rechner schon freigegeben (siehe
            // IsEntitlementExpiredAt) - egal ob die Berechtigung ausgelaufen ist
            // oder die eingebaute Fassungsgrenze erreicht wurde. Diese Seite
            // ersetzt die normale Verwaltungsoberflaeche komplett, statt sie nur
            // zu verdecken: es gibt nichts mehr zu verwalten.
            if (Support.IsEntitlementExpired(Support.LoadConfig()))
            {
                BuildExpiredScreen();
                return;
            }

            // Dock order: Fill first, then Left, so the sidebar sits beside the
            // content instead of painting over it.
            mainPanel = new Panel { Dock = DockStyle.Fill, BackColor = theme.WindowBackground };
            Controls.Add(mainPanel);

            sidebarPanel = new Panel { Dock = DockStyle.Left, Width = SidebarWidth, BackColor = theme.SidebarBackground };
            Controls.Add(sidebarPanel);

            pageHost = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = theme.WindowBackground };
            Ui.ApplyScrollbarTheme(pageHost, theme.IsDark);
            mainPanel.Controls.Add(pageHost);

            Panel separator = new Panel { Dock = DockStyle.Top, Height = 1, BackColor = theme.Divider };
            mainPanel.Controls.Add(separator);
            themeAppliers.Add(delegate { separator.BackColor = theme.Divider; });

            // Status + the one most important action stay visible on every page.
            statusCard = new StatusPanel { Dock = DockStyle.Top, Height = 140, BackColor = theme.CardBackground };
            statusCard.GlyphBounds = new Rectangle(28, 26, 30, 30);
            Ui.SetAccessibility(statusCard, "Schutzstatus", "Aktueller Purestate Schutzstatus mit der wichtigsten Aktion.", AccessibleRole.Grouping);

            // DESK-02: keine rechten Anker mehr - LayoutStatusCard setzt Breite
            // und Hoehe nach der echten Kartenbreite und der Textlaenge.
            statusLabel = new Label
            {
                Location = new Point(76, 22),
                Size = new Size(700, 30),
                AutoSize = false,
                Font = Ui.FontStatus,
                BackColor = Color.Transparent
            };
            statusCard.Controls.Add(statusLabel);
            Ui.SetAccessibility(statusLabel, "Aktueller Schutzstatus", "Zeigt in einfacher Sprache, ob Purestate dieses Gerät gerade schützt.", AccessibleRole.StaticText);

            statusHintLabel = new Label
            {
                Location = new Point(78, 54),
                Size = new Size(700, 20),
                AutoSize = false,
                Font = Ui.FontHint,
                ForeColor = theme.TextSecondary,
                BackColor = Color.Transparent
            };
            statusCard.Controls.Add(statusHintLabel);
            Ui.SetAccessibility(statusHintLabel, "Statushinweis", "Erklärt den nächsten sinnvollen Schritt.", AccessibleRole.StaticText);

            activateButton = Ui.PrimaryButton(theme, "&Schutz aktivieren", "Aktiviert den Purestate Schutz sofort.");
            activateButton.Location = new Point(32, 88);
            activateButton.Click += delegate { ActivateProtection(); };
            statusCard.Controls.Add(activateButton);
            actionButtons.Add(activateButton);

            setupButton = Ui.PrimaryButton(theme, "Schutzbereiche einstellen", "Öffnet die Seite Schutzbereiche.");
            setupButton.Location = new Point(32, 88);
            setupButton.Visible = false;
            setupButton.Click += delegate { NavigateTo("areas"); };
            statusCard.Controls.Add(setupButton);
            actionButtons.Add(setupButton);

            repairButton = Ui.PrimaryButton(theme, "&Jetzt reparieren", "Repariert den Purestate Schutz automatisch.");
            repairButton.Location = new Point(32, 88);
            repairButton.Visible = false;
            repairButton.Click += delegate { RepairApp(); };
            statusCard.Controls.Add(repairButton);
            actionButtons.Add(repairButton);

            pauseButton = Ui.SecondaryButton(theme, "Schutz &pausieren", "Öffnet die Auswahl, wie lange der Schutz pausiert werden soll.");
            pauseButton.Location = new Point(200, 88);
            pauseButton.Click += delegate { PauseProtection(); };
            statusCard.Controls.Add(pauseButton);
            actionButtons.Add(pauseButton);

            detailsLink = new LinkLabel
            {
                Text = "Technische Details anzeigen",
                Location = new Point(390, 98),
                AutoSize = true,
                LinkColor = theme.Accent,
                Font = Ui.FontHint,
                BackColor = Color.Transparent
            };
            Ui.SetAccessibility(detailsLink, "Technische Details anzeigen", "Zeigt den vollständigen technischen Schutzstatus als kopierbaren Bericht.", AccessibleRole.Link);
            detailsLink.LinkClicked += delegate { ShowTextDialog("Technische Details", detailsText, true); };
            statusCard.Controls.Add(detailsLink);

            // Quiet inline confirmation ("Änderungen gespeichert.") instead of a
            // MessageBox after every successful save.
            feedbackLabel = new Label
            {
                Location = new Point(78, 118),
                Size = new Size(700, 18),
                AutoSize = false,
                Font = Ui.FontHint,
                ForeColor = theme.StatusActive,
                BackColor = Color.Transparent,
                Text = string.Empty
            };
            statusCard.Controls.Add(feedbackLabel);
            Ui.SetAccessibility(feedbackLabel, "Rückmeldung", "Bestätigt gespeicherte Änderungen und abgeschlossene Aktionen.", AccessibleRole.StaticText);
            feedbackTimer = new Timer { Interval = 6000 };
            feedbackTimer.Tick += delegate
            {
                feedbackTimer.Stop();
                Ui.SetDynamicText(feedbackLabel, string.Empty, "Rückmeldung");
                LayoutStatusCard();
            };

            statusCard.Resize += delegate { LayoutStatusCard(); };
            mainPanel.Controls.Add(statusCard);
            LayoutStatusCard();

            BuildSidebar();
            BuildStartPage();
            BuildProtectionAreasPage();
            BuildSettingsPage();
            BuildMorePage();

            ApplyThemeColors();
            NavigateTo("start");
            RefreshStatus();

            string entitlementWarning;
            if (Program.DueEntitlementWarningMessage(out entitlementWarning, true) > 0)
            {
                Ui.Inform(this, theme, "Purestate", entitlementWarning);
            }

            refreshTimer = new Timer { Interval = 4000 };
            refreshTimer.Tick += delegate { RefreshStatus(); };
            refreshTimer.Start();
            FormClosed += delegate { refreshTimer.Stop(); };
        }

        // Der Ablaufbildschirm (siehe AdminForm()-Weiche oben). Steht fuer sich
        // allein statt in pages/pageHost zu haengen, weil es hier nichts zu
        // navigieren gibt. Das Scrollen uebernimmt deshalb das Fenster selbst -
        // sonst waere bei grosser Systemschrift oder hoher Skalierung
        // ausgerechnet auf diesem Bildschirm der Ausweg "Purestate entfernen"
        // unter den Fensterrand geschoben und unerreichbar.
        private void BuildExpiredScreen()
        {
            AutoScroll = true;
            Ui.ApplyScrollbarTheme(this, theme.IsDark);

            TableLayoutPanel content = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 1,
                Padding = new Padding(Ui.PagePadding, Ui.GapSection, Ui.PagePadding, Ui.GapSection),
                BackColor = theme.WindowBackground
            };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            Controls.Add(content);

            AddPageTitle(content, "Beta beendet");

            // Ein abgelaufener Freischaltcode ist reaktivierbar (Verlaengerung
            // ueber denselben Code, siehe EnrollAuthorityDevice), deshalb bleibt
            // die Schaltflaeche unten erreichbar. Nur wenn die eingebaute
            // Fassungsgrenze erreicht ist, ist sie ausgegraut statt versteckt -
            // EnrollAuthorityDevice wuerde jeden Code ohnehin ablehnen.
            //
            // Der Text folgt genau demselben Schnitt. Unbedingt "laesst sich
            // nicht mehr freischalten" zu behaupten waere im Verlaengerungsfall
            // schlicht falsch: es stuende ueber einer Schaltflaeche, die genau
            // das tut, und schickte den Tester auf die Suche nach einem
            // Download, statt seinen verlaengerten Code einzuloesen.
            bool buildExpired = Support.IsBuildExpired(Support.LoadConfig());
            content.Controls.Add(Ui.WrapLabel(theme,
                "Der Beta-Zeitraum ist abgelaufen. Purestate beendet den Schutz und nimmt seine Systemänderungen automatisch zurück. Falls noch Sperren bestehen, kannst du Purestate unten entfernen." +
                Environment.NewLine + Environment.NewLine +
                (buildExpired
                    ? "Die neue Fassung findest du unter purestate-app.com. Diese Beta-Fassung lässt sich nicht mehr freischalten."
                    // "demselben", nicht "einem neuen": die Verlaengerung laeuft
                    // ueber denselben Code mit neuem Datum vom Server, und
                    // docs\BETA-TESTER-GUIDE.md sagt dem Tester genau das.
                    : "Mit demselben Freischaltcode läuft Purestate weiter."),
                Ui.ContentMaxWidth, false));

            FlowLayoutPanel buttonRow = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                AutoSize = true,
                Margin = new Padding(0, Ui.GapGroup, 0, 0)
            };
            content.Controls.Add(buttonRow);

            Button newVersionButton = Ui.PrimaryButton(theme, "&Zur neuen Fassung",
                "Sucht die neue Fassung und bietet die Installation an. Ohne Verbindung öffnet sie purestate-app.com im Standardbrowser.");
            newVersionButton.Click += delegate { CheckForNewVersionOrOpenWebsite(); };
            buttonRow.Controls.Add(newVersionButton);
            actionButtons.Add(newVersionButton);

            Button removeButton = Ui.SecondaryButton(theme, "Purestate &entfernen",
                "Startet die Deinstallation von Purestate.");
            removeButton.Margin = new Padding(Ui.GapGroup, 0, 0, 0);
            removeButton.Click += delegate { LaunchUninstaller(); };
            buttonRow.Controls.Add(removeButton);
            actionButtons.Add(removeButton);

            Button reactivateButton = Ui.SecondaryButton(theme, "&Freischaltcode eingeben",
                buildExpired
                    ? "Diese Fassung ist beendet und nimmt keinen Freischaltcode mehr an."
                    : "Öffnet die Eingabe für deinen Freischaltcode.");
            reactivateButton.Margin = new Padding(Ui.GapGroup, 0, 0, 0);
            reactivateButton.Enabled = !buildExpired;
            reactivateButton.Click += delegate
            {
                EnrollAuthorityDevice();
            };
            buttonRow.Controls.Add(reactivateButton);
            if (!buildExpired)
            {
                actionButtons.Add(reactivateButton);
            }
        }

        private UiTheme LoadThemePreference()
        {
            if (SystemInformation.HighContrast)
            {
                return UiTheme.HighContrast();
            }
            try
            {
                if (File.Exists(themePreferencePath) &&
                    string.Equals(File.ReadAllText(themePreferencePath).Trim(), "dark", StringComparison.OrdinalIgnoreCase))
                {
                    return UiTheme.Dark;
                }
            }
            catch
            {
            }
            return UiTheme.Light;
        }

        private void SaveThemePreference()
        {
            try
            {
                Support.EnsureDataDir();
                File.WriteAllText(themePreferencePath, theme.IsDark ? "dark" : "light", Encoding.ASCII);
            }
            catch
            {
            }
        }

        private void ToggleTheme()
        {
            if (theme.IsHighContrast)
            {
                return;
            }
            theme = theme.IsDark ? UiTheme.Light : UiTheme.Dark;
            SaveThemePreference();
            Ui.ApplyDarkTitleBar(Handle, theme.IsDark);
            ApplyThemeColors();
        }

        // Recolors the chrome after a theme toggle. Pages register their
        // re-theme handlers in themeAppliers, so nothing is left half-themed.
        private readonly List<Action> themeAppliers = new List<Action>();

        private void ApplyThemeColors()
        {
            BackColor = theme.WindowBackground;
            mainPanel.BackColor = theme.WindowBackground;
            pageHost.BackColor = theme.WindowBackground;
            Ui.ApplyScrollbarTheme(pageHost, theme.IsDark);
            statusCard.BackColor = theme.CardBackground;
            statusCard.Invalidate();
            sidebarPanel.BackColor = theme.SidebarBackground;
            statusLabel.ForeColor = theme.TextPrimary;
            statusHintLabel.ForeColor = theme.TextSecondary;
            feedbackLabel.ForeColor = theme.StatusActive;
            detailsLink.LinkColor = theme.Accent;
            Ui.StylePrimary(theme, activateButton);
            Ui.StylePrimary(theme, setupButton);
            Ui.StylePrimary(theme, repairButton);
            Ui.StyleSecondary(theme, pauseButton);

            foreach (Panel page in pages.Values)
            {
                page.BackColor = theme.WindowBackground;
            }
            foreach (Action apply in themeAppliers)
            {
                apply();
            }
            foreach (KeyValuePair<string, Button> entry in navButtons)
            {
                bool active = string.Equals(entry.Key, currentPageKey, StringComparison.Ordinal);
                entry.Value.BackColor = active ? theme.AccentTint : theme.SidebarBackground;
                entry.Value.ForeColor = active ? (theme.IsHighContrast ? SystemColors.HighlightText : theme.Accent) : theme.TextPrimary;
                entry.Value.Font = active ? Ui.FontBodyBold : Ui.FontBody;
                RoundButton round = entry.Value as RoundButton;
                if (round != null)
                {
                    round.FocusRingColor = theme.Accent;
                    // F1: wie Ui.StyleRound - aus dem eigenen Vordergrund/
                    // Hintergrund-Paar statt aus einer Palettenkonstante.
                    round.DisabledForeColor = theme.IsHighContrast
                        ? SystemColors.GrayText
                        : Ui.Mix(entry.Value.ForeColor, entry.Value.BackColor, 40);
                    round.Square = theme.IsHighContrast;
                }
                entry.Value.Invalidate();
            }
            RefreshStatus();
        }

        private void BuildSidebar()
        {
            Label appTitle = new Label
            {
                Text = "Purestate",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = theme.TextPrimary,
                Location = new Point(24, 24),
                Size = new Size(SidebarWidth - 40, 28)
            };
            sidebarPanel.Controls.Add(appTitle);

            Label versionLabel = new Label
            {
                Text = "Version " + Support.AppVersion,
                Font = Ui.FontHint,
                ForeColor = theme.TextSecondary,
                Location = new Point(24, 52),
                Size = new Size(SidebarWidth - 40, 20)
            };
            sidebarPanel.Controls.Add(versionLabel);

            // Persistent DEV-MODE indicator - always visible while a
            // dev-companion override is active (it weakens the browser-trust check).
            devModeSidebarLabel = new Label
            {
                Text = "DEV-MODUS AKTIV",
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = theme.StatusRestricted,
                Location = new Point(24, 72),
                Size = new Size(SidebarWidth - 40, 18),
                Visible = false
            };
            Ui.SetAccessibility(devModeSidebarLabel, "Dev-Modus aktiv", "Eine nicht-offizielle Browser-Erweiterung wird zusätzlich vertraut. Nur für Entwicklung.", AccessibleRole.StaticText);
            sidebarPanel.Controls.Add(devModeSidebarLabel);

            int y = 100;
            y = AddNavItem("start", "Start", UiIcon.Home, y);
            y = AddNavItem("areas", "Schutzbereiche", UiIcon.Shield, y);
            y = AddNavItem("settings", "Einstellungen", UiIcon.Settings, y);
            AddNavItem("more", "Mehr", UiIcon.More, y);

            // WS-03: "sendet nichts ins Internet" war falsch - Familien-DNS ist
            // Standard, und fuer Reddit/Bluesky fragt der Browser-Schutz
            // oeffentliche Plattform-Schnittstellen ab (Vertrag V-1, V-6..V-8).
            string privacyText = "Purestate wertet auf diesem Gerät aus und lädt keine Seiteninhalte hoch. " +
                "Ausnahmen: Der Internetfilter (DNS-Anbieter) sieht aufgerufene Domains, und für Reddit und Bluesky " +
                "fragt der Browser-Schutz deren öffentliche Schnittstellen ab.";
            if (Support.ServerAuthorityUiAvailable(Support.LoadConfig()))
            {
                privacyText += " Zur Freischaltung und Verlängerung spricht die App mit dem Purestate-Server; im Servermodus auch für Lockerungen.";
            }
            Label privacyNote = new Label
            {
                Text = privacyText,
                Font = Ui.FontHint,
                ForeColor = theme.TextSecondary,
                Dock = DockStyle.Bottom,
                Padding = new Padding(24, 8, 16, 16),
                AutoSize = false
            };
            privacyNote.Height = TextRenderer.MeasureText(privacyText, Ui.FontHint,
                new Size(SidebarWidth - privacyNote.Padding.Horizontal, 0), TextFormatFlags.WordBreak).Height + privacyNote.Padding.Vertical + 4;
            sidebarPanel.Controls.Add(privacyNote);
            themeAppliers.Add(delegate
            {
                appTitle.ForeColor = theme.TextPrimary;
                versionLabel.ForeColor = theme.TextSecondary;
                devModeSidebarLabel.ForeColor = theme.StatusRestricted;
                privacyNote.ForeColor = theme.TextSecondary;
            });
        }

        private int AddNavItem(string key, string label, UiIcon icon, int y)
        {
            Panel row = new Panel
            {
                Location = new Point(8, y),
                Size = new Size(SidebarWidth - 16, 46),
                BackColor = theme.SidebarBackground
            };
            RoundButton button = new RoundButton
            {
                Dock = DockStyle.Fill,
                Text = label,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(44, 0, 0, 0),
                FlatStyle = FlatStyle.Flat,
                Font = Ui.FontBody,
                BackColor = theme.SidebarBackground,
                ForeColor = theme.TextPrimary,
                // Website-Look: aktiver Eintrag als gerundete Teal-Flaeche.
                CornerRadius = 8,
                Icon = icon,
                FocusRingColor = theme.Accent,
                Square = theme.IsHighContrast
            };
            button.FlatAppearance.BorderSize = 0;
            Ui.SetAccessibility(button, label, "Öffnet den Bereich " + label + ".", AccessibleRole.PushButton);
            button.Click += delegate { NavigateTo(key); };
            button.MouseEnter += delegate
            {
                if (!string.Equals(currentPageKey, key, StringComparison.Ordinal))
                {
                    button.BackColor = Ui.Mix(theme.SidebarBackground, theme.IsDark ? Color.White : Color.Black, 8);
                }
            };
            button.MouseLeave += delegate
            {
                bool active = string.Equals(currentPageKey, key, StringComparison.Ordinal);
                button.BackColor = active ? theme.AccentTint : theme.SidebarBackground;
            };
            row.Controls.Add(button);
            sidebarPanel.Controls.Add(row);
            navButtons[key] = button;
            themeAppliers.Add(delegate { row.BackColor = theme.SidebarBackground; });
            return y + 46;
        }

        private void NavigateTo(string key)
        {
            pageHost.Controls.Clear();
            pageHost.Controls.Add(pages[key]);
            pageHost.AutoScrollPosition = new Point(0, 0);
            currentPageKey = key;

            if (string.Equals(key, "settings", StringComparison.Ordinal))
            {
                UpdateWeakeningRow();
            }

            foreach (KeyValuePair<string, Button> entry in navButtons)
            {
                bool active = string.Equals(entry.Key, key, StringComparison.Ordinal);
                entry.Value.BackColor = active ? theme.AccentTint : theme.SidebarBackground;
                entry.Value.ForeColor = active ? (theme.IsHighContrast ? SystemColors.HighlightText : theme.Accent) : theme.TextPrimary;
                entry.Value.Font = active ? Ui.FontBodyBold : Ui.FontBody;
                entry.Value.Invalidate();
            }
        }

        // Pages are single-column TableLayoutPanels docked Top: full width,
        // auto height, vertical scrolling via pageHost.AutoScroll.
        private TableLayoutPanel CreatePage(string key)
        {
            TableLayoutPanel page = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 1,
                Padding = new Padding(Ui.PagePadding, Ui.GapSection, Ui.PagePadding, Ui.GapSection),
                BackColor = theme.WindowBackground
            };
            page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            pages[key] = page;
            return page;
        }

        private void AddPageTitle(TableLayoutPanel page, string title)
        {
            Label kicker = Ui.MonoLabel(theme, "Purestate");
            page.Controls.Add(kicker);
            themeAppliers.Add(delegate { kicker.ForeColor = theme.TextSecondary; });

            Label label = new Label
            {
                Text = title,
                Font = Ui.FontPageTitle,
                ForeColor = theme.TextPrimary,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, Ui.GapSmall)
            };
            Ui.SetAccessibility(label, title, "Seite " + title + ".", AccessibleRole.StaticText);
            page.Controls.Add(label);
            themeAppliers.Add(delegate { label.ForeColor = theme.TextPrimary; });
        }

        private void AddSectionTitle(TableLayoutPanel page, string title)
        {
            Label label = new Label
            {
                Text = title,
                Font = Ui.FontSection,
                ForeColor = theme.TextPrimary,
                AutoSize = true,
                Margin = new Padding(0, Ui.GapSection, 0, Ui.GapSmall)
            };
            Ui.SetAccessibility(label, title, "Abschnitt " + title + ".", AccessibleRole.StaticText);
            page.Controls.Add(label);
            themeAppliers.Add(delegate { label.ForeColor = theme.TextPrimary; });
        }

        private Label AddPageHint(TableLayoutPanel page, string text)
        {
            Label hint = Ui.WrapLabel(theme, text, Ui.ContentMaxWidth, true);
            page.Controls.Add(hint);
            themeAppliers.Add(delegate { hint.ForeColor = theme.TextSecondary; });
            return hint;
        }

        // Grouped command row: short action on the right, explanation beside it.
        // Liefert die Zeile zurueck, damit Aufrufer mit veraenderlichem Text
        // (siehe Abschnitt "Einstellungen lockern") Beschriftung und
        // Schaltflaeche spaeter aktualisieren koennen. Bestehende Aufrufer
        // ignorieren den Rueckgabewert.
        private TableLayoutPanel AddActionRow(TableLayoutPanel page, string title, string description, string actionText, EventHandler onClick, bool danger)
        {
            TableLayoutPanel row = (TableLayoutPanel)Ui.CommandRow(theme, title,
                description, actionText, description, onClick);
            Button button = (Button)row.GetControlFromPosition(1, 0);
            if (danger)
            {
                button.ForeColor = theme.DangerRed;
                button.Tag = "danger";
            }
            page.Controls.Add(row);
            actionButtons.Add(button);
            themeAppliers.Add(delegate
            {
                Ui.StyleCard(theme, (RoundCard)row);
                TableLayoutPanel copy = row.GetControlFromPosition(0, 0) as TableLayoutPanel;
                if (copy != null)
                {
                    Label titleLabel = copy.GetControlFromPosition(0, 0) as Label;
                    Label descriptionLabel = copy.GetControlFromPosition(0, 1) as Label;
                    if (titleLabel != null) titleLabel.ForeColor = danger ? theme.DangerRed : theme.TextPrimary;
                    if (descriptionLabel != null) descriptionLabel.ForeColor = theme.TextSecondary;
                }
                Ui.StyleSecondary(theme, button);
                button.ForeColor = danger ? theme.DangerRed : theme.TextPrimary;
            });
            return row;
        }

        // ------------------------------------------------------------------
        // Status: gathered on a background thread (registry, hosts file,
        // scheduled tasks and powershell queries are too slow for the UI
        // thread), applied on the UI thread.
        // ------------------------------------------------------------------

        private void RefreshStatus()
        {
            if (statusCard == null || refreshInFlight)
            {
                return;
            }

            refreshInFlight = true;
            UiTheme currentTheme = theme;
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                StatusSnapshot snapshot = null;
                try
                {
                    snapshot = BuildStatusSnapshot(currentTheme);
                }
                catch
                {
                }
                finally
                {
                    refreshInFlight = false;
                }

                if (snapshot == null)
                {
                    return;
                }

                try
                {
                    if (IsHandleCreated && !IsDisposed)
                    {
                        BeginInvoke(new Action(delegate { ApplyStatusSnapshot(snapshot); }));
                    }
                }
                catch
                {
                }
            });
        }

        private static StatusSnapshot BuildStatusSnapshot(UiTheme theme)
        {
            AppConfig config = Support.LoadConfig();
            bool service = Support.ServiceRunning();
            bool hosts = Support.HostsActive();
            bool dns = Support.FamilyDnsActive();
            bool browserHardening = Support.BrowserHardeningActive();
            int bypassRules = Support.CountBypassFirewallRules();
            // BYS-002: Nur noetig, wenn es KEINE Regeln gibt - dann entscheidet
            // sich, ob null Regeln der Sollzustand ist. Die Zaehlung laeuft ueber
            // alle laufenden Prozesse; bei vorhandenen Regeln waere sie bei jeder
            // Statusaktualisierung verschenkt.
            int bypassToolIndicators = bypassRules > 0 ? 0 : Support.CountBypassToolIndicators();
            int browserBlockRules = Support.CountUnsupportedBrowserFirewallRules();
            bool watchdog = Support.WatchdogTaskRegistered();
            string pauseDescription = Support.PauseDescription(config);
            bool shouldProtect = Support.ProtectionShouldBeActive(config);
            string chromeStatus = Support.ChromeCompanionStatus();
            string edgeStatus = Support.EdgeCompanionStatus();
            string firefoxStatus = Support.FirefoxMixedSiteStatus();
            string scheduleDescription = Support.ScheduleDescription(config);

            StatusSnapshot snapshot = new StatusSnapshot();

            // STA-003: Die Bewertung hing frueher allein an der hosts-Datei.
            // DNS, Browser-Richtlinien, Umgehungsschutz und Watchdog wurden
            // erhoben, gingen aber nur in den Detailtext ein - wer den
            // DNS-Schutz verloren hatte, las trotzdem "Alle aktivierten
            // Schutzbereiche funktionieren".
            string[] failedLayers = Support.FindFailedProtectionLayers(
                config.HostsEnabled, hosts,
                config.FamilyDnsEnabled, dns,
                config.BrowserPoliciesEnabled, Support.BrowserPoliciesActive(),
                config.BypassBlockingEnabled,
                Support.BypassBlockingEffective(bypassRules, bypassToolIndicators),
                watchdog);

            if (shouldProtect && service && failedLayers.Length == 0 && !Support.AnyProtectionAreaActive(config))
            {
                snapshot.Kind = ProtectionStatusKind.NoAreas;
                snapshot.StatusText = "Noch kein Schutzbereich eingeschaltet";
                snapshot.HintText = "Purestate ist bereit. Wähle unter „Schutzbereiche“, wovor es dich schützen soll.";
                snapshot.StatusColor = theme.StatusPaused;
            }
            else if (shouldProtect && service && failedLayers.Length == 0)
            {
                snapshot.Kind = ProtectionStatusKind.Active;
                snapshot.StatusText = "Purestate schützt dieses Gerät";
                snapshot.HintText = Support.IsScheduleActiveNow(config) && !config.ProtectionEnabled
                    ? "Der Schutz ist gerade durch den Zeitplan aktiv."
                    : "Alle aktivierten Schutzbereiche funktionieren.";
                snapshot.StatusColor = theme.StatusActive;
            }
            else if (shouldProtect && service)
            {
                snapshot.Kind = ProtectionStatusKind.Restricted;
                snapshot.StatusText = "Ein Teil des Schutzes funktioniert nicht";
                // Die betroffene Schicht nennen, statt pauschal zu warnen: sonst
                // weiss der Nutzer nicht, was fehlt, und der Hinweis nutzt sich ab.
                snapshot.HintText = failedLayers.Length > 0
                    ? "Nicht wirksam: " + string.Join(", ", failedLayers) + ". Klicke auf „Jetzt reparieren“."
                    : "Einige Schutzregeln sind noch nicht angewendet. Klicke auf „Jetzt reparieren“.";
                snapshot.StatusColor = theme.StatusRestricted;
            }
            else if (shouldProtect)
            {
                snapshot.Kind = ProtectionStatusKind.NeedsRepair;
                snapshot.StatusText = "Ein Teil des Schutzes funktioniert nicht";
                snapshot.HintText = "Der Schutzdienst läuft nicht. Klicke auf „Jetzt reparieren“.";
                snapshot.StatusColor = theme.StatusRepair;
            }
            else
            {
                snapshot.Kind = ProtectionStatusKind.Paused;
                if (pauseDescription.StartsWith("bis ", StringComparison.OrdinalIgnoreCase))
                {
                    snapshot.StatusText = "Der Schutz ist pausiert " + pauseDescription;
                    snapshot.HintText = "Bis dahin werden die gewählten Sperren nicht angewendet.";
                }
                else
                {
                    snapshot.StatusText = "Der Schutz ist ausgeschaltet";
                    snapshot.HintText = "Klicke auf „Schutz aktivieren“, um die gewählten Sperren anzuwenden.";
                }
                snapshot.StatusColor = theme.StatusPaused;
            }

            snapshot.AreaStatusLines = BuildAreaStatusLines(config);

            snapshot.DetailsText =
                "Dienst läuft: " + YesNo(service) + Environment.NewLine +
                "Inhalts-Sperrliste aktiv: " + YesNo(hosts) + Environment.NewLine +
                "DNS-Inhaltsfilter aktiv: " + YesNo(dns) + Environment.NewLine +
                "Chrome: " + chromeStatus + Environment.NewLine +
                "Edge: " + edgeStatus + Environment.NewLine +
                "Firefox: " + firefoxStatus + Environment.NewLine +
                "Browser-Umgehungsschutz aktiv: " + YesNo(browserHardening) + Environment.NewLine +
                "Umgehungsschutz-Regeln: " + bypassRules + Environment.NewLine +
                "Browser-Block-Regeln: " + browserBlockRules + Environment.NewLine +
                "Watchdog eingerichtet: " + YesNo(watchdog) + Environment.NewLine +
                "Pause: " + pauseDescription + " | Sperrmodus: " + YesNo(config.LockdownModeEnabled) + Environment.NewLine +
                "Zeitplan: " + scheduleDescription + Environment.NewLine +
                "Webseiten-Schutz aktiv: " + Support.EnabledSiteProtectionCount(config) + " von " + Support.SiteProtectionTotal + Environment.NewLine +
                "Adressen in Listen: " + Support.CountDomains() +
                DescribeCanaryFailClosedBlocks();

            return snapshot;
        }

        // GRD-022: Eine Canary-Sperre entsteht, wenn ein Erkennungsskript auf
        // einer zugeordneten Seite seinen Anker nicht mehr findet - ein Umbau
        // der Seite loest sie bei allen Nutzern gleichzeitig aus. Sie ist
        // gewollt, stand aber ohne jede Erklaerung in der Oberflaeche. Nichts
        // anzeigen, solange keine Sperre aktiv ist: eine Dauerzeile "keine"
        // nutzt sich ab und verdraengt die Zeilen, die immer zaehlen.
        private static string DescribeCanaryFailClosedBlocks()
        {
            string[] blocks = Support.ActiveCanaryFailClosedBlocks(
                Support.CanaryFailClosedPath,
                DateTime.UtcNow);
            if (blocks.Length == 0)
            {
                return string.Empty;
            }

            StringBuilder text = new StringBuilder();
            text.Append(Environment.NewLine);
            text.Append("Automatisch gesperrt (Prüfung greift nicht):");
            foreach (string block in blocks)
            {
                text.Append(Environment.NewLine);
                text.Append("  " + block);
            }
            return text.ToString();
        }

        // One plain-language line per protection area, e.g.
        // "Social Media|Zeitlimit 45 Minuten täglich".
        private static string[] BuildAreaStatusLines(AppConfig config)
        {
            List<string> lines = new List<string>();
            ProtectionAreaSnapshot[] areas = Support.BuildProtectionAreaSnapshots(config);
            foreach (ProtectionAreaSnapshot area in areas)
            {
                lines.Add(area.Id + "|" + AreaDisplayName(area.Id) + "|" + DescribeAreaStatus(config, area));
            }
            return lines.ToArray();
        }

        private static string AreaDisplayName(string areaId)
        {
            if (string.Equals(areaId, Support.AreaAdultContent, StringComparison.OrdinalIgnoreCase)) { return "Erwachseneninhalte"; }
            if (string.Equals(areaId, Support.AreaGambling, StringComparison.OrdinalIgnoreCase)) { return "Glücksspiel"; }
            if (string.Equals(areaId, Support.AreaShopping, StringComparison.OrdinalIgnoreCase)) { return "Shopping"; }
            if (string.Equals(areaId, Support.AreaSocialMedia, StringComparison.OrdinalIgnoreCase)) { return "Social Media"; }
            if (string.Equals(areaId, Support.AreaVideoGames, StringComparison.OrdinalIgnoreCase)) { return "Videospiele"; }
            return areaId;
        }

        private static string DescribeAreaStatus(AppConfig config, ProtectionAreaSnapshot area)
        {
            string id = area.Id;
            if (string.Equals(id, Support.AreaAdultContent, StringComparison.OrdinalIgnoreCase))
            {
                return area.Status == "active" ? "Aktiv" : "Aus";
            }
            if (string.Equals(id, Support.AreaGambling, StringComparison.OrdinalIgnoreCase))
            {
                if (Support.EffectiveGamblingProtectionEnabled(config)) { return "Vollständig gesperrt"; }
                if (config.GamblingDailyLimitEnabled) { return "Zeitlimit " + Support.NormalizeDailyLimitMinutes(config.GamblingDailyLimitMinutes, 15) + " Minuten täglich"; }
                return "Aus";
            }
            if (string.Equals(id, Support.AreaShopping, StringComparison.OrdinalIgnoreCase))
            {
                if (!config.ShoppingProtectionEnabled) { return "Aus"; }
                if (config.ShoppingDailyLimitEnabled) { return "Zeitlimit " + Support.NormalizeDailyLimitMinutes(config.ShoppingDailyLimitMinutes, 30) + " Minuten täglich"; }
                if (config.ShoppingCurfewEnabled) { return "Shopping-Pause " + config.ShoppingCurfewStart + " bis " + config.ShoppingCurfewEnd; }
                return "Aktiv";
            }
            if (string.Equals(id, Support.AreaSocialMedia, StringComparison.OrdinalIgnoreCase))
            {
                if (!config.SocialMediaProtectionEnabled) { return "Aus"; }
                if (config.SocialMediaDailyBudgetEnabled) { return "Zeitlimit " + Support.NormalizeSocialMediaBudgetMinutes(config.SocialMediaDailyBudgetMinutes) + " Minuten täglich"; }
                if (!string.IsNullOrEmpty(config.SocialMediaBlockedPlatforms)) { return "Einzelne Plattformen gesperrt"; }
                return "Aktiv";
            }
            if (string.Equals(id, Support.AreaVideoGames, StringComparison.OrdinalIgnoreCase))
            {
                if (!config.VideoGamesProtectionEnabled) { return "Aus"; }
                if (string.Equals(config.VideoGamesProtectionMode, "strict", StringComparison.OrdinalIgnoreCase)) { return "Vollständig gesperrt"; }
                if (config.VideoGamesDailyLimitEnabled) { return "Zeitlimit " + Support.NormalizeVideoGamesDailyLimitMinutes(config.VideoGamesDailyLimitMinutes) + " Minuten täglich"; }
                if (config.VideoGamesCurfewEnabled) { return "Gesperrt von " + config.VideoGamesCurfewStart + " bis " + config.VideoGamesCurfewEnd; }
                return "Aktiv";
            }
            return area.Status;
        }

        private void ApplyStatusSnapshot(StatusSnapshot snapshot)
        {
            Ui.SetDynamicText(statusLabel, snapshot.StatusText, "Schutzstatus");
            statusLabel.ForeColor = theme.IsHighContrast ? theme.TextPrimary : snapshot.StatusColor;
            Ui.SetDynamicText(statusHintLabel, snapshot.HintText, "Statushinweis");
            statusHintLabel.Visible = !string.IsNullOrEmpty(snapshot.HintText);
            detailsText = snapshot.DetailsText;

            bool needsRepair = snapshot.Kind == ProtectionStatusKind.Restricted || snapshot.Kind == ProtectionStatusKind.NeedsRepair;
            bool noAreas = snapshot.Kind == ProtectionStatusKind.NoAreas;
            repairButton.Visible = needsRepair;
            setupButton.Visible = noAreas;
            activateButton.Visible = !needsRepair && !noAreas;
            pauseButton.Visible = !noAreas;
            // Exactly one primary action: activate while off/paused, repair while broken,
            // set up the protection areas while none is on yet.
            if (!needsRepair)
            {
                activateButton.Enabled = actionButtonsEnabled;
            }
            statusNeedsRepair = needsRepair;
            statusNoAreas = noAreas;
            LayoutStatusCard();

            statusCard.GlyphKind = GlyphKindFor(snapshot.Kind);
            statusCard.GlyphColor = snapshot.StatusColor;
            statusCard.Invalidate();

            ApplyAreaStatusLines(snapshot.AreaStatusLines);
            UpdateDevModeIndicator();
        }

        private static string GlyphKindFor(ProtectionStatusKind kind)
        {
            switch (kind)
            {
                case ProtectionStatusKind.Restricted:
                    return "restricted";
                case ProtectionStatusKind.NeedsRepair:
                    return "repair";
                case ProtectionStatusKind.Paused:
                    return "paused";
                case ProtectionStatusKind.NoAreas:
                    return "idle";
                default:
                    return "active";
            }
        }

        private void UpdateDevModeIndicator()
        {
            if (devModeSidebarLabel == null)
            {
                return;
            }
            string devId = Support.GetDevCompanionId();
            // Ein Bau ohne Passwort und ohne Fristen darf nie unsichtbar sein.
            bool unlocked = Support.DevUnlockActive;
            devModeSidebarLabel.Text = unlocked ? "Entwicklerbau - kein Passwort, keine Fristen" : "Entwicklermodus";
            devModeSidebarLabel.Visible = unlocked || !string.IsNullOrEmpty(devId);
        }

        // ------------------------------------------------------------------
        // Actions
        // ------------------------------------------------------------------

        private void ActivateProtection()
        {
            RunAction("Schutz aktivieren", delegate
            {
                Support.SetProtectionEnabled(true);
                Support.EnforceProtection();
                try
                {
                    Support.StartService();
                }
                catch
                {
                }
            }, delegate (bool success)
            {
                if (success)
                {
                    ShowSaveFeedback("Der Schutz ist jetzt aktiv.");
                }
            });
        }

        private void PauseProtection()
        {
            if (!ConfirmPassword("Pausieren"))
            {
                return;
            }

            int minutes;
            if (!PromptPauseDuration(out minutes))
            {
                return;
            }

            RunAction("Schutz pausieren", delegate
            {
                Support.SetProtectionPaused(minutes);
                Support.StopService();
                Support.ClearProtection();
            }, delegate (bool success)
            {
                if (success)
                {
                    ShowSaveFeedback("Der Schutz ist jetzt pausiert.");
                }
            }, delegate (Exception failure)
            {
                // DESK-03: Der Start der Wartezeit ist das erwartete Ergebnis
                // von "nach 10 Minuten", kein Fehler - mit sichtbarer Uhrzeit.
                PauseCooldownStartedException cooldown = failure as PauseCooldownStartedException;
                if (cooldown != null)
                {
                    string readyAt = cooldown.ReadyAtUtc.ToLocalTime().ToString("t");
                    ShowSaveFeedback("Wartezeit gestartet: Pausieren ist ab " + readyAt + " Uhr möglich.");
                    Ui.Inform(this, theme, "Wartezeit gestartet",
                        "Vor dem Pausieren läuft jetzt eine Wartezeit von 10 Minuten. Ab " + readyAt +
                        " Uhr kannst du den Schutz pausieren - wähle dann erneut „Schutz pausieren“.");
                    return;
                }
                // Sperrmodus oder strenger Zeitplan: die Meldung aus Support ist
                // fuer Nutzer geschrieben.
                if (failure is InvalidOperationException)
                {
                    Ui.Inform(this, theme, "Pausieren nicht möglich", failure.Message);
                    return;
                }
                ShowErrorDialog("Schutz pausieren", failure);
            });
        }

        private void RepairApp()
        {
            if (!ConfirmPassword("Reparieren"))
            {
                return;
            }

            bool repaired = true;
            RunAction("Purestate reparieren", delegate
            {
                repaired = Support.RepairInstalledApp();
            }, delegate (bool success)
            {
                if (success)
                {
                    ShowSaveFeedback(repaired
                        ? "Die Reparatur ist abgeschlossen."
                        : "Es fehlten Programmdateien. Das Installationsprogramm wurde gestartet und stellt sie wieder her.");
                }
            });
        }

        private void LaunchUninstaller()
        {
            string uninstaller = Path.Combine(Support.InstallDir, "PurestateUninstaller.exe");
            if (!File.Exists(uninstaller))
            {
                Ui.Inform(this, theme, "Deinstallieren", "Der Deinstaller wurde nicht gefunden.");
                return;
            }

            Process.Start(uninstaller);
        }

        private void ShowSaveFeedback(string message)
        {
            // Auf dem Ablaufbildschirm (BuildExpiredScreen) gibt es keine
            // Statuskarte und damit kein feedbackLabel - dort faellt dieselbe
            // Rueckmeldung auf einen modalen Hinweis zurueck, statt still zu
            // verschwinden.
            if (feedbackLabel == null)
            {
                Ui.Inform(this, theme, "Purestate", message);
                return;
            }

            Ui.SetDynamicText(feedbackLabel, message, "Rückmeldung");
            LayoutStatusCard();
            feedbackTimer.Stop();
            feedbackTimer.Start();
        }

        // DESK-02: Statuskarte nach echter Breite und Textlaenge anordnen.
        // Vorher: rechte Anker, berechnet gegen die kleine Anfangsbreite der
        // Karte (Labels 1260 px breit), und feste 20/18 px Hoehe - lange
        // Hinweise wie die Liste nicht wirksamer Schichten endeten unsichtbar.
        private void LayoutStatusCard()
        {
            if (statusCard == null || statusLabel == null || statusHintLabel == null || feedbackLabel == null ||
                activateButton == null || repairButton == null || setupButton == null || pauseButton == null || detailsLink == null)
            {
                return;
            }

            int width = Math.Max(160, statusCard.ClientSize.Width - statusHintLabel.Left - Ui.PagePadding);
            statusLabel.Width = width;
            statusLabel.Height = Math.Max(30, MeasureWrapped(statusLabel, width));
            statusHintLabel.Top = statusLabel.Bottom + 2;
            statusHintLabel.Width = width;
            statusHintLabel.Height = Math.Max(20, MeasureWrapped(statusHintLabel, width));
            bool hasHint = !string.IsNullOrEmpty(statusHintLabel.Text);

            int buttonsTop = (hasHint ? statusHintLabel.Bottom : statusLabel.Bottom) + 14;
            activateButton.Top = buttonsTop;
            repairButton.Top = buttonsTop;
            setupButton.Top = buttonsTop;
            pauseButton.Top = buttonsTop;
            Button mainButton = statusNeedsRepair ? repairButton : (statusNoAreas ? setupButton : activateButton);
            pauseButton.Left = mainButton.Right + Ui.GapGroup;
            // Pausieren ist im NoAreas-Zustand verborgen - der Detail-Link
            // rueckt dann direkt neben den sichtbaren Hauptknopf.
            // Befund #10: pauseButton.Visible ist in WinForms auch dann false,
            // wenn das Formular noch gar nicht angezeigt wird - der Aufruf aus
            // dem Konstruktor sah den Knopf also faelschlich als verborgen an,
            // bis das naechste Resize/Status-Update kam. statusNoAreas kennt
            // den beabsichtigten Zustand unabhaengig davon.
            detailsLink.Left = (!statusNoAreas ? pauseButton.Right : mainButton.Right) + Ui.GapSection;
            detailsLink.Top = pauseButton.Top + (pauseButton.Height - detailsLink.Height) / 2;
            if (detailsLink.Right > statusCard.ClientSize.Width - Ui.GapGroup)
            {
                detailsLink.Left = activateButton.Left;
                detailsLink.Top = pauseButton.Bottom + Ui.GapSmall;
            }

            feedbackLabel.Top = Math.Max(pauseButton.Bottom, detailsLink.Bottom) + 4;
            feedbackLabel.Width = width;
            feedbackLabel.Height = Math.Max(18, MeasureWrapped(feedbackLabel, width));
            int height = feedbackLabel.Bottom + Ui.GapSmall;
            if (statusCard.Height != height)
            {
                statusCard.Height = height;
            }
        }

        private static int MeasureWrapped(Label label, int width)
        {
            return string.IsNullOrEmpty(label.Text)
                ? 0
                : TextRenderer.MeasureText(label.Text, label.Font, new Size(width, 0), TextFormatFlags.WordBreak).Height;
        }

        // Runs the action on a background thread (these shell out to
        // powershell.exe/sc.exe and would freeze the window). All action
        // buttons are disabled while running; completion is marshaled back.
        // Callers must capture dialog control values into locals BEFORE
        // calling RunAction.
        private void RunAction(string name, Action action)
        {
            RunAction(name, action, null);
        }

        private void RunAction(string name, Action action, Action<bool> onCompleted)
        {
            RunAction(name, action, onCompleted, null);
        }

        // onFailure != null: der Aufrufer zeigt den Fehler selbst (z. B. eine
        // erwartete Ablehnung als verstaendliche Meldung statt "fehlgeschlagen").
        private void RunAction(string name, Action action, Action<bool> onCompleted, Action<Exception> onFailure)
        {
            ToggleButtons(false);
            Cursor = Cursors.WaitCursor;
            if (statusHintLabel != null)
            {
                Ui.SetDynamicText(statusHintLabel, name + " läuft ...", "Statushinweis");
                statusHintLabel.Visible = true;
            }
            LayoutStatusCard();

            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                bool success = false;
                Exception failure = null;
                try
                {
                    action();
                    success = true;
                }
                catch (Exception ex)
                {
                    failure = ex;
                }

                try
                {
                    if (success)
                    {
                        Support.WriteSecurityLog("Action completed: " + name);
                    }
                    else
                    {
                        Support.WriteSecurityLog("Action failed: " + name + " (" + failure.GetType().Name + ")");
                    }

                    if (IsHandleCreated && !IsDisposed)
                    {
                        BeginInvoke(new Action(delegate
                        {
                            Cursor = Cursors.Default;
                            ToggleButtons(true);
                            if (statusHintLabel != null)
                            {
                                Ui.SetDynamicText(statusHintLabel, string.Empty, "Statushinweis");
                                statusHintLabel.Visible = false;
                            }
                            LayoutStatusCard();
                            if (!success)
                            {
                                if (onFailure != null)
                                {
                                    onFailure(failure);
                                }
                                else
                                {
                                    ShowErrorDialog(name, failure);
                                }
                            }
                            RefreshStatus();
                            if (onCompleted != null)
                            {
                                onCompleted(success);
                            }
                        }));
                    }
                }
                catch
                {
                }
            });
        }

        // Plain-language error with the technical part in a copyable report,
        // not in the user's face.
        private void ShowErrorDialog(string name, Exception failure)
        {
            string detailsText = name + " ist fehlgeschlagen." + Environment.NewLine + Environment.NewLine + failure;
            using (DialogShell dialog = new DialogShell(theme, "Aktion fehlgeschlagen",
                name + " hat leider nicht geklappt. Du kannst es erneut versuchen.",
                "Zeigt eine verständliche Fehlermeldung und auf Wunsch technische Details.", false))
            {
                Button details = Ui.SecondaryButton(theme, "Technische Details anzeigen",
                    "Öffnet einen kopierbaren technischen Fehlerbericht.");
                details.Click += delegate
                {
                    dialog.Close();
                    ShowTextDialog("Technische Details zu: " + name, detailsText, true);
                };
                dialog.Add(details);
                dialog.FinishLayout();
                dialog.Shown += delegate { dialog.CloseButtonControl.Focus(); };
                dialog.ShowDialog(this);
            }
        }

        // DESK-08: Speichern aus einem Einstellungsdialog. Die Werte sind vor
        // der Passwortabfrage erfasst; der Dialog bleibt offen, bis Support das
        // Ergebnis liefert. Eine Ablehnung (Abschwaechungs-Gate, gesperrte
        // Datei) steht im Dialog, der Entwurf bleibt erhalten. Das Gate selbst
        // bleibt allein in Support.
        private void RunAction(string name, DialogShell shell, Action action, string successMessage)
        {
            bool stillApplying = false;
            shell.SaveInBackground(delegate
            {
                try
                {
                    // Vorher abholen: ein frueherer Lauf auf diesem Poolthread
                    // kann die Antwort liegen gelassen haben.
                    Support.TakeReapplyStillRunning();
                    action();
                    stillApplying = Support.TakeReapplyStillRunning();
                }
                catch (Exception ex)
                {
                    TryWriteLogs("Action failed: " + name + " (" + ex.GetType().Name + ")",
                        "Settings save failed: " + name + ": " + ex.GetType().Name + ": " + ex.Message);
                    throw;
                }
                TryWriteLogs("Action completed: " + name, null);
            }, delegate
            {
                ShowSaveFeedback(stillApplying
                    ? successMessage + " Der Schutz wird noch im Hintergrund angewendet - das kann ein paar Minuten dauern."
                    : successMessage);
                RefreshStatus();
            }, DescribeSaveFailure);
        }

        private static string DescribeSaveFailure(Exception failure)
        {
            // Meldungen aus Support (Gate, fehlendes Passwort, ungueltige
            // Eingabe) sind fuer Nutzer geschrieben.
            if (failure is InvalidOperationException)
            {
                return failure.Message + WeakeningReleaseHint(failure.Message);
            }
            // Der Fehler kann nach dem gespeicherten Setter beim Anwenden
            // entstehen - "nicht gespeichert" waere dann falsch.
            return "Speichern oder Anwenden ist nicht vollständig gelungen (" + failure.GetType().Name + "). Deine Eingaben sind noch da - " +
                "prüfe den Schutzstatus und versuche es erneut. Details stehen unter „Mehr“ → „Protokolle anzeigen“.";
        }

        // Nennt bei einer Gate-Ablehnung den Zeitpunkt, falls schon eine Frist
        // laeuft. Nur Anzeige - entschieden hat Support.
        private static string WeakeningReleaseHint(string message)
        {
            if (message.IndexOf("abschwaechen", StringComparison.OrdinalIgnoreCase) < 0)
            {
                return string.Empty;
            }
            try
            {
                AppConfig config = Support.LoadConfig();
                if (Support.IsServerAuthorityMode(config))
                {
                    return string.Empty;
                }
                DateTime opensAt;
                DateTime closesAt;
                if (Support.EvaluateWeakeningRequest(config, Support.TrustedUtcNow(config), out opensAt, out closesAt) != 1)
                {
                    return string.Empty;
                }
                DateTime minorOpensAt = opensAt.AddDays(-Support.WeakeningWaitDays).AddHours(Support.WeakeningMinorWaitHours);
                return " Deine Frist läuft bereits: kleinere Lockerungen ab " + minorOpensAt.ToLocalTime().ToString("g") +
                    ", alle ab " + opensAt.ToLocalTime().ToString("g") + ".";
            }
            catch (Exception)
            {
                // Nur Anzeige: laeuft das im UI-Thread schief, fehlt der
                // Zusatzsatz, nicht die Meldung.
                return string.Empty;
            }
        }

        private static void TryWriteLogs(string securityMessage, string activityMessage)
        {
            try
            {
                Support.WriteSecurityLog(securityMessage);
                if (activityMessage != null)
                {
                    Support.WriteActivityLog(activityMessage);
                }
            }
            catch (IOException)
            {
            }
            catch (UnauthorizedAccessException)
            {
            }
        }

        // DESK-10: Datei-Aenderungen aus Dialogen (Freigaben, Ausnahmen) mit
        // eigenem Fehlerpfad. Erwartbare Fehler landen als Meldung am Feld,
        // Unerwartetes bleibt unbehandelt sichtbar statt still verschluckt.
        private bool TryListChange(DialogShell shell, Label errorLine, Control focusTarget, Action change)
        {
            try
            {
                change();
                return true;
            }
            catch (Exception ex)
            {
                if (!(ex is IOException || ex is UnauthorizedAccessException || ex is InvalidOperationException ||
                    ex is System.Security.SecurityException))
                {
                    throw;
                }
                TryWriteLogs("List change failed (" + ex.GetType().Name + ")", "List change failed: " + ex.GetType().Name + ": " + ex.Message);
                shell.ShowError(errorLine, ex is InvalidOperationException
                    ? ex.Message
                    : "Die Änderung konnte nicht gespeichert werden - die Datei ist gerade gesperrt oder schreibgeschützt. Bitte versuche es erneut.",
                    focusTarget);
                return false;
            }
        }

        private bool actionButtonsEnabled = true;

        private void ToggleButtons(bool enabled)
        {
            actionButtonsEnabled = enabled;
            foreach (Button button in actionButtons)
            {
                button.Enabled = enabled;
            }
        }

        private static string YesNo(bool value)
        {
            return value ? "Ja" : "Nein";
        }
    }
}
