# Purestate - Anleitung fuer die geschlossene Beta

Diese Beta ist fuer 5-10 eingeladene Testpersonen auf Windows mit **Google
Chrome** vorgesehen. Zuerst testen zwei Personen 48 Stunden; nach Auswertung
folgen die weiteren Einladungen. Der Pilot endet nicht automatisch mit einer
Deinstallation: Dafuer gilt die unten beschriebene Wartezeit.

Purestate dient der freiwilligen Selbst-Einschraenkung. Lies vor der
Installation besonders die Hinweise zu Passwort, Schutzbereichen und
Deinstallation. Ein Windows-Administrator kann solchen Schutz grundsaetzlich
umgehen; Purestate macht spontane Abschwaechungen schwieriger.

## Vor der Installation

- Purestate benoetigt **Administratorrechte** und richtet einen Windows-Dienst
  sowie Browser-Richtlinien ein. Nutze einen Rechner, auf dem du diese
  Aenderungen bewusst moechtest. Speichere offene Arbeit im Browser vorher.
- Bewahre dein **Purestate-Passwort** sicher auf. Es gibt keine Funktion zum
  Zuruecksetzen eines vergessenen Passworts. Fuer regulaere geschuetzte
  Aenderungen und die regulaere Deinstallation brauchst du es erneut.
- **Nach einer Neuinstallation sind alle fuenf Schutzbereiche aus.** Erst
  Einschalten und Speichern aktiviert den gewaehlten Bereich. Dienst und
  Browser-Richtlinien werden bereits bei der Installation eingerichtet.
- Die Beta ist **nicht codesigniert**. SmartScreen kann warnen, die
  Benutzerkontensteuerung zeigt "Unbekannter Herausgeber". Pruefe die Datei
  vor dem Start wie unten beschrieben.
- Fuer die Neuinstallation brauchst du **den Freischaltcode aus deiner
  Einladung** und eine Internetverbindung. Der Code wird vor der Einrichtung
  eingeloest. Ohne gueltige Freischaltung werden weder Dienst noch
  Schutzregeln eingerichtet; der lokal erzeugte Geraeteschluessel kann bleiben.
- Dein Code hat eine begrenzte Zahl von Geraeteplaetzen, die in der Einladung
  steht. Reparatur und Update mit demselben Geraeteschluessel belegen keinen
  weiteren Platz; eine Neuinstallation mit neuem Schluessel dagegen schon.
- **Die Beta ist befristet.** Nach dem geprueften Ablauf endet der Schutz.
  Lies dazu "Wann die Beta endet". Nach der Freischaltung setzt Purestate die
  Regeln lokal durch; normale Lockerungen behalten ihre lokalen Wartefristen.

## Datei pruefen

Eine **SHA256-Pruefsumme ersetzt keine Herausgebersignatur**. Sie zeigt, ob die
ZIP-Datei mit der erwarteten Datei uebereinstimmt. Beziehe den erwarteten Wert
ueber den gesondert mitgeteilten, vertrauenswuerdigen Kontaktweg. Die neben der
ZIP liegende `.sha256.txt` allein bestaetigt nicht deren Herkunft.

1. Oeffne PowerShell im Ordner mit der heruntergeladenen ZIP-Datei.
2. Fuehre diesen Befehl aus:

```powershell
Get-FileHash .\Purestate-Windows-*.zip -Algorithm SHA256
```

3. Vergleiche den Wert fuer die richtige Datei vollstaendig mit dem separat
   mitgeteilten SHA256-Wert.
4. Bei Abweichung oder unklarer Herkunft: **nicht installieren**, sondern ueber
   den Beta-Kontakt melden.

## Installieren und ersten Schutz einschalten

1. Entpacke die freigegebene `Purestate-Windows-v<Version>.zip` und starte
   `Installieren.exe`.
2. Wenn Herkunft und Pruefsumme stimmen und du die unsignierte Beta bewusst
   installieren moechtest: Bei einer SmartScreen-Warnung ggf.
   **"Weitere Informationen"**, dann **"Trotzdem ausfuehren"** waehlen.
   Bestaetige die Benutzerkontensteuerung mit **"Ja"**.
3. Trage den Freischaltcode aus deiner Einladung ein. Lege dein Passwort fest:
   mindestens 12 Zeichen mit drei Zeichenarten oder
   eine lange Passphrase ab 20 Zeichen. Der Hinweis darf das Passwort nicht
   enthalten. Warte auf das Ergebnis des Installers.
4. Oeffne Chrome. Purestate richtet die automatische Installation des
   **Purestate Companion** aus dem Chrome Web Store per Richtlinie ein.
   Unter `chrome://extensions` soll die Erweiterung vorhanden und verwaltet
   sein. Eine manuelle Installation ist normalerweise nicht erforderlich.
   Fehlt sie, melde das und nutze den mitgeteilten Store-Link zur Kontrolle;
   lade fuer diesen Test keine entpackte Entwickler-Erweiterung.
5. Oeffne Purestate. Bei einer Neuinstallation ist
   **"Noch kein Schutzbereich eingeschaltet"** der erwartete Startzustand.
6. Fuer den ersten Test: **"Schutzbereiche"**, bei **"Erwachseneninhalte"**
   auf **"Einstellen"**, dann **"Erwachseneninhalte-Schutz einschalten"**.
   Klicke **"Aenderungen speichern"** und bestaetige mit deinem Passwort.
   Die einzelnen Webseiten-Haken wirken erst zusammen mit diesem Hauptschalter.
7. Warte auf die Speicherrueckmeldung. Oeffne den Bereich erneut: Die Auswahl
   muss erhalten sein. Pruefe auf **"Start"** den Schutzstatus und unter
   **"Mehr"** die **"Installation pruefen"**-Funktion.
8. Starte Windows einmal neu. Pruefe erneut App, gespeicherten Bereich,
   Companion und normale Webseiten in Chrome. Aktiviere weitere Bereiche
   gezielt; das spaetere Abschalten unterliegt einer Wartefrist.

Ein Update behaelt bestehende Bereichseinstellungen. Zeigt der Installer an,
dass die Schutzaktivierung noch laeuft, warte und pruefe den Status in der App.
Eine abgeschlossene Dateikopie allein ist noch kein Nachweis fuer aktiven Schutz.

## Chrome und Edge

In dieser Beta testen wir **Chrome**. Fuer Edge steht derzeit keine passende
Verteilung ueber den Edge-Store bereit. Ohne anerkannten, aktuellen Companion
werden geschuetzte gemischte Seiten dort vollstaendig gesperrt, beispielsweise
Reddit bei eingeschaltetem Erwachsenen-Schutz. Je nach Bereich koennen weitere
Seiten betroffen sein. **Das bedeutet nicht, dass jede Seite in Edge gesperrt
ist.** Windows kann einzelne Links trotzdem in Edge oeffnen.

Auch in Chrome bleiben solche Seiten vollstaendig gesperrt, wenn der Companion
fehlt, nicht aktiv ist oder nicht zur App passt. Melde diesen Zustand in Chrome.
App und Store-Erweiterung muessen zum freigegebenen Beta-Stand passen.

## Was wir im Pilot testen

- Installation, erstes Einschalten und Speichern ohne Haenger oder Absturz.
- Nach Neustart: Einstellungen erhalten, Companion aktiv, Schutzstatus plausibel.
- Harmlose Seiten und normale Beitraege auf unterstuetzten Plattformen bleiben
  in Chrome benutzbar. Melde auch einzelne unberechtigte Sperren.
- Schutzwirkung: Unter **"Mehr"** **"Schutz automatisch testen"** ausfuehren
  und die vereinbarten Browser-Testfaelle pruefen. Du musst fuer die Beta keine
  expliziten Inhalte suchen oder ansehen.
- Geschuetzte Aenderungen verlangen das Passwort. Abschwaechungen zeigen ihre
  Wartefrist. Eine Passwortfreigabe bedeutet nicht, dass jede Aenderung sofort
  erlaubt ist.
- Pausieren startet in der Voreinstellung zunaechst eine Wartezeit von
  **10 Minuten**. Erst danach die Aktion erneut ausfuehren. Ein strenger
  Zeitplan kann eine Pause weiter verhindern. **"Aktivieren"** beendet eine
  laufende Pause sofort.
- Optional nach Absprache: Nach fuenf falschen Passwoertern muss eine
  zeitweilige Sperre greifen. Danach die angezeigte Zeit abwarten.

Nach 48 Stunden bitte auch dann kurz Rueckmeldung geben, wenn alles funktioniert.
Wiederholte Browser-Schliessungen, verlorene Einstellungen, ungeschuetzte
aktivierte Bereiche oder ein defekter Installations-/Deinstallationsweg bitte
sofort melden. Weitere Einladungen folgen erst nach Auswertung des Piloten.

## Freigaben und Wartefristen

Eine faelschlich **automatisch erkannte** Erwachsenen- oder Gluecksspielseite
kannst du im jeweiligen Bereich mit Passwort freigeben. Diese Freigabe wirkt
nach **15 Minuten**, gilt **30 Tage** und laesst sich sofort zuruecknehmen.
Pro Bereich sind hoechstens 500 solche Freigaben moeglich. Sie hebt andere
Sperrgruende nicht automatisch auf.

Im aktuellen lokalen Modus brauchen grosse Abschwaechungen, etwa das Abschalten
eines Bereichs, **7 Tage** Vorlauf. Kleinere Abschwaechungen koennen bereits
nach **24 Stunden** moeglich sein. Beachte die konkrete Frist in der App;
Verschaerfungen werden nicht durch dieses Freigabefenster verzoegert.

## Daten und Browser-Berechtigung

Der Companion braucht die Berechtigung, Daten auf Webseiten zu lesen und zu
aendern, um Inhalte lokal zu erkennen und zu filtern. Auch harmlose Seiten
koennen dabei geprueft werden. Purestate uebertraegt deren Texte, Bilder und
Videos nicht an einen Purestate-Server.

Es gibt dennoch Netzwerkzugriffe: Die Erweiterung fragt fuer bereits sichtbare
Kennungen oeffentliche **Reddit- und Bluesky-APIs** ab. Reddit-Abfragen koennen
deine angemeldete Sitzung verwenden. Chrome bezieht den Companion aus dem
Store. Aktiviertes Familien-DNS leitet DNS-Anfragen an den gewaehlten Anbieter,
der dabei Domainnamen erfaehrt.

Bei Freischaltung und Verlaengerung gehen Code und oeffentlicher
Geraeteschluessel an den Purestate-Server. Der private Schluessel, dein
Passwort, Seiteninhalte und Nutzungszaehler werden nicht dorthin uebertragen.

Lokal speichert Purestate unter anderem Einstellungen, technische Protokolle,
erkannte zu sperrende Hostnamen und je nach Bereich Nutzungsdaten. Einzelheiten
stehen in der mitgeteilten [Datenschutzerklaerung](PRIVACY-POLICY.md).

## Fehler melden und Diagnose erstellen

Bitte sende ueber den mitgeteilten Beta-Kanal:

- Purestate-Version, Windows-Version, Browser und Companion-Version.
- Aktive Schutzbereiche, Zeitpunkt und die Schritte unmittelbar vor dem Fehler.
- Erwartetes und tatsaechliches Verhalten; tritt es nach einem Neustart erneut auf?
- Bei Bedarf einen Ausschnitt der Fehlermeldung oder den technischen Bericht.
  Keine Passwoerter oder Aktivierungstokens mitschicken.

Den Bericht findest du in Purestate unter **"Mehr"**, **"Technischen
Statusbericht erstellen"**. Er enthaelt Status, Richtlinien und letzte
technische Protokollzeilen; bestimmte Angaben werden geschwaerzt. **Lies ihn
vor dem Versenden durch** und entferne persoenliche Angaben, die du nicht teilen
moechtest. Er wird nicht automatisch an uns gesendet. Wenn die App nicht
startet, melde zuerst die sichtbare Fehlermeldung; wir geben dir dann die
passende Diagnoseanleitung.

## Wenn die Installation abbricht

Den geprueften Installer `Installieren.exe` erneut starten. Er kann fehlende Dateien und den
Dienst wieder einrichten; ein normaler Reparatur-/Update-Lauf behaelt Passwort
und Einstellungen. Verbliebene System-Sperren koennen bis dahin weiter wirken.
Loesche die Installations- oder Datenordner nicht von Hand. Scheitert auch der
zweite Lauf oder meldet Purestate eine beschaedigte Konfiguration, melde den
genauen Text ueber den Beta-Kanal.

## Updates

Ab der naechsten Version nach dieser findet Purestate neue Fassungen selbst. Die erste
Fassung mit dieser Funktion installierst du noch von Hand, so wie jede bisherige.

Einmal am Tag fragt die App im Hintergrund auf purestate-app.com, ob es eine neuere
Version gibt (zwei kleine oeffentliche Dateien, ohne Geraetekennung und ohne
Freischaltcode). Gibt es eine, zeigt das Tray-Symbol eine Meldung, im Verwaltungsfenster
steht oben auf der Startseite ein Hinweis, und unter "Mehr" gibt es "Nach Updates suchen".

Ein Klick auf die Meldung oeffnet das Verwaltungsfenster (Windows fragt wie gewohnt nach
der Erlaubnis) mit dem Update-Dialog: Version, Datum, was neu ist. "Jetzt installieren"
laedt die Datei, prueft Signatur, Groesse und Pruefsumme, entpackt sie und startet den
Installer. Der fragt wie bei jedem Update nach deinem Purestate-Passwort. Eine stille
Installation gibt es nicht. "Spaeter" blendet die Meldung 24 Stunden aus.

Aktualisiere, wenn die Meldung kommt: eine neue Browser-Erweiterung aus dem Store sperrt
gemischte Seiten, solange die App aelter ist.

## Wann die Beta endet

Der Schutz endet zum **frueheren** dieser beiden Zeitpunkte:

- Ablauf deiner signierten Freischaltung; das Datum zeigt die App an.
- Festes Ende dieser Programmfassung: **31.03.2027, 00:00 Uhr UTC**.

Vor Ablauf erinnert die App bei 14, 7 und 1 Tag Restlaufzeit, wenn sie laeuft
oder geoeffnet wird. Die Frist folgt der geschuetzten Uhr. Ein laufender
Schutzdienst begrenzt Manipulationen der Windows-Uhr; ein Administrator kann
lokale Schutzsoftware dennoch umgehen. **Stell die Windows-Uhr nicht vor:**
nach einem Neustart uebernimmt Purestate eine vorgestellte Uhr, und ein so
erreichtes Ende laesst sich nicht zuruecknehmen.

Wenn wir deinen Zeitraum verlaengert haben, kannst du **denselben Code erneut
einloesen**, in den Einstellungen unter "Freischaltung" oder auf dem
Bildschirm "Beta beendet". Dafuer brauchst du wieder Internet. Das feste
Fassungsende verlangt eine neue Programmfassung.

Bei geprueftem Ablauf nimmt Purestate seine System-Sperren zurueck und zeigt
"Beta beendet". Einstellungen bleiben fuer eine moegliche Verlaengerung
erhalten. **Deinstallation braucht weiterhin dein Passwort, aber keine
Wartefrist mehr.** Ein Serverausfall allein beendet den Schutz nicht; die
bereits signierte Freischaltung gilt offline bis zu ihrem Ablauf.

## Regulaer deinstallieren

1. Waehle in Purestate **"Mehr"**, **"Purestate deinstallieren"**, oder starte
   `PurestateUninstaller.exe` im Installationsordner.
2. Gib dein Passwort ein. Dadurch beginnt eine Wartezeit von **7 Tagen**.
   Der Schutz bleibt waehrenddessen aktiv.
3. Nach Ablauf hast du **24 Stunden** Zeit: Deinstaller erneut oeffnen,
   Passwort eingeben und die Entfernung bestaetigen. Verpasst du dieses
   Fenster, muss die Wartezeit erneut gestartet werden.
4. Lass die Entfernung fertiglaufen und schliesse die Erfolgsmeldung.
   Danach wird der Installationsordner bereinigt. Pruefe deine gewohnten
   Webseiten und melde verbliebene Sperren.

Nach geprueftem Beta-Ablauf entfaellt die Wartefrist. Passwort und Bestaetigung
bleiben auch dann erforderlich.

Falsche Passwoerter unterliegen derselben zeitweiligen Sperre wie in der App.
Bearbeite `C:\ProgramData\Purestate\config.json` nicht von Hand: Aenderungen
werden als Integritaetsfehler behandelt. Bei einer beschaedigten Konfiguration
gelten die gesonderten Hinweise im Deinstaller; melde diesen Zustand vor weiteren
Versuchen ueber den Beta-Kanal.
