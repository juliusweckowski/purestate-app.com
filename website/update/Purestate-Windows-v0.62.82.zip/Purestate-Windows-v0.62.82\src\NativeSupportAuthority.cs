using System;
using System.Globalization;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace Purestate.Native
{
    // Clientseite der Serverautoritaet. Erzeugt den Geraeteschluessel, baut das
    // Kanonisat byteweise wie server/Purestate.Authority/Grants.cs und prueft
    // erteilte Freigaben gegen den eingebetteten Serverschluessel.
    //
    // Diese Datei enthaelt bewusst KEINEN Netzwerkcode fuer den Durchsetzungs-
    // pfad: der Guard spricht nie mit dem Netz, saemtliche Serveraufrufe
    // passieren in der App auf Nutzeraktion.
    internal static partial class Support
    {
        public const string AuthorityModeLocal = "local";
        public const string AuthorityModeServer = "server";

        // Beidseitig gepinnt, siehe Grants.WaitingPeriod / Grants.WindowLength.
        public const int AuthorityWaitingPeriodHours = 72;
        public const int AuthorityWindowHours = 24;

        // Oeffentlicher Serverschluessel im Format "base64(Modulus).base64(Exponent)".
        // Gepinnt auf den Autoritaetsserver; der private Teil bleibt dort.
        // Ein Schluesselwechsel braucht eine Migration bestehender Berechtigungen.
        public const string AuthorityServerPublicKey = "yqjnprlosz2GXD0LZhra0J9J4vZfn7NMudNqJtXftxQQ9t0K+oaEwkwAenFqHWt3ESFKCRVJGfj0n4mos77aSZxFA5sEQD/RT8kMRufJQTV61hmU738Zq4oBj8TJPSXCcp/OcLGSRofQXIcY0cr47tiYwje/wU8y5jjdywhcawPTdFz+m2MpY1olKQTzVn6I6mo/ATyVix0hcr3WJFJoGDgRg4DOgpqFaTaH0mKUuvUPagCYonSbJe8A6Qq9mZSMXiSXGqwR1nWf+M4n63VSvMDJFhF6cVXZLEOemANrQvadncIsycF7EH9Tw60uLWdvLz2Fr7XgSPc2d3S7nMJLoQ==.AQAB";

        // Eigene HTTPS-Domain, damit ein Hosterwechsel keine neue App braucht.
        public const string AuthorityBaseUrl = "https://api.purestate-app.com";

        // Adresse der Abschaltdatei. Bewusst getrennt von AuthorityBaseUrl:
        // sie muss einen Ausfall des Autoritaetsservers ueberleben und liegt
        // deshalb statisch woanders. Siehe docs/AUTHORITY-SHUTDOWN.md.
        public const string AuthorityShutdownUrl = "";

        // Ende dieser Programmfassung. Im Beta-Build gesetzt, im Verkaufs-Build
        // leer. Auch ein Kauf-Code haelt die Beta-Fassung nicht darueber hinaus
        // am Leben - das ist der harte Schnitt zwischen Beta und Verkauf.
        public const string BetaBuildEndUtc = "2027-03-31T00:00:00.0000000Z";

        public const int MinimumDeviceKeySizeBits = 2048;

        // --- Geraeteschluessel ------------------------------------------------

        // Erzeugt beim ersten Aufruf ein RSA-2048-Paar und gibt es danach
        // unveraendert zurueck. Der private Teil verlaesst das Geraet nie.
        public static RSA EnsureDeviceKey()
        {
            EnsureDataDir();
            return LoadOrCreateDeviceKey(DeviceKeyPath);
        }

        // RSACryptoServiceProvider mit ausdruecklicher Schluessellaenge statt
        // RSA.Create(): das .NET Framework kennt kein RSA.Create(int) und legt
        // sonst 1024 Bit an. PersistKeyInCsp = false, damit kein zweites
        // Exemplar des privaten Schluessels im Schluesselspeicher des Profils
        // liegen bleibt - device.key ist der einzige Ort.
        private static RSACryptoServiceProvider NewDeviceKeyContainer(int keySizeBits)
        {
            RSACryptoServiceProvider provider = new RSACryptoServiceProvider(keySizeBits);
            provider.PersistKeyInCsp = false;
            return provider;
        }

        internal static RSA LoadOrCreateDeviceKey(string path)
        {
            RSACryptoServiceProvider key = NewDeviceKeyContainer(MinimumDeviceKeySizeBits);

            try
            {
                if (File.Exists(path))
                {
                    // FromXmlString/ToXmlString statt ImportRSAPrivateKey: die
                    // DER-Ex- und -Importe gibt es im .NET Framework nicht.
                    key.FromXmlString(File.ReadAllText(path));
                    return key;
                }

                // SRV-001: Das hier ist der PRIVATE Geraeteschluessel - genau
                // die Sorte Datei, fuer die WriteAllTextDurable eingefuehrt
                // wurde, nachdem am 2026-08-04 live ein integrity.key aus lauter
                // NUL-Bytes bestand. Ohne Server faellt es heute nicht auf;
                // sobald einer laeuft, kostet ein genullter device.key die
                // Geraeteeinloesung: der Server kennt den oeffentlichen Teil,
                // das Geraet den privaten nicht mehr.
                WriteAllTextDurable(path, key.ToXmlString(true));
                return key;
            }
            catch
            {
                key.Clear();
                throw;
            }
        }

        // Liest den oeffentlichen Geraeteschluessel, ohne einen anzulegen.
        // Fehlt die Datei, ist das Geraet nicht eingeloest - dann darf hier
        // nichts entstehen, sonst erzeugte jede Fensterpruefung einen
        // Schluessel, den der Server nie gesehen hat.
        public static string TryReadDevicePublicKey()
        {
            try
            {
                if (!File.Exists(DeviceKeyPath))
                {
                    return string.Empty;
                }

                using (RSA key = LoadOrCreateDeviceKey(DeviceKeyPath))
                {
                    return FormatDevicePublicKey(key);
                }
            }
            catch
            {
                return string.Empty;
            }
        }

        public static string DevicePublicKeyBase64()
        {
            using (RSA key = EnsureDeviceKey())
            {
                return FormatDevicePublicKey(key);
            }
        }

        // Modulus und Exponent statt SubjectPublicKeyInfo: das .NET Framework
        // kennt ExportSubjectPublicKeyInfo nicht. Base64 enthaelt keinen
        // Punkt, deshalb ist er als Trenner eindeutig.
        public static string FormatDevicePublicKey(RSA key)
        {
            RSAParameters parameters = key.ExportParameters(false);
            return Convert.ToBase64String(parameters.Modulus) + "." + Convert.ToBase64String(parameters.Exponent);
        }

        public static bool TryParseDevicePublicKey(string encoded, out RSA key)
        {
            key = null;
            if (string.IsNullOrEmpty(encoded))
            {
                return false;
            }

            string[] parts = encoded.Split('.');
            if (parts.Length != 2)
            {
                return false;
            }

            RSACryptoServiceProvider candidate = null;
            try
            {
                RSAParameters parameters = new RSAParameters();
                parameters.Modulus = Convert.FromBase64String(parts[0]);
                parameters.Exponent = Convert.FromBase64String(parts[1]);

                candidate = NewDeviceKeyContainer(MinimumDeviceKeySizeBits);
                candidate.ImportParameters(parameters);

                // Ein 512-Bit-Schluessel waere in Minuten zu brechen und damit
                // eine Geraetebindung, die keine ist.
                if (candidate.KeySize < MinimumDeviceKeySizeBits)
                {
                    candidate.Clear();
                    return false;
                }

                key = candidate;
                candidate = null;
                return true;
            }
            catch (FormatException) { return false; }
            catch (CryptographicException) { return false; }
            catch (ArgumentException) { return false; }
            finally
            {
                if (candidate != null) { candidate.Clear(); }
            }
        }

        // --- Kanonisate, byteweise identisch mit dem Server -------------------

        public static string GrantCanonical(string pubKey, long version, DateTime fromUtc, DateTime untilUtc)
        {
            return "pubkey=" + pubKey + "\n" +
                   "version=" + version.ToString(CultureInfo.InvariantCulture) + "\n" +
                   "from=" + fromUtc.ToUniversalTime().ToString("o", CultureInfo.InvariantCulture) + "\n" +
                   "until=" + untilUtc.ToUniversalTime().ToString("o", CultureInfo.InvariantCulture);
        }

        // Die Operation steht mit im signierten Text, damit eine Signatur fuer
        // /request nicht als Signatur fuer /approve durchgeht.
        public static string AuthorityRequestCanonical(string operation, string pubKey, long version)
        {
            return "op=" + operation + "\n" +
                   "pubkey=" + pubKey + "\n" +
                   "version=" + version.ToString(CultureInfo.InvariantCulture);
        }

        public static string EntitlementCanonical(string pubKey, string entitledUntilUtc, int maxDevices)
        {
            return "pubkey=" + pubKey + "\n" +
                   "entitled_until=" + (entitledUntilUtc ?? string.Empty) + "\n" +
                   "max_devices=" + maxDevices.ToString(CultureInfo.InvariantCulture);
        }

        public static string SignWithDeviceKey(string canonical, RSA privateKey)
        {
            return Convert.ToBase64String(privateKey.SignData(
                Encoding.UTF8.GetBytes(canonical), HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1));
        }

        public static bool VerifyAuthoritySignature(string canonical, string signature, RSA publicKey)
        {
            try
            {
                return publicKey.VerifyData(
                    Encoding.UTF8.GetBytes(canonical), Convert.FromBase64String(signature),
                    HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }
            catch (FormatException) { return false; }
            catch (CryptographicException) { return false; }
        }

        // --- Freigabepruefung -------------------------------------------------

        // Alles ausser einem ausdruecklichen "server" ist der lokale Modus.
        // Ein verstuemmelter Wert kann nur aus einer Konfiguration kommen, die
        // ihre Integritaetspruefung ohnehin nicht besteht.
        public static string NormalizeAuthorityMode(string value)
        {
            return string.Equals(value, AuthorityModeServer, StringComparison.OrdinalIgnoreCase)
                ? AuthorityModeServer
                : AuthorityModeLocal;
        }

        // AUTH-001: Die Einstellungen boten "Freischalten" fuer einen Server
        // an, den es nicht gibt - der Klick verlangte einen Freischaltcode und
        // endete zwangslaeufig in einer Fehlermeldung. Der Autoritaetscode
        // selbst bleibt unangetastet: er ist vollstaendig, fail-closed und
        // inert, solange keine Adresse eingetragen ist. Nur die Oberflaeche
        // haelt sich zurueck. Ein bereits freigeschaltetes Geraet sieht die
        // Zeilen weiterhin, sonst kaeme es nicht mehr zurueck.
        public static bool ServerAuthorityUiAvailable(AppConfig config)
        {
            return !string.IsNullOrEmpty(AuthorityBaseUrl) || IsServerAuthorityMode(config);
        }

        public static bool IsServerAuthorityMode(AppConfig config)
        {
            return config != null && string.Equals(config.AuthorityMode, AuthorityModeServer, StringComparison.Ordinal);
        }

        // Zerlegt "pubkey|version|von|bis". Liefert false, sobald irgendetwas
        // nicht passt - eine unlesbare Freigabe oeffnet nichts.
        public static bool TryParseWeakeningGrant(string stored, out string pubKey, out long version,
            out DateTime fromUtc, out DateTime untilUtc)
        {
            pubKey = string.Empty;
            version = 0;
            fromUtc = DateTime.MinValue;
            untilUtc = DateTime.MinValue;

            if (string.IsNullOrEmpty(stored))
            {
                return false;
            }

            string[] parts = stored.Split('|');
            if (parts.Length != 4)
            {
                return false;
            }

            if (!long.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out version))
            {
                return false;
            }

            if (!TryReadUtc(parts[2], out fromUtc) || !TryReadUtc(parts[3], out untilUtc))
            {
                return false;
            }

            pubKey = parts[0];
            return pubKey.Length > 0 && untilUtc > fromUtc;
        }

        public static string FormatWeakeningGrant(string pubKey, long version, DateTime fromUtc, DateTime untilUtc)
        {
            return pubKey + "|" + version.ToString(CultureInfo.InvariantCulture) + "|" +
                   fromUtc.ToUniversalTime().ToString("o", CultureInfo.InvariantCulture) + "|" +
                   untilUtc.ToUniversalTime().ToString("o", CultureInfo.InvariantCulture);
        }

        // Prueft die abgelegte Freigabe vollstaendig offline gegen den
        // eingebetteten Serverschluessel. Braucht kein Netz - ein stiller
        // Server macht eine bereits erteilte Freigabe nicht ungueltig.
        public static bool IsGrantValidFor(AppConfig config, DateTime nowUtc, string ownDevicePublicKey,
            string serverPublicKey)
        {
            // Ohne eingebetteten Serverschluessel gibt es keine Abschwaechung -
            // nicht etwa jede.
            if (config == null || string.IsNullOrEmpty(serverPublicKey))
            {
                return false;
            }

            string pubKey;
            long version;
            DateTime fromUtc;
            DateTime untilUtc;
            if (!TryParseWeakeningGrant(config.WeakeningGrant, out pubKey, out version, out fromUtc, out untilUtc))
            {
                return false;
            }

            // Die Freigabe eines anderen Geraets darf hier nicht aufgehen,
            // auch wenn ihre Signatur echt ist.
            if (string.IsNullOrEmpty(ownDevicePublicKey) ||
                !string.Equals(pubKey, ownDevicePublicKey, StringComparison.Ordinal))
            {
                return false;
            }

            // Die Freigabe gilt fuer genau den Zaehlerstand, den dieses Geraet
            // fuehrt. Eine aeltere oder neuere passt nicht.
            if (version != config.PolicyVersion)
            {
                return false;
            }

            if (nowUtc < fromUtc || nowUtc >= untilUtc)
            {
                return false;
            }

            RSA serverKey;
            if (!TryParseDevicePublicKey(serverPublicKey, out serverKey))
            {
                return false;
            }

            using (serverKey)
            {
                return VerifyAuthoritySignature(
                    GrantCanonical(pubKey, version, fromUtc, untilUtc), config.GrantSignature, serverKey);
            }
        }

        // Der Geraeteschluessel wird nur gelesen, wenn ueberhaupt eine Freigabe
        // abgelegt ist - sonst wuerde jede Fensterpruefung eine Datei anfassen.
        public static bool IsGrantValid(AppConfig config, DateTime nowUtc)
        {
            if (config == null || string.IsNullOrEmpty(config.WeakeningGrant))
            {
                return false;
            }

            return IsGrantValidFor(config, nowUtc, TryReadDevicePublicKey(), AuthorityServerPublicKey);
        }

        // --- Serveraufrufe ----------------------------------------------------
        //
        // Nur von der App, nur auf Nutzeraktion. Der Guard ruft hier nichts auf
        // und bekommt keinen Netzwerkcode; ein Quelltext-Vertrag pinnt das.

        public const string AuthorityUnreachableMessage =
            "Der Server ist nicht erreichbar. Der Schutz läuft unverändert weiter.";

        private const int AuthorityTimeoutMs = 15000;

        // HttpWebRequest statt HttpClient: es liegt in System.dll und braucht
        // damit in keiner der fuenf Compile-Listen eine neue Referenz.
        private static string PostJson(string path, string body, out string error)
        {
            error = string.Empty;

            if (string.IsNullOrEmpty(AuthorityBaseUrl))
            {
                error = AuthorityUnreachableMessage;
                return string.Empty;
            }

            try
            {
                // The legacy csc build defaults to SSL3/TLS1.0. SystemDefault
                // also fails on this target when Windows selects TLS1.3.
                // TLS1.2 is supported by the server; certificate checks stay intact.
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(AuthorityBaseUrl.TrimEnd('/') + path);
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Timeout = AuthorityTimeoutMs;
                request.ReadWriteTimeout = AuthorityTimeoutMs;

                byte[] payload = Encoding.UTF8.GetBytes(body);
                request.ContentLength = payload.Length;
                using (Stream stream = request.GetRequestStream())
                {
                    stream.Write(payload, 0, payload.Length);
                }

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
                {
                    return reader.ReadToEnd();
                }
            }
            catch (WebException ex)
            {
                error = ReadServerError(ex);
                return string.Empty;
            }
            catch (Exception)
            {
                error = AuthorityUnreachableMessage;
                return string.Empty;
            }
        }

        // Ein fehlendes Netz ist kein Fehlerzustand der App, sondern eine
        // normale Meldung. Eine Antwort mit Fehlertext wird durchgereicht.
        private static string ReadServerError(WebException ex)
        {
            HttpWebResponse response = ex.Response as HttpWebResponse;
            if (response == null)
            {
                return AuthorityUnreachableMessage;
            }

            using (response)
            using (StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
            {
                string serverError = ReadString(reader.ReadToEnd(), "error");
                return string.IsNullOrEmpty(serverError)
                    ? "Der Server hat die Anfrage abgelehnt."
                    : TranslateAuthorityError(serverError);
            }
        }

        public static string TranslateAuthorityError(string serverError)
        {
            switch (serverError)
            {
                case "unknown token": return "Dieser Freischaltcode ist unbekannt.";
                case "device limit reached": return "Dieser Freischaltcode ist bereits für die zulässige Zahl an Geräten eingelöst.";
                case "license expired": return "Dieser Freischaltcode ist abgelaufen.";
                case "invalid public key": return "Der Geräteschlüssel wurde abgelehnt.";
                case "policy rollback detected": return "Der Server hat eine zurückgespielte Konfiguration erkannt. Das Gerät bleibt geschützt.";
                case "waiting": return "Die Frist läuft noch.";
                case "no request": return "Es läuft keine Anfrage. Starte zuerst die Frist.";
                case "unknown device": return "Dieses Gerät ist nicht eingelöst.";
                case "device already enrolled": return "Dieses Gerät ist bereits mit einem anderen Freischaltcode eingelöst.";
                default: return "Der Server hat die Anfrage abgelehnt.";
            }
        }

        private static string JsonString(string value)
        {
            return "\"" + EscapeJson(value ?? string.Empty) + "\"";
        }

        // HTTP 200 allein beweist keine Einloesung: auch ein Proxy kann eine
        // Erfolgsseite liefern. Erst die geraetegebundene Serversignatur darf
        // eine gespeicherte Berechtigung ersetzen.
        public static bool TryReadAuthorityEnrollment(string response, string expectedPubKey,
            string serverPublicKey, out string entitledUntilUtc)
        {
            int maxDevices;
            string signature;
            return TryReadAuthorityEnrollment(response, expectedPubKey, serverPublicKey,
                out entitledUntilUtc, out maxDevices, out signature);
        }

        public static bool TryReadAuthorityEnrollment(string response, string expectedPubKey,
            string serverPublicKey, out string entitledUntilUtc, out int maxDevices, out string signature)
        {
            entitledUntilUtc = string.Empty;
            maxDevices = 0;
            signature = string.Empty;
            if (string.IsNullOrEmpty(response) || string.IsNullOrEmpty(expectedPubKey)) return false;
            string pubKey = ReadString(response, "pubKey");
            string serverSignature = ReadString(response, "signature");
            int devices = ReadInt(response, "maxDevices", 0);
            if (!string.Equals(pubKey, expectedPubKey, StringComparison.Ordinal) ||
                string.IsNullOrEmpty(serverSignature) || devices < 1) return false;

            string untilText = ReadString(response, "entitledUntil");
            string normalizedUntil = string.Empty;
            if (!string.IsNullOrEmpty(untilText))
            {
                DateTimeOffset until;
                if (!DateTimeOffset.TryParse(untilText, CultureInfo.InvariantCulture,
                    DateTimeStyles.None, out until)) return false;
                normalizedUntil = until.UtcDateTime.ToString("o", CultureInfo.InvariantCulture);
            }

            RSA key;
            if (!TryParseDevicePublicKey(serverPublicKey, out key)) return false;
            using (key)
            {
                if (!VerifyAuthoritySignature(EntitlementCanonical(pubKey, normalizedUntil, devices),
                    serverSignature, key)) return false;
            }
            entitledUntilUtc = normalizedUntil;
            maxDevices = devices;
            signature = serverSignature;
            return true;
        }

        // Prueft die Berechtigungsaussage des Servers. Sie ist ungueltig,
        // sobald irgendetwas fehlt - ein leerer eingebetteter Serverschluessel
        // eingeschlossen. Die Aufrufer duerfen aus "ungueltig" NIE ableiten,
        // dass der Schutz abgeschaltet gehoert; siehe IsEntitlementExpiredAt.
        public static bool VerifyEntitlement(string devicePubKey, string entitledUntilUtc, int maxDevices, string signature)
        {
            if (string.IsNullOrEmpty(AuthorityServerPublicKey)
                || string.IsNullOrEmpty(devicePubKey)
                || string.IsNullOrEmpty(signature) || maxDevices < 1)
            {
                return false;
            }

            RSA serverKey;
            if (!TryParseDevicePublicKey(AuthorityServerPublicKey, out serverKey))
            {
                return false;
            }

            using (serverKey)
            {
                return VerifyAuthoritySignature(
                    EntitlementCanonical(devicePubKey, entitledUntilUtc, maxDevices), signature, serverKey);
            }
        }

        public static bool IsEntitlementExpired(AppConfig config)
        {
            return IsEntitlementExpiredAt(config, TrustedUtcNow(config));
        }

        // Nur die eingebaute Fassungsgrenze, ohne die Berechtigung des
        // Geraets. EnrollAuthorityDevice braucht genau diese Trennung: ein
        // abgelaufener Freischaltcode darf erneut eingeloest werden (die
        // Verlaengerung laeuft ueber denselben Code mit neuem Datum), aber
        // kein Code haelt die Beta-Fassung ueber BetaBuildEndUtc hinaus am
        // Leben. Eine leere oder unlesbare Konstante bedeutet "nicht
        // abgelaufen" - das ist der Verkaufs-Build, in dem die Konstante
        // bewusst leer bleibt.
        public static bool IsBuildExpired(AppConfig config)
        {
            // Wie IsEntitlementExpiredAt: gemessen wird am Uhr-Anker aus
            // config.json, und eine manipulierte Konfiguration ist nie
            // abgelaufen.
            if (config != null && config.IntegrityCompromised)
            {
                return false;
            }

            DateTime buildEnd;
            return TryReadUtc(BetaBuildEndUtc, out buildEnd) && TrustedUtcNow(config) >= buildEnd;
        }

        // Fuer die Neuinstallation: ein eingeloester Termin, der schon
        // verstrichen ist. IsEntitlementExpiredAt gaebe den Rechner sonst im
        // ersten Takt wieder frei, direkt nachdem Dienst, Aufgabe und
        // Richtlinien entstanden sind. Die Signatur hat TryRedeemToken schon
        // geprueft; ein leerer Termin ist der "kein Ablauf"-Fall des Servers.
        public static bool IsRedeemedEntitlementExpiredAt(string entitledUntilUtc, DateTime nowUtc)
        {
            DateTime entitledUntil;
            return TryReadUtc(entitledUntilUtc, out entitledUntil) && nowUtc >= entitledUntil;
        }

        public static readonly int[] EntitlementWarningDays = new int[] { 14, 7, 1 };

        public static string EntitlementWarningMarkerPath
        {
            get { return Path.Combine(DataDir, "entitlement-warnings.txt"); }
        }

        // Liefert die faellige Schwelle oder 0. Bewusst ohne signierten
        // Merker: wer die Datei loescht, bekommt seine eigenen Hinweise
        // nochmal; wer sie faelscht, unterdrueckt seine eigenen Hinweise. Beides
        // schadet niemand anderem und rechtfertigt kein weiteres Schemafeld.
        public static int DueEntitlementWarning(AppConfig config, DateTime nowUtc, string markerPath)
        {
            return DueEntitlementWarning(config, nowUtc, markerPath, true);
        }

        // consume=false liest nur, was faellig waere, ohne es abzuhaken. Die
        // Sprechblase im Infobereich hat keine Zustellgarantie - Windows
        // unterdrueckt sie im Fokus-Assistenten, bei Vollbild und wenn
        // Benachrichtigungen aus sind. Haette sie die Schwelle verbraucht,
        // waere die Warnung still verschwunden, und Abschnitt 6 der
        // Spezifikation sagt "Es gibt keinen stillen Ablauf." Verbraucht wird
        // deshalb nur im Verwaltungsfenster, wo der Hinweis wirklich ankommt.
        public static int DueEntitlementWarning(AppConfig config, DateTime nowUtc, string markerPath, bool consume)
        {
            DateTime effectiveEnd;
            if (!TryEffectiveEntitlementEnd(config, out effectiveEnd) || nowUtc >= effectiveEnd)
            {
                return 0;
            }

            string shown = string.Empty;
            try
            {
                if (File.Exists(markerPath)) { shown = File.ReadAllText(markerPath); }
            }
            catch { shown = string.Empty; }

            double remainingDays = (effectiveEnd - nowUtc).TotalDays;
            for (int index = 0; index < EntitlementWarningDays.Length; index++)
            {
                int threshold = EntitlementWarningDays[index];
                if (remainingDays > threshold || (index + 1 < EntitlementWarningDays.Length
                    && remainingDays <= EntitlementWarningDays[index + 1]))
                {
                    continue;
                }

                // Jede Frist hat eigene Warnungen. Alte Eintraege bleiben stehen,
                // damit ein noch geladener alter Config-Stand nichts zuruecksetzt.
                string tag = "[" + effectiveEnd.ToString("O", CultureInfo.InvariantCulture) + ":"
                    + threshold.ToString(CultureInfo.InvariantCulture) + "]";
                if (shown.IndexOf(tag, StringComparison.Ordinal) >= 0)
                {
                    // Diese Schwelle wurde schon gezeigt - das schliesst eine
                    // spaetere, noch nicht gezeigte Schwelle nicht aus.
                    continue;
                }

                if (consume)
                {
                    try { WriteAllTextDurable(markerPath, shown + tag); } catch { }
                }
                return threshold;
            }

            return 0;
        }

        // Das fruehere der beiden Enden: die eigene Berechtigung und die
        // eingebaute Fassungsgrenze - genau wie IsEntitlementExpiredAt den
        // Schutz beim ersten der beiden abschaltet. Ein fehlender oder
        // unlesbarer Wert erfindet keine Frist, sondern faellt aus dem
        // Vergleich heraus.
        internal static bool TryEffectiveEntitlementEnd(AppConfig config, out DateTime effectiveEnd)
        {
            DateTime entitledUntil = DateTime.MaxValue;
            bool hasEntitlement = config != null && !string.IsNullOrEmpty(config.EntitledUntilUtc)
                && TryReadUtc(config.EntitledUntilUtc, out entitledUntil);

            DateTime buildEnd = DateTime.MaxValue;
            bool hasBuildEnd = TryReadUtc(BetaBuildEndUtc, out buildEnd);

            if (!hasEntitlement && !hasBuildEnd)
            {
                effectiveEnd = DateTime.MinValue;
                return false;
            }

            effectiveEnd = entitledUntil < buildEnd ? entitledUntil : buildEnd;
            return true;
        }

        // Abgelaufen ist nur, was aus einer Quelle stammt, der zu trauen ist:
        // der eingebauten Fassungsgrenze oder einem vom Server signierten
        // Termin. Alles andere - fehlendes Feld, unlesbares Datum, fehlende
        // oder falsche Signatur - laesst den Schutz AN. Die unsichere Richtung
        // waere hier das Abschalten, nicht das Weiterlaufen.
        //
        // Die Signatur wird erst geprueft, wenn der Termin ueberhaupt
        // verstrichen ist. Das spart im Normalfall das Einlesen und Parsen des
        // Geraeteschluessels bei jedem Takt.
        //
        // Eine Konfiguration, die ihre Integritaetspruefung nicht besteht, ist
        // nie abgelaufen - sie erzwingt allen Schutz (ForceSafeProtection) und
        // darf nicht das Gegenteil ausloesen. Die Pruefung steht VOR der
        // Fassungsgrenze: der Aufrufer hat nowUtc in aller Regel ueber
        // TrustedUtcNow(config) aus dem Uhr-Anker berechnet, und der Anker ist
        // ein Feld in config.json. SaveConfigUnlocked schreibt eine
        // kompromittierte Konfiguration nie neu signiert zurueck, die
        // Manipulation bleibt also bei jedem Laden erkennbar.
        public static bool IsEntitlementExpiredAt(AppConfig config, DateTime nowUtc)
        {
            if (config != null && config.IntegrityCompromised)
            {
                return false;
            }

            DateTime buildEnd;
            if (TryReadUtc(BetaBuildEndUtc, out buildEnd) && nowUtc >= buildEnd)
            {
                return true;
            }

            if (config == null || string.IsNullOrEmpty(config.EntitledUntilUtc))
            {
                return false;
            }

            DateTime entitledUntil;
            if (!TryReadUtc(config.EntitledUntilUtc, out entitledUntil))
            {
                return false;
            }

            if (nowUtc < entitledUntil)
            {
                return false;
            }

            return VerifyEntitlement(TryReadDevicePublicKey(), config.EntitledUntilUtc,
                config.EntitlementMaxDevices, config.EntitlementSignature);
        }

        // Bringt das Ablaufdatum aus der Serverantwort auf dieselbe Form, in
        // der der Server signiert (Grants.EntitlementCanonical rendert ueber
        // DateTimeOffset.UtcDateTime.ToString("o")). Die Leitungsform weicht
        // davon ab - der Server serialisiert denselben Zeitpunkt ohne eigenen
        // JSON-Konverter als "...+00:00" statt "...Z" - deshalb muessen
        // Pruefung UND Ablage denselben normalisierten Text verwenden. Ein
        // fehlender, leerer oder unlesbarer Wert bleibt leer - das ist der
        // "kein Ablauf"-Fall des Servers.
        internal static string NormalizeEntitlementDate(string wireValue)
        {
            DateTime parsed;
            if (!TryReadUtc(wireValue, out parsed))
            {
                return string.Empty;
            }
            return parsed.ToString("o", CultureInfo.InvariantCulture);
        }

        // Loest einen Freischaltcode ein und gibt das Ergebnis zurueck, ohne
        // etwas zu speichern. Der Installer braucht genau das: er hat zum
        // Zeitpunkt der Einloesung noch keine Konfiguration, in die er
        // schreiben koennte, und darf bei einem Fehlschlag nichts hinterlassen.
        public static bool TryRedeemToken(string token, out string entitledUntilUtc,
            out int maxDevices, out string signature, out string error)
        {
            entitledUntilUtc = string.Empty;
            maxDevices = 0;
            signature = string.Empty;
            error = string.Empty;

            string pubKey;
            try
            {
                using (RSA key = EnsureDeviceKey())
                {
                    pubKey = FormatDevicePublicKey(key);
                }
            }
            catch
            {
                error = "Der Geräteschlüssel ließ sich nicht lesen.";
                return false;
            }

            string response = PostJson("/enroll",
                "{\"token\":" + JsonString(token) + ",\"pubkey\":" + JsonString(pubKey) + "}", out error);
            if (response.Length == 0)
            {
                // HTTP 200 mit leerem Rumpf: PostJson hat dann nichts zu
                // melden, und der leere Fehlertext wurde woertlich in den
                // Fehlerdialog des Installers eingesetzt.
                if (string.IsNullOrEmpty(error))
                {
                    error = "Der Server hat eine leere Antwort geschickt.";
                }
                return false;
            }

            if (!TryReadAuthorityEnrollment(response, pubKey, AuthorityServerPublicKey,
                out entitledUntilUtc, out maxDevices, out signature))
            {
                error = "Die Antwort des Servers trägt keine gültige Signatur.";
                return false;
            }

            return true;
        }

        // Schreibt das Ergebnis einer Einloesung in die Konfiguration: genau
        // die drei Berechtigungsfelder und nichts sonst. Installer und
        // Verlaengerung (EnrollDevice) teilen sich das.
        //
        // Bewusst NICHT AuthorityMode: der Servermodus ersetzt die lokale
        // Siebentagefrist fuer Abschwaechungen durch ein serverbestaetigtes
        // 72-Stunden-Fenster OHNE Offline-Rueckfall (IsWeakeningWindowOpen).
        // Ein Serverausfall hiesse dann, dass niemand mehr etwas lockern kann -
        // Abschnitt 10 der Spezifikation sagt das Gegenteil. Die Ablaufregel
        // braucht den Servermodus nicht: IsEntitlementExpiredAt liest
        // AuthorityMode gar nicht. Ein Geraet, das schon im Servermodus ist,
        // bleibt es; heraus fuehrt LeaveServerAuthority.
        public static void ApplyRedeemedEntitlement(AppConfig config, string entitledUntilUtc, int maxDevices, string signature)
        {
            config.EntitledUntilUtc = entitledUntilUtc;
            config.EntitlementMaxDevices = maxDevices;
            config.EntitlementSignature = signature;
        }

        // Loest einen Freischaltcode ein oder verlaengert ihn (derselbe Code,
        // neues Datum vom Server). Der Modus des Geraets bleibt, wie er ist.
        // Als einziger Aufruf unsigniert - der Server kennt das Geraet hier
        // noch nicht.
        public static bool EnrollDevice(string token, out string error)
        {
            string entitledUntil;
            int maxDevices;
            string signature;
            if (!TryRedeemToken(token, out entitledUntil, out maxDevices, out signature, out error))
            {
                return false;
            }

            UpdateConfig(delegate (AppConfig config)
            {
                ApplyRedeemedEntitlement(config, entitledUntil, maxDevices, signature);
            });
            return true;
        }

        // Setzt die Autoritaetsfelder auf den lokalen Modus zurueck.
        // PolicyVersion bleibt bewusst stehen: der Server fuehrt denselben
        // Zaehler weiter, und ein auf 0 zurueckgesetztes Geraet wuerde beim
        // naechsten Einloesen als zurueckgespielt abgewiesen.
        public static void ApplyLocalAuthority(AppConfig config)
        {
            if (config == null)
            {
                return;
            }

            config.AuthorityMode = AuthorityModeLocal;
            config.WeakeningGrant = string.Empty;
            config.GrantSignature = string.Empty;
            config.EntitledUntilUtc = string.Empty;
            config.EntitlementSignature = string.Empty;
            config.EntitlementMaxDevices = 0;

            // Eine Frist aus der Zeit vor dem Freischalten darf im lokalen
            // Modus nicht sofort wieder ein Fenster oeffnen.
            config.WeakeningRequestedUtc = string.Empty;
        }

        // Der freiwillige Rueckwechsel. Er ist selbst eine Abschwaechung und
        // laeuft deshalb durch dasselbe Fenster wie jede andere Einstellung -
        // im Servermodus oeffnet das nur eine gueltige Serverfreigabe. Ohne
        // sie wirft der Gate-Aufruf mit der ueblichen Meldung.
        public static void LeaveServerAuthority(DateTime localNow)
        {
            UpdateConfigWithWeakeningGate(ApplyLocalAuthority, localNow, false);
        }

        // --- Abschaltdatei ----------------------------------------------------
        //
        // Der zweite Weg zurueck, fuer den Fall dass der Dienst endet: eine
        // global gueltige, signierte Datei (docs/AUTHORITY-SHUTDOWN.md). Sie
        // ist NICHT der Schutz gegen dauerhaftes Feststecken - das ist die
        // lokale Deinstallation, die in jedem Server- und Netzzustand
        // funktioniert. Sie erlaubt, Purestate nach dem Ende des Dienstes
        // weiter zu benutzen, statt es deinstallieren zu muessen.

        // Die abgelegte Kopie. Sie wird bei JEDER Benutzung neu geprueft und
        // nie blind geglaubt - eine hier hineingelegte Datei ohne gueltige
        // Signatur bewirkt nichts.
        public static readonly string ShutdownFilePath = Path.Combine(DataDir, "shutdown.json");

        public const string ShutdownRejectedMessage =
            "Diese Datei ist keine gültige Purestate-Abschaltdatei.";

        // Byteweise wie Grants.ShutdownCanonical auf dem Server.
        public static string ShutdownCanonical(string issuedUtc)
        {
            return "op=shutdown\n" +
                   "issued=" + issuedUtc;
        }

        // Ohne eingebetteten Serverschluessel gilt keine Abschaltdatei -
        // fail-closed wie bei jeder Freigabe. Sonst waere eine leere
        // Schluesselkonstante ein Generalschluessel statt einer Sperre.
        public static bool TryReadShutdownFile(string json, string serverPublicKey, out string issuedUtc)
        {
            issuedUtc = string.Empty;
            if (string.IsNullOrEmpty(json) || string.IsNullOrEmpty(serverPublicKey))
            {
                return false;
            }

            string issued = ReadString(json, "issued");
            string signature = ReadString(json, "signature");
            if (issued.Length == 0 || signature.Length == 0)
            {
                return false;
            }

            RSA serverKey;
            if (!TryParseDevicePublicKey(serverPublicKey, out serverKey))
            {
                return false;
            }

            using (serverKey)
            {
                if (!VerifyAuthoritySignature(ShutdownCanonical(issued), signature, serverKey))
                {
                    return false;
                }
            }

            issuedUtc = issued;
            return true;
        }

        public static bool HasValidShutdownFile()
        {
            string issuedUtc;
            return TryReadStoredShutdownFile(out issuedUtc);
        }

        private static bool TryReadStoredShutdownFile(out string issuedUtc)
        {
            issuedUtc = string.Empty;
            try
            {
                if (!File.Exists(ShutdownFilePath))
                {
                    return false;
                }

                return TryReadShutdownFile(
                    File.ReadAllText(ShutdownFilePath), AuthorityServerPublicKey, out issuedUtc);
            }
            catch (IOException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
        }

        // Wendet eine Abschaltdatei an. Ohne Abschwaechungsfenster - der Dienst
        // existiert nicht mehr, und auf einer Frist zu bestehen, die niemand
        // mehr verkuerzen kann, waere reine Haerte. Die Signatur beweist, dass
        // der Betreiber abschaltet; das Passwort in der Oberflaeche beweist,
        // dass der Geraetebesitzer es anwendet.
        public static bool ApplyShutdownFile(string json, out string error)
        {
            error = string.Empty;

            string issuedUtc;
            if (!TryReadShutdownFile(json, AuthorityServerPublicKey, out issuedUtc))
            {
                error = ShutdownRejectedMessage;
                WriteSecurityLog("Authority shutdown file rejected.");
                return false;
            }

            StoreShutdownFile(json);
            UpdateConfig(ApplyLocalAuthority);
            WriteSecurityLog("Authority shutdown applied. Issued: " + issuedUtc);
            return true;
        }

        public static bool ApplyShutdownFileFromPath(string path, out string error)
        {
            try
            {
                return ApplyShutdownFile(File.ReadAllText(path), out error);
            }
            catch (IOException)
            {
                error = "Die Datei ließ sich nicht lesen.";
                return false;
            }
            catch (UnauthorizedAccessException)
            {
                error = "Die Datei ließ sich nicht lesen.";
                return false;
            }
        }

        public static bool ApplyStoredShutdownFile(out string error)
        {
            string issuedUtc;
            if (!TryReadStoredShutdownFile(out issuedUtc))
            {
                error = ShutdownRejectedMessage;
                return false;
            }

            return ApplyShutdownFile(File.ReadAllText(ShutdownFilePath), out error);
        }

        private static void StoreShutdownFile(string json)
        {
            EnsureDataDir();
            // SRV-001: Die Abschaltdatei entscheidet, ob der Schutz noch
            // gilt - halb geschrieben ist sie unbrauchbar.
            WriteAllTextDurable(ShutdownFilePath, json);
        }

        // Holt die Datei von der statischen Adresse und legt sie ab, wenn sie
        // aufgeht. Sie wird dabei NICHT angewendet - das bleibt eine Aktion
        // des Nutzers mit Passwort. Eine fehlende oder ungueltige Datei ist
        // kein Fehlerzustand, sondern der Normalfall: sie wird ignoriert,
        // ungueltig mit einer Zeile im Protokoll.
        public static bool TryFetchShutdownFile()
        {
            if (string.IsNullOrEmpty(AuthorityShutdownUrl))
            {
                return false;
            }

            string json = GetText(AuthorityShutdownUrl);
            if (json.Length == 0)
            {
                return false;
            }

            string issuedUtc;
            if (!TryReadShutdownFile(json, AuthorityServerPublicKey, out issuedUtc))
            {
                WriteSecurityLog("Authority shutdown file from the network did not verify.");
                return false;
            }

            StoreShutdownFile(json);
            WriteSecurityLog("Authority shutdown file received. Issued: " + issuedUtc);
            return true;
        }

        private static string GetText(string url)
        {
            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "GET";
                request.Timeout = AuthorityTimeoutMs;
                request.ReadWriteTimeout = AuthorityTimeoutMs;

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
                {
                    return reader.ReadToEnd();
                }
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        // Startet die Wartefrist oder fragt die laufende ab. Liefert den
        // Zeitpunkt, ab dem der Server eine Freigabe erteilt.
        public static bool RequestWeakening(out DateTime opensAtUtc, out string error)
        {
            opensAtUtc = DateTime.MinValue;

            string response = SignedPost("request", out error);
            if (response.Length == 0)
            {
                return false;
            }

            return TryReadUtc(ReadString(response, "opensAt"), out opensAtUtc);
        }

        // Holt die Freigabe ab, sobald die Frist abgelaufen ist, und legt sie
        // zusammen mit dem neuen Zaehlerstand ab.
        public static bool FetchGrant(out string error)
        {
            string response = SignedPost("approve", out error);
            if (response.Length == 0)
            {
                return false;
            }

            long version = ReadLong(response, "version", -1);
            DateTime fromUtc;
            DateTime untilUtc;
            if (version < 0 ||
                !TryReadUtc(ReadString(response, "from"), out fromUtc) ||
                !TryReadUtc(ReadString(response, "until"), out untilUtc))
            {
                error = "Die Antwort des Servers war unvollständig.";
                return false;
            }

            string signature = ReadString(response, "signature");
            string pubKey = TryReadDevicePublicKey();
            string grant = FormatWeakeningGrant(pubKey, version, fromUtc, untilUtc);

            // Erst pruefen, dann ablegen. Eine Freigabe, die hier nicht aufgeht,
            // wuerde spaeter nur das Fenster verschliessen und den Zaehler
            // verstellen.
            AppConfig candidate = LoadConfig();
            candidate.PolicyVersion = version;
            candidate.WeakeningGrant = grant;
            candidate.GrantSignature = signature;
            if (!IsGrantValidFor(candidate, fromUtc, pubKey, AuthorityServerPublicKey))
            {
                error = "Die Freigabe des Servers ließ sich nicht prüfen.";
                return false;
            }

            UpdateConfig(delegate (AppConfig config)
            {
                config.PolicyVersion = version;
                config.WeakeningGrant = grant;
                config.GrantSignature = signature;
            });
            return true;
        }

        private static string SignedPost(string operation, out string error)
        {
            error = string.Empty;

            AppConfig config = LoadConfig();
            string pubKey;
            string signature;
            using (RSA key = EnsureDeviceKey())
            {
                pubKey = FormatDevicePublicKey(key);
                signature = SignWithDeviceKey(
                    AuthorityRequestCanonical(operation, pubKey, config.PolicyVersion), key);
            }

            return PostJson("/" + operation,
                "{\"pubkey\":" + JsonString(pubKey) +
                ",\"version\":" + config.PolicyVersion.ToString(CultureInfo.InvariantCulture) +
                ",\"signature\":" + JsonString(signature) + "}", out error);
        }
    }
}
