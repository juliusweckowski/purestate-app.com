using System;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // Gambling protection: one clear choice (off / time limit / full block)
    // instead of the old checkbox pair whose relationship was invisible.
    // Config mapping is unchanged: full block = GamblingProtectionEnabled,
    // time limit = GamblingDailyLimitEnabled (only effective while the strict
    // block is off - exactly what the radio group now makes visible).
    internal sealed partial class AdminForm
    {
        private void ShowGamblingProtectionSettings()
        {
            AppConfig config = Support.LoadConfig();
            using (DialogShell shell = new DialogShell(theme, "Glücksspiel-Schutz",
                "Purestate blockiert Glücksspiel-Webseiten und passende Suchanfragen direkt auf diesem Gerät.",
                "Stellt den Schutz vor Glücksspiel-Webseiten ein.", true))
            {
                shell.Kicker = "Schutzbereich";
                shell.AddSection("Schutz");

                bool strictOn = Support.EffectiveGamblingProtectionEnabled(config);
                RadioButton off = Ui.Radio(theme, "Kein Glücksspiel-Schutz", !strictOn && !config.GamblingDailyLimitEnabled,
                    "Glücksspiel-Webseiten werden nicht eingeschränkt.");
                RadioButton limit = Ui.Radio(theme, "Nur Zeitlimit: Glücksspiel-Webseiten täglich begrenzen", !strictOn && config.GamblingDailyLimitEnabled,
                    "Glücksspiel-Webseiten bleiben erreichbar, aber nur für die eingestellte Zeit pro Tag.");
                RadioButton full = Ui.Radio(theme, "Glücksspiel-Webseiten vollständig sperren", strictOn,
                    "Glücksspiel-Webseiten und Suchanfragen werden komplett blockiert.");
                shell.Add(off);
                shell.Add(limit);

                ComboBox limitMinutes = Ui.MinutesCombo(5, 240,
                    Support.NormalizeDailyLimitMinutes(config.GamblingDailyLimitMinutes, 15),
                    "Zeitlimit in Minuten", "Wert zwischen 5 und 240 Minuten pro Tag.");
                System.Windows.Forms.Label limitUnit = Ui.WrapLabel(theme, "Minuten pro Tag", 200, true);
                FlowLayoutPanel limitRow = shell.Row(limitMinutes, limitUnit);
                limitRow.Padding = new Padding(24, 0, 0, 0);
                shell.Add(limitRow);
                Ui.BindVisibility(limit, limitRow);

                shell.Add(full);

                shell.AddSection("Zusätzliche Webseite sperren");
                shell.AddHint("Fehlt eine Glücksspiel-Webseite? Du kannst sie hier zusätzlich sperren lassen.");
                Button blockSite = Ui.SecondaryButton(theme, "Webseite zur Sperrliste hinzufügen", "Fügt eine weitere Glücksspiel-Webseite zur Sperrliste hinzu.");
                blockSite.Click += delegate { ShowAddCustomGamblingDomain(shell); };
                shell.Add(blockSite);

                shell.AddSection("Fälschlich erkannte Webseite freigeben");
                shell.AddHint("Purestate erkennt Glücksspielseiten auch am Inhalt. Wurde eine harmlose Seite gesperrt, kannst du sie hier freigeben. Die Freigabe wirkt nach 15 Minuten und nur auf die Inhaltserkennung — gesperrte Webseiten aus den Listen bleiben gesperrt.");

                ListBox exemptionList = new ListBox
                {
                    Width = shell.InnerWidth,
                    Height = 100,
                    Font = Ui.FontBody,
                    HorizontalScrollbar = true,
                    IntegralHeight = false,
                    BackColor = theme.CardBackground,
                    ForeColor = theme.TextPrimary
                };
                Ui.SetAccessibility(exemptionList, "Liste der Freigaben",
                    "Webseiten, die die Inhaltserkennung nie als Glücksspiel einstufen darf.", AccessibleRole.List);
                shell.Add(exemptionList);

                Action refreshExemptions = delegate
                {
                    exemptionList.Items.Clear();
                    foreach (GamblingHeuristicExemption exemption in Support.ReadGamblingHeuristicExemptions())
                    {
                        string entry = exemption.Host;
                        if (exemption.ActivatesAtUtc > Support.TrustedUtcNow())
                        {
                            entry += " (wirksam ab " + exemption.ActivatesAtUtc.ToLocalTime().ToString("g") + ")";
                        }
                        exemptionList.Items.Add(entry);
                    }
                };
                refreshExemptions();

                Label exemptionError = shell.AddErrorLine();
                Button addExemption = Ui.SecondaryButton(theme, "Webseite freigeben",
                    "Nimmt eine fälschlich erkannte Webseite von der Inhaltserkennung aus. Braucht das Passwort und wirkt nach 15 Minuten.");
                Button removeExemption = Ui.SecondaryButton(theme, "Freigabe entfernen",
                    "Nimmt eine Freigabe zurück. Wirkt sofort.");

                addExemption.Click += delegate
                {
                    string input;
                    if (!PromptText("Webseite freigeben",
                        "Adresse der Webseite eingeben (steht auf der Sperrseite, zum Beispiel beispiel-verein.de):", out input))
                    {
                        return;
                    }

                    // Eine Freigabe fuer eine gelistete Domain haette keine
                    // Wirkung - der Companion fragt die Listen zuerst. Sie
                    // trotzdem anzunehmen waere eine Attrappe.
                    if (Support.IsListedGamblingDomain(input))
                    {
                        shell.ShowError(exemptionError,
                            "Diese Webseite steht auf einer Sperrliste. Eine Freigabe würde daran nichts ändern.",
                            addExemption);
                        return;
                    }

                    if (!ConfirmPassword("Gluecksspiel-Freigabe hinzufügen", shell))
                    {
                        return;
                    }

                    string addError = string.Empty;
                    if (!TryListChange(shell, exemptionError, addExemption, delegate { addError = Support.AddGamblingHeuristicExemption(input); }))
                    {
                        return;
                    }
                    if (addError.Length != 0)
                    {
                        shell.ShowError(exemptionError, addError, addExemption);
                        return;
                    }

                    shell.ClearError(exemptionError);
                    refreshExemptions();
                    ShowSaveFeedback("Die Webseite ist in 15 Minuten freigegeben.");
                };

                removeExemption.Click += delegate
                {
                    if (exemptionList.SelectedIndex < 0)
                    {
                        shell.ShowError(exemptionError, "Bitte zuerst eine Freigabe in der Liste auswählen.", removeExemption);
                        return;
                    }

                    // Zuruecknehmen ist eine Verstaerkung: kein Passwort, keine
                    // Frist. Der Eintrag traegt bei noch nicht erreichter
                    // Aktivierung einen Zusatz in Klammern, der weg muss.
                    string entry = Convert.ToString(exemptionList.Items[exemptionList.SelectedIndex]);
                    int marker = entry.IndexOf(" (", StringComparison.Ordinal);
                    string host = marker > 0 ? entry.Substring(0, marker) : entry;

                    if (!TryListChange(shell, exemptionError, removeExemption, delegate { Support.RemoveGamblingHeuristicExemption(host); }))
                    {
                        return;
                    }
                    shell.ClearError(exemptionError);
                    refreshExemptions();
                    ShowSaveFeedback("Die Freigabe wurde entfernt.");
                };

                shell.Add(shell.Row(addExemption, removeExemption));

                shell.AddHint("Purestate ersetzt keine Beratung und speichert keine Finanz- oder Bankdaten.");

                shell.SaveButton.Click += delegate
                {
                    bool enabledValue = full.Checked;
                    bool dailyLimitValue = limit.Checked;
                    int dailyLimitMinutesValue = int.Parse(limitMinutes.Text);

                    if (!ConfirmPassword("Glücksspiel-Schutz speichern", shell))
                    {
                        return;
                    }

                    RunAction("Glücksspiel-Schutz speichern", shell, delegate
                    {
                        Support.SetGamblingSettingsGuarded(enabledValue, dailyLimitValue, dailyLimitMinutesValue, Support.TrustedLocalNow(), false);
                        Support.ReapplyProtection();
                    }, "Glücksspiel-Schutz: Änderungen gespeichert.");
                };

                shell.FinishLayout();
                shell.Shown += delegate { (full.Checked ? full : (limit.Checked ? limit : off)).Focus(); };
                shell.ShowDialog(this);
            }
        }

        private void ShowAddCustomGamblingDomain(IWin32Window owner)
        {
            string input;
            if (!PromptText("Webseite sperren", "Adresse der Webseite eingeben (zum Beispiel beispiel-casino.de):", out input))
            {
                return;
            }

            if (!ConfirmPassword("Glücksspielseite blockieren", owner))
            {
                return;
            }

            RunAction("Webseite sperren", delegate
            {
                bool added = Support.AddCustomGamblingDomain(input);
                if (added)
                {
                    Support.WriteSecurityLog("Custom gambling block domain added.");
                }

                Support.ReapplyProtection();
            }, delegate (bool success)
            {
                if (success)
                {
                    ShowSaveFeedback("Die Webseite wurde gesperrt. Eventuell ist ein Browser-Neustart nötig.");
                    RefreshStatus();
                }
            });
        }

        private void ShowAddCustomShoppingDomain(IWin32Window owner)
        {
            string input;
            if (!PromptText("Webseite sperren", "Adresse der Shop-Webseite eingeben (zum Beispiel beispiel-shop.de):", out input))
            {
                return;
            }

            if (!ConfirmPassword("Shoppingseite blockieren", owner))
            {
                return;
            }

            RunAction("Webseite sperren", delegate
            {
                bool added = Support.AddCustomShoppingDomain(input);
                if (added)
                {
                    Support.WriteSecurityLog("Custom shopping block domain added.");
                }

                Support.ReapplyProtection();
            }, delegate (bool success)
            {
                if (success)
                {
                    ShowSaveFeedback("Die Webseite wurde gesperrt. Eventuell ist ein Browser-Neustart nötig.");
                    RefreshStatus();
                }
            });
        }
    }
}
