using System;

namespace Purestate.Native
{
    internal sealed class ProtectionAreaSnapshot
    {
        public string Id = string.Empty;
        public string Label = string.Empty;
        public bool Enabled;
        public string Mode = string.Empty;
        public string ResourceCountry = string.Empty;
        public string RulePackVersion = string.Empty;
        public string Status = string.Empty;
    }

    internal static partial class Support
    {
        public const string AreaAdultContent = "adult-content";
        public const string AreaGambling = "gambling";
        public const string AreaShopping = "shopping";
        public const string AreaVideoGames = "video-games";
        public const string AreaSocialMedia = "social-media";

        public static ProtectionAreaSnapshot[] BuildProtectionAreaSnapshots(AppConfig config)
        {
            if (config == null)
            {
                config = new AppConfig();
            }

            bool gamblingEnabled = EffectiveGamblingProtectionEnabled(config);
            string gamblingMode = EffectiveGamblingProtectionMode(config);

            return new[]
            {
                NewProtectionArea(AreaAdultContent, "Erwachsene Inhalte", config.AdultContentProtectionEnabled, NormalizeProtectionAreaMode(config.AdultContentProtectionMode, "strict"), "DE", config.ProtectionAreaRulePackVersion),
                NewProtectionArea(AreaGambling, "Gluecksspiel", gamblingEnabled, gamblingMode, "DE", config.ProtectionAreaRulePackVersion),
                NewProtectionArea(AreaShopping, "Shopping", config.ShoppingProtectionEnabled, NormalizeSoftProtectionAreaMode(config.ShoppingProtectionMode, "planned"), "DE", config.ProtectionAreaRulePackVersion),
                NewProtectionArea(AreaVideoGames, "Videospiele", config.VideoGamesProtectionEnabled, NormalizeProtectionAreaMode(config.VideoGamesProtectionMode, "planned"), "DE", config.ProtectionAreaRulePackVersion),
                NewProtectionArea(AreaSocialMedia, "Social Media", config.SocialMediaProtectionEnabled, NormalizeSoftProtectionAreaMode(config.SocialMediaProtectionMode, "planned"), "DE", config.ProtectionAreaRulePackVersion)
            };
        }

        public static bool IsProtectionAreaEnabled(AppConfig config, string areaId)
        {
            foreach (ProtectionAreaSnapshot area in BuildProtectionAreaSnapshots(config))
            {
                if (string.Equals(area.Id, areaId, StringComparison.OrdinalIgnoreCase))
                {
                    return area.Enabled && string.Equals(area.Mode, "strict", StringComparison.OrdinalIgnoreCase);
                }
            }

            return false;
        }

        // Compares two dotted numeric version strings (e.g. "0.62.31").
        // Returns negative if a < b, 0 if equal, positive if a > b. Missing or
        // non-numeric components count as 0, so "0.62" == "0.62.0". Kept
        // byte-compatible with Compare-PurestateVersion in scripts\Common.ps1.
        public static int CompareVersionStrings(string a, string b)
        {
            string[] pa = (a ?? string.Empty).Split('.');
            string[] pb = (b ?? string.Empty).Split('.');
            int count = Math.Max(pa.Length, pb.Length);
            for (int i = 0; i < count; i++)
            {
                int va = ParseVersionComponent(i < pa.Length ? pa[i] : null);
                int vb = ParseVersionComponent(i < pb.Length ? pb[i] : null);
                if (va != vb)
                {
                    return va < vb ? -1 : 1;
                }
            }
            return 0;
        }

        private static int ParseVersionComponent(string text)
        {
            int value;
            if (int.TryParse((text ?? string.Empty).Trim(), System.Globalization.NumberStyles.None, System.Globalization.CultureInfo.InvariantCulture, out value) && value >= 0)
            {
                return value;
            }
            return 0;
        }

        // True when installing packageVersion over an existing install whose
        // recorded floor is installedFloor would be a downgrade. An empty or
        // unparseable floor (legacy configs from before schema 7) is treated as
        // no floor, so it never blocks.
        public static bool IsInstallDowngrade(string packageVersion, string installedFloor)
        {
            if (string.IsNullOrWhiteSpace(installedFloor))
            {
                return false;
            }
            return CompareVersionStrings(packageVersion, installedFloor) < 0;
        }

        public static string NormalizeProtectionAreaMode(string mode, string fallback)
        {
            string value = (mode ?? string.Empty).Trim().ToLowerInvariant();
            if (value == "off" || value == "planned" || value == "gentle" || value == "strict")
            {
                return value;
            }

            string safeFallback = (fallback ?? string.Empty).Trim().ToLowerInvariant();
            return (safeFallback == "off" || safeFallback == "planned" || safeFallback == "gentle" || safeFallback == "strict") ? safeFallback : "off";
        }

        // Shopping and social media are friction areas: nothing anywhere
        // enforces a strict gate for them, so their honest mode domain is
        // off/planned/gentle and "strict" clamps to "gentle". Applied only on
        // write and display paths - read/verification paths keep accepting
        // "strict" because legacy configs carry it SIGNED and a read clamp
        // would flip their canonical text into an integrity failure. PS mirror:
        // Get-NormalizedSoftProtectionAreaMode in scripts\Common.ps1 (pinned).
        public static string NormalizeSoftProtectionAreaMode(string mode, string fallback)
        {
            string value = NormalizeProtectionAreaMode(mode, fallback);
            return value == "strict" ? "gentle" : value;
        }

        public static void NormalizeSoftProtectionAreaState(AppConfig config)
        {
            if (config == null)
            {
                return;
            }

            config.ShoppingProtectionMode = NormalizeSoftProtectionAreaMode(config.ShoppingProtectionMode, "planned");
            config.SocialMediaProtectionMode = NormalizeSoftProtectionAreaMode(config.SocialMediaProtectionMode, "planned");
        }

        public static bool EffectiveGamblingProtectionEnabled(AppConfig config)
        {
            return config != null && (config.GamblingProtectionEnabled || config.GamblingSupportEnabled);
        }

        // "An" im Sinne des Nutzers: der Bereich schuetzt gerade vor etwas.
        // Gluecksspiel zaehlt auch mit reinem Zeitlimit als an.
        public static bool IsAreaActive(AppConfig config, string areaId)
        {
            if (config == null)
            {
                return false;
            }
            if (string.Equals(areaId, AreaAdultContent, StringComparison.OrdinalIgnoreCase)) { return config.AdultContentProtectionEnabled; }
            if (string.Equals(areaId, AreaGambling, StringComparison.OrdinalIgnoreCase)) { return EffectiveGamblingProtectionEnabled(config) || config.GamblingDailyLimitEnabled; }
            if (string.Equals(areaId, AreaShopping, StringComparison.OrdinalIgnoreCase)) { return config.ShoppingProtectionEnabled; }
            if (string.Equals(areaId, AreaSocialMedia, StringComparison.OrdinalIgnoreCase)) { return config.SocialMediaProtectionEnabled; }
            if (string.Equals(areaId, AreaVideoGames, StringComparison.OrdinalIgnoreCase)) { return config.VideoGamesProtectionEnabled; }
            return false;
        }

        private static readonly string[] ProtectionAreaIds = { AreaAdultContent, AreaGambling, AreaShopping, AreaSocialMedia, AreaVideoGames };

        public static bool AnyProtectionAreaActive(AppConfig config)
        {
            foreach (string areaId in ProtectionAreaIds)
            {
                if (IsAreaActive(config, areaId))
                {
                    return true;
                }
            }
            return false;
        }

        // Ein Bereich, der gerade eingeschaltet wird, zieht die Bausteine nach,
        // ohne die er sich umgehen liesse. Nur einschalten, nie ausschalten:
        // wer eine Sperre bewusst abgeschaltet hat, bekommt sie erst mit dem
        // naechsten eingeschalteten Bereich zurueck.
        public static void ApplyAreaDependencies(AppConfig before, AppConfig after)
        {
            if (before == null || after == null)
            {
                return;
            }
            foreach (string areaId in ProtectionAreaIds)
            {
                if (IsAreaActive(before, areaId) || !IsAreaActive(after, areaId))
                {
                    continue;
                }
                after.HostsEnabled = true;
                after.BypassBlockingEnabled = true;
                after.UnsupportedBrowserBlockingEnabled = true;
                if (string.Equals(areaId, AreaAdultContent, StringComparison.OrdinalIgnoreCase))
                {
                    after.FamilyDnsEnabled = true;
                }
            }
        }

        public static string EffectiveGamblingProtectionMode(AppConfig config)
        {
            return EffectiveGamblingProtectionEnabled(config) ? "strict" : "off";
        }

        public static void NormalizeGamblingProtectionState(AppConfig config)
        {
            if (config == null)
            {
                return;
            }

            config.GamblingProtectionEnabled = EffectiveGamblingProtectionEnabled(config);
            config.GamblingProtectionMode = EffectiveGamblingProtectionMode(config);
            config.GamblingSupportEnabled = config.GamblingProtectionEnabled;
            config.GamblingSupportMode = config.GamblingProtectionMode;
        }

        private static ProtectionAreaSnapshot NewProtectionArea(string id, string label, bool enabled, string mode, string resourceCountry, string rulePackVersion)
        {
            bool active = enabled && string.Equals(mode, "strict", StringComparison.OrdinalIgnoreCase);
            return new ProtectionAreaSnapshot
            {
                Id = id,
                Label = label,
                Enabled = active,
                Mode = active ? "strict" : mode,
                ResourceCountry = resourceCountry,
                RulePackVersion = string.IsNullOrWhiteSpace(rulePackVersion) ? "1" : rulePackVersion.Trim(),
                Status = active ? "active" : (mode == "planned" ? "planned" : (mode == "gentle" ? "gentle" : "off"))
            };
        }
    }
}
