using System;
using System.IO;
using System.Text;

namespace Purestate.Native
{
    internal static partial class Support
    {
        private static readonly string[] ObsoletePersonalSupportFileNames =
        {
            "gambling-support.txt",
            "shopping-support.txt",
            "social-media-support.txt"
        };

        public static int RemoveObsoletePersonalSupportData()
        {
            int removed = RemoveObsoletePersonalSupportData(DataDir);
            if (removed > 0) WriteActivityLog("Obsolete persönliche Supportdaten entfernt: " + removed + ".");
            return removed;
        }

        internal static int RemoveObsoletePersonalSupportData(string dataDirectory)
        {
            if (string.IsNullOrWhiteSpace(dataDirectory)) throw new ArgumentException("Datenverzeichnis fehlt.", "dataDirectory");
            string suppliedRoot = Path.GetPathRoot(dataDirectory);
            bool driveRelative = !string.IsNullOrEmpty(suppliedRoot) &&
                suppliedRoot.Length == 2 && suppliedRoot[1] == Path.VolumeSeparatorChar;
            bool currentDriveRelative = !string.IsNullOrEmpty(suppliedRoot) &&
                suppliedRoot.Length == 1 &&
                (suppliedRoot[0] == Path.DirectorySeparatorChar || suppliedRoot[0] == Path.AltDirectorySeparatorChar);
            if (!Path.IsPathRooted(dataDirectory) || driveRelative || currentDriveRelative)
                throw new ArgumentException("Datenverzeichnis muss ein absoluter Pfad sein.", "dataDirectory");

            string fullPath = Path.GetFullPath(dataDirectory);
            string filesystemRoot = Path.GetPathRoot(fullPath);
            string root = fullPath.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            string normalizedFilesystemRoot = (filesystemRoot ?? string.Empty).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            if (string.Equals(root, normalizedFilesystemRoot, StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("Dateisystem-Stammverzeichnis ist nicht zulässig.", "dataDirectory");
            if (!Directory.Exists(root)) return 0;
            EnsureDirectoryIsNotReparsePoint(root);

            int removed = 0;
            foreach (string fileName in ObsoletePersonalSupportFileNames)
            {
                string target = Path.GetFullPath(Path.Combine(root, fileName));
                if (!string.Equals(Path.GetDirectoryName(target), root, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Ungültiger veralteter Datenpfad.");
                if (!File.Exists(target)) continue;
                File.Delete(target);
                removed++;
            }
            return removed;
        }

        public static string NormalizeImpulseAreaMode(string mode, string fallback)
        {
            string value = (mode ?? string.Empty).Trim().ToLowerInvariant();
            if (value == "off" || value == "gentle" || value == "strict")
            {
                return value;
            }

            string safeFallback = (fallback ?? string.Empty).Trim().ToLowerInvariant();
            return (safeFallback == "off" || safeFallback == "gentle" || safeFallback == "strict") ? safeFallback : "off";
        }

        public static int NormalizeGamblingDelayMinutes(int minutes)
        {
            return (minutes == 2 || minutes == 5 || minutes == 10 || minutes == 15) ? minutes : 10;
        }

        public static string BuildInformationAndHelpText()
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Purestate: Informationen und Hilfe");
            builder.AppendLine();
            builder.AppendLine("Purestate ist ein technisches Selbstschutz-Werkzeug. Es stellt keine Diagnose und ersetzt keine medizinische, psychologische oder psychotherapeutische Behandlung oder Beratung. Es ersetzt auch keine rechtliche oder finanzielle Beratung.");
            builder.AppendLine();
            builder.AppendLine("Offizielle und professionelle Anlaufstellen (Deutschland):");
            builder.AppendLine("- OASIS-Spielersperre: https://rp-darmstadt.hessen.de/sicherheit-und-kommunales/gluecksspiel/spielersperrsystem-oasis/spielerinnen-und-spieler");
            builder.AppendLine("- BIÖG-Beratungstelefon zur Glücksspielsucht: 0800 1 37 27 00 (kostenfrei und anonym)");
            builder.AppendLine("- Hilfe vor Ort: https://www.suchthilfeverzeichnis.de/");
            builder.AppendLine("- Kostenfreie anonyme Onlineberatung: https://www.suchtberatung.digital/");
            builder.AppendLine();
            builder.AppendLine("Bei unmittelbarer Gefahr oder einem medizinischen Notfall: 112.");
            return builder.ToString();
        }
    }
}
