using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // Start page: the status card above already answers "am I protected" and
    // offers the one main action. This page only adds a plain-language summary
    // of the five protection areas - no technical cards, no raw booleans.
    internal sealed partial class AdminForm
    {
        private readonly Dictionary<string, Label> startAreaStatusLabels = new Dictionary<string, Label>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, Label> areaPageStatusLabels = new Dictionary<string, Label>(StringComparer.OrdinalIgnoreCase);
        private Label focusStatusLabel;
        private Button focusButton;
        private FocusStatus focusStatus;

        private void BuildStartPage()
        {
            TableLayoutPanel page = CreatePage("start");
            AddPageTitle(page, "Start");
            AddPageHint(page, "Hier siehst du auf einen Blick, was Purestate auf diesem Gerät gerade macht.");
            BuildUpdateBanner(page);
            BuildStartFocusSection(page);

            AddSectionTitle(page, "Deine Schutzbereiche");

            string[] areaIds =
            {
                Support.AreaAdultContent,
                Support.AreaGambling,
                Support.AreaShopping,
                Support.AreaSocialMedia,
                Support.AreaVideoGames
            };
            foreach (string areaId in areaIds)
            {
                page.Controls.Add(BuildStartAreaRow(areaId));
            }

            Button openAreas = Ui.SecondaryButton(theme, "Schutzbereiche ansehen und einstellen", "Öffnet die Seite mit allen fünf Schutzbereichen.");
            openAreas.Margin = new Padding(0, Ui.GapGroup, 0, 0);
            openAreas.Click += delegate { NavigateTo("areas"); };
            page.Controls.Add(openAreas);
            actionButtons.Add(openAreas);
            themeAppliers.Add(delegate { Ui.StyleSecondary(theme, openAreas); });

            Button guidedSetup = Ui.SecondaryButton(theme, "Geführte Einrichtung", "Geht die fünf Schutzbereiche Schritt für Schritt durch.");
            guidedSetup.Margin = new Padding(0, Ui.GapSmall, 0, 0);
            guidedSetup.Click += delegate { StartGuidedSetup(); };
            page.Controls.Add(guidedSetup);
            actionButtons.Add(guidedSetup);
            themeAppliers.Add(delegate { Ui.StyleSecondary(theme, guidedSetup); });
        }

        private void BuildStartFocusSection(TableLayoutPanel page)
        {
            AddSectionTitle(page, "Lernmodus");
            RoundCard row = (RoundCard)Ui.CommandRow(theme, "Ablenkungen sperren",
                "Stand gerade nicht abrufbar", "Lernmodus starten", "Öffnet die Dauer, Pausen und gesperrten Einträge für den Lernmodus.",
                delegate { using (DialogShell dialog = FocusDialog.Create(theme, RefreshStatus)) { dialog.ShowDialog(this); } });
            TableLayoutPanel copy = (TableLayoutPanel)row.GetControlFromPosition(0, 0);
            focusStatusLabel = (Label)copy.GetControlFromPosition(0, 1);
            focusButton = (Button)row.GetControlFromPosition(1, 0);
            actionButtons.Add(focusButton);
            page.Controls.Add(row);
            themeAppliers.Add(delegate
            {
                Ui.StyleCard(theme, row);
                copy.Controls[0].ForeColor = theme.TextPrimary;
                focusStatusLabel.ForeColor = theme.TextSecondary;
                Ui.StyleSecondary(theme, focusButton);
            });
            ApplyFocusStatus(null);
        }

        private void ApplyFocusStatus(FocusStatus status)
        {
            focusStatus = status;
            if (focusStatusLabel == null) { return; }
            string text = FocusStatusText(status, DateTime.Now);
            if (status != null && status.Available)
            {
                if (status.BetaExpired) { text += " " + Support.FocusErrorText("beta-expired"); }
                else if (status.Phase == "off" && !status.Covered) { text += " " + Support.FocusErrorText("no-companion"); }
            }
            Ui.SetDynamicText(focusStatusLabel, text, "Lernmodus Status");
            bool active = status != null && status.Available && status.Phase != "off";
            focusButton.Text = active ? "Liste erweitern" : "Lernmodus starten";
            Ui.SetAccessibility(focusButton, focusButton.Text, "Öffnet die Einstellungen und gesperrten Einträge für den Lernmodus.", AccessibleRole.PushButton);
            UpdateFocusButton();
        }

        private void UpdateFocusButton()
        {
            if (focusButton != null)
                focusButton.Enabled = actionButtonsEnabled && focusStatus != null && focusStatus.Available &&
                    !focusStatus.BetaExpired && (focusStatus.Phase != "off" || focusStatus.Covered);
        }

        internal static string FocusStatusText(FocusStatus status, DateTime nowLocal)
        {
            if (status == null || !status.Available) { return "Stand gerade nicht abrufbar"; }
            string end = nowLocal.AddSeconds(status.EndSeconds).ToString("HH:mm");
            string edge = nowLocal.AddSeconds(status.EdgeSeconds).ToString("HH:mm");
            if (status.Phase == "break") { return "Pause bis " + edge + " Uhr, danach geht der Lernmodus weiter. Ende um " + end + " Uhr."; }
            if (status.Phase == "learn")
                return status.EdgeSeconds < status.EndSeconds ? "Lernmodus läuft. Nächste Pause um " + edge + " Uhr, Ende um " + end + " Uhr." : "Lernmodus läuft bis " + end + " Uhr.";
            return "Sperrt für eine gewählte Zeit alles Ablenkende. Lässt sich nicht vorzeitig beenden.";
        }

        private Control BuildStartAreaRow(string areaId)
        {
            TableLayoutPanel row = new TableLayoutPanel
            {
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 2,
                Margin = Dpi.Padding(0, 0, 0, 4),
                Padding = Dpi.Padding(8, 4, 8, 4),
                BackColor = Color.Transparent
            };
            Ui.FitToPageColumn(row, Dpi.Px(44));
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Dpi.Px(200)));
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));

            Label name = new Label
            {
                Text = AreaDisplayName(areaId),
                Font = Ui.FontBodyBold,
                ForeColor = theme.TextPrimary,
                AutoSize = true,
                MinimumSize = Dpi.Size(0, 28),
                TextAlign = ContentAlignment.MiddleLeft,
                Margin = Dpi.Padding(0, 2, 0, 2)
            };
            Ui.SetAccessibility(name, AreaDisplayName(areaId), "Schutzbereich " + AreaDisplayName(areaId) + ".", AccessibleRole.StaticText);
            row.Controls.Add(name, 0, 0);

            Label status = new Label
            {
                Text = "wird ermittelt ...",
                Font = Ui.FontBody,
                ForeColor = theme.TextSecondary,
                AutoSize = true,
                MinimumSize = Dpi.Size(0, 28),
                TextAlign = ContentAlignment.MiddleLeft,
                Margin = Dpi.Padding(0, 2, 0, 2)
            };
            Ui.SetAccessibility(status, AreaDisplayName(areaId) + " Status", "Aktueller Zustand dieses Schutzbereichs in einfacher Sprache.", AccessibleRole.StaticText);
            row.Controls.Add(status, 1, 0);

            startAreaStatusLabels[areaId] = status;
            themeAppliers.Add(delegate
            {
                name.ForeColor = theme.TextPrimary;
                status.ForeColor = theme.TextSecondary;
            });
            return row;
        }

        // Called from ApplyStatusSnapshot with lines "id|name|statusText".
        private void ApplyAreaStatusLines(string[] lines)
        {
            if (lines == null)
            {
                return;
            }
            foreach (string line in lines)
            {
                string[] parts = line.Split(new[] { '|' }, 3);
                if (parts.Length < 3)
                {
                    continue;
                }
                Label startLabel;
                // DESK-05: Der Screenreader-Name traegt den aktuellen Zustand
                // ("Shopping Status: Zeitlimit 30 Minuten täglich").
                if (startAreaStatusLabels.TryGetValue(parts[0], out startLabel))
                {
                    Ui.SetDynamicText(startLabel, parts[2], parts[1] + " Status");
                }
                Label pageLabel;
                if (areaPageStatusLabels.TryGetValue(parts[0], out pageLabel))
                {
                    Ui.SetDynamicText(pageLabel, parts[2], parts[1] + " Status");
                }
            }
            UpdateGuidedSetupStatus();
        }
    }
}
