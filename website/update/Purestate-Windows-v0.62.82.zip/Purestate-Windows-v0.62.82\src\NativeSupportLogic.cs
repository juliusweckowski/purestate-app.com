using System;
using System.Collections.Generic;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace Purestate.Native
{
    internal static partial class Support
    {
        // ---- Cryptography -------------------------------------------------------

        public const int MinimumPasswordLength = 12;
        public const int LongPassphraseLength = 20;
        public const string PasswordPolicyMessage = "Das Passwort muss mindestens 12 Zeichen haben und entweder drei Zeichenarten enthalten oder eine lange Passphrase ab 20 Zeichen sein.";

        public static PasswordRecord NewPasswordRecord(string password)
        {
            string policyError = GetPasswordPolicyError(password, string.Empty);
            if (!string.IsNullOrEmpty(policyError))
            {
                throw new InvalidOperationException(policyError);
            }

            byte[] salt = new byte[16];
            using (RandomNumberGenerator rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }

            const int iterations = 180000;
            byte[] hash;
            using (Rfc2898DeriveBytes derive = new Rfc2898DeriveBytes(password, salt, iterations, HashAlgorithmName.SHA256))
            {
                hash = derive.GetBytes(32);
            }

            return new PasswordRecord
            {
                Algorithm = "PBKDF2-SHA256",
                Iterations = iterations,
                Salt = Convert.ToBase64String(salt),
                Hash = Convert.ToBase64String(hash)
            };
        }

        public static string GetPasswordPolicyError(string password, string hint)
        {
            string value = password ?? string.Empty;
            if (value.Length < MinimumPasswordLength)
            {
                return PasswordPolicyMessage;
            }

            if (string.IsNullOrWhiteSpace(value) || value.IndexOf('\r') >= 0 || value.IndexOf('\n') >= 0)
            {
                return "Das Passwort darf nicht leer sein und keine Zeilenumbrueche enthalten.";
            }

            bool hasLower = false;
            bool hasUpper = false;
            bool hasDigit = false;
            bool hasSymbol = false;
            bool allSame = true;
            for (int index = 0; index < value.Length; index++)
            {
                char c = value[index];
                if (index > 0 && c != value[0])
                {
                    allSame = false;
                }
                if (char.IsLower(c)) hasLower = true;
                else if (char.IsUpper(c)) hasUpper = true;
                else if (char.IsDigit(c)) hasDigit = true;
                else hasSymbol = true;
            }

            if (allSame)
            {
                return "Das Passwort darf nicht nur aus demselben Zeichen bestehen.";
            }

            int categories = 0;
            if (hasLower) categories++;
            if (hasUpper) categories++;
            if (hasDigit) categories++;
            if (hasSymbol) categories++;
            if (value.Length < LongPassphraseLength && categories < 3)
            {
                return PasswordPolicyMessage;
            }

            string lowered = value.ToLowerInvariant();
            if (lowered.Contains("purestate") || lowered.Contains("password") || lowered.Contains("passwort"))
            {
                return "Das Passwort darf keine offensichtlichen Produkt- oder Passwortbegriffe enthalten.";
            }

            string cleanHint = CleanPasswordHint(hint);
            if (cleanHint.Length > 0 && cleanHint.ToLowerInvariant().Contains(lowered))
            {
                return "Der Passworthinweis darf das Passwort nicht enthalten.";
            }

            return string.Empty;
        }

        public static void EnsurePasswordPolicy(string password, string hint)
        {
            string error = GetPasswordPolicyError(password, hint);
            if (!string.IsNullOrEmpty(error))
            {
                throw new InvalidOperationException(error);
            }
        }

        // ---- Config integrity (HMAC) --------------------------------------------

        // Language-neutral canonical form of the security-relevant config
        // fields. MUST stay byte-for-byte identical to Get-ConfigCanonical in
        // scripts\Common.ps1 (a cross-language oracle test in
        // tests\Purestate.Tests.ps1 / PurestateLogicTests.cs enforces this).
        // Uses raw in-memory values because both LoadConfig and PowerShell
        // Get-Config normalize on load; bools map to "true"/"false"; every
        // line ends with '\n'. The Integrity field itself is never included.
        // CFG-002: Hier stand frueher, PasswordHint UND die
        // Deinstallations-Karenzfelder seien bewusst ausgenommen. Fuer die
        // Karenzfelder war das falsch - PendingUninstallUntilUtc und
        // UninstallApprovalExpiresUtc stehen sehr wohl im Kanonisat, und das
        // ist auch richtig so: sie tragen die 7-Tage-Deinstallationsfrist.
        // Ein Kommentar, der zwei signierte Felder als "kein Umgehungspfad"
        // bezeichnet, laedt dazu ein, ihre Behandlung spaeter zu lockern.
        // Ausgenommen sind, nachgezaehlt: PasswordHint und
        // BrowserPoliciesEnabled (beide bewusst), Integrity selbst,
        // IntegrityCompromised (Laufzeitflag, nicht persistiert) sowie die
        // Altfelder GamblingSupportEnabled/-Mode. Die beiden Altfelder koennen
        // den Glücksspielschutz an JEDER Auswertungsstelle nur einschalten
        // ("||"), nie ausschalten - unsigniert sind sie damit ungefaehrlich.
        // Password ist ueber die vier Password.*-Zeilen gedeckt.
        // ConfigCanonicalFieldCoverageTests haelt diese Liste gegen die
        // wirklichen Felder; ein neues Feld faellt dort auf, statt still einen
        // Nebenkanal zu oeffnen.
        internal static string BuildConfigCanonical(AppConfig config, int schemaVersion, bool includeSchemaLine, bool betaSchema14 = false)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }
            if (betaSchema14 && schemaVersion != 14)
            {
                throw new ArgumentException("The beta canonical variant only exists for schema 14.", "schemaVersion");
            }

            PasswordRecord pw = config.Password;
            StringBuilder sb = new StringBuilder();
            if (includeSchemaLine)
            {
                AppendCanonicalLine(sb, "IntegritySchemaVersion", schemaVersion.ToString());
            }

            AppendCanonicalLine(sb, "ProtectionEnabled", CanonicalBool(config.ProtectionEnabled));
            AppendCanonicalLine(sb, "HostsEnabled", CanonicalBool(config.HostsEnabled));
            AppendCanonicalLine(sb, "FamilyDnsEnabled", CanonicalBool(config.FamilyDnsEnabled));
            AppendCanonicalLine(sb, "DnsProfile", config.DnsProfile ?? string.Empty);
            AppendCanonicalLine(sb, "BypassBlockingEnabled", CanonicalBool(config.BypassBlockingEnabled));
            AppendCanonicalLine(sb, "UnsupportedBrowserBlockingEnabled", CanonicalBool(config.UnsupportedBrowserBlockingEnabled));
            AppendCanonicalLine(sb, "TamperProtectionEnabled", CanonicalBool(config.TamperProtectionEnabled));
            AppendCanonicalLine(sb, "SiteRedditEnabled", CanonicalBool(config.SiteRedditEnabled));
            AppendCanonicalLine(sb, "SiteXEnabled", CanonicalBool(config.SiteXEnabled));
            AppendCanonicalLine(sb, "SiteBlueskyEnabled", CanonicalBool(config.SiteBlueskyEnabled));
            AppendCanonicalLine(sb, "SiteTumblrEnabled", CanonicalBool(config.SiteTumblrEnabled));
            AppendCanonicalLine(sb, "SiteDeviantArtEnabled", CanonicalBool(config.SiteDeviantArtEnabled));
            AppendCanonicalLine(sb, "SitePixivEnabled", CanonicalBool(config.SitePixivEnabled));
            AppendCanonicalLine(sb, "SiteNewgroundsEnabled", CanonicalBool(config.SiteNewgroundsEnabled));
            AppendCanonicalLine(sb, "SiteImgurEnabled", CanonicalBool(config.SiteImgurEnabled));
            AppendCanonicalLine(sb, "SiteInstagramEnabled", CanonicalBool(config.SiteInstagramEnabled));
            AppendCanonicalLine(sb, "SiteTikTokEnabled", CanonicalBool(config.SiteTikTokEnabled));
            AppendCanonicalLine(sb, "SitePinterestEnabled", CanonicalBool(config.SitePinterestEnabled));
            AppendCanonicalLine(sb, "AdultContentProtectionEnabled", CanonicalBool(config.AdultContentProtectionEnabled));
            AppendCanonicalLine(sb, "AdultContentProtectionMode", config.AdultContentProtectionMode ?? string.Empty);
            AppendCanonicalLine(sb, "GamblingProtectionEnabled", CanonicalBool(EffectiveGamblingProtectionEnabled(config)));
            AppendCanonicalLine(sb, "GamblingProtectionMode", EffectiveGamblingProtectionMode(config));
            AppendCanonicalLine(sb, "ShoppingProtectionEnabled", CanonicalBool(config.ShoppingProtectionEnabled));
            AppendCanonicalLine(sb, "ShoppingProtectionMode", config.ShoppingProtectionMode ?? string.Empty);
            AppendCanonicalLine(sb, "ShoppingCheckoutDelayEnabled", CanonicalBool(config.ShoppingCheckoutDelayEnabled));
            AppendCanonicalLine(sb, "ShoppingStimulusDampingEnabled", CanonicalBool(config.ShoppingStimulusDampingEnabled));
            AppendCanonicalLine(sb, "ShoppingDealSearchBlockEnabled", CanonicalBool(config.ShoppingDealSearchBlockEnabled));
            AppendCanonicalLine(sb, "ShoppingCurfewEnabled", CanonicalBool(config.ShoppingCurfewEnabled));
            AppendCanonicalLine(sb, "ShoppingCurfewStart", config.ShoppingCurfewStart ?? string.Empty);
            AppendCanonicalLine(sb, "ShoppingCurfewEnd", config.ShoppingCurfewEnd ?? string.Empty);
            if (schemaVersion >= 2)
            {
                AppendCanonicalLine(sb, "ShoppingDailyLimitEnabled", CanonicalBool(config.ShoppingDailyLimitEnabled));
                AppendCanonicalLine(sb, "ShoppingDailyLimitMinutes", config.ShoppingDailyLimitMinutes.ToString());
                AppendCanonicalLine(sb, "ShoppingMonthlyOrderLimitEnabled", CanonicalBool(config.ShoppingMonthlyOrderLimitEnabled));
                AppendCanonicalLine(sb, "ShoppingMonthlyOrderLimit", config.ShoppingMonthlyOrderLimit.ToString());
                AppendCanonicalLine(sb, "ShoppingMonthlyBudgetEnabled", CanonicalBool(config.ShoppingMonthlyBudgetEnabled));
                AppendCanonicalLine(sb, "ShoppingMonthlyBudgetEuro", config.ShoppingMonthlyBudgetEuro.ToString());
                AppendCanonicalLine(sb, "GamblingDailyLimitEnabled", CanonicalBool(config.GamblingDailyLimitEnabled));
                AppendCanonicalLine(sb, "GamblingDailyLimitMinutes", config.GamblingDailyLimitMinutes.ToString());
            }
            if (schemaVersion >= 3)
            {
                AppendCanonicalLine(sb, "SocialMediaDailyBudgetEnabled", CanonicalBool(config.SocialMediaDailyBudgetEnabled));
                AppendCanonicalLine(sb, "SocialMediaDailyBudgetMinutes", config.SocialMediaDailyBudgetMinutes.ToString());
                AppendCanonicalLine(sb, "SocialMediaPlatformLimits", config.SocialMediaPlatformLimits ?? string.Empty);
                AppendCanonicalLine(sb, "SocialMediaBlockedPlatforms", config.SocialMediaBlockedPlatforms ?? string.Empty);
                AppendCanonicalLine(sb, "SocialMediaCurfewEnabled", CanonicalBool(config.SocialMediaCurfewEnabled));
                AppendCanonicalLine(sb, "SocialMediaCurfewStart", config.SocialMediaCurfewStart ?? string.Empty);
                AppendCanonicalLine(sb, "SocialMediaCurfewEnd", config.SocialMediaCurfewEnd ?? string.Empty);
                AppendCanonicalLine(sb, "SocialMediaReflectionEnabled", CanonicalBool(config.SocialMediaReflectionEnabled));
                AppendCanonicalLine(sb, "SocialMediaFeedDampingEnabled", CanonicalBool(config.SocialMediaFeedDampingEnabled));
            }
            if (schemaVersion >= 4)
            {
                AppendCanonicalLine(sb, "SocialMediaFeedDampingScrolls", config.SocialMediaFeedDampingScrolls.ToString());
            }
            if (schemaVersion >= 5)
            {
                AppendCanonicalLine(sb, "VideoGamesDailyLimitEnabled", CanonicalBool(config.VideoGamesDailyLimitEnabled));
                AppendCanonicalLine(sb, "VideoGamesDailyLimitMinutes", config.VideoGamesDailyLimitMinutes.ToString());
                AppendCanonicalLine(sb, "VideoGamesCurfewEnabled", CanonicalBool(config.VideoGamesCurfewEnabled));
                AppendCanonicalLine(sb, "VideoGamesCurfewStart", config.VideoGamesCurfewStart ?? string.Empty);
                AppendCanonicalLine(sb, "VideoGamesCurfewEnd", config.VideoGamesCurfewEnd ?? string.Empty);
            }
            if (schemaVersion >= 6)
            {
                AppendCanonicalLine(sb, "VideoGamesAutoDetectEnabled", CanonicalBool(config.VideoGamesAutoDetectEnabled));
                AppendCanonicalLine(sb, "VideoGamesHeuristicEnabled", CanonicalBool(config.VideoGamesHeuristicEnabled));
            }
            AppendCanonicalLine(sb, "VideoGamesProtectionEnabled", CanonicalBool(config.VideoGamesProtectionEnabled));
            AppendCanonicalLine(sb, "VideoGamesProtectionMode", config.VideoGamesProtectionMode ?? string.Empty);
            AppendCanonicalLine(sb, "SocialMediaProtectionEnabled", CanonicalBool(config.SocialMediaProtectionEnabled));
            AppendCanonicalLine(sb, "SocialMediaProtectionMode", config.SocialMediaProtectionMode ?? string.Empty);
            AppendCanonicalLine(sb, "ProtectionAreaRulePackVersion", config.ProtectionAreaRulePackVersion ?? string.Empty);
            AppendCanonicalLine(sb, "LockdownModeEnabled", CanonicalBool(config.LockdownModeEnabled));
            AppendCanonicalLine(sb, "PauseCooldownEnabled", CanonicalBool(config.PauseCooldownEnabled));
            AppendCanonicalLine(sb, "ScheduleEnabled", CanonicalBool(config.ScheduleEnabled));
            AppendCanonicalLine(sb, "StrictModeEnabled", CanonicalBool(config.StrictModeEnabled));
            AppendCanonicalLine(sb, "ScheduleStart", config.ScheduleStart ?? string.Empty);
            AppendCanonicalLine(sb, "ScheduleEnd", config.ScheduleEnd ?? string.Empty);
            AppendCanonicalLine(sb, "PauseUntilUtc", config.PauseUntilUtc ?? string.Empty);
            AppendCanonicalLine(sb, "PendingPauseUntilUtc", config.PendingPauseUntilUtc ?? string.Empty);
            AppendCanonicalLine(sb, "PendingUninstallUntilUtc", config.PendingUninstallUntilUtc ?? string.Empty);
            AppendCanonicalLine(sb, "UninstallApprovalExpiresUtc", config.UninstallApprovalExpiresUtc ?? string.Empty);
            AppendCanonicalLine(sb, "PasswordFailedAttempts", Math.Max(0, config.PasswordFailedAttempts).ToString());
            AppendCanonicalLine(sb, "PasswordLockoutUntilUtc", config.PasswordLockoutUntilUtc ?? string.Empty);
            AppendCanonicalLine(sb, "Password.Algorithm", pw == null ? string.Empty : (pw.Algorithm ?? string.Empty));
            AppendCanonicalLine(sb, "Password.Iterations", pw == null ? "0" : pw.Iterations.ToString());
            AppendCanonicalLine(sb, "Password.Salt", pw == null ? string.Empty : (pw.Salt ?? string.Empty));
            AppendCanonicalLine(sb, "Password.Hash", pw == null ? string.Empty : (pw.Hash ?? string.Empty));
            if (schemaVersion >= 7)
            {
                AppendCanonicalLine(sb, "InstalledVersion", config.InstalledVersion ?? string.Empty);
                AppendCanonicalLine(sb, "ShoppingDelayDefaultMinutes", config.ShoppingDelayDefaultMinutes.ToString());
            }
            if (schemaVersion >= 8)
            {
                AppendCanonicalLine(sb, "SocialMediaFeedBlockedPlatforms", config.SocialMediaFeedBlockedPlatforms ?? string.Empty);
            }
            if (schemaVersion >= 9)
            {
                AppendCanonicalLine(sb, "ClockAnchorUtc", config.ClockAnchorUtc ?? string.Empty);
                AppendCanonicalLine(sb, "ClockTickAnchorMs", config.ClockTickAnchorMs.ToString(System.Globalization.CultureInfo.InvariantCulture));
            }
            if (schemaVersion >= 10)
            {
                AppendCanonicalLine(sb, "WeakeningRequestedUtc", config.WeakeningRequestedUtc ?? string.Empty);
            }
            if (schemaVersion >= 11)
            {
                AppendCanonicalLine(sb, "AuthorityMode", NormalizeAuthorityMode(config.AuthorityMode));
                AppendCanonicalLine(sb, "PolicyVersion", config.PolicyVersion.ToString(System.Globalization.CultureInfo.InvariantCulture));
                AppendCanonicalLine(sb, "WeakeningGrant", config.WeakeningGrant ?? string.Empty);
                AppendCanonicalLine(sb, "GrantSignature", config.GrantSignature ?? string.Empty);
                AppendCanonicalLine(sb, "EntitledUntilUtc", config.EntitledUntilUtc ?? string.Empty);
            }
            if (schemaVersion >= 12)
            {
                AppendCanonicalLine(sb, "CompanionGrace", config.CompanionGrace ?? string.Empty);
            }
            if (schemaVersion >= 13)
            {
                AppendCanonicalLine(sb, "YouTubeRestrictEnabled", CanonicalBool(config.YouTubeRestrictEnabled));
            }
            if (schemaVersion >= 14 && !betaSchema14)
            {
                AppendCanonicalLine(sb, "AdultHostsFollowArea", CanonicalBool(config.AdultHostsFollowArea));
            }
            if (schemaVersion >= 15 || betaSchema14)
            {
                AppendCanonicalLine(sb, "EntitlementSignature", config.EntitlementSignature ?? string.Empty);
                AppendCanonicalLine(sb, "EntitlementMaxDevices", config.EntitlementMaxDevices.ToString(System.Globalization.CultureInfo.InvariantCulture));
            }
            return sb.ToString();
        }

        private static void AppendCanonicalLine(StringBuilder builder, string key, string value)
        {
            builder.Append(key).Append('=').Append(value ?? string.Empty).Append('\n');
        }

        private static string CanonicalBool(bool value)
        {
            return value ? "true" : "false";
        }

        internal static string ComputeConfigIntegrity(AppConfig config, byte[] key)
        {
            if (config != null && config.IntegritySchemaVersion == CurrentIntegritySchemaVersion)
            {
                return ComputeConfigIntegrityForSchema(config, key, CurrentIntegritySchemaVersion);
            }

            // Unversioned = the 0.62.18 on-disk format: schema-2 canonical
            // WITHOUT a schema line. Pinned to 2 on purpose - it must keep
            // matching existing signatures across future schema bumps.
            return ComputeHmac(BuildConfigCanonical(config, 2, false), key);
        }

        internal static string ComputeConfigIntegrityForSchema(AppConfig config, byte[] key, int schemaVersion, bool betaSchema14 = false)
        {
            // Schema 2 was the first version that wrote the schema line into
            // the canonical, so the floor is a fixed 2 - never relative to
            // CurrentIntegritySchemaVersion (that would silently re-sign old
            // schemas without their line and break every existing config).
            return ComputeHmac(BuildConfigCanonical(config, schemaVersion, schemaVersion >= 2, betaSchema14), key);
        }

        // ---- Vertrauenswuerdige Uhr ---------------------------------------------

        // Wanduhr und monotone Uhr duerfen pro Tick um diesen Betrag
        // auseinanderlaufen, bevor es als Manipulation gilt. Deckt NTP- und
        // Zeitzonenkorrekturen sowie Tick-Verzoegerung unter Last ab.
        public const double ClockJumpToleranceSeconds = 60.0;

        // Reine Fortschreibungsregel fuer den signierten Uhr-Anker. Der Anker
        // geht nie rueckwaerts, und ein Vorwaertssprung der Wanduhr wird nur
        // mit der monoton gemessenen Dauer gutgeschrieben.
        // monotonicElapsedSeconds stammt von GetTickCount64: schlaf- und
        // ruhezustandsfest und unabhaengig von der Systemuhr.
        public static DateTime ComputeNextClockAnchor(
            DateTime anchorUtc,
            DateTime wallUtc,
            double monotonicElapsedSeconds,
            double wallElapsedSeconds,
            out bool jumpDetected)
        {
            jumpDetected = false;

            if (monotonicElapsedSeconds < 0.0)
            {
                monotonicElapsedSeconds = 0.0;
            }

            if (wallElapsedSeconds > monotonicElapsedSeconds + ClockJumpToleranceSeconds)
            {
                jumpDetected = true;
                return anchorUtc.AddSeconds(monotonicElapsedSeconds);
            }

            return wallUtc > anchorUtc ? wallUtc : anchorUtc;
        }

        private static bool TryReadClockAnchor(AppConfig config, out DateTime anchor)
        {
            anchor = DateTime.MinValue;
            if (config == null || string.IsNullOrEmpty(config.ClockAnchorUtc))
            {
                return false;
            }

            DateTime parsed;
            if (!DateTime.TryParse(config.ClockAnchorUtc, null, System.Globalization.DateTimeStyles.RoundtripKind, out parsed))
            {
                return false;
            }

            anchor = parsed.Kind == DateTimeKind.Utc ? parsed : parsed.ToUniversalTime();
            return true;
        }

        // Massgebliche Uhr fuer JEDES Gate: Wartefristen, Cooldowns,
        // Sperrzeiten, Tagesbudgets, Lockout, Abschwaechungsfenster. Liefert
        // den vom Guard fortgeschriebenen Anker, NICHT die Systemuhr. Steht
        // der Guard, friert diese Uhr ein und keine Wartefrist laeuft ab. Das
        // ist beabsichtigt fail-closed: Dienst stoppen, Uhr stellen, App
        // oeffnen bringt dem Angreifer damit nichts.
        public static DateTime TrustedUtcNow(AppConfig config)
        {
            DateTime anchor;
            if (TryReadClockAnchor(config, out anchor))
            {
                return anchor;
            }

            // Noch nie geschrieben (Neuinstallation, Migration aus Schema <9):
            // die Systemuhr ist der Startwert, den der Guard beim naechsten
            // Tick festschreibt.
            return DateTime.UtcNow;
        }

        public static DateTime TrustedUtcNow()
        {
            return TrustedUtcNow(LoadConfig());
        }

        public static DateTime TrustedLocalNow(AppConfig config)
        {
            return TrustedUtcNow(config).ToLocalTime();
        }

        public static DateTime TrustedLocalNow()
        {
            return TrustedUtcNow().ToLocalTime();
        }

        // AUSNAHME, ausschliesslich fuer den Deinstallationspfad. Sie darf nie
        // einfrieren, weil sonst ein gestoppter Guard das Entfernen dauerhaft
        // verhindern wuerde - das waere unerwuenschte Software. Sie ist nur
        // rueckwaerts-, nicht vorwaertsfest: die bewusst akzeptierte Grenze
        // aus der Architekturspezifikation.
        public static DateTime MonotonicUtcNow()
        {
            DateTime wall = DateTime.UtcNow;
            DateTime anchor = TrustedUtcNow();
            return wall > anchor ? wall : anchor;
        }

        private static string ComputeHmac(string canonical, byte[] key)
        {
            byte[] data = Encoding.UTF8.GetBytes(canonical);
            using (HMACSHA256 hmac = new HMACSHA256(key))
            {
                return Convert.ToBase64String(hmac.ComputeHash(data));
            }
        }

        // ---- Password attempt throttling ---------------------------------------

        // The first PasswordLockoutThreshold consecutive wrong passwords are
        // free; from there each further wrong password locks the password
        // prompt for an exponentially growing window (base doubling, capped),
        // which turns scripted guessing against the 180k-iteration PBKDF2 hash
        // from "tens per second" into "one per cooldown". The counter lives in
        // the HMAC-protected config, so resetting it by editing config.json
        // trips the integrity check and re-enables protection.
        public const int PasswordLockoutThreshold = 5;
        public const int PasswordLockoutBaseSeconds = 30;
        public const int PasswordLockoutCapSeconds = 1800;

        public static int ComputePasswordLockoutSeconds(int failedAttempts)
        {
            if (failedAttempts < PasswordLockoutThreshold)
            {
                return 0;
            }

            int steps = failedAttempts - PasswordLockoutThreshold;
            long seconds = PasswordLockoutBaseSeconds;
            for (int i = 0; i < steps && seconds < PasswordLockoutCapSeconds; i++)
            {
                seconds *= 2;
            }

            return (int)Math.Min(seconds, (long)PasswordLockoutCapSeconds);
        }

        // ---- Protection policy --------------------------------------------------

        // Der eine Ort, an dem der Ablauf im Hauptprogramm wirkt. Die zwoelf
        // Aufrufer - Verwaltungsoberflaeche, Status- und Berichtspfade,
        // Durchsetzungs-Einstiege und das Sperrmodus-Gate - erben ihn dadurch,
        // ohne einzeln angefasst zu werden.
        //
        // NICHT geerbt wird der Guard: PurestateGuard.exe ist ein eigenes
        // Programm, das ohne die NativeSupport*-Dateien uebersetzt wird (siehe
        // tools/Build-Release.ps1) und diese Klasse deshalb gar nicht kennt. Er
        // setzt ueber scripts/Enforce-Protection.ps1 durch und faellt dort an
        // Test-ProtectionShouldRun. Der Ablauf muss dort GESONDERT gezogen
        // werden - wer nur diese Zeile liest, haelt die Maschine sonst
        // faelschlich fuer entwaffnet.
        public static bool ProtectionShouldBeActive(AppConfig config)
        {
            return config != null
                && !IsEntitlementExpired(config)
                && (config.ProtectionEnabled || IsScheduleActiveNow(config));
        }

        public static bool IsScheduleActiveNow(AppConfig config)
        {
            return IsScheduleActiveAt(config, TrustedLocalNow(config));
        }

        public static bool IsScheduleActiveAt(AppConfig config, DateTime localTime)
        {
            if (config == null || !config.ScheduleEnabled)
            {
                return false;
            }

            int start;
            int end;
            if (!TryParseTimeText(config.ScheduleStart, out start) || !TryParseTimeText(config.ScheduleEnd, out end) || start == end)
            {
                return false;
            }

            int now = localTime.Hour * 60 + localTime.Minute;
            if (start < end)
            {
                return now >= start && now < end;
            }

            return now >= start || now < end;
        }

        public static string ScheduleDescription(AppConfig config)
        {
            if (config == null || !config.ScheduleEnabled)
            {
                return "aus";
            }

            string label = NormalizeTimeText(config.ScheduleStart, "22:00") + "-" + NormalizeTimeText(config.ScheduleEnd, "06:00");
            label += IsScheduleActiveNow(config) ? " (jetzt aktiv)" : " (gerade aus)";
            if (config.StrictModeEnabled)
            {
                label += ", streng";
            }

            return label;
        }

        public static string PauseDescription(AppConfig config)
        {
            if (config == null || config.ProtectionEnabled)
            {
                return "keine";
            }

            DateTime until;
            if (TryReadPauseUntil(config, out until) && until > TrustedUtcNow(config))
            {
                return "bis " + until.ToLocalTime().ToString("g");
            }

            DateTime pendingUntil;
            if (TryReadPendingPauseUntil(config, out pendingUntil) && pendingUntil > TrustedUtcNow(config))
            {
                return "Abkuehlzeit bis " + pendingUntil.ToLocalTime().ToString("g");
            }

            return "unbegrenzt";
        }

        // ---- Uninstall cooldown -------------------------------------------------

        public static int EvaluateUninstallCooldown(AppConfig config, DateTime utcNow, out int remainingSeconds)
        {
            remainingSeconds = 0;
            if (config == null)
            {
                return 0;
            }

            // Ist die Fassung abgelaufen, gibt es nichts mehr zu schuetzen -
            // der Schutz ist aus, und Invoke-EntitlementRelease nimmt die
            // Systemaenderungen zurueck, notfalls im naechsten Lauf.
            // Die Frist wuerde dann nur den Ausstieg verzoegern, und zwar genau
            // dann, wenn der Wechsel auf die neue Fassung ansteht.
            //
            // Das schwaecht nichts ab: der Termin stammt aus der eingebauten
            // Fassungsgrenze oder aus einem signierten Serverdatum, beide an der
            // vertrauenswuerdigen Uhr gemessen. Faelschen laesst er sich nicht;
            // vorziehen nur ueber die dokumentierte Restluecke der Uhr
            // (Vorwaertssprung bei gestopptem Dienst, docs/THREAT-MODEL.md) -
            // und damit verkuerzt sich auch jede Wartefrist.
            //
            // Bewusst TrustedUtcNow(config) und nicht der uebergebene utcNow:
            // der Aufrufer reicht hier eine monoton gemessene Zeit fuer die
            // Frist selbst durch, waehrend der Ablauf am fortgeschriebenen
            // Uhr-Anker haengt.
            if (IsEntitlementExpiredAt(config, TrustedUtcNow(config)))
            {
                return 2;
            }

            DateTime readyAt;
            DateTime expiresAt;
            if (!TryReadUtc(config.PendingUninstallUntilUtc, out readyAt) ||
                !TryReadUtc(config.UninstallApprovalExpiresUtc, out expiresAt) ||
                expiresAt <= readyAt || utcNow >= expiresAt)
            {
                return 0;
            }

            if (utcNow < readyAt)
            {
                remainingSeconds = Math.Max(1, (int)Math.Ceiling((readyAt - utcNow).TotalSeconds));
                return 1;
            }

            return 2;
        }

        // ---- DNS profile --------------------------------------------------------

        public static string NormalizeDnsProfile(string profile)
        {
            string value = (profile ?? string.Empty).Trim().ToLowerInvariant();
            if (value == "cleanbrowsing" || value == "cleanbrowsingfamily" || value == "cleanbrowsing family")
            {
                return "CleanBrowsingFamily";
            }

            if (value == "opendns" || value == "opendnsfamily" || value == "opendnsfamilyshield" || value == "opendns familyshield")
            {
                return "OpenDnsFamilyShield";
            }

            return "CloudflareFamily";
        }

        public static string DnsProfileLabel(string profile)
        {
            string normalized = NormalizeDnsProfile(profile);
            if (normalized == "CleanBrowsingFamily")
            {
                return "CleanBrowsing Family";
            }

            if (normalized == "OpenDnsFamilyShield")
            {
                return "OpenDNS FamilyShield";
            }

            return "Cloudflare Family";
        }

        public static string DnsProfileFromLabel(string label)
        {
            return NormalizeDnsProfile(label);
        }

        public static string[] DnsProfileLabels()
        {
            return new string[]
            {
                "Cloudflare Family",
                "CleanBrowsing Family",
                "OpenDNS FamilyShield"
            };
        }

        // Gemessen am 2026-10-06: CleanBrowsing Family beantwortet www.youtube.com
        // mit der Adresse von restrictmoderate.youtube.com und erzwingt den
        // eingeschraenkten YouTube-Modus damit auf DNS-Ebene - am Schalter
        // "YouTube im eingeschraenkten Modus" vorbei, der dagegen nichts ausrichten
        // kann. Cloudflare Family und OpenDNS FamilyShield liefern die normalen
        // Adressen. Die Einstellungen sagen das beim Waehlen des Profils.
        public static bool DnsProfileForcesYouTubeRestrict(string profile)
        {
            return NormalizeDnsProfile(profile) == "CleanBrowsingFamily";
        }

        // ---- Password hint ------------------------------------------------------

        public static string CleanPasswordHint(string hint)
        {
            string value = (hint ?? string.Empty).Replace("\r", " ").Replace("\n", " ").Trim();
            while (value.Contains("  "))
            {
                value = value.Replace("  ", " ");
            }

            if (value.Length > 120)
            {
                value = value.Substring(0, 120).Trim();
            }

            return value;
        }

        // ---- Domain normalization -----------------------------------------------

        public static string NormalizeDomain(string input)
        {
            string value = (input ?? string.Empty).Trim().ToLowerInvariant();
            value = Regex.Replace(value, @"^https?://", string.Empty);
            value = value.Split('/')[0].Trim();
            value = value.Trim('.');
            return value;
        }

        public static bool IsValidDomain(string domain)
        {
            return Regex.IsMatch(domain ?? string.Empty, @"^[a-z0-9.-]+\.[a-z]{2,}$", RegexOptions.IgnoreCase);
        }

        // DOM-002: IsValidDomain laesst nur ASCII zu - richtig, denn genau so
        // steht eine Domain in der hosts-Datei und in der Browser-Richtlinie.
        // Nur wurde eine Eingabe wie "mueller-shop.de" mit echtem Umlaut damit
        // rundweg abgelehnt (frueher sogar still verworfen), obwohl ihre
        // Punycode-Form voellig gueltig ist.
        //
        // Die Wandlung sitzt BEWUSST nur in der Eingabeschicht, wie im Befund
        // empfohlen: zoege sie in die Leser der Regeldateien, muesste sie in
        // allen drei Implementierungen gleich erfolgen (C#, PowerShell,
        // Erweiterung) - und genau diese Divergenz vermeidet das Projekt sonst
        // mit Muehe. Was gespeichert wird, ist ASCII; alle Leser sehen
        // unveraendert dasselbe.
        public static string ToAsciiDomain(string domain)
        {
            string value = domain ?? string.Empty;
            if (value.Length == 0)
            {
                return value;
            }

            bool nurAscii = true;
            foreach (char zeichen in value)
            {
                if (zeichen > 127)
                {
                    nurAscii = false;
                    break;
                }
            }

            if (nurAscii)
            {
                return value;
            }

            try
            {
                return new IdnMapping().GetAscii(value).ToLowerInvariant();
            }
            catch (ArgumentException)
            {
                // Keine wandelbare Domain. Unveraendert zurueck - der Aufrufer
                // lehnt sie gleich mit derselben Meldung ab wie bisher.
                return value;
            }
        }

        internal static string[] DomainCandidates(string domain)
        {
            string normalized = NormalizeDomain(domain);
            if (normalized.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
            {
                return new string[] { normalized, normalized.Substring(4) };
            }

            return new string[] { normalized, "www." + normalized };
        }

        // ---- Time / UTC parsing -------------------------------------------------

        private static bool TryReadUtc(string value, out DateTime result)
        {
            DateTime parsed;
            if (DateTime.TryParse(value, null, System.Globalization.DateTimeStyles.RoundtripKind, out parsed))
            {
                result = parsed.ToUniversalTime();
                return true;
            }
            result = DateTime.MinValue;
            return false;
        }

        private static bool TryReadPauseUntil(AppConfig config, out DateTime until)
        {
            until = DateTime.MinValue;
            if (config == null || string.IsNullOrEmpty(config.PauseUntilUtc))
            {
                return false;
            }

            DateTime parsed;
            if (!DateTime.TryParse(config.PauseUntilUtc, null, System.Globalization.DateTimeStyles.RoundtripKind, out parsed))
            {
                return false;
            }

            until = parsed.Kind == DateTimeKind.Utc ? parsed : parsed.ToUniversalTime();
            return true;
        }

        private static bool TryReadPendingPauseUntil(AppConfig config, out DateTime until)
        {
            until = DateTime.MinValue;
            if (config == null || string.IsNullOrEmpty(config.PendingPauseUntilUtc))
            {
                return false;
            }

            DateTime parsed;
            if (!DateTime.TryParse(config.PendingPauseUntilUtc, null, System.Globalization.DateTimeStyles.RoundtripKind, out parsed))
            {
                return false;
            }

            until = parsed.Kind == DateTimeKind.Utc ? parsed : parsed.ToUniversalTime();
            return true;
        }

        // Public wrapper around the canonical schedule-time parser so the settings
        // dialog can validate user input with exactly the rules the schedule logic
        // applies (no second, drift-prone regex in the UI layer).
        public static bool IsValidScheduleTimeText(string value)
        {
            int minutes;
            return TryParseTimeText(value, out minutes);
        }

        private static string NormalizeTimeText(string value, string fallback)
        {
            int minutes;
            if (!TryParseTimeText(value, out minutes))
            {
                if (!TryParseTimeText(fallback, out minutes))
                {
                    minutes = 22 * 60;
                }
            }

            return (minutes / 60).ToString("00") + ":" + (minutes % 60).ToString("00");
        }

        private static bool TryParseTimeText(string value, out int minutes)
        {
            minutes = 0;
            string text = (value ?? string.Empty).Trim();
            Match match = Regex.Match(text, @"^(\d{1,2}):(\d{2})$");
            if (!match.Success)
            {
                return false;
            }

            int hour;
            int minute;
            if (!int.TryParse(match.Groups[1].Value, out hour) || !int.TryParse(match.Groups[2].Value, out minute))
            {
                return false;
            }

            if (hour < 0 || hour > 23 || minute < 0 || minute > 59)
            {
                return false;
            }

            minutes = hour * 60 + minute;
            return true;
        }

        // ---- Backup parsing -----------------------------------------------------

        private static bool ParseBackupBool(string value, bool fallback)
        {
            if (string.Equals(value, "true", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "1", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "yes", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            if (string.Equals(value, "false", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "0", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "no", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            return fallback;
        }

        // ---- JSON helpers -------------------------------------------------------

        private static bool ReadBool(string json, string name, bool fallback)
        {
            Match match = Regex.Match(json, "\"" + Regex.Escape(name) + "\"\\s*:\\s*(true|false)", RegexOptions.IgnoreCase);
            if (!match.Success)
            {
                return fallback;
            }

            return string.Equals(match.Groups[1].Value, "true", StringComparison.OrdinalIgnoreCase);
        }

        private static int ReadInt(string json, string name, int fallback)
        {
            Match match = Regex.Match(json, "\"" + Regex.Escape(name) + "\"\\s*:\\s*(\\d+)", RegexOptions.IgnoreCase);
            if (!match.Success)
            {
                return fallback;
            }

            int value;
            return int.TryParse(match.Groups[1].Value, out value) ? value : fallback;
        }

        private static long ReadLong(string json, string name, long fallback)
        {
            Match match = Regex.Match(json, "\"" + Regex.Escape(name) + "\"\\s*:\\s*(\\d+)", RegexOptions.IgnoreCase);
            if (!match.Success)
            {
                return fallback;
            }

            long value;
            return long.TryParse(match.Groups[1].Value, out value) ? value : fallback;
        }

        private sealed class TopLevelJsonProperty
        {
            public TopLevelJsonProperty(string name, int valueStart)
            {
                Name = name;
                ValueStart = valueStart;
            }

            public string Name { get; private set; }
            public int ValueStart { get; private set; }
        }

        private static int ReadIntegritySchemaVersion(string json, IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (!string.Equals(property.Name, "IntegritySchemaVersion", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                int valueStart = property.ValueStart;
                if (valueStart >= json.Length || json[valueStart] < '0' || json[valueStart] > '9')
                {
                    return 0;
                }

                int valueEnd = valueStart;
                if (json[valueEnd] == '0')
                {
                    valueEnd++;
                }
                else
                {
                    while (valueEnd < json.Length && json[valueEnd] >= '0' && json[valueEnd] <= '9')
                    {
                        valueEnd++;
                    }
                }

                int delimiter = valueEnd;
                while (delimiter < json.Length && char.IsWhiteSpace(json[delimiter]))
                {
                    delimiter++;
                }
                if (delimiter >= json.Length || (json[delimiter] != ',' && json[delimiter] != '}'))
                {
                    return 0;
                }

                int value;
                return int.TryParse(json.Substring(valueStart, valueEnd - valueStart), out value) ? value : 0;
            }

            return 0;
        }

        private static bool TryReadTopLevelJsonProperties(string json, out List<TopLevelJsonProperty> properties)
        {
            properties = new List<TopLevelJsonProperty>();
            if (string.IsNullOrEmpty(json))
            {
                return true;
            }

            int depth = 0;
            for (int index = 0; index < json.Length; index++)
            {
                char current = json[index];
                if (current == '"')
                {
                    string value;
                    int stringEnd;
                    if (!TryReadJsonString(json, index, out value, out stringEnd))
                    {
                        return false;
                    }

                    index = stringEnd;
                    if (depth != 1)
                    {
                        continue;
                    }

                    int separator = index + 1;
                    while (separator < json.Length && char.IsWhiteSpace(json[separator]))
                    {
                        separator++;
                    }

                    if (separator < json.Length && json[separator] == ':')
                    {
                        int valueStart = separator + 1;
                        while (valueStart < json.Length && char.IsWhiteSpace(json[valueStart]))
                        {
                            valueStart++;
                        }
                        properties.Add(new TopLevelJsonProperty(value, valueStart));
                    }
                    continue;
                }

                if (current == '{' || current == '[')
                {
                    depth++;
                }
                else if (current == '}' || current == ']')
                {
                    depth--;
                    if (depth < 0)
                    {
                        return false;
                    }
                }
            }

            return depth == 0;
        }

        private static bool HasDuplicateTopLevelJsonProperties(IList<TopLevelJsonProperty> properties)
        {
            HashSet<string> propertyNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (TopLevelJsonProperty property in properties)
            {
                if (!propertyNames.Add(property.Name))
                {
                    return true;
                }
            }
            return false;
        }

        private static bool TryReadJsonString(string json, int stringStart, out string value, out int stringEnd)
        {
            StringBuilder decoded = new StringBuilder();
            value = string.Empty;
            stringEnd = stringStart;
            for (int index = stringStart + 1; index < json.Length; index++)
            {
                char current = json[index];
                if (current == '"')
                {
                    value = decoded.ToString();
                    stringEnd = index;
                    return true;
                }

                if (current != '\\')
                {
                    if (current < 0x20)
                    {
                        return false;
                    }
                    decoded.Append(current);
                    continue;
                }

                index++;
                if (index >= json.Length)
                {
                    return false;
                }

                current = json[index];
                switch (current)
                {
                    case '"': decoded.Append('"'); break;
                    case '\\': decoded.Append('\\'); break;
                    case '/': decoded.Append('/'); break;
                    case 'b': decoded.Append('\b'); break;
                    case 'f': decoded.Append('\f'); break;
                    case 'n': decoded.Append('\n'); break;
                    case 'r': decoded.Append('\r'); break;
                    case 't': decoded.Append('\t'); break;
                    case 'u':
                        if (index + 4 >= json.Length)
                        {
                            return false;
                        }
                        int codePoint = 0;
                        for (int offset = 1; offset <= 4; offset++)
                        {
                            int digit = HexDigitValue(json[index + offset]);
                            if (digit < 0)
                            {
                                return false;
                            }
                            codePoint = (codePoint * 16) + digit;
                        }
                        decoded.Append((char)codePoint);
                        index += 4;
                        break;
                    default:
                        return false;
                }
            }

            return false;
        }

        private static int HexDigitValue(char value)
        {
            if (value >= '0' && value <= '9')
            {
                return value - '0';
            }
            if (value >= 'a' && value <= 'f')
            {
                return value - 'a' + 10;
            }
            if (value >= 'A' && value <= 'F')
            {
                return value - 'A' + 10;
            }
            return -1;
        }

        private static string ReadString(string json, string name)
        {
            Match match = Regex.Match(json, "\"" + Regex.Escape(name) + "\"\\s*:\\s*\"([^\"]*)\"", RegexOptions.IgnoreCase);
            return match.Success ? match.Groups[1].Value : string.Empty;
        }

        private static string ToJsonBool(bool value)
        {
            return value ? "true" : "false";
        }

        private static string EscapeJson(string value)
        {
            return (value ?? string.Empty).Replace("\\", "\\\\").Replace("\"", "\\\"");
        }

        // ---- Display helpers ----------------------------------------------------

        private static string YesNo(bool value)
        {
            return value ? "Ja" : "Nein";
        }

        private static void AppendProtectionCheck(StringBuilder report, List<string> problems, string label, bool ok, string problem)
        {
            report.AppendLine("- " + label + ": " + (ok ? "OK" : "Problem"));
            if (!ok && !string.IsNullOrEmpty(problem))
            {
                problems.Add(problem);
            }
        }

        // RPT-001: Diese Listen enthalten die SELBST eingetragenen Sperr- und
        // Allowlist-Domains - die persoenlichsten Daten, die Purestate haelt.
        // Der Bericht ist zum Weitergeben gebaut; die Datenschutzerklaerung sagt
        // zugleich, diese Eintraege verliessen das Geraet nicht. Maskiert bleibt
        // der diagnostische Wert erhalten (man erkennt, WELCHE Zeile gemeint
        // ist), ohne die Seite preiszugeben. Vollstaendig sieht der Nutzer sie
        // weiterhin in der App unter "Domains" und "Allowlist".
        private static void AppendLimitedValues(StringBuilder report, IEnumerable<string> values, int maxCount)
        {
            int count = 0;
            foreach (string value in values)
            {
                if (count >= maxCount)
                {
                    report.AppendLine("  ...");
                    return;
                }

                report.AppendLine("  - " + MaskReportDomain(value));
                count++;
            }
        }

        // RPT-002: Der Umgehungscheck listet Name PLUS vollstaendigen Pfad, und
        // gesucht wird unter anderem in LocalApplicationData - also unter
        // C:\Users\<Benutzername>. Der weitergegebene Bericht trug damit den
        // Windows-Benutzernamen und eine Teilinventur installierter Software.
        // Spiegelt Protect-DiagnosticText in tools\Get-Diagnostics.ps1, wo
        // dieselbe Ersetzung fuer den Diagnosebericht laengst steht. Der Pfad
        // bleibt bis auf den Namen lesbar; fuer die Diagnose war er nie noetig.
        internal static string MaskUserPaths(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                return string.Empty;
            }

            return System.Text.RegularExpressions.Regex.Replace(
                text,
                @"(?<prefix>[A-Za-z]:\\Users\\)(?<user>[^\\\s)]+)",
                "${prefix}<redacted>",
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        }

        // Behaelt die ersten drei Zeichen und die oberste Domainebene. Aus
        // "shop.beispielseite.de" wird "sho***.de": genug, um eine Zeile
        // wiederzuerkennen, zu wenig, um die Seite zu nennen.
        internal static string MaskReportDomain(string value)
        {
            string text = (value ?? string.Empty).Trim();
            if (text.Length == 0)
            {
                return string.Empty;
            }

            string suffix = string.Empty;
            int lastDot = text.LastIndexOf('.');
            if (lastDot > 0 && lastDot < text.Length - 1)
            {
                suffix = text.Substring(lastDot);
                text = text.Substring(0, lastDot);
            }

            string head = text.Length <= 3 ? string.Empty : text.Substring(0, 3);
            return head + "***" + suffix;
        }

        private static void AppendReportList(StringBuilder report, string title, string[] values, string emptyText)
        {
            report.AppendLine(title + ":");
            if (values.Length == 0)
            {
                report.AppendLine("- " + emptyText);
            }
            else
            {
                foreach (string value in values)
                {
                    report.AppendLine("- " + value);
                }
            }

            report.AppendLine();
        }

        // ---- Collection helpers -------------------------------------------------

        private static string[] UniqueStrings(IEnumerable<string> values)
        {
            List<string> result = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string value in values)
            {
                if (string.IsNullOrEmpty(value) || seen.Contains(value))
                {
                    continue;
                }

                seen.Add(value);
                result.Add(value);
            }

            return result.ToArray();
        }

        private static string[] ToLimitedArray(SortedSet<string> values, int maxResults)
        {
            List<string> result = new List<string>();
            foreach (string value in values)
            {
                result.Add(value);
                if (result.Count >= maxResults)
                {
                    break;
                }
            }

            return result.ToArray();
        }

        private static bool TextContainsAny(string text, string[] keywords)
        {
            string value = (text ?? string.Empty).ToLowerInvariant();
            foreach (string keyword in keywords)
            {
                if (keyword.Length > 0 && value.IndexOf(keyword.ToLowerInvariant(), StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }

            return false;
        }
    }
}
