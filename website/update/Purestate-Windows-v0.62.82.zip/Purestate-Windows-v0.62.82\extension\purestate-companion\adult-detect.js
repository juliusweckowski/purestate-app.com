"use strict";

// Purestate: Erwachseneninhalte am Inhalt erkennen.
//
// 186 kuratierte Domains stehen gegen eine Zahl von Angeboten, die niemand
// pflegen kann. Dieses Modul entscheidet am Inhalt der bereits geladenen
// Seite - kein Netz, kein Speichern von Seiteninhalten.
//
// Zwei Stufen nach Signalstaerke:
//   hart  - die Seite meldet sich selbst als Erwachsenenangebot UND ein
//           zweites, unabhaengiges Signal bestaetigt das. Vollvorhang.
//   weich - nur Wortsignale, mindestens SOFT_MIN_HITS unabhaengige Treffer.
//           Warnleiste, die Seite bleibt lesbar.
//
// Ein Marker allein traegt nie: ein Bericht, der den RTA-String zitiert,
// fuehrt ihn ebenfalls. Ein einzelnes Betriebswort allein traegt auch nicht -
// erst die Dichte (mehrere unabhaengige Treffer) ist ein Signal, genau wie
// bei den generischen Woertern unten.
//
// ponytail: pageText/eachJsonLd/isEditorial/EDITORIAL_TYPES sind eine
// woertliche Kopie aus gambling-detect.js, aus demselben Grund wie dort
// dokumentiert (Zeile 15-17): Zusammenlegen hiesse ausgeliefertem, live
// geprueftem Code anzufassen fuer wenige gesparte Zeilen.

(function () {
  // Marker: Selbstauskunft. Diese Zeichen setzen Betreiber freiwillig, weil
  // sie Jugendschutzfilter bedienen wollen - sie stehen praktisch nirgends
  // sonst.
  const RTA_LABEL = /RTA-5042-1996-1400-1577-RTA/i;
  const RATING_VALUES = /^(adult|mature|rta-5042-1996-1400-1577-rta)$/i;
  const STATEMENT_2257 = /18\s*u\.?\s*s\.?\s*c\.?\s*(?:§\s*)?2257/i;

  // Bestaetigung: Betriebswoerter, gezaehlt statt nur geprueft. Ein einzelner
  // Treffer traegt nur zusammen mit dem Marker (hart); erst SOFT_MIN_HITS
  // unabhaengige Treffer tragen ohne Marker (weich). Jedes Wort mit
  // Wortgrenze, sonst steckt es im naechsten harmlosen langen Wort.
  //
  // "hardcore" und "xxx" bewusst NICHT aufgenommen: beide haben ausserhalb
  // der Branche eine gebraeuchliche zweite Bedeutung (Musikgenre/Fitness-
  // Slang bzw. Kleidergroesse und der Filmtitel "xXx") - eine Musik-,
  // Sport- oder Kinoseite kann sie mehrfach fuehren und haette damit allein
  // den Schwellenwert erreicht. Runde 1 hat denselben Fehler schon einmal
  // gezeigt: "Alle Kategorien" und "Jetzt streamen"/"Jetzt schauen" standen
  // hier, bis eine neutrale Mediathekseite genau darueber die weiche Stufe
  // ausgeloest haette (Nie-sperren-Korpus verlangt 0 Treffer, nicht
  // "meistens selten") - siehe der Sicherheitsfall im Nie-sperren-Test.
  const OPERATIONAL = new RegExp(
    // Eindeutiges Vokabular ohne zweite Bedeutung ausserhalb der Branche.
    "\\bpornostars?\\b" +
    "|\\bpornofilme?\\b" +
    "|\\bsexvideos?\\b" +
    "|\\bwebcam ?girls?\\b" +
    "|\\blive ?cams?\\b" +
    "|\\bmilf\\b",
    "gi"
  );

  // Weiche Stufe: dieselben Woerter, aber ueber die Dichte statt ueber den
  // Einzeltreffer - ein einzelnes Wort in einem langen Text loest nichts aus.
  const SOFT_MIN_HITS = 3;

  // Ein Videozaehler allein ist kein unabhaengiges Erwachsenen-Signal: eine
  // Nachrichten- oder Mediathekseite kann ebenso viele Player tragen. Der
  // medienbasierte Zweig akzeptiert deshalb nur eindeutige Begriffe aus
  // ausdruecklich markierten Kategorie-/Tag-Elementen. Freier Seitentext und
  // mehrdeutige Woerter wie "teen" oder "amateur" tragen hier nie.
  const ADULT_CATEGORY = /\b(?:bdsm|fetisch|hentai|gangbang|porn(?:o)?|erotik)\b/i;
  const ADULT_CATEGORY_SELECTOR =
    '[data-category], [data-category-name], a[href*="/category/"], ' +
    'a[href*="/categories/"], a[href*="/tag/"], a[href*="/tags/"]';

  // Deckel gegen sehr grosse Seiten. Gelesen werden Anfang UND Ende, nie nur
  // der Anfang: die 2257-Erklaerung steht ueblicherweise im Fussbereich. Ein
  // reiner Kopf-Ausschnitt haette sie dort abgeschnitten.
  const TEXT_HEAD = 60000;
  const TEXT_TAIL = 60000;

  function pageText(doc) {
    const body = doc && doc.body;
    const raw = String((body && body.textContent) || "");
    if (raw.length <= TEXT_HEAD + TEXT_TAIL) {
      return raw;
    }
    return raw.slice(0, TEXT_HEAD) + " " + raw.slice(raw.length - TEXT_TAIL);
  }

  // Gezaehlt werden UNTERSCHIEDLICHE Treffer, nicht Wiederholungen: ein
  // Themenartikel, der dreimal "Pornofilme" schreibt, ist ein Signal, keine
  // drei. Nur so heisst SOFT_MIN_HITS wirklich "unabhaengige Signale".
  function countOperational(text) {
    const matches = text.match(OPERATIONAL);
    return matches ? new Set(matches.map((value) => value.toLowerCase())).size : 0;
  }

  // Ziffergrenze statt Wortgrenze: "2257" steckt sonst in jeder laengeren
  // Artikel-ID (/news/122570) und machte die halbe Presse zum Kandidaten.
  const LINK_2257 = /(?:^|[^0-9])2257(?:[^0-9]|$)/;

  // Selbstauskunft ohne Aussprache: die Seite verlinkt ihre eigene
  // 2257-Erklaerung, statt sie hier abzudrucken. Gemessen am 2026-08-05 an
  // den KI-Begleiter-Plattformen (tools\Measure-AiCompanionSignals.js) - dort
  // steht die Erklaerung auf einer Unterseite, die der Nutzer nie oeffnet,
  // der Verweis aber im Fussbereich jeder Seite. In der Kontrollgruppe aus
  // allgemeinen KI-Werkzeugen fuehrt ihn keine einzige Seite.
  function has2257Link(doc) {
    let links;
    try {
      links = doc.querySelectorAll("a[href]");
    } catch {
      return false;
    }
    for (const link of Array.from(links || [])) {
      const href = String((link && link.getAttribute && link.getAttribute("href")) || "");
      if (LINK_2257.test(href) || LINK_2257.test(String((link && link.textContent) || ""))) {
        return true;
      }
    }
    return false;
  }

  function hasMarker(doc, text) {
    if (RTA_LABEL.test(text) || STATEMENT_2257.test(text) || has2257Link(doc)) {
      return true;
    }
    let metas;
    try {
      metas = doc.querySelectorAll("meta");
    } catch {
      return false;
    }
    for (const meta of Array.from(metas || [])) {
      const name = String((meta.getAttribute && meta.getAttribute("name")) || "").toLowerCase();
      if (name !== "rating") {
        continue;
      }
      const content = String((meta.getAttribute && meta.getAttribute("content")) || "").trim();
      if (RATING_VALUES.test(content)) {
        return true;
      }
    }
    return false;
  }

  // Nur explizite Struktur, nie der bereits fuer andere Signale gelesene
  // Fliesstext: dadurch wird ein Themenwort nicht zur Angebotskategorie.
  function hasAdultCategoryMetadata(doc) {
    let nodes;
    try {
      nodes = doc.querySelectorAll(ADULT_CATEGORY_SELECTOR);
    } catch {
      return false;
    }
    for (const node of Array.from(nodes || [])) {
      const get = node && typeof node.getAttribute === "function"
        ? (name) => String(node.getAttribute(name) || "")
        : () => "";
      const metadata = [
        String((node && node.textContent) || ""),
        get("aria-label"),
        get("title"),
        get("data-category"),
        get("data-category-name"),
        get("href")
      ].join(" ");
      if (ADULT_CATEGORY.test(metadata)) {
        return true;
      }
    }
    return false;
  }

  // Ersatz fuer den Wort-Treffer: eine Galerieseite ohne Fliesstext zeigt
  // viele Vorschauclips statt Betriebswoertern.
  function hasMediaAndCategories(doc) {
    let videos;
    try {
      videos = doc.querySelectorAll("video");
    } catch {
      return false;
    }
    return Array.from(videos || []).length >= 6 && hasAdultCategoryMetadata(doc);
  }

  // Aufklaerung, Beratung, Gesundheit, Behoerden, Nachschlagewerk. FEST IM
  // CODE und per Test gepinnt: konfigurierbar hiesse leerbar, und eine
  // leerbare Ausnahmeliste fuer Aufklaerung ist genau der Schalter, den man
  // im Impuls umlegt. Diese Seiten reden am dichtesten ueber das Thema -
  // ohne die Liste sperrt die weiche Stufe zuerst sie.
  const NEVER_BLOCK_HOSTS = [
    "bzga.de",
    "profamilia.de",
    "loveline.de",
    "sextra.de",
    "liebesleben.de",
    "gesundheitsinformation.de",
    "bundesgesundheitsministerium.de",
    "wikipedia.org",
    "who.int",
    "telefonseelsorge.de"
  ];

  function isNeverBlockHost(hostname) {
    const host = String(hostname || "").toLowerCase().replace(/^www\./, "");
    if (!host) {
      return false;
    }
    for (const entry of NEVER_BLOCK_HOSTS) {
      // Suffix-Semantik: exakt oder Unterdomain. Nie Teilzeichenkette, sonst
      // waere "bzga.de.beispiel.example" eine Beratungsstelle.
      if (host === entry || host.endsWith("." + entry)) {
        return true;
      }
    }
    return false;
  }

  // Redaktionelle Seiten nennen Marker und Betriebswoerter, ohne ein Angebot
  // zu sein. Dieselbe Regel wie im Gluecksspiel- und Shopping-Bereich.
  const EDITORIAL_TYPES = /^(article|newsarticle|blogposting|liveblogposting|opinionnewsarticle|reportagenewsarticle)$/i;

  function eachJsonLd(doc, visit) {
    let scripts;
    try {
      scripts = doc.querySelectorAll('script[type="application/ld+json"]');
    } catch {
      return;
    }
    for (const script of Array.from(scripts || [])) {
      let data;
      try {
        data = JSON.parse(String((script && script.textContent) || ""));
      } catch {
        continue;
      }
      walk(data, 0);
    }
    function walk(node, depth) {
      if (!node || typeof node !== "object" || depth > 6) {
        return;
      }
      if (Array.isArray(node)) {
        for (const entry of node) {
          walk(entry, depth + 1);
        }
        return;
      }
      visit(node);
      for (const key of Object.keys(node)) {
        walk(node[key], depth + 1);
      }
    }
  }

  function isEditorial(doc) {
    let found = false;
    eachJsonLd(doc, (node) => {
      if (found) {
        return;
      }
      const types = Array.isArray(node["@type"]) ? node["@type"] : [node["@type"]];
      for (const type of types) {
        if (typeof type === "string" && EDITORIAL_TYPES.test(type.trim())) {
          found = true;
          return;
        }
      }
    });
    return found;
  }

  function detectAdultPage(doc, hostname) {
    if (!doc || typeof doc.querySelectorAll !== "function") {
      return { level: "none", reason: "" };
    }
    // Beide Ausnahmen stehen VOR der Erkennung: sie schlagen jedes Signal.
    if (isNeverBlockHost(hostname)) {
      return { level: "none", reason: "never-block" };
    }
    if (isEditorial(doc)) {
      return { level: "none", reason: "editorial" };
    }
    const text = pageText(doc);
    const hits = countOperational(text);
    if (hasMarker(doc, text) && (hits > 0 || hasMediaAndCategories(doc))) {
      return { level: "hard", reason: "marker-and-signal" };
    }
    if (hits >= SOFT_MIN_HITS) {
      return { level: "soft", reason: "wording" };
    }
    return { level: "none", reason: hits > 0 ? "zu wenig Signale" : "" };
  }

  globalThis.purestateDetectAdultPage = detectAdultPage;

  // adult-page-content.js fragt die Liste vor JEDER anderen Regel - auch vor
  // den gelernten Hosts und vor dem eigenen Gedaechtnis. Deshalb muss die
  // Pruefung dort erreichbar sein, ohne die ganze Erkennung laufen zu lassen;
  // eine zweite Kopie der Suffix-Semantik waere die naechste Drift-Quelle.
  globalThis.purestateAdultIsNeverBlockHost = isNeverBlockHost;

  // Nur fuer den Test, der die Liste gegen Leerlaufen sichert.
  globalThis.purestateAdultNeverBlockHosts = function () {
    return NEVER_BLOCK_HOSTS.slice();
  };
})();
