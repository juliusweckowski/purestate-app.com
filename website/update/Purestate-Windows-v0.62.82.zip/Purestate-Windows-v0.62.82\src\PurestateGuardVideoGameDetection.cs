using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Purestate
{
    // Automatic game detection for the guard service. Compiled ONLY into
    // PurestateGuard.exe (standalone, no Purestate.Native.Support references).
    // Layer 1 turns store install manifests (Steam/Epic/GOG/EA/Battle.net/
    // XboxGames) into game DIRECTORIES: a process whose main-module path lies
    // under one of them is a game with certainty - no heuristics involved.
    internal sealed class DetectedGameDirectory
    {
        public string Path = string.Empty;
        public string Source = string.Empty;
    }

    // Result of one detection pass over the processes that are not already
    // listed targets: store matches are certain (path-based) and enforced
    // immediately; heuristic matches get the 60-second save-countdown.
    internal sealed class DetectionMatches
    {
        public List<System.Diagnostics.Process> StoreMatches = new List<System.Diagnostics.Process>();
        public List<System.Diagnostics.Process> HeuristicMatches = new List<System.Diagnostics.Process>();
    }

    internal static class VideoGameDetection
    {
        private const int StoreScanIntervalMinutes = 10;
        private const long MaxDetectedFileBytes = 65536;
        private const int CountdownSeconds = 60;
        internal const int FirstCountdownSeconds = 300;

        private static List<DetectedGameDirectory> storeCache;
        private static DateTime lastStoreScanMonotonic = DateTime.MinValue;

        // Reine Verlaufszeit fuer kurze Fristen: 60 Sekunden Countdown und
        // 10 Minuten Zwischenspeicher brauchen kein Datum. Eine gestellte
        // Systemuhr darf sie weder verlaengern noch einfrieren - genau das
        // passierte bisher (Befunde KIL-001, SCN-001: eine zurueckgestellte Uhr
        // machte die Cache-Differenz negativ, der Store-Scan lief nie wieder).
        //
        // Bewusst mit einer Epoche ohne Bezug zur Wanduhr: so faellt beim Lesen
        // sofort auf, dass diese Zeitwerte KEIN Kalenderdatum sind. Unterschied
        // zu Support.MonotonicUtcNow (Maximum aus Wanduhr und Anker, fuer
        // Fristen, die einen Neustart ueberleben muessen).
        private static readonly System.Diagnostics.Stopwatch monotonicClock = System.Diagnostics.Stopwatch.StartNew();
        private static readonly DateTime monotonicEpochUtc = new DateTime(2000, 1, 1, 0, 0, 0, DateTimeKind.Utc);

        internal static DateTime MonotonicNowUtc()
        {
            return monotonicEpochUtc.Add(monotonicClock.Elapsed);
        }

        // Wann gilt eine "Kein Spiel"-Ausnahme als wirksam? Es zaehlt die
        // FRUEHERE der beiden Uhren (CLK-002): die Systemuhr vorzustellen darf
        // die 15-Minuten-Frist nicht abkuerzen. Bewusst nicht nur der Anker -
        // steht der Guard, steht der Anker, und die Ausnahme ist der einzige
        // Notausgang bei einem Fehlalarm der Heuristik (VG-001/VG-002).
        internal static DateTime ExemptionActivationNowUtc(DateTime anchorUtc, DateTime systemUtc)
        {
            return anchorUtc < systemUtc ? anchorUtc : systemUtc;
        }

        private static string DataDirectory
        {
            get
            {
                return System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                    "Purestate");
            }
        }

        internal static string DetectedStatePath
        {
            get { return System.IO.Path.Combine(DataDirectory, "video-games-detected.json"); }
        }

        // ---- Store manifest parsers (pure, pinned by Pester reflection tests) ----

        // libraryfolders.vdf: every "path" "C:\\SteamLibrary" value, including
        // the nested per-library blocks. VDF escapes backslashes.
        internal static List<string> ParseSteamLibraryFolders(string vdfText)
        {
            List<string> paths = new List<string>();
            foreach (Match match in Regex.Matches(vdfText ?? string.Empty,
                "\"path\"\\s+\"([^\"]+)\""))
            {
                string value = match.Groups[1].Value.Replace("\\\\", "\\").Trim();
                if (value.Length != 0)
                {
                    paths.Add(value);
                }
            }
            return paths;
        }

        // appmanifest_*.acf: the "installdir" "GameFolder" value (folder name
        // below steamapps\common, no path separators expected).
        internal static string ParseSteamAppManifestInstallDir(string acfText)
        {
            Match match = Regex.Match(acfText ?? string.Empty,
                "\"installdir\"\\s+\"([^\"]+)\"");
            if (!match.Success)
            {
                return string.Empty;
            }
            string value = match.Groups[1].Value.Replace("\\\\", "\\").Trim();
            return (value.IndexOfAny(new[] { '\\', '/', ':' }) >= 0) ? string.Empty : value;
        }

        // Epic *.item manifest (JSON): "InstallLocation": "C:\\Games\\Foo".
        internal static string ParseEpicManifestInstallLocation(string itemJson)
        {
            Match match = Regex.Match(itemJson ?? string.Empty,
                "\"InstallLocation\"\\s*:\\s*\"([^\"]+)\"");
            if (!match.Success)
            {
                return string.Empty;
            }
            return match.Groups[1].Value.Replace("\\\\", "\\").Replace("\\/", "/").Trim();
        }

        // A detected directory must be rooted, must not be a drive root, and
        // must never lie inside the Windows or Purestate install directories -
        // a hostile manifest could otherwise turn the guard against them.
        internal static bool IsSafeGameDirectory(string path, string windowsDir, string installDir)
        {
            string trimmed = (path ?? string.Empty).Trim();
            if (trimmed.Length == 0)
            {
                return false;
            }
            string fullPath;
            try
            {
                if (!System.IO.Path.IsPathRooted(trimmed))
                {
                    return false;
                }
                fullPath = System.IO.Path.GetFullPath(trimmed);
            }
            catch
            {
                return false;
            }
            string root = System.IO.Path.GetPathRoot(fullPath) ?? string.Empty;
            if (root.Length < 2 ||
                string.Equals(fullPath.TrimEnd('\\', '/'), root.TrimEnd('\\', '/'), StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }
            if (!IsLocalPath(fullPath, root))
            {
                return false;
            }

            return !IsInsideDirectory(fullPath, windowsDir) && !IsInsideDirectory(fullPath, installDir);
        }

        // SCN-006: Der Store-Scan rief Directory.Exists/GetFiles/GetDirectories
        // direkt auf jeden Pfad auf, den ein Store-Manifest nennt. Eine
        // Steam-Bibliothek auf einem Netzlaufwerk oder ein Epic-InstallLocation
        // auf einer GETRENNTEN Freigabe blockiert diesen Aufruf fuer die volle
        // SMB-Zeitueberschreitung - Groessenordnung 20 bis 45 Sekunden je Pfad.
        // Solange er haengt, findet im Videospielbereich keine Durchsetzung
        // statt, und der Zehn-Minuten-Cache begrenzt die Haeufigkeit, nicht die
        // Dauer.
        //
        // Ein Spiel auf einem Netzlaufwerk zu erkennen ist kein Ziel dieses
        // Produkts, also werden solche Pfade uebersprungen. Die Alternative -
        // der Scan in einem eigenen Faden mit Zeitgrenze - waere deutlich mehr
        // Aufwand fuer denselben Nutzen.
        internal static bool IsLocalPath(string fullPath, string root)
        {
            // UNC (\\server\share) ist kein Laufwerk; DriveInfo wuerde hier
            // werfen, und der Pfad ist ohnehin per Definition nicht lokal.
            if ((fullPath ?? string.Empty).StartsWith(@"\\", StringComparison.Ordinal))
            {
                return false;
            }

            try
            {
                System.IO.DriveInfo drive = new System.IO.DriveInfo(root);
                return drive.DriveType != System.IO.DriveType.Network;
            }
            catch
            {
                // Kein normales Laufwerk - im Zweifel nicht anfassen.
                return false;
            }
        }

        internal static bool IsInsideDirectory(string fullPath, string directory)
        {
            if (string.IsNullOrWhiteSpace(directory))
            {
                return false;
            }
            string normalized;
            try
            {
                normalized = System.IO.Path.GetFullPath(directory)
                    .TrimEnd(System.IO.Path.DirectorySeparatorChar, System.IO.Path.AltDirectorySeparatorChar)
                    + System.IO.Path.DirectorySeparatorChar;
            }
            catch
            {
                return false;
            }
            return fullPath.StartsWith(normalized, StringComparison.OrdinalIgnoreCase);
        }

        // ---- Android emulators (uninstall registry entries) -----------------------

        // Android emulators run games inside their own player process, so the
        // store layers never see them. Known emulators are detected over their
        // Uninstall entries and enforced exactly like store directories.
        // BlueStacks nxt carries NO InstallLocation - the directory comes from
        // the DisplayIcon path instead.
        private static readonly string[] EmulatorDisplayNamePatterns =
        {
            "bluestacks", "ldplayer", "nox app player", "noxplayer", "memu",
            "mumu", "gameloop", "google play games"
        };

        // SCN-005: Gesucht wurde als reine Teilzeichenkette. "memu" und "mumu"
        // sind vier Zeichen - ein Deinstallationseintrag, dessen Anzeigename die
        // Folge enthaelt (Kandidat: "Memurai for Windows", ein Datenbankdienst),
        // lieferte damit sein Installationsverzeichnis als Emulatorordner. Alles
        // darunter gilt danach als Spiel und wird im strengen Modus beendet.
        //
        // Dieselbe Familie wie BYP-003, RUL-001 und RGL-005. Eine Wortgrenze
        // genuegt hier, anders als bei BYP-003: "Memurai" endet nicht nach
        // "memu", waehrend "MEmu" alleinsteht oder von Trennzeichen umgeben ist
        // ("MEmu App Player", "MuMu Player 12").
        private static bool DisplayNameContainsWord(string name, string word)
        {
            string haystack = name ?? string.Empty;
            int start = 0;
            while (true)
            {
                int index = haystack.IndexOf(word, start, StringComparison.OrdinalIgnoreCase);
                if (index < 0)
                {
                    return false;
                }

                bool linksFrei = index == 0 || !char.IsLetter(haystack[index - 1]);
                int nach = index + word.Length;
                // Rechts darf eine ZIFFER folgen, aber kein Buchstabe: die
                // Emulatoren heissen "LDPlayer9", "MuMu Player 12", "MEmu 7" -
                // eine Versionsnummer klebt regelmaessig am Namen. Ein
                // Buchstabe dagegen macht ein anderes Wort daraus ("Memurai",
                // "Mumuration"), und genau das war der Fehlalarm.
                //
                // Der erste Anlauf verlangte auch rechts "kein Buchstabe UND
                // keine Ziffer" - damit fiel LDPlayer9 aus der Erkennung, und
                // der bestehende Test hat es gefangen.
                bool rechtsFrei = nach >= haystack.Length || !char.IsLetter(haystack[nach]);
                if (linksFrei && rechtsFrei)
                {
                    return true;
                }

                start = index + 1;
            }
        }

        internal static string ResolveEmulatorDirectoryFromUninstallEntry(
            string displayName, string installLocation, string displayIcon)
        {
            string name = (displayName ?? string.Empty).Trim();
            bool matches = false;
            foreach (string pattern in EmulatorDisplayNamePatterns)
            {
                if (DisplayNameContainsWord(name, pattern))
                {
                    matches = true;
                    break;
                }
            }
            if (!matches)
            {
                return string.Empty;
            }

            string location = (installLocation ?? string.Empty).Trim().Trim('"');
            if (location.Length != 0)
            {
                return location;
            }

            // DisplayIcon format: "C:\dir\app.exe,0" or a bare icon/exe path.
            string icon = (displayIcon ?? string.Empty).Trim().Trim('"');
            int commaIndex = icon.LastIndexOf(',');
            if (commaIndex > 1)
            {
                icon = icon.Substring(0, commaIndex).Trim();
            }
            if (icon.Length == 0)
            {
                return string.Empty;
            }
            try
            {
                return System.IO.Path.GetDirectoryName(icon) ?? string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        // An emulator directory must never be a bare installation root like
        // "C:\Program Files" - the prefix match would otherwise cover every
        // program below it.
        internal static bool IsForbiddenInstallRootDirectory(string path, IEnumerable<string> forbiddenRoots)
        {
            string normalized;
            try
            {
                normalized = System.IO.Path.GetFullPath((path ?? string.Empty).Trim())
                    .TrimEnd('\\', '/');
            }
            catch
            {
                return true;
            }
            foreach (string root in forbiddenRoots ?? new string[0])
            {
                string trimmedRoot;
                try
                {
                    trimmedRoot = System.IO.Path.GetFullPath((root ?? string.Empty).Trim()).TrimEnd('\\', '/');
                }
                catch
                {
                    continue;
                }
                if (trimmedRoot.Length != 0 &&
                    string.Equals(normalized, trimmedRoot, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        // SCN-002: Die Liste galt zuerst nur fuer Emulatoren, gebraucht wird
        // sie fuer jede Quelle - ein Store-Eintrag, der auf einen dieser
        // Ordner zeigt, macht jedes Programm darunter zum Spiel.
        internal static List<string> ForbiddenInstallRootDirectories()
        {
            List<string> forbiddenRoots = new List<string>();
            Action<Environment.SpecialFolder> addRoot = delegate (Environment.SpecialFolder folder)
            {
                try
                {
                    string value = Environment.GetFolderPath(folder);
                    if (!string.IsNullOrEmpty(value))
                    {
                        forbiddenRoots.Add(value);
                    }
                }
                catch
                {
                }
            };
            addRoot(Environment.SpecialFolder.ProgramFiles);
            addRoot(Environment.SpecialFolder.ProgramFilesX86);
            addRoot(Environment.SpecialFolder.CommonApplicationData);
            addRoot(Environment.SpecialFolder.LocalApplicationData);
            addRoot(Environment.SpecialFolder.UserProfile);
            try
            {
                string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                if (!string.IsNullOrEmpty(localAppData))
                {
                    forbiddenRoots.Add(System.IO.Path.Combine(localAppData, "Programs"));
                }
            }
            catch
            {
            }

            // Das Elternverzeichnis der Benutzerprofile steht in keiner
            // SpecialFolder-Liste, ist aber genauso breit.
            try
            {
                string userProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
                if (!string.IsNullOrEmpty(userProfile))
                {
                    string parent = System.IO.Path.GetDirectoryName(userProfile);
                    if (!string.IsNullOrEmpty(parent))
                    {
                        forbiddenRoots.Add(parent);
                    }
                }
            }
            catch
            {
            }

            return forbiddenRoots;
        }

        // Live reader: known emulators from the Uninstall hives. HKCU entries
        // are only visible when the guard runs in that user's context - a
        // per-user emulator install is a documented detection limit of the
        // session-0 service.
        private static List<string> ReadEmulatorInstallDirectories()
        {
            List<string> forbiddenRoots = ForbiddenInstallRootDirectories();

            List<string> directories = new List<string>();
            Action<RegistryKey, string> scan = delegate (RegistryKey hive, string subKey)
            {
                try
                {
                    using (RegistryKey key = hive.OpenSubKey(subKey))
                    {
                        if (key == null)
                        {
                            return;
                        }
                        foreach (string childName in key.GetSubKeyNames())
                        {
                            try
                            {
                                using (RegistryKey child = key.OpenSubKey(childName))
                                {
                                    if (child == null)
                                    {
                                        continue;
                                    }
                                    string directory = ResolveEmulatorDirectoryFromUninstallEntry(
                                        child.GetValue("DisplayName") as string,
                                        child.GetValue("InstallLocation") as string,
                                        child.GetValue("DisplayIcon") as string);
                                    if (directory.Length != 0 &&
                                        !IsForbiddenInstallRootDirectory(directory, forbiddenRoots))
                                    {
                                        directories.Add(directory);
                                    }
                                }
                            }
                            catch
                            {
                            }
                        }
                    }
                }
                catch
                {
                }
            };
            scan(Registry.LocalMachine, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall");
            scan(Registry.LocalMachine, @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall");
            scan(Registry.CurrentUser, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall");
            return directories;
        }

        // ---- Store scan (directories from install manifests) ---------------------

        // Ein Store-Verzeichnis ist kein Beweis fuer ein Spiel: in denselben
        // Bibliotheken liegen Anwendungen, Werkzeuge, Redistributables und
        // reine Datenordner. Live gefunden (Befund V-1, 2026-08-06): der
        // strenge Modus beendete Wallpaper Engine bei jedem Takt, sofort und
        // ohne Speicherwarnung, weil "steamapps\common\wallpaper_engine" als
        // Spiel galt. Steam selbst hilft nicht - appmanifest_*.acf kennt kein
        // Feld Spiel-vs-Anwendung, den Typ traegt nur die interne appinfo.vdf.
        // Also eine feste Liste im Code, wie beim Nie-sperren-Korpus der
        // Erwachsenen- und Gluecksspielerkennung. Sie deckt die gemessenen
        // Faelle, nicht jede fremde Nicht-Spiel-Anwendung; dafuer bleibt der
        // Ausnahmeweg, der seit Befund V-2 auch auffindbar ist.
        private static readonly string[] NonGameStoreDirectoryNames =
        {
            "wallpaper_engine",
            "steamworks shared",
            "steamworks common redistributables",
            "smart game booster for steam",
            "gamesave",
            "gamesaves"
        };

        // Unreal-Engine-Editoren installieren sich als "UE_5.4", "UE_5.5", ...
        // Ein Engine-Editor ist ein Arbeitswerkzeug; die Heuristik schliesst
        // "unrealeditor.exe" laengst aus, die Store-Schicht tat es nicht.
        private static readonly string[] NonGameStoreDirectoryPrefixes =
        {
            "ue_"
        };

        // Ein Xbox-/Microsoft-Store-Spiel LAEUFT nicht aus seinem
        // Installationsordner: Windows startet die registrierte MSIX-Kopie
        // unter "Program Files\WindowsApps\<Paketname>_<Version>_<Arch>__<Hash>".
        // Live gefunden (Befund V-4, 2026-08-06): sieben Minecraft-Prozesse
        // liefen aus WindowsApps, der Abgleich gegen "C:\XboxGames\Minecraft
        // Launcher" traf keinen einzigen - jedes Store-Spiel entkam der
        // Store-Schicht komplett. Die Bruecke ist das Manifest im
        // Installationsordner: seine Identity nennt genau den Paketnamen, mit
        // dem der WindowsApps-Ordner beginnt. Bleibt damit pfadbasiert und
        // sicher, ohne Heuristik.
        internal static string ReadAppxIdentityName(string gameInstallDirectory)
        {
            string[] candidates =
            {
                System.IO.Path.Combine(gameInstallDirectory ?? string.Empty, "Content", "appxmanifest.xml"),
                System.IO.Path.Combine(gameInstallDirectory ?? string.Empty, "appxmanifest.xml")
            };
            foreach (string candidate in candidates)
            {
                try
                {
                    if (!File.Exists(candidate))
                    {
                        continue;
                    }
                    Match match = Regex.Match(
                        File.ReadAllText(candidate),
                        "<Identity[^>]*\\sName\\s*=\\s*\"([^\"]+)\"",
                        RegexOptions.IgnoreCase);
                    if (match.Success)
                    {
                        string identity = match.Groups[1].Value.Trim();
                        // SCN-003: Der Name geht als SUCHMUSTER an
                        // Directory.GetDirectories. Ein Stern haette dort jedes
                        // MSIX-Paket zum Spielverzeichnis gemacht - Rechner,
                        // Terminal, Fotos. Erlaubt ist genau die Zeichenmenge,
                        // die eine Appx-Identity ueberhaupt haben darf.
                        if (!Regex.IsMatch(identity, "^[A-Za-z0-9][A-Za-z0-9.\\-]{0,127}$"))
                        {
                            return string.Empty;
                        }
                        return identity;
                    }
                }
                catch
                {
                }
            }
            return string.Empty;
        }

        internal static List<string> PackageDirectoriesForInstalledGame(
            string gameInstallDirectory, string windowsAppsDirectory)
        {
            List<string> found = new List<string>();
            string identity = ReadAppxIdentityName(gameInstallDirectory);
            if (identity.Length == 0 || string.IsNullOrEmpty(windowsAppsDirectory))
            {
                return found;
            }
            try
            {
                if (!Directory.Exists(windowsAppsDirectory))
                {
                    return found;
                }
                // Der Unterstrich trennt den Paketnamen von der Version, ohne
                // ihn wuerde "Microsoft.Game" auch "Microsoft.GameHelfer" treffen.
                foreach (string directory in Directory.GetDirectories(windowsAppsDirectory, identity + "_*"))
                {
                    found.Add(directory);
                }
            }
            catch
            {
            }
            return found;
        }

        internal static string SafeDirectoryLeafName(string path)
        {
            try
            {
                return System.IO.Path.GetFileName(
                    (path ?? string.Empty).TrimEnd('\\', '/'));
            }
            catch
            {
                return string.Empty;
            }
        }

        internal static bool IsNonGameStoreDirectoryName(string directoryName)
        {
            string name = (directoryName ?? string.Empty).Trim();
            foreach (string nonGame in NonGameStoreDirectoryNames)
            {
                if (string.Equals(name, nonGame, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            foreach (string prefix in NonGameStoreDirectoryPrefixes)
            {
                if (name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        // Pure-ish core: every I/O source is parameterized so tests can point
        // it at fixture directories. Unsafe or missing directories are dropped;
        // per-source failures never abort the other sources.
        // SCN-006: Jeder Zugriff des Store-Scans laeuft ueber diese vier
        // Huellen. Sie pruefen zuerst, ob der Pfad ueberhaupt lokal ist - ein
        // Directory.Exists auf eine getrennte Freigabe blockiert sonst fuer die
        // volle SMB-Zeitueberschreitung, und der Scan laeuft im
        // Videospiel-Takt: solange er haengt, findet in diesem Bereich keine
        // Durchsetzung statt.
        //
        // Der erste Anlauf dieses Fixes sass in IsSafeGameDirectory - also zu
        // spaet, denn die Wurzeln werden angefasst, BEVOR ein Ergebnis
        // hinzugefuegt wird. Der Test hat es mit 21 Sekunden gemessen.
        private static bool IsLocalPathForScan(string path)
        {
            string trimmed = (path ?? string.Empty).Trim();
            if (trimmed.Length == 0)
            {
                return false;
            }

            try
            {
                if (!System.IO.Path.IsPathRooted(trimmed))
                {
                    return false;
                }

                string full = System.IO.Path.GetFullPath(trimmed);
                return IsLocalPath(full, System.IO.Path.GetPathRoot(full) ?? string.Empty);
            }
            catch
            {
                return false;
            }
        }

        private static bool LocalDirectoryExists(string path)
        {
            return IsLocalPathForScan(path) && Directory.Exists(path);
        }

        private static bool LocalFileExists(string path)
        {
            return IsLocalPathForScan(path) && File.Exists(path);
        }

        private static string[] LocalDirectoryGetFiles(string path, string pattern)
        {
            return IsLocalPathForScan(path) ? Directory.GetFiles(path, pattern) : new string[0];
        }

        private static string[] LocalDirectoryGetDirectories(string path)
        {
            return IsLocalPathForScan(path) ? Directory.GetDirectories(path) : new string[0];
        }

        internal static List<DetectedGameDirectory> ScanStoreGameDirectoriesCore(
            string steamRoot, string epicManifestDirectory,
            IEnumerable<string> gogGameDirectories, IEnumerable<string> eaGameDirectories,
            IEnumerable<string> battleNetRootDirectories, IEnumerable<string> xboxGamesRootDirectories,
            IEnumerable<string> emulatorInstallDirectories,
            string windowsAppsDirectory,
            string windowsDir, string installDir)
        {
            List<DetectedGameDirectory> result = new List<DetectedGameDirectory>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            // SCN-002: Ein Store-Eintrag darf nie ein nackter
            // Installations-Stamm sein. Der Epic-Manifestordner liegt unter
            // %ProgramData% und ist fuer den Standardbenutzer beschreibbar, die
            // GOG- und EA-Pfade stammen aus der Registry - ein Stammpfad macht
            // dort jedes Programm darunter zum Spiel, und Store-Treffer werden
            // ohne Warnung beendet.
            List<string> forbiddenRoots = ForbiddenInstallRootDirectories();
            Action<string, string> add = delegate (string path, string source)
            {
                if (!IsSafeGameDirectory(path, windowsDir, installDir))
                {
                    return;
                }
                if (IsForbiddenInstallRootDirectory(path, forbiddenRoots))
                {
                    return;
                }
                if (IsNonGameStoreDirectoryName(SafeDirectoryLeafName(path)))
                {
                    return;
                }
                string full;
                try
                {
                    full = System.IO.Path.GetFullPath(path);
                }
                catch
                {
                    return;
                }
                if (LocalDirectoryExists(full) && seen.Add(full))
                {
                    result.Add(new DetectedGameDirectory { Path = full, Source = source });
                }
            };

            try
            {
                if (!string.IsNullOrEmpty(steamRoot))
                {
                    string vdf = System.IO.Path.Combine(steamRoot, "steamapps", "libraryfolders.vdf");
                    List<string> libraries = new List<string> { steamRoot };
                    if (LocalFileExists(vdf))
                    {
                        libraries.AddRange(ParseSteamLibraryFolders(File.ReadAllText(vdf, Encoding.UTF8)));
                    }
                    HashSet<string> seenLibraries = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    foreach (string library in libraries)
                    {
                        string steamApps = System.IO.Path.Combine(library, "steamapps");
                        if (!seenLibraries.Add(steamApps) || !LocalDirectoryExists(steamApps))
                        {
                            continue;
                        }
                        foreach (string acf in LocalDirectoryGetFiles(steamApps, "appmanifest_*.acf"))
                        {
                            string installFolder = ParseSteamAppManifestInstallDir(File.ReadAllText(acf, Encoding.UTF8));
                            if (installFolder.Length != 0)
                            {
                                add(System.IO.Path.Combine(steamApps, "common", installFolder), "steam");
                            }
                        }
                    }
                }
            }
            catch
            {
            }

            try
            {
                if (!string.IsNullOrEmpty(epicManifestDirectory) && LocalDirectoryExists(epicManifestDirectory))
                {
                    foreach (string item in LocalDirectoryGetFiles(epicManifestDirectory, "*.item"))
                    {
                        string location = ParseEpicManifestInstallLocation(File.ReadAllText(item, Encoding.UTF8));
                        if (location.Length != 0)
                        {
                            add(location, "epic");
                        }
                    }
                }
            }
            catch
            {
            }

            foreach (string dir in gogGameDirectories ?? new string[0])
            {
                add(dir, "gog");
            }
            foreach (string dir in eaGameDirectories ?? new string[0])
            {
                add(dir, "ea");
            }
            foreach (string root in battleNetRootDirectories ?? new string[0])
            {
                try
                {
                    if (LocalDirectoryExists(root))
                    {
                        // SCN-004: Beides ist richtig. Nennt der
                        // Uninstall-Eintrag das Spielverzeichnis, liegt die
                        // ausfuehrbare Datei in "root" selbst; nennt er den
                        // gemeinsamen Battle.net-Ordner, liegen die Spiele
                        // darunter. Vorher kam nur der zweite Fall an.
                        add(root, "battlenet");
                        foreach (string sub in LocalDirectoryGetDirectories(root))
                        {
                            add(sub, "battlenet");
                        }
                    }
                }
                catch
                {
                }
            }
            foreach (string root in xboxGamesRootDirectories ?? new string[0])
            {
                try
                {
                    if (LocalDirectoryExists(root))
                    {
                        foreach (string sub in LocalDirectoryGetDirectories(root))
                        {
                            add(sub, "xbox");
                            foreach (string packageDirectory in
                                PackageDirectoriesForInstalledGame(sub, windowsAppsDirectory))
                            {
                                add(packageDirectory, "xbox");
                            }
                        }
                    }
                }
                catch
                {
                }
            }
            foreach (string dir in emulatorInstallDirectories ?? new string[0])
            {
                add(dir, "emulator");
            }
            return result;
        }

        internal static string WindowsAppsDirectory()
        {
            try
            {
                return System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                    "WindowsApps");
            }
            catch
            {
                return string.Empty;
            }
        }

        // Live wrapper: reads the real registry / drive layout, refreshes at
        // most every 10 minutes, never throws.
        public static List<DetectedGameDirectory> GetStoreGameDirectories(Action<string> log)
        {
            if (storeCache != null && (MonotonicNowUtc() - lastStoreScanMonotonic) < TimeSpan.FromMinutes(StoreScanIntervalMinutes))
            {
                return storeCache;
            }

            string windowsDir = string.Empty;
            string installDir = string.Empty;
            try
            {
                windowsDir = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            }
            catch
            {
            }
            try
            {
                installDir = AppDomain.CurrentDomain.BaseDirectory;
            }
            catch
            {
            }

            string steamRoot = ReadRegistryString(@"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath");
            if (steamRoot.Length == 0)
            {
                steamRoot = ReadRegistryString(@"SOFTWARE\Valve\Steam", "InstallPath");
            }

            string epicManifests = string.Empty;
            try
            {
                epicManifests = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                    "Epic", "EpicGamesLauncher", "Data", "Manifests");
            }
            catch
            {
            }

            List<string> xboxRoots = new List<string>();
            try
            {
                foreach (DriveInfo drive in DriveInfo.GetDrives())
                {
                    if (drive.DriveType == DriveType.Fixed)
                    {
                        xboxRoots.Add(System.IO.Path.Combine(drive.RootDirectory.FullName, "XboxGames"));
                    }
                }
            }
            catch
            {
            }

            List<DetectedGameDirectory> scanned;
            try
            {
                scanned = ScanStoreGameDirectoriesCore(
                    steamRoot, epicManifests,
                    ReadRegistrySubKeyValues(@"SOFTWARE\WOW6432Node\GOG.com\Games", "path"),
                    ReadRegistrySubKeyValues(@"SOFTWARE\WOW6432Node\Electronic Arts", "Install Dir"),
                    ReadBlizzardInstallLocations(),
                    xboxRoots, ReadEmulatorInstallDirectories(),
                    WindowsAppsDirectory(), windowsDir, installDir);
            }
            catch (Exception ex)
            {
                try { log("Videospiel-Erkennung: Store-Scan fehlgeschlagen: " + ex.Message); } catch { }
                scanned = new List<DetectedGameDirectory>();
            }

            storeCache = scanned;
            lastStoreScanMonotonic = MonotonicNowUtc();
            return storeCache;
        }

        // Test seam: lets the Pester end-to-end tests inject a fake store scan
        // result without touching the registry. No production caller.
        internal static void SetStoreCacheForTests(List<DetectedGameDirectory> directories)
        {
            storeCache = directories;
            // Dieselbe Uhr wie der echte Schreibweg: die Naht darf keine
            // Wanduhrzeit in ein monotones Feld schreiben.
            lastStoreScanMonotonic = MonotonicNowUtc();
        }

        private static string ReadRegistryString(string subKey, string valueName)
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(subKey))
                {
                    if (key == null)
                    {
                        return string.Empty;
                    }
                    return (key.GetValue(valueName) as string ?? string.Empty).Trim();
                }
            }
            catch
            {
                return string.Empty;
            }
        }

        private static List<string> ReadRegistrySubKeyValues(string subKey, string valueName)
        {
            List<string> values = new List<string>();
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(subKey))
                {
                    if (key == null)
                    {
                        return values;
                    }
                    foreach (string childName in key.GetSubKeyNames())
                    {
                        try
                        {
                            using (RegistryKey child = key.OpenSubKey(childName))
                            {
                                string value = (child == null ? null : child.GetValue(valueName) as string ?? string.Empty).Trim();
                                if (!string.IsNullOrEmpty(value))
                                {
                                    values.Add(value);
                                }
                            }
                        }
                        catch
                        {
                        }
                    }
                }
            }
            catch
            {
            }
            return values;
        }

        private static List<string> ReadBlizzardInstallLocations()
        {
            List<string> locations = new List<string>();
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(
                    @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"))
                {
                    if (key == null)
                    {
                        return locations;
                    }
                    foreach (string childName in key.GetSubKeyNames())
                    {
                        try
                        {
                            using (RegistryKey child = key.OpenSubKey(childName))
                            {
                                if (child == null)
                                {
                                    continue;
                                }
                                string publisher = child.GetValue("Publisher") as string ?? string.Empty;
                                if (!string.Equals(publisher.Trim(), "Blizzard Entertainment", StringComparison.OrdinalIgnoreCase))
                                {
                                    continue;
                                }
                                string location = (child.GetValue("InstallLocation") as string ?? string.Empty).Trim();
                                if (location.Length != 0)
                                {
                                    locations.Add(location);
                                }
                            }
                        }
                        catch
                        {
                        }
                    }
                }
            }
            catch
            {
            }
            return locations;
        }

        // ---- Heuristic layer (portable EXEs only) ---------------------------------

        // A process is only ever classified as a game when BOTH signals - a
        // loaded game-API module AND sustained 3D GPU load - hold for
        // HeuristicRequiredTicks consecutive guard ticks (~2 minutes). One
        // spike never classifies; a single quiet tick resets the streak.
        internal const int HeuristicRequiredTicks = 4;
        internal const float HeuristicGpu3DThresholdPercent = 20f;

        private static readonly string[] GameApiModuleFileNames =
        {
            "d3d9.dll", "d3d10.dll", "d3d10_1.dll", "d3d11.dll", "d3d12.dll",
            "dxgi.dll", "vulkan-1.dll", "opengl32.dll"
        };

        // Mirrors the critical list in PurestateGuardVideoGames.cs (pinned by
        // tests) plus known browsers: browser games are deliberately out of
        // scope for the process heuristic (companion territory), and killing a
        // whole browser over a WebGL tab would be wildly disproportionate.
        private static readonly string[] NeverClassifyFileNames =
        {
            "smss.exe", "csrss.exe", "wininit.exe", "winlogon.exe", "services.exe",
            "lsass.exe", "svchost.exe", "dwm.exe", "explorer.exe", "taskmgr.exe",
            "conhost.exe", "cmd.exe", "powershell.exe", "powershell_ise.exe", "pwsh.exe",
            "regedit.exe", "mmc.exe", "msiexec.exe", "dllhost.exe", "runtimebroker.exe",
            "sihost.exe", "fontdrvhost.exe", "ctfmon.exe", "logonui.exe", "userinit.exe",
            "msmpeng.exe", "nissrv.exe", "mpcmdrun.exe", "securityhealthservice.exe",
            "securityhealthsystray.exe",
            "purestate.exe", "purestateguard.exe", "purestatenativehost.exe",
            "purestateuninstaller.exe", "installieren.exe",
            "chrome.exe", "msedge.exe", "msedgewebview2.exe", "firefox.exe",
            "brave.exe", "opera.exe", "vivaldi.exe", "librewolf.exe",
            "waterfox.exe", "iexplore.exe",
            // VG-002: Chromium-Wirte. "d3d11.dll geladen" war einmal ein
            // Spielsignal; bei einer Electron-Anwendung heisst es "hat ein
            // Fenster". Eine Videokonferenz mit Hintergrundunschaerfe rendert
            // den Weichzeichner ueber die 3D-Engine und erfuellt beide Signale
            // laenger als die geforderten zwei Minuten - beendet wuerde sie
            // mitten im Gespraech.
            "teams.exe", "ms-teams.exe", "zoom.exe", "discord.exe", "slack.exe",
            "code.exe", "figma.exe", "spotify.exe", "notion.exe", "whatsapp.exe",
            "signal.exe", "steamwebhelper.exe"
        };

        internal static bool HasGameApiModule(IEnumerable<string> moduleFileNames)
        {
            foreach (string moduleName in moduleFileNames ?? new string[0])
            {
                string fileName;
                try
                {
                    fileName = System.IO.Path.GetFileName(moduleName ?? string.Empty);
                }
                catch
                {
                    continue;
                }
                foreach (string gameApi in GameApiModuleFileNames)
                {
                    if (string.Equals(fileName, gameApi, StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        // Known GPU-heavy creative/benchmark tools (Blender, OBS, engine
        // editors, CAD, benchmarks) trip both heuristic signals for minutes at
        // a time. They are excluded from the HEURISTIC layer only: a copy
        // installed under a detected store directory or listed as an explicit
        // target is still enforced (path-based matches are certain, the
        // exclusion covers only the uncertain signal-based branch). Renaming a
        // game to one of these names evades the heuristic - same accepted
        // limit class as the documented exe-rename gap of exact-target
        // matching.
        private static readonly string[] HeuristicOnlyExcludedFileNames =
        {
            "blender.exe", "maya.exe", "3dsmax.exe", "houdini.exe", "houdinifx.exe",
            "zbrush.exe", "cinema 4d.exe",
            "obs64.exe", "obs32.exe", "streamlabs obs.exe", "adobe premiere pro.exe",
            "afterfx.exe", "resolve.exe", "xsplit.core.exe",
            "unrealeditor.exe", "ue4editor.exe", "unity.exe", "godot.exe",
            "acad.exe", "sldworks.exe", "inventor.exe", "fusion360.exe",
            "freecad.exe", "rhino.exe",
            "3dmark.exe", "furmark.exe", "superposition.exe", "heaven.exe",
            "valley.exe", "cinebench.exe",
            // VG-002: dieselbe Klasse wie Photoshop - GPU-beschleunigte
            // Kreativwerkzeuge, die stundenlang beide Signale erfuellen.
            "photoshop.exe", "krita.exe", "illustrator.exe", "lightroom.exe",
            "indesign.exe"
        };

        internal static bool IsHeuristicExcludedFileName(string processFileName)
        {
            foreach (string excluded in HeuristicOnlyExcludedFileNames)
            {
                if (string.Equals(processFileName ?? string.Empty, excluded, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        internal static bool IsNeverClassifyProcessName(string processFileName)
        {
            foreach (string never in NeverClassifyFileNames)
            {
                if (string.Equals(processFileName ?? string.Empty, never, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        // Platform launchers are NEVER auto-enforced (design rule: a launcher
        // is only ever blocked as an explicitly listed target with its own
        // broad-impact warning). Battle.net's own uninstall entry carries
        // Publisher "Blizzard Entertainment", so its install directory shows
        // up in the store scan - this gate keeps launcher processes out of
        // the store AND heuristic match sets. Mirrors
        // KnownGameLauncherFileNames in src\NativeSupportVideoGames.cs.
        private static readonly string[] LauncherFileNames =
        {
            "steam.exe", "epicgameslauncher.exe", "eadesktop.exe", "origin.exe",
            "ubisoftconnect.exe", "upc.exe", "battle.net.exe", "riotclientservices.exe",
            "riotclient.exe", "galaxyclient.exe"
        };

        internal static bool IsAutoEnforcementExcludedFileName(string processFileName)
        {
            if (IsNeverClassifyProcessName(processFileName))
            {
                return true;
            }
            foreach (string launcher in LauncherFileNames)
            {
                if (string.Equals(processFileName ?? string.Empty, launcher, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        internal static int EvaluateHeuristicTick(bool gpu3DSustained, bool gameApiModuleLoaded, int previousConsecutiveTicks)
        {
            if (gpu3DSustained && gameApiModuleLoaded)
            {
                return Math.Max(0, previousConsecutiveTicks) + 1;
            }
            return 0;
        }

        internal static bool ShouldClassifyAsGame(int consecutiveTicks)
        {
            return consecutiveTicks >= HeuristicRequiredTicks;
        }

        // Sums the 3D-engine GPU utilization of one process. Deliberately only
        // engtype_3D: video playback runs on the decode engine and must not
        // look like gaming. Any failure (counters missing, instance gone)
        // returns 0 - the heuristic then stays silent, never false-positive.
        public static float ReadProcess3DGpuPercent(int processId)
        {
            List<System.Diagnostics.PerformanceCounter> counters =
                new List<System.Diagnostics.PerformanceCounter>();
            try
            {
                System.Diagnostics.PerformanceCounterCategory category =
                    new System.Diagnostics.PerformanceCounterCategory("GPU Engine");
                string pidToken = "pid_" + processId + "_";
                foreach (string instance in category.GetInstanceNames())
                {
                    if (instance.IndexOf(pidToken, StringComparison.OrdinalIgnoreCase) < 0 ||
                        !instance.EndsWith("engtype_3D", StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }
                    try
                    {
                        System.Diagnostics.PerformanceCounter counter =
                            new System.Diagnostics.PerformanceCounter("GPU Engine", "Utilization Percentage", instance, true);
                        counter.NextValue();
                        counters.Add(counter);
                    }
                    catch
                    {
                    }
                }

                if (counters.Count == 0)
                {
                    return 0f;
                }

                // One shared sampling window for ALL engine instances of this
                // process - a per-instance sleep would stall the guard tick
                // for seconds on GPUs that expose many 3D engines.
                System.Threading.Thread.Sleep(100);
                float total = 0f;
                foreach (System.Diagnostics.PerformanceCounter counter in counters)
                {
                    try
                    {
                        total += counter.NextValue();
                    }
                    catch
                    {
                    }
                }
                return total;
            }
            catch
            {
                return 0f;
            }
            finally
            {
                foreach (System.Diagnostics.PerformanceCounter counter in counters)
                {
                    try { counter.Dispose(); } catch { }
                }
            }
        }

        // ---- Process image path (anti-cheat safe) ---------------------------------

        // Anti-cheat drivers (EasyAntiCheat, BattlEye) strip VM_READ from
        // foreign process handles, so Process.MainModule comes back null (and
        // Modules empty) for protected games like Dead by Daylight - a bare
        // MainModule read makes those games invisible to the guard.
        // QueryFullProcessImageName only needs
        // PROCESS_QUERY_LIMITED_INFORMATION, which anti-cheat allows.
        private const uint ProcessQueryLimitedInformation = 0x1000;

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr OpenProcess(uint desiredAccess, bool inheritHandle, int processId);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CloseHandle(IntPtr handle);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern bool QueryFullProcessImageName(IntPtr process, uint flags, StringBuilder exeName, ref uint size);

        public static string GetProcessImagePath(System.Diagnostics.Process process)
        {
            try
            {
                string path = process.MainModule == null ? string.Empty : process.MainModule.FileName;
                if (!string.IsNullOrEmpty(path))
                {
                    return path;
                }
            }
            catch
            {
                // Access denied / exited - fall through to the limited query.
            }
            try
            {
                IntPtr handle = OpenProcess(ProcessQueryLimitedInformation, false, process.Id);
                if (handle == IntPtr.Zero)
                {
                    return string.Empty;
                }
                try
                {
                    StringBuilder buffer = new StringBuilder(1024);
                    uint size = (uint)buffer.Capacity;
                    if (QueryFullProcessImageName(handle, 0, buffer, ref size))
                    {
                        return buffer.ToString();
                    }
                }
                finally
                {
                    CloseHandle(handle);
                }
            }
            catch
            {
            }
            return string.Empty;
        }

        internal static List<string> TryGetModuleFileNames(System.Diagnostics.Process process)
        {
            List<string> names = new List<string>();
            try
            {
                foreach (System.Diagnostics.ProcessModule module in process.Modules)
                {
                    try
                    {
                        names.Add(module.ModuleName ?? string.Empty);
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
                // Access denied / 32-vs-64-bit mismatch / process exited.
            }
            return names;
        }

        // ---- Per-tick matching (called from VideoGamesGuard.Run) ------------------

        private static readonly Dictionary<int, int> heuristicTickStreaks = new Dictionary<int, int>();
        private static HashSet<string> persistedHeuristicPaths;
        private static string lastSavedDetectedFingerprint;

        // Classifies every candidate process (already filtered to "not a
        // listed target"). Store match = main-module path under a detected
        // game directory. Heuristic branch only when enabled, never for
        // exempted paths, never-classify names, or anything under the Windows
        // or Purestate directories. A heuristic classification is persisted,
        // so restarting the game or the service does not restart the ~2-minute
        // observation window.
        public static DetectionMatches MatchProcesses(
            IEnumerable<System.Diagnostics.Process> candidates,
            List<DetectedGameDirectory> storeDirectories,
            List<string> activeExemptions,
            bool heuristicEnabled,
            string windowsDir, string installDir, Action<string> log)
        {
            DetectionMatches matches = new DetectionMatches();
            if (persistedHeuristicPaths == null)
            {
                persistedHeuristicPaths = new HashSet<string>(LoadPersistedHeuristicPaths(), StringComparer.OrdinalIgnoreCase);
            }

            // VG-002: Eine eingetragene Ausnahme widerruft die persistierte
            // Einstufung sofort, auch waehrend ihre Frist noch laeuft. Danach
            // kann das Programm nur ueber die Signale neu eingestuft werden -
            // fuer die Programme, die dieser Befund betrifft, schliesst die
            // Nie-einstufen-Liste diesen Weg ohnehin.
            foreach (string widerrufen in LoadAllExemptionPaths())
            {
                persistedHeuristicPaths.Remove(widerrufen);
            }

            HashSet<string> exempt = new HashSet<string>(activeExemptions ?? new List<string>(), StringComparer.OrdinalIgnoreCase);
            HashSet<int> seenPids = new HashSet<int>();
            foreach (System.Diagnostics.Process process in candidates ?? new System.Diagnostics.Process[0])
            {
                int pid;
                string fullPath;
                string fileName;
                try
                {
                    pid = process.Id;
                    string path = GetProcessImagePath(process);
                    if (string.IsNullOrEmpty(path))
                    {
                        continue;
                    }
                    fullPath = System.IO.Path.GetFullPath(path);
                    fileName = System.IO.Path.GetFileName(fullPath);
                }
                catch
                {
                    // Access denied / exited between enumeration and inspection.
                    continue;
                }
                seenPids.Add(pid);

                if (IsAutoEnforcementExcludedFileName(fileName))
                {
                    continue;
                }

                // VG-001: Diese beiden Aussagen lauten "das ist kein Spiel" und
                // gelten deshalb fuer BEIDE Erkennungswege. Sie standen bisher
                // nur im Heuristikzweig, hinter dem Abbruch des Store-Zweigs -
                // Blender, Krita oder OBS aus der Steam-Bibliothek wurden damit
                // ohne Warnung, ohne Ausschlussliste und ohne Ausnahmeweg
                // beendet, im strengen Modus bei jedem Takt.
                if (IsHeuristicExcludedFileName(fileName))
                {
                    heuristicTickStreaks.Remove(pid);
                    continue;
                }
                if (exempt.Contains(fullPath))
                {
                    heuristicTickStreaks.Remove(pid);
                    continue;
                }

                bool underStore = false;
                foreach (DetectedGameDirectory directory in storeDirectories ?? new List<DetectedGameDirectory>())
                {
                    if (IsInsideDirectory(fullPath, directory.Path))
                    {
                        underStore = true;
                        break;
                    }
                }
                if (underStore)
                {
                    matches.StoreMatches.Add(process);
                    continue;
                }

                if (!heuristicEnabled ||
                    IsInsideDirectory(fullPath, windowsDir) || IsInsideDirectory(fullPath, installDir))
                {
                    continue;
                }
                // Werkzeug-Ausschluss und Nutzer-Ausnahme sind oben bereits
                // geprueft, vor dem Store-Zweig - ein frueher faelschlich
                // persistierter Werkzeugpfad matcht deshalb auch hier nicht
                // mehr, sobald ein Update die Liste erweitert.
                if (persistedHeuristicPaths.Contains(fullPath))
                {
                    matches.HeuristicMatches.Add(process);
                    continue;
                }

                bool moduleSignal = HasGameApiModule(TryGetModuleFileNames(process));
                bool gpuSignal = moduleSignal &&
                    ReadProcess3DGpuPercent(pid) >= HeuristicGpu3DThresholdPercent;
                int previousStreak;
                heuristicTickStreaks.TryGetValue(pid, out previousStreak);
                int streak = EvaluateHeuristicTick(gpuSignal, moduleSignal, previousStreak);
                heuristicTickStreaks[pid] = streak;
                if (ShouldClassifyAsGame(streak))
                {
                    persistedHeuristicPaths.Add(fullPath);
                    // Freshly classified in this guard run: the first kill
                    // countdown gets the long save window. Paths loaded from
                    // the persisted state never qualify.
                    firstCountdownPaths.Add(fullPath);
                    matches.HeuristicMatches.Add(process);
                    try { log("Videospiel-Erkennung: \"" + fileName + "\" per Heuristik als Spiel eingestuft."); } catch { }
                }
            }

            List<int> stalePids = new List<int>();
            foreach (int key in heuristicTickStreaks.Keys)
            {
                if (!seenPids.Contains(key))
                {
                    stalePids.Add(key);
                }
            }
            foreach (int key in stalePids)
            {
                heuristicTickStreaks.Remove(key);
            }

            PersistDetectedStateIfChanged(storeDirectories);
            return matches;
        }

        private static void PersistDetectedStateIfChanged(List<DetectedGameDirectory> storeDirectories)
        {
            List<string> heuristicPaths = new List<string>(persistedHeuristicPaths);
            heuristicPaths.Sort(StringComparer.OrdinalIgnoreCase);
            StringBuilder fingerprintBuilder = new StringBuilder();
            foreach (DetectedGameDirectory directory in storeDirectories ?? new List<DetectedGameDirectory>())
            {
                fingerprintBuilder.Append(directory.Source).Append(':').Append(directory.Path).Append('|');
            }
            fingerprintBuilder.Append('#');
            foreach (string path in heuristicPaths)
            {
                fingerprintBuilder.Append(path).Append('|');
            }
            string fingerprint = fingerprintBuilder.ToString();
            if (!string.Equals(fingerprint, lastSavedDetectedFingerprint, StringComparison.OrdinalIgnoreCase))
            {
                SaveDetectedState(storeDirectories ?? new List<DetectedGameDirectory>(), heuristicPaths);
                lastSavedDetectedFingerprint = fingerprint;
            }
        }

        // ---- Heuristic kill countdown ---------------------------------------------

        // Path-keyed so a game restart during an active kill window cannot
        // dodge the countdown by getting a new PID - but a path whose process
        // is gone is pruned, so a FRESH launch always gets the full 60-second
        // save warning instead of an instant kill from a stale deadline.
        private static readonly Dictionary<string, DateTime> countdownDeadlines =
            new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

        // Paths entitled to the one-time long first countdown (freshly
        // classified this guard run, entitlement consumed when the deadline is
        // created). Deliberately NOT cleared with the countdowns: below the
        // budget the entitlement waits for the first kill condition, however
        // late that comes.
        private static readonly HashSet<string> firstCountdownPaths =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        internal static List<System.Diagnostics.Process> TakeDueCountdownKills(
            List<System.Diagnostics.Process> heuristicMatches, DateTime nowUtc,
            out List<System.Diagnostics.Process> newlyAnnounced,
            out List<System.Diagnostics.Process> newlyAnnouncedFirstWindow)
        {
            newlyAnnounced = new List<System.Diagnostics.Process>();
            newlyAnnouncedFirstWindow = new List<System.Diagnostics.Process>();
            List<System.Diagnostics.Process> due = new List<System.Diagnostics.Process>();
            Dictionary<string, System.Diagnostics.Process> byPath =
                new Dictionary<string, System.Diagnostics.Process>(StringComparer.OrdinalIgnoreCase);
            foreach (System.Diagnostics.Process process in heuristicMatches ?? new List<System.Diagnostics.Process>())
            {
                try
                {
                    string path = GetProcessImagePath(process);
                    if (path.Length != 0)
                    {
                        byPath[System.IO.Path.GetFullPath(path)] = process;
                    }
                }
                catch
                {
                }
            }

            List<string> gonePaths = new List<string>();
            foreach (string key in countdownDeadlines.Keys)
            {
                if (!byPath.ContainsKey(key))
                {
                    gonePaths.Add(key);
                }
            }
            foreach (string key in gonePaths)
            {
                countdownDeadlines.Remove(key);
            }

            foreach (KeyValuePair<string, System.Diagnostics.Process> pair in byPath)
            {
                DateTime deadline;
                if (!countdownDeadlines.TryGetValue(pair.Key, out deadline))
                {
                    // Remove doubles as the presence check: the long-window
                    // entitlement is consumed by creating this deadline.
                    if (firstCountdownPaths.Remove(pair.Key))
                    {
                        countdownDeadlines[pair.Key] = nowUtc.AddSeconds(FirstCountdownSeconds);
                        newlyAnnouncedFirstWindow.Add(pair.Value);
                    }
                    else
                    {
                        countdownDeadlines[pair.Key] = nowUtc.AddSeconds(CountdownSeconds);
                        newlyAnnounced.Add(pair.Value);
                    }
                }
                else if (nowUtc >= deadline)
                {
                    due.Add(pair.Value);
                    countdownDeadlines.Remove(pair.Key);
                }
            }
            return due;
        }

        internal static void ClearCountdowns()
        {
            countdownDeadlines.Clear();
        }

        // ---- "Kein Spiel" exemptions (heuristic layer only) -----------------------

        // Line format "<ISO-8601-UTC>|<full path>" (written by the app, see
        // src\NativeSupportVideoGames.cs). Only entries whose activation time
        // has been reached count: a freshly created exemption can never rescue
        // the current gaming session. Store and listed targets are never
        // exemptable - callers must consult this list ONLY in the heuristic
        // branch.
        internal static List<string> ParseActiveExemptions(string fileText, DateTime nowUtc)
        {
            List<string> active = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string raw in (fileText ?? string.Empty).Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string trimmed = raw.Trim();
                if (trimmed.Length == 0 || trimmed.StartsWith("#", StringComparison.Ordinal))
                {
                    continue;
                }

                string[] parts = trimmed.Split(new[] { '|' }, 2);
                if (parts.Length != 2)
                {
                    continue;
                }

                DateTime activatesAt;
                if (!DateTime.TryParse(parts[0].Trim(), null,
                    System.Globalization.DateTimeStyles.RoundtripKind, out activatesAt) ||
                    activatesAt.ToUniversalTime() > nowUtc)
                {
                    continue;
                }

                string path = parts[1].Trim();
                string fullPath;
                try
                {
                    if (!System.IO.Path.IsPathRooted(path) ||
                        !string.Equals(System.IO.Path.GetExtension(path), ".exe", StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }
                    fullPath = System.IO.Path.GetFullPath(path);
                }
                catch
                {
                    continue;
                }

                if (seen.Add(fullPath))
                {
                    active.Add(fullPath);
                }
            }
            return active;
        }

        // VG-002: Die 15-Minuten-Frist ist gegen impulsives Freischalten
        // gedacht. Auf einen erkannten Fehlalarm angewandt ist sie eine
        // Strafe: das falsch eingestufte Programm bliebe eine Viertelstunde
        // lang ein "Spiel". Die eingetragene Ausnahme nimmt deshalb die
        // PERSISTIERTE Einstufung sofort zurueck - wirken als Ausnahme, also
        // gegen eine neue Einstufung aus den Signalen, tut sie weiterhin erst
        // nach der Frist.
        internal static List<string> ParseAllExemptionPaths(string fileText)
        {
            return ParseActiveExemptions(fileText, DateTime.MaxValue);
        }

        public static List<string> LoadActiveExemptions()
        {
            return LoadExemptionsUpTo(
                ExemptionActivationNowUtc(GuardService.ReadClockAnchorUtc(), DateTime.UtcNow));
        }

        internal static List<string> LoadAllExemptionPaths()
        {
            return LoadExemptionsUpTo(DateTime.MaxValue);
        }

        private static List<string> LoadExemptionsUpTo(DateTime nowUtc)
        {
            try
            {
                string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "video-game-exemptions.txt");
                if (!File.Exists(path))
                {
                    return new List<string>();
                }
                return ParseActiveExemptions(File.ReadAllText(path, Encoding.UTF8), nowUtc);
            }
            catch
            {
                return new List<string>();
            }
        }

        // ---- Detected-state persistence (read by the app for display) ------------

        private static string JsonEscape(string value)
        {
            return (value ?? string.Empty).Replace("\\", "\\\\").Replace("\"", "\\\"");
        }

        private static string JsonUnescape(string value)
        {
            return (value ?? string.Empty).Replace("\\\"", "\"").Replace("\\\\", "\\");
        }

        internal static string BuildDetectedJson(List<DetectedGameDirectory> directories, List<string> heuristicPaths)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("{\"Directories\":[");
            bool first = true;
            foreach (DetectedGameDirectory directory in directories ?? new List<DetectedGameDirectory>())
            {
                if (!first)
                {
                    sb.Append(',');
                }
                first = false;
                sb.Append("{\"Path\":\"").Append(JsonEscape(directory.Path))
                    .Append("\",\"Source\":\"").Append(JsonEscape(directory.Source)).Append("\"}");
            }
            sb.Append("],\"HeuristicPaths\":[");
            first = true;
            foreach (string path in heuristicPaths ?? new List<string>())
            {
                if (!first)
                {
                    sb.Append(',');
                }
                first = false;
                sb.Append('"').Append(JsonEscape(path)).Append('"');
            }
            sb.Append("]}");
            return sb.ToString();
        }

        internal static List<string> ParseDetectedHeuristicPaths(string json)
        {
            List<string> paths = new List<string>();
            Match arrayMatch = Regex.Match(json ?? string.Empty,
                "\"HeuristicPaths\"\\s*:\\s*\\[([^\\]]*)\\]");
            if (!arrayMatch.Success)
            {
                return paths;
            }
            foreach (Match entry in Regex.Matches(arrayMatch.Groups[1].Value, "\"((?:[^\"\\\\]|\\\\.)*)\""))
            {
                string value = JsonUnescape(entry.Groups[1].Value).Trim();
                if (value.Length != 0)
                {
                    paths.Add(value);
                }
            }
            return paths;
        }

        internal static List<string> LoadPersistedHeuristicPaths()
        {
            try
            {
                string path = DetectedStatePath;
                if (!File.Exists(path))
                {
                    return new List<string>();
                }
                FileInfo info = new FileInfo(path);
                if (info.Length > MaxDetectedFileBytes)
                {
                    return new List<string>();
                }
                return ParseDetectedHeuristicPaths(File.ReadAllText(path, Encoding.UTF8));
            }
            catch
            {
                return new List<string>();
            }
        }

        public static void SaveDetectedState(List<DetectedGameDirectory> directories, List<string> heuristicPaths)
        {
            try
            {
                string path = DetectedStatePath;
                string json = BuildDetectedJson(directories, heuristicPaths);
                GuardService.ReplaceFileAtomically(path, delegate(string temp)
                {
                    File.WriteAllText(temp, json, new UTF8Encoding(false));
                });
            }
            catch
            {
            }
        }

        // Pure self-test used by PurestateGuard.exe --self-test.
        internal static string RunSelfTest()
        {
            List<string> libs = ParseSteamLibraryFolders(
                "\"libraryfolders\"\n{\n\t\"0\"\n\t{\n\t\t\"path\"\t\t\"C:\\\\Program Files (x86)\\\\Steam\"\n\t}\n\t\"1\"\n\t{\n\t\t\"path\"\t\t\"D:\\\\SteamLibrary\"\n\t}\n}");
            if (libs.Count != 2 || libs[0] != @"C:\Program Files (x86)\Steam" || libs[1] != @"D:\SteamLibrary")
            {
                return "steam libraryfolders parsing failed";
            }
            if (ParseSteamAppManifestInstallDir("\"AppState\"\n{\n\t\"installdir\"\t\t\"MyGame\"\n}") != "MyGame" ||
                ParseSteamAppManifestInstallDir("\"AppState\"\n{\n\t\"installdir\"\t\t\"..\\\\evil\"\n}") != string.Empty ||
                ParseSteamAppManifestInstallDir("no manifest") != string.Empty)
            {
                return "steam appmanifest parsing failed";
            }
            if (ParseEpicManifestInstallLocation("{\"InstallLocation\": \"C:\\\\Games\\\\EpicGame\"}") != @"C:\Games\EpicGame" ||
                ParseEpicManifestInstallLocation("{}") != string.Empty)
            {
                return "epic manifest parsing failed";
            }
            string windows = @"C:\Windows";
            string install = @"C:\Program Files\Purestate";
            if (!IsSafeGameDirectory(@"C:\Games\MyGame", windows, install) ||
                IsSafeGameDirectory(@"C:\Windows\System32", windows, install) ||
                IsSafeGameDirectory(@"C:\Program Files\Purestate\rules", windows, install) ||
                IsSafeGameDirectory(@"C:\", windows, install) ||
                IsSafeGameDirectory("Games", windows, install))
            {
                return "game directory safety validation failed";
            }

            List<DetectedGameDirectory> jsonDirs = new List<DetectedGameDirectory>
            {
                new DetectedGameDirectory { Path = @"C:\Games\My Game", Source = "steam" }
            };
            List<string> jsonPaths = new List<string> { @"C:\Games\portable\game.exe" };
            string detectedJson = BuildDetectedJson(jsonDirs, jsonPaths);
            List<string> parsedPaths = ParseDetectedHeuristicPaths(detectedJson);
            if (parsedPaths.Count != 1 || parsedPaths[0] != @"C:\Games\portable\game.exe")
            {
                return "detected-state json roundtrip failed";
            }

            if (!HasGameApiModule(new[] { "kernel32.dll", "D3D11.DLL" }) ||
                HasGameApiModule(new[] { "kernel32.dll", "user32.dll" }) ||
                !IsNeverClassifyProcessName("chrome.exe") ||
                !IsNeverClassifyProcessName("SVCHOST.EXE") ||
                IsNeverClassifyProcessName("mygame.exe"))
            {
                return "heuristic module/never-classify checks failed";
            }

            if (!IsHeuristicExcludedFileName("blender.exe") ||
                !IsHeuristicExcludedFileName("OBS64.EXE") ||
                !IsHeuristicExcludedFileName("unrealeditor.exe") ||
                IsHeuristicExcludedFileName("chrome.exe") ||
                IsHeuristicExcludedFileName("mygame.exe"))
            {
                return "heuristic gpu-tool exclusion failed";
            }

            if (!IsAutoEnforcementExcludedFileName("Battle.net.exe") ||
                !IsAutoEnforcementExcludedFileName("steam.exe") ||
                !IsAutoEnforcementExcludedFileName("chrome.exe") ||
                IsAutoEnforcementExcludedFileName("mygame.exe"))
            {
                return "auto-enforcement launcher exclusion failed";
            }

            if (ResolveEmulatorDirectoryFromUninstallEntry("BlueStacks", "", @"C:\Program Files\BlueStacks_nxt\ProductLogo.ico") != @"C:\Program Files\BlueStacks_nxt" ||
                ResolveEmulatorDirectoryFromUninstallEntry("BlueStacks Services", "", @"C:\Users\x\AppData\Local\Programs\bluestacks-services\BlueStacksServices.exe,0") != @"C:\Users\x\AppData\Local\Programs\bluestacks-services" ||
                ResolveEmulatorDirectoryFromUninstallEntry("LDPlayer9", @"C:\LDPlayer\LDPlayer9", "") != @"C:\LDPlayer\LDPlayer9" ||
                ResolveEmulatorDirectoryFromUninstallEntry("7-Zip", @"C:\Program Files\7-Zip", "") != string.Empty ||
                ResolveEmulatorDirectoryFromUninstallEntry("BlueStacks", "", "") != string.Empty)
            {
                return "emulator uninstall entry resolution failed";
            }
            string[] forbiddenRoots = { @"C:\Program Files", @"C:\Users\x\AppData\Local\Programs" };
            if (!IsForbiddenInstallRootDirectory(@"C:\Program Files", forbiddenRoots) ||
                !IsForbiddenInstallRootDirectory(@"C:\Program Files\", forbiddenRoots) ||
                IsForbiddenInstallRootDirectory(@"C:\Program Files\BlueStacks_nxt", forbiddenRoots))
            {
                return "emulator root directory guard failed";
            }

            using (System.Diagnostics.Process self = System.Diagnostics.Process.GetCurrentProcess())
            {
                if (string.IsNullOrEmpty(GetProcessImagePath(self)))
                {
                    return "process image path resolution failed";
                }
            }

            int streak = 0;
            for (int i = 0; i < HeuristicRequiredTicks - 1; i++)
            {
                streak = EvaluateHeuristicTick(true, true, streak);
            }
            if (ShouldClassifyAsGame(streak) ||
                EvaluateHeuristicTick(false, true, streak) != 0 ||
                !ShouldClassifyAsGame(EvaluateHeuristicTick(true, true, HeuristicRequiredTicks - 1)))
            {
                return "heuristic tick state machine failed";
            }

            return string.Empty;
        }
    }
}
