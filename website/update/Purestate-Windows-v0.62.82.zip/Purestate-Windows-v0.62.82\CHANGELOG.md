# Purestate Aenderungsprotokoll

## Version 0.62.82

Purestate findet neue Versionen selbst. Die erste Fassung mit dieser Funktion
installierst du noch von Hand; erst ab der nächsten läuft es automatisch. Der
Companion ändert sich in dieser Version nicht.

- **Purestate meldet neue Versionen.** Einmal am Tag fragt der Tray im
  Hintergrund auf purestate-app.com nach einer neueren Fassung: zwei kleine
  öffentliche Dateien, ohne Gerätekennung, Freischaltcode oder Einstellungen.
  Das Verwaltungsfenster zeigt oben auf der Startseite einen Hinweis; unter
  „Mehr“ gibt es „Nach Updates suchen“.
- **Ein Klick führt bis zum Installer.** Der Update-Dialog zeigt Version,
  Datum und was neu ist. „Jetzt installieren“ lädt die Datei, prüft Signatur,
  Größe und Prüfsumme, entpackt sie und startet den Installer, der wie immer
  nach dem Passwort fragt. Eine stille Installation gibt es nicht.
- **Nur der Betreiber kann Updates ausliefern.** Die Dateien sind mit einem
  eigenen Schlüssel signiert, dessen öffentlicher Teil fest in der App steht.
  Eine veränderte Datei, eine fremde Signatur oder eine ältere Version wird
  ignoriert.
- **Nach einem Update läuft der Tray wieder.** Der Installer startet das
  Symbol neu, statt es bis zur nächsten Anmeldung fehlen zu lassen.
- **„Zur neuen Fassung“ bietet das Update an.** Auf dem Bildschirm „Beta
  beendet“ sucht der Knopf zuerst nach der neuen Fassung; nur ohne Verbindung
  öffnet er wie bisher die Website.
- **Kurze Knöpfe sind nicht mehr abgeschnitten.** Bei Beschriftungen wie
  „OK“ oder „Später“ ragte der Knopf in Meldungsfenstern rechts aus dem
  Fenster.

## Version 0.62.81

Aus den Notizen der ersten lokalen Installation (2026-10-06). Die Companion-Änderungen brauchen den Store-Upload: erst die App
verteilen, dann den Companion veröffentlichen.

- **Ein Wort wie „analysis“ löst den Vorhang nicht mehr aus.** Der Vorhang
  kam schon beim Tippen von „anal“, nahm den Fokus und ließ das Wort nicht
  zu Ende schreiben. Das letzte, noch offene Wort in einem Suchfeld zählt
  jetzt erst nach einem Leerzeichen, nach Enter oder wenn das Feld den Fokus
  verliert. Abgeschickte Suchen bleiben so streng wie bisher. Dasselbe galt
  für „cocktail“, „Milford“, „adulthood“ und viele mehr; es gilt für die
  Suchfelder von YouTube und Suchmaschinen, X, Bluesky und Instagram.
- **Die Kasse sagt, was Sache ist.** Auf der ersten Kassenseite von Amazon
  steht noch keine Summe. Die Einblendung meldete dort „Betrag nicht lesbar“
  und klang nach Fehler. Jetzt steht dort, dass der Betrag noch nicht feststeht
  und nachgetragen wird. Summen, die in getrennten Zellen stehen, findet
  Purestate außerdem bis zu drei Ebenen über der Beschriftung.
- **Shopping und Glücksspiel zeigen die Restzeit.** Wie bei Social Media
  erscheint unten rechts ein kleines Kästchen („Noch 28:45 min“), solange ein
  Tageslimit gilt und noch nicht erreicht ist.
- **YouTube liegt nicht mehr unter dem Shopping-Vorhang.** Eine einzige Seite
  mit Preis und Kaufen-Knopf (ein Produktregal, eine Werbung) genügte, und
  Purestate hielt youtube.com 30 Tage lang für einen Shop. Das Zuschauen zählte
  dann als Shopping-Zeit, und war das Shopping-Limit voll oder die Sperrzeit
  aktiv, lag „Tageszeit für Shopping erreicht“ über YouTube, obwohl das
  Social-Media-Limit noch Zeit hatte. Die Plattformen des Social-Media-Bereichs
  (YouTube, Reddit, X, Instagram, TikTok, Pinterest, Tumblr, Bluesky und die
  Streamingdienste) gelten jetzt nie als Shop, auch ein alter Eintrag im
  Browserprofil wirkt nicht mehr. Gepflegte und selbst eingetragene Shops
  bleiben, wie sie waren. Außerdem merkt sich Purestate einen Host nur noch bei
  echter Produktauszeichnung 30 Tage lang als Shop; ein einzelner Fehltreffer der
  weichen Regel („Warenkorb plus Preis“) trifft nur noch seine eine Seite.
- **Spiele: die Restzeit steht beim Start.** Das Kästchen oben rechts kam bisher
  erst in der letzten halben Stunde. Beim Spielstart zeigt es jetzt kurz
  „Noch 60 min heute“, egal ob das Tageslimit voll oder angebrochen ist. Ein
  schneller Fühler erkennt den Start nach wenigen Sekunden statt erst im
  30-Sekunden-Takt.
- **Streaming gehört zu Social Media.** Netflix, Disney+, Prime Video, Max,
  Paramount+, Apple TV+, Crunchyroll, Twitch, Joyn, RTL+, DAZN und WOW lassen
  sich auf der Social-Media-Seite begrenzen oder sperren. Streaming hat ein
  eigenes Tageslimit: es zählt nicht ins gemeinsame Zeitlimit, und die
  Social-Media-Pause gilt dort nicht. Nur im Browser; die Apps der Dienste und
  Prime Video auf amazon.de bleiben frei.
- **Der Internetschutz warnt vor CleanBrowsing.** CleanBrowsing Family erzwingt
  auf DNS-Ebene den eingeschränkten YouTube-Modus (gemessen), auch wenn der
  Schalter in Purestate aus ist. Die Einstellungen sagen das beim Wählen des
  Filters. Cloudflare Family und OpenDNS FamilyShield tun das nicht.
- **Eine Marke für App, Companion und Store.** Der Companion trägt das
  Purestate-Zeichen statt eines „P“ in der Symbolleiste, das Store-Symbol ist
  das aktuelle, und die Säulen im App-Symbol haben dieselben runden Ecken wie
  auf der Webseite.
- **Purestate öffnet ohne Rückfrage der Benutzerkontensteuerung.** Auf einem
  Administratorkonto startet die Verwaltung über eine erhöhte Aufgabe, ohne
  dass Windows bei jedem Öffnen nachfragt. Ohne die Aufgabe und auf einem
  Standardkonto bleibt es bei der Rückfrage wie bisher. Installer und
  Deinstaller fragen weiterhin.
- **Die Reparatur der Wächter-Aufgaben funktioniert.** Löscht oder deaktiviert
  jemand die Watchdog- oder die Startaufgabe von Purestate, legt Purestate sie
  wieder an. Bisher scheiterte das still: Windows bekam den Befehl in Stücken.

## Version 0.62.80

- **Speichern geht deutlich schneller und lässt keine Lücke mehr.** Bisher baute
  Purestate bei jedem Speichern erst den ganzen Schutz ab und dann neu auf. Das
  dauerte auf langsamen Rechnern Minuten, und dazwischen war der Rechner kurz
  ungeschützt. Jetzt gleicht Purestate nur ab: Ausgeschaltetes wird gezielt
  entfernt, Eingeschaltetes aufgebaut.
- **Offene Browserfenster bleiben beim Speichern meist offen.** Chrome und Edge
  starten nur noch neu, wenn sich an ihrer Sperrliste oder an einer Richtlinie
  wie dem eingeschränkten YouTube-Modus wirklich etwas ändert.

## Version 0.62.79

- **Das erste Einschalten meldet keinen Fehler mehr, wenn alles geklappt
  hat.** Nach einer Neuinstallation muss Purestate beim ersten Schutzbereich
  alles auf einmal einrichten. Das dauerte länger als erlaubt, und der Dialog
  meldete "nicht vollständig gelungen" - obwohl die Einstellung gespeichert war
  und der Schutz kurz darauf stand. Jetzt steht dort, dass gespeichert wurde
  und der Schutz noch im Hintergrund angewendet wird, und Purestate lässt sich
  dafür mehr Zeit.
- **Version 0.62.78 wurde nie ausgeliefert.** Ihre Änderungen (unten) kommen
  mit dieser Version.

## Version 0.62.78

- **Nach der Installation ist noch nichts eingeschaltet.** Eine neue
  Installation startet mit allen fünf Schutzbereichen aus, dazu ohne
  Sperrliste, Familien-DNS, VPN-, Tor- und Proxy-Sperre und ohne Sperre nicht
  unterstützter Browser. Browser- und Manipulationsschutz laufen von Anfang an.
  Die Startseite sagt "Noch kein Schutzbereich eingeschaltet" und führt mit
  einem Knopf zu den Schutzbereichen.
- **Ein Schutzbereich schaltet ein, was er braucht.** Wer einen Bereich
  einschaltet, bekommt die Sperrliste, die VPN-, Tor- und Proxy-Sperre und die
  Sperre nicht unterstützter Browser dazu, beim Erwachsenenschutz auch den
  Familien-DNS. Ausgeschaltet wird dabei nie etwas.
- **Ein Update ändert keine Einstellungen.** Bestehende Installationen
  behalten, was eingeschaltet ist. Der Installer schaltet bei einem Update
  keine Filter mehr ein.
- **Erwachseneninhalte haben einen Hauptschalter.** Ist "Erwachseneninhalte-
  Schutz einschalten" aus, wirken auch die Filter für einzelne Seiten wie
  Reddit oder X, die erzwungene sichere Suche und die Sperre von Suchbegriffen
  nicht. Den Schalter auszuschalten gilt wie jede andere Lockerung.
- **Die App sieht aus wie die Webseite.** Farben, abgerundete Karten und
  Knöpfe und die Schrifthierarchie folgen purestate-app.com, im hellen wie im
  dunklen Modus. Der aktive Menüeintrag und die Auswahl in Listen sind
  deutlich zu sehen.
- **Auswahlfelder passen zum dunklen Modus.** Rahmen und Pfeil, etwa bei den
  Uhrzeiten der festen Shopping-Sperrzeit, erscheinen in den Farben der App
  statt als weißer Kasten, und der untere Rand fehlt nicht mehr.
- **Version 0.62.77 wurde nie ausgeliefert.** Ihre Korrekturen (unten)
  kommen mit dieser Version.

## Version 0.62.77

- **Instagram und DeviantArt werden nicht mehr grundlos einen Tag lang
  gesperrt.** Die Erweiterung lädt im Hintergrund die Einstellungsseite dieser
  Dienste, um eine Änderung vom Handy zurückzudrehen. Instagram verbietet das
  grundsätzlich, und DeviantArt zeigt Abgemeldeten stattdessen die Anmeldung.
  Beides wurde als Fehler gewertet, und nach etwa zwei Minuten sperrte
  Purestate die ganze Seite für 24 Stunden und startete Chrome neu. Jetzt zählt
  nur noch eine wirklich geladene Einstellungsseite.
- **Ein Ausfall des Schutzdienstes hebt die Tageslimits nicht mehr auf.**
  Konnte die Erweiterung den Dienst nicht erreichen, galten die Tageslimits für
  Shopping, Glücksspiel und Social Media nicht mehr - und ein neu geladener Tab
  kannte gar kein Limit. Jetzt gelten die zuletzt bekannten Regeln bis zu einen
  Tag weiter. Kennt die Erweiterung keine, pausiert sie die Seite nach etwa
  zwei Minuten, statt sie frei zu geben.
- **"Zurück" führt aus einer gesperrten Seite heraus.** Hatte der Tab keinen
  Verlauf, sprang der Knopf auf die Startseite derselben Seite - bei
  Erwachsenen- und Glücksspielseiten und in der Shopping-Sperrzeit ist die aber
  genauso gesperrt. Man landete wieder vor demselben Vorhang. Jetzt öffnet
  "Zurück" dort eine leere Seite.
- **Kleinere Textkorrekturen** in den Vorhängen: deutsche Anführungszeichen,
  ein echter Gedankenstrich, und die Tageslimit-Vorhänge wiederholen ihren
  Titel nicht mehr.

## Version 0.62.76

- **Die Einblendungen sehen aus wie purestate-app.com.** Jede Sperre, jeder
  Dialog, jeder Feed-Platzhalter, die Warnleiste und das Zeit-Abzeichen tragen
  jetzt die Farben, das Pausezeichen und die Schrifthierarchie der Website und
  folgen dabei deinem Hell-/Dunkelmodus. Sichtbare Texte schreiben Umlaute
  wieder als Umlaute statt als "ae/oe/ue". Was wann gesperrt wird, bleibt
  unveraendert; nur das Aussehen aendert sich.
- **Die Knoepfe in den Einblendungen sind auch bei starkem Zoom erreichbar.**
  Bei 400 Prozent Zoom lag die letzte Aktion knapp unter dem Fensterrand, und
  im Dunkelmodus war der Fokusrahmen des Hauptknopfs nicht vom Knopf zu
  unterscheiden. Auf Shops, die ihre Grundschrift verkleinern, schrumpfte die
  Textspalte bis auf ein Zehntel ihrer Breite.
- **Berichte geben deine eigenen Domains nicht mehr im Klartext preis.** Die
  Pruefung der Webseitenlisten nannte bis zu vierzig Eintraege namentlich -
  darunter deine selbst gepflegte Sperr- und Allowlist. Der Bericht ist zum
  Weitergeben gedacht; jetzt stehen die Eintraege dort verkuerzt
  (bei***.de). Vollstaendig siehst du sie weiterhin in der App.
- **Aus allen Berichten verschwindet der Windows-Benutzername.** Der
  Umgehungscheck listete vollstaendige Programmpfade unter
  C:\Users\<Name>\... - eine Teilinventur installierter Software samt
  Kontoname, in einem Text, den du weitergeben sollst.
- **Die Datenschutzerklaerung stimmt wieder mit der App ueberein.** Vier
  Stellen waren veraltet oder unvollstaendig: Sie beschrieb die Erhebung von
  Gesundheitsdaten (Stimmung, Stress, Schlaf), die es gar nicht mehr gibt;
  sie nannte nur eine von drei Pruefungen, die auf jeder Webseite laufen; und
  sie verschwieg, was ueber die lokale Verbindung zwischen Erweiterung und App
  tatsaechlich uebertragen wird - darunter der Hostname einer erkannten
  Erwachsenenseite und der Kaufbetrag beim Shopping-Schutz.

- **Die Statusanzeige sagt jetzt, was wirklich wirkt.** Der gruene Haken hing
  allein an der hosts-Sperre: fehlte der Familien-DNS oder eine
  Browser-Richtlinie, stand trotzdem "Alle aktivierten Schutzbereiche
  funktionieren" da. Jetzt ist gruen nur gruen, wenn jeder eingeschaltete
  Bereich auch wirkt - und wenn nicht, steht dabei, welcher. Bereiche, die du
  bewusst ausgeschaltet hast, zaehlen nicht mit.
- **"Familien-DNS aktiv" prueft die richtigen Netzwerkkarten.** Bisher genuegte
  eine einzige Karte mit dem Familien-DNS - auch eine abgestoepselte. Wer sein
  Notebook aus der Dockingstation nahm oder ein VPN aufbaute, surfte
  ungefiltert und sah trotzdem "aktiv".
- **"Companion aktiv" bedeutet wieder, dass Purestates eigene Regeln stehen.**
  Auf Geraeten mit einer Sperrliste einer anderen Software genuegte deren
  blosse Anwesenheit fuer die Erfolgsmeldung.
- **Der angezeigte Proxy-Status gehoert zum richtigen Konto.** Wer die App mit
  einem separaten Administratorkonto oeffnet, sah bisher dessen Einstellungen,
  waehrend Purestate die des eigenen Kontos aenderte.

- **Der DNS-Schutz wirkt jetzt auch auf Rechnern mit VPN, WSL2, Docker oder
  Hyper-V.** Bisher wurden ausschliesslich physische Netzwerkadapter umgestellt -
  auf genau diesen Rechnern laeuft die Namensaufloesung aber ueber einen
  virtuellen Adapter. Der DNS-Schutz war dort wirkungslos, waehrend die Anzeige
  ihn als aktiv meldete.
- **Eine beschaedigte DNS-Sicherung fuehrt nicht mehr dazu, dass der erzwungene
  Familien-DNS dauerhaft bestehen bleibt.** War die Sicherungsdatei unlesbar -
  etwa nach einem Stromausfall oder einem Virenscanner -, wurde sie mit dem
  bereits erzwungenen DNS neu geschrieben; die Deinstallation "stellte" danach
  genau diesen wieder her. Die unlesbare Datei wird jetzt beiseitegelegt, und
  ein bereits erzwungener DNS wandert grundsaetzlich nicht mehr in die
  Sicherung. Beim Zuruecksetzen wird der Adapter ausserdem ueber seinen Namen
  statt ueber eine Nummer angesprochen, die Windows jederzeit neu vergeben kann.
- **Auf verwalteten Rechnern gehen keine Sperren mehr still verloren.** Sind in
  Chrome oder Edge bereits Sperrlisten einer anderen Software eingetragen
  (Firma, Schule, Sicherheitsprodukt), wurden Purestates eigene Regeln dahinter
  gehaengt - ueber das Limit von 1000 Eintraegen hinaus, das der Browser
  auswertet. Der Rest fiel aus, ohne Hinweis. Jetzt stehen die eigenen Regeln
  vorn, die Liste wird auf das Limit gekuerzt, und der Fall wird protokolliert.
- **Der Companion prueft, mit wem er spricht.** Die lokale Verbindung zum
  Schutzdienst wurde bisher ungeprueft als vertrauenswuerdig behandelt. Ein
  anderes Programm konnte diesen Kanal vorab belegen, Schutzbereiche darueber
  abschalten und mitlesen. Die Gegenstelle muss jetzt der installierte
  Schutzdienst sein.
- **Der Dienst startet zuegig, statt in eine Neustartschleife zu geraten.** Die
  erste vollstaendige Durchsetzung lief beim Start direkt mit und konnte laenger
  dauern, als Windows auf einen Dienst wartet. Die Folge war Fehler 1053 und ein
  Neustart im Minutentakt. Sie laeuft jetzt im Hintergrund weiter.
- **Die Deinstallation laesst keine Aufgabe mehr zurueck.** Die Aufgabe fuer das
  Videospiel-Abzeichen wurde beim Entfernen uebersehen und blieb im
  Aufgabenplaner stehen - mit einem Verweis auf eine Datei, die es nicht mehr
  gab. Weil der Ordner dadurch nicht leer war, blieb auch er liegen. Beides
  wird jetzt entfernt, und eine Aufgabe, die gar nicht existiert, bricht das
  Aufraeumen nicht mehr ab.
- **Eine selbst gesperrte Webseite laesst sich nicht mehr in Sekunden wieder
  freigeben.** Eintragen wirkt weiterhin sofort; das Entfernen wartet jetzt
  15 Minuten, so wie jede andere Abschwaechung eine Frist hat. Genau dieser
  Ablauf - im klaren Moment eintragen, im Impuls wieder loeschen - war der
  Grund, warum es die Fristen ueberhaupt gibt. **Ein Vertipper bleibt
  korrigierbar**: was du in der letzten Stunde eingetragen hast, verschwindet
  sofort wieder. Und wer die Sperre zurueckholt, bevor die Frist um ist, hebt
  seine eigene Freigabe damit auf.
- **Aus einer beschaedigten Konfiguration fuehrt jetzt ein Weg heraus.** War die
  Konfiguration gesperrt - was auch ohne Zutun passiert, etwa nach einem
  Stromausfall -, verweigerten App, Installer und Deinstaller jeden Dienst. Es
  gab damit **keine Moeglichkeit mehr, Purestate loszuwerden**, und die frueher
  angezeigte Anleitung liess ausgerechnet die Ordner loeschen, in denen die
  Werkzeuge fuer den Rueckbau liegen: hosts-Eintrag, erzwungenes DNS,
  Proxy, Firewall-Regeln und Browser-Richtlinien waeren dauerhaft
  zurueckgeblieben. Der Deinstaller bietet in diesem Fall jetzt ein
  vollstaendiges Entfernen ohne Passwort an - mit ausdruecklicher Rueckfrage,
  und es nimmt alle Systemaenderungen zurueck. Der Installer verweist auf
  denselben Weg, statt zum Loeschen von Ordnern zu raten.
- **Ein Companion, der nicht mehr laeuft, gilt nicht mehr als aktiv.** Fehlte
  sein Lebenszeichen, genuegte bisher der Registry-Eintrag, den Purestate selbst
  fuer die erzwungene Installation schreibt - der belegt aber nur, dass die
  Erweiterung installiert ist. Brach die Verbindung zur Erweiterung weg, lud sie
  keine Regeln mehr, und die Vollsperre der gemischten Seiten blieb trotzdem
  aus: der Rechner war ungefiltert, ohne Hinweis. Der Eintrag traegt jetzt nur
  noch, solange der Browser gerade gestartet ist oder das letzte Lebenszeichen
  wenige Minuten zurueckliegt. **Wer die gemischten Seiten unerwartet gesperrt
  sieht, hat einen echten Ausfall der Erweiterung** - die Statusanzeige nennt
  ihn jetzt.
- **Der Dev-Modus ist im ausgelieferten Programm nicht mehr vorhanden.** Er gab
  die Vertrauensrolle des Companions an eine beliebige selbst geladene
  Browser-Erweiterung weiter und nahm gleichzeitig die erzwungene Installation
  der echten Erweiterung zurueck - geschuetzt nur durch das Passwort, ohne
  Wartezeit, waehrend die Oberflaeche den Schutz weiter als aktiv meldete.
  Damit haette ein einziger Handgriff die gesamte browserseitige Schutzschicht
  aushebeln koennen. Der Eintrag unter "Mehr" entfaellt; den Dev-Modus gibt es
  nur noch in Entwicklerbauten.
- **Ein fehlgeschlagenes Speichern laesst den Rechner nicht mehr ungeschuetzt
  zurueck.** Jedes Speichern raeumt den Schutz erst ab und baut ihn danach neu
  auf. Brach der Abbau unterwegs ab, unterblieb der Aufbau ganz - ohne
  hosts-Sperre, ohne Familien-DNS, ohne Browser-Richtlinien, waehrend die
  Einstellungen weiter "aktiv" zeigten und die App "gespeichert" gemeldet
  hatte. Der Aufbau laeuft jetzt in jedem Fall, der Fehler steht weiterhin im
  Sicherheitsprotokoll.
- **Freigaben heben mitgelieferte Sperren nicht mehr auf.** Ein Eintrag in der
  Allowlist konnte bisher eine kuratierte Erwachsenen- oder Gluecksspieldomain
  sofort aus der lokalen Sperre nehmen - ohne die Wartefrist, die dieselbe
  Abschwaechung ueber die Einstellungen gebraucht haette. **Wer heute eine
  solche Domain freigegeben hat, verliert diese Freigabe mit diesem Update.**
  Selbst eingetragene Sperren (eigene Liste) bleiben weiterhin freigebbar, und
  neue Eintraege dieser Art werden jetzt mit einer Meldung abgelehnt, statt
  wirkungslos in der Datei zu stehen.
- **Werkzeuge aus der Spielebibliothek werden nicht mehr beendet.** Blender,
  Krita oder OBS stehen bei vielen Nutzern in der Steam-Bibliothek. Weil der
  Videospielschutz einen Fund im Store-Verzeichnis sofort als Spiel behandelte,
  wurden sie ohne Warnung und ohne Ausnahmeweg geschlossen - im strengen Modus
  alle 30 Sekunden erneut. Die Werkzeugliste und die eigenen "Kein Spiel"-
  Ausnahmen gelten jetzt fuer beide Erkennungswege.
- **Eine wiederhergestellte Sicherung kann den Schutz nicht mehr sofort
  abschwaechen.** Der Import setzte praktisch jeden Schutzschalter aus einer
  Textdatei, die man selbst bearbeiten kann - vorbei an der Wartezeit, die
  dieselbe Aenderung ueber die Einstellungen gebraucht haette. **Eine Sicherung,
  die nichts abschwaecht, laeuft weiterhin sofort durch** (der Normalfall nach
  einer Neuinstallation); nur der abschwaechende Import wartet, und die Meldung
  nennt das Feld, das die Sperre ausloest.
- **Suchen wie "breast cancer", "sex education" oder "Nacktmull" werden nicht
  mehr blockiert.** Die gemeinsame Suchwortliste hatte keine Kontextausnahme;
  der Vollvorhang traf damit ausgerechnet Aufklaerung, Medizin und Biologie.
  Die Ausnahme entfernt nur ihre eigene Phrase - "breast cancer porn" bleibt
  gesperrt.
- **Programme mit "tor" im Pfad verlieren nicht mehr den Netzwerkzugriff.**
  Adobe Illustrator, TortoiseGit und jedes Programm unter einem Benutzernamen
  wie "Viktor" bekamen eine Firewallregel, weil die Stichwoerter als
  Teilzeichenkette geprueft wurden. Sie treffen jetzt nur noch als ganzes Wort.
- **Das Shopping-Monatsbudget zaehlt wieder mit.** Der gebuchte Betrag erreichte
  seinen Empfaenger im Schutzdienst nie, das Monatslimit sperrte deshalb zu spaet
  oder gar nicht.
- **Eine abgeschaltete Erweiterung loescht nicht mehr die Browser-Sperrliste.**
  Der Notfallpfad ersetzte die ganze Liste durch seine eigenen Eintraege; jetzt
  werden sie zusammengefuehrt.

## Version 0.62.75

- **Suchmaschinen-Schutz greift jetzt auch auf Unteradressen.** Bei manchen
  Anbietern liegt die Suche auf einer Unteradresse wie `html.duckduckgo.com`.
  Dort lief die Erweiterung bisher gar nicht, und die Suche blieb ungefiltert.
- **Suchen ohne Suchbegriff in der Adresse werden erkannt.** Manche Anbieter -
  Startpage etwa - schicken den Begriff unsichtbar mit, statt ihn in die
  Adresszeile zu schreiben. Solche Suchen liefen bisher am Schutz vorbei;
  jetzt wird der Begriff aus dem Suchfeld gelesen.

## Version 0.62.74

- **Die Systemuhr zurueckzustellen hebelt den Browserschutz nicht mehr aus.**
  Purestate laesst einem frisch gestarteten Browser eine kurze Schonfrist,
  damit er nicht gesperrt wird, bevor die Erweiterung sich melden konnte. Wer
  die Uhr zurueckstellte, liess den Browser dadurch juenger wirken, als er war,
  und rutschte immer wieder in diese Schonfrist - der Schutz blieb dann
  ueberwiegend aus. Fuer das Alter des Browsers zaehlt jetzt dieselbe
  faelschungssichere Zeit, die Purestate schon fuer Wartezeiten und Fristen
  benutzt.

## Version 0.62.73

- **Die Deinstallation nimmt die Browser-Erweiterung jetzt wirklich mit.** Beim
  Entfernen blieb bisher die Regel zurueck, die die Purestate-Erweiterung in
  Chrome erzwingt und anheftet. Die Erweiterung blieb dadurch im Browser
  stehen, liess sich nicht entfernen und konnte nichts mehr tun. Sie wird jetzt
  am Ende des Entfernens noch einmal abgeraeumt, nachdem der Schutzdienst weg
  ist - vorher konnte er sie im letzten Moment neu setzen.

## Version 0.62.72

- **Der Browser schliesst sich nicht mehr im Kreis, wenn die Erweiterung
  ausfaellt.** Faellt die Verbindung zur Browser-Erweiterung aus, schloss
  Purestate den Browser und oeffnete ihn wieder - und der frisch gestartete
  Browser bekam erneut die Schonfrist, die eigentlich nur fuer einen normalen
  Start gedacht ist. Dadurch begann alles von vorn, etwa alle fuenf Minuten,
  und der Schutz kam nie richtig zum Tragen. Ein Start, den Purestate selbst
  ausgeloest hat, bekommt diese Schonfrist jetzt nicht mehr; ein normaler
  Start durch dich weiterhin schon.

## Version 0.62.71

- **Die Browser-Erweiterung meldet sich wieder als lebendig.** Ihre
  Lebendmeldung an den Schutzdienst kam in Wahrheit nie an: der Vermittler
  zwischen Browser und Dienst prueft, ob die Gegenstelle wirklich der
  installierte Dienst ist, und diese Pruefung schlug systembedingt immer fehl.
  Sichtbar war das als Browser, der sich von selbst schloss und neu startete.
  Der Schutz griff die ganze Zeit, aber ueber einen Notweg, der nur befristet
  gedacht ist. Die Pruefung geht denselben Nachweis jetzt anders an und
  gelingt.
- **Fehler der Browser-Erweiterung stehen wieder im Protokoll.** Der
  Vermittler schrieb sein Fehlerprotokoll an eine Stelle, an der er gar nicht
  schreiben darf, und verwarf jede Meldung stillschweigend. Er weicht jetzt
  auf einen Ort aus, an dem das Schreiben gelingt, und die Diagnose sieht dort
  ebenfalls nach.

## Version 0.62.70

- **YouTube laeuft nicht mehr zwangsweise im eingeschraenkten Modus.** Der
  Modus blendet neben Erwachseneninhalten auch vieles andere aus - Musik,
  Nachrichten, ganze Kanaele -, und das war als Vorgabe zu grob fuer ein
  Werkzeug, das gegen einen bestimmten Impuls hilft. Der Schalter bleibt und
  laesst sich jederzeit einschalten; wer ihn bereits aktiviert hatte, behaelt
  ihn unveraendert.

## Version 0.62.69

- **Ein Kaestchen oben rechts zeigt beim Spielen die verbleibende Zeit.** Es
  erscheint in der letzten halben Stunde des Tagesbudgets, zaehlt runter und
  wird unter fuenf Minuten rot. Klicks gehen hindurch, es nimmt keinen Fokus
  und taucht nicht in Alt-Tab auf. Im exklusiven Vollbild ist es nicht zu
  sehen - dort liegt kein Fenster ueber dem Spiel.
- **Die Warnung bei 30, 15 und 5 Minuten kommt ohne Meldefenster.** Bisher
  erschien ein Windows-Fenster mitten im Bild, das man waehrend des Spielens
  wegklicken musste. Der Hinweis laeuft jetzt ueber dasselbe Kaestchen.
- **Das Tagesbudget zaehlt die echte Zeit.** Es buchte rund das
  Anderthalbfache, weil der Zeitanker nur einmal pro Minute geschrieben wird,
  die Durchsetzung aber alle 30 Sekunden laeuft und fuer einen stehenden Anker
  trotzdem einen vollen Takt buchte. Ein 45-Minuten-Budget war dadurch nach gut
  30 Minuten aufgebraucht.
- **Xbox- und Microsoft-Store-Spiele werden erkannt.** Sie laufen nicht aus
  ihrem Installationsordner, sondern aus dem registrierten Paketordner unter
  `WindowsApps` - dadurch entkamen sie der automatischen Erkennung vollstaendig.
- **Anwendungen aus Spielebibliotheken werden nicht mehr fuer Spiele
  gehalten.** Wallpaper Engine, Steamworks-Redistributables, Engine-Editoren und
  Spielstandordner wurden im strengen Modus jedes Mal beendet.
- **Das Protokoll nennt die beendeten Programme mit vollem Pfad** statt nur
  ihrer Anzahl. Ohne Namen liess sich weder eine Ausnahme eintragen noch ein
  Fehler melden.
- **Zwei gemessene Cloud-Gaming-Dienste aufgenommen**, `luna.amazon.de` und
  `now.gg`. Von Amazon Luna war nur die .com-Domain gesperrt, was ausgerechnet
  deutsche Nutzer durchliess.
- **Der Familien-DNS wird zurueckgegeben, sobald der Schalter aus ist.** Bisher
  geschah das erst bei der Deinstallation, der Adapter blieb also auf dem
  erzwungenen Filter stehen.

## Version 0.62.68

- **Die Reflexionsfrage schaltet den Ton stumm.** Bisher verdeckte sie nur das
  Bild - ein laufendes Video lief darunter weiter, mit Ton. Angehalten wird der
  Abspieler aus diesem Weg weiterhin nicht: ein wieder aktivierter
  YouTube-Abspieler kann den Tab dabei einfrieren. Stummschalten aendert den
  Abspielzustand nicht und kann das deshalb nicht ausloesen.
- **Der Umgehungsschutz meldet die Proxy-Abschaltung nur noch bei einer echten
  Aenderung.** Der Durchsetzungslauf kam alle 30 Sekunden wieder und schrieb die
  Werte jedes Mal neu, samt Protokollzeile, obwohl laengst alles aus war. Das
  Aktivitaetsprotokoll fuellte sich mit 32 KB Rauschen, echte Eintraege gingen
  darin unter.

## Version 0.62.67

- **Eine Seite, die ihre eigene 2257-Erklaerung verlinkt, gilt als
  selbstgekennzeichnet.** Bisher zaehlte nur die ausgeschriebene Erklaerung und
  das RTA-Kennzeichen. Gemessen an den KI-Begleiter-Plattformen steht die
  Erklaerung dort auf einer Unterseite, die niemand oeffnet, der Verweis aber
  im Fussbereich jeder Seite. Ein zweites, unabhaengiges Signal bleibt noetig -
  der Verweis allein sperrt nichts. Allgemeine KI-Werkzeuge fuehren ihn nicht:
  in der Kontrollgruppe der Messung keine einzige Seite.
- **Zwei gemessene Anbieter in die Erwachsenenliste aufgenommen**,
  `spicychat.ai` und `dreamgf.ai`. Beide kommen durch den Familien-DNS-Filter,
  beide weisen sich selbst als Erwachsenenangebot aus. Sieben weitere
  Anbieter derselben Klasse bleiben bewusst draussen, solange nur die
  Vermutung und kein Beleg vorliegt.

## Version 0.62.66

- **Der Browser wird beim Richtlinien-Neuladen jetzt wirklich geschlossen.** Der
  Durchsetzungslauf des Dienstes laeuft als LocalSystem in Session 0, der
  Browser in der Sitzung des Nutzers; ein `CloseMainWindow` von dort erreicht
  dessen Fenster nie. Der Lauf schob den Refresh deshalb bei jedem Takt erneut
  auf (10 Sekunden Leerlauf pro Takt), und eine Freigabe wirkte in Chrome erst,
  wenn der Nutzer den Browser selbst neu startete. Das Schliessen geht jetzt
  ueber dieselbe Einmalaufgabe im Nutzerkontext wie der Neustart, mit
  `taskkill` ohne `/F` - also weiterhin ohne Hard-Kill und ohne Tab-Verlust.

- **Auch der Schutzdienst schiesst den Browser nicht mehr grundlos ab.** Sein
  eigener Schliessweg (er greift nur, wenn der Companion vorsaetzlich
  abgeschaltet wurde) hatte dieselbe Sitzungsgrenze: das Wartefenster von acht
  Sekunden lief immer leer aus, danach blieb nur der harte Abbruch mit
  Tab-Verlust. Der Dienst nimmt jetzt denselben Weg ueber den Nutzerkontext;
  der Abbruch bleibt als letzte Instanz bestehen.

## Version 0.62.65

- **Drei Anbieter in die kuratierte Erwachsenenliste aufgenommen**, gemessen
  statt geraten: `candy.ai`, `soulgen.net` und `fanvue.com` kommen als einzige
  von 50 erreichbaren Kandidaten durch den Familien-DNS-Filter, und die
  Inhaltserkennung sieht sie ebenfalls nicht - ihre Startseiten tragen weder
  Kennzeichen noch zweites Signal. `unstability.ai` bleibt bewusst draussen: ein
  allgemeiner Bildgenerator ist kein Erwachsenenangebot.

- **Ein aufgeschobener Richtlinien-Refresh geht nicht mehr verloren.** Bleibt
  der Browser beim Schliessversuch offen, merkt der Lauf den ausstehenden
  Refresh in `pending-policy-refresh.txt` und wiederholt ihn im naechsten
  Durchgang. Vorher haing die Wiederholung an einer erneuten Aenderung der
  Sperrliste, die es nach dem ersten Schreiben nie wieder gab - eine wirksame
  Freigabe blieb im Browser bis zu drei Stunden gesperrt.
- **Schluessel, Konfiguration und DNS-Sicherung werden bis auf die Platte
  durchgeschrieben.** `File.WriteAllText` und `Set-Content` legen den Inhalt nur
  im Dateisystem-Cache ab; nach einem unsauberen Herunterfahren behielten
  `integrity.key` und `dns-backup.json` ihre Groesse und verloren ihren Inhalt.
  Die signierte Konfiguration galt danach als kompromittiert, und die einzige
  Abhilfe war das Loeschen des Datenordners samt aller Einstellungen.
- **Verwaiste Aufgabendateien blockieren keine Neuinstallation mehr.** Bleiben
  nach einer Deinstallation Dateien unter `%WINDIR%\System32\Tasks\Purestate`
  liegen, waehrend der Aufgabenplaner den Ordner nicht mehr kennt, scheitern
  `GetFolder` und `CreateFolder` gemeinsam und die Installation brach ab. Der
  Ordner wird jetzt in genau diesem Fall aufgeraeumt und neu angelegt.

## Version 0.62.64

- **Erwachseneninhalte werden jetzt auch am Seiteninhalt erkannt, nicht nur
  ueber die kuratierte Domainliste.** Meldet sich eine Seite selbst als
  Erwachsenenangebot (RTA-Kennzeichen, 2257-Erklaerung) UND bestaetigt ein
  zweites, unabhaengiges Signal das, verdeckt der Companion sie sofort mit
  einem Vollvorhang. Nur Wortsignale ohne Marker geben eine Warnleiste, die
  Seite bleibt lesbar. Aufklaerung, Beratung, Gesundheitsportale, Behoerden
  und Nachschlagewerke stehen auf einer festen Ausnahmeliste und werden nie
  erkannt, redaktionelle Berichte ueber das Thema ebenfalls nicht. Viele
  Videoelemente zaehlen nur zusammen mit eindeutigem Erwachsenen-Vokabular
  in ausdruecklich markierten Kategorie-/Tag-Elementen. Freier Seitentext und
  mehrdeutige Woerter wie `teen` oder `amateur` tragen nicht; ein
  `mature`-Marker auf einer neutralen Videogalerie reicht nicht.
- **Ein erkannter Host wirkt jetzt browseruebergreifend, nicht nur solange
  derselbe Chrome-Companion offen ist.** Der Guard-Dienst uebernimmt hart
  erkannte Hosts dauerhaft in die hosts-Datei und in die Chromium-Sperrliste
  (`URLBlocklist`) - Letzteres haelt auch dann, wenn ein Browser die
  hosts-Datei mit eigenem Secure-DNS umgeht.
- **Faelschlich erkannte Webseiten lassen sich in den Schutzbereich-
  Einstellungen freigeben.** Gleiche Bauart wie beim Gluecksspiel-Bereich:
  Hinzufuegen braucht das Passwort und wirkt nach 15 Minuten, Zuruecknehmen
  wirkt sofort und ohne Passwort.
- **Pruefstand und Live-Pruefliste vorbereitet.** `tools\Measure-AdultDetection.js`
  misst die Erkennung gegen einen Treffer- und einen Nie-sperren-Korpus;
  zuletzt gemessen 9/9 erreichbarer Seiten aus dem Treffer-Korpus hart
  erkannt, 0 Fehltreffer im Nie-sperren-Korpus. Ersetzt nicht den Live-Test
  in `docs\LIVE-TEST-ADULT.md` an einer echten Installation mit echtem
  Chrome-Companion und Firefox als Gegenprobe ohne Companion. Der Pruefstand
  scheitert jetzt auch, wenn eine Treffer-Seite nur weich oder gar nicht
  erkannt wird.
- **Die Schlusspruefung der Erwachsenen-Erkennung schliesst Zeit-, Retry- und
  Groessengrenzen.** Bereits offene Tabs erhalten ohne Navigation exakt an
  der 15-Minuten-Aktivierung und der 30-Tage-Ablaufkante einen neuen Rule
  Pack. Ein Hostbericht bleibt vor dem ersten Native-Host-Versuch persistent
  in einer deduplizierten, alarmgestuetzten Retry-Queue und wird erst nach
  einem Erfolgs-Ack entfernt. Das lokale 30-Tage-Gedaechtnis beginnt erst,
  nachdem die Queue-Aufnahme bestaetigt wurde; eine volle Queue lehnt den
  neuen Host ab, ohne einen unbestaetigten Eintrag zu verdraengen.
  Erwachsenen-Freigaben sind auf 500 gleichzeitig
  nicht abgelaufene Eintraege begrenzt; Nummer 501 wird in der App sichtbar
  abgewiesen. Uebergrosse Altdateien werden vollstaendig gelesen und erst
  danach auf die 500 juengsten Eintraege begrenzt, sodass ein abgelaufener
  Vorspann keine gueltige spaetere Freigabe verdeckt. Native Host und
  Companion akzeptieren gueltige Mehrlabel-Hosts
  bis 253 Zeichen, deduplizieren linear und sichern das 1-MiB-Nachrichtenbudget.

## Version 0.62.63

- **Die Sperrliste fuer Chrome und Edge steht endlich in dem Format, das diese
  Browser lesen.** Beide Browserlisten wurden bisher als
  Firefox-Match-Patterns erzeugt (`*://*.reddit.com/r/*nsfw*`). Chromium
  versteht nur `host/pfad` und verwirft alles andere stillschweigend - von
  1000 Eintraegen wirkten 24. Domainsperren waren nie betroffen, die traegt
  die hosts-Datei ohnehin doppelt; verloren waren die Regeln, die nur eine
  Browser-Richtlinie kann, weil sie einen Pfad haben: die NSFW-Subreddits, die
  Feed-Routen und `xbox.com/play`. Stichwort-Suchmuster
  (`/search*porn*`) lassen sich in Chromium nicht ausdruecken und entfallen
  dort - sie waren dort ohnehin wirkungslos; diese Schicht tragen der
  erzwungene SafeSearch und der Companion. Firefox bleibt unveraendert.
- **Der Umgehungsschutz hat keine Luecke mehr zwischen zwei
  Durchsetzungslaeufen.** Die Firewallregeln gegen VPN- und Proxy-Programme
  wurden bei jedem Lauf geloescht und neu angelegt, also alle 30 Sekunden.
  Zwischen Loeschen und Neuanlegen war der Schutz kurz aus. Jetzt wird nur
  noch gebaut, wenn sich die Liste der zu sperrenden Programme geaendert hat -
  fehlt eine Regel, wird weiterhin sofort repariert.
- **Drei Stellen erledigen selbst, worum sie bisher gebeten haben.** Fehlen
  Programmdateien, startet die Reparatur das Installationsprogramm selbst,
  statt darum zu bitten. Haelt ein von Chrome neu gestarteter Native Host
  waehrend einer Aktualisierung eine Datei fest, fasst der Kopiervorgang noch
  einmal nach, statt "Bitte schliesse Purestate" zu melden. Und der
  Aufraeumordner der Deinstallation entfernt sich selbst, statt als leerer
  Ordner stehen zu bleiben.

## Version 0.62.62

- **Gluecksspiel-Schutz: heuristisch erkannte Seiten werden im strikten Modus
  vom Companion verdeckt.** Bisher zaehlte eine erkannte Seite nur auf das
  Tagesbudget - gesperrt war sie nicht. Gelistete Domains bleiben unveraendert
  ueber hosts-Datei, DNS und Browser-Richtlinie gesperrt; fuer erkannte Hosts
  ist der Vorhang die einzige Durchsetzung, weil sie nur der Browser kennt.
- **Faelschlich erkannte Webseiten lassen sich im Gluecksspiel-Dialog
  freigeben.** Hinzufuegen braucht das Passwort und wirkt nach 15 Minuten,
  Zuruecknehmen wirkt sofort und ohne Passwort. Die Freigabe wirkt nur auf die
  Inhaltserkennung - Seiten aus den Sperrlisten bleiben gesperrt, und eine
  Freigabe fuer sie wird mit Begruendung abgelehnt statt als Attrappe
  angenommen.

## Version 0.62.61

- **Die Erkennung wurde an echten Anbietern im echten Browser gemessen, nicht
  nur am Pruefstand.** An sechs Anbieter kommt der Pruefstand nicht heran:
  vier wehren ihn als Bot ab, zwei bauen ihre Seite erst im Browser auf und
  werden unter headless Chrome nie fertig. Alle sechs wurden von Hand gegen
  beide Signale geprueft.
- **Drei Anbieter haetten ohne diese Version durchgerutscht.** merkurbets.de,
  interwetten.com und rollbit.com fuehren ihren Pflichthinweis nicht als
  Warnsatz, sondern als "Responsible Gaming" oder "Responsible Gambling";
  rollbit.com braucht zusaetzlich "Sportsbook" als Betriebswort. Beides ist
  jetzt aufgenommen. Der Pruefstand haette das nie gezeigt - er erreicht
  keinen der drei.
- **stake.com war eine echte Luecke.** Die Seite nennt weder Warnsatz noch
  Lizenzgeber im Text, sondern "Stake setzt sich fuer verantwortungsvolles
  Gluecksspiel ein". Diese Formel zaehlt jetzt als Signal 1.
  "Selbstausschluss" haette denselben Dienst getan und ist bewusst **nicht**
  aufgenommen: das Wort steht auf jeder Beratungs- und Aufsichtsseite.
- **Lotterien werden erkannt.** lotto.de fuehrt den Pflichthinweis, verkauft
  aber weder Wettschein noch Freispiel und fiel deshalb durch. Spielteilnahme,
  Spielschein, Tippschein, Lottoschein und Spieleinsatz kommen dazu; nicht
  aufgenommen ist "Gewinnzahlen", das meldet jede Nachrichtenseite am
  Samstagabend.
- **Zwei dieser Woerter stehen hinter einer Wortgrenze**, weil sie sonst in
  "Gluecksspielteilnahme" und "Gluecksspieleinsatz" stecken - den Woertern,
  mit denen jeder Fachtext ueber Spielsucht arbeitet. Der Wikipedia-Artikel
  zur Gluecksspielstoerung trug bis dahin beide Signale und hing allein an
  der redaktionellen Ausnahme.
- **Die Gluecksspielbehoerde steht jetzt fest in der Ausnahmeliste.** Sie galt
  als redaktionelle Seite, fuehrt live aber ueberhaupt kein JSON-LD - die
  Ausnahme greift dort nicht. Geschuetzt war sie nur davon, dass auf der
  Startseite zufaellig kein Betriebswort steht, waehrend "Spielerschutz" auf
  jeder ihrer Seiten steht.
- **Der Pruefstand sieht jetzt, was ein Browser sieht.** Mit `--dom` rendert
  er die Seiten durch das installierte Chrome; eine Wettseite liefert
  ausgeliefert 248 Zeichen Text und gerendert ueber 14000. Zustimmungsbanner
  werden auch im Shadow-DOM gefunden, unsichtbare Schaltflaechen
  uebersprungen und der Klick wiederholt, weil das Banner teils erst Sekunden
  nach dem Laden erscheint.
- **Die Rahmen-Frage ist beantwortet, und zwar mit nein.** Bei jedem nicht
  erkannten Anbieter bewertet der Pruefstand dessen Rahmen einzeln. Kein
  einziger trug Gluecksspiel, das im obersten Dokument gefehlt haette -
  `all_frames` haette an keinem Fall etwas geaendert, und der damit
  verbundene Umbau auf den Service-Worker ist nicht gerechtfertigt.
- `detectGamblingPage` benennt bei einem Nein jetzt das fehlende Signal
  statt einer leeren Zeichenkette. Der Grund steuert nichts - entschieden
  wird weiter allein ueber `gambling` -, aber ohne ihn ist nicht zu sehen,
  ob eine Seite den Pflichthinweis nicht fuehrt oder kein Angebot macht.
- Pruefstand: 7 von 9 erreichbaren Anbietern, 0 von 10 Fehltreffern im
  Nie-sperren-Korpus. Mit dem Live-Durchgang zusammen sind 13 von 13
  geprueften Anbietern erkannt. Nur Companion und Werkzeug; kein
  Schemawechsel, keine neue Berechtigung, keine Aenderung an der
  Windows-seitigen Durchsetzung. **Gesperrt wird weiterhin nichts.**

## Version 0.62.60

- **Gluecksspiel wird am Inhalt erkannt, nicht nur an einer Liste.** Bisher
  galt der Schutz auf 42 Baseline-Domains plus den Offshore- und
  Custom-Listen; "nimm eine andere Seite" war damit dieselbe billige Umgehung
  wie im Shopping-Bereich vor 0.62.58 - und gerade die unlizenzierten
  Anbieter koennen auf keiner amtlichen Liste stehen.
- Ein Treffer verlangt **zwei unabhaengige Signale**: den regulatorischen
  Suchthinweis oder Lizenztext und ein betriebliches Element (Einzahlung,
  Wettschein, Freispiele) oder einen eingebetteten Spielanbieter. Keins von
  beiden reicht allein: der Warnhinweis steht auf jeder Seite, die ueber
  Spielsucht schreibt, die Betriebswoerter stehen bei jeder Bank.
- **Zwei harte Nicht-Erkennen-Regeln stehen darueber:** redaktionelle Seiten
  (`Article`, `NewsArticle`) und eine feste Liste der Hilfsangebote (BZgA,
  check-dein-spiel.de, Caritas, Diakonie, Telefonseelsorge und weitere)
  werden nie erkannt. Die Liste steht im Code und ist per Test gepinnt -
  konfigurierbar hiesse leerbar, und eine gesperrte Beratungsstelle waere
  Schaden am Zweck des Bereichs, kein Schoenheitsfehler.
- **Gesperrt wird in dieser Stufe nichts.** Erkannte Hosts laufen nur auf das
  bestehende Tages-Zeitbudget, wie eine gelistete Domain. Ein Host-Gedaechtnis
  haelt einen erkannten Anbieter 30 Tage fest, damit auch seine Unterseiten
  mitzaehlen.
- **Neues Werkzeug `tools/Measure-GamblingDetection.js`:** misst gegen drei
  Korpora - lizenzierte Anbieter, Offshore-Casinos und einen Nie-sperren-
  Korpus aus Beratung, Presse und Banken. Ein Treffer im dritten Korpus setzt
  den Rueckgabewert auf 1. Aktueller Lauf: 0 von 10.
- **Zwei Fehler kamen erst durch das Messen an echten Seiten heraus, nicht
  aus den Attrappen.** Eine Wettseite rendert ueber eine halbe Million
  Zeichen - der Textdeckel liest jetzt Anfang UND Ende statt nur den Anfang,
  sonst faellt der Pflichthinweis im Fussbereich weg. Und hinter einem
  Zustimmungsbanner liefert eine Seite 1.400 Zeichen, waehrend sich der
  Ladezustand danach nie mehr aendert: der Erkenner sieht deshalb bis zu
  viermal nach statt einmal, mit fester Obergrenze gegen einen Dauerscan.
- Nur der Companion hat sich geaendert. Kein Schemawechsel, keine neue
  Berechtigung, keine Aenderung an der Windows-seitigen Durchsetzung.
  **Web-Store-Upload noetig**, damit die Aenderung ohne Dev-Modus wirkt.

## Version 0.62.59

- **Die Kaufverzoegerung griff auf gemerkten Shops nicht.** Das Host-
  Gedaechtnis aus 0.62.58 deckt Startseiten und Kategorien - Sperrzeit,
  Zaehlung und Reizdaempfung liefen dort. `shoppingCheckoutHere()` fragte fuer
  nicht kuratierte Hosts aber weiter `detectedShopPage()`, und eine Kassenseite
  traegt fast nie Produktauszeichnung. Ausgerechnet der Mechanismus, der
  unmittelbar vor dem Kauf sitzt, fiel damit durch.
- Gefragt wird jetzt der Host statt der einzelnen Seite - dieselbe Frage, die
  der Rest des Moduls stellt. Kuratierte Shops und selbst eingetragene Domains
  sind unveraendert, sie liefen schon vorher ueber ihre eigenen Kassenrouten.
- Eigene Version statt Nachbesserung an 0.62.58, weil 0.62.58 getaggt ist:
  eine Versionsnummer muss einen festen Satz Dateien bedeuten.

## Version 0.62.58

- **Die Shop-Erkennung aus 0.62.57 funktionierte, lief aber fast nie.** Bei
  einem nicht gelisteten Host wurde genau einmal gefragt: in dem Moment, in
  dem das Regelpaket eintraf. Das ist Millisekunden nach `document_start`, und
  da ist die Seite leer. Also lautete das Urteil "kein Shop", das Modul startete
  nie, und danach fragte nichts mehr nach. Die elf kuratierten Shops waren nicht
  betroffen, weil sie bedingungslos starten - deshalb sah es aus wie "geht bei
  Amazon, sonst nicht". Gefunden im Livelauf auf notebooksbilliger.de.
- Gefragt wird jetzt zusaetzlich bei `DOMContentLoaded` und `load`. Und weil
  Produktauszeichnung im `<head>` steht und dort fertig ist, lange bevor die
  Seite sichtbar wird, startet ein Kopf-Beobachter das Modul schon bei diesem
  Markup und schaltet sich danach ab.
- **Neu: das Host-Gedaechtnis.** Wurde auf einem Hostnamen einmal ein Shop
  erkannt, gilt der ganze Host 30 Tage lang als Shop. Ohne das blieben
  Startseiten, Kategorien und Suchergebnisse ungedeckt - genau die Seiten, auf
  denen Zeit verloren geht, und auf denen deshalb auch das Tagesbudget nicht
  mitlief. Gespeichert wird nur der Hostname mit Zeitstempel in
  `chrome.storage.local`, hoechstens 300 Eintraege, hoechstens stuendlich je
  Host geschrieben; ein zukunftsdatierter Eintrag verfaellt bewusst nicht
  sofort, damit eine vorgestellte Uhr das Gedaechtnis nicht leert.
  `PRIVACY-POLICY.md` benennt die Liste samt Verfall und Obergrenze.
- **Ein echter Fehltreffer, gefunden vom neuen Pruefstand:** heise.de traegt
  `Article` UND `Product` im selben Dokument. Auf redaktionellen Seiten reicht
  Produktauszeichnung deshalb nicht mehr - ein Warenkorb-Bedienelement muss
  dazukommen. Ein Shop mit Redaktionsteil wird weiter erkannt.
- **Preisvergleichsportale** (idealo, geizhals, billiger.de, guenstiger.de,
  preisvergleich.de) sind fuer eine kaufseiten-orientierte Erkennung
  strukturell unsichtbar: kein Warenkorb, teils gar kein Markup. Sie sind jetzt
  eine kurze kuratierte Gruppe - **ohne Kassenrouten**, weil dort nicht gekauft
  wird. Fuers Stoebern sind sie die reinste Form.
- **Neues Werkzeug `tools/Measure-ShopDetection.js`:** misst die Erkennung
  gegen eine Liste echter Shops und Nicht-Shops und meldet Trefferquote und
  Fehltreffer. Es laedt den echten Erkenner; nachgebaut ist nur das Dokument.
  Damit laesst sich die Qualitaet messen, **ohne Nutzerdaten zu sammeln** -
  bewusst die Alternative zu einer Telemetrie, die Surfverlauf an einen Server
  schicken wuerde. Aktueller Lauf: 6 von 12 erreichbaren Shop-Startseiten
  erkannt, 0 von 14 Fehltreffern. Seiten mit Bot-Abwehr antworten mit 403 und
  werden ehrlich als "nicht erreichbar" gemeldet.
- Nur der Companion hat sich geaendert. Kein Schemawechsel, keine Aenderung an
  der Windows-seitigen Durchsetzung. **Web-Store-Upload noetig**, damit die
  Aenderungen ohne Dev-Modus wirken.

## Version 0.62.57

- **Der Shopping-Schutz haengt nicht mehr an einer Liste.** Bisher galt er auf
  elf kuratierten Shops plus den selbst eingetragenen Domains - "nimm einen
  anderen Shop" war damit die billigste Umgehung des ganzen Schutzbereichs.
  Der neue `shopping-detect.js` entscheidet am Inhalt der Seite: Produkt-
  auszeichnung (JSON-LD/schema.org, `og:type`), Warenkorb-Bedienelemente und
  Preisangaben.
- **Fehltreffer kosten Wartezeit, nicht Zugang.** Erkannte Shops bekommen nur
  die sanften Mechanismen: Kaufverzoegerung, Reizdaempfung, Sperrzeit und
  Zaehlung. Der harte Block bleibt den kuratierten und den selbst
  eingetragenen Domains vorbehalten - dasselbe Muster wie beim
  Videospiel-Heuristik-Layer.
- **Keine neue Berechtigung noetig.** Das Shopping-Modul lief schon bisher auf
  `*://*/*` und hat sich nur selbst per Hostliste ausgeschaltet. Es aendert
  sich also nichts an dem, was die Erweiterung darf - nur daran, wann sie
  handelt.
- **Der Kaufbetrag wird von der Seite gelesen statt eingetippt.** Beim
  Monatsbudget gab es bisher ein optionales Eingabefeld im Wartescreen. Ein
  Budget, dessen Zahlen man im Kaufmoment selbst eintraegt, kann genau dann
  kleingerechnet werden, wenn es binden wuerde. Jetzt liest die Erweiterung
  die Gesamtsumme der Kassenseite (beschriftete Summenzeile, sonst
  Preisauszeichnung), deutsche und englische Schreibweise.
- Ist kein Betrag lesbar, wird der Kauf **gezaehlt, aber ohne Betrag** - das
  Budget ist dann eine Untergrenze. Ein Fail-closed haette einen Shop mit
  ungewoehnlichem Markup komplett unbenutzbar gemacht, auch fuer harmlose
  Kaeufe.
- Gelesen wird nur die bereits geladene Seite, im Arbeitsspeicher. Der Betrag
  bleibt im Browserprofil und geht nie in `config.json`, Backups,
  Supportdateien, Protokolle oder ans Netz. `PRIVACY-POLICY.md`,
  `THREAT-MODEL.md` und die Store-Begruendungen sind entsprechend geaendert -
  "Betraege nur nach freiwilliger Eingabe" stimmt nicht mehr.
- Geprueft im Browser auf einem Host, der in keiner Liste steht: die
  Einblendung erscheint dort von selbst und nennt den Betrag aus der
  Gesamtsumme der Seite. Dazu drei Node-Pruefungen fuer Erkenner und
  Betragsformate. Kein Schemawechsel, keine Aenderung an der Windows-seitigen
  Durchsetzung.

## Version 0.62.56

- **Windows zeigt jetzt das Purestate-Zeichen statt eines Buchstabens.** Im
  Fenster, in der Taskleiste und im Infobereich stand bisher ein gezeichnetes
  "P" auf blauem Kreis. Jetzt steht dort das Schild mit den zwei Saeulen von
  der Webseite, in GDI+ mit denselben Koordinaten wie
  `website/public/favicon.svg` nachgezogen.
- Gezeichnet wird die dunkle Fassung auf einer Navy-Kachel. Der dunkle Bogen
  des hellen Entwurfs waere auf einer dunklen Taskleiste kaum zu sehen, und
  ohne Kachel verschwaende das helle Zeichen auf hellem Grund.
- **Die Programmdateien hatten ueberhaupt kein Symbol.** `Build-Release.ps1`
  reichte `/win32manifest` an csc weiter, aber kein `/win32icon` - Explorer,
  Startmenue, Verknuepfungen und der Windows-Uninstall-Eintrag zeigten damit
  das generische .NET-Symbol. Alle drei Programme bekommen jetzt
  `src/purestate.ico`.
- `PurestateVisualIdentity` liegt dafuer in einer eigenen Datei: `tools/New-
  AppIcon.ps1` kompiliert genau diese Zeichenroutine mit, damit es keinen
  zweiten Satz Koordinaten gibt, der auseinanderlaufen kann.
- Die ersten Rahmen waren PNG. Der Explorer versteht das, GDI+ nicht - das
  Symbol liess sich nicht zurueckpruefen. Jetzt sind 16 bis 128 klassische
  DIB-Rahmen und nur 256 bleibt PNG; alle geprueften Groessen laden sauber.
- Keine Aenderung an der Schutzwirkung, kein Schemawechsel.

## Version 0.62.55

- **Die Abschaltdatei ist implementiert.** Sie war seit dem Entwurf des
  Abschaltplans offen und muss laut Spezifikation vor dem ersten Verkauf
  stehen: wird Purestate als Dienst eingestellt, veroeffentlicht der Betreiber
  eine signierte Datei, und Geraete die sie sehen kehren dauerhaft in den
  lokalen Modus zurueck.
- Kanonisat `op=shutdown` + `issued=<ISO-8601 UTC>`, gemeinsam gepinnt mit
  `Grants.ShutdownCanonical` auf dem Server. Bewusst ohne Geraeteschluessel -
  die Abschaltung gilt global - und ohne Ablauf: sie muss in zehn Jahren noch
  aufgehen.
- **Kein Abschwaechungsfenster, aber Passwort.** Der Dienst existiert dann
  nicht mehr; auf einer Frist zu bestehen, die niemand mehr verkuerzen kann,
  waere reine Haerte. Die Serversignatur ersetzt das Fenster und ist damit das
  einzige Gate - deshalb steht die Pruefung vor jedem Schreiben, und ein
  Pester-Vertrag pinnt diese Reihenfolge.
- Zwei Wege an die Datei: Abruf beim Programmstart (nur im Servermodus, nur mit
  eingetragener `AuthorityShutdownUrl` - heute also nie) und "Abschaltdatei
  einlesen" ueber einen Dateidialog. Der Abruf wendet nichts an, er legt die
  geprüfte Datei nur ab; angewendet wird sie auf Nutzeraktion.
- Die abgelegte Kopie wird bei jeder Benutzung neu geprueft. Eine selbst
  dorthin gelegte Datei bewirkt nichts, und ohne eingebetteten
  `AuthorityServerPublicKey` gilt gar keine - fail-closed wie bei jeder
  Freigabe.
- Neuer Betreiberbefehl `--create-shutdown-file <pfad>`. Er erzeugt nichts auf
  Vorrat: eine signierte Abschaltdatei in der Schublade waere ein
  Generalschluessel, der abhandenkommen kann.
- Der Ende-zu-Ende-Lauf faehrt den Weg jetzt komplett: Datei erzeugen,
  veraenderte Datei abgelehnt, echte Datei ohne Frist und ohne Freigabe
  angenommen. Kein Schemawechsel, keine Aenderung an der Schutzwirkung.

## Version 0.62.54

- **Die Gate-Meldung nennt im Servermodus nicht mehr die falsche Frist.** Bis
  hierher lautete jede abgelehnte Lockerung "Starte dafuer unter Einstellungen
  die Frist: sieben Tage spaeter kannst du einen Tag lang lockern" - auch im
  Servermodus, wo die lokale Sieben-Tage-Frist gar nichts oeffnet. Der Text
  schickte den Nutzer auf einen Weg, den es dort nicht gibt. Jetzt nennt er die
  72 Stunden und das Abrufen der Freigabe.
- `ProtectionWeakeningGateMessage` bekommt den Modus als zweiten Parameter,
  bewusst ohne Vorgabewert: beide Aufrufer haben die Konfiguration ohnehin in
  der Hand, und eine stille Vorgabe waere genau der Fehler, der hier gerade
  behoben wird.
- **Gefunden im Ende-zu-Ende-Lauf, nicht in der Suite.**
  `tools/Test-AuthorityEndToEnd.ps1` prueft jetzt auch den Rueckweg gegen einen
  echten Server: Rueckwechsel ohne Freigabe abgelehnt, mit Freigabe erfolgreich, danach
  erneutes Einloesen mit dem behaltenen Zaehler - und als Gegenprobe, dass ein
  auf 0 zurueckgesetzter Zaehler abgewiesen wird. Genau diese Gegenprobe
  begruendet, warum `PolicyVersion` beim Rueckwechsel stehen bleibt.
- Kein Schemawechsel, keine Aenderung an der Schutzwirkung.

## Version 0.62.53

- **Der Weg zurueck in den lokalen Modus existiert jetzt auch als Aktion.**
  `AuthorityMode` wurde bisher nur an einer einzigen Stelle auf `server`
  gesetzt - beim Einloesen eines Freischaltcodes - und nirgends zurueck. Wer
  freischaltete, sass dauerhaft im Servermodus fest, obwohl die Spezifikation
  den Rueckweg ausdruecklich zusagt (Abschnitt 6 in
  `docs/superpowers/specs/2026-07-28-serverautoritaet-design.md`).
- Der Mechanismus war vollstaendig da: `IsProtectionWeakening` behandelt
  `server` nach `local` bereits als Abschwaechung. Es fehlte allein die
  Aktion, die den Wechsel ausloest.
- Neu sind `Support.ApplyLocalAuthority` und `Support.LeaveServerAuthority`.
  Der Wechsel laeuft ueber `UpdateConfigWithWeakeningGate`, also durch
  dasselbe Fenster wie jede andere Lockerung - im Servermodus oeffnet das nur
  eine gueltige Serverfreigabe. Ohne sie wird er mit der ueblichen Meldung
  abgelehnt; ein Ausstieg ohne Frist entsteht dadurch nicht.
- **`PolicyVersion` bleibt beim Wechsel stehen.** Auf 0 zurueckgesetzt meldete
  dasselbe Geraet beim naechsten Einloesen einen zurueckgespielten Zaehler und
  der Server wiese es mit `policy rollback detected` ab.
- **`WeakeningRequestedUtc` wird geleert.** Eine Frist aus der Zeit vor dem
  Freischalten haette im lokalen Modus sonst sofort wieder ein Fenster offen.
- In der Oberflaeche ist aus "Geraet freischalten" die Zeile "Servermodus"
  geworden: ein Knopf, dessen Beschriftung dem Modus folgt
  (`Freischalten` / `Servermodus verlassen`). Das Verlassen fragt Passwort und
  Bestaetigung ab. Kein Schemawechsel, keine Aenderung an der Schutzwirkung.

## Version 0.62.52

Drei Beobachtungen aus den Protokollen des 0.62.50-Live-Tests. Zwei behoben,
eine eingeordnet. Keine Aenderung an der Schutzwirkung.

- **hosts-Schreibversuch wiederholt sich.** `Set-AsciiTextFile` schrieb genau
  einmal. Hatte ein Fremdprozess die Datei kurz offen - Virenscanner,
  DNS-Client, ein Editor -, scheiterte der gesamte Durchsetzungslauf mit
  Exit 1. Jetzt fuenf Versuche mit steigender Wartezeit; die Sperre ist fast
  immer nach Millisekunden weg.
- **Browser-Sperrlisten werden aktualisiert statt neu angelegt.**
  `Set-PolicyStringList` loeschte den Registrierungsschluessel und legte ihn
  neu an. Haelt ein anderer Prozess noch ein Handle darauf, steht der
  Schluessel danach als "pending deletion" da: das Anlegen meldet Erfolg, das
  Schreiben der Werte scheitert mit "Pfad nicht gefunden". Genau das stand im
  Protokoll fuer Edge und Firefox, waehrend die Liste kurz darauf trotzdem
  gefuellt war. Jetzt wird der Schluessel angelegt falls noetig, die Werte
  werden ueberschrieben und ueberzaehlige Nummern eines laengeren
  Vorgaengerstands entfernt. Nebeneffekt: Fremdwerte im selben Schluessel
  ueberleben, passend zur ohnehin besitzstandswahrenden Logik.
- **AccessViolationException im Durchsetzungshelfer: kein Fehler im
  Purestate-Code.** Beide Stapel zeigen die PowerShell-Engine selbst - das
  Erzeugen von CDXML-Modulen beim Autoladen und das Setzen automatischer
  Variablen. Auswirkung: ein ausgelassener Reparaturlauf. Bereits gesetzte
  Durchsetzung bleibt im System stehen, und der naechste Tick laeuft normal.
  Nicht behoben, weil ausserhalb des eigenen Codes.

## Version 0.62.51

- **Der Watchdog haelt sich waehrend einer Installation zurueck.** Aus dem
  Live-Test von 0.62.50: `security.log` enthielt zweimal
  `Config integrity check failed ... Forcing full protection` waehrend des
  Installationslaufs.
- Ursache: der Watchdog laeuft als eigene geplante Aufgabe und ruft
  `Get-Config`. Feuert er mitten im Datei-Kopieren, liest noch altes
  `Common.ps1` eine bereits auf das neue Schema migrierte Konfiguration - und
  meldet voellig korrekt einen Integritaetsfehler.
- **Es war nie ein Schaden**, sondern ein Fehlalarm: `Save-Config` und
  `SaveConfigUnlocked` verweigern beide das Zurueckschreiben einer als
  veraendert erkannten Konfiguration, in keiner Sprache konnte sie neu signiert
  werden.
- Der Schaden war diagnostisch: die Upgrade-Prueflisten nennen genau diese
  Meldung als Bestehenskriterium. Bei zwei Fehlalarmen pro Update haette sich
  ein echter Manipulationsversuch darin versteckt.
- Umsetzung: der Installer legt fuer die Dauer des Laufs
  `install-in-progress.txt` im geschuetzten Datenverzeichnis an und raeumt ihn
  im `finally` wieder weg. Der Watchdog beendet sich, solange der Marker frisch
  ist.
- **Ein abgebrochener Installer legt den Watchdog nicht lahm:** der Marker
  laeuft nach 15 Minuten ab und wird danach ignoriert, ebenso ein unlesbarer
  oder in der Zukunft liegender. Im Zweifel arbeitet der Watchdog weiter.
- Kein Schemawechsel, keine Aenderung an der Schutzwirkung.

## Version 0.62.50

- **Uebergangsfrist fuer den Companion.** Nach einem App-Update bleibt die
  unmittelbare Vorgaengerversion des Companions 14 Tage lang gueltig.
- Grund: die Pruefung verlangte bisher exakte Versionsgleichheit zwischen App
  und Companion. Der Chrome Web Store liefert die passende Version aber erst
  nach seiner Pruefung aus, und bis dahin fiel die Erkennung fail-closed - alle
  gemischten Seiten waren voll gesperrt statt gefiltert. Damit sperrte jedes
  App-Update den Browser fuer Tage. Auf dem Maintainer-Rechner war das seit
  mehreren Versionen der Dauerzustand.
- Es gilt ausschliesslich die Vorgaengerversion. Ein zweites Update innerhalb
  der Frist ersetzt sie, statt sie zu verlaengern; eine Kette schneller Updates
  haelt also keine beliebig alte Version gueltig.
- Neues signiertes Feld `CompanionGrace` (`version|bisUtc`); das
  Integritaetsschema steigt von 11 auf 12. Gueltige Signaturen der Schemata 1
  bis 11 und das unversionierte 0.62.18-Format migrieren weiter; eine unter
  aelterer Signatur untergeschobene Frist faellt fail-closed durch.
- Gemessen wird mit der manipulationsfesten Uhr aus Phase 1. Eine vorgestellte
  Systemuhr verlaengert die Frist nicht, ein eingefrorener Anker verkuerzt sie
  hoechstens - beides fail-closed.
- **Bewusste Abschwaechung:** waehrend dieser 14 Tage laeuft ein Companion, der
  nicht zur App gehoert. Fehlen ihm neue Site-Module, wirken sie in dieser Zeit
  nicht. Das ist der Preis dafuer, dass der Browser nach einem Update
  ueberhaupt benutzbar bleibt.
- Die Regel, dass **jedes** Chrome-Profil **jedes** Windows-Kontos den
  Companion tragen muss, bleibt unveraendert. Ein zweites Konto mit
  ungeschuetztem Chrome waere sonst die einfachste Umgehung.

- **Der Dev-Modus schaltet das Abschwaechungs-Gate nicht mehr ab.** Bisher
  reichte die blosse Anwesenheit von `dev-companion-id.txt` im
  Installationsordner, um jede Abschwaechung ohne Frist und ohne Fenster
  durchzulassen: alle Speicherpfade der Oberflaeche reichten
  `Support.IsDevModeActive()` an das Gate durch. Damit hebelte eine Datei in
  `Program Files` den gesamten Schutz aus - fuer einen Angreifer mit
  Administratorrechten, und genau der ist der im Bedrohungsmodell gewaehlte
  Angreifer.
- Die Oberflaeche uebergibt jetzt ueberall fest `false`. `IsDevModeActive()`
  ist damit ohne Aufrufer und entfernt; `GetDevCompanionId()` bleibt und macht
  nur noch das, wofuer der Dev-Modus da ist - einen entpackten Companion
  zulassen.
- Nebeneffekt fuer die Entwicklung: der Companion laesst sich jetzt testen,
  waehrend das Gate echt bleibt. Vorher war beides gekoppelt, und wer den
  Companion entwickelte, pruefte das Gate versehentlich nie.
- Ersatz fuer den legitimen Zweck des alten Schalters:
  `tools\Set-DevWeakeningRequest.ps1` datiert die Frist auf einer
  Wegwerf-Installation zurueck und signiert die Konfiguration neu. `tools\`
  wird nicht mitgepackt, und jeder Lauf schreibt nach `security.log`.

## Version 0.62.49

- Vorbereitung fuer die Serverautoritaet, Phase 5 der C-min-Richtung
  (`docs/superpowers/specs/2026-07-28-serverautoritaet-design.md`). Ein Geraet
  kann mit einem Freischaltcode an den Purestate-Server gebunden werden. Im
  Servermodus misst der Client die Frist nicht mehr selbst: das Fenster oeffnet
  ausschliesslich eine vom Server signierte Freigabe nach 72 Stunden.
- Neuer Server unter `server/` (.NET 10, SQLite). Er haelt den Signierschluessel,
  misst die Frist mit einer Uhr, die der Nutzer nicht stellt, fuehrt einen
  monotonen Policy-Zaehler gegen zurueckgespielte Konfigurationen und bindet die
  Frist an ein Geraet. Er speichert keine Schutzbereiche, Domains oder
  Nutzungszeiten.
- Ist der Server nicht erreichbar, laeuft der Schutz unveraendert weiter,
  unbegrenzt lange. Es gibt dann keine Abschwaechung und keinen Rueckfall auf
  lokale Autoritaet - sonst waere das Blockieren des Servers die schnellste
  Umgehung ueberhaupt. Eine bereits erteilte Freigabe wird offline gegen den
  eingebetteten Serverschluessel geprueft und bleibt ohne Netz gueltig.
- Ein abgelaufener Anspruch schaltet NICHT in den lokalen Modus zurueck, und der
  Server erteilt trotzdem Freigaben. Schutz faellt bei Nichtzahlung nie weg;
  was endet, sind Neuerungen und Regelpflege. Der Wechsel zurueck auf lokale
  Autoritaet ist selbst eine Abschwaechung und braucht dieselbe Wartezeit.
- Der private Geraeteschluessel wird lokal erzeugt, liegt als eigene Datei
  `device.key` im geschuetzten Datenverzeichnis und verlaesst das Geraet nie.
- Fuenf neue signierte Felder (`AuthorityMode`, `PolicyVersion`,
  `WeakeningGrant`, `GrantSignature`, `EntitledUntilUtc`); das
  Integritaetsschema steigt von 10 auf 11. Gueltige Signaturen der Schemata 1
  bis 10 und das unversionierte 0.62.18-Format migrieren weiter; ein unter
  aelterer Signatur untergeschobenes Autoritaetsfeld faellt fail-closed durch.
- Der Guard bekommt keinen Netzwerkcode. Saemtliche Serveraufrufe passieren in
  der App, auf Nutzeraktion; die Durchsetzung bleibt vollstaendig offline. Ein
  Quelltext-Vertrag pinnt das fuer alle vier Guard-Dateien.
- **Noch nicht nutzbar:** es laeuft kein Server, und der eingebettete
  oeffentliche Serverschluessel ist leer. Solange das so ist, ist der
  Servermodus fail-closed - ohne Schluessel gibt es keine Abschwaechung, nicht
  etwa jede. Nichts davon wurde auf einer echten Installation geprueft.

## Version 0.62.48

- Abschwaechungen laufen nicht mehr ueber das Monatsfenster, sondern ueber eine
  selbst gestartete Frist: sieben Tage Vorlauf, danach steht 24 Stunden lang
  ein Fenster offen, in dem beliebig viele Einstellungen gelockert werden
  koennen. Verstaerken bleibt jederzeit sofort moeglich.
- Grund fuer den Wechsel: das Monatsfenster erzwang im schlechtesten Fall
  30 Tage Wartezeit und liess gleichzeitig jeden ohne jede Wartezeit durch, der
  zufaellig am 1. in die App sah - die Bremse versagte genau dort, wo sie am
  billigsten zu umgehen war.
- Neuer Abschnitt "Einstellungen lockern" in den Einstellungen: zeigt den
  Zustand der Frist an und startet oder bricht sie ab. Eine bereits laufende
  Frist wird durch einen zweiten Klick nicht zurueckgesetzt.
- Neues signiertes Feld `WeakeningRequestedUtc`; das Integritaetsschema steigt
  von 9 auf 10. Gueltige Signaturen der Schemata 1 bis 9 und das
  unversionierte 0.62.18-Format migrieren weiter; ein unter aelterer Signatur
  injizierter Fristbeginn faellt fail-closed aus.
- Die Frist wird ueber die vertrauenswuerdige Uhr aus 0.62.47 gemessen:
  Vorstellen der Systemuhr bei laufendem Dienst verkuerzt sie nicht.
- Ehrliche Grenze, im Threat Model dokumentiert: ein Administrator kann die
  Frist weiterhin vorziehen, indem er die Konfiguration mit dem lokal
  liegenden `integrity.key` neu signiert.
- Keine Aenderung an Companion, Dienstverhalten, Deinstallationsfrist oder
  Datenschutzgrenzen.

### In der Live-Pruefung gefundene Fehler (alle in 0.62.48 behoben)

- **Uhr-Anker war nach dem ersten Schreiben eingefroren.** `Update-ClockAnchor`
  und `Get-TrustedLocalNow` kombinierten `RoundtripKind` mit
  `AdjustToUniversal`; .NET lehnt das ab, und das umschliessende try/catch
  verschluckte die Ausnahme. Der Anker wurde genau einmal geschrieben. Folge:
  alle Wartefristen standen still, Sperrzeiten und Tagesbudgets sprangen nie
  um, und die Sieben-Tage-Frist haette sich nie geoeffnet.
- **Die staerkste Gluecksspiel-Einstellung war unerreichbar.** Der Wechsel von
  "Zeitlimit" auf "komplette Sperre" schaltet das Companion-Tageslimit ab, weil
  es unter der Sperre nicht mehr greift. Der Feldvergleich meldete das als
  Abschwaechung und lehnte die Verstaerkung ab.
- **Die Deinstallation liess das erzwungene Family-DNS zurueck.**
  `Disable-Protection` rief seine Schritte ohne Fehlerisolierung auf; ein
  Fehlschlag in den Browserrichtlinien brach vor der DNS-Rueckgabe ab. Jeder
  Schritt laeuft jetzt gekapselt, Fehlschlaege landen im Protokoll.
- **Die Deinstallation liess einen leeren Hosts-Markerblock zurueck**, der auf
  eine nicht mehr vorhandene App verwies. Das Entfernen raeumt jetzt ein
  zweites Mal auf, nachdem Dienst und Watchdog weg sind.
- Die Meldung des Abschwaechungs-Gates nennt jetzt die ausloesende Einstellung
  statt nur "diese Aenderung wuerde den Schutz abschwaechen".

## Version 0.62.47

- Lokales Uhr-Hardening: Alle Gates, Cooldowns, Sperrzeiten und Tagesbudgets
  lesen jetzt eine manipulationsfeste Uhr statt der Systemuhr. Das Zurueckstellen
  der Systemuhr ist damit wirkungslos, und ein Vorwaertssprung wird bei
  laufendem Dienst nur mit der monoton gemessenen Dauer als Wartezeit
  gutgeschrieben.
- Neues signiertes Feld `ClockAnchorUtc` plus `ClockTickAnchorMs`; das
  Integritaetsschema steigt von 8 auf 9. Gueltige Signaturen der Schemata 1 bis 8
  und das unversionierte 0.62.18-Format migrieren weiter; ein unter aelterer
  Signatur injizierter Uhr-Schluessel faellt fail-closed aus.
- Der Anker wird im PowerShell-Durchsetzungspfad (`Enable-Protection`) auf jedem
  30-Sekunden-Tick fortgeschrieben. Der C#-Guard liest ihn nur, weil seine
  Dateien standalone ohne `NativeSupport*.cs` kompiliert werden. Monotone
  Zeitquelle ist `GetTickCount64`, weil Stopwatch und
  QueryUnbiasedInterruptTime Schlaf- und Ruhezustand nicht mitzaehlen und jedes
  Aufwachen sonst als Uhrsprung gaelte.
- Ein erkannter Vorwaertssprung wird im `security.log` vermerkt.
- Der Deinstallationspfad liest bewusst `max(Systemuhr, Anker)` und kann nie
  einfrieren: ein gestoppter Dienst darf das Entfernen nicht dauerhaft
  verhindern.
- Ehrliche Grenze, im Threat Model dokumentiert: ein Vorwaertssprung bei
  gestopptem Dienst bleibt ununterscheidbar von einem regulaeren
  Herunterfahren und wird nicht erkannt.
- Keine Aenderung an Schutzlogik, Companion, Dienstverhalten oder
  Datenschutzgrenzen.

## Version 0.62.46

- UI-Feinschliff auf Nutzerfeedback zu 0.62.45: Symbole nur noch in der
  Navigation und in Statusmeldungen (Bereichs- und Zeilen-Symbole entfernt),
  dunkle native Scrollbalken ueber SetWindowTheme, Hover-Farben werden beim
  Theme-Wechsel neu berechnet (weisser Hover-Bug behoben), Checkboxen/Radios
  im Dunkelmodus flach gerendert.
- Eigene themed Bestaetigungs- und Infodialoge ersetzen die hellen
  System-MessageBoxen in der Admin-UI (Installer/Uninstaller unveraendert).
- Eingabefelder modernisiert: Uhrzeiten als Auswahllisten in halben Stunden,
  Minuten-Limits als Stufenlisten, Stueckzahlen/Budget als Minus/Plus-Stepper;
  NumericUpDown und Freitext-Zeitfelder entfernt. Gespeicherte Werte und
  guarded Setter unveraendert.
- Aktionszeilen tragen spezifische Verben (Aendern, Verwalten, Pruefen, ...);
  die doppelte Einstellungszeile "Geschuetzte Webseiten waehlen" entfaellt.
  Einstellungsdialoge gruppieren Abschnitte als Karten.
- Reine UI-Aenderung: Schutzlogik, Passwort-, Cooldown- und Fail-closed-Pfade
  bleiben unveraendert. Kein Live-Installationstest.

## Version 0.62.45

- Visuelle Ueberarbeitung im Stil „Calm Windows Security“: textgestuetzte
  GDI-Symbole in Navigation, Status und Schutzbereichen; klarere Hierarchie,
  einheitliche Aktionszeilen sowie stripe-freie Status- und Auswahlflaechen.
- DialogShell auf 640 px Inhaltsbreite und maximal 740 px Fensterbreite
  erweitert. Alle Text-, Auswahl-, Zahlen- und Listenfelder erhalten zentrale
  Hell-/Dunkel-/Hochkontrast-Stile. Erwachsenen-Seiten erscheinen zweispaltig;
  die Spieleliste hat einen erklaerenden Leerzustand.
- Interaktive Rahmen sind von dekorativen Trennlinien getrennt und kontrastiver.
  `docs/UI-DESIGN.md` wird im Windows-Paket mit Manifestpruefung ausgeliefert.
- Reine UI-Aenderung: Schutzlogik, guarded Setter, Passwort-, Cooldown- und
  Fail-closed-Pfade bleiben unveraendert. Kein Live-Installationstest.

## Version 0.62.44

- Zusammenfuehrung der UI-Ueberarbeitung (0.62.43) mit den zuvor separat
  entwickelten Staenden 0.62.42 (Fenster-/Tray-Symbol, Monatsfenster-Sperre
  fuer schutzabschwaechende Aenderungen) und 0.62.41 (Selector-Canary
  fail-closed). Die neuen Schutzbereichs-Dialoge speichern jetzt ueber die
  guarded Setter (SetGamblingSettingsGuarded, SetShoppingSettingsGuarded,
  SetSocialMediaSettingsGuarded, SetVideoGamesSettingsGuarded,
  SetFeatureSettingsGuarded, SetSiteProtectionSettingsGuarded sowie
  ThrowIfVideoGameTargetsWeakeningNotAllowed), sodass die Monatsfenster-Sperre
  auch nach dem UI-Umbau greift. Schutzlogik unveraendert.

## Version 0.62.43

- Vollstaendige Ueberarbeitung der Windows-Oberflaeche (nur UI, keine
  Schutzlogik-Aenderung). Neue Navigation mit vier Bereichen: Start,
  Schutzbereiche, Einstellungen, Mehr. Die Startseite zeigt den Status in
  Alltagssprache ("Purestate schuetzt dieses Geraet", "Ein Teil des
  Schutzes funktioniert nicht") mit genau einer Hauptaktion; technische
  Werte bleiben ueber "Technische Details anzeigen" erreichbar.
- Schutzbereichs-Dialoge neu aufgebaut (DialogShell: Titel, Erklaersatz,
  scrollbarer Inhalt, feste Aktionsleiste): Gluecksspiel als klare
  Auswahl Aus/Zeitlimit/Vollsperre; Shopping gruppiert in Kaufpause/
  Zeiten/Kaeufe; Social Media als eine Zeile pro Plattform mit
  Auswahlliste statt der 8x3-Checkbox-Matrix; Videospiele in Abschnitte
  Schutz/Zeitregeln/Geschuetzte Spiele/Automatische Erkennung mit
  Namens- und Pfadspalte. Eingabefelder erscheinen nur, wenn die
  zugehoerige Option aktiv ist.
- Passwortablauf vereinfacht, ohne Schutzabschwaechung: Dialoge oeffnen
  zum Lesen ohne Passwort; jedes Speichern (und jede direkte Aktion wie
  Pausieren, Listenaenderung, Backup) verlangt weiterhin das Passwort.
- Erfolgs-MessageBoxen ersetzt durch ruhige Inline-Bestaetigung auf der
  Statuskarte; ungespeicherte Aenderungen werden beim Schliessen erkannt;
  Eingabefehler erscheinen direkt am Feld.
- Sichtbare Texte durchgaengig mit echten Umlauten und einheitlichen
  Begriffen (Erlaubte/Gesperrte Webseiten, Browser-Schutz, Zeitlimit,
  Sperrzeit). Buttons beschreiben die Aktion ("Backup erstellen",
  "Spiel hinzufuegen"); abgeschnittene Buttons ("Abbreche") behoben.
- Hauptfenster vergroesserbar (Minimum 900x640), Seiten und Dialoge
  scrollbar und DPI-fest (max. 85% der Arbeitsflaeche), Fonts auf
  mindestens 10pt angehoben, Windows-Hochkontrast nutzt Systemfarben,
  Status nie nur ueber Farbe (Formen-Glyphen), Farbanimation entfernt.
- UI-Code in src/UI/ aufgeteilt (Theme, DialogShell, Pages, Dialogs);
  Designsystem dokumentiert in docs/UI-DESIGN.md.
- Erwartete Artefakte: `Purestate-Windows-v0.62.44.zip`,
  `Purestate-Companion-WebStore-v0.62.44.zip`,
  `Purestate-Handoff-v0.62.44.zip`.

## Version 0.62.42

- Purestate.exe zeigt jetzt ein eigenes Fenster- und Tray-Symbol. Beim
  Windows-Login startet ein sichtbarer Tray-Prozess und meldet kurz, ob
  Purestate aktiv ist; der eigentliche Schutz bleibt Aufgabe des
  Windows-Dienstes und Watchdogs.
- Passwortgeschuetzte Einstellungen, die den Schutz abschwaechen, werden
  nur am 1. Kalendertag eines Monats gespeichert. Staerkende Aenderungen
  (niedrigere Tagesbudgets, zusaetzliche Sperren) bleiben sofort moeglich.
  Im Dev-Modus ist diese Monatsfenster-Sperre aus.

## Version 0.62.41

- Selector-Canary-Misses fuer Pixiv, DeviantArt, Instagram, Imgur,
  Newgrounds und Tumblr sind nicht mehr nur Diagnose: Nach wiederholtem
  Miss sperrt Purestate die betroffene Mixed-Site temporaer per
  Browser-URLBlocklist fail-closed. Die Sperre ist pro Site, laeuft nach
  24 Stunden ohne neuen Miss aus und respektiert deaktivierte
  Webseiten-Schutz-Schalter. Es werden nur maschinenlesbare Site-/Check-
  Tokens gespeichert, keine Seiteninhalte oder URLs.

## Version 0.62.40

- Ehrliches Modusmodell fuer die Reibungs-Bereiche Shopping und Social
  Media: nirgendwo im Produkt erzwingt fuer sie ein "strenger" Modus mehr
  als der sanfte - deshalb ist ihre Modus-Domaene jetzt offiziell
  aus/geplant/sanft. Ein historisch gespeichertes "streng" wird beim
  naechsten Speichern auf "sanft" migriert und in der Bereichsuebersicht
  sofort als "sanft" angezeigt; der Manipulations-Schutzpfad
  (ForceSafeProtection/Set-SafeProtection) setzt die beiden Bereiche auf
  "sanft" bei weiterhin vollstaendig erzwungenen Einzel-Funktionen.
  Der Schutzumfang aendert sich dadurch nicht.
- Wichtig fuer Bestandsinstallationen: Beim LADEN wird nie umgeschrieben -
  signierte Alt-Konfigurationen mit "streng" verifizieren unveraendert
  (kein falscher Manipulationsalarm); erst der naechste legitime
  Speichervorgang klemmt und signiert neu.
- Der Bereichstext im sanften Modus ist praeziser: "Reibung und lokale
  Limits; harte Sperren nur fuer selbst gewaehlte Plattformen und
  Domains" - denn Plattform-Vollsperren und eigene Domain-Eintraege
  greifen auch im sanften Modus hart.

## Version 0.62.39

- Die Companion-Soft-Features fuer Gluecksspiel (Tageszeit-Overlay) und
  Shopping (Checkout-Verzoegerung, Sperrzeit, Bestell-/Budgetlimits,
  Reiz-Daempfung) laufen nicht mehr nur auf der festen Manifest-Liste:
  Der Companion laeuft jetzt mit breiter Host-Berechtigung auf allen
  Seiten und entscheidet pro Hostname. Der Native Host liefert dafuer
  dieselben Domainlisten, die auch die Richtlinien-Schicht nutzt
  (gambling-domains.txt, offshore-gambling-domains.txt,
  custom-gambling-domains.txt, custom-shopping-domains.txt) - eine in
  der App ergaenzte Domain wirkt sofort in hosts/DNS/URLBlocklist UND
  im Companion.
- Ohne Rule Pack bleibt exakt das bisherige Verhalten (feste
  Kern-Domains); auf allen anderen Seiten bleiben die Module inert.
  Der Background validiert jede gelieferte Domain streng (Form,
  Dedup, Obergrenze).
- Ehrliche Grenzen: Die Erweiterung zeigt im Store/Browser jetzt die
  Berechtigung "Zugriff auf alle Websites" (noetig fuer die dynamische
  Abdeckung; es werden weiterhin keine Seiteninhalte erfasst oder
  uebertragen). Eine Domain, die in keiner Liste steht, bleibt
  unbehandelt (Blacklist-Prinzip). Dynamische Shops nutzen nur die
  generische Checkout-Erkennung. Wirkt erst nach dem naechsten
  Web-Store-Update der Erweiterung.

## Version 0.62.38

- Neuer selektiver Social-Media-Modus "Nur Feed": pro Plattform lassen
  sich benannte Ablenkungsflaechen sperren, waehrend der Rest der
  Plattform (DMs, Suche, Abos) nutzbar bleibt. Gesperrte Routen:
  Instagram /reels und /explore, YouTube /shorts, X /explore, Reddit
  /r/popular und /r/all, Tumblr /explore. Der Companion zeigt auf diesen
  Routen ein Voll-Overlay (SPA-fest, Medien werden pausiert), die
  Browser-Richtlinie sperrt die Routen per URL-Pattern und der
  Schutzdienst nimmt sie in die Fail-closed-Filter auf.
- Vollsperre und Feed-Sperre schliessen sich aus; die Vollsperre gewinnt
  beim Speichern. Der neue Konfigurationsschluessel ist signiert
  (Integritaetsschema 8); bestehende Schema-7-Konfigurationen
  (0.62.32-0.62.37) migrieren beim naechsten Speichern, ein von aussen
  injizierter Feed-Schluessel gilt als manipuliert.
- Ehrliche Grenzen: TikTok, Pinterest und Bluesky bieten keinen
  selektiven Modus (ganze Plattform ist Feed bzw. Routen instabil) -
  dort gibt es weiterhin nur die Vollsperre. Ein Redesign einer Route
  hebt die Sperre still auf (kein Routen-Canary); die
  Companion-Aenderung wirkt erst mit dem naechsten Web-Store-Update.

## Version 0.62.37

- SafeSearch wird ueber Google hinaus erzwungen: Die Browser-Richtlinie
  setzt YouTube in den moderaten eingeschraenkten Modus
  (ForceYouTubeRestrict=1, vorher explizit aus) und erzwingt in Edge
  striktes Bing-SafeSearch (ForceBingSafeSearch=2; Chrome kennt diese
  Richtlinie nicht). Der Status-Check erwartet die neuen Werte.
- Der Companion erzwingt auf Ergebnisseiten die dokumentierten
  Safe-Parameter direkt in der Such-URL, solange der Adult-Bereich aktiv
  ist: Bing adlt=strict (Web-/Bilder-/Videosuche), DuckDuckGo kp=1,
  Yandex family=yes. Bereits sichere URLs werden nie umgeschrieben
  (schleifensicher); der bestehende Begriff-Block bleibt unveraendert
  aktiv.
- Ehrliche Grenzen: Ecosia und Startpage haben keine verlaesslich
  dokumentierten Safe-Parameter und bleiben beim Begriff-Block; Firefox
  bietet keine SafeSearch-Richtlinien; die Companion-Aenderung wirkt erst
  mit dem naechsten Web-Store-Update der Erweiterung.

## Version 0.62.36

- Im strengen Videospiel-Modus sperrt Purestate jetzt auch Cloud-Gaming
  und Browser-Spiele im Web: eine neue Domainliste
  (rules/gaming-domains.txt) mit Cloud-Diensten (GeForce Now, Boosteroid,
  Amazon Luna, Blacknut, Antstream, Utomik, airgpu, Shadow) und grossen
  Browser-Spiele-Portalen (Poki, CrazyGames, Miniclip, Y8, Kongregate,
  Armor Games, Addicting Games) greift in der hosts-/DNS-Schicht, in der
  Chromium-URLBlocklist, im Firefox-WebsiteFilter und im
  Fail-closed-Filter des Schutzdienstes.
- Xbox Cloud Gaming wird nur ueber die Route xbox.com/play in der
  Browser-Richtlinien-Schicht gesperrt; xbox.com selbst (Store, Konto,
  Game-Pass-Verwaltung) bleibt nutzbar. Ehrliche Grenzen: Die
  hosts-/DNS-Schicht kann keine Pfade sperren (die xCloud-Sperre haengt
  an der Browser-Richtlinie), itch.io wird bewusst nicht gesperrt
  (Indie-Store und Kreativplattform), und der sanfte Modus misst
  Cloud-/Browser-Spielzeit weiterhin nicht - die Sperre gilt nur im
  strengen Modus.

## Version 0.62.35

- Die automatische Videospiel-Erkennung stuft bekannte GPU-intensive
  Kreativ-, Streaming-, CAD- und Benchmark-Programme (z. B. Blender,
  OBS, Unreal-/Unity-Editor, DaVinci Resolve, AutoCAD, 3DMark) in der
  Heuristik-Schicht nie mehr als Spiel ein. Pfadbasierte Treffer
  bleiben unveraendert: eine Kopie unter einem erkannten
  Store-Spielverzeichnis oder als gelistetes Ziel wird weiter beendet.
- Ein erstmalig per Heuristik als Spiel eingestuftes Programm bekommt
  vor dem Beenden einmalig 5 Minuten Zeit zum Speichern statt 60
  Sekunden - genug, um bei einer Fehleinstufung zu speichern und eine
  "Kein Spiel"-Ausnahme in der App einzutragen. Jeder weitere
  Countdown fuer denselben Pfad bleibt bei 60 Sekunden; ein Umbenennen
  der Spieldatei gewinnt damit hoechstens einmalig etwa 5 Minuten.

## Version 0.62.34

- Die monatlichen Shopping-Zaehler (Bestellungen und geschaetzte Ausgaben)
  sind jetzt ebenfalls guard-persistent: Jede bestaetigte Bestellung wird
  als Ereignis (plus optional selbst geschaetztem Eurobetrag) ueber den
  Native Host an den Schutzdienst gemeldet, der die Monatsstaende in
  derselben geschuetzten Datei usage.json fuehrt wie die Tagesbudgets.
  Der Monat rollt nur vorwaerts (Uhr zurueckstellen schafft keinen
  frischen Monat), Wiederholungs-Tokens verhindern Doppelzaehlung, der
  Betrag ist auf 5 Stellen begrenzt, und ein beschaedigter Zaehler
  faellt offen aus. Der Browserzaehler bleibt lokaler Puffer und wird
  vom Dienst wieder aufgefuellt. Es werden weiterhin nur aggregierte
  Selbstauskuenfte gespeichert - keine Artikel, Shops oder Bankdaten.

## Version 0.62.33

- Persistente, manipulationsgeschuetzte Tageszaehler fuer die Zeitbudgets
  von Social Media (Gesamt- und Plattform-Limits), Shopping und
  Gluecksspiel: Der Verbrauch wurde bisher nur in chrome.storage.local
  gezaehlt und liess sich durch Loeschen der Browserdaten, ein frisches
  Profil, Inkognito, einen zweiten Browser oder Neuinstallation der
  Erweiterung trivial zuruecksetzen. Der Companion meldet jetzt jeden
  Mess-Tick als Delta ueber den Native Host an den Schutzdienst, der den
  autoritativen Tagesstand in der ACL-geschuetzten Datei
  %ProgramData%\Purestate\usage.json fuehrt (Standardnutzer ohne
  Schreibrecht). Durchsetzung nutzt den Dienst-Stand; der Browserzaehler
  ist nur noch lokaler Puffer und wird vom Dienst wieder aufgefuellt.
  Schutzeigenschaften: Tag rollt nur vorwaerts (Uhr zurueckstellen gibt
  kein frisches Budget), Einzelmeldungen auf 120 Sekunden geklemmt,
  Wiederholungs-Tokens verhindern Doppelzaehlung, beschaedigte oder
  fehlende Zaehlerdatei faellt offen aus (nie eine Dauersperre).
  Ehrliche Grenzen: pro PC (kein Geraeteabgleich); ohne erreichbaren
  Dienst greift die bestehende Vollsperre der geschuetzten Seiten.

## Version 0.62.32

- Installation auf frischen Rechnern ohne Chrome/Firefox brach ab ("Ein
  Windows-Hilfsprozess konnte nicht erfolgreich abgeschlossen werden"):
  Registryschluessel wurden ohne -Force angelegt, was fehlschlaegt, wenn ein
  uebergeordneter Schluessel (z. B. Policies\Google) noch nicht existiert.
  Betraf auch die Firefox-Sperrliste WebsiteFilter\Block und war Ursache der
  wiederkehrenden Watchdog-Fehler.
- Manipulationsschutz (fail-closed) erzwingt jetzt auch die Budget-Bereiche
  Shopping, Social Media und Videospiele monoton auf "an/streng" - wie schon
  Gluecksspiel. Eine beschaedigte oder manipulierte Konfiguration kann keinen
  dieser Bereiche mehr entsperren.
- Downgrade-Schutz: Der Installer verweigert das Herabstufen auf eine aeltere
  Purestate-Version. Die installierte Version wird signiert in der
  Konfiguration hinterlegt (Integritaetsschema 7); aeltere Pakete koennen die
  neuere Konfiguration nicht mehr authentifizieren. Ein bewusstes Zurueckstufen
  ist nur nach vorheriger Deinstallation moeglich.

## Version 0.62.31

- Anti-Cheat-Fix: Spiele mit EasyAntiCheat/BattlEye (z. B. Dead by Daylight,
  Fortnite) waren fuer den Videospiel-Schutz unsichtbar, weil deren
  Anti-Cheat fremden Prozess-Handles das Leserecht entzieht -
  Process.MainModule liefert dann leer und der Prozess wurde uebersprungen.
  Der Schutzdienst liest Programmpfade jetzt mit Fallback ueber
  QueryFullProcessImageName (PROCESS_QUERY_LIMITED_INFORMATION, vom
  Anti-Cheat erlaubt); betrifft Store-Erkennung, Heuristik-Countdown und
  eingetragene Ziele. Live gegen Dead by Daylight verifiziert.
- Android-Emulatoren als eigene Erkennungsquelle "emulator": Bekannte
  Emulatoren (BlueStacks, LDPlayer, Nox App Player, MEmu, MuMu, GameLoop,
  Google Play Games) werden ueber ihre Uninstall-Registryeintraege erkannt
  (Verzeichnis aus InstallLocation, sonst DisplayIcon-Pfad - BlueStacks
  traegt keine InstallLocation) und exakt wie Store-Spiele behandelt:
  Sofort-Beendigung in der Vollsperre, Tagesbudget/Sperrzeit, Anzeige in
  der Erkannt-Liste, nie ausnehmbar. Nackte Installationsstaemme (z. B.
  "C:\Program Files") werden nie als Spielverzeichnis uebernommen.
  Bekannte Grenze: rein benutzerbezogene Emulator-Installationen (nur
  HKCU-Eintrag) sieht der Dienst nicht.

## Version 0.62.30

- Automatische Videospiel-Erkennung als zweite Schicht ueber der Zielliste:
  Der Schutzdienst liest zyklisch (alle 10 Minuten, gecacht) die
  Installationsquellen Steam (libraryfolders.vdf + appmanifest), Epic
  (Manifest-Verzeichnis), GOG- und EA-Registry, Battle.net
  (Blizzard-Uninstall-Eintraege) und XboxGames-Ordner aller Laufwerke.
  Prozesse, deren Programmpfad unter einem erkannten Spielverzeichnis
  liegt, zaehlen und sperren exakt wie eingetragene Ziele (gemeinsames
  Tagesbudget, Sperrzeit, Vollsperre). Unsichere Verzeichnisse
  (Windows-/Purestate-Ordner, Laufwerkswurzeln) werden verworfen.
- Verhaltens-Heuristik fuer portable Spiele (optional, nur zusammen mit
  der automatischen Erkennung): Einstufung erst nach mehreren
  aufeinanderfolgenden Pruefintervallen (~2 Minuten) mit gleichzeitig
  anhaltender 3D-GPU-Last (nur 3D-Engine, Videowiedergabe zaehlt nicht)
  und geladener Spiel-Schnittstelle (Direct3D/Vulkan/OpenGL). Browser und
  kritische Prozesse werden nie eingestuft. In Sperrfaellen erhalten
  Heuristik-Treffer eine 60-Sekunden-Speicherwarnung vor dem Beenden;
  Einstufungen ueberleben Neustarts (video-games-detected.json), die App
  zeigt die erkannten Spiele samt Quelle an.
- Nicht-Spiel-Ausnahmen fuer die Heuristik: Anlegen nur mit App-Passwort,
  wirksam erst nach 15 Minuten (rettet keine laufende Spielsitzung),
  Entfernen jederzeit frei. Ausnahmen wirken nie auf eingetragene Ziele
  oder Store-Treffer und liegen in rules\video-game-exemptions.txt;
  Export/Import ueber die neue Backup-Sektion [VideoGameExemptions].
- Zwei neue Einstellungen (automatische Erkennung, Heuristik) sind
  HMAC-kanonisch: Integritaetsschema 6. Bestehende Schema-5-Configs
  (0.62.29) migrieren beim naechsten Speichern; nachtraeglich eingefuegte,
  unsignierte Erkennungs-Schluessel machen die Config auf allen aelteren
  Pfaden ungueltig (fail-closed). Sprachuebergreifendes Schema-6-Oracle in
  beiden Testsuiten gepinnt.
- Bewusste Grenzen unveraendert dokumentiert: Browser- und Cloud-Gaming
  bleiben unerkannt (Companion-Thema), UWP-Spiele nur ueber den
  XboxGames-Ordner, Messgroesse bleibt Prozesslaufzeit. Keine
  Companion-/Extension-/NativeHost-Aenderung.

## Version 0.62.29

- Neuer Schutzbereich Videospiele: passwortgeschuetzter Dialog mit selbst
  ausgewaehlten Windows-Spielzielen (Dateidialog, voller Pfad, Aktiv-Haken,
  Duplikat- und Sicherheitspruefung). Sanfter Modus mit optionalem taeglichem
  Laufzeit-Budget (5-600 Minuten, Standard 60, aus) und Sperrzeit (auch ueber
  Mitternacht); strenger Modus als dauerhafte Vollsperre. Durchsetzung laeuft
  als eigene Komponente (PurestateGuardVideoGames.cs) im Schutzdienst im
  30-Sekunden-Takt, auch bei geschlossener App, mit neutraler Vorwarnung
  (~5 Minuten) per WTSSendMessage und sanftem Beenden vor dem harten Kill.
- Zielerkennung ausschliesslich ueber den vollstaendigen normalisierten
  Programmpfad (gleicher Name an anderem Pfad bleibt unberuehrt). Kritische
  Windows-, Anmelde-, Shell-, Sicherheits- und Purestate-Prozesse sowie
  Programme aus Windows-Systemverzeichnissen werden als Ziel abgelehnt;
  bekannte Spieleplattform-Launcher (Steam, Epic, EA, Ubisoft, Battle.net,
  Riot, GOG) sind nie standardmaessig gesperrt und nur mit ausdruecklicher
  Warnung als breit wirkendes Ziel waehlbar. Ziele liegen in
  rules\video-game-targets.txt und werden beim Laden erneut validiert.
- Ehrliche Messgrenze: gezaehlt wird die Laufzeit gestarteter Spielprozesse
  (Prozess-Sampling, keine Doppelzaehlung mehrerer Prozesse), nicht die
  aktive Vordergrundnutzung. Store-/UWP-Spiele, umbenannte Kopien und
  Browser-/Cloud-Gaming werden nicht erkannt und die UI sagt das klar.
  Tageszaehler liegt atomar in video-games-usage.json (ProgramData), rollt
  nur bei echtem Datumswechsel vorwaerts (Zurueckstellen der Uhr gibt kein
  frisches Budget), klemmt Standby-Luecken ab und uebersteht Dienst- und
  Rechnerneustarts. Keine Spielpfade, -namen oder Nutzungswerte in Logs
  oder Diagnoseberichten (nur Anzahlen und Modus).
- Fuenf neue Einstellungen sind HMAC-kanonisch: Integritaetsschema 5.
  Gueltige Schema-4-Signaturen (0.62.22-0.62.28) und alle aelteren gueltigen
  Schemata werden beim Update akzeptiert und beim naechsten Speichern
  migriert; in alte Signaturen eingeschleuste Videospiel-Schluessel gelten
  als manipuliert und erzwingen den Vollschutz. C#- und
  PowerShell-Kanonisierung sind byte-identisch (neues Schema-5-Oracle in
  beiden Suiten). Backups exportieren die technischen Videospiel-Felder und
  die Zielliste ([VideoGameTargets], beim Import erneut validiert); der
  Tageszaehler bleibt bewusst ausserhalb des Backups.
- Standardmaessig ist der Videospielschutz aus und wird bei bestehenden
  Nutzern nicht automatisch aktiviert. Gesundheitscheck, Diagnose und
  Schutztest zeigen Modus, Zielanzahl und Lesbarkeit; der Guard-Selbsttest
  prueft Zielvalidierung, Sperrzeitfenster, Tageswechsel und Zaehlerklemmung.
  Browser-/Cloud-Gaming und eine Sitzungsbegrenzung mit Pausen sind bewusst
  nicht enthalten (spaetere Erweiterung).
- Regressionen: 197 Pester-, 205 C#- und 95 Node-Tests sowie 23 isolierte
  Browser-Fixtures gruen, darunter neue Live-Durchsetzungstests mit einem
  isolierten kopierten Testprozess (streng, Tagesbudget nach Dienstneustart,
  Sperrzeit, gleichnamiger Prozess an anderem Pfad bleibt unberuehrt);
  Release-Build und Paket-Selbsttests gruen.

## Version 0.62.28

- Assigns a distinct version to the post-hardening live-test build; protection behavior, technical data formats, and the technical-only beta boundary remain unchanged from 0.62.27.

## Version 0.62.27

- Retires the personal journal, check-in, and support-plan UI/model/persistence before beta; the remaining Information and Help view is static and stores no input.
- Exports technical settings and domain lists only, skips the three old personal backup sections without decoding or writing them, and removes only the three exact obsolete local support files after a successful technical config update.
- Corrects read-only diagnostics for numeric Companion policy slots, dynamic protected-site totals, redacted development state, and isolated browser fixtures.

## Version 0.62.21

- Fixes aus der ersten Social-Media-Live-Runde: unter jedem Vollseiten-
  Overlay werden Videos und Audios pausiert und stummgeschaltet (vorher
  spielte z. B. ein YouTube-Video unter der Vollsperre weiter). Der
  Zurueck-Knopf verlaesst die Plattform jetzt zuverlaessig: fuehrt der
  Verlauf nicht hinaus, geht es auf eine neutrale leere Seite statt zurueck
  unter dasselbe Overlay.
- Wird eine Vollsperre oder Sperrzeit per Einstellung aufgehoben, laedt der
  betroffene Tab einmal automatisch neu, statt eingefroren zu wirken.
  Hinweis: Tabs, die bereits auf der Browser-Richtlinien-Fehlerseite
  stehen, muessen weiterhin manuell neu geladen werden.
- Neues dezentes Rest-Zeit-Badge unten rechts (nur bei aktivem Budget oder
  Einzel-Limit): zeigt live die verbleibende Zeit. Der erste Zeit-Tick
  laeuft sofort beim Laden statt erst nach 15 Sekunden, und ein bereits
  erschoepftes Limit deckt die Seite direkt nach dem Laden ab. Die
  Sperrzeit beginnt und endet jetzt auch ohne Einstellungs-Push puenktlich.
- Endlos-Scroll-Bremse komplett ueberarbeitet: statt Pixelhoehen zaehlt sie
  einzelne Scroll-Vorgaenge (auch Swipes/Wheel bei Kurzvideo-Feeds). Nach
  50 Scrolls erscheint ein ruhiger Vollseiten-Stopp mit Bilanz ("Du hast
  gerade 50-mal weitergescrollt - das waren etwa X Minuten."), Vorschlaegen
  fuer die gewonnene Zeit und einem Weiterscrollen-Knopf.
- Regressionen: 153 Pester-, 195 C#- und 84 Node-Tests sowie 23 isolierte
  Browser-Fixtures gruen, darunter der neue Scroll-Stopp-Vollseitencheck.

## Version 0.62.20

- Neuer Schutzbereich Social Media (hybrid, sanft): taegliches Gesamtbudget
  ueber X/Twitter, Instagram, TikTok, Pinterest, Tumblr, Bluesky, Reddit und
  YouTube (Default 60 Minuten, aus), optionale strengere Einzel-Limits pro
  Plattform und eine optionale Vollsperre pro Plattform. Die Vollsperre
  greift doppelt: Companion-Vollseiten-Overlay plus Browser-Richtlinie
  (URLBlocklist/WebsiteFilter) und Guard-Filter.
- Sperrzeit-Fenster wie beim Shopping, eine Reflexionsfrage beim ersten
  Oeffnen einer Plattform am Tag (Zehnerpool, Weiter nach 5 Sekunden) und
  eine Endlos-Scroll-Bremse (sanfter Zwischenstopp nach fuenf
  Bildschirmhoehen, nur Scroll-Beobachtung, kein Eingriff in die Feeds).
- Voller Support-Hub fuer Social Media ueber die generische
  Deskriptor-Struktur (Check-in mit Scroll-Impuls-Skala, Verzoegerung,
  Trigger, Notfallplan, Motivation und Regeln, Hilfequellen; Wortlaut der
  Hilfequellen weiterhin extern fachlich zu pruefen).
- Neun neue Einstellungen sind HMAC-kanonisch: Integritaetsschema 3.
  Gueltige Schema-2- und unversionierte 0.62.18-Signaturen werden beim
  Update akzeptiert und migriert; in aeltere Signaturen eingeschleuste
  Social-Media-Schluessel gelten als manipuliert und erzwingen den
  Vollschutz. Zeit- und Reflexionsstaende liegen ausschliesslich lokal im
  Browser-Profil, nie in config.json, Backups oder Logs.
- Manifest: ein neuer Content-Script-Eintrag auf 44 bereits freigegebenen
  Host-Mustern der acht Plattformen; keine neuen Host-Berechtigungen.
- Regressionen: 153 Pester-, 195 C#- und 82 Node-Tests sowie 22 isolierte
  Browser-Fixtures gruen, darunter vier neue Social-Media-Vollseitenchecks.

## Version 0.62.19

- Update-/Reparaturpfad gehaertet: gueltig signierte 0.62.18-Konfigurationen
  werden akzeptiert und beim naechsten Speichern auf Integritaetsschema 2
  migriert. Manipulierte Schema-Angaben, doppelte Konfigurationsschluessel und
  defektes JSON gelten weiterhin als kompromittiert und erzwingen den
  Vollschutz.
- Ein uebrig gebliebener Ordner unter `C:\Program Files\Purestate` ohne
  config.json erzwingt bei der Neuinstallation nicht mehr den
  Update-Passwortdialog; das Passwortfeld richtet sich jetzt nach einem
  tatsaechlich vorhandenen Passwort in der Konfiguration.
- Der Installer beendet vor dem Dateiaustausch auch den installierten
  PurestateNativeHost.exe, damit keine gesperrte Datei den Austausch blockiert.
- Die zurueckgestellte Deinstallations-Bereinigung versucht das Entfernen von
  Installations- und Datenordner mehrfach, nachdem der erhoehte Uninstaller
  beendet ist, statt nur einmal nach fester Wartezeit.
- Regressionen: 152 Pester-, 174 C#- und 75 Node-Tests sowie 18 isolierte
  Browser-Fixtures gruen; Release-Build mit Selbsttest erfolgreich.

## Version 0.62.18

- Taegliche Companion-Zeitlimits zaehlen nur sichtbare, fokussierte Tabs:
  Shopping standardmaessig 30 Minuten; Gluecksspielseiten 15 Minuten, nur
  solange der strenge Vollschutz aus ist. Zeitstaende liegen lokal je
  Browserprofil/Kalendertag; das Gambling-Script ist auf 42 kuratierte Hosts
  begrenzt und benoetigt keine `tabs`-Berechtigung.
- Shopping erhaelt ein hartes monatliches Bestelllimit (Default 10) und ein
  optionales Euro-Budget. Bestellzaehler und freiwillige ganzzahlige
  Schaetzbetraege liegen ausschliesslich in `chrome.storage.local`, werden
  monatlich bereinigt und nie in config.json, Backups oder Logs uebernommen.
- Der Checkout-Wartescreen zeigt drei verschiedene Fragen aus einem
  Zehnerpool. Nach Erreichen eines Monatslimits fehlt der Kauf-Button; nur
  Zurueck bleibt. Kaufreiz-Daempfung erkennt weitere Befristungs-, Blitzdeal-,
  Knappheits- und Prozent-Spartexte ohne den neutralen Vergleichssatz zu
  treffen.
- Shopping- und Gluecksspiel-Dialoge enthalten passwortgeschuetzte
  Zeit-/Monatslimit-Einstellungen mit normalisierten Grenzen. Rule-Pack,
  Config-HMAC, lesbarer Companion-Spiegel und Backup-Konfiguration tragen die
  neuen Einstellungen; Browser-Zeit-/Zaehlerdaten selbst bleiben ausserhalb
  der Backups.
- Regressionen: 135 Pester-, 171 C#- und 75 Node-Tests sowie 18 isolierte
  Browser-Fixtures, darunter neue Vollseitenchecks fuer Tages- und
  Monatslimit.

## Version 0.62.17

- Kritischer Fix fuer den Rule-Pack-Kanal: config.json ist seit 0.61.47 auf
  Administratoren+SYSTEM beschraenkt, der Native Host laeuft aber unter dem
  normalen Benutzerkonto von Chrome und fiel deshalb still auf Defaults
  zurueck - Shopping-Mechanismen und Bereichs-Schalter kamen nie im Browser
  an (dieselbe Ursache wie der historische 0.62.6-Befund "Rule-Pack-Kanal
  nicht ueberall erreichbar"). Die App und der PowerShell-Pfad spiegeln jetzt
  bei jedem Speichern ausschliesslich die unkritischen Regel-Felder
  (Bereichs-Modi, Shopping-Bremsen, Webseiten-Schalter) nach
  ProgramData\Purestate\public\companion-rule-state.json (Benutzer: nur
  lesen). Der Host liest und ueberwacht diese Datei; die Haertung von
  config.json bleibt unveraendert. Keine Passwoerter, HMAC-Werte, Timer oder
  persoenliche Supportdaten im Spiegel (testgepinnt).
- Zweiter Fix: PowerShell 5.1 uebergibt $null an .NET-String-Parameter als
  leeren String; dadurch scheiterte der atomare Config-Ersetzungspfad
  (File.Replace) immer, wenn die Zieldatei bereits existierte - betraf alle
  PowerShell-seitigen Config-Speicherungen wie Set-SafeProtection.
  Jetzt [NullString]::Value.
- Companion-Konsolenmarker meldet die echte Manifest-Version statt des
  eingebrannten "0.62.13"; Native-Push-Portabbrueche werden als behandelt
  markiert (kein "Unchecked runtime.lastError"-Rauschen mehr).

## Version 0.62.16

- Einstellungen wirken sofort: Der Companion haelt eine dauerhafte
  Native-Messaging-Verbindung ({type:"subscribe"}); der Windows-Host
  ueberwacht config.json und die lokalen Regeldateien und pusht bei jeder
  Speicherung binnen Sekunden ein frisches Rule-Pack. Der Hintergrunddienst
  der Erweiterung verteilt es an alle offenen Tabs; Shopping- und
  Such-Overlays erscheinen/verschwinden ohne Tab-Neuladen. Der bisherige
  Minuten-Heartbeat und der 5-Minuten-Cache bleiben als Rueckfallpfad.
- Keine neuen Berechtigungen, keine Aenderung an Enforcement-Pfaden;
  One-Shot-Heartbeat/Rules/Canary-Verhalten des Hosts unveraendert.

## Version 0.62.15

- Neues Shopping-Modul: Der Schutzbereich "Shopping" oeffnet jetzt ein eigenes,
  passwortgeschuetztes Einstellungsfenster mit sanfter (gentle) lokaler
  Unterstuetzung bei problematischem Kaufverhalten - keine Blockade, keine
  Diagnose, keine Speicherung von Betraegen, Bank- oder Bestelldaten.
- Der bereichsparametrisierte Hilfe-Hub traegt das Shopping-Modul komplett:
  taeglicher Check-in (Kaufimpuls-Staerke), Impuls-Verzoegerung mit
  Shopping-Alternativen, persoenliche Ausloeser, Notfallplan mit
  Storno-/Rueckgabe-Hinweis, ruhige Reflexion nach einem Kauf, Fortschritt
  ohne Streaks und optionale Hilfequellen (Suchtberatung, Schuldnerberatung,
  Telefonseelsorge; fachlich extern zu pruefen).
- Neu fuer alle Bereiche: "Motivation und Regeln" im Hilfe-Hub - eigene
  Gruende und editierbare persoenliche Regeln (Shopping-Vorlagen z. B.
  Wartezeit vor Kaeufen, keine gespeicherten Zahlungsdaten, Wunschliste statt
  Warenkorb), gespeichert in neuen [Motivation]/[Rules]-Sektionen der lokalen
  Supportdatei; Altdateien bleiben unveraendert lesbar.
- Backup: Shopping-Einstellungen wandern in Backups; persoenliche
  Shopping-Supportdaten nur nach ausdruecklichem Opt-in
  ([ShoppingSupportDataBase64]); alte Backups ohne Shopping-Zeilen bleiben
  vollstaendig kompatibel.
- Kein Enforcement-Verhalten geaendert: Shopping bleibt unterhalb von
  "strict" und wird von Windows-/Companion-Schutzpfaden weiterhin nicht
  erzwungen (bestehende Tests pinnen das).
- Shopping-Enforcement (zweite Runde): gentle wird reale Reibung. Fuenf
  konkrete Mechanismen, alle einzeln passwortgeschuetzt schaltbar im
  Shopping-Dialog:
  1. Checkout-Wartezeit: Kassen-Seiten auf 12 Shop-Domains (Amazon, eBay,
     Otto, Zalando, Kleinanzeigen, MediaMarkt, Saturn, Temu, Shein,
     AliExpress, Wish) oeffnen hinter einem ruhigen Overlay mit
     Pflicht-Timer (2/5/10/15 min) und Reflexionsfragen; "Weiter zum Kauf"
     erst nach Ablauf, kein Skip, Reload-/Neustart-fest
     (chrome.storage.local, nur Timestamps).
  2. Kaufreiz-Daempfung: Countdown-Angebote, Knappheits-Hinweise
     ("Nur noch 2"), Deal-Banner werden auf den Shop-Seiten ausgeblendet
     (fail-open, nie Produktlisten).
  3. Deal-Suchblock: Gutschein-/Rabattcode-/Black-Friday-Suchen werden auf
     allen unterstuetzten Suchmaschinen blockiert (Companion-Overlay plus
     kuratierte URLBlocklist-Patterns, wie beim Gluecksspiel-Suchblock).
  4. Shopping-Pause: im konfigurierbaren Zeitfenster (Default 22:00-06:00,
     Mitternachts-Wrap) sind die Shop-Seiten komplett abgedeckt.
  5. Eigene Shop-Sperrliste: "Shoppingseite blockieren" schreibt in
     rules\custom-shopping-domains.txt und wirkt ueber Hosts,
     Chromium-URLBlocklist und Guard-Fail-closed; Backup-Sektion
     [CustomShoppingDomains].
- Sechs neue Shopping-Keys sind HMAC-kanonisch (beide Sprachen); die
  Cross-Language-Oracles wurden neu berechnet und gepinnt. Companion-Manifest
  erhaelt die Shop-Hosts und die storage-Permission (nur lokale
  Wartezeit-Timestamps) - Web-Store-Re-Upload noetig. Rule-Pack traegt den
  Shopping-Bereich generisch (gentle) mit Einstellungen und Suchbegriffen.
- Neue Tests: 3 Browser-Fixtures (Checkout-Overlay, Sperrzeit, Daempfung),
  Node-Tests fuer Termlisten/Curfew-Wrap/Checkout-Matcher/Rule-Pack-Sanitize,
  Pester fuer Suchpatterns/Sperrliste/Kanonform, C#-Checks fuer Config,
  Setter, Domains und Backup.

## Version 0.62.14

Konsolidierter Eintrag fuer die 0.62-Linie (0.62.0-0.62.14 wurden nicht
einzeln veroeffentlicht; die Zwischenschritte sind in README.txt unter
"Wichtig fuer Version 0.62.x" dokumentiert).

- Gleichgewichtige Schutzbereiche: Gluecksspiel ist ein strenger optionaler
  Schutzbereich mit lokalen Domain-/Suchbegriff-/Affiliate-Listen (inkl.
  GGL-gelisteter Anbieter wie bet365.de, tipico.com, Merkur-Domains und
  Offshore-Domains wie playzilla.com), Chromium-URLBlocklist-Sperre,
  Guard-Fail-Closed-Abdeckung und lokaler "Gluecksspielseite blockieren"-
  Aktion (custom-gambling-domains.txt).
- Gluecksspiel-Suchen (z. B. "online casino") werden wie NSFW-Suchen per
  Browser-Richtlinie und Companion-Overlay blockiert; mehrdeutige Begriffe
  (poker, lotto, roulette) bleiben bewusst ausgenommen.
- Reddit-Feed-Fixes: harmlose Beitragsbilder werden nicht mehr durch
  Text-Erwaehnungen von "nsfw" verdeckt, Kommentar-Avatare bleiben sichtbar,
  Zurueck-Button der Blockseite zentriert und SPA-sicher.
- Dev-Companion-Modus: passwortgeschuetzt kann eine entpackte Test-Companion-
  Version die Store-Erzwingung ersetzen; fehlt sie, bleibt der Browser
  fail-closed geschuetzt.
- Schutzbereich-Modusmodell um "gentle" (Sanft) erweitert - Modell-only,
  erzwingt nichts; Vorbereitung fuer Shopping, Videospiele und Social Media.
  Cross-Language-HMAC-Abdeckung inklusive.
- Companion uebernimmt Schutzbereiche generisch aus dem Native-Host-Rule-Pack
  (keine hartkodierte Bereichsliste mehr).
- Hilfe-und-Notfall-Funktionen bereichsparametrisiert (AreaSupportDescriptor);
  Gluecksspiel-Daten, -Texte und -Ablaeufe bleiben unveraendert.

## Version 0.61.51

- Companion-Feinschliff aus einer Live-Test-Runde, keine Kern-Schutzlogik
  entfernt: Auf Reddit sind die Buttons der Block-Seite jetzt zentriert, der
  Zurueck-Button faellt bei einer verschluckten SPA-Navigation auf die
  Startseite zurueck, die schwarze Flaeche unter blockierten Medien ist behoben
  (Platzhalter wird jetzt korrekt auf die Medienhoehe dimensioniert) und ein
  blockierter Beitrag zeigt keinen erklaerenden Zusatztext mehr.
- Die Einstellungs-Schalter fuer Erwachseneninhalte sind jetzt zusaetzlich
  buchstaeblich un-anklickbar (pointer-events-Sperre, zusaetzlich zur bereits
  vorhandenen Rueckstellung): X ("sensible Medien anzeigen"), Imgur ("Nicht
  jugendfreie Inhalte anzeigen") und Reddits "ich bin ueber 18"-Schalter. Fuer
  Bluesky wird der "Inhalte fuer Erwachsene aktivieren"-Schalter auf
  bsky.app/moderation jetzt erstmals aktiv auf Aus erzwungen und gesperrt.
- pixiv: Adult-Suchbegriffe werden jetzt auch im ?q=-Parameter der
  /search-Seite blockiert (vorher nur ?word= und der /tags/-Pfad).

## Version 0.61.50

- Beta-Haertung, keine Schutzlogik im Alltag geaendert: Browser-Richtlinien
  (ExtensionSettings, ExtensionInstallForcelist, URLBlocklist, Firefox
  WebsiteFilter) werden jetzt mit bereits vorhandenen (z. B. Firmen-/Schul-/
  Family-Safety-)Richtlinien zusammengefuehrt statt sie zu ueberschreiben oder
  bei der Deinstallation komplett zu loeschen.
- Fehlgeschlagene Ordner-Absicherung (ACL) bricht Installation/Reparatur jetzt
  sichtbar ab, statt still einen unsicheren Zustand zuzulassen.
- Installation prueft das Paket vor dem Ersetzen und reaktiviert bei einem
  Fehler den vorherigen Schutz; die Deinstallation raeumt Systemaenderungen
  zuerst auf, solange der Waechter noch existiert.
- DNS-/Proxy-Wiederherstellung ist robuster (pro Adapter und Adressfamilie;
  Sicherung bleibt bei Teilfehlern erhalten; Proxy nutzt den richtigen
  Benutzer-Hive).
- Release-Werkzeuge koennen jetzt eine Codesignatur erzwingen
  (Build-Release.ps1 -RequireSignature, Test-ReleasePreflight.ps1
  -RequireSignedExecutables).

## Version 0.61.49

- Umbenennung von Clearstate zu Purestate. Der Produktname, die
  Installationspfade (C:\Program Files\Purestate, C:\ProgramData\Purestate),
  der Windows-Dienst- und der Native-Messaging-Host-Name
  (com.purestate.companion), der Erweiterungsordner (purestate-companion)
  sowie die Namen der erzeugten Pakete (Purestate-Windows-v*,
  Purestate-Companion-WebStore-v*) wurden umgestellt. Keine Schutzlogik
  geaendert. Die Chrome-Erweiterungs-ID bleibt unveraendert. Hinweis: eine
  bestehende Clearstate-Installation vor dem Update sauber deinstallieren.

## Version 0.61.48

- Anzeige-Fix: der Webseiten-Schutz-Zaehler in der Uebersicht und im
  Detailbericht zeigte "11/9" bzw. "11 von 9" - der Nenner war seit den
  TikTok/Pinterest-Modulen (0.61.43) nicht mitgezogen worden. Beide Stellen
  nutzen jetzt die neue gemeinsame Konstante SiteProtectionTotal (11), die
  per C#-Test gegen die reale Zahl der Site-Schalter abgesichert ist.
  Keine Schutzlogik geaendert.

## Version 0.61.47

- Windows-Haertung: erhoehte Helper-Aufrufe (sc, schtasks, icacls, netsh,
  ipconfig) werden ueber absolute System32-Pfade aufgeloest statt PATH-
  abhaengig; Konfigurationsschreibzugriffe laufen serialisiert (globaler
  Mutex) und atomar (Ersetzen ueber temporaere Datei); Deinstallations-
  Cleanup-Skripte liegen im geschuetzten ProgramData statt im Benutzer-Temp;
  Child-Prozess-Ausgaben werden asynchron/begrenzt gelesen, Heartbeat-Pipe-
  Reads sind zeit- und groessenbegrenzt; lokale Logs werden gekappt und
  einzeilig normalisiert (kein Log-Flooding, keine Zeileninjektion).
- Passwortrichtlinie verschaerft: neue Passwoerter brauchen mindestens 12
  Zeichen (bzw. eine lange Passphrase) mit ausreichender Komplexitaet, und
  der Passworthinweis darf das Passwort nicht enthalten.
- Companion: neue TikTok- und Pinterest-Module mit erweiterter Laenderhost-
  Abdeckung (u. a. pinterest.at/ch/co.uk/com.au) und Fail-Closed-Teilnahme;
  Instagram blockiert pornografische Begriffe bereits beim Tippen im echten
  Suchfeld, bevor die AJAX-Vorschlaege nutzbar sind.
- Konfigurations-Integritaet (neu): der schutzrelevante Teil der config.json
  wird mit HMAC-SHA256 signiert und beim Laden geprueft - in der Windows-App
  UND im PowerShell-Enforcement-Pfad. Wird die Datei ausserhalb von
  Purestate veraendert (z. B. Schutz per Editor abgeschaltet), wird das
  erkannt, protokolliert und der Schutz zwangsweise wieder aktiviert
  (fail-closed). Die sprachuebergreifende Gleichheit ist per gemeinsamem
  HMAC-Testwert in beiden Testsuiten abgesichert.
- Nachgezogener Fail-Closed-Fix fuer die Integritaetslogik: bei signierter,
  aber kompromittierter config.json werden jetzt alle Schutzschalter sicher
  gesetzt, Pause- und Deinstallations-Timer geleert, ein getauschter
  Passwort-Hash abgelehnt und ein erneutes Speichern/Re-Signieren der
  manipulierten Werte blockiert. Ein fehlender Integritaetsschluessel bei
  signierter Config gilt ebenfalls als kompromittiert. Die
  Deinstallations-Cooldown-Felder sind nun Teil des HMAC.
- Passwort-Sperre (neu): nach 5 aufeinanderfolgenden Fehlversuchen wird die
  Passworteingabe mit wachsender Wartezeit gesperrt (30 s bis maximal
  30 min), zentral erzwungen fuer App, Installer und Deinstallation - ein
  erneutes Oeffnen des Dialogs umgeht die Sperre nicht. Der Zaehler liegt in
  der HMAC-geschuetzten Konfiguration und laesst sich nicht unbemerkt
  zuruecksetzen.
- Robustheit/Diagnose (neu): fehlgeschlagene ACL-Haertung wird jetzt ins
  Sicherheitsprotokoll geschrieben statt verschluckt; Sicherheitsereignisse
  werden zusaetzlich best-effort ins Windows-Ereignisprotokoll gespiegelt;
  die Statusanzeige startet keine powershell.exe mehr (DNS-Status ueber die
  .NET-Netzwerk-API, Firewall-Regelzaehler ueber die Windows-Firewall-COM-
  API).

## Version 0.61.43

- Zwei neue Companion-Site-Module: TikTok und Pinterest. Beide blockieren
  pornografische Such-, Tag-, Discover-/Themen- und (TikTok) Musik-Routen
  mit dem gemeinsamen Overlay, nehmen am Fail-Closed-Schutz teil und haben
  eigene Schalter im Bereich "Webseiten-Schutz" (jetzt 11 Webseiten).
- Pinterest-Luecke geschlossen: Pinterest leitet auf Laender-Subdomains um
  (live verifiziert: pinterest.com -> de.pinterest.com), auf denen der
  bisherige Suchmaschinen-Schutz nicht lief. Das neue Modul deckt
  pinterest.com samt aller Subdomains und die pinterest.<land>-Domains ab
  (Manifest um 13 Laenderdomains erweitert).
- Instagram verstaerkt: abgesendete Suchanfragen
  (/explore/search/keyword/?q=...) werden jetzt wie Hashtag-Seiten
  blockiert - das war die dokumentierte Luecke des Instagram-Moduls.
- TikTok-Hinweis: die Erzwingung des "Eingeschraenkten Modus" braucht eine
  eingeloggte Sitzung (live verifiziert: /setting leitet ohne Login um)
  und ist als dokumentiertes TODO im Modul vermerkt.
- C#/PowerShell-Angleichung: der Regelzaehler in NativeSupportPackage.cs
  spiegelt jetzt die 0.61.42-Template-Aenderungen (Reddit-Dedupe, neue
  Suchmaschinen); ein neuer Pester-Vertragstest haelt beide Template-Saetze
  dauerhaft identisch.
- Neue Node-Regressionstests fuer TikTok-, Pinterest- und
  Instagram-Suchrouten (inklusive Gegenproben und Fremd-Host-Proben).

## Version 0.61.42

- NSFW-Schutz standardisiert und erweitert (Suchmaschinen + Begriffsliste +
  Windows-URL-Sperrliste), keine Aenderung an den Site-Modulen.
- Neue Suchmaschinen im Companion: Ecosia, Startpage, Qwant und MetaGer
  (inklusive metager.de) werden jetzt deterministisch geprueft.
- Geschlossene Luecken bei bestehenden Suchmaschinen: Bing-Bilder-/Video-/
  News-Suche (/images/search usw.), Yahoo-Subdomains (de.search.yahoo.com,
  images.search.yahoo.com), Yandex-Bilder-/Video-Suche, TikTok-Suchbereiche
  (/search/video), Pinterest-Suchbereiche (/search/videos usw.), Giphy
  /explore-Routen sowie 20 weitere Google-Laenderdomains im Manifest.
- Erweiterte gemeinsame Begriffsliste: deutsche Begriffe (u. a. titten,
  muschi, erotik, sexfilme, nacktbilder), weitere Plattform-/Seitennamen
  (u. a. xhamster, spankbang, nhentai, e621, youporn) und KI-Auszieh-Tools
  (deepnude, nudify, undress ai, clothoff).
- Neue Leetspeak-Erkennung: einfache Ziffern-/Zeichen-Verschleierungen wie
  "pr0n", "s3x", "pu55y" oder "t1ts" werden dekodiert und erkannt; harmlose
  Zahlen-Suchen ("windows 10", "3d printer", "1080p") bleiben frei.
- Windows-URL-Sperrliste standardisiert: redundante www./old./new.reddit-
  Varianten entfernt (Chromium matcht Subdomains implizit, Firefox nutzt das
  *.reddit.com-Muster) - das gibt rund 300 der 1000 Chromium-Regel-Plaetze
  frei, die jetzt die neuen Suchmaschinen und Bilder-/Video-Suchen abdecken.
- Neue Regressionstests: zusaetzliche Node-Tests fuer alle neuen Routen,
  Begriffe und Leetspeak-Varianten (inklusive Gegenproben) und neue
  Pester-Tests fuer die erweiterten URL-Sperrmuster und die Reddit-Dedupe.

## Version 0.61.41

- UI/UX-Runde ohne Schutzlogik-Aenderung, basierend auf einem vollstaendigen
  UI-Audit der App und der Companion-Overlays.
- App friert nicht mehr ein: Aktivieren, Pausieren, Reparieren und das
  Speichern von Einstellungen laufen jetzt im Hintergrund; waehrenddessen
  sind die Buttons gesperrt und die Statuskarte zeigt "... laeuft ...".
- Passwortabfrage erlaubt bis zu drei Versuche mit Hinweis direkt im Dialog,
  statt bei einem Tippfehler die ganze Aktion abzubrechen; jeder Fehlversuch
  wird weiterhin im Sicherheitsprotokoll vermerkt.
- Neues-Passwort- und Einstellungsdialog validieren direkt im Dialog
  (Passwortlaenge/-wiederholung, Zeitplan-Zeiten im Format HH:MM inklusive
  "Start gleich Ende"-Pruefung).
- Statuskarte hat einen neuen Link "Details anzeigen" mit dem vollstaendigen
  technischen Schutzstatus als kopierbarem Bericht (war zuvor unsichtbar).
- Browser-Karte der Uebersicht meldet jetzt "Teilweise", wenn nur Chrome
  ODER Edge abgesichert ist; "Geschuetzt" erfordert beide.
- Berichte (Diagnose, Logs, Regelcheck usw.) werden in Monospace-Schrift
  angezeigt.
- Alle deutschen App-Texte verwenden jetzt echte Umlaute (vorher "ue/oe/ae");
  der Build kompiliert dafuer explizit mit UTF-8-Codepage.
- Companion-Block-Overlay: neue dunkle Farbvariante folgt dem
  Betriebssystem-/Seiten-Farbschema (kein greller weisser Block mehr auf
  dunklen Seiten) und ein "Zurueck"-Knopf fuehrt von der blockierten Seite
  weg (navigiert nur zurueck, kein Freischalten).

## Version 0.61.40

- Suchmaschinen-NSFW-Schutz vom Windows-URLBlocklist-Fallback in den Companion
  gehoben: Google, Bing, DuckDuckGo, Brave Search, Yahoo, Yandex, YouTube,
  TikTok, Pinterest und Giphy werden jetzt direkt im Content Script geprueft.
- Adult-Querys und Adult-Tags wie `https://search.brave.com/search?q=porn`
  werden mit dem Purestate-Overlay blockiert, bevor Ergebnislisten nutzbar
  sind.
- der WebStore-Companion fordert dafuer gezielte Host-Rechte fuer die
  abgedeckten Such-/Video-/Tag-Seiten an.
- neue Node-Regression prueft die exakte Brave-Search-Live-Luecke sowie
  weitere Suchmaschinen-/Video-/Tag-Routen und harmlose Lookalikes.

**Wichtig fuer Version 0.61.40:**
- Diese Version ersetzt 0.61.39 als Web-Store-/Windows-Live-Testkandidat,
  weil der Live-Test gezeigt hat, dass Chrome die gesetzten URLBlocklist-
  Query-Wildcards nicht verlaesslich blockiert.
- Es wurden weiterhin keine KI- oder Bilderkennungsmechaniken eingefuehrt.

## Version 0.61.39

- NSFW-Hardening ohne KI: die zentrale URLBlocklist-Erzeugung garantiert jetzt
  Core-Abdeckung fuer harte Erwachsenenbegriffe auf Google, Bing,
  DuckDuckGo, Brave Search, Yahoo, Yandex, YouTube, TikTok, Instagram,
  Pinterest und Giphy, bevor lange Reddit-/Social-Listen das Chromium-Limit
  von 1000 Regeln fuellen.
- `rules\adult-url-keywords.txt` wurde auf 100 transparente, deterministische
  NSFW-URL-Begriffe erweitert.
- der Companion erkennt zusaetzliche Plattform-/Aliasbegriffe wie
  `justforfans`, `loyalfans`, `manyvids`, `pornography`, `goonsky`,
  `spicysky`, `skyhub` und `realnsfw`.
- neue Regressionstests sichern ab, dass wichtige Suchmaschinen-/Video-/Tag-
  Routen trotz 1000-Regel-Grenze in der URLBlocklist bleiben.

**Wichtig fuer Version 0.61.39:**
- Diese Version ersetzt 0.61.38 als naechsten Web-Store-/Windows-
  Live-Testkandidaten.
- Es wurden keine KI- oder Bilderkennungsmechaniken eingefuehrt; der Schutz
  bleibt deterministisch ueber Regeln, Labels, URLs, Plattformsignale und
  vorhandene Companion-Logik.

## Version 0.61.38

- neuer passwortgeschuetzter Bereich "Webseiten-Schutz" in der Windows-App:
  Reddit, X/Twitter, Bluesky, Tumblr, DeviantArt, pixiv, Newgrounds, Imgur
  und Instagram koennen einzeln an- oder ausgeschaltet werden.
- die Auswahl wird in der geschuetzten Purestate-Konfiguration gespeichert
  und bleibt in Backup/Restore erhalten; neue Installationen starten weiterhin
  mit allen neun Webseiten aktiv.
- der Native Host liefert die Webseiten-Auswahl an den Companion aus, damit
  deaktivierte Module ihre Content-Script-Ueberwachung nicht starten.
- Windows-URLBlocklist und direkter Fail-Closed-Pfad respektieren deaktivierte
  Webseiten ebenfalls, statt diese Seiten weiter ueber Richtlinien zu sperren.
- Diagnose zeigt nun an, wie viele Webseiten-Schutzmodule aktiv sind und welche
  deaktiviert wurden.

**Wichtig fuer Version 0.61.38:**
- Diese Version ersetzt 0.61.37 als naechsten Web-Store-/Windows-
  Live-Testkandidaten, weil Windows-App und Companion gemeinsam ausgeliefert
  werden muessen.
- Browser-Haertung, DNS, Hosts-Sperrliste und Umgehungsschutz bleiben von den
  einzelnen Webseiten-Schaltern getrennt.

## Version 0.61.37

- Verwaltungs-App optisch und strukturell aufgeraeumt: Die Uebersicht zeigt
  die wichtigsten Schutzsignale jetzt als Statuskarten statt als langen
  technischen Textblock.
- Einstellungen wurden in klare Gruppen fuer Basisschutz, Browser-/
  Umgehungsschutz sowie Pause/Zeitplan gegliedert.
- Buttons in App, Installer und Uninstaller haben konsistentere Hover-,
  Pressed- und Fokus-Zustaende.
- Accessibility-/DPI-Polish: zentrale Fenster und Dialoge bekommen explizite
  AccessibleNames/Descriptions, sinnvollere Tab-Reihenfolgen, Fokusstartpunkte
  und DPI-AutoScaling.
- Companion-Blockhinweise fuer X, Bluesky, Tumblr und DeviantArt nutzen jetzt
  dieselbe Purestate-Overlay-Komponente mit ARIA-Rolle und Fokussteuerung.

**Wichtig fuer Version 0.61.37:**
- Diese Version ersetzt 0.61.36 als naechsten Web-Store-/Windows-
  Live-Testkandidaten und enthaelt keine neue Schutzlogik; der Schwerpunkt
  liegt auf UI/UX, A11y und einheitlicheren Companion-Hinweisen.
- 0.61.34 bleibt die zuletzt live-validierte Version (Chrome-Live-Gate gruen
  am 2026-07-03).

## Version 0.61.36

- neuer Selektor-Canary: die sechs Module mit Einstellungs-Erzwingung (pixiv,
  DeviantArt, Instagram, Imgur, Newgrounds, Tumblr) melden jetzt, wenn sie auf
  der Einstellungsseite sind, ihre Schutz-Kontrollelemente dort aber nicht mehr
  finden - das passiert typischerweise, wenn die Webseite ihr Design aendert
  und der Schutz sonst still ausfallen wuerde
- die Meldungen landen lokal in `%ProgramData%\Purestate\companion-canary.log`
  (nur technische Kurz-Kennungen wie `pixiv:viewing-checkboxes`, niemals
  Seiteninhalte) und werden von der Diagnose mit angezeigt
- bei pixiv, DeviantArt und Instagram prueft der Canary zusaetzlich jeden
  Selbstheilungs-Zyklus (das versteckte Einstellungs-iframe), sodass ein
  Design-Bruch auch ohne Besuch der Einstellungsseite innerhalb weniger
  Minuten auffaellt
- reine Diagnose-Funktion: keine Aenderung an Schutz-, Blockier- oder
  Heartbeat-Logik

**Wichtig fuer Version 0.61.36:**
- Diese Version ersetzt 0.61.35 (nie hochgeladen) und 0.61.34 als naechsten
  Web-Store-/Windows-Live-Testkandidaten; sie buendelt Native-Host-Logging
  und Selektor-Canary in einem Update.
- 0.61.34 bleibt die zuletzt live-validierte Version (Chrome-Live-Gate gruen
  am 2026-07-03).

## Version 0.61.35

- der Native Host protokolliert jetzt jeden Abbruchgrund nach `%ProgramData%\Purestate\native-host.log` (abgelehnter Origin, ungueltige Nachricht, Guard-Pipe-Fehler, Guard-Ablehnung) - bisher endeten alle diese Pfade stumm, was die Heartbeat-Fehlersuche in 0.61.32/0.61.33 unnoetig schwer machte
- das Log ist groessenbegrenzt, enthaelt nur technische Metadaten (Browser, Version, Fehlertext) und niemals Seiteninhalte
- die Diagnose (`Get-Diagnostics.ps1`) zeigt die neuesten Native-Host-Fehlerzeilen mit an
- keine Aenderung an Schutz-, Blockier- oder Heartbeat-Logik

**Wichtig fuer Version 0.61.35:**
- Diese Version ersetzt 0.61.34 als naechsten Web-Store-/Windows-Live-Testkandidaten.
- 0.61.34 bleibt die zuletzt live-validierte Version (Chrome-Live-Gate gruen am 2026-07-03).

## Version 0.61.34

- verhindert Chrome-Close-Loops, wenn der verwaltete Store-Companion in der richtigen Version installiert ist, aber der Native-Messaging-Heartbeat stale bleibt
- stuft den Native-Heartbeat kuenftig als Diagnose-/Native-Host-Liveness-Signal ein, nicht mehr als alleinige Voraussetzung fuer die Browser-Schutzfreigabe
- Fail-Closed bleibt aktiv, wenn der Companion fehlt, deaktiviert, veraltet oder nicht per Managed Policy erzwungen ist
- Diagnose meldet bei laufendem Browser und gueltiger Companion-Policy nun `Live-Gate: gruen (verwalteter Companion aktiv; Native-Heartbeat nicht aktuell)` statt Chrome in die Vollsperre zu treiben

**Wichtig fuer Version 0.61.34:**
- Diese Version ersetzt 0.61.33 als naechsten Web-Store-/Windows-Live-Testkandidaten.
- 0.61.33 bleibt nachvollziehbar, ist aber wegen weiterem Chrome-Schliessen nicht public-ready.

## Version 0.61.33

- entfernt den zu fragilen Parent-Prozess-Check aus dem Native Host, nachdem 0.61.32 im Live-Test weiterhin Chrome schloss, ohne dass ein Heartbeat den Guard erreichte
- behaelt die Chrome-Extension-Origin-Pruefung im Native Host und die installierter-Pfad-Pruefung im Guard bei
- bleibt beim Heartbeat-Retry-Verhalten aus 0.61.32

**Wichtig fuer Version 0.61.33:**
- Diese Version ersetzt 0.61.32 als naechsten Web-Store-/Windows-Live-Testkandidaten.
- 0.61.32 bleibt nachvollziehbar, ist aber wegen weiterhin fehlendem Chrome-Heartbeat nicht public-ready.

## Version 0.61.32

- repariert den roten Chrome-Live-Heartbeat-Gate aus 0.61.31, indem der Native Host selbst prueft, ob er von Chrome oder Edge gestartet wurde
- der Schutzdienst akzeptiert Heartbeat-Pipe-Schreibvorgaenge weiterhin nur vom installierten `PurestateNativeHost.exe`, verlaesst sich dabei aber nicht mehr auf eine fragile Parent-Prozess-Abfrage aus dem Dienstkontext
- der Companion retryt fehlgeschlagene Heartbeats ueber einen separaten Alarm, damit kurze Native-Host-/Service-Worker-Startfenster nicht dauerhaft stale bleiben
- erweitert die Diagnose um Browser-Prozessalter und `Live-Gate`, damit Chrome-Startfenster und echte Heartbeat-Ausfaelle sauber unterschieden werden

**Wichtig fuer Version 0.61.32:**
- Diese Version ersetzt 0.61.31 als naechsten Web-Store-/Windows-Live-Testkandidaten.
- 0.61.31 bleibt nachvollziehbar, ist aber wegen stale Chrome-Heartbeat nach Ablauf des Startfensters nicht public-ready.

## Version 0.61.31

- hebt App- und Companion-Version auf 0.61.31 an, damit das aktuelle Web-Store-Paket eindeutig neuer ist als das bereits vorhandene, aber nicht aktuelle 0.61.30-Paket
- enthaelt keine neue Schutzlogik gegenueber dem aktuellen 0.61.30-Quellstand; der Versionssprung dient der sauberen Chrome-Web-Store-Auslieferung und Artefakt-Nachverfolgbarkeit

**Wichtig fuer Version 0.61.31:**
- Diese Windows-Version erst installieren, nachdem der dazu passende Companion 0.61.31 im Chrome Web Store veroeffentlicht wurde.
- Die Erweiterung wird danach automatisch installiert; Entwicklermodus und "Entpackte Erweiterung laden" werden nicht mehr verwendet.
- Beim ersten Richtlinienwechsel kann Purestate Chrome einmal schliessen.

## Version 0.61.30

- unterstuetzt jetzt auch Instagram: erzwingt die Sensible-Inhalte-Einstellung auf "Weniger", haelt sie geraeteuebergreifend aufrecht und blockiert bekannte Erwachsenen-Hashtags
- unterstuetzt jetzt auch Imgur: blockiert Erwachsenen-Tag-Seiten und -Suchanfragen und schaltet die Konto-Einstellung "Jugendgefaehrdende Beitraege anzeigen" aus
- blockiert auf Newgrounds den Umgehungslink "trotzdem anzeigen" auf der Inhalts-gefiltert-Seite direkt und verdeckt eine direkt aufgerufene Mature-/Adult-Werkseite auch dann, wenn der Link genutzt wurde
- unterstuetzt jetzt auch Newgrounds: sperrt Mature- und Adult-Inhalte ueber die Konto-Alterseinstufung und blendet passende Vorschaukarten aus
- blockiert eindeutige Suchbegriffe jetzt einheitlich auf allen unterstuetzten Webseiten ueber eine zentrale Begriffsliste
- macht die R-18-Einstellungen bei pixiv buchstaeblich unklickbar und entfernt zusaetzliche "Anzeigen"-Umgehungen bei einzelnen Beitraegen und Profilen
- unterstuetzt jetzt auch pixiv: erzwingt die serverseitige R-18-Filterung und leitet eindeutige Erwachsenen-Suchen auf den sicheren Modus um
- schliesst bei DeviantArt eine Umgehung des "Trotzdem anzeigen"-Buttons, wenn dieser in einem Schatten-DOM-Element versteckt ist
- schliesst bei DeviantArt eine Umgehung des Sicheren Modus ueber das Browsing-Modus-Menue, das jetzt auf jeder Seite erreichbar ist, und blockiert dort zusaetzlich den "Trotzdem anzeigen"-Button auf gesperrten Beitraegen
- unterstuetzt jetzt auch DeviantArt: erzwingt den Sicheren Modus im Konto und blockiert bekannte Erwachsenen-Suchen und -Tags
- erkennt bei Tumblr Erwachseneninhalte zuverlaessig ueber die sichtbare Inhalts-Kennzeichnung und erzwingt die passenden Konto-Einstellungen dafuer
- unterstuetzt jetzt auch Tumblr: blockiert eindeutig gekennzeichnete Beitraege sowie bekannte Erwachsenen-Tags und -Suchen
- erzwingt Reddit Safe Search auf "Aktiviert" und blockiert Klicks auf "Automatisch" oder "Deaktiviert"
- blockiert Reddit-NSFW-Suchvorschauen in "All" auch dann, wenn Reddit keine normale Postkarte oder Blocklisten-Community liefert
- erkennt lose Reddit-Suchergebniszeilen mit sichtbarem NSFW-Badge und Preview-Medium robuster
- kann lokale Browser-Companion-Regeln aus rules\browser-companion-rules.txt ueber den geschuetzten Native Host laden
- reduziert kuenftige Chrome-Web-Store-Wartezyklen fuer neue deterministische Bluesky-Begriffe, weil lokale Regeln additiv zu den eingebauten Regeln wirken
- erweitert die lokalen Bluesky-Regeln um eindeutige Such-/Hashtag-Signale wie cock, dick, penis, femdom und findom
- erkennt lokale Bluesky-Erwachsenenlinks wie justfor.fans und 2cams.org
- findet Bluesky-Posts mit sichtbaren Medien jetzt auch ueber das Medium selbst, wenn Bluesky keinen stabilen Postcontainer markiert
- blockiert auf Bluesky auch starke Varianten wie "titties", "bigboobs", "cumtribute" und vergleichbare eindeutige Hashtags
- blockiert Bluesky-Feed-Karten mit eindeutigen Erwachsenen-Signalen auch dann, wenn Bluesky keinen normalen Post-Link im sichtbaren Kartenbereich liefert
- repariert den fehlenden Windows-Aufgabenordner vor dem Anlegen von Startup- und Watchdog-Aufgaben
- erkennt den aktuellen Bluesky-Feed-Container korrekt und blockiert Medien bei eindeutigen Postsignalen
- blockiert eindeutige Bluesky-Suchen jetzt auch ueber das sichtbare Suchfeld, falls Bluesky die Adresse spaet aktualisiert
- ersetzt eindeutige Bluesky-18+-Beitraege jetzt als ganze Postkarte, statt nur die Medien auszublenden
- erkennt den live gefundenen Bluesky-Fall mit #breasts, #boobs, #goonsky, #spicysky und verwandten Hashtags
- deckt die eindeutigen Bluesky-Begriffe cock, dick, penis, femdom und findom direkt im Companion ab
- erweitert eindeutige Suchbegriffe fuer Reddit, X/Twitter und Bluesky, darunter boobs, breasts, tits, pussy, cock, dick, penis, gooner und goonsky
- priorisiert die URL-Regelerzeugung fuer Reddit, X/Twitter und Bluesky, bevor weitere Suchmaschinenregeln aufgefuellt werden
- blockiert eindeutige X-Suchen auch ueber sichtbare Suchfelder, falls X die Adresse spaet aktualisiert
- erkennt Store-Companion-Profile auch dann, wenn Chrome nur den versionierten Web-Store-Pfad speichert
- bereinigt einen alten Vollsperr-Policy-Zustand beim Wechsel zur aktiven verwalteten Erweiterung gezielt
- blockiert auch eindeutige Bluesky-Suchanfragen wie "pussy" direkt
- behaelt beim normalen Chrome-Start und bei wiederhergestellten Tabs selektive Mixed-Site-Regeln bei
- wartet bei einer nachweislich aktiven verwalteten Store-Erweiterung bis zu 300 Sekunden auf den ersten Heartbeat, statt Chrome sofort zu schliessen
- schreibt bei Background-Anfragen einen gedrosselten frischen Companion-Heartbeat, damit Chrome nicht wegen kurzer Service-Worker-Aussetzer geschlossen wird
- schliesst Chrome nicht mehr nur zum Entfernen einer alten Vollsperr-Policy, wenn der Companion wieder aktiv ist
- behaelt einen noch aktuellen Heartbeat bei einem Neustart des Schutzdienstes bei
- verlangt nach dieser kurzen Startphase wieder zwingend einen aktuellen Heartbeat und wechselt sonst in die Vollsperre
- blockiert auf Bluesky starke Suchbegriffe wie tits, boobs, naked, topless und weitere eindeutige Varianten ohne KI
- verdeckt Bluesky-Medien bei starken Hashtags, eindeutigen Erwachsenenlinks sowie pornografischen Autor- oder Zitatlabels
- laesst Recovery- und Hilfstexte wie "porn addiction recovery" trotz der strengeren Textpruefung sichtbar
- erhaelt bestehende Registry-Werte beim Reparieren von Chrome-, Edge-, Firefox-, Proxy- und App-Schluesseln
- repariert kurz entfernte Companion-Richtlinien direkt im Schutzdienst innerhalb einer Sekunde
- erkennt eine deaktivierte Companion-Erweiterung ueber das Chrome-Profil ohne auf den Heartbeat-Timeout zu warten
- aktiviert sofort die Vollsperre und schliesst den betroffenen Browser fuer die sichere Richtlinienuebernahme genau einmal
- macht Browserrichtlinien bei aktivem Schutz verpflichtend und repariert die force-installed-Richtlinie automatisch
- startet den Hintergrundschutz als verzoegert-automatischen Windows-Dienst und zusaetzlich ueber einen SYSTEM-Startwaechter
- erlaubt das Aktivieren des Schutzes ohne Passwort; Pausieren, Ausschalten und Deinstallieren bleiben geschuetzt
- wechselt von der entpackten Entwickler-Erweiterung zur verwalteten Chrome-Web-Store-Installation
- verwendet die feste Store-ID gmldhenkcnghfoapdnhkikfpgdmmnlok
- erzwingt Installation und Aktivzustand ueber Chrome- und Edge-Richtlinien
- entfernt dadurch den normalen Aus-Schalter und die Entfernen-Schaltflaeche
- laesst Chrome und Edge die Erweiterung automatisch ueber den Store aktualisieren
- stellt die verwaltete Richtlinie ueber den Purestate-Watchdog wieder her

**Wichtig fuer Version 0.61.30:**
- Diese Windows-Version erst installieren, nachdem der dazu passende Companion im Chrome Web Store veroeffentlicht wurde.
- Die Erweiterung wird danach automatisch installiert; Entwicklermodus und "Entpackte Erweiterung laden" werden nicht mehr verwendet.
- Beim ersten Richtlinienwechsel kann Purestate Chrome einmal schliessen.

## Version 60

- schliesst Chrome nach dem erstmaligen Aktivieren des Companion nicht mehr zwangsweise, damit Chrome die entpackte Erweiterung dauerhaft speichern kann
- loescht den lokalen Lebensnachweis sofort, sobald Chrome oder Edge eine Erweiterungseinstellung aendert
- setzt beim Ausschalten oder Entfernen weiterhin die Vollsperre und schliesst den betroffenen Browser zur sicheren Richtlinienuebernahme
- akzeptiert Lebensnachweise nur noch 90 Sekunden statt ueber einen geschlossenen Browser hinweg
- verwirft gespeicherte Lebensnachweise bei jedem Start des Schutzdienstes

**Wichtig fuer Version 60:**
- Nach dem Laden des Companion Chrome selbst vollstaendig schliessen und erneut oeffnen.
- Purestate schliesst Chrome beim Einschalten nicht mehr automatisch.
- Beim Ausschalten oder Entfernen muss Chrome dagegen automatisch geschlossen werden; danach sind Reddit, X, Twitter und Bluesky vollstaendig gesperrt.

## Version 59

- gibt Purestate Companion eine feste, kryptografisch abgeleitete Extension-ID fuer alle Chrome- und Edge-Profile
- behebt die verweigerte lokale Verbindung, die durch unterschiedliche zufaellige IDs je Browserprofil entstand
- beschraenkt den lokalen Kommunikationshost weiterhin exakt auf die feste Purestate-ID
- behaelt den direkten lokalen Lebensnachweis und die Vollsperre bei fehlendem Signal bei

**Wichtig fuer Version 59:**
- Nach der Purestate-Aktualisierung die bisherige Companion-Erweiterung auf chrome://extensions entfernen.
- Danach "Entpackte Erweiterung laden" waehlen und erneut C:\Program Files\Purestate\extension\purestate-companion laden.
- Die neue feste ID muss jggfcgoibicehopjdmehefbickhofiac und die Version 0.59.0 sein.
- Chrome danach neu starten; beim ersten erfolgreichen Richtlinienwechsel kann Purestate Chrome einmal schliessen.

## Version 58

- ersetzt die fehleranfaellige alleinige Auswertung von Chrome-Dateien durch einen direkten lokalen Companion-Lebensnachweis
- uebertraegt dabei nur Browsername und Purestate-Version an den lokalen Windows-Dienst, niemals Webseiten oder Inhalte
- hebt die Vollsperre auf, sobald der aktuelle Companion erfolgreich mit dem geschuetzten Dienst verbunden ist
- laesst die Vollsperre wieder greifen, wenn der Lebensnachweis bei laufendem Browser ausbleibt
- registriert den lokalen Chrome- und Edge-Kommunikationshost bei Installation und Reparatur automatisch

**Wichtig fuer Version 58:**
- Purestate zuerst auf 0.58.0 aktualisieren und danach Companion auf chrome://extensions aktualisieren.
- Chrome anschliessend vollstaendig neu starten und bis zu eine Minute auf den ersten Lebensnachweis warten.
- Beim ersten erfolgreichen Wechsel kann Purestate Chrome einmal schliessen, damit die gelockerte Richtlinie sicher neu geladen wird.

## Version 57

- behebt die falsche Vollsperre bei eingeschaltetem Purestate Companion
- unterscheidet einen reinen Identitaetseintrag ohne Aktivstatus von einer ausdruecklich deaktivierten Erweiterung
- akzeptiert weiterhin nur die aktuelle Companion-Version aus dem geschuetzten Purestate-Installationsordner
- behaelt die Vollsperre bei einem echten Off-Zustand, Deaktivierungsgrund, falschen Pfad oder veralteter Version bei
- prueft die geteilte Chrome-Einstellungsdarstellung mit einem eigenen Regressionstest

**Wichtig fuer Version 57:**
- Purestate und Companion gemeinsam auf 0.57.0 aktualisieren.
- Chrome wird beim erkannten Versions- und Richtlinienwechsel einmal geschlossen.
- Danach muessen Reddit, X und Bluesky mit Companion On wieder erreichbar und mit Companion Off vollstaendig gesperrt sein.

## Version 56

- behebt den zentralen Formatfehler der Chrome- und Edge-Vollsperre
- verwendet fuer Chromium-Richtlinien native Domainfilter wie reddit.com, x.com, twitter.com und bsky.app
- verwendet WebExtension-Match-Patterns nicht mehr als Vollsperrfilter in Chromes URLBlocklist
- behaelt die bisherigen Wildcard-Muster getrennt fuer Firefox, dessen WebsiteFilter dieses Format erwartet
- erkennt installierte alte Vollsperrregeln aus Version 55 als ungueltig und ersetzt sie automatisch
- erzwingt durch den Versionswechsel anschliessend einen einmaligen Browserneustart
- prueft im Selbsttest, dass die ersten Chromium-Vollsperrfilter keine Sternchen-Schema-Muster enthalten

**Wichtig fuer Version 56:**
- Nach der Aktualisierung muss chrome://policy bei URLBlocklist am Anfang reddit.com, x.com, twitter.com und bsky.app zeigen.
- Mit Companion Off muessen diese vier Domains nach dem automatischen Chrome-Neustart vollstaendig gesperrt sein.
- Companion fuer den normalen selektiven Schutz danach auf 0.56.0 aktualisieren und wieder aktivieren.

## Version 55

- behebt die reale Chrome-Umgehung, bei der Companion Off war, die Vollsperre in Windows aber erst nach einem Browserneustart wirksam wurde
- wertet Secure Preferences und Preferences gemeinsam als aktiv, deaktiviert oder dort nicht vorhanden aus
- erkennt geteilte Chrome-Eintraege, bei denen Installationspfad und Aktivzustand in unterschiedlichen Einstellungsdateien stehen
- behandelt eine Deaktivierung in einer der beiden Dateien immer vorsorglich als Off
- verwendet den geschuetzten Installationspfad als starke Companion-Identitaet, auch wenn Chrome dort nicht alle Manifestdaten wiederholt
- speichert neben Aktivzustaenden nun auch die Purestate-Version und erzwingt nach jedem Versionswechsel einmal das Neuladen der Browserrichtlinien
- schliesst Chrome beziehungsweise Edge bei einem erkannten Wechsel immer, solange der Browser-Schutz aktiv ist; der optionale Sperrmodus-Schalter beeinflusst das nicht mehr

**Wichtig fuer Version 55:**
- Bei der ersten Aktualisierung von Version 54 auf 55 wird Chrome einmal absichtlich geschlossen, auch wenn Companion bereits Off ist.
- Beim erneuten Aktivieren oder Deaktivieren wird Chrome danach jeweils genau einmal geschlossen.
- Nach dem Neustart mit Companion Off muessen Reddit, X und Bluesky vollstaendig gesperrt sein.
- Companion danach auf 0.55.0 aktualisieren und fuer den normalen selektiven Schutz wieder einschalten.

## Version 54

- schliesst die Umgehung durch den Aus-Schalter von Purestate Companion
- speichert den letzten aktiven Companion-Zustand geschuetzt unter ProgramData
- erkennt Aktivieren und Deaktivieren als echten Zustandswechsel statt nur die Registry-Regeln zu vergleichen
- schreibt zuerst Companion- oder Vollsperrregeln und schliesst danach den betroffenen Chrome-/Edge-Browser einmal
- erzwingt dadurch, dass der neu gestartete Browser die aktuelle Windows-Richtlinie einliest
- behandelt beim ersten Start ein bereits deaktiviertes Companion ebenfalls als unsicheren Wechsel
- schliesst den Browser nicht bei unveraenderten 30-Sekunden-Pruefungen erneut

**Wichtig fuer Version 54:**
- Wenn Companion ein- oder ausgeschaltet wird, schliesst Purestate Chrome beziehungsweise Edge absichtlich einmal.
- Nicht gespeicherte Formulareingaben koennen dabei verloren gehen; normale Tabs kann Chrome ueblicherweise wiederherstellen.
- Bei ausgeschaltetem Companion bleiben Reddit, X und Bluesky nach dem Neustart vollstaendig gesperrt.
- Nach dem Update Companion 0.54.0 aktualisieren. Purestate kann Chrome dabei einmal im Vollsperrmodus und nach der erfolgreichen Aktivierung ein weiteres Mal schliessen.

## Version 53

- erweitert Purestate Companion auf Bluesky
- blockiert pornografische Bluesky-Suchen und Hashtags bereits anhand der Adresse
- liest sichtbare Bluesky-Post-IDs und prueft die oeffentlichen strukturierten Post-Labels
- sperrt Selbst- und Moderationslabels wie porn, sexual und nudity ohne normale Diskussionstexte auszuwerten
- verdeckt Bilder und Videos waehrend der Pruefung und gibt sie nur nach einer eindeutig sicheren Antwort frei
- laesst nicht erreichbare oder unbekannte Postdaten vorsorglich verdeckt
- behandelt zitierte Posts gemeinsam: ein blockiertes oder unbekanntes Teil haelt die gesamte Medienkarte geschlossen
- faengt sichtbare 18+-Warnungen und Freigabeklicks direkt auf der Seite ab
- nimmt Bluesky in die Vollsperre auf, wenn Companion fehlt, deaktiviert oder veraltet ist

**Wichtig fuer Version 53:**
- Nach dem Update muss Companion 0.53.0 aus C:\Program Files\Purestate\extension\purestate-companion geladen und aktualisiert werden.
- Bluesky sollte danach mit einer normalen Suche und einer expliziten Testsuche praktisch geprueft werden.

## Version 52

- beobachtet Chrome- und Edge-Profildateien direkt im Windows-Schutzdienst
- reagiert nach einer Aenderung mit einem entprellten Companion-Schnelltest statt auf den naechsten Gesamtlauf zu warten
- schreibt Browserrichtlinien nur neu, wenn Companion-Zustand und Vollsperrmodus nicht zusammenpassen
- behaelt den 30-Sekunden-Gesamtlauf als zweite Rueckfallebene bei
- merkt sich einen Schnelltest, der waehrend einer laufenden Gesamtpruefung angefordert wurde, und fuehrt ihn direkt danach aus
- prueft die Dateisystemwache mit einem echten temporaeren Browserprofil im Dienst-Selbsttest

**Wichtig fuer Version 52:**
- Die Profilwache reagiert typischerweise innerhalb weniger Sekunden auf Entfernen, Deaktivieren oder Aktualisieren.
- Der Browser selbst kann eine geaenderte Windows-Richtlinie leicht verzoegert uebernehmen; ein Browser-Neustart erzwingt die aktuelle Richtlinie.
- Nach dem Update muss Companion 0.52.0 aus C:\Program Files\Purestate\extension\purestate-companion geladen sein.

## Version 51

- akzeptiert nicht mehr irgendeine gleich benannte Browsererweiterung
- verlangt Purestate Companion in der exakt aktuellen Version
- verlangt als Quelle den geschuetzten Purestate-Installationsordner unter C:\Program Files\Purestate
- schaltet bei einer alten, kopierten oder anderswo geladenen Erweiterung auf die X-/Reddit-Vollsperre
- zeigt in der App fuer Chrome und Edge klar "Companion aktiv" oder "Vollsperre aktiv" an
- zeigt fuer Firefox den weiterhin aktiven X-/Reddit-Vollsperrmodus getrennt an

**Wichtig fuer Version 51:**
- Eine zuvor direkt aus einem Download- oder Paketordner geladene Erweiterung gilt absichtlich nicht mehr als sicher.
- Entferne diese alte Kopie und lade die Erweiterung aus C:\Program Files\Purestate\extension\purestate-companion.
- Nach jedem Purestate-Update auf chrome://extensions oder edge://extensions "Aktualisieren" anklicken und den Browser neu starten.

## Version 50

- prueft Purestate Companion getrennt fuer Chrome und Edge
- verlangt eine aktive Erweiterung in jedem vorhandenen Default- oder Profile-Browserprofil
- sperrt Reddit, X und Twitter im betroffenen Browser vollstaendig, wenn Companion fehlt oder deaktiviert ist
- hebt die Vollsperre nach erneuter Aktivierung der Erweiterung automatisch wieder auf
- deaktiviert Gastmodus und das Anlegen weiterer Chrome-/Edge-Profile per Richtlinie
- sperrt Reddit und X in Firefox vollstaendig, bis eine eigene Firefox-Companion-Version vorhanden ist
- priorisiert die Vollsperren innerhalb des Browserlimits von 1000 URL-Regeln

**Wichtig fuer Version 50:**
- Purestate Companion muss in jedem bereits vorhandenen Chrome- oder Edge-Profil geladen und aktiviert sein.
- Nach Aenderungen an Erweiterungen kann es bis zu etwa zwei Minuten dauern, bis Browser und Schutzdienst die Richtlinie aktualisiert haben.
- Chrome oder Edge danach vollstaendig neu starten.

## Version 49

- verlangt das Purestate-Passwort auch fuer Reparaturen und Aktualisierungen einer bestehenden Installation
- startet nach der ersten Passwortfreigabe eine gespeicherte 10-Minuten-Abkuehlzeit vor der Deinstallation
- verlangt nach Ablauf der Abkuehlzeit das Passwort ein zweites Mal
- haelt Schutz, Dienst und Richtlinien waehrend der Abkuehlzeit aktiv
- entfernt stille Deinstallations- und Aenderungswege aus dem Windows-App-Eintrag
- beschraenkt normale Windows-Benutzer im Installationsordner auf Lesen und Ausfuehren
- stellt manipulierte Deinstallationseintraege und Dateirechte durch den Watchdog wieder her

## Version 48

- erkennt X-Medienraster mit mehreren sensiblen Warnkacheln als erhoehtes Risiko
- blockiert in einem solchen Raster auch bereits enthuellte oder nicht mehr markierte Medienkacheln
- merkt sich die Risikoentscheidung fuer die aktuelle X-Suche waehrend der Sitzung
- laesst normale Medienraster ohne mehrere Warnsignale weiterhin nutzbar
- behaelt die fruehe Show-Sperre und alle bisherigen Schutzschichten bei

## Version 47

- erkennt X-Suchergebnisse in der Ansicht Media als eigenstaendige Medienkacheln
- ersetzt Kacheln mit "Warning: Sensitive content" oder "Warning: Nudity" vollstaendig
- entfernt Show-Links und Zieladressen dieser Kacheln
- faengt Show-Klicks bereits vor der X-Seitenlogik ab
- verhindert dadurch auch eine Freigabe durch wiederholtes Klicken
- behaelt Suchsperre, sichere X-Einstellungen und alle bisherigen Schutzschichten bei

## Version 46

- blockiert pornografische Suchanfragen auf X direkt in der Erweiterung
- greift auch bei internen X-Seitenwechseln, die keine normale Browser-Navigation ausloesen
- setzt "Display media that may contain sensitive content" auf aus
- setzt "Hide sensitive content" auf an
- verhindert, dass diese beiden X-Schalter im geschuetzten Browser wieder unsicher gesetzt werden
- behaelt den Einzelmedien-, Reddit- und YouTube-Schutz der vorherigen Versionen bei

## Version 45

- erweitert Purestate Companion auf X und Twitter
- erkennt X-Beitraege mit nativen Warnungen fuer sensible oder nicht jugendfreie Medien
- blockiert deren Bilder, Videos und Vorschaukarten ohne Freigabe-Schaltflaeche
- verdeckt Vorschaukarten bekannter expliziter Anbieter auch innerhalb normaler X-Feeds
- beobachtet dynamisch nachgeladene X-Beitraege beim Scrollen und laesst normale Posts nutzbar
- fuehrt das X-Seitenmodul im Vorabcheck, Dienst-Selbsttest und Integritaetsmanifest

## Version 44

- erkennt Reddit-Suchergebnisse in All und Beitraege direkt ueber das sichtbare NSFW-Kennzeichen
- sperrt dadurch die gesamte einzelne Ergebniszeile und auch Reddits eigene Vorschaubild-Komponenten
- verhindert mehrere Platzhalter fuer denselben Reddit-Treffer und laesst normale Ergebnisse unberuehrt
- erzwingt nicht mehr den pauschalen strengen YouTube Restricted Mode, der auch Musik- und Rap-Inhalte ausblenden konnte
- behaelt die gezielten Porno-/NSFW-Such- und URL-Regeln fuer YouTube bei

## Version 43

- fasst Reddit-Suchergebnisse in den Ansichten All und Beitraege als jeweils eine Post-Karte zusammen
- entfernt alle Bilder, Videos und Hintergrundmedien dieser Karte statt nur einzelne Linkbereiche
- zeigt pro NSFW-Treffer genau einen kompakten Hinweis direkt an der Stelle der Medienvorschau
- verhindert doppelte oder ueber dem Beitragstext liegende Purestate-Platzhalter

## Version 42

- behebt Konflikte mit einer bereits vorhandenen oder geprueften Installieren.pending.exe
- verwendet fuer jeden Aktualisierungsversuch eine eindeutige temporaere Installer-Datei
- beendet ausschliesslich alte Purestate-Abschlussprozesse und laesst andere PowerShell-Prozesse unangetastet
- kennzeichnet den neuesten Abschlussauftrag, damit ein aelterer Helfer niemals eine neuere Installer-Version ueberschreibt
- behaelt den Reddit-Medien-, Einzelpost- und Subreddit-Schutz aus Version 41 bei

## Version 41

- blockiert NSFW-Vorschaubilder, Videos, GIFs, eingebettete Player und Hintergrundbilder auf Reddit
- erfasst kompakte Listen, Suchtreffer, Profilansichten und die Reddit-Medienansicht ueber die jeweilige Post-ID
- prueft bis zu 50 sichtbare Posts gemeinsam und speichert Entscheidungen lokal zwischen
- verdeckt Medien bis zur sicheren Freigabe und pausiert Videos oder Audio sofort
- laesst nicht eindeutig pruefbare Medien vorsorglich blockiert, damit keine Vorschau als Umgehung dient
- behaelt den Einzelpost-, Subreddit- und Installer-Schutz der vorherigen Versionen bei

## Version 40

- behebt Aktualisierungsfehler bei einer gesperrten Installieren.exe
- beendet alte installierte Updater-Fenster gezielt vor dem Kopieren
- aktualisiert alle anderen Purestate-Dateien auch dann, wenn der Installer sich selbst erst nach dem Schliessen ersetzen kann
- prueft die zwischengespeicherte Installer-Datei per SHA256 vor und nach dem Ersatz

## Version 39

- blockiert auf Reddit auch einzelne als 18+ oder NSFW markierte Beitraege
- ersetzt solche Beitraege durch einen neutralen Purestate-Platzhalter ohne Freigabe-Knopf
- erkennt Markierungen ueber Reddit-Attribute, sichtbare Kennzeichen und eingebettete Beitragsdaten
- prueft dynamisch nachgeladene Beitraege beim Scrollen und bei Reddit-Navigationen
- normale Beitraege und normale Subreddits bleiben weiterhin nutzbar

## Version 38

- verhindert den Chrome-Fehler "Extension context invalidated" nach einem Erweiterungsupdate
- beendet veraltete Seitenpruefungen, sobald Chrome die alte Erweiterungsversion abschaltet
- laedt bereits offene Reddit-Tabs nach dem Update automatisch einmal neu

## Version 37

- behebt Aktualisierungsfehler, wenn Purestate.exe noch geoeffnet ist
- schliesst beim Aktualisieren gezielt nur die installierte Purestate-Verwaltungs-App
- wiederholt kurzzeitig blockierte Kopiervorgaenge und zeigt bei Problemen eine klare Meldung

## Version 36

- behebt die nicht ausgeloeste Sperre bei 18+-Communities wie r/long_porn
- erkennt eindeutige Erwachsenenbegriffe im Community-Namen lokal und ohne Netzwerkabfrage
- fragt Reddit-Metadaten mit der vorhandenen Reddit-Sitzung ueber zwei Reddit-Adressen ab
- erkennt 18+-Kennzeichnungen zusaetzlich direkt in Seitenattributen, Hinweisen und eingebetteten Community-Daten
- laesst Hilfs-Communities wie r/pornfree und r/nofap weiterhin zu

## Version 35

- erste Purestate Companion Browsererweiterung fuer Chrome und Edge
- erkennt besuchte Reddit-Communities direkt im Browser
- blockiert lokale NSFW-Subreddits aus extension\purestate-companion\rules\nsfw-subreddits.txt
- prueft zusaetzlich Reddit-about-Metadaten auf 18+
- zeigt eine neutrale Purestate-Blockseite statt Reddit komplett zu sperren
- ist als spaetere Sensor-Schicht fuer KI-Erkennung vorbereitet
- Vorabcheck, Integritaetscheck und Dienst-Selbsttest pruefen die Extension-Dateien

## Version 34

- staerkerer Reddit-Schutz fuer 18+-Communities
- neue Datei rules\nsfw-subreddits.txt fuer bekannte NSFW-Subreddits
- Purestate erzeugt daraus direkte Reddit-Blockregeln, auch wenn der Subreddit-Name keine eindeutigen Begriffe wie "porn" oder "nsfw" enthaelt
- Vorabcheck, Regelcheck, Integritaetscheck und Dienst-Selbsttest pruefen die neue Reddit-Liste
- Reddit bleibt grundsaetzlich nutzbar; die zusaetzlichen Regeln zielen auf bekannte 18+-Communities

## Version 33

- behebt einen Installationsfehler beim Schreiben der Windows-hosts-Datei
- Purestate nutzt dafuer jetzt einen robusteren direkten Dateischreiber
- ein moegliches Schreibschutz-Attribut der hosts-Datei wird vor dem Schreiben entfernt

## Version 32

- neuer neutraler Produktname: Purestate
- Purestate ist als private Selbstrestriktions-App angelegt, nicht nur als reine Pornografie-Blocker-App
- der erste Bereich heisst jetzt Inhalts-Schutz und bleibt auf pornografische Inhalte fokussiert
- Verwaltungs-App, Dienst, Deinstaller, Startmenue, Datenordner, Manifest und Berichte verwenden den Purestate-Namen
- die Oberflaeche ist sprachlich neutraler und laesst spaetere Selbstrestriktions-Module zu

## Version 31

- privater Selbstrestriktionsmodus ohne Cloud und ohne andere Personen
- Pausieren im Sperrmodus startet zuerst eine lokale 10-Minuten-Abkuehlzeit
- erst nach Ablauf der Abkuehlzeit kann die Pause erneut bestaetigt werden
- Einstellungen enthalten jetzt "Pausieren erst nach 10 Minuten Abkuehlzeit"
- Status zeigt eine laufende Abkuehlzeit als Pause-Hinweis
- Backup, Wiederherstellung, Schutztest, Diagnose und Gesundheitscheck kennen die Abkuehlzeit

## Version 30

- Sperrmodus fuer den vorgesehenen Schutzbetrieb
- Sperrmodus ist standardmaessig eingeschaltet
- Pausieren wird blockiert, solange der Sperrmodus aktiv ist
- Einstellungen enthalten jetzt "Sperrmodus: Pausieren blockieren"
- Schutztest und Gesundheitscheck bewerten den Sperrmodus als Teil der Schutzhaertung
- Status, Diagnose und Umgehungscheck zeigen den Sperrmodus an
- Wichtig: Fuer wirklich belastbaren Schutz sollte der geschuetzte Nutzer kein Windows-Administrator sein

## Version 29

- auswaehlbare Familien-DNS-Profile
- Cloudflare Family bleibt Standard
- CleanBrowsing Family und OpenDNS FamilyShield koennen in den Einstellungen gewaehlt werden
- Backup und Wiederherstellung enthalten das DNS-Profil
- Schutztest, Diagnose und Gesundheitscheck zeigen das gewaehlte DNS-Profil
- das Schutzskript prueft alle drei DNS-Profile im Selbsttest

## Version 28

- staerkere Nicht-KI-Erkennung fuer pornografische Inhalte auf gemischten Webseiten
- deutlich mehr erwachsene URL-Begriffe in rules\adult-url-keywords.txt
- mehr sichtbare Regeln in rules\mixed-site-url-patterns.txt
- neue automatische Muster fuer TikTok, Instagram, Pinterest, Imgur, Giphy, YouTube-Hashtags und X/Twitter-Hashtags
- Reddit, Tumblr und Suchmaschinen bleiben gezielt ueber Pfad-, Such- und Tag-Muster abgedeckt
- Schutztest, Regelcheck und Vorabcheck erwarten jetzt die groessere Regelabdeckung

## Version 27

- Manipulationsschutz fuer Proxy und Browser
- Windows-Proxy und PAC-Skripte werden waehrend aktivem Schutz gesichert und ausgeschaltet
- beim Entfernen des Schutzes werden die vorherigen Proxy-Einstellungen wiederhergestellt
- Chrome und Edge werden per Richtlinie auf direkten Netzwerkzugriff gesetzt
- Firefox bekommt zusaetzliche Proxy-Haertung ueber Richtlinien
- Einstellungen enthalten jetzt "Manipulationsschutz fuer Proxy und Browser"
- Diagnose, Gesundheit, Schutztest und Umgehungscheck zeigen Proxy-Schutz und Proxy-Status
- Reparieren setzt Proxy- und Browser-Haertung wieder neu, falls etwas veraendert wurde

## Version 26

- Browser-Kontrolle fuer nicht unterstuetzte Browser
- Chrome, Edge und Firefox bleiben die unterstuetzten Browser fuer Richtlinien und URL-Regeln
- bekannte andere Browser koennen per Windows-Firewall blockiert werden
- neue Datei rules\unsupported-browser-keywords.txt fuer transparente Browser-Begriffe
- Einstellungen enthalten jetzt "Nicht unterstuetzte Browser blockieren"
- Umgehungscheck, Diagnose, Gesundheit und Schutztest zeigen Browser-Block-Regeln
- Vorabcheck und Integritaetscheck pruefen die neue Browser-Regeldatei

## Version 25

- Zeitplan fuer taegliche Schutzzeiten
- Standardzeit im Dialog: 22:00 bis 06:00
- der Schutz kann im Zeitfenster automatisch wieder aktiv werden
- optionaler Strenger Modus verhindert Pausieren waehrend der aktive Zeitplan laeuft
- Status, Diagnose, Gesundheit und Schutztest zeigen den Zeitplan an
- Backup und Wiederherstellung enthalten Zeitplan und Strengen Modus
- Watchdog beachtet den Zeitplan und aktiviert den Schutz im Zeitfenster wieder

## Version 24

- Umgehungsschutz als eigene Schutzschicht
- bekannte VPN/Tor/Proxy/portable-Browser-Programme koennen per Windows-Firewall blockiert werden
- neue Datei rules\bypass-app-keywords.txt fuer transparente Umgehungs-App-Begriffe
- Einstellungen enthalten jetzt "VPN/Tor/Proxy-Umgehung blockieren"
- Umgehungscheck zeigt, ob die Schutzschicht eingeschaltet ist und wie viele Firewall-Regeln aktiv sind
- Diagnose, Gesundheit und Schutztest zeigen die Umgehungsschutz-Regeln
- Vorabcheck prueft Windows-Firewall-Funktionen und die neue Umgehungs-App-Liste

## Version 23

- bleibt weiterhin ohne KI und verbessert die lokale Grundabdeckung
- Haupt-Sperrliste deutlich erweitert
- beim Aktivieren werden automatisch Varianten mit und ohne www geschrieben
- Schutztest erwartet jetzt eine groessere lokale Domainabdeckung
- Vorabcheck und Integritaetscheck erkennen eine zu kleine Haupt-Sperrliste strenger

## Version 22

- bleibt bewusst ohne KI und nutzt zuerst robuste Regeltechnik
- neue Datei rules\adult-url-keywords.txt fuer erwachsene URL-Begriffe
- erzeugt automatisch viele URL-Regeln fuer Suchmaschinen und gemischte Plattformen
- blockiert typische Porno-/NSFW-Suchanfragen bei Google, Bing, DuckDuckGo, Brave Search, Yahoo, Yandex und YouTube-Suche
- erweitert gemischte Webseiten wie Reddit, Tumblr und X/Twitter ueber Keyword-Muster
- Schutztest, Diagnose, Gesundheit, Regelcheck und Integritaetscheck zeigen nun auch die Keyword-Schicht
- Vorabcheck prueft die Keyword-Datei und die daraus entstehenden URL-Regeln

## Version 21

- Pornografie-Blockierung steht staerker im Mittelpunkt
- neue URL-Regeln fuer gemischte Webseiten wie Reddit, Tumblr, X/Twitter
- gemischte Webseiten bleiben erreichbar, aber bekannte NSFW-/Porno-Bereiche werden blockiert
- Chrome und Edge bekommen eine verwaltete URLBlocklist
- Firefox bekommt WebsiteFilter-Regeln ueber seine Windows-Richtlinien
- Schutztest, Diagnose, Gesundheit, Regelcheck und Integritaetscheck zeigen die neuen URL-Regeln an
- Vorabcheck prueft, ob die Mixed-Site-Regeldatei im Paket vorhanden und plausibel ist

## Version 20

- Integritaetsmanifest im Paket
- Integritaetscheck vergleicht installierte Dateien mit Soll-Groesse und Soll-SHA-256
- Vorabcheck prueft, ob das Manifest im Paket vorhanden ist
- Integritaetscheck in der Verwaltungs-App prueft erwartete EXE-Dateien, Skripte und Regeldateien
- meldet fehlende, leere oder unplausible Dateien
- optionaler Passwort-Hinweis bei Installation und Passwortwechsel
- Passwortabfragen zeigen den Hinweis, aber nie das Passwort
- Sicherheitsprotokoll fuer wichtige Aktionen ohne Passwortinhalt
- zeitgesteuerte Pause: 15, 30, 60 Minuten, bis morgen oder unbegrenzt
- Regelcheck, Schutztest, Umgehungscheck und Gesundheitscheck in der Verwaltungs-App
- echter Installer als EXE mit Reparatur-/Update-Pfad
- Eintrag in Windows "Apps & Features" und Startmenue-Eintraege
- Domain-Manager, Allowlist und Domain-Test in der App
- Backup und Wiederherstellung fuer Einstellungen und eigene Domains
- erweiterter Browser-Umgehungsschutz fuer Chrome, Edge und Firefox
- SafeSearch-Richtlinien und gezielte YouTube-Regeln
