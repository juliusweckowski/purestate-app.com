#!/usr/bin/env bash
# First Caddy installation for the Purestate Authority server.
# Package source: https://caddyserver.com/docs/install#debian-ubuntu-raspbian
set -euo pipefail
umask 022
[[ $EUID -eq 0 ]] || { echo 'Run with sudo.' >&2; exit 1; }
[[ ! -e /etc/caddy/Caddyfile ]] || { echo 'Caddy configuration already exists; inspect it before continuing.' >&2; exit 1; }
systemctl is-active --quiet purestate-authority.service
getent ahostsv4 api.purestate-app.com | awk '{print $1}' | grep -qx '202.61.254.204' || {
    echo 'Set api.purestate-app.com A to 202.61.254.204 before continuing.' >&2
    exit 1
}
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y debian-keyring debian-archive-keyring apt-transport-https curl gnupg
curl --fail --silent --show-error --location https://dl.cloudsmith.io/public/caddy/stable/gpg.key \
    | gpg --batch --yes --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl --fail --silent --show-error --location https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt \
    -o /etc/apt/sources.list.d/caddy-stable.list
chmod 0644 /usr/share/keyrings/caddy-stable-archive-keyring.gpg /etc/apt/sources.list.d/caddy-stable.list

# Write the intended configuration before package installation starts Caddy.
install -d -m 0755 /etc/caddy
cat > /etc/caddy/Caddyfile <<'CADDY'
api.purestate-app.com {
    reverse_proxy 127.0.0.1:5199
}
CADDY
chmod 0644 /etc/caddy/Caddyfile
apt-get update
apt-get -o Dpkg::Options::=--force-confold install -y caddy
caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile
systemctl enable --now caddy
systemctl reload caddy
echo 'Caddy configured. Check public HTTPS and certificate issuance next.'
