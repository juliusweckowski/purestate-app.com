#!/usr/bin/env bash
# Create an encrypted, consistent snapshot. No plaintext leaves this server.
# Usage: sudo bash Backup-AuthorityServer.sh /path/to/backup-recipient.pub
set -euo pipefail
umask 077
[[ $EUID -eq 0 && $# -eq 1 ]] || { echo 'Usage: sudo bash Backup-AuthorityServer.sh recipient.pub' >&2; exit 1; }
recipient_file=$(realpath -- "$1")
[[ -s $recipient_file ]] || { echo 'Recipient file missing.' >&2; exit 1; }
command -v age >/dev/null || { echo 'Install age first: sudo apt-get install age' >&2; exit 1; }
[[ -s /var/lib/purestate-authority/authority.key && -s /var/lib/purestate-authority/authority.db ]]
staging=$(mktemp -d /run/purestate-backup.XXXXXXXX)
trap 'rm -rf -- "$staging"' EXIT
export PURESTATE_BACKUP_STAGE="$staging"

# SQLite's online backup API includes committed WAL contents without stopping
# the service. Key rotation is unsupported; the signing key is immutable.
python3 - <<'PY'
import os, pathlib, shutil, sqlite3, hashlib
stage = pathlib.Path(os.environ['PURESTATE_BACKUP_STAGE'])
with sqlite3.connect('file:/var/lib/purestate-authority/authority.db?mode=ro', uri=True) as src:
    with sqlite3.connect(stage / 'authority.db') as dst:
        src.backup(dst)
        assert dst.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', 'Database integrity check failed'
for source, target in [
    ('/var/lib/purestate-authority/authority.key', 'authority.key'),
    ('/etc/systemd/system/purestate-authority.service', 'purestate-authority.service'),
    ('/etc/caddy/Caddyfile', 'Caddyfile'),
]:
    shutil.copyfile(source, stage / target)
with (stage / 'SHA256SUMS').open('w') as manifest:
    for path in sorted(stage.iterdir()):
        if path.name != 'SHA256SUMS':
            manifest.write(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + path.name + '\n')
PY
install -d -m 0750 -o root -g pureadmin /var/backups/purestate
output=$(mktemp /var/backups/purestate/authority-"$(date -u +%Y%m%dT%H%M%SZ)"-XXXXXX.tar.gz.age)
if ! tar -czf - -C "$staging" . | age -R "$recipient_file" -o "$output"; then
    rm -f -- "$output"
    echo 'Encryption failed; incomplete output removed.' >&2
    exit 1
fi
chown root:pureadmin "$output"
chmod 0640 "$output"
sha256sum "$output"
echo 'Encrypted snapshot ready. Copy off-server and verify recovery before relying on it.'
