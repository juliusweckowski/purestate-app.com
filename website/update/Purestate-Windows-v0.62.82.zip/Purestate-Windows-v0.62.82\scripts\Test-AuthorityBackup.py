"""Verify an age-encrypted Authority snapshot entirely in memory.

Usage: python Test-AuthorityBackup.py ARCHIVE AGE_EXE IDENTITY EXPECTED_SHA256
Never prints secrets or extracts the private signing key to disk.
"""
import hashlib
import io
import pathlib
import sqlite3
import subprocess
import sys
import tarfile


def verify(archive, age, identity, expected_hash):
    encrypted = pathlib.Path(archive).read_bytes()
    if hashlib.sha256(encrypted).hexdigest() != expected_hash.lower():
        raise ValueError("Encrypted archive checksum mismatch")
    result = subprocess.run(
        [age, "--decrypt", "-i", identity], input=encrypted, capture_output=True
    )
    if result.returncode:
        raise ValueError("Archive decryption failed")
    expected_files = {"authority.key", "authority.db", "Caddyfile", "purestate-authority.service", "SHA256SUMS"}
    files = {}
    with tarfile.open(fileobj=io.BytesIO(result.stdout), mode="r:gz") as tar:
        for member in tar:
            if member.name == "." and member.isdir():
                continue
            name = member.name.removeprefix("./")
            if not member.isfile() or name not in expected_files or name in files:
                raise ValueError("Unexpected archive member")
            files[name] = tar.extractfile(member).read()
    if set(files) != expected_files:
        raise ValueError("Incomplete snapshot")
    checked = set()
    for line in files["SHA256SUMS"].decode("ascii").splitlines():
        digest, name = line.split("  ", 1)
        if name not in expected_files - {"SHA256SUMS"} or name in checked:
            raise ValueError("Unexpected manifest entry")
        if hashlib.sha256(files[name]).hexdigest() != digest:
            raise ValueError("Snapshot member checksum mismatch")
        checked.add(name)
    if checked != expected_files - {"SHA256SUMS"}:
        raise ValueError("Incomplete checksum manifest")
    with sqlite3.connect(":memory:") as database:
        database.deserialize(files["authority.db"])
        if database.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise ValueError("Database integrity check failed")
        for table in ("licenses", "devices"):
            count = database.execute("SELECT COUNT(*) FROM " + table).fetchone()[0]
            print(table + ": " + str(count) + " rows")
    # A damaged ciphertext must be rejected rather than silently restored.
    damaged = bytearray(encrypted)
    damaged[-1] ^= 1
    rejection = subprocess.run(
        [age, "--decrypt", "-i", identity], input=damaged, capture_output=True
    )
    if rejection.returncode == 0:
        raise ValueError("Corrupted ciphertext was accepted")
    print("PASS: archive checksum, decryption, member checksums, SQLite integrity, corruption rejection")
    print("No plaintext snapshot files were written to disk.")


if __name__ == "__main__":
    if len(sys.argv) != 5:
        raise SystemExit("Usage: Test-AuthorityBackup.py ARCHIVE AGE_EXE IDENTITY EXPECTED_SHA256")
    verify(*sys.argv[1:])
