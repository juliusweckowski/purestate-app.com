using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace Purestate
{
    // Video-games enforcement for the guard service. Compiled ONLY into
    // PurestateGuard.exe together with PurestateGuardService.cs, so it must
    // stay self-contained (no Purestate.Native.Support references). The
    // target parsing and safety validation mirror
    // src\NativeSupportVideoGames.cs; tests pin both sides against each other.
    //
    // What it does, once per guard tick (30s):
    //   off/planned  -> nothing is scanned, counted, or terminated.
    //   gentle       -> runtime of configured targets is accrued into a local
    //                   day counter; targets are closed only while the curfew
    //                   window is active or the daily runtime budget is used up
    //                   (a one-time neutral warning is sent ~5 minutes before).
    //   strict       -> enabled targets are always closed.
    // A 5-second start probe (RunStartProbe) only wakes this run early when a
    // target appears, so the remaining time is announced at game start.
    // "Runtime" is deliberately process runtime (the process exists), NOT
    // foreground play time - a session-0 service cannot reliably measure
    // foreground use across user sessions, and mislabeling is worse than the
    // narrower metric.
    internal sealed class VideoGamesGuardTarget
    {
        public bool Enabled = true;
        public string Name = string.Empty;
        public string Path = string.Empty;
    }

    internal sealed class VideoGamesGuardRules
    {
        public bool Enabled;
        public string Mode = "off";
        public bool DailyLimitEnabled;
        public int DailyLimitMinutes = 60;
        public bool CurfewEnabled;
        public string CurfewStart = "22:00";
        public string CurfewEnd = "06:00";
        // Wochenplan (0.62.87), normalisiert; "" = jeden Abend das Standardfenster.
        public string CurfewWeek = string.Empty;
        public bool AutoDetectEnabled;
        public bool HeuristicEnabled;
        public List<VideoGamesGuardTarget> Targets = new List<VideoGamesGuardTarget>();
    }

    internal sealed class VideoGamesUsageState
    {
        public string Day = string.Empty;
        public int UsedSeconds;
        public string LastSampleUtc = string.Empty;
        public bool WarnedToday;
        // Kleinste Schwelle in Minuten, zu der heute schon gewarnt wurde (0 =
        // noch keine). Frueher gab es nur eine Warnung bei 5 Minuten
        // (WarnedToday); die bleibt beim Laden als Schwelle 5 erhalten, damit
        // eine bestehende Datei nach dem Update nicht erneut warnt.
        public int WarnedThresholdMinutes;
        // USG-001: Datei war da, trug aber keine oder eine falsche Signatur.
        // Frueher hiess das "frischer Tag", also volles Budget - der
        // beschaedigte Zustand war eine Belohnung.
        public bool Damaged;
    }

    // Startet das Restzeit-Abzeichen in der Sitzung des angemeldeten Benutzers.
    //
    // Der Dienst laeuft als LocalSystem in Sitzung 0 und kann dort nichts
    // zeichnen (Befund L-10). Der einzige Weg in die Nutzersitzung, der auf
    // diesem Rechner nachweislich traegt, ist eine Aufgabe mit /RU <Nutzer> und
    // /IT.
    //
    // Fund 2026-10-18: Nach Windows-Updates verweigerte die Aufgabenplanung das
    // ERSETZEN der alten Aufgabe ("Das System kann den angegebenen Pfad nicht
    // finden"). Der Dienst gab jedes Mal still auf, und das Abzeichen blieb
    // aus, ohne dass im Protokoll eine Zeile stand. Deshalb: Ersetzen
    // scheitert -> loeschen und neu anlegen; und eine Aufgabe, die dieser Lauf
    // schon angelegt hat, wird nur noch gestartet, nicht jedes Mal ersetzt.
    //
    // Fund 2026-10-19: Die per Kommandozeile angelegte Aufgabe trug den
    // schtasks-Standard DisallowStartIfOnBatteries=true. Im Akkubetrieb
    // verweigert Windows den Start dann (0x800710E0), und der Dienst merkt es
    // nicht: /Run meldet Erfolg, die Ablehnung steht erst im "Letzten Ergebnis"
    // der Aufgabe. Deshalb wird sie wie die Tray- und die Oeffnen-Aufgabe ueber
    // XML angelegt.
    internal sealed class BadgeTaskLauncher
    {
        private readonly string taskName;
        private readonly Func<string, string> runSchtasks;
        private readonly string xmlPath;
        private string registered = string.Empty;
        private bool failing;

        // runSchtasks liefert null oder leer, wenn schtasks Erfolg meldet, sonst
        // dessen Meldung (nie leer). xmlPath ist die Datei, aus der die Aufgabe
        // angelegt wird; sie gehoert in den Datenordner (dort schreiben nur
        // SYSTEM und Administratoren), damit sie zwischen Schreiben und Anlegen
        // niemand austauschen kann.
        internal BadgeTaskLauncher(string taskName, Func<string, string> runSchtasks, string xmlPath)
        {
            this.taskName = taskName;
            this.runSchtasks = runSchtasks;
            this.xmlPath = xmlPath;
        }

        internal bool Launch(string owner, string exe, Action<string> log)
        {
            string run = "/Run /TN \"" + taskName + "\"";
            string key = owner + "|" + exe;
            if (string.Equals(key, registered, StringComparison.OrdinalIgnoreCase) && string.IsNullOrEmpty(runSchtasks(run)))
            {
                return Succeed(log);
            }
            registered = string.Empty;

            string error = Create(owner, exe);
            if (!string.IsNullOrEmpty(error))
            {
                runSchtasks("/Delete /TN \"" + taskName + "\" /F");
                string again = Create(owner, exe);
                if (!string.IsNullOrEmpty(again))
                {
                    return Fail(log, "Die Abzeichen-Aufgabe laesst sich nicht anlegen: " + again);
                }
                Write(log, "Videospiel-Abzeichen: Die Abzeichen-Aufgabe liess sich nicht ersetzen (" +
                    error + ") und wurde neu angelegt.");
            }

            string runError = runSchtasks(run);
            if (!string.IsNullOrEmpty(runError))
            {
                return Fail(log, "Die Abzeichen-Aufgabe laesst sich nicht starten: " + runError);
            }
            registered = key;
            return Succeed(log);
        }

        // Schreibt die Aufgabendatei, legt die Aufgabe daraus an (/F ersetzt eine
        // bestehende) und raeumt die Datei wieder weg. Liefert null bei Erfolg,
        // sonst die Meldung.
        private string Create(string owner, string exe)
        {
            try
            {
                File.WriteAllText(xmlPath, BuildTaskXml(owner, exe), Encoding.Unicode);
                return runSchtasks("/Create /TN \"" + taskName + "\" /XML \"" + xmlPath + "\" /F");
            }
            catch (Exception ex)
            {
                return "Aufgabendatei: " + ex.Message;
            }
            finally
            {
                try { File.Delete(xmlPath); } catch { }
            }
        }

        // HighestAvailable ist Pflicht, nicht Kosmetik: Purestate.exe traegt
        // requestedExecutionLevel="requireAdministrator". Ohne erhoehte Aufgabe
        // verweigert Windows den Start mit 0x800702E4 (ERROR_ELEVATION_REQUIRED)
        // - live gefunden (Befund V-7), das Abzeichen konnte auf diesem Weg nie
        // erscheinen. Mit erhoehter Aufgabe startet es ohne Rueckfrage, also ohne
        // UAC-Dialog im Spiel. InteractiveToken legt das Abzeichen in die Sitzung
        // des Benutzers (Befund L-10). Ohne Ausloeser: nur der Dienst startet die
        // Aufgabe; der Einmal-Ausloeser um 23:59 der Kommandozeilen-Anlage startete
        // das Abzeichen ohne Datei. IgnoreNew: der Dienst startet alle fuenf
        // Minuten erneut, ein laufendes Abzeichen soll nicht doppelt erscheinen.
        internal static string BuildTaskXml(string owner, string exe)
        {
            return "<?xml version=\"1.0\" encoding=\"UTF-16\"?>\r\n" +
                "<Task version=\"1.2\" xmlns=\"http://schemas.microsoft.com/windows/2004/02/mit/task\">\r\n" +
                "  <Triggers />\r\n" +
                "  <Principals><Principal id=\"Author\"><UserId>" + System.Security.SecurityElement.Escape(owner) + "</UserId>" +
                "<LogonType>InteractiveToken</LogonType><RunLevel>HighestAvailable</RunLevel></Principal></Principals>\r\n" +
                "  <Settings>\r\n" +
                "    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>\r\n" +
                "    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>\r\n" +
                "    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>\r\n" +
                "    <AllowStartOnDemand>true</AllowStartOnDemand>\r\n" +
                "  </Settings>\r\n" +
                "  <Actions Context=\"Author\"><Exec><Command>" + System.Security.SecurityElement.Escape(exe) +
                "</Command><Arguments>--badge</Arguments></Exec></Actions>\r\n" +
                "</Task>\r\n";
        }

        // Eine Dauerstoerung meldet das Protokoll einmal, nicht bei jedem
        // Versuch (alle 5 bis 15 Minuten); die Erholung ebenfalls einmal.
        private bool Fail(Action<string> log, string message)
        {
            if (!failing)
            {
                failing = true;
                Write(log, "Videospiel-Abzeichen: " + message + " Das Restzeit-Abzeichen erscheint so nicht.");
            }
            return false;
        }

        private bool Succeed(Action<string> log)
        {
            if (failing)
            {
                failing = false;
                Write(log, "Videospiel-Abzeichen: Der Start der Abzeichen-Aufgabe klappt wieder.");
            }
            return true;
        }

        private static void Write(Action<string> log, string message)
        {
            try
            {
                if (log != null)
                {
                    log(message.Replace('\r', ' ').Replace('\n', ' '));
                }
            }
            catch
            {
            }
        }
    }

    internal static class VideoGamesGuard
    {
        private const int TickSeconds = 30;
        private const int WarningRemainingMinutes = 5;
        // VG-003: Fuenf Sekunden waren fuer ein Vollbildspiel keine Frist.
        // CloseMainWindow schickt WM_CLOSE; ein Exklusiv-Vollbildspiel
        // reagiert oft gar nicht darauf oder oeffnet einen Bestaetigungsdialog,
        // den der Nutzer in fuenf Sekunden nicht findet - der Regelfall war
        // damit Kill() und der Fortschritt seit dem letzten Autosave weg.
        private const int CloseGracefullyWaitMilliseconds = 20000;
        private const int SecondCloseWaitMilliseconds = 10000;
        private const long MaxUsageFileBytes = 4096;
        private static DateTime lastBlockMessageUtc = DateTime.MinValue;

        [DllImport("wtsapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern bool WTSSendMessage(
            IntPtr hServer, int sessionId, string title, int titleLength,
            string message, int messageLength, int style, int timeoutSeconds,
            out int response, bool wait);

        [DllImport("kernel32.dll")]
        private static extern uint WTSGetActiveConsoleSessionId();

        private static string DataDirectory
        {
            get
            {
                return Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                    "Purestate");
            }
        }

        // internal: der Geraete-Abgleich liest den eigenen Spielzaehler von hier.
        internal static string UsagePath
        {
            get { return Path.Combine(DataDirectory, "video-games-usage.json"); }
        }

        private static string TargetsPath
        {
            get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules", "video-game-targets.txt"); }
        }

        // Entry point called from the guard's 30-second timer. Never throws.
        // Der Startfuehler (RunStartProbe) laeuft ueber denselben Weg; das
        // Schloss verhindert, dass zwei Laeufe gleichzeitig Zaehler und
        // Abzeichen schreiben.
        public static void Run(Action<string> log)
        {
            lock (runSync)
            {
                RunCore(log);
            }
        }

        private static void RunCore(Action<string> log)
        {
            try
            {
                // Nach dem Beta-Ende werden keine Spiele mehr geschlossen. Der
                // Schalter VideoGamesProtectionEnabled steht dann noch in der
                // Konfiguration, aber die abgelaufene Oberflaeche bietet ihn
                // nicht mehr an - ohne dieses Gate beendete der Guard weiter
                // Spiele, ohne dass ihn noch jemand abschalten koennte.
                if (GuardService.IsBetaExpired())
                {
                    return;
                }

                VideoGamesGuardRules rules = LoadRules();
                if (!rules.Enabled || (rules.Mode != "gentle" && rules.Mode != "strict"))
                {
                    return;
                }

                Process[] snapshot = Process.GetProcesses();
                try
                {
                    List<Process> running;
                    List<Process> heuristicMatches;
                    int totalRunning = FindTargetsRunning(rules, snapshot, log, out running, out heuristicMatches);

                    if (rules.Mode == "strict")
                    {
                        // Im strengen Modus gibt es keine Restzeit, also auch
                        // kein Abzeichen.
                        UpdateBadge(false, 0, string.Empty, string.Empty, log);
                        if (running.Count > 0)
                        {
                            NotifyUser("Purestate Videospiel-Schutz",
                                "Der strenge Videospiel-Schutz ist aktiv. Das ausgewaehlte Spiel wird beendet.");
                            string description = DescribeProcesses(running);
                            StopOutcome outcome = StopProcesses(running);
                            log("Videospiel-Schutz (streng): " + outcome.Total + " Zielprozess(e) (" +
                                outcome + "): " + description);
                        }
                        EnforceHeuristicCountdown(heuristicMatches, true, log);
                        return;
                    }

                    // Gentle mode: accrue runtime while at least one target
                    // (listed, store-detected, or heuristic) runs.
                    DateTime nowUtc = GuardService.ReadClockAnchorUtc();
                    DateTime nowLocal = nowUtc.ToLocalTime();
                    string today = GuardService.BudgetDayKey(nowLocal);
                    byte[] integrityKey = TryLoadUsageIntegrityKey();
                    VideoGamesUsageState state = LoadUsageState(UsagePath, today, integrityKey);
                    if (state.Damaged && rules.DailyLimitEnabled)
                    {
                        // USG-001: Wer den Zaehler von aussen schreibt, bekommt das
                        // Budget nicht geschenkt. Es gilt fuer heute als aufgebraucht
                        // und wird sofort sauber signiert zurueckgeschrieben, damit
                        // der naechste Takt wieder normal liest.
                        state.Damaged = false;
                        state.UsedSeconds = rules.DailyLimitMinutes * 60;
                        state.LastSampleUtc = nowUtc.ToString("o");
                        SaveUsageState(UsagePath, state, integrityKey);
                        log("Videospiel-Schutz: Laufzeitzaehler ohne gueltige Signatur - Tagesbudget gilt als aufgebraucht.");
                    }

                    // Geraete-Abgleich: das strengste Limit der anderen gilt hier mit. Es aendert nur
                    // diese Regeln im Speicher, nie config.json. Erst nach dem Befund am Zaehler: der obige
                    // Zweig sieht so nur das eigene Limit. Mit dem fremden davor schriebe ein Speicherfehler
                    // auf einem Geraet ohne eigenes Limit dessen Limit * 60 als eigene Spielzeit fest, und der
                    // naechste Export veroeffentlichte sie - das Budget der anderen Geraete waere heute weg.
                    GuardService.ApplyDeviceSyncGameLimit(rules, nowUtc);

                    if (totalRunning > 0)
                    {
                        state.UsedSeconds += ComputeAccrualSeconds(state.LastSampleUtc, nowUtc, TickSeconds);
                        state.LastSampleUtc = nowUtc.ToString("o");
                        SaveUsageState(UsagePath, state, integrityKey);
                    }

                    string curfewUntil;
                    bool curfewActive = CurfewWeekActive(rules.CurfewEnabled, rules.CurfewStart, rules.CurfewEnd, rules.CurfewWeek, nowLocal, out curfewUntil);
                    // Die Spielzeit der anderen Geraete zaehlt in die Grenze und die Restzeit, steht
                    // aber nie in state.UsedSeconds und damit nie in der Datei (gleicher Zeitraum
                    // wie die eigene Zeit, state.Day).
                    int usedWithPeers = GuardService.DeviceSyncWithForeign(
                        state.UsedSeconds, "games", state.Day, GuardService.MonthOfDay(state.Day));
                    bool limitReached = rules.DailyLimitEnabled &&
                        usedWithPeers >= rules.DailyLimitMinutes * 60;

                    int remaining = rules.DailyLimitMinutes * 60 - usedWithPeers;

                    // Spielstart = der Uebergang von "kein Ziel lief" zu "ein Ziel
                    // laeuft". Dann wird die Restzeit angesagt, auch wenn das
                    // Abzeichen sonst erst in der letzten halben Stunde erscheint.
                    bool gameStarted = ShouldAnnounceStart(
                        rules.DailyLimitEnabled, gameWasRunning, totalRunning > 0, curfewActive || limitReached);
                    // Bei langem Budget kommt dieselbe Ansage alle 15 Minuten wieder.
                    bool reminderDue = !gameStarted && ShouldAnnounceReminder(
                        rules.DailyLimitEnabled, totalRunning > 0, curfewActive || limitReached, remaining,
                        lastAnnouncementUtc, DateTime.UtcNow);
                    gameWasRunning = totalRunning > 0;
                    if (gameStarted || reminderDue)
                    {
                        startNoticeText = BuildStartNotice(remaining);
                        startNoticeUntilUtc = DateTime.UtcNow.AddSeconds(NoticeSeconds);
                        lastAnnouncementUtc = DateTime.UtcNow;
                    }

                    string notice = string.Empty;
                    if (totalRunning > 0 && !curfewActive && !limitReached && rules.DailyLimitEnabled)
                    {
                        // Die Schwellen 30/15/5 liefen frueher ueber
                        // WTSSendMessage - ein echtes Meldefenster mitten im
                        // Bild, mit Fokus und OK-Knopf. Live abgelehnt
                        // (Befund V-6): mitten im Spiel wegklicken zu muessen
                        // ist genau die Stoerung, die der Schutz nicht braucht.
                        // Die Warnung traegt jetzt das Abzeichen, das ohnehin
                        // ab 30 Minuten Rest sichtbar ist und weder Fokus noch
                        // Klick verlangt.
                        int dueThreshold = NextWarningThreshold(remaining, state.WarnedThresholdMinutes);
                        if (dueThreshold > 0)
                        {
                            notice = "Noch " + dueThreshold + " min - guter Moment zum Speichern";
                            state.WarnedThresholdMinutes = dueThreshold;
                            state.WarnedToday = true;
                            SaveUsageState(UsagePath, state, integrityKey);
                        }
                    }

                    // Solange die Ansage steht, bleibt sie auch ueber einen weiteren
                    // Lauf hinweg stehen: der Startfuehler loest den ersten Lauf
                    // mitten im 30-Sekunden-Takt aus, und der naechste Takt darf die
                    // Ansage nicht nach wenigen Sekunden wegnehmen.
                    bool announcingStart = totalRunning > 0 && !curfewActive && !limitReached &&
                        rules.DailyLimitEnabled && DateTime.UtcNow < startNoticeUntilUtc;
                    if (announcingStart)
                    {
                        notice = startNoticeText;
                    }

                    UpdateBadge(
                        announcingStart ||
                            ShouldShowBadge(rules.DailyLimitEnabled, totalRunning > 0 && !curfewActive && !limitReached, remaining),
                        remaining,
                        FirstProcessName(running.Count > 0 ? running : heuristicMatches),
                        notice,
                        log);

                    if (running.Count > 0 && (curfewActive || limitReached))
                    {
                        if ((DateTime.UtcNow - lastBlockMessageUtc) > TimeSpan.FromMinutes(5))
                        {
                            lastBlockMessageUtc = DateTime.UtcNow;
                            NotifyUser("Purestate Videospiel-Schutz", curfewActive
                                ? "Die Videospiel-Sperrzeit ist aktiv. Das Spiel wird beendet und bleibt bis zum Ende der Sperrzeit gesperrt."
                                : "Das heutige Videospiel-Zeitbudget ist erreicht. Das Spiel wird beendet und bleibt bis zum naechsten Tag gesperrt.");
                        }
                        string description = DescribeProcesses(running);
                        StopOutcome outcome = StopProcesses(running);
                        log("Videospiel-Schutz (sanft): " + outcome.Total + " Zielprozess(e) (" +
                            (curfewActive ? "Sperrzeit" : "Tagesbudget") + ", " + outcome + "): " + description);
                    }
                    EnforceHeuristicCountdown(heuristicMatches, curfewActive || limitReached, log);
                }
                finally
                {
                    foreach (Process process in snapshot)
                    {
                        try { process.Dispose(); } catch { }
                    }
                }
            }
            catch (Exception ex)
            {
                try { log("Videospiel-Schutz Fehler: " + ex.Message); } catch { }
            }
        }

        // Gelistete Ziele, Store-Treffer und Heuristik-Treffer eines
        // Prozess-Schnappschusses - vom Takt und vom Startfuehler gemeinsam
        // benutzt, damit beide dieselbe Antwort auf "laeuft ein Spiel" geben.
        private static int FindTargetsRunning(
            VideoGamesGuardRules rules, Process[] snapshot, Action<string> log,
            out List<Process> running, out List<Process> heuristicMatches)
        {
            HashSet<int> claimedIds = new HashSet<int>();
            running = FindRunningTargets(snapshot, rules.Targets, claimedIds);
            heuristicMatches = new List<Process>();
            if (rules.AutoDetectEnabled)
            {
                List<Process> candidates = new List<Process>();
                foreach (Process process in snapshot)
                {
                    int processId;
                    try { processId = process.Id; } catch { continue; }
                    if (!claimedIds.Contains(processId))
                    {
                        candidates.Add(process);
                    }
                }
                DetectionMatches detected = VideoGameDetection.MatchProcesses(
                    candidates,
                    VideoGameDetection.GetStoreGameDirectories(log),
                    VideoGameDetection.LoadActiveExemptions(),
                    rules.HeuristicEnabled,
                    Environment.GetFolderPath(Environment.SpecialFolder.Windows),
                    AppDomain.CurrentDomain.BaseDirectory,
                    log);
                // Store matches are certain (path-based) and get the
                // same immediate enforcement as listed targets.
                running.AddRange(detected.StoreMatches);
                heuristicMatches = detected.HeuristicMatches;
            }
            return running.Count + heuristicMatches.Count;
        }

        // Schneller Startfuehler (alle fuenf Sekunden, vom Dienst gerufen). Der
        // 30-Sekunden-Takt haette die Restzeit erst bis zu eine halbe Minute nach
        // dem Spielstart angesagt (Tester-Notiz 2026-10-06: "direkt beim Starten").
        // Der Fuehler rechnet nichts selbst: sieht er ein neu gestartetes Ziel,
        // ruft er den normalen Lauf, der Zeit bucht, ansagt und durchsetzt. Waehrend
        // ein Spiel laeuft, kostet er nichts (gameWasRunning). Nur im sanften Modus
        // mit Tageslimit - alles andere hat nichts anzusagen.
        public static void RunStartProbe(Action<string> log)
        {
            if (Interlocked.Exchange(ref startProbeRunning, 1) == 1)
            {
                return;
            }
            try
            {
                if (gameWasRunning || GuardService.IsBetaExpired())
                {
                    return;
                }
                VideoGamesGuardRules rules = LoadRules();
                if (!rules.Enabled || rules.Mode != "gentle" || !rules.DailyLimitEnabled)
                {
                    return;
                }
                Process[] snapshot = Process.GetProcesses();
                try
                {
                    List<Process> running;
                    List<Process> heuristicMatches;
                    if (FindTargetsRunning(rules, snapshot, log, out running, out heuristicMatches) > 0)
                    {
                        Run(log);
                    }
                }
                finally
                {
                    foreach (Process process in snapshot)
                    {
                        try { process.Dispose(); } catch { }
                    }
                }
            }
            catch (Exception ex)
            {
                try { log("Videospiel-Startfuehler Fehler: " + ex.Message); } catch { }
            }
            finally
            {
                Interlocked.Exchange(ref startProbeRunning, 0);
            }
        }

        // ---- Rules -----------------------------------------------------------

        internal static VideoGamesGuardRules LoadRules()
        {
            string configPath = Path.Combine(DataDirectory, "config.json");
            string json = string.Empty;
            try
            {
                if (File.Exists(configPath))
                {
                    json = File.ReadAllText(configPath, Encoding.UTF8);
                }
            }
            catch
            {
                return new VideoGamesGuardRules();
            }

            VideoGamesGuardRules rules = ParseRules(json);
            rules.Targets = LoadTargets(TargetsPath,
                Environment.GetFolderPath(Environment.SpecialFolder.Windows),
                AppDomain.CurrentDomain.BaseDirectory);
            return rules;
        }

        // Die Regeln aus config.json, ohne Zielliste. Ein Standardfenster mit
        // gleichem Start und Ende schaltet die Sperrzeit nicht mehr ganz ab:
        // ein Abend mit eigener Zeit gilt trotzdem (CurfewWeekActive).
        internal static VideoGamesGuardRules ParseRules(string json)
        {
            VideoGamesGuardRules rules = new VideoGamesGuardRules();
            rules.Enabled = ReadJsonBool(json, "VideoGamesProtectionEnabled", false);
            rules.Mode = ReadJsonString(json, "VideoGamesProtectionMode", "off").Trim().ToLowerInvariant();
            rules.DailyLimitEnabled = ReadJsonBool(json, "VideoGamesDailyLimitEnabled", false);
            int limitMinutes = ReadJsonInt(json, "VideoGamesDailyLimitMinutes", 60);
            rules.DailyLimitMinutes = (limitMinutes >= 5 && limitMinutes <= 600) ? limitMinutes : 60;
            rules.AutoDetectEnabled = ReadJsonBool(json, "VideoGamesAutoDetectEnabled", false);
            rules.HeuristicEnabled = ReadJsonBool(json, "VideoGamesHeuristicEnabled", false);
            rules.CurfewEnabled = ReadJsonBool(json, "VideoGamesCurfewEnabled", false);
            rules.CurfewStart = ReadJsonString(json, "VideoGamesCurfewStart", "22:00");
            rules.CurfewEnd = ReadJsonString(json, "VideoGamesCurfewEnd", "06:00");
            rules.CurfewWeek = NormalizeCurfewWeek(ReadJsonString(json, "VideoGamesCurfewWeek", string.Empty));
            return rules;
        }

        internal static List<VideoGamesGuardTarget> LoadTargets(string path, string windowsDir, string installDir)
        {
            List<VideoGamesGuardTarget> targets = new List<VideoGamesGuardTarget>();
            try
            {
                if (!File.Exists(path))
                {
                    return targets;
                }

                HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (string raw in File.ReadAllLines(path, Encoding.UTF8))
                {
                    VideoGamesGuardTarget target = ParseTargetLine(raw, windowsDir, installDir);
                    if (target == null || !seen.Add(target.Path))
                    {
                        continue;
                    }
                    targets.Add(target);
                }
            }
            catch
            {
            }
            return targets;
        }

        // Mirrors Support.ParseVideoGameTargetLine (pinned by tests). Malformed
        // or unsafe lines are dropped so a hand-edited file can never turn the
        // guard against a critical process.
        internal static VideoGamesGuardTarget ParseTargetLine(string line, string windowsDir, string installDir)
        {
            string trimmed = (line ?? string.Empty).Trim();
            if (trimmed.Length == 0 || trimmed.StartsWith("#", StringComparison.Ordinal))
            {
                return null;
            }

            string[] parts = trimmed.Split(new[] { '|' }, 4);
            if (parts.Length != 4)
            {
                return null;
            }

            string path = parts[3].Trim();
            if (!IsSafeTargetPath(path, windowsDir, installDir))
            {
                return null;
            }

            return new VideoGamesGuardTarget
            {
                Enabled = parts[0].Trim() == "1",
                Name = parts[2].Trim(),
                Path = Path.GetFullPath(path)
            };
        }

        // Mirrors Support.ValidateVideoGameTargetPath (pinned by tests).
        private static readonly string[] CriticalTargetFileNames =
        {
            "smss.exe", "csrss.exe", "wininit.exe", "winlogon.exe", "services.exe",
            "lsass.exe", "svchost.exe", "dwm.exe", "explorer.exe", "taskmgr.exe",
            "conhost.exe", "cmd.exe", "powershell.exe", "powershell_ise.exe", "pwsh.exe",
            "regedit.exe", "mmc.exe", "msiexec.exe", "dllhost.exe", "runtimebroker.exe",
            "sihost.exe", "fontdrvhost.exe", "ctfmon.exe", "logonui.exe", "userinit.exe",
            "msmpeng.exe", "nissrv.exe", "mpcmdrun.exe", "securityhealthservice.exe",
            "securityhealthsystray.exe",
            "purestate.exe", "purestateguard.exe", "purestatenativehost.exe",
            "purestateuninstaller.exe", "installieren.exe"
        };

        internal static bool IsSafeTargetPath(string path, string windowsDir, string installDir)
        {
            string trimmed = (path ?? string.Empty).Trim();
            if (trimmed.Length == 0)
            {
                return false;
            }

            string fullPath;
            try
            {
                if (!Path.IsPathRooted(trimmed))
                {
                    return false;
                }
                fullPath = Path.GetFullPath(trimmed);
            }
            catch
            {
                return false;
            }

            string root = Path.GetPathRoot(fullPath) ?? string.Empty;
            if (root.Length < 2 || (root.Length == 2 && root[1] == Path.VolumeSeparatorChar))
            {
                return false;
            }

            if (!string.Equals(Path.GetExtension(fullPath), ".exe", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            if (IsInsideDirectory(fullPath, windowsDir) || IsInsideDirectory(fullPath, installDir))
            {
                return false;
            }

            string fileName = Path.GetFileName(fullPath);
            foreach (string critical in CriticalTargetFileNames)
            {
                if (string.Equals(fileName, critical, StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        private static bool IsInsideDirectory(string fullPath, string directory)
        {
            if (string.IsNullOrWhiteSpace(directory))
            {
                return false;
            }
            string normalized;
            try
            {
                normalized = Path.GetFullPath(directory)
                    .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            }
            catch
            {
                return false;
            }
            return fullPath.StartsWith(normalized, StringComparison.OrdinalIgnoreCase);
        }

        // ---- Process matching ------------------------------------------------

        // One shared process snapshot per tick (the caller owns disposal). A
        // process counts as a target ONLY when its main-module full path
        // equals a configured, enabled target path (name alone never kills -
        // a same-named process at a different path stays untouched).
        // Processes whose path cannot be read are skipped: no false positives
        // at the price of a documented rename/copy bypass limit. Matched
        // process ids land in claimedIds so the detection layer skips them.
        private static List<Process> FindRunningTargets(Process[] snapshot, List<VideoGamesGuardTarget> targets, HashSet<int> claimedIds)
        {
            List<Process> matches = new List<Process>();
            Dictionary<string, List<VideoGamesGuardTarget>> byFileName =
                new Dictionary<string, List<VideoGamesGuardTarget>>(StringComparer.OrdinalIgnoreCase);
            foreach (VideoGamesGuardTarget target in targets)
            {
                if (!target.Enabled)
                {
                    continue;
                }
                string key = Path.GetFileNameWithoutExtension(target.Path);
                List<VideoGamesGuardTarget> list;
                if (!byFileName.TryGetValue(key, out list))
                {
                    list = new List<VideoGamesGuardTarget>();
                    byFileName[key] = list;
                }
                list.Add(target);
            }

            if (byFileName.Count == 0)
            {
                return matches;
            }

            foreach (Process process in snapshot)
            {
                try
                {
                    List<VideoGamesGuardTarget> candidates;
                    if (byFileName.TryGetValue(process.ProcessName, out candidates))
                    {
                        string processPath = VideoGameDetection.GetProcessImagePath(process);
                        if (!string.IsNullOrEmpty(processPath))
                        {
                            string fullProcessPath = Path.GetFullPath(processPath);
                            foreach (VideoGamesGuardTarget candidate in candidates)
                            {
                                if (string.Equals(fullProcessPath, candidate.Path, StringComparison.OrdinalIgnoreCase))
                                {
                                    matches.Add(process);
                                    claimedIds.Add(process.Id);
                                    break;
                                }
                            }
                        }
                    }
                }
                catch
                {
                    // Access denied / exited between enumeration and inspection.
                }
            }
            return matches;
        }

        // Heuristic hits are killed with a save warning instead of
        // immediately: a false positive must never cost unsaved work without
        // notice. A freshly classified path gets a one-time 5-minute window
        // (time to save and file an exemption), every later countdown is 60
        // seconds. Outside every kill condition the pending countdowns are
        // dropped, so a later block starts a fresh warning window.
        private static void EnforceHeuristicCountdown(List<Process> heuristicMatches, bool killCondition, Action<string> log)
        {
            if (!killCondition)
            {
                VideoGameDetection.ClearCountdowns();
                return;
            }
            if (heuristicMatches.Count == 0)
            {
                return;
            }

            List<Process> newlyAnnounced;
            List<Process> newlyAnnouncedFirstWindow;
            // Stoppuhr statt Wanduhr: die 60 Sekunden bis zum Beenden brauchen
            // kein Datum, und wer die Uhr wiederholt zurueckstellt, erreichte
            // das Fristende sonst nie (Befund KIL-001).
            List<Process> due = VideoGameDetection.TakeDueCountdownKills(heuristicMatches, VideoGameDetection.MonotonicNowUtc(), out newlyAnnounced, out newlyAnnouncedFirstWindow);
            if (newlyAnnouncedFirstWindow.Count > 0)
            {
                NotifyUser("Purestate Videospiel-Schutz",
                    "Ein laufendes Programm wurde erstmals als Spiel eingestuft und wird in 5 Minuten beendet. Bitte jetzt speichern. Falls das kein Spiel ist, kann eine Ausnahme in der Purestate-App eingetragen werden.");
            }
            if (newlyAnnounced.Count > 0)
            {
                NotifyUser("Purestate Videospiel-Schutz",
                    "Ein laufendes Programm wurde als Spiel eingestuft und wird in 60 Sekunden beendet. Bitte jetzt speichern.");
            }
            if (due.Count > 0)
            {
                string description = DescribeProcesses(due);
                StopOutcome outcome = StopProcesses(due);
                log("Videospiel-Schutz: " + outcome.Total +
                    " per Heuristik erkannte(r) Prozess(e) nach Countdown (" + outcome + "): " + description);
            }
        }

        // Live gefunden (Befund V-2, 2026-08-06): das Protokoll meldete nur die
        // ANZAHL beendeter Prozesse. Als der strenge Modus sieben Prozesse auf
        // einmal beendete, war aus keiner Datei rekonstruierbar, welche - und
        // damit weder eine Ausnahme eintragbar noch der Fehler meldbar. Genau
        // deshalb blieb Befund V-1 (Wallpaper Engine) so lange unentdeckt.
        // Muss VOR dem Beenden gerufen werden, danach ist der Pfad weg.
        internal static string DescribeProcesses(List<Process> processes)
        {
            const int MaxNamed = 10;
            List<string> parts = new List<string>();
            foreach (Process process in processes ?? new List<Process>())
            {
                if (parts.Count >= MaxNamed)
                {
                    parts.Add("... (" + (processes.Count - MaxNamed) + " weitere)");
                    break;
                }
                string path;
                try
                {
                    path = VideoGameDetection.GetProcessImagePath(process);
                }
                catch
                {
                    path = string.Empty;
                }
                if (string.IsNullOrEmpty(path))
                {
                    try { path = process.ProcessName; } catch { path = "unbekannt"; }
                }
                parts.Add(path);
            }
            if (parts.Count == 0)
            {
                return "unbekannt";
            }
            return string.Join(", ", parts.ToArray());
        }

        // Graceful first (gives the game a chance to run its own save/cleanup
        // handlers), hard kill only for what is still alive afterwards.
        private static StopOutcome StopProcesses(List<Process> processes)
        {
            List<int> indexes = new List<int>();
            for (int index = 0; index < processes.Count; index++)
            {
                indexes.Add(index);
            }

            return StopWithGracePeriods(
                indexes,
                delegate(int index)
                {
                    try
                    {
                        if (processes[index].MainWindowHandle != IntPtr.Zero)
                        {
                            processes[index].CloseMainWindow();
                        }
                    }
                    catch
                    {
                    }
                },
                delegate(int index) { return IsProcessAlive(processes[index]); },
                delegate(int index)
                {
                    try
                    {
                        processes[index].Kill();
                        return true;
                    }
                    catch
                    {
                        // Zugriff verweigert, Anti-Cheat, oder der Prozess ist
                        // zwischen Pruefung und Aufruf doch noch verschwunden.
                        // Der Aufrufer zaehlt das als "nicht zu beenden" - genau
                        // die Zahl, die vorher nirgends auftauchte.
                        return false;
                    }
                },
                delegate(int waitMilliseconds) { WaitWhileAnyAlive(processes, waitMilliseconds); },
                CloseGracefullyWaitMilliseconds,
                SecondCloseWaitMilliseconds);
        }

        private static void WaitWhileAnyAlive(List<Process> processes, int waitMilliseconds)
        {
            DateTime deadline = DateTime.UtcNow.AddMilliseconds(waitMilliseconds);
            while (DateTime.UtcNow < deadline)
            {
                bool anyAlive = false;
                foreach (Process process in processes)
                {
                    if (IsProcessAlive(process))
                    {
                        anyAlive = true;
                        break;
                    }
                }
                if (!anyAlive)
                {
                    return;
                }
                Thread.Sleep(250);
            }
        }

        // Lebt der Prozess noch? Process.HasExited braucht das Recht
        // PROCESS_QUERY_INFORMATION. Ein Anti-Cheat-Treiber (Riot Vanguard) und
        // geschuetzte Systemprozesse nehmen es weg, dann wirft HasExited
        // Win32Exception "Zugriff verweigert" (an csrss.exe nachgestellt). Frueher
        // galt jede Ausnahme als "beendet": ein laufendes, geschuetztes Spiel
        // wurde als "selbst beendet" gemeldet und nie angefasst. Bei einer
        // Ausnahme entscheidet jetzt die Prozessliste (braucht kein Handle); ist
        // auch die nicht zu haben, gilt der Prozess als lebendig.
        internal static bool ProbeAlive(Func<bool> hasExited, Func<bool> processExists)
        {
            try
            {
                return !hasExited();
            }
            catch
            {
            }

            try
            {
                return processExists();
            }
            catch
            {
                return true;
            }
        }

        internal static bool IsProcessAlive(Process process)
        {
            return ProbeAlive(
                delegate { return process.HasExited; },
                delegate
                {
                    try
                    {
                        using (Process.GetProcessById(process.Id))
                        {
                            return true;
                        }
                    }
                    catch (ArgumentException)
                    {
                        // Keine Prozess-ID dieser Art mehr in der Liste.
                        return false;
                    }
                });
        }

        // VG-003: Zwei Schonzyklen. Wer nach dem ersten WM_CLOSE noch lebt,
        // bekommt ein zweites und noch einmal Zeit; hart beendet wird nur, was
        // danach immer noch laeuft. Kostet im schlechtesten Fall eine halbe
        // Minute Spielzeit und rettet im besten den Spielstand.
        // VG-004: Gezaehlt wurde schlicht die Zahl der uebergebenen Prozesse -
        // unabhaengig davon, was mit ihnen geschah. Das Protokoll meldete damit
        // mehr Eingriffe als stattgefunden haben, und genau diese Zahl wird zur
        // Diagnose herangezogen. Schlimmer: ein Prozess, den Purestate NICHT
        // beenden konnte (Zugriff verweigert, Anti-Cheat), hinterliess gar keine
        // Spur. Die drei Ausgaenge sind jetzt getrennt.
        internal sealed class StopOutcome
        {
            public int ClosedThemselves;
            public int Killed;
            public int Failed;

            public int Total
            {
                get { return ClosedThemselves + Killed + Failed; }
            }

            public override string ToString()
            {
                return "selbst beendet: " + ClosedThemselves +
                    ", hart beendet: " + Killed +
                    ", nicht zu beenden: " + Failed;
            }
        }

        internal static StopOutcome StopWithGracePeriods(
            IEnumerable<int> ids,
            Action<int> requestClose,
            Func<int, bool> isAlive,
            Func<int, bool> kill,
            Action<int> waitForExit,
            int firstWaitMilliseconds,
            int secondWaitMilliseconds)
        {
            List<int> all = new List<int>(ids ?? new int[0]);
            StopOutcome outcome = new StopOutcome();

            foreach (int waitMilliseconds in new[] { firstWaitMilliseconds, secondWaitMilliseconds })
            {
                bool anyAlive = false;
                foreach (int id in all)
                {
                    if (isAlive(id))
                    {
                        requestClose(id);
                        anyAlive = true;
                    }
                }
                if (!anyAlive)
                {
                    outcome.ClosedThemselves = all.Count;
                    return outcome;
                }
                waitForExit(waitMilliseconds);
            }

            foreach (int id in all)
            {
                if (!isAlive(id))
                {
                    outcome.ClosedThemselves++;
                    continue;
                }

                if (kill(id))
                {
                    outcome.Killed++;
                }
                else
                {
                    outcome.Failed++;
                }
            }

            return outcome;
        }

        // ---- Usage accounting --------------------------------------------------

        // The counter never resets on a clock that was turned BACK: the day
        // only rolls over when the current local date is ordinally greater
        // than the stored one, so "set the clock to yesterday" does not grant
        // a fresh budget.
        internal static bool ShouldResetDay(string storedDay, string currentDay)
        {
            if (string.IsNullOrWhiteSpace(storedDay))
            {
                return true;
            }
            return string.CompareOrdinal(currentDay, storedDay) > 0;
        }

        // Each accrual is clamped to at most twice the tick interval so a
        // suspended machine (standby/hibernate) or a forward clock jump can
        // never book hours of "runtime" from a single sample gap.
        internal static int ComputeAccrualSeconds(string lastSampleUtcText, DateTime nowUtc, int tickSeconds)
        {
            DateTime lastSample;
            if (!DateTime.TryParse(lastSampleUtcText, null, System.Globalization.DateTimeStyles.RoundtripKind, out lastSample))
            {
                return tickSeconds;
            }

            double elapsed = (nowUtc - lastSample.ToUniversalTime()).TotalSeconds;
            if (elapsed < 0)
            {
                // Rueckwaerts gesprungene Uhr: einen Takt buchen. Wer die Zeit
                // zurueckstellt, darf damit keine Freizeit gewinnen.
                return tickSeconds;
            }
            if (elapsed == 0)
            {
                // Live gefunden (Befund V-5, 2026-08-06): der Zeitanker wird nur
                // etwa einmal pro Minute geschrieben, der Guard tickt aber alle
                // 30 Sekunden. Stand der Anker still, buchte der Lauf trotzdem
                // einen vollen Takt - und beim naechsten Takt, wenn der Anker um
                // 60 Sekunden springt, noch einmal dieselbe Minute. Gemessen
                // waren das +60 und +89 Sekunden je 32 Sekunden echter
                // Spielzeit, also rund das Anderthalbfache. Steht der Anker,
                // ist keine vertrauenswuerdige Zeit vergangen: 0 buchen. Der
                // naechste Takt holt die volle Minute nach.
                return 0;
            }
            return (int)Math.Min(elapsed, tickSeconds * 2);
        }

        internal static bool TryParseTimeText(string value, out int minutes)
        {
            minutes = 0;
            Match match = Regex.Match((value ?? string.Empty).Trim(), @"^(\d{1,2}):(\d{2})$");
            if (!match.Success)
            {
                return false;
            }
            int hour;
            int minute;
            if (!int.TryParse(match.Groups[1].Value, out hour) || !int.TryParse(match.Groups[2].Value, out minute) ||
                hour < 0 || hour > 23 || minute < 0 || minute > 59)
            {
                return false;
            }
            minutes = hour * 60 + minute;
            return true;
        }

        // Wochenplan der Sperrzeit (0.62.87): sieben Eintraege Mo..So, je
        // "std" (Standardfenster), "off" (keine Sperre an diesem Abend) oder
        // "HH:MM-HH:MM". Ein Eintrag gehoert zum Abend, an dem die Sperre
        // beginnt; vor 04:00 ist noch die Nacht des Vorabends, wie beim
        // Budget-Tag. "" heisst: jeden Abend das Standardfenster. Eine falsche
        // Anzahl oder ein unlesbarer Eintrag ergibt "" - nie etwas Lockereres
        // als den Standard. Vertrag fuer Waechter, App und Companion:
        // tests/fixtures/curfew-week-cases.json. Zwilling: Support.NormalizeCurfewWeek.
        internal static string NormalizeCurfewWeek(string text)
        {
            string[] parts = (text ?? string.Empty).Split(',');
            if (parts.Length != 7)
            {
                return string.Empty;
            }

            string[] tokens = new string[7];
            bool allStandard = true;
            for (int i = 0; i < 7; i++)
            {
                string token = parts[i].Trim().ToLowerInvariant();
                if (token != "std" && token != "off")
                {
                    string[] times = token.Split('-');
                    int start;
                    int end;
                    if (times.Length != 2 || !TryParseTimeText(times[0], out start) || !TryParseTimeText(times[1], out end))
                    {
                        return string.Empty;
                    }
                    token = start == end ? "off" : CurfewClockText(start) + "-" + CurfewClockText(end);
                }
                tokens[i] = token;
                allStandard = allStandard && token == "std";
            }
            return allStandard ? string.Empty : string.Join(",", tokens);
        }

        internal static bool CurfewWeekActive(bool enabled, string start, string end, string week, DateTime localNow, out string until)
        {
            return CurfewWeekActive(enabled, start, end, week, ((int)localNow.DayOfWeek + 6) % 7, localNow.Hour * 60 + localNow.Minute, out until);
        }

        // weekdayMon0: Kalendertag der Uhr, Montag = 0. Nur der Abend des
        // laufenden Budget-Tags und der davor koennen den Zeitpunkt abdecken;
        // until ist das Ende des Fensters, das am laengsten laeuft.
        internal static bool CurfewWeekActive(bool enabled, string start, string end, string week, int weekdayMon0, int minuteOfDay, out string until)
        {
            until = string.Empty;
            if (!enabled)
            {
                return false;
            }

            int dayStart = GuardService.BudgetDayStartHour * 60;
            string[] tokens = NormalizeCurfewWeek(week).Split(',');
            int budgetDay = minuteOfDay < dayStart ? (weekdayMon0 + 6) % 7 : weekdayMon0;
            int offset = (minuteOfDay - dayStart + 1440) % 1440;
            int latest = -1;
            for (int back = 0; back < 2; back++)
            {
                int row = (budgetDay + 7 - back) % 7;
                int position = offset + back * 1440;
                string token = tokens.Length == 7 ? tokens[row] : "std";
                if (token == "off")
                {
                    continue;
                }

                string[] times = token == "std" ? new[] { start, end } : token.Split('-');
                int from;
                int to;
                if (!TryParseTimeText(times[0], out from) || !TryParseTimeText(times[1], out to))
                {
                    continue;
                }

                int length = (to - from + 1440) % 1440;
                int begin = (from - dayStart + 1440) % 1440;
                if (length > 0 && position >= begin && position < begin + length)
                {
                    int finish = begin + length - back * 1440;
                    if (finish > latest)
                    {
                        latest = finish;
                        until = CurfewClockText(to);
                    }
                }
            }
            return latest >= 0;
        }

        private static string CurfewClockText(int minutes)
        {
            return (minutes / 60).ToString("00", System.Globalization.CultureInfo.InvariantCulture) + ":" +
                (minutes % 60).ToString("00", System.Globalization.CultureInfo.InvariantCulture);
        }

        internal static VideoGamesUsageState LoadUsageState(string path, string currentDay)
        {
            return LoadUsageState(path, currentDay, null);
        }

        internal static VideoGamesUsageState LoadUsageState(string path, string currentDay, byte[] integrityKey)
        {
            VideoGamesUsageState state = new VideoGamesUsageState { Day = currentDay };
            try
            {
                if (!File.Exists(path))
                {
                    return state;
                }

                FileInfo info = new FileInfo(path);
                if (info.Length > MaxUsageFileBytes)
                {
                    return state;
                }

                string json = File.ReadAllText(path, Encoding.UTF8);
                string storedDay = ReadJsonString(json, "Day", string.Empty);
                int usedSeconds = ReadJsonInt(json, "UsedSeconds", 0);
                if (ShouldResetDay(storedDay, currentDay))
                {
                    return state;
                }

                state.Day = storedDay;
                state.UsedSeconds = Math.Max(0, usedSeconds);
                state.LastSampleUtc = ReadJsonString(json, "LastSampleUtc", string.Empty);
                state.WarnedToday = ReadJsonBool(json, "WarnedToday", false);
                state.WarnedThresholdMinutes = ReadJsonInt(json, "WarnedThresholdMinutes", 0);
                if (state.WarnedThresholdMinutes == 0 && state.WarnedToday)
                {
                    state.WarnedThresholdMinutes = WarningRemainingMinutes;
                }

                // USG-001: Ohne Schluessel bleibt es beim alten Verhalten - ein
                // fehlender integrity.key macht ohnehin schon die Konfiguration
                // ungueltig und faellt dort viel lauter auf.
                if (integrityKey != null)
                {
                    string body;
                    string stored = SplitUsageIntegrity(json, out body);
                    if (stored == null ||
                        !string.Equals(stored, ComputeUsageIntegrity(body, integrityKey), StringComparison.Ordinal))
                    {
                        // Auch eine Datei ohne Integrity-Feld faellt hierunter. Nach
                        // einem Update aus einer aelteren Fassung kostet das einmalig
                        // den Rest des laufenden Tages - die sichere Richtung.
                        return new VideoGamesUsageState { Day = currentDay, Damaged = true };
                    }
                }
            }
            catch
            {
                // Damaged runtime data: start a fresh day counter, never throw.
            }
            return state;
        }

        // ---- Restzeit-Anzeige ---------------------------------------------
        //
        // Der Guard bleibt die einzige Stelle, die Restzeit rechnet: er legt
        // sie fertig in video-games-badge.json ab, das Abzeichen liest nur.
        // Rechnete das Abzeichen selbst, muesste es Budget, Sperrzeit und
        // Ausnahmen ein zweites Mal auslegen - und zwei Auslegungen laufen
        // frueher oder spaeter auseinander.

        internal static readonly int[] WarningThresholdsMinutes = { 30, 15, 5 };

        private const string BadgeTaskName = "\\Purestate\\Badge";
        private static DateTime lastBadgeLaunchUtc = DateTime.MinValue;
        private static readonly BadgeTaskLauncher badgeLauncher = new BadgeTaskLauncher(
            BadgeTaskName, RunSchtasks, Path.Combine(DataDirectory, "video-games-badge-task.xml"));

        // Spielstart-Ansage (Tester-Notiz 2026-10-06): die Restzeit wird beim
        // Start gezeigt, egal ob das Budget voll oder angebrochen ist.
        private static readonly object runSync = new object();
        private static volatile bool gameWasRunning;
        private static int startProbeRunning;
        private static DateTime startNoticeUntilUtc = DateTime.MinValue;
        private static string startNoticeText = string.Empty;
        // Zeitpunkt der letzten Ansage (Start oder Erinnerung): von hier laufen die
        // 15 Minuten bis zur naechsten Erinnerung.
        private static DateTime lastAnnouncementUtc = DateTime.MinValue;

        private static string BadgePath
        {
            get { return Path.Combine(DataDirectory, "video-games-badge.json"); }
        }

        private static string FirstProcessName(List<Process> processes)
        {
            foreach (Process process in processes ?? new List<Process>())
            {
                try
                {
                    string name = process.ProcessName;
                    if (!string.IsNullOrEmpty(name))
                    {
                        return name;
                    }
                }
                catch
                {
                }
            }
            return string.Empty;
        }

        // Schreibt den Stand fuer das Abzeichen und startet es, wenn noetig.
        // Darf nie werfen: die Anzeige ist Beiwerk, die Durchsetzung nicht.
        private static void UpdateBadge(bool show, int remainingSeconds, string gameName, string notice, Action<string> log)
        {
            try
            {
                if (!show)
                {
                    if (File.Exists(BadgePath))
                    {
                        File.Delete(BadgePath);
                    }
                    return;
                }

                bool wasVisible = File.Exists(BadgePath);
                File.WriteAllText(BadgePath, BuildBadgeJson(remainingSeconds, gameName, DateTime.UtcNow, notice), Encoding.UTF8);

                // Starten, sobald das Abzeichen faellig wird - und danach
                // hoechstens alle fuenf Minuten erneut, falls es der Nutzer
                // abgeschossen hat. Es laeuft ohnehin von selbst aus, sobald
                // die Datei veraltet.
                if (!wasVisible || (DateTime.UtcNow - lastBadgeLaunchUtc) > TimeSpan.FromMinutes(5))
                {
                    if (StartBadgeInUserSession(log))
                    {
                        lastBadgeLaunchUtc = DateTime.UtcNow;
                    }
                }
            }
            catch
            {
            }
        }

        // Die Aufgabe selbst legt BadgeTaskLauncher an und startet sie.
        private static bool StartBadgeInUserSession(Action<string> log)
        {
            string owner = ConsoleSessionUser();
            if (owner.Length == 0)
            {
                return false;
            }
            string exe = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Purestate.exe");
            if (!File.Exists(exe))
            {
                return false;
            }
            return badgeLauncher.Launch(owner, exe, log);
        }

        // Liefert null, wenn schtasks Erfolg meldet, sonst dessen Meldung fuers
        // Protokoll. Die Standardeingabe wird sofort geschlossen: fragt schtasks
        // je nach Fall "ersetzen (J/N)?", scheitert es am Dateiende, statt
        // ewig auf eine Eingabe zu warten, die in Sitzung 0 niemand tippt.
        private static string RunSchtasks(string arguments)
        {
            try
            {
                ProcessStartInfo info = new ProcessStartInfo(
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "schtasks.exe"),
                    arguments);
                info.UseShellExecute = false;
                info.CreateNoWindow = true;
                info.RedirectStandardInput = true;
                info.RedirectStandardOutput = true;
                info.RedirectStandardError = true;
                using (Process process = Process.Start(info))
                {
                    if (process == null)
                    {
                        return "schtasks liess sich nicht starten";
                    }
                    process.StandardInput.Close();
                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();
                    if (!process.WaitForExit(10000))
                    {
                        try { process.Kill(); } catch { }
                        return "schtasks antwortete nicht innerhalb von 10 Sekunden";
                    }
                    if (process.ExitCode == 0)
                    {
                        return null;
                    }
                    string message = (error + " " + output).Trim();
                    return message.Length > 0 ? message : "Exitcode " + process.ExitCode;
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private const int WtsUserName = 5;
        private const int WtsDomainName = 7;

        [DllImport("wtsapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern bool WTSQuerySessionInformation(
            IntPtr hServer, int sessionId, int wtsInfoClass, out IntPtr ppBuffer, out int pBytesReturned);

        [DllImport("wtsapi32.dll")]
        private static extern void WTSFreeMemory(IntPtr pMemory);

        private static string ConsoleSessionUser()
        {
            try
            {
                int sessionId = (int)WTSGetActiveConsoleSessionId();
                string user = QuerySessionString(sessionId, WtsUserName);
                if (user.Length == 0)
                {
                    return string.Empty;
                }
                string domain = QuerySessionString(sessionId, WtsDomainName);
                return domain.Length > 0 ? domain + "\\" + user : user;
            }
            catch
            {
                return string.Empty;
            }
        }

        private static string QuerySessionString(int sessionId, int infoClass)
        {
            IntPtr buffer = IntPtr.Zero;
            try
            {
                int returned;
                if (!WTSQuerySessionInformation(IntPtr.Zero, sessionId, infoClass, out buffer, out returned))
                {
                    return string.Empty;
                }
                return Marshal.PtrToStringUni(buffer) ?? string.Empty;
            }
            catch
            {
                return string.Empty;
            }
            finally
            {
                if (buffer != IntPtr.Zero)
                {
                    WTSFreeMemory(buffer);
                }
            }
        }

        // Ab hier ist die Restzeit knapp genug, dass die Anzeige hilft statt
        // nur zu stoeren.
        internal const int BadgeVisibleFromMinutes = 30;

        // Welche Schwelle jetzt gemeldet werden muss - 0 heisst: keine. Es
        // feuert immer nur die naechstkleinere, ein Sprung von 40 auf 3 Minuten
        // (Rechner stand still) meldet also 5 und nicht dreimal hintereinander.
        internal static int NextWarningThreshold(int remainingSeconds, int alreadyWarnedMinutes)
        {
            if (remainingSeconds < 0)
            {
                return 0;
            }
            int due = 0;
            foreach (int threshold in WarningThresholdsMinutes)
            {
                if (remainingSeconds <= threshold * 60 &&
                    (alreadyWarnedMinutes <= 0 || threshold < alreadyWarnedMinutes))
                {
                    due = threshold;
                }
            }
            return due;
        }

        internal static bool ShouldShowBadge(bool dailyLimitEnabled, bool gameRunning, int remainingSeconds)
        {
            return dailyLimitEnabled && gameRunning &&
                remainingSeconds > 0 && remainingSeconds <= BadgeVisibleFromMinutes * 60;
        }

        // Angesagt wird nur der Start selbst (vorher lief kein Ziel) und nur, wo
        // es eine Restzeit gibt und das Spiel nicht ohnehin gleich beendet wird.
        internal static bool ShouldAnnounceStart(bool dailyLimitEnabled, bool wasRunning, bool gameRunning, bool blocked)
        {
            return dailyLimitEnabled && gameRunning && !wasRunning && !blocked;
        }

        // Nutzerwunsch 2026-10-11 (119 von 180 Minuten gespielt, das Fenster nie
        // bemerkt): bei einem langen Budget kommt das Abzeichen nicht nur beim
        // Start, sondern alle 15 Minuten kurz mit der Restzeit. In der letzten
        // halben Stunde steht es ohnehin dauerhaft da, dort braucht es keine
        // Erinnerung.
        internal const int ReminderIntervalMinutes = 15;

        internal static bool ShouldAnnounceReminder(
            bool dailyLimitEnabled, bool gameRunning, bool blocked, int remainingSeconds,
            DateTime lastUtc, DateTime nowUtc)
        {
            return dailyLimitEnabled && gameRunning && !blocked &&
                remainingSeconds > BadgeVisibleFromMinutes * 60 &&
                (nowUtc - lastUtc) >= TimeSpan.FromMinutes(ReminderIntervalMinutes);
        }

        internal static string BuildStartNotice(int remainingSeconds)
        {
            return FormatRemaining(remainingSeconds) + " heute";
        }

        // Angezeigt wird immer aufgerundet: bei 30 verbleibenden Sekunden ist
        // "Noch 1 min" ehrlicher als "Noch 0 min".
        internal static string FormatRemaining(int remainingSeconds)
        {
            int minutes = (Math.Max(0, remainingSeconds) + 59) / 60;
            return "Noch " + Math.Max(1, minutes) + " min";
        }

        // NoticeSeconds ist kuerzer als ein Takt: der Hinweis ist wieder weg,
        // bevor der naechste Lauf die Datei ohne ihn ueberschreibt.
        internal const int NoticeSeconds = 15;

        internal static string BuildBadgeJson(int remainingSeconds, string gameName, DateTime nowUtc)
        {
            return BuildBadgeJson(remainingSeconds, gameName, nowUtc, string.Empty);
        }

        internal static string BuildBadgeJson(int remainingSeconds, string gameName, DateTime nowUtc, string notice)
        {
            return "{\"RemainingSeconds\":" + Math.Max(0, remainingSeconds) +
                ",\"Game\":\"" + EscapeJsonValue(gameName ?? string.Empty) +
                "\",\"Notice\":\"" + EscapeJsonValue(notice ?? string.Empty) +
                "\",\"NoticeSeconds\":" + NoticeSeconds +
                ",\"UpdatedUtc\":\"" + nowUtc.ToString("o") + "\"}";
        }

        private static string EscapeJsonValue(string value)
        {
            return value.Replace("\\", "\\\\").Replace("\"", "\\\"");
        }

        // USG-001: Derselbe Schluessel, mit dem die Konfiguration signiert wird
        // (NativeSupportConfig.cs:841). Der Waechter kompiliert eigenstaendig,
        // ohne Support-Referenzen, deshalb steht der Lader hier ein zweites Mal.
        //
        // Die Grenze ist bekannt und bewusst: derselbe erhoehte Administrator
        // kann integrity.key lesen und den HMAC selbst rechnen. Der Aufwand
        // steigt von "Zahl aendern" auf "Skript schreiben" - dieselbe Grenze,
        // die die Konfigurationssignatur seit jeher hat.
        internal static byte[] TryLoadUsageIntegrityKey()
        {
            try
            {
                string path = Path.Combine(DataDirectory, "integrity.key");
                if (!File.Exists(path))
                {
                    return null;
                }

                byte[] key = Convert.FromBase64String(File.ReadAllText(path).Trim());
                return key.Length >= 32 ? key : null;
            }
            catch
            {
                return null;
            }
        }

        // Signiert wird der Dateitext ohne das Integrity-Feld. Absichtlich nicht
        // die geparsten Werte: App und Waechter muessten sonst fuenf
        // Feldnormalisierungen zeichengleich nachbauen, und die erste Abweichung
        // wuerde jede Datei als gefaelscht melden. Der Waechter ist der einzige
        // Schreiber, sein Text ist kanonisch.
        internal static string ComputeUsageIntegrity(string body, byte[] key)
        {
            using (HMACSHA256 hmac = new HMACSHA256(key))
            {
                return Convert.ToBase64String(hmac.ComputeHash(Encoding.UTF8.GetBytes(body)));
            }
        }

        // Trennt den signierten Rumpf vom angehaengten Integrity-Feld.
        // Gibt null zurueck, wenn kein Feld da ist.
        internal static string SplitUsageIntegrity(string json, out string body)
        {
            body = json ?? string.Empty;
            const string marker = ",\"Integrity\":\"";
            int index = body.IndexOf(marker, StringComparison.Ordinal);
            if (index < 0)
            {
                return null;
            }

            int start = index + marker.Length;
            int end = body.IndexOf('"', start);
            if (end < 0)
            {
                return null;
            }

            string stored = body.Substring(start, end - start);
            body = body.Substring(0, index) + "}";
            return stored;
        }

        internal static string BuildUsageJson(VideoGamesUsageState state, byte[] key)
        {
            string body = BuildUsageJson(state);
            if (key == null)
            {
                return body;
            }

            return body.Substring(0, body.Length - 1) +
                ",\"Integrity\":\"" + ComputeUsageIntegrity(body, key) + "\"}";
        }

        internal static string BuildUsageJson(VideoGamesUsageState state)
        {
            return "{\"Day\":\"" + state.Day + "\",\"UsedSeconds\":" + Math.Max(0, state.UsedSeconds) +
                ",\"LastSampleUtc\":\"" + (state.LastSampleUtc ?? string.Empty) +
                "\",\"WarnedToday\":" + (state.WarnedToday ? "true" : "false") +
                ",\"WarnedThresholdMinutes\":" + Math.Max(0, state.WarnedThresholdMinutes) + "}";
        }

        private static void SaveUsageState(string path, VideoGamesUsageState state, byte[] key)
        {
            try
            {
                string json = BuildUsageJson(state, key);
                GuardService.ReplaceFileAtomically(path, delegate(string temp)
                {
                    File.WriteAllText(temp, json, new UTF8Encoding(false));
                });
            }
            catch
            {
            }
        }

        // ---- Notifications -----------------------------------------------------

        // A session-0 service must not open dialogs itself; WTSSendMessage is
        // the documented way to put a plain message box into the active console
        // session. Non-blocking (wait=false) so the guard tick never stalls.
        private static void NotifyUser(string title, string message)
        {
            try
            {
                // Only the real (non-interactive) service session sends session
                // messages; interactive runs (console, tests) stay silent.
                if (Environment.UserInteractive)
                {
                    return;
                }
                uint sessionId = WTSGetActiveConsoleSessionId();
                if (sessionId == 0xFFFFFFFF)
                {
                    return;
                }
                int response;
                WTSSendMessage(IntPtr.Zero, (int)sessionId, title, title.Length * 2,
                    message, message.Length * 2, 0x00000040 /* MB_ICONINFORMATION */, 0, out response, false);
            }
            catch
            {
            }
        }

        // ---- Read-only JSON helpers (regex-based like the rest of the guard) ----

        internal static bool ReadJsonBool(string json, string name, bool fallback)
        {
            Match match = Regex.Match(json ?? string.Empty,
                "\"" + Regex.Escape(name) + "\"\\s*:\\s*(true|false)", RegexOptions.IgnoreCase);
            return match.Success ? bool.Parse(match.Groups[1].Value) : fallback;
        }

        internal static string ReadJsonString(string json, string name, string fallback)
        {
            Match match = Regex.Match(json ?? string.Empty,
                "\"" + Regex.Escape(name) + "\"\\s*:\\s*\"([^\"]*)\"");
            return match.Success ? match.Groups[1].Value : fallback;
        }

        internal static int ReadJsonInt(string json, string name, int fallback)
        {
            Match match = Regex.Match(json ?? string.Empty,
                "\"" + Regex.Escape(name) + "\"\\s*:\\s*(-?\\d{1,9})");
            int value;
            return match.Success && int.TryParse(match.Groups[1].Value, out value) ? value : fallback;
        }

        // Pure self-test used by PurestateGuard.exe --self-test; returns an
        // error text or empty on success.
        internal static string RunSelfTest()
        {
            string windows = @"C:\Windows";
            string install = @"C:\Program Files\Purestate";

            if (IsSafeTargetPath(@"C:\Windows\System32\notepad.exe", windows, install) ||
                IsSafeTargetPath(@"C:\Games\explorer.exe", windows, install) ||
                IsSafeTargetPath(@"C:\Program Files\Purestate\Purestate.exe", windows, install) ||
                IsSafeTargetPath(@"C:\Games\game.bat", windows, install) ||
                IsSafeTargetPath("game.exe", windows, install) ||
                !IsSafeTargetPath(@"C:\Games\MyGame\game.exe", windows, install))
            {
                return "video-games target safety validation failed";
            }

            VideoGamesGuardTarget parsed = ParseTargetLine(@"1|0|Mein Spiel|C:\Games\MyGame\game.exe", windows, install);
            if (parsed == null || !parsed.Enabled || parsed.Name != "Mein Spiel" ||
                ParseTargetLine(@"1|0|X|C:\Windows\System32\cmd.exe", windows, install) != null ||
                ParseTargetLine("# comment", windows, install) != null ||
                ParseTargetLine("broken|line", windows, install) != null)
            {
                return "video-games target parsing failed";
            }

            string until;
            if (!CurfewWeekActive(true, "22:00", "06:00", string.Empty, 0, 23 * 60, out until) ||
                !CurfewWeekActive(true, "22:00", "06:00", string.Empty, 0, 3 * 60, out until) ||
                CurfewWeekActive(true, "22:00", "06:00", string.Empty, 0, 12 * 60, out until) ||
                CurfewWeekActive(true, "10:00", "10:00", string.Empty, 0, 10 * 60, out until) ||
                !CurfewWeekActive(true, "08:00", "17:00", string.Empty, 0, 9 * 60, out until) ||
                CurfewWeekActive(true, "22:00", "06:00", "std,std,std,std,std,off,std", 5, 23 * 60, out until))
            {
                return "video-games curfew window check failed";
            }

            if (ShouldResetDay("2026-07-14", "2026-07-13") ||
                !ShouldResetDay("2026-07-14", "2026-07-15") ||
                !ShouldResetDay("", "2026-07-15") ||
                ShouldResetDay("2026-07-14", "2026-07-14"))
            {
                return "video-games day rollover check failed";
            }

            DateTime now = new DateTime(2026, 7, 14, 12, 0, 0, DateTimeKind.Utc);
            if (ComputeAccrualSeconds(now.AddSeconds(-30).ToString("o"), now, 30) != 30 ||
                ComputeAccrualSeconds(now.AddHours(-8).ToString("o"), now, 30) != 60 ||
                ComputeAccrualSeconds("not a date", now, 30) != 30 ||
                ComputeAccrualSeconds(now.AddSeconds(30).ToString("o"), now, 30) != 30)
            {
                return "video-games accrual clamp check failed";
            }

            VideoGamesUsageState state = new VideoGamesUsageState { Day = "2026-07-14", UsedSeconds = 90, LastSampleUtc = now.ToString("o"), WarnedToday = true };
            string json = BuildUsageJson(state);
            if (ReadJsonString(json, "Day", "") != "2026-07-14" ||
                ReadJsonInt(json, "UsedSeconds", -1) != 90 ||
                !ReadJsonBool(json, "WarnedToday", false))
            {
                return "video-games usage state roundtrip failed";
            }

            return string.Empty;
        }
    }
}
