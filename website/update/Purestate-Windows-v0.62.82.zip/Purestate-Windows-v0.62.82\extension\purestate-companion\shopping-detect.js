"use strict";

// Purestate: Shop-Erkennung und Betragsermittlung ohne Hostliste.
//
// Eine gepflegte Liste deckt zwangslaeufig nur die Shops ab, an die jemand
// gedacht hat - "nimm einen anderen Shop" waere die billigste Umgehung des
// ganzen Schutzbereichs. Dieses Modul entscheidet stattdessen am Inhalt der
// Seite, ob dort etwas gekauft werden kann.
//
// Bewusste Grenzen:
// - Erkannte Shops bekommen nur die sanften Mechanismen (Kaufverzoegerung,
//   Reizdaempfung, Sperrzeit, Zaehlung). Der harte Block bleibt den
//   kuratierten und den selbst eingetragenen Domains vorbehalten. Ein
//   Fehltreffer kostet damit Wartezeit, nicht den Zugang.
// - Gelesen wird ausschliesslich die bereits geladene Seite. Kein Netz, keine
//   Weitergabe, kein Speichern von Seiteninhalten.

(function () {
  // Starkes Signal: die Seite beschreibt selbst ein kaufbares Produkt.
  const PRODUCT_TYPES = /^(product|offer|aggregateoffer|productgroup|itempage)$/i;
  const OG_PRODUCT = /^(product|product\.item|og:product)$/i;

  // Mittleres Signal: Warenkorb-Bedienelemente. Allein zu schwach - ein Blog
  // kann "In den Warenkorb" im Fliesstext stehen haben -, zusammen mit einem
  // Preis aber eindeutig genug.
  const CART_TEXT = /(in den warenkorb|zum warenkorb|warenkorb hinzu|add to (cart|basket|bag)|jetzt kaufen|buy now|sofort kaufen)/i;
  const CART_ATTRIBUTE = /(add[-_]?to[-_]?cart|addtobasket|warenkorb|basket|cart)/i;

  // Preis im sichtbaren Text. Gehashte Klassennamen ("yUjq5DY2") tragen kein
  // "price" mehr - ohne dieses Signal blieben moderne Shops unerkannt. Die
  // Waehrung muss dabeistehen: eine blosse Zahl waere auch ein Datum.
  const PRICE_TEXT = /\d[\d.\s]*[.,]\d{2}\s*(?:€|EUR\b)|(?:€|EUR)\s*\d[\d.\s]*[.,]\d{2}/i;

  // Summenzeile im Kassenbereich. Reihenfolge zaehlt: "Gesamtsumme" ist
  // aussagekraeftiger als "Summe", deshalb steht sie vorn.
  const TOTAL_LABEL = /(gesamtsumme|gesamtbetrag|zu zahlen(?:der betrag)?|rechnungsbetrag|endbetrag|order total|grand total|gesamt|summe|total)/i;

  function textOf(node) {
    return String((node && node.textContent) || "").replace(/\s+/g, " ").trim();
  }

  function eachJsonLd(doc, visit) {
    let scripts;
    try {
      scripts = doc.querySelectorAll('script[type="application/ld+json"]');
    } catch {
      return;
    }
    for (const script of Array.from(scripts || [])) {
      let data;
      try {
        data = JSON.parse(textOf(script));
      } catch {
        continue;
      }
      walkJsonLd(data, visit, 0);
    }
  }

  // Verschachtelung ist in der Praxis flach; die Tiefenbremse verhindert nur,
  // dass eine bösartig verschachtelte Seite den Content-Script beschaeftigt.
  function walkJsonLd(node, visit, depth) {
    if (!node || typeof node !== "object" || depth > 6) {
      return;
    }
    if (Array.isArray(node)) {
      for (const entry of node) {
        walkJsonLd(entry, visit, depth + 1);
      }
      return;
    }
    visit(node);
    for (const key of Object.keys(node)) {
      walkJsonLd(node[key], visit, depth + 1);
    }
  }

  // Redaktionelle Seiten betten Produktauszeichnung ein, ohne ein Shop zu
  // sein: Preisvergleichs-Kaesten, Angebots-Teaser, Testberichte. Live
  // gefunden auf heise.de - "Article" und "Product" im selben Dokument.
  const EDITORIAL_TYPES = /^(article|newsarticle|blogposting|liveblogposting|opinionnewsarticle|reportagenewsarticle|reviewnewsarticle|backgroundnewsarticle)$/i;

  // Ein Durchlauf fuer beide Fragen: die Typen der Seite einmal einsammeln.
  function jsonLdTypes(doc) {
    const found = new Set();
    eachJsonLd(doc, (node) => {
      const types = Array.isArray(node["@type"]) ? node["@type"] : [node["@type"]];
      for (const type of types) {
        if (typeof type === "string") {
          found.add(type.trim());
        }
      }
    });
    return found;
  }

  function anyType(types, pattern) {
    for (const type of types) {
      if (pattern.test(type)) {
        return true;
      }
    }
    return false;
  }

  function hasProductMeta(doc) {
    let metas;
    try {
      metas = doc.querySelectorAll('meta[property="og:type"], meta[name="og:type"]');
    } catch {
      return false;
    }
    for (const meta of Array.from(metas || [])) {
      const value = String(meta.getAttribute("content") || "").trim();
      if (OG_PRODUCT.test(value)) {
        return true;
      }
    }
    return false;
  }

  function hasProductMicrodata(doc) {
    try {
      return !!doc.querySelector('[itemtype*="schema.org/Product" i], [itemtype*="schema.org/Offer" i]');
    } catch {
      return false;
    }
  }

  function hasPriceMarkup(doc) {
    try {
      if (doc.querySelector('[itemprop="price"], [itemprop="lowPrice"], [data-price], [class*="price" i]')) {
        return true;
      }
    } catch {
      return false;
    }
    // Bewusst innerText, nicht textContent: der sichtbare Text laesst Skript-
    // bloecke und ausgeblendete Knoten aus. Gemessen auf spiegel.de, dessen
    // Werbe-JSON sonst neun Betraege beisteuert. Der Erkenner laeuft je
    // Ladezustand nur einmal, das Umbrechen faellt daher nicht ins Gewicht.
    try {
      const body = doc.body;
      if (!body) {
        return false;
      }
      const text = String(body.innerText !== undefined && body.innerText !== null
        ? body.innerText
        : (body.textContent || ""));
      // Deckel: ein Preis steht nie erst nach 300k Zeichen.
      return PRICE_TEXT.test(text.slice(0, 300000));
    } catch {
      return false;
    }
  }

  function hasCartControl(doc) {
    if (cartControlInRoot(doc)) {
      return true;
    }
    return cartControlInShadowRoots(doc);
  }

  // Web Components verstecken ihre Bedienelemente vor querySelectorAll. Live
  // gefunden (2026-08-09, obi.de): der Warenkorb steht in <buy-mini-cart> als
  // <a class="mini-cart" href="/cart">, im Light-DOM der Seite kommt das Wort
  // "Warenkorb" gar nicht vor. Ohne diesen zweiten Blick bleibt jeder Shop
  // unerkannt, der so gebaut ist.
  // ponytail: eine Ebene tief, kein rekursives Absteigen in verschachtelte
  // Roots - gemessen reicht das, und der Aufstieg kostet einen Durchlauf ueber
  // alle Elemente. Deckel wie ueberall sonst gegen entartete Seiten.
  function cartControlInShadowRoots(doc) {
    let all;
    try {
      all = doc.querySelectorAll("*");
    } catch {
      return false;
    }
    let roots = 0;
    for (const element of Array.from(all || []).slice(0, 20000)) {
      const root = element && element.shadowRoot;
      if (!root) {
        continue;
      }
      roots += 1;
      if (roots > 50) {
        return false;
      }
      if (cartControlInRoot(root)) {
        return true;
      }
    }
    return false;
  }

  function cartControlInRoot(doc) {
    let candidates;
    try {
      candidates = doc.querySelectorAll("button, a, input[type=submit], form");
    } catch {
      return false;
    }
    // Deckel gegen sehr grosse Seiten: die Bedienelemente eines Shops stehen
    // nie erst an Position 400.
    const list = Array.from(candidates || []).slice(0, 400);
    for (const element of list) {
      const attributes = [
        element.getAttribute("id"),
        element.getAttribute("name"),
        element.getAttribute("class"),
        element.getAttribute("action"),
        element.getAttribute("data-testid"),
        element.getAttribute("aria-label")
      ].join(" ");
      if (CART_ATTRIBUTE.test(attributes)) {
        return true;
      }
      const label = textOf(element);
      if (label.length <= 40 && CART_TEXT.test(label)) {
        return true;
      }
    }
    return false;
  }

  // Liefert den Grund mit, damit ein Fehltreffer nachvollziehbar ist - im
  // Protokoll steht spaeter nur dieser kurze Bezeichner, nie Seiteninhalt.
  function detectShopPage(doc) {
    if (!doc || typeof doc.querySelector !== "function") {
      return { shop: false, reason: "" };
    }

    const types = jsonLdTypes(doc);
    // Auf einer redaktionellen Seite reicht Produktauszeichnung nicht: dort
    // steht sie im Kasten neben dem Text. Ein Warenkorb-Bedienelement muss
    // dann dazukommen - kaufen kann man nur, wo auch ein Kauf beginnt.
    const editorial = anyType(types, EDITORIAL_TYPES);

    if (anyType(types, PRODUCT_TYPES) && (!editorial || hasCartControl(doc))) {
      return { shop: true, reason: editorial ? "jsonld-product-with-cart" : "jsonld-product" };
    }
    if (hasProductMeta(doc)) {
      return { shop: true, reason: "og-product" };
    }
    if (hasProductMicrodata(doc) && (!editorial || hasCartControl(doc))) {
      return { shop: true, reason: "microdata-product" };
    }
    if (hasCartControl(doc) && hasPriceMarkup(doc)) {
      return { shop: true, reason: "cart-and-price" };
    }
    return { shop: false, reason: "" };
  }

  // --- Betrag ------------------------------------------------------------

  // Deutsche und englische Schreibweise. Sind beide Trenner da, ist der
  // hintere der Dezimaltrenner; steht nur einer da, entscheidet die Zahl der
  // Nachkommastellen. "1.234" ist tausend, "1.23" ist eins.
  function parseAmountEuro(text) {
    const raw = String(text || "");
    const match = raw.match(/\d[\d.,\s ']*\d|\d/);
    if (!match) {
      return null;
    }

    let digits = match[0].replace(/[\s ']/g, "");
    const lastComma = digits.lastIndexOf(",");
    const lastDot = digits.lastIndexOf(".");
    let decimalAt = -1;

    if (lastComma >= 0 && lastDot >= 0) {
      decimalAt = Math.max(lastComma, lastDot);
    } else if (lastComma >= 0 || lastDot >= 0) {
      const only = Math.max(lastComma, lastDot);
      const rest = digits.length - only - 1;
      if (rest === 2 || rest === 1) {
        decimalAt = only;
      }
    }

    let whole = decimalAt >= 0 ? digits.slice(0, decimalAt) : digits;
    const fraction = decimalAt >= 0 ? digits.slice(decimalAt + 1) : "";
    whole = whole.replace(/[.,]/g, "");
    if (!/^\d+$/.test(whole)) {
      return null;
    }

    const value = parseInt(whole, 10) + (fraction && /^\d+$/.test(fraction) ? parseFloat("0." + fraction) : 0);
    const euro = Math.round(value);
    if (!Number.isFinite(euro) || euro <= 0 || euro > 99999) {
      return null;
    }
    return euro;
  }

  // Kassenzeilen nennen Stueckzahlen und Steuersaetze vor dem Betrag:
  // "Zu zahlender Betrag inkl. 19% MwSt. 249,00 EUR". Die erste Zahl ist dann
  // der Steuersatz, nicht die Summe - deshalb schlaegt ein Betrag mit Waehrung
  // jede blosse Zahl. Bleibt die Waehrung im Nachbarelement stehen, greift
  // weiter unten der Rueckfall auf die blosse Zahl.
  const AMOUNT_WITH_CURRENCY = /(?:€|EUR)\s*(\d[\d.,\s']*\d|\d)|(\d[\d.,\s']*\d|\d)\s*(?:€|EUR\b)/gi;

  function amountFromCurrencyText(text) {
    let best = null;
    for (const match of String(text || "").matchAll(AMOUNT_WITH_CURRENCY)) {
      const amount = parseAmountEuro(match[1] !== undefined ? match[1] : match[2]);
      if (amount !== null) {
        // Innerhalb einer Zeile ist die Gesamtsumme der groesste Betrag:
        // Versand, Rabatt und ausgewiesene Steuer sind kleiner.
        best = best === null ? amount : Math.max(best, amount);
      }
    }
    return best;
  }

  function amountFromLabelledElements(doc) {
    let candidates;
    try {
      candidates = doc.querySelectorAll("*");
    } catch {
      return null;
    }

    let best = null;
    // Der fruehere Deckel nahm die ERSTEN 1500 Elemente. Summenzeilen stehen
    // aber hinter der Artikelliste, und schon die Startseiten von lidl.de und
    // tchibo.de liefern ueber 3000 Elemente - die Summe lag also regelmaessig
    // hinter dem Deckel. Der Deckel bleibt als Bremse gegen entartete Seiten,
    // nur weit genug oben; die Lesung laeuft einmal je Einblendung, nicht je
    // Takt.
    const list = Array.from(candidates || []).slice(0, 20000);
    for (const element of list) {
      const own = ownText(element);
      if (!own || own.length > 120 || !TOTAL_LABEL.test(own)) {
        continue;
      }

      // Die eigenen Einblendungen nennen selbst Betraege. Ohne diesen
      // Ausschluss laese der Erkenner seine eigene Anzeige. Die Pruefung steht
      // bewusst hinter dem Label: sie laeuft den Baum hinauf und waere vor dem
      // Label eine Aufwaertssuche je Element der Seite.
      try {
        if (typeof element.closest === "function" && element.closest('[id^="purestate-"]')) {
          continue;
        }
      } catch {
      }

      // Betrag steht in derselben Zeile, im Nachbarelement oder - wenn Label
      // und Betrag je eine eigene Huelle tragen (Zellen, Spalten) - ein bis
      // zwei Ebenen darueber. Gemessen an /buy/cart (2026-08): eine Ebene zu
      // wenig. Die Laengengrenze unten haelt die Huelle klein; was naeher
      // liegt, gewinnt.
      const nearby = [own, textOf(element.nextElementSibling)];
      let ancestor = element.parentElement;
      for (let level = 0; level < 3 && ancestor; level += 1) {
        nearby.push(textOf(ancestor));
        ancestor = ancestor.parentElement;
      }
      for (const text of nearby) {
        if (!text || text.length > 200) {
          continue;
        }
        const withCurrency = amountFromCurrencyText(text);
        const amount = withCurrency !== null ? withCurrency : parseAmountEuro(text);
        if (amount !== null) {
          // Die groesste beschriftete Summe ist die Gesamtsumme; Zwischen-
          // summen und Versandkosten sind kleiner.
          best = best === null ? amount : Math.max(best, amount);
          break;
        }
      }
    }
    return best;
  }

  function ownText(element) {
    if (!element || !element.childNodes) {
      return "";
    }
    let text = "";
    for (const node of Array.from(element.childNodes)) {
      if (node.nodeType === 3) {
        text += node.nodeValue || "";
      }
    }
    return text.replace(/\s+/g, " ").trim();
  }

  function amountFromMarkup(doc) {
    let best = null;
    eachJsonLd(doc, (node) => {
      const price = node.price !== undefined ? node.price : (node.total !== undefined ? node.total : null);
      if (price === null || price === undefined) {
        return;
      }
      const amount = parseAmountEuro(String(price));
      if (amount !== null) {
        best = best === null ? amount : Math.max(best, amount);
      }
    });
    if (best !== null) {
      return best;
    }

    let elements;
    try {
      elements = doc.querySelectorAll('[itemprop="price"], [data-price]');
    } catch {
      return null;
    }
    for (const element of Array.from(elements || []).slice(0, 40)) {
      const amount = parseAmountEuro(element.getAttribute("content") || element.getAttribute("data-price") || textOf(element));
      if (amount !== null) {
        best = best === null ? amount : Math.max(best, amount);
      }
    }
    return best;
  }

  // Zuerst die beschriftete Summe, dann das Markup. Findet sich nichts,
  // liefert die Funktion null - der Kauf wird dann gezaehlt, aber ohne Betrag.
  // Ein Eingabefeld gibt es bewusst nicht mehr: eine Zahl, die der Nutzer im
  // Kaufmoment selbst eintraegt, kann jede beliebige sein.
  function readCheckoutTotal(doc) {
    if (!doc || typeof doc.querySelectorAll !== "function") {
      return null;
    }
    const labelled = amountFromLabelledElements(doc);
    if (labelled !== null) {
      return labelled;
    }
    return amountFromMarkup(doc);
  }

  // Nur die Signale, die im <head> stehen und daher schon fertig sind, bevor
  // die Seite sichtbar wird. Warenkorb und Preis fehlen hier bewusst: die
  // stehen im Body, ein frueher Blick darauf faende nichts.
  function detectShopMarkup(doc) {
    if (!doc || typeof doc.querySelector !== "function") {
      return false;
    }
    if (hasProductMeta(doc)) {
      return true;
    }
    const types = jsonLdTypes(doc);
    // Dieselbe Regel wie im vollen Erkenner - sonst holte der fruehe Blick
    // die Fehltreffer zurueck, die dort gerade ausgeschlossen werden.
    return anyType(types, PRODUCT_TYPES) && !anyType(types, EDITORIAL_TYPES);
  }

  globalThis.purestateDetectShopPage = detectShopPage;
  globalThis.purestateDetectShopMarkup = detectShopMarkup;
  globalThis.purestateParseShopAmount = parseAmountEuro;
  globalThis.purestateReadCheckoutTotal = readCheckoutTotal;
})();
