#!/usr/bin/env bash
# Install the reviewed snapshot script and recipient as root-owned files.
set -euo pipefail
[[ $EUID -eq 0 && $# -eq 2 ]] || { echo 'Usage: sudo bash Install-AuthorityBackupTimer.sh backup-script recipient.pub' >&2; exit 1; }
backup_script=$(realpath -- "$1")
recipient=$(realpath -- "$2")
[[ -s $backup_script && -s $recipient ]]
bash -n "$backup_script"
command -v age >/dev/null
for path in /etc/systemd/system/purestate-backup.service /etc/systemd/system/purestate-backup.timer /usr/local/sbin/purestate-backup /etc/purestate-backup-recipient.pub; do
    [[ ! -e $path ]] || { echo "Already exists: $path" >&2; exit 1; }
done
install -o root -g root -m 0700 "$backup_script" /usr/local/sbin/purestate-backup
install -o root -g root -m 0644 "$recipient" /etc/purestate-backup-recipient.pub
cat > /etc/systemd/system/purestate-backup.service <<'UNIT'
[Unit]
Description=Encrypted Purestate Authority snapshot

[Service]
Type=oneshot
ExecStart=/usr/bin/flock --nonblock /run/purestate-backup.lock /usr/local/sbin/purestate-backup /etc/purestate-backup-recipient.pub
UMask=0077
Nice=10
TimeoutStartSec=10min
UNIT
cat > /etc/systemd/system/purestate-backup.timer <<'UNIT'
[Unit]
Description=Daily encrypted Purestate Authority snapshot

[Timer]
OnCalendar=*-*-* 03:15:00 Europe/Berlin
Persistent=true
RandomizedDelaySec=10min
Unit=purestate-backup.service

[Install]
WantedBy=timers.target
UNIT
chmod 0644 /etc/systemd/system/purestate-backup.service /etc/systemd/system/purestate-backup.timer
systemd-analyze verify /etc/systemd/system/purestate-backup.service /etc/systemd/system/purestate-backup.timer
systemctl daemon-reload
systemctl enable --now purestate-backup.timer
systemctl start purestate-backup.service
systemctl list-timers purestate-backup.timer --no-pager
echo 'Server snapshot timer installed. Off-server transfer must be configured separately.'
