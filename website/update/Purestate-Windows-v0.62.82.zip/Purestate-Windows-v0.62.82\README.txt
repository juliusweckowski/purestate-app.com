﻿Purestate fuer Windows - Version 0.62.82
=========================================

Aktuelle technische Beta-Grenze:
- Purestate ist ein lokales technisches Werkzeug zur freiwilligen
  Selbstbeschraenkung unter Windows. Es stellt keine Diagnose und ersetzt
  keine medizinische, psychologische, psychotherapeutische, rechtliche oder
  finanzielle Beratung.
- Die persoenliche Tagebuch-, Check-in- und Supportplan-Funktion wurde vor der
  Beta eingestellt. Die App bietet dafuer keine Eingabeflaechen mehr und legt
  keine neuen persoenlichen Supportdaten an.
- Ein Installations-, Reparatur- oder Aktualisierungslauf entfernt nach einer
  erfolgreichen Aktualisierung der technischen Konfiguration genau die drei
  veralteten Dateien gambling-support.txt, shopping-support.txt und
  social-media-support.txt. Alle anderen Dateien bleiben unberuehrt.
- Neue Backups enthalten nur technische Einstellungen und Domainlisten. Beim
  Einlesen alter Backups werden technische Einstellungen und Listen weiterhin
  wiederhergestellt; die drei alten persoenlichen Supportabschnitte werden
  uebersprungen, ohne ihren Inhalt zu dekodieren oder als Datei zu schreiben.
- "Informationen und Hilfe" zeigt nur statischen Text und offizielle
  Anlaufstellen. Die Seite nimmt keine persoenlichen Angaben entgegen und
  speichert nichts.

Start:
1. Doppelklicke "Installieren.exe".
2. Bestaetige die Windows-Abfrage fuer Administrator-Rechte.
3. Klicke optional auf "Vorabcheck", um Paket, Windows-Werkzeuge und vorhandene Installation zu pruefen.
4. Trage bei einer Neuinstallation deinen Beta-Freischaltcode ein (Internet erforderlich) und lege ein Passwort fest.
5. Danach ist Purestate installiert, im Startmenue verfuegbar und in Windows unter "Apps & Features" eingetragen.

Enthaltene Programme:
- Installieren.exe: installiert Purestate.
- Purestate.exe: Verwaltungs-App nach der Installation.
- PurestateUninstaller.exe: entfernt Purestate mit Passwortabfrage.
- PurestateGuard.exe: Windows-Schutzdienst im Hintergrund.
- extension\purestate-companion: Browsererweiterung fuer Chrome und Edge.

Purestate Companion installieren:
1. Installiere oder aktualisiere zuerst die passende Purestate-Windows-Version.
2. Purestate verwaltet den passenden Companion danach ueber die Chrome-/Edge-Richtlinie.
3. Entwicklermodus und "Entpackte Erweiterung laden" gehoeren nur in den passwortgeschuetzten Dev-Companion-Modus fuer lokale Tests.
4. Ohne aktuellen, aktiven und vertrauenswuerdigen Companion sperrt Purestate geschuetzte gemischte Webseiten vollstaendig.

Wichtig fuer die geschlossene Beta 0.62.82:
- Neuinstallation erfordert einen gueltigen Freischaltcode. Aktivierung und
  Verlaengerung sind signiert; Regeln und Wartefristen bleiben lokal.
- Alle fuenf Schutzbereiche sind nach Neuinstallation aus. Schalte die
  gewuenschten Bereiche in der App ein und speichere mit deinem Passwort.
- Die Beta endet zum frueheren Zeitpunkt aus Lizenzende und festem Buildende
  31.03.2027, 00:00 UTC. Dann endet der Schutz, seine System-Sperren werden
  entfernt. Zum Deinstallieren bleibt dein Passwort erforderlich; die
  Wartefrist entfaellt nach geprueftem Ablauf.
- Ein verlaengerter Code wird erneut eingeloest. Ueber das feste Buildende
  hinaus brauchst du eine neue Programmfassung.
- Diese geschlossene Beta wird mit Chrome getestet. Ohne passenden aktiven
  Companion sind geschuetzte gemischte Seiten voll gesperrt; fuer Edge fehlt
  derzeit die passende Store-Verteilung. Nicht jede Edge-Seite ist gesperrt.
- Integritaetsschema 15 fuehrt die beiden bisherigen Schema-14-Varianten
  zusammen. Anleitung: docs/BETA-TESTER-GUIDE.md.

Wichtig fuer Version 0.62.69:
- Die inhaltsbasierte Erwachsenen-Erkennung kann falsch gelernte Hosts nach
  Passwortabfrage freigeben: wirksam nach 15 Minuten und fuer 30 Tage. Die
  Freigabe trifft nur gelernte Hosts, nicht kuratierte Domains.
- Reife Erwachsenen-Freigaben erreichen den Browser auch dann, wenn ihr Host
  hinter dem 250-Eintraege-Deckel von `adult.hostDomains` liegt; abgelaufene
  Freigaben leben nicht wieder auf. Bereits offene Tabs sehen Aktivierung und
  Ablauf exakt an der Zeitkante, ohne Neuladen oder Navigation.
- Gleichzeitig duerfen hoechstens 500 nicht abgelaufene Erwachsenen-
  Freigaben bestehen; eine weitere wird mit einer sichtbaren Meldung
  abgewiesen. Auch gueltige Mehrlabel-Hosts bis 253 Zeichen erreichen den
  Companion, ohne das Native-Messaging-Budget zu ueberschreiten.
- Scheitert die erste Weitergabe eines erkannten Hosts an Native Host oder
  Guard, bleibt sie browserseitig persistent vorgemerkt und wird
  dedupliziert mit wachsendem Abstand wiederholt, bis ein Erfolgs-Ack kommt.
  Das lokale 30-Tage-Gedaechtnis beginnt erst nach bestaetigter Queue-Aufnahme;
  eine volle Queue verwirft keinen unbestaetigten Host. Uebergrosse Altdateien
  werden vor dem 500er-Deckel vollstaendig ausgewertet.
- Viele Videos bestaetigen eine harte Inhaltserkennung nur mit eindeutigem
  Erwachsenen-Vokabular in markierten Kategorie-/Tag-Elementen; freier Text
  und mehrdeutige Woerter wie `teen` oder `amateur` reichen nicht.
- Zwei Robustheitsfehler behoben, die im Protokoll auffielen. Die
  Schutzwirkung aendert sich nicht.
- Die hosts-Datei wird jetzt bis zu fuenfmal geschrieben, wenn ein anderer
  Programm sie kurz geoeffnet hat. Vorher scheiterte dabei der gesamte
  Durchsetzungslauf.
- Browser-Sperrlisten werden aktualisiert, statt den Registrierungsschluessel
  zu loeschen und neu anzulegen. Das Neuanlegen konnte fehlschlagen, wenn ein
  anderer Prozess den Schluessel noch offen hatte.

Wichtig fuer Version 0.62.51:
- Ein Installations- oder Aktualisierungslauf schreibt keine falschen
  Integritaets-Warnungen mehr ins Sicherheitsprotokoll. Der Watchdog haelt
  sich waehrend des Laufs zurueck, statt mitten im Kopieren eine halb
  aktualisierte Installation zu pruefen.
- An der Schutzwirkung aendert sich nichts. Die Warnungen waren Fehlalarme:
  eine als veraendert erkannte Konfiguration wird in keinem Fall
  zurueckgeschrieben.
- Bricht eine Installation ab, laeuft die Zurueckhaltung nach 15 Minuten von
  selbst aus.

Wichtig fuer Version 0.62.50:
- Nach einem Purestate-Update bleibt die vorherige Companion-Version noch
  14 Tage lang gueltig. Grund: der Chrome Web Store liefert die passende
  neue Version erst nach seiner Pruefung aus, und bis dahin waren bisher
  ALLE gemischten Seiten (Reddit, X, YouTube und die uebrigen) voll
  gesperrt statt gefiltert.
- Es gilt ausschliesslich die unmittelbare Vorgaengerversion, und nur fuer
  14 Tage. Danach greift wieder die Vollsperre.
- Ein zweites Update innerhalb der Frist ersetzt sie, statt sie zu
  verlaengern - eine Kette schneller Updates haelt also keine sehr alte
  Version beliebig lange gueltig.
- Die Frist ist signiert (Integritaetsschema 12) und wird ueber die
  manipulationsfeste Uhr gemessen. Von Hand verlaengern schlaegt fehl.

Wichtig fuer Version 0.62.49:
- Ueberholt durch die Beta-Freischaltung: Einloesen und Verlaengern eines
  Freischaltcodes schalten ein Geraet NICHT in den Servermodus. Die Frist
  fuer Lockerungen bleibt die lokale.
- Vorbereitung fuer die Serverautoritaet. Ein Geraet kann mit einem
  Freischaltcode an den Purestate-Server gebunden werden. Danach werden die
  72 Stunden Vorlauf fuer Abschwaechungen vom Server gemessen und nicht mehr
  von diesem PC, und das Fenster oeffnet nur eine signierte Freigabe.
- Ohne Freischaltung aendert sich nichts: es gelten weiterhin sieben Tage
  Vorlauf, lokal berechnet.
- Ist der Server nicht erreichbar, laeuft der Schutz unveraendert weiter. Es
  gibt dann keine Abschwaechung und keinen Rueckfall auf die lokale Frist.
  Eine bereits erteilte Freigabe bleibt ohne Netz gueltig.
- Der Wechsel zurueck auf die lokale Frist ist selbst eine Abschwaechung und
  braucht dieselbe Wartezeit.
- Der private Geraeteschluessel entsteht auf diesem PC und verlaesst ihn nie.
  Der Server speichert keine Schutzbereiche, Domains oder Nutzungszeiten.
- Der Autoritaetsserver ist unter https://api.purestate-app.com erreichbar;
  sein oeffentlicher Signierschluessel ist in dieser Fassung eingebettet.
  Die integrierte Fassung braucht vor Testerfreigabe frische Pruefungen und
  abgeglichene Betriebs-/Datenschutzangaben. Die geschlossene Beta bleibt
  bewusst unsigniert; eine Pruefsumme ersetzt keine Herausgebersignatur.

Wichtig fuer Version 0.62.46:
- UI-Feinschliff: Symbole nur noch in Navigation und Statusmeldungen,
  dunkle Scrollbalken und lesbare Hover-Farben im Dunkelmodus, eigene
  gestaltete Bestaetigungsdialoge statt heller Systemfenster.
- Eingaben modernisiert: Uhrzeiten und Minuten-Limits als Auswahllisten,
  Stueckzahlen und Budget mit Minus/Plus-Steppern, passende Button-Verben
  statt ueberall "Oeffnen". Die doppelte Zeile "Geschuetzte Webseiten
  waehlen" in den Einstellungen entfaellt.
- Einstellungsdialoge gruppieren Abschnitte jetzt als Karten.
- Schutzlogik, Passwortabfragen, Monatsfenster und Fail-closed-Verhalten sind
  unveraendert. Es wurde keine installierte Kopie veraendert oder live getestet.

Wichtig fuer Version 0.62.45:
- Ruhigeres Windows-Security-Design: Navigation und Status verwenden klare
  Symbole plus Text, Schutzbereiche stehen in gleich breiten Zeilen, und
  Aktionen folgen einem einheitlichen Zeilenmuster.
- Einstellungsdialoge sind breiter, bleiben bei 100/150/200 Prozent DPI
  scrollbar und verwenden auch im Dunkelmodus einheitlich gestaltete
  Eingabefelder, Listen und sichtbare Rahmen. Die Erwachsenen-Seitenliste
  ist zweispaltig; Videospiele zeigen einen echten Leerzustand.
- Schutzlogik, Passwortabfragen, Monatsfenster und Fail-closed-Verhalten sind
  unveraendert. Es wurde keine installierte Kopie veraendert oder live getestet.

Wichtig fuer Version 0.62.44:
- Die UI-Ueberarbeitung (0.62.43) ist mit den Staenden 0.62.42 und 0.62.41
  zusammengefuehrt. Die neuen Schutzbereichs-Dialoge speichern ueber die
  Monatsfenster-geschuetzten Setter, sodass schutzabschwaechende Aenderungen
  weiterhin nur am 1. Kalendertag eines Monats moeglich sind.

Wichtig fuer Version 0.62.43:
- Die Windows-Oberflaeche wurde vollstaendig ueberarbeitet: vier klare
  Bereiche (Start, Schutzbereiche, Einstellungen, Mehr), einfache Sprache
  mit echten Umlauten, groessere Schrift und Bedienelemente, vergroesserbares
  Fenster, scrollbare Dialoge, Hochkontrast-Unterstuetzung.
- Schutzbereiche lassen sich jetzt ohne Passwort ANSEHEN; das Passwort wird
  erst beim SPEICHERN von Aenderungen verlangt. Jede Aenderung bleibt damit
  genauso passwortgeschuetzt wie bisher.
- Technische Werkzeuge (Diagnose, Protokolle, Reparatur, Dev-Modus) liegen
  jetzt gesammelt unter "Mehr" und sind klar vom Alltag getrennt.
- Schutzlogik, Konfigurationsfelder und Sicherheitsgrenzen sind unveraendert.

Wichtig fuer Version 0.62.42:
- Purestate.exe zeigt jetzt ein eigenes Fenster- und Tray-Symbol. Beim
  Windows-Login startet ein sichtbarer Tray-Prozess und meldet kurz, ob
  Purestate aktiv ist; der eigentliche Schutz bleibt weiter Aufgabe des
  Windows-Dienstes und Watchdogs.
- Passwortgeschuetzte Einstellungen, die den Schutz abschwaechen, werden
  nur am 1. Kalendertag eines Monats gespeichert. Staerkende Aenderungen
  wie niedrigere Tagesbudgets oder zusaetzliche Sperren bleiben sofort
  moeglich. Im Dev-Modus ist diese Monatsfenster-Sperre aus.

Wichtig fuer Version 0.62.41:
- Selector-Canary-Misses fuer Pixiv, DeviantArt, Instagram, Imgur,
  Newgrounds und Tumblr fuehren nach wiederholtem Miss temporaer zu einer
  per-site Browser-URLBlocklist-Sperre. Die Sperre laeuft nach 24 Stunden
  ohne neuen Miss aus, respektiert deaktivierte Webseiten-Schutz-Schalter
  und speichert nur Site-/Check-Tokens, keine Seiteninhalte oder URLs.

Wichtig fuer Version 0.62.40:
- Shopping und Social Media sind Reibungs-Bereiche: ihr Modus ist jetzt
  ehrlich aus/geplant/sanft (ein "streng" ohne zusaetzliche Durchsetzung
  gibt es dort nicht mehr; harte Sperren greifen weiterhin fuer selbst
  gewaehlte Plattformen und Domains). Am Schutzumfang aendert sich nichts.

Wichtig fuer Version 0.62.39:
- Der Companion deckt Gluecksspiel- und Shopping-Seiten jetzt dynamisch ab:
  Domains aus den Purestate-Domainlisten (auch selbst ergaenzte) bekommen
  die Soft-Features (Overlays, Checkout-Verzoegerung, Zeitbudgets), nicht
  mehr nur die fest eingebaute Seitenliste.
- Dafuer verlangt die Erweiterung jetzt die Browser-Berechtigung "Zugriff
  auf alle Websites". Es werden weiterhin keine Seiteninhalte erfasst oder
  uebertragen; die Entscheidung faellt lokal pro Hostname. Die Aenderung
  wirkt erst nach dem naechsten Web-Store-Update der Erweiterung.

Wichtig fuer Version 0.62.38:
- Neuer selektiver Social-Media-Modus "Nur Feed": Ablenkungsflaechen wie
  Instagram-Reels/Explore, YouTube-Shorts, X-Explore, Reddit r/popular
  und r/all sowie Tumblr-Explore lassen sich sperren, waehrend der Rest
  der Plattform (DMs, Suche, Abos) nutzbar bleibt. Vollsperre und
  Feed-Sperre schliessen sich aus; die Vollsperre gewinnt.
- Ehrliche Grenze: TikTok, Pinterest und Bluesky bestehen fast nur aus
  Feed bzw. haben instabile Routen - dort gibt es nur die Vollsperre.
  Die Companion-Aenderung wirkt erst nach dem naechsten Web-Store-Update
  der Erweiterung.

Wichtig fuer Version 0.62.37:
- SafeSearch wird jetzt ueber Google hinaus erzwungen: YouTube laeuft im
  moderaten eingeschraenkten Modus (Browser-Richtlinie), Edge erzwingt
  striktes Bing-SafeSearch, und der Companion setzt auf Bing, DuckDuckGo
  und Yandex die dokumentierten Safe-Parameter direkt in der Such-URL
  (adlt=strict, kp=1, family=yes).
- Ehrliche Grenze: Ecosia und Startpage haben keine verlaesslichen
  Safe-Parameter und bleiben beim Blocken von Suchen mit expliziten
  Begriffen; Firefox kennt keine SafeSearch-Richtlinien. Die
  Companion-Aenderung wirkt erst nach dem naechsten Web-Store-Update der
  Erweiterung.

Wichtig fuer Version 0.62.36:
- Im strengen Videospiel-Modus werden jetzt auch Cloud-Gaming-Dienste
  (GeForce Now, Boosteroid, Amazon Luna, Xbox Cloud Gaming ueber
  xbox.com/play, u. a.) und grosse Browser-Spiele-Portale (Poki,
  CrazyGames, Miniclip usw.) im Browser gesperrt. xbox.com selbst bleibt
  nutzbar (Store, Konto, Game-Pass-Verwaltung) - nur der Spielbereich
  /play ist blockiert.
- Ehrliche Grenze: Der sanfte Modus (Tagesbudget/Sperrzeit) misst und
  begrenzt Cloud- und Browser-Spielzeit weiterhin nicht; die Sperre gilt
  nur im strengen Modus.

Wichtig fuer Version 0.62.35:
- Die automatische Spiel-Heuristik verschont bekannte GPU-intensive
  Kreativ-, Streaming-, CAD- und Benchmark-Programme (z. B. Blender,
  OBS, Unreal-/Unity-Editor, DaVinci Resolve, 3DMark). Ein erstmals
  per Heuristik als Spiel eingestuftes Programm erhaelt vor dem Beenden
  einmalig 5 Minuten Zeit zum Speichern statt 60 Sekunden - genug, um
  bei einer Fehleinstufung eine "Kein Spiel"-Ausnahme einzutragen.

Wichtig fuer Version 0.62.34:
- Auch die monatlichen Shopping-Grenzen (Bestellanzahl und geschaetztes
  Budget) zaehlen jetzt manipulationsgeschuetzt auf dem PC statt nur im
  Browser - wie seit 0.62.33 die taeglichen Zeitbudgets. Browserdaten
  loeschen setzt den Monatszaehler nicht mehr zurueck.

Wichtig fuer Version 0.62.33:
- Die taeglichen Zeitbudgets fuer Social Media, Shopping und Gluecksspiel
  zaehlen jetzt manipulationsgeschuetzt auf dem PC statt nur im Browser:
  Der Schutzdienst fuehrt den Tageszaehler in einem geschuetzten
  Systemverzeichnis. Browserdaten loeschen, ein frisches Profil, ein
  zweiter Browser oder eine Neuinstallation der Erweiterung setzen das
  Budget nicht mehr zurueck.
- Ehrliche Grenze: Der Zaehler gilt pro PC (kein Geraeteabgleich). Ist der
  Schutzdienst nicht erreichbar, greift wie bisher die Vollsperre der
  geschuetzten Seiten.

Wichtig fuer Version 0.62.32:
- Spiele mit Anti-Cheat-Schutz (z. B. EasyAntiCheat, BattlEye) werden jetzt
  zuverlaessig erkannt und beendet: Der Schutzdienst liest den Programmpfad
  solcher Prozesse ueber eine vom Anti-Cheat erlaubte Systemabfrage.
- Bekannte Android-Emulatoren (BlueStacks, LDPlayer, Nox, MEmu, MuMu,
  GameLoop, Google Play Games) werden ueber ihre Installationseintraege
  erkannt und wie erkannte Spiele behandelt (Sofort-Beendigung in der
  Vollsperre, Tagesbudget, Sperrzeit).

Wichtig fuer Version 0.62.30:
- Spiele werden jetzt automatisch erkannt: Installationen aus Steam, Epic,
  GOG, EA, Battle.net und dem XboxGames-Ordner erkennt der Schutzdienst
  ueber ihre Installationsverzeichnisse und behandelt sie wie eingetragene
  Ziele (gemeinsames Tagesbudget, Sperrzeit, Vollsperre). Optional stuft
  eine Verhaltens-Heuristik auch unbekannte (portable) Spiele nach ca.
  2 Minuten anhaltender 3D-Grafiklast ein; in Sperrfaellen gibt es vor dem
  Beenden eine 60-Sekunden-Warnung zum Speichern.
- Nicht-Spiel-Ausnahmen fuer die Heuristik lassen sich nur mit Passwort
  anlegen und werden erst nach 15 Minuten wirksam; Entfernen ist jederzeit
  frei. Eingetragene Ziele und erkannte Store-Spiele sind nie ausnehmbar.
- Ehrliche Messgrenze: gemessen wird die Laufzeit gestarteter Spielprozesse
  (Prozess laeuft), nicht die aktive Vordergrundnutzung. Browser- und
  Cloud-Gaming sowie UWP-Spiele ausserhalb des XboxGames-Ordners werden
  weiterhin nicht erkannt. Spieleplattform-Launcher (Steam, Epic usw.)
  werden nie automatisch gesperrt; sie lassen sich nur ausdruecklich und
  mit Warnung als breit wirkendes Ziel eintragen. Kritische Windows-,
  Sicherheits- und Purestate-Prozesse koennen nicht als Ziel gespeichert
  werden.
- Fuenf neue technische Einstellungen sind HMAC-kanonisch: Integritaetsschema
  5. Gueltige Schema-4-Signaturen (0.62.22-0.62.28) und aeltere gueltige
  Schemata werden beim Update akzeptiert und migriert; in alte Signaturen
  eingeschleuste Videospiel-Schluessel gelten als manipuliert und erzwingen
  den Vollschutz. Der Videospielschutz ist standardmaessig aus und wird bei
  bestehenden Nutzern nicht automatisch aktiviert. Der lokale Tageszaehler
  (video-games-usage.json) bleibt ausserhalb von Backups. Wird ein Spiel
  beendet, schreibt der Dienst den vollstaendigen Programmpfad ins lokale
  Dienstprotokoll und der Diagnosebericht zeigt ihn an - nur so kannst du eine
  Fehleinstufung erkennen und den Pfad als Ausnahme eintragen. Aus dem
  Benutzerordner wird dabei der Benutzername entfernt
  (C:\Users\<redacted>\...), bevor der Bericht weitergegeben wird.

Wichtig fuer Version 0.62.28:
- Diese Version kennzeichnet den neuen Live-Teststand nach Abschluss der
  technischen Haertung von 0.62.27. Schutzlogik, Datenformat und die
  technische Beta-Grenze bleiben unveraendert.

Wichtig fuer Version 0.62.26:
- Social-Media-Feinschliff: Die Endlos-Scroll-Bremse kann jetzt in der
  Purestate-App auf eine eigene Scroll-Schwelle eingestellt werden (Standard
  50). Der Scroll-Stopp zaehlt als voller Pause-Screen, pausiert und mutet
  Videos/Audio auch bei spaeter nachgeladenen Short-Form-Playern, und die
  Social-Media-Zeitmessung laeuft darunter nicht weiter.
- Der erste 5-Sekunden-Wartescreen zaehlt nach echter Uhrzeit statt nach
  verpassten Timer-Ticks. Wenn eine Plattform beim Laden kurz haengt, wird der
  Weiter-Knopf nach Ablauf trotzdem sofort freigegeben, sobald die Seite wieder
  reagiert.
- Auf bereits offenen YouTube-Video-Tabs wird der Reflexionsscreen erst gebaut,
  wenn der Tab sichtbar und der Seiten-Renderer wieder idle ist. Dieser erste
  Wartescreen fasst weder den laufenden YouTube-Player noch die globalen
  Sichtbarkeits- und Scroll-Styles der bereits geladenen Seite an. Er legt nur
  seinen eigenen festen Overlay-Knoten an und entfernt ihn wieder. Die harte
  Sperre, Curfew, Zeitlimit und der Scroll-Stopp pausieren Videos/Audio
  weiterhin. Der Weiter-Knopf ist gegen YouTube-Seiten-CSS isoliert.

Wichtig fuer Version 0.62.21:
- Social-Media-Feinschliff aus der ersten Live-Runde: Videos/Audio werden
  unter Vollsperren-Overlays pausiert und stummgeschaltet, der
  Zurueck-Knopf verlaesst die Plattform zuverlaessig, aufgehobene Sperren
  laden den Tab automatisch neu, ein Rest-Zeit-Badge zeigt live die
  verbleibende Zeit, und die Scroll-Bremse stoppt nach 50 Scrolls mit
  einer kurzen Zeitbilanz und Vorschlaegen.

Wichtig fuer Version 0.62.20:
- Neuer Schutzbereich Social Media: taegliches Gesamtbudget ueber X/Twitter,
  Instagram, TikTok, Pinterest, Tumblr, Bluesky, Reddit und YouTube,
  optionale Einzel-Limits und eine Vollsperre pro Plattform (Achtung: die
  YouTube-Vollsperre sperrt YouTube komplett, auch Tutorials und Musik).
  Dazu Sperrzeit-Fenster, eine Reflexionsfrage beim ersten Oeffnen am Tag
  und eine Endlos-Scroll-Bremse. Zeitstaende bleiben lokal im
  Browser-Profil; es zaehlt nur ein sichtbarer, fokussierter Tab.
- Bestehende Konfigurationen werden beim Update automatisch auf das neue
  Integritaetsschema uebernommen; alle neuen Funktionen sind standardmaessig
  aus, bis du den Bereich Social Media aktivierst.

Wichtig fuer Version 0.62.19:
- Update-/Reparaturlauf: bestehende 0.62.18-Konfigurationen werden mit
  dem aktuellen Integritaetsschema akzeptiert und migriert. Ein uebrig
  gebliebener Installationsordner ohne Config blockiert die Neuinstallation
  nicht mehr. Der installierte Native Host wird vor dem Dateiaustausch
  beendet, damit PurestateNativeHost.exe nicht gesperrt bleibt.
- Taegliche Zeitlimits: Shopping ist ab Werk auf 30 Minuten begrenzt;
  Gluecksspielseiten auf 15 Minuten, solange der strenge Vollschutz aus ist.
  Es zaehlt nur ein sichtbarer, fokussierter Tab. Die Zeitstaende bleiben
  lokal im Browser-Profil. Das Gluecksspiel-Limit gilt fuer die 42 konkret
  im Companion gelisteten Anbieter-Domains; es gibt keine globale Tab-URL-
  Berechtigung.
- Shopping-Monatslimit: standardmaessig blockiert der geschuetzte Checkout
  beim 10. monatlichen Kaufversuch bis zum Monatswechsel. Optional kann ein
  Monatsbudget verwendet werden. Purestate speichert Kauf-Schaetzbetraege nur,
  wenn du sie freiwillig eintraegst - grob, ganzzahlig und lokal im Browser-
  Profil, nie in Windows-Konfiguration, Backups oder Logs. Die eingestellte
  Budgetgrenze selbst ist normale Konfiguration. Bank-, Zahlungs- und
  Bestelldaten werden nicht gelesen.
- Der Wartescreen zeigt drei wechselnde Fragen aus einem Zehnerpool. Weitere
  zeitlich begrenzte Angebote, Blitzdeals und Prozent-Sparreize werden
  gedaempft. Fuer die neuen Shop-/Gluecksspiel-Hosts ist ein Companion-
  Update im Chrome Web Store erforderlich.

Wichtig fuer Version 0.62.17:
- Fehlerbehebung fuer alle Bereichs-Schalter: Die Browsererweiterung erhielt
  die Schutz-Einstellungen bisher nicht zuverlaessig, weil die gehaertete
  Konfigurationsdatei fuer normale Benutzerkonten nicht lesbar ist. Die App
  spiegelt jetzt die unkritischen Schalter (Bereiche, Shopping-Bremsen,
  Webseiten-Schalter) in eine lesbare Zustandsdatei. Ohne dieses Update
  bleiben Shopping-Wartezeit, Sperrzeit und Deal-Suchblock im Browser wirkungslos.

Wichtig fuer Version 0.62.16:
- Einstellungen wirken jetzt sofort: Speichern in der Windows-App erreicht
  offene Browser-Tabs in wenigen Sekunden (dauerhafte Verbindung zwischen
  Erweiterung und Windows-Schutzdienst). Kein Tab-Neuladen und kein
  Browser-Neustart mehr noetig.

Wichtig fuer Version 0.62.15:
- Neuer Schutzbereich Shopping: passwortgeschuetztes Modul mit lokalem
  Hilfe-Hub (Check-in, Impuls verzoegern, Motivation und Regeln, Notfallplan,
  Reflexion, Fortschritt, Hilfequellen) und fuenf sanften Kaufbremsen:
  Checkout-Wartezeit auf 12 Shop-Seiten, Ausblenden von Kaufreiz-Elementen,
  Deal-/Gutschein-Suchblock, Shopping-Pause (Zeitfenster) und eigene
  Shop-Sperrliste. Es werden keine Betraege oder Bestelldaten gespeichert.
- Companion-Erweiterung braucht ein Update im Web Store (neue Shop-Seiten und
  die storage-Berechtigung fuer lokale Wartezeit-Zeitstempel).

Wichtig fuer Version 0.62.14:
- Schutzbereich-Modell: Neben "Aus", "Geplant" und "Streng" kennt Purestate
  jetzt den Modus "Sanft" (gentle) als Vorbereitung fuer die kommenden
  Bereiche Shopping, Videospiele und Social Media. Der Modus erzwingt in
  dieser Version noch nichts - nur "Streng" blockiert. Verhalten bestehender
  Installationen aendert sich nicht.
- Companion: Die Erweiterung uebernimmt Schutzbereiche jetzt generisch vom
  Windows-Schutzdienst statt ueber eine feste Liste. Neue Bereiche brauchen
  kuenftig keine Companion-Codeaenderung mehr.
- Hilfe und Notfall: Die lokalen Hilfsfunktionen (Check-in, Impuls verzoegern,
  Trigger, Notfallplan, Fortschritt, Reflexion, Hilfe) sind intern
  bereichsuebergreifend aufgebaut. Fuer Gluecksspiel aendert sich nichts:
  gleiche Datei (gambling-support.txt), gleiche Texte, gleiche Ablaeufe.

Wichtig fuer Version 0.62.13:
- Dev-Modus: Wenn eine gueltige Dev-Companion-ID eingetragen ist, gibt
  Purestate die erzwungene Installation des offiziellen Web-Store-Companions
  frei. So kannst du den Store-Companion in Chrome/Edge deaktivieren und eine
  entpackte, noch nicht im Web Store veroeffentlichte Companion-Version testen.
  Die dafuer erzeugte Native-Host-Manifestkopie liegt im fuer Chrome lesbaren
  Installationsordner, nicht im abgesperrten ProgramData-Datenordner.
  PurestateNativeHost.exe akzeptiert die eingetragene Dev-ID jetzt auch selbst;
  vorher konnte der Host trotz lesbarem Manifest den Dev-Origin ablehnen.
  Fehlt oder stoppt die eingetragene Test-Erweiterung, bleibt der Browser
  fail-closed geschuetzt. Ohne Dev-ID wird der offizielle Web-Store-Companion
  weiter automatisch erzwungen.
- Gluecksspiel-Schutz: die lokale Domain-Sperre wurde mit aktuellen
  GGL-gelisteten Sportwetten-/Automaten-Domains ergaenzt. Neben tipico.com
  werden jetzt auch bet365.de sowie Merkur-Domains wie merkur-sports.de,
  merkurbets.de, merkurslots.de, jackpotpiraten.de und bingbong.de in die
  Chromium-URLBlocklist uebernommen, sobald Gluecksspiel-Schutz aktiv ist und
  die Regeln nach Update/Reparatur neu angewendet wurden.
- Fail-Closed: Wenn der Companion fehlt, deaktiviert oder stale ist, schreibt
  der Guard die Gluecksspiel-Domains jetzt selbst in die Chrome/Edge-Sperre,
  sobald Gluecksspiel-Schutz aktiv ist. Dadurch bleiben bet365.com, bet365.de,
  tipico.com, Merkur-/Automaten-Domains und eigene Gluecksspiel-Domains auch in
  diesem Vollsperrmodus blockiert.
- Strenger Gluecksspiel-Schutz: Purestate blockiert jetzt neben lizenzierten
  und bekannten Anbietern auch konkrete Offshore-/graue Gluecksspiel-Domains
  wie playzilla.com sowie kleine Affiliate-/Casino-Bonus-Domainlisten. Die
  Listen greifen lokal ueber Hosts, Chrome/Edge URLBlocklist und Guard-
  Vollsperre, sobald Gluecksspiel-Schutz aktiv ist.
- Lokale Ergaenzung: Im Gluecksspiel-Schutz kann eine konkrete Domain oder URL
  ueber "Gluecksspielseite blockieren" in custom-gambling-domains.txt
  aufgenommen und der Schutz neu angewendet werden.

Wichtig fuer Version 0.62.6:
- Gluecksspiel-Suche: Suchanfragen wie "online casino" werden jetzt schon per
  Browser-Richtlinie (URLBlocklist) auf allen Suchmaschinen blockiert - genau
  wie NSFW-Suchen. Vorher blieb die Google-Suche haengen (Service-Worker-
  Warmup), weil es keine Richtlinien-Sperre gab. Betrifft nur eindeutige
  Begriffe (casino, sportwetten, spielautomaten, tipico, bet365 ...); sehr
  mehrdeutige Woerter (poker, lotto, roulette) sind bewusst ausgenommen.
  Erfordert eine Neuinstallation/Reparatur, damit die Richtlinie neu
  geschrieben wird.

Wichtig fuer Version 0.62.5:
- Gluecksspiel-Suche: Suchanfragen wie "online casino"/"online casinos" werden
  jetzt genauso zuverlaessig blockiert wie NSFW-Suchen - unabhaengig davon, ob
  der Companion gerade den lokalen Schutzdienst erreicht. Die Domain-Sperre fuer
  Gluecksspiel bleibt an den Gluecksspiel-Schutz-Schalter gebunden.

Wichtig fuer Version 0.62.4:
- Reddit: Bilder harmloser Beitraege wurden im Feed (Startseite) weiter
  blockiert, weil Reddit die Alters-Abfrage grosser Feed-Bloecke ausbremst.
  Unbestaetigte Beitraege werden jetzt nicht mehr verdeckt. Echte NSFW-Inhalte
  bleiben durch das nsfw/over18-Kennzeichen, Badges, bestaetigte Metadaten und
  Reddits erzwungene Sichere-Suche/Unschaerfe gesperrt.
- Reddit: Profilbilder in Kommentaren wurden faelschlich verdeckt. Kommentar-
  Links steuern jetzt keine Medien-Sperre mehr, nur echte Beitrags-Links.
- Gluecksspiel: Auch Mehrzahl-Suchen wie "Online Casinos" werden jetzt blockiert.

Wichtig fuer Version 0.62.3:
- Reddit: Bilder harmloser Beitraege wurden faelschlich blockiert, wenn im
  Umfeld irgendwo "nsfw"/"18+"/"adult" im Text stand. Medien werden jetzt nur
  noch bei einem echten NSFW-Kennzeichen (Badge/Attribut/Post-Metadaten)
  gesperrt.
- Reddit: Der Text im "Zurueck"-Button der NSFW-Suche ist jetzt korrekt
  zentriert (Flexbox statt Block).
- Reddit: Gluecksspiel-Suchanfragen werden jetzt wie NSFW-Suchen mit dem
  Purestate-Overlay blockiert, sobald der Gluecksspiel-Schutz aktiv ist.

Wichtig fuer Version 0.62.2:
- Gluecksspiel-Schutz: Die Gluecksspiel-Domains werden jetzt zusaetzlich als
  Browser-Richtlinie (URLBlocklist in Chrome/Edge) gesperrt, nicht nur ueber die
  hosts-Datei. So greift die Sperre auch dann, wenn der Browser die hosts-Datei
  umgeht.
- Reddit: Der "Zurueck"-Button auf der blockierten NSFW-Suche ist wieder korrekt
  zentriert und verlaesst die blockierte Seite zuverlaessig. Die Sichere-Suche-
  Pruefung laeuft nur noch auf Such- und Einstellungsseiten, was normale Reddit-
  Seiten spuerbar entlastet.
- Installer: Nach erfolgreicher Installation startet Purestate automatisch und
  der Installer schliesst sich selbst.
- Deinstallation: Der leere Task-Scheduler-Ordner "\Purestate" wird jetzt
  ebenfalls entfernt. Eigene Backup-Dateien bleiben unberuehrt.

Wichtig fuer Version 0.62.1:
- Gluecksspiel-Schutz: Der Companion bekommt den aktiven Gluecksspielmodus jetzt
  vom Windows-Schutzdienst statt direkt aus dem geschuetzten Datenordner. Damit
  werden Gluecksspiel-Suchen wie "online casino" blockiert, sobald der Bereich
  aktiv ist.
- Gluecksspiel-Domains: stargames.de, stargames.at und stargames.com sind in der
  lokalen Sperrliste enthalten.
- Reddit: Der Zurueck-Button auf blockierten Reddit-Community-Seiten fuehrt
  nicht mehr auf eine ebenfalls blockierte NSFW-Suche zurueck, sondern verlaesst
  die blockierte Route. Zusaetzliche Diagnoseausgaben und ein aggressiver
  700-ms-Rescan wurden aus dem Live-Companion entfernt.

Wichtig fuer Version 0.62.0:
- Interne Haertung ohne sichtbaren Bedienungsunterschied: Browser-Richtlinien
  werden jetzt mit bereits vorhandenen (z. B. Firmen-/Schul-/Family-Safety-)
  Richtlinien zusammengefuehrt statt sie zu ueberschreiben; Installation,
  Deinstallation und die Wiederherstellung von DNS-/Proxy-Einstellungen sind
  robuster gegen Abbruchfehler.
- Die App heisst jetzt Purestate (frueher Clearstate). Nur der Name und die
  Installationspfade haben sich geaendert - der Schutz funktioniert
  unveraendert. Eine alte Clearstate-Installation vorher sauber
  deinstallieren.
- Diese Windows-Version erst installieren, nachdem der dazu passende Companion im Chrome Web Store veroeffentlicht wurde.
- Anzeige-Fix: der Webseiten-Schutz-Zaehler in der Uebersicht zeigte
  faelschlich "11/9"; er zeigt jetzt korrekt "11/11".
- Pinterest-Fail-Closed wurde auf alle im Companion abgedeckten Laenderhosts
  erweitert (z. B. pinterest.at, pinterest.ch, pinterest.co.uk,
  pinterest.com.au). Wenn der Companion fehlt oder nicht vertrauenswuerdig ist,
  werden diese Hosts nun wie pinterest.com/pinterest.de voll gesperrt.
- Instagram-Schutz verstaerkt: Adult-Begriffe in echten Instagram-Suchfeldern
  werden jetzt schon vor dem Absenden durch das lokale Purestate-Overlay
  verdeckt, damit Suchvorschlaege nicht nutzbar werden.
- Reddit/pixiv-Haertung: Reddits Zurueck-Schaltflaeche verlaesst blockierte
  SPA-Routen zuverlaessig, der neue Faceplate-18+-Schalter wird wieder auf AUS
  gesetzt, und pixiv-Adult-Suchen behalten Overlay/Seitenausblendung ohne
  sichtbares Flackern.
- Neuer Bereich "Schutzbereiche": Gluecksspiel-Schutz wird als
  gleichgewichtiger strenger Schutzbereich gefuehrt. Lokale Regeln fuer
  Domains, Suchbegriffe und gemischte Seiten koennen Wett-/Casino-Routen
  blockieren; Hilfe-, Check-in- und Notfallwerkzeuge bleiben sekundaer, lokal
  und freiwillig. Das ist keine medizinische oder therapeutische Behandlung und
  ersetzt keine professionelle Beratung.
- Windows-Haertung: Dienst-, Task-, ACL- und Firewall-Helfer werden aus
  System32 gestartet; Konfigurationswrites sind gesperrt und atomar; die
  Uninstall-Nachbereinigung laeuft aus geschuetztem ProgramData statt Temp.
- Robustheit: Hilfsprozesse werden mit Timeout und parallelem Output-Drain
  ausgefuehrt; Native-Heartbeat-Pipes koennen nicht unbegrenzt an einer
  halben Nachricht haengen.
- Diagnose-Logs sind groessenbegrenzt und einzeilig normalisiert. Technische
  Hilfsprozessdetails landen lokal im Aktivitaetslog statt direkt in
  Fehlerdialogen.
- Neue Passwoerter muessen mindestens 12 Zeichen haben und entweder drei
  Zeichenarten enthalten oder eine lange Passphrase ab 20 Zeichen sein. Der
  Passworthinweis darf das Passwort nicht enthalten.
- Aus 0.61.43 uebernommen: TikTok und Pinterest haben eigene
  Companion-Module mit eigenen Schaltern im Bereich "Webseiten-Schutz".
  Pinterest wird dabei auch auf den Laender-Adressen (de.pinterest.com,
  pinterest.de usw.) geschuetzt - vorher lief der Suchschutz dort nicht.
- Aus 0.61.43 uebernommen: abgesendete Instagram-Suchanfragen
  (Suchergebnis-Seiten) werden jetzt genauso blockiert wie Hashtags.
- Aus 0.61.42: erweiterter Suchmaschinen-Schutz (Ecosia, Startpage, Qwant,
  MetaGer, Bilder-/Video-Suchen), erweiterte Begriffsliste inklusive
  deutscher Begriffe und Verschleierungen (z. B. "pr0n", "s3x").
- Der Bereich "Webseiten-Schutz" erlaubt weiterhin pro Webseite, ob Purestate dort Companion-Regeln erzwingen soll.
- Die Erweiterung wird danach automatisch installiert; Entwicklermodus und "Entpackte Erweiterung laden" werden nicht mehr verwendet.
- Beim ersten Richtlinienwechsel kann Purestate Chrome einmal schliessen.

Reparieren oder aktualisieren:
- Starte "Installieren.exe" erneut.
- Nutze bei Bedarf zuerst "Vorabcheck", um zu sehen, ob Paketdateien und Windows-Werkzeuge bereit sind.
- Wenn Purestate schon installiert ist, muss das bestehende Purestate-Passwort fuer Reparatur oder Aktualisierung eingegeben werden.
- Der Installer erneuert Dateien, Dienst, Startmenue-Eintraege und Windows-App-Eintrag.
- Nach erfolgreicher technischer Konfigurationsaktualisierung entfernt er nur
  gambling-support.txt, shopping-support.txt und social-media-support.txt aus
  dem Purestate-Datenordner. Andere Dateien werden nicht als Teil dieser
  Datenbereinigung geloescht.

Vorabcheck:
- Der Vorabcheck nimmt keine Aenderungen am System vor.
- Er zeigt, ob Administrator-Rechte, PowerShell, sc.exe, schtasks.exe, ipconfig.exe und icacls.exe vorhanden sind.
- Er prueft die enthaltenen EXE-Dateien, Skripte und Regeldateien.
- Er startet nur die eingebauten Skript-Selbsttests mit "-SelfTest".
- Der Bericht kann kopiert werden, falls spaeter eine Fehlersuche noetig ist.

Was blockiert wird:
- lokale Sperrliste aus rules\adult-domains.txt
- automatische www-/ohne-www-Varianten der lokalen Sperrliste
- eigene Domains aus rules\custom-domains.txt
- lokale Gluecksspiel-Sperrlisten aus rules\gambling-domains.txt,
  rules\offshore-gambling-domains.txt, rules\gambling-affiliate-domains.txt
  und rules\custom-gambling-domains.txt, wenn Gluecksspiel-Schutz aktiv ist
- lokale Ausnahmen aus rules\allow-domains.txt werden nicht in die Hosts-Sperre geschrieben
- URL-Regeln aus rules\mixed-site-url-patterns.txt fuer pornografische Bereiche auf gemischten Webseiten
- Browser Companion mit eigenen Schutzregeln fuer Reddit, X/Twitter, Bluesky, Tumblr, DeviantArt, pixiv, Newgrounds, Imgur, Instagram, TikTok und Pinterest
- Browser Companion blockiert pornografische Suchanfragen auf Google, Bing, DuckDuckGo, Brave, Yahoo, Yandex, Ecosia, Startpage, Qwant, MetaGer, YouTube und Giphy
- Such- und Plattformmuster aus rules\adult-url-keywords.txt
- Gluecksspiel-Suchbegriffe und URL-Muster aus
  rules\gambling-search-terms.txt und rules\gambling-url-keywords.txt, wenn
  Gluecksspiel-Schutz aktiv ist
- Netzwerkzugriff bekannter Umgehungsprogramme aus rules\bypass-app-keywords.txt, wenn passende Programme gefunden werden
- Netzwerkzugriff bekannter nicht unterstuetzter Browser aus rules\unsupported-browser-keywords.txt
- Familien-DNS ueber auswaehlbare Profile: Cloudflare Family, CleanBrowsing Family oder OpenDNS FamilyShield
- Browser-DNS-over-HTTPS wird fuer Chrome, Edge und Firefox per Richtlinie deaktiviert, soweit der Browser diese Richtlinie respektiert
- Chrome/Edge: privater Modus/Gastmodus und Google SafeSearch werden per Richtlinie gesetzt; der pauschale YouTube Restricted Mode bleibt aus
- Chrome/Edge: bekannte Porno-/NSFW-Pfade auf gemischten Webseiten werden per URLBlocklist
  gesperrt, soweit die Chromium-Filtersyntax sie ausdruecken kann: Praefixpfade wie
  reddit.com/r/<name> - darunter alle kuratierten NSFW-Subreddits. Muster mit einem
  Wortbestandteil (Subreddit-Name *enthaelt* ein Signalwort) und Suchseiten-Muster kennt
  die Filtersyntax nicht; die setzt der Browser Companion durch. Fehlt der Companion,
  greift die Vollsperre der gemischten Seiten.
- Firefox: privates Browsen, DNS-over-HTTPS und bekannte Porno-/NSFW-Pfade werden per Richtlinie eingeschraenkt

Webseiten-Schutz:
- In Purestate.exe unter "Einstellungen" > "Webseiten-Schutz" kann der Schutz
  fuer Reddit, X/Twitter, Bluesky, Tumblr, DeviantArt, pixiv, Newgrounds,
  Imgur, Instagram, TikTok und Pinterest einzeln ein- oder ausgeschaltet werden.
- Diese Aenderung ist passwortgeschuetzt. Browser-Haertung, DNS,
  Hosts-Sperrliste und Umgehungsschutz bleiben getrennt aktiv.

In der App:
- "Schutzbereiche" enthaelt Erwachseneninhalt und Gluecksspiel als
  gleichgewichtige Schutzbereiche. Der Gluecksspiel-Schutz ist standardmaessig
  aus und kann passwortgeschuetzt aktiviert werden.
- "Informationen und Hilfe" zeigt statische Grenzen des Produkts sowie
  offizielle und professionelle Anlaufstellen. Diese Ansicht hat keine
  persoenlichen Eingabefelder und speichert nichts.
- "Einstellungen" legt fest, welche Schutzarten aktiv sein sollen, inklusive Umgehungsschutz, Browser-Kontrolle und Zeitplan.
- "Pausieren" fragt nach einer Dauer und kann den Schutz automatisch wieder aktivieren lassen.
- Wenn der Strenge Modus im aktiven Zeitplan laeuft, ist Pausieren nicht erlaubt.
- "Passwort" aendert Passwort und optionalen Hinweis.
- "Domains" verwaltet die eigene Sperrliste direkt in der App.
- "Allowlist" verwaltet lokale Ausnahmen direkt in der App.
- "Domain testen" zeigt, ob eine Domain lokal gelistet oder bereits aktiv gesperrt ist.
- "Gesundheit" zeigt, ob Dienst, App-Eintrag, Regeln und Dateien korrekt aussehen.
- "Schutztest" prueft die wichtigsten Schutzkomponenten in einem kopierbaren Bericht.
- "Regelcheck" prueft Sperrlisten, Allowlist, Mixed-Site-URL-Regeln und URL-Begriffe.
- "Integritaet" prueft installierte Dateien, Skripte und Regeln mit SHA-256-Pruefsummen.
- "Umgehung" zeigt Hinweise auf VPNs, Tor, Proxy, portable Browser und Browser-Haertung.
- Der Umgehungsschutz schreibt reversible Windows-Firewall-Regeln mit eindeutigem Purestate-Namen.
- Die Browser-Kontrolle schreibt ebenfalls reversible Windows-Firewall-Regeln mit eindeutigem Purestate-Namen.
- "Reparieren" stellt Dienst, Watchdog, Startmenue, Windows-App-Eintrag und Schutzregeln wieder her.
- "Backup" speichert Einstellungen und eigene Domains in eine Datei.
- "Wiederherstellen" spielt Einstellungen und eigene Domains aus einem Backup ein.
- "Logs anzeigen" zeigt die letzten Aktivitaets-, Sicherheits- und Dienstmeldungen.
- "Diagnose" erstellt einen kopierbaren Bericht mit Status, Browser-Richtlinien, Einstellungen und Logauszug.

Sicherheitsprotokoll:
- Das Sicherheitsprotokoll liegt unter C:\ProgramData\Purestate\security.log.
- Es enthaelt Zeitpunkte und Aktionsnamen, aber keine Passwoerter.
- Es protokolliert Passwortfreigaben, falsche Passwortversuche, Pausen, Aktivierungen, Reparaturen, Backups und Deinstallation.
- Beim Entfernen von Purestate wird auch der Datenordner mit den Logs entfernt.

Passwort-Hinweis:
- Der Hinweis ist optional und soll nur beim Erinnern helfen.
- Der Hinweis wird lokal in der Konfiguration gespeichert.
- Der Hinweis ist kein Ersatz fuer das Passwort und erlaubt keine Freischaltung.
- Purestate lehnt neue Hinweise ab, die das neue Passwort enthalten.
- Backups enthalten weiterhin kein Klartext-Passwort.

Integritaetscheck:
- Der Check liest nur Dateien und aendert nichts.
- Er zeigt SHA-256-Pruefsummen, damit Veraenderungen spaeter verglichen werden koennen.
- Ab Version 20 vergleicht er die Dateien mit PurestateManifest.txt.
- Die optionale Allowlist darf fehlen und wird dann nicht als Fehler bewertet.
- Bei Problemen Installieren.exe erneut starten und Reparieren/Aktualisieren ausfuehren.

Umgehungscheck:
- Der Check entfernt keine Programme und aendert keine Netzwerkeinstellungen.
- Er meldet Hinweise, keine Garantie. Manche VPNs oder portable Browser koennen anders heissen.
- Ab Version 24 kann der Umgehungsschutz passende Programme per Firewall am Netzwerk hindern.
- Ab Version 26 koennen bekannte nicht unterstuetzte Browser ebenfalls per Firewall blockiert werden.
- Beim Pausieren oder Entfernen von Purestate werden diese Firewall-Regeln wieder entfernt.
- Ein normales Windows-Konto ohne Administrator-Rechte ist weiterhin wichtig.
- Fuer starken Schutz sollten Router-/Familienkontrollen als zweite Schutzschicht genutzt werden.

Schutztest:
- Der Schutztest aendert keine Einstellungen.
- Er prueft, ob die aktivierten Schutzarten auch wirklich sichtbar aktiv sind.
- Er zeigt, ob der Zeitplan gerade verlangt, dass der Schutz aktiv sein soll.
- Er nutzt lokale Beispieldomains aus der Sperrliste und zeigt, ob diese in der Hosts-Sperre stehen.
- Wenn der Schutz pausiert ist, bewertet er nur, ob Komponenten vorhanden sind.
- Bei Problemen zuerst "Reparieren" ausfuehren und danach den Schutztest wiederholen.

Regelcheck:
- Der Regelcheck aendert keine Listen.
- Er zeigt ungueltige Zeilen und doppelte Eintraege in jeder Regeldatei.
- Er zeigt Konflikte, wenn eine Domain gleichzeitig gesperrt und erlaubt ist.
- Er zeigt auch, ob die URL-Regeln fuer gemischte Webseiten vorhanden sind.
- Er zeigt auch, ob die Keyword-Datei fuer Such- und Plattformmuster vorhanden ist.
- Zum Aufraeumen in der App "Domains" oder "Allowlist" oeffnen und "Bereinigen" nutzen.

Gemischte Webseiten:
- Diese Stufe blockiert bekannte URL-Muster, nicht die gesamte Webseite.
- Beispiel: Reddit bleibt nutzbar, waehrend passende NSFW-/Porno-Subreddits und Suchseiten blockiert werden.
- Die selektive Nutzung geschuetzter gemischter Webseiten setzt einen
  aktuellen, aktiven und vertrauenswuerdigen Purestate Companion voraus. Fehlt
  er, ist er deaktiviert oder veraltet oder stammt er aus einem nicht
  vertrauenswuerdigen Pfad, sperrt Purestate die geschuetzten gemischten
  Webseiten vollstaendig (Fail-Closed).
- Der Browser Companion deckt zusaetzlich X/Twitter, Bluesky, Tumblr, DeviantArt, pixiv, Newgrounds, Imgur und Instagram mit eigenen, an die jeweilige Seite angepassten Regeln ab (z.B. erzwungener Sicherer Modus/Kontoeinstellungen, ausgeblendete Vorschaukarten, blockierte Erwachsenen-Suchen).
- Suchmaschinen bleiben nutzbar, waehrend typische Porno-/NSFW-Suchanfragen blockiert werden.
- Diese Stufe ist kein Bilderkennungsfilter und liest keine verschluesselten Seiteninhalte mit.
- Neue feste Muster koennen spaeter in rules\mixed-site-url-patterns.txt ergaenzt werden.
- Neue Such-/Plattformbegriffe koennen spaeter in rules\adult-url-keywords.txt ergaenzt werden.
- Nach Aenderungen Reparieren/Aktualisieren ausfuehren, damit Browser-Richtlinien neu geschrieben werden.

KI spaeter:
- KI ist fuer Bilder, Vorschaubilder und uneindeutige Inhalte sinnvoll.
- Vor KI sollten Domainlisten, Familien-DNS, Browser-Richtlinien, SafeSearch, Suchmuster und gemischte Webseiten ausgereizt sein.
- Wenn KI spaeter eingebaut wird, sollte sie lokal oder datenschutzsparsam laufen und Fehlalarme klar behandeln.

Backups:
- Backups enthalten kein Klartext-Passwort.
- Beim Wiederherstellen bleibt das aktuell eingerichtete Passwort erhalten.
- Backups enthalten eigene Sperrliste und Allowlist.
- Backups enthalten Zeitplan, Strengen Modus und Umgehungsschutz-Einstellung.
- Backups enthalten Schutzbereich-Konfiguration einschliesslich strengem
  Gluecksspiel-Schutz und eigenen Gluecksspiel-Domains.
- Backups enthalten ausschliesslich technische Konfiguration und Domainlisten,
  keine persoenlichen Tagebuch-, Check-in- oder Supportplan-Daten.
- Alte Backups bleiben fuer technische Einstellungen und Listen kompatibel.
  Die veralteten persoenlichen Supportabschnitte fuer Gluecksspiel, Shopping
  und Social Media werden ohne Dekodierung und ohne Dateischreibvorgang
  ignoriert.
- Nach dem Wiederherstellen werden die Schutzregeln passend zur wiederhergestellten Einstellung neu angewendet.

Zeitplan:
- Der Zeitplan ist taeglich und nutzt lokale Uhrzeit.
- Ein Bereich wie 22:00 bis 06:00 laeuft ueber Mitternacht.
- Wenn der Zeitplan aktiv ist, kann der Watchdog den Schutz wieder herstellen.
- Der Strenge Modus verhindert Pausieren waehrend eines aktiven Zeitfensters.

Browser-Kontrolle:
- Unterstuetzt sind aktuell Chrome, Edge und Firefox.
- Nicht unterstuetzte Browser koennen die gesetzten Browser-Richtlinien umgehen.
- Deshalb kann Purestate bekannte andere Browser wie Brave, Opera, Vivaldi, LibreWolf, Waterfox und portable Browser per Firewall blockieren.
- Die Liste ist transparent in rules\unsupported-browser-keywords.txt.

Abgebrochene Installation:
- Zwischen dem Entfernen des alten Dienstes und dem Kopieren der neuen Dateien
  gibt es ein Fenster ohne Schutzdienst. Der Systemzustand - hosts, DNS,
  Browser-Richtlinien, Firewall - bleibt in dieser Zeit bestehen.
- Bricht die Installation dort ab, ist der Ausweg ein erneuter Lauf von
  Installieren.exe. Er legt den Dienst neu an und ersetzt die Dateien.
- Das Hilfsskript scripts\Finish-Installer-Update.ps1 schliesst NUR den
  Austausch einer gesperrten Installieren.exe ab. Eine abgebrochene
  Installation setzt es nicht fort.

Eigene Domains und Unterdomains:
- Ein Eintrag sperrt die Domain selbst und ihre www.-Form.
- In der Hosts-Datei gilt genau das: weitere Unterdomains wie m.beispiel.de oder
  cdn.beispiel.de sind einzeln einzutragen, weil eine Hosts-Datei keine
  Platzhalter kennt.
- Die Browser-Sperrliste von Chrome und Edge deckt Unterdomains dagegen mit ab,
  und der Companion prueft ebenfalls Unterdomains.
- Wirksam ist der Unterschied dort, wo keine Browser-Richtlinie greift: in
  Firefox, in nicht unterstuetzten Browsern und wenn ein Browser seine
  Richtlinien umgeht.

Allowlist:
- Eine Domain in der Allowlist wird nicht lokal per Hosts-Datei blockiert.
- Eine Freigabe wirkt im Browser fuer die Domain UND ihre Unterdomains, in der
  Hosts-Datei dagegen nur fuer die Domain selbst und ihre www.-Form. Eine
  Freigabe ist im Browser also breiter als in der Hosts-Datei.
- Familien-DNS kann dieselbe Domain trotzdem blockieren, wenn der DNS-Anbieter sie als Erwachsenenseite einstuft.
- Der Domain-Test zeigt Konflikte an, wenn eine Domain gleichzeitig in Blockliste und Allowlist steht.

Watchdog:
- Die geplante Windows-Aufgabe heisst \Purestate\Watchdog.
- Sie prueft alle 5 Minuten, ob der Schutz aktiv sein soll.
- Wenn der Schutz zeitgesteuert pausiert ist, aktiviert sie ihn nach Ablauf wieder.
- Wenn der Schutz unbegrenzt pausiert ist, startet sie den Dienst nicht.
- Bei der Deinstallation wird die Aufgabe wieder entfernt.

Zeitpause:
- Beim Pausieren kann 15, 30, 60 Minuten, bis morgen oder unbegrenzt gewaehlt werden.
- Bei einer Zeitpause speichert die App nur den Ablaufzeitpunkt.
- Nach Ablauf setzt der Watchdog den Schutz wieder auf aktiv und startet den Dienst erneut.
- "Aktivieren" beendet jede laufende Pause sofort.

Wichtige Grenzen:
- Ein Windows-Administrator, der das Geraet und die lokal ausgefuehrte Software
  kontrolliert, kann Purestate technisch umgehen. Purestate bietet
  Widerstand gegen impulsive Umgehung, keine buchstaebliche Unumgehbarkeit.
- VPNs, Tor, portable Browser und manche Sicherheitsprogramme koennen Filter umgehen.
- Diese Version hat noch keine automatische Online-Aktualisierung der Blockliste.
- Fuer sehr starken Schutz sollte der normale Benutzer kein Windows-Admin sein.

Gespeicherte Daten:
- Konfiguration, Passwort-Hash, DNS-Sicherung und Logs liegen unter: C:\ProgramData\Purestate
- Das Passwort wird nicht im Klartext gespeichert.
- Purestate speichert keine persoenlichen Tagebuch-, Check-in- oder
  Supportplan-Daten. Die statische Ansicht "Informationen und Hilfe" speichert
  nichts.
- Die App sendet fuer die Beta-Freischaltung und Verlaengerung Code und
  oeffentlichen Geraeteschluessel an den Purestate-Server. Die Beta bleibt
  im lokalen Modus; normale Lockerungen benoetigen dort keinen Serveraufruf.
  Bestehende Geraete im gesonderten Servermodus senden auf Nutzeraktion
  Freigabeanfragen. Surfverlauf, Seiteninhalte, Einstellungen und
  Nutzungszaehler gehen nicht an Purestate. Einzelheiten stehen in
  docs/PRIVACY-POLICY.md.
  Die Browser-Erweiterung fragt ausserdem oeffentliche Schnittstellen der
  Plattformen ab, auf denen du gerade bist - siehe naechster Abschnitt.

Datenschutz bei Abfragen an Dritte:
Die Erweiterung erreicht genau drei Hosts, und nur diese drei:

- public.api.bsky.app (Bluesky): fuer die Label-Pruefung, mit den ohnehin
  sichtbaren Post-IDs. Ohne Anmeldedaten.
- www.reddit.com und old.reddit.com: fuer die Alterskennzeichnung einzelner
  Beitraege und Subreddits, ebenfalls nur mit den IDs, die im Browser bereits
  sichtbar sind. old.reddit.com wird als Ausweichweg abgefragt, wenn die
  Hauptadresse nicht antwortet - auch dann, wenn du diese Adresse selbst nie
  benutzt.

Zwei Punkte, die wir ausdruecklich nennen, weil sie sonst niemand sieht:
- Die Reddit-Abfragen laufen mit deiner bestehenden Reddit-Sitzung
  (Cookies werden mitgeschickt). Reddit kann sie damit deinem Konto zuordnen.
  Ohne Sitzung waeren manche Kennzeichen nicht sichtbar, und ein fehlendes
  Kennzeichen hiesse: nicht gesperrt.
- Texte, Bilder und Videos werden nie hochgeladen. Es gehen ausschliesslich
  Kennungen raus, keine Inhalte.

Aenderungsprotokoll:
Alle Versionsaenderungen sind in CHANGELOG.md dokumentiert.
