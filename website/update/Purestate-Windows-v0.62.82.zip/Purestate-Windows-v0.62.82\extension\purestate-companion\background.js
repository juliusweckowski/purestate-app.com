"use strict";

const REDDIT_CHECK = "purestate.checkRedditSubreddit";
const REDDIT_POSTS_CHECK = "purestate.checkRedditPosts";
const BLUESKY_POSTS_CHECK = "purestate.checkBlueskyPosts";
const BROWSER_RULES_GET = "purestate.getBrowserRules";
const CANARY_MISS_REPORT = "purestate.canaryMiss";
const ADULT_LEARN_HOST_MESSAGE = "purestate.adultLearnHost";
const TIME_TICK = "purestate.timeTick";
// Reine Leseabfrage. Live gefunden (2026-08-09): ein frisch geladener Tab
// wartete auf den ersten Tick, um vom erreichten Limit zu erfahren - und Ticks
// laufen nur bei Fokus. Wer neu lud oder den Tab im Hintergrund liess, bekam
// nie einen Vorhang. Zaehlen darf diese Abfrage nicht, sonst erfindet jedes
// Neuladen Nutzungszeit.
const TIME_STATE = "purestate.timeState";
const SOCIAL_TIME_TICK = "purestate.socialTimeTick";
const SOCIAL_TIME_STATE = "purestate.socialTimeState";
const SHOPPING_ORDER = "purestate.shoppingOrder";
const SHOPPING_SPEND = "purestate.shoppingSpend";
const SHOPPING_MONTH_GET = "purestate.shoppingMonth";
const TIME_TICK_SECONDS = 15;
const CANARY_FORWARD_MIN_INTERVAL_MS = 60 * 60 * 1000;
const COMPANION_HEARTBEAT_ALARM = "purestate.companionHeartbeat";
const COMPANION_HEARTBEAT_RETRY_ALARM = "purestate.companionHeartbeatRetry";
const ADULT_LEARN_RETRY_ALARM = "purestate.adultLearnRetry";
const ADULT_LEARN_RETRY_STORAGE_KEY = "purestateAdultLearnRetryQueue";
const ADULT_LEARN_RETRY_BASE_MS = 60 * 1000;
const ADULT_LEARN_RETRY_MAX_MS = 60 * 60 * 1000;
const ADULT_LEARN_RETRY_CAP = 500;
const ADULT_LEARN_RETRY_BATCH = 10;
const NATIVE_HOST = "com.purestate.companion";
const CACHE_TTL_MS = 10 * 60 * 1000;
const UNKNOWN_CACHE_TTL_MS = 30 * 1000;
const LOCAL_RULE_PACK_TTL_MS = 5 * 60 * 1000;
// Letztes gueltiges Regelpaket, dauerhaft gespeichert. Faellt der Dienst aus,
// gilt es weiter, hoechstens einen Tag - sonst hob jeder Ausfall die
// Tageslimits auf: der Takt rechnete mit dem leeren Standardpaket, und ein neu
// geladener Tab uebernahm es (Frontend-Audit, entschieden am 2026-09-19).
const LAST_VALID_RULE_PACK_KEY = "purestateLastValidRulePack";
const LAST_VALID_RULE_PACK_MAX_AGE_MS = 24 * 60 * 60 * 1000;
const HEARTBEAT_MIN_INTERVAL_MS = 20 * 1000;
const BLUESKY_POST_BATCH_SIZE = 25;
const BLUESKY_PROFILE_RESOLVE_BATCH_SIZE = 10;
const SOCIAL_MEDIA_PLATFORM_IDS = [
  "x", "instagram", "tiktok", "pinterest", "tumblr", "bluesky", "reddit", "youtube", "streaming"
];
// Plattformen mit eigenem Zeitbudget (Streaming, Tester-Notiz 2026-10-06):
// ihre Zeit zaehlt nicht ins gemeinsame Social-Media-Limit, und dieses gilt
// nicht fuer sie - ein Film frisst sonst das Limit fuer alles andere. Spiegel:
// SOCIAL_OWN_BUDGET_PLATFORMS in social-media-content.js und
// SocialMediaOwnBudgetPlatformIds in src\NativeSupportConfig.cs (gepinnt).
const SOCIAL_MEDIA_OWN_BUDGET_PLATFORM_IDS = ["streaming"];
// Platforms with a stable set of distraction routes for the selective feed
// block. Mirrors the route map in social-media-content.js (pinned by tests).
const SOCIAL_MEDIA_FEED_ROUTE_PLATFORM_IDS = [
  "instagram", "youtube", "x", "reddit", "tumblr"
];

const SITE_PROTECTION_KEYS = [
  "reddit",
  "x",
  "bluesky",
  "tumblr",
  "deviantart",
  "pixiv",
  "newgrounds",
  "imgur",
  "instagram",
  "tiktok",
  "pinterest"
];
const decisionCache = new Map();
const postDecisionCache = new Map();
const blueskyDecisionCache = new Map();
const blueskyHandleCache = new Map();
const BLUESKY_ADULT_LABELS = new Set([
  "adult",
  "explicit",
  "explicit-sexual",
  "nsfw",
  "nudity",
  "porn",
  "sexual"
]);
const SAFE_NAME_EXCEPTIONS = new Set([
  "loveafterporn",
  "nofap",
  "pornaddicted",
  "pornaddiction",
  "pornfree",
  "pornismisogyny"
]);
const ADULT_NAME_TERMS = [
  "gonewild",
  "hentai",
  "nudes",
  "nudity",
  "onlyfans",
  "porn",
  "rule34",
  "xxx"
];

let localSubredditListPromise = null;
let localRulePackCache = { checkedAt: 0, response: null };
let rulePackPushPort = null;
let rulePackPushReconnectDelayMs = 5000;
let lastHeartbeatAttemptAt = 0;
let timeTickQueue = Promise.resolve();
let adultLearnQueueWork = Promise.resolve();
const canaryForwardLast = new Map();

function companionBrowserName() {
  return /Edg\//i.test(navigator.userAgent) ? "Edge" : "Chrome";
}

function companionVersion() {
  const manifest = chrome.runtime.getManifest();
  return manifest.version;
}

function sendNativeMessage(payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendNativeMessage(NATIVE_HOST, payload, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message || "Native host unavailable." });
        return;
      }
      resolve(response || { ok: false });
    });
  });
}

function ensureCompanionHeartbeatAlarm() {
  chrome.alarms.create(COMPANION_HEARTBEAT_ALARM, { delayInMinutes: 1, periodInMinutes: 1 });
}

function scheduleCompanionHeartbeatRetry() {
  chrome.alarms.create(COMPANION_HEARTBEAT_RETRY_ALARM, { delayInMinutes: 0.5 });
}

function sendCompanionHeartbeat() {
  lastHeartbeatAttemptAt = Date.now();
  chrome.runtime.sendNativeMessage(NATIVE_HOST, {
    type: "heartbeat",
    browser: companionBrowserName(),
    version: companionVersion()
  }, (response) => {
    if (chrome.runtime.lastError || !response || response.ok !== true) {
      scheduleCompanionHeartbeatRetry();
    }
  });
}

function sendCompanionHeartbeatThrottled() {
  if (Date.now() - lastHeartbeatAttemptAt >= HEARTBEAT_MIN_INTERVAL_MS) {
    sendCompanionHeartbeat();
  }
}

chrome.runtime.onInstalled.addListener(() => {
  ensureCompanionHeartbeatAlarm();
  sendCompanionHeartbeat();
});

chrome.runtime.onStartup.addListener(() => {
  ensureCompanionHeartbeatAlarm();
  sendCompanionHeartbeat();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm && alarm.name === ADULT_LEARN_RETRY_ALARM) {
    retryPendingAdultLearnHosts();
    return;
  }
  if (alarm && (alarm.name === COMPANION_HEARTBEAT_ALARM || alarm.name === COMPANION_HEARTBEAT_RETRY_ALARM)) {
    sendCompanionHeartbeat();
  }
});

ensureCompanionHeartbeatAlarm();
sendCompanionHeartbeat();
connectRulePackPushPort();
resumeAdultLearnRetries();

// Long-lived native port: the host stays alive behind {type:"subscribe"} and
// pushes a fresh rule pack the moment the Windows app saves a protection
// change, so open tabs update in seconds instead of waiting out the cache
// TTL plus a manual reload. The minute heartbeat + TTL cache stay as the
// fallback path when the port is unavailable (e.g. host too old).
function connectRulePackPushPort() {
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.connectNative !== "function") {
      return;
    }
    const port = chrome.runtime.connectNative(NATIVE_HOST);
    rulePackPushPort = port;
    port.onMessage.addListener((message) => {
      rulePackPushReconnectDelayMs = 5000;
      applyPushedRulePack(message);
    });
    port.onDisconnect.addListener(() => {
      // Reading lastError marks the disconnect reason as handled (otherwise
      // Chrome logs "Unchecked runtime.lastError", e.g. when the dev native
      // manifest was overwritten by an update install).
      void (chrome.runtime && chrome.runtime.lastError);
      rulePackPushPort = null;
      const delay = rulePackPushReconnectDelayMs;
      rulePackPushReconnectDelayMs = Math.min(rulePackPushReconnectDelayMs * 2, 60000);
      setTimeout(connectRulePackPushPort, delay);
    });
    port.postMessage({
      type: "subscribe",
      browser: companionBrowserName(),
      version: companionVersion()
    });
  } catch {
    rulePackPushPort = null;
  }
}

function applyPushedRulePack(message) {
  return withLastValidRulePack({
    ok: !!(message && message.ok),
    rules: sanitizeBrowserRulePack(message && message.rules),
    source: message && message.ok ? "native-host-push" : "native-host-unavailable"
  }).then((sanitized) => {
    localRulePackCache = { checkedAt: Date.now(), response: sanitized };
    broadcastRulePack(sanitized);
  });
}

function broadcastRulePack(sanitized) {
  try {
    if (typeof chrome === "undefined" || !chrome.tabs || typeof chrome.tabs.query !== "function") {
      return;
    }
    chrome.tabs.query({}, (tabs) => {
      if (chrome.runtime && chrome.runtime.lastError) {
        return;
      }
      for (const tab of Array.isArray(tabs) ? tabs : []) {
        if (!tab || typeof tab.id !== "number") {
          continue;
        }
        try {
          chrome.tabs.sendMessage(tab.id, {
            type: "purestate.rulesUpdated",
            ok: sanitized.ok,
            rules: sanitized.rules
          }, () => {
            // Tabs without a Purestate content script reject the message;
            // reading lastError swallows the noise on purpose.
            void (chrome.runtime && chrome.runtime.lastError);
          });
        } catch {
        }
      }
    });
  } catch {
  }
}

function handleRuntimeMessage(message, sender, sendResponse) {
  if (!message) {
    return false;
  }
  if (message.type !== TIME_TICK && message.type !== TIME_STATE) {
    sendCompanionHeartbeatThrottled();
  }

  if (message.type === TIME_STATE) {
    readTimeState(message.area, Date.now())
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, area: "shopping", usedSeconds: 0, limitSeconds: 0, limitReached: false }));
    return true;
  }

  if (message.type === SOCIAL_TIME_STATE) {
    readSocialTimeState(message.platform, Date.now())
      .then(sendResponse)
      .catch(() => sendResponse({
        ok: false, platform: "", usedSecondsTotal: 0, usedSecondsPlatform: 0,
        budgetSeconds: 0, platformLimitSeconds: 0, limitReached: false
      }));
    return true;
  }

  if (message.type === SOCIAL_TIME_TICK) {
    enqueueSocialTick(message.platform, Date.now())
      .then(sendResponse)
      .catch((error) => {
        sendResponse({
          ok: false,
          platform: "",
          usedSecondsTotal: 0,
          usedSecondsPlatform: 0,
          budgetSeconds: 0,
          platformLimitSeconds: 0,
          limitReached: false,
          error: error && error.message ? error.message : "Time storage unavailable."
        });
      });
    return true;
  }

  if (message.type === TIME_TICK) {
    enqueueTimeTick(message.area, Date.now())
      .then(sendResponse)
      .catch((error) => {
        sendResponse({
          ok: false,
          area: message.area === "gambling" ? "gambling" : "shopping",
          usedSeconds: 0,
          limitSeconds: 0,
          limitReached: false,
          error: error && error.message ? error.message : "Time storage unavailable."
        });
      });
    return true;
  }

  if (message.type === SHOPPING_ORDER) {
    const orderAmount = Number.isInteger(message.amountEuro) ? message.amountEuro : null;
    // Ohne lesbaren Betrag legt die Hintergrundseite den Merker fuer den
    // Nachtrag an (EXT-A06) - sie ist sein einziger Besitzer.
    const markerWritten = orderAmount === null
      ? rememberPendingShoppingSpend(message.host, Date.now())
      : Promise.resolve();
    markerWritten
      .catch(() => {})
      .then(() => reportShoppingOrder(orderAmount))
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, orders: 0, spend: 0 }));
    return true;
  }

  if (message.type === SHOPPING_SPEND) {
    settlePendingShoppingSpend(message.host, Number.isInteger(message.amountEuro) ? message.amountEuro : null, Date.now())
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, orders: 0, spend: 0 }));
    return true;
  }

  if (message.type === SHOPPING_MONTH_GET) {
    queryShoppingMonth()
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, orders: 0, spend: 0 }));
    return true;
  }

  if (message.type === REDDIT_CHECK) {
    checkRedditSubreddit(message.subreddit)
      .then(sendResponse)
      .catch((error) => {
        sendResponse({
          blocked: false,
          reason: "",
          source: "error",
          error: error && error.message ? error.message : "Unknown error"
        });
      });

    return true;
  }

  if (message.type === REDDIT_POSTS_CHECK) {
    checkRedditPosts(message.postIds)
      .then(sendResponse)
      .catch((error) => {
        sendResponse({
          decisions: [],
          source: "error",
          error: error && error.message ? error.message : "Unknown error"
        });
      });

    return true;
  }

  if (message.type === BLUESKY_POSTS_CHECK) {
    checkBlueskyPosts(message.posts)
      .then(sendResponse)
      .catch((error) => {
        sendResponse({
          decisions: [],
          source: "error",
          error: error && error.message ? error.message : "Unknown error"
        });
      });

    return true;
  }

  if (message.type === CANARY_MISS_REPORT) {
    forwardCanaryMiss(message.site, message.check);
    sendResponse({ ok: true });
    return false;
  }

  if (message.type === BROWSER_RULES_GET) {
    getLocalBrowserRulePack()
      .then(sendResponse)
      .catch((error) => {
        sendResponse({
          ok: false,
          rules: emptyBrowserRulePack(),
          source: "error",
          error: error && error.message ? error.message : "Unknown error"
        });
      });

    return true;
  }

  if (message.type === ADULT_LEARN_HOST_MESSAGE) {
    const host = sanitizeLearnedHost(message.host);
    if (!host) {
      sendResponse({ ok: false, pending: false });
      return false;
    }
    enqueueAdultLearnHost(host)
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, pending: false }));
    return true;
  }

  return false;
}

chrome.runtime.onMessage.addListener(handleRuntimeMessage);

function localDateKey(nowMs) {
  const date = new Date(nowMs);
  const year = String(date.getFullYear()).padStart(4, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return year + "-" + month + "-" + day;
}

function timeStorageKey(area, nowMs) {
  return "purestateTime:" + area + ":" + localDateKey(nowMs);
}

function storedTimeForDay(area, nowMs, storeObj) {
  const value = storeObj && storeObj[timeStorageKey(area, nowMs)];
  return Number.isInteger(value) && value >= 0 ? value : 0;
}

function accumulateTimeTick(area, nowMs, storeObj) {
  if ((area !== "shopping" && area !== "gambling") || !storeObj || typeof storeObj !== "object") {
    return 0;
  }
  const currentKey = timeStorageKey(area, nowMs);
  const prefix = "purestateTime:" + area + ":";
  for (const key of Object.keys(storeObj)) {
    if (key.startsWith(prefix) && key !== currentKey) {
      delete storeObj[key];
    }
  }
  const current = storedTimeForDay(area, nowMs, storeObj);
  const next = Math.min(Number.MAX_SAFE_INTEGER, current + TIME_TICK_SECONDS);
  storeObj[currentKey] = next;
  return next;
}

function timeTickResponse(area, pack, usedSeconds) {
  const safeArea = area === "gambling" ? "gambling" : "shopping";
  const safePack = pack && typeof pack === "object" ? pack : emptyBrowserRulePack();
  const settings = safeArea === "gambling"
    ? (safePack.gamblingLimits || {})
    : (safePack.shopping || {});
  const fallbackMinutes = safeArea === "gambling" ? 15 : 30;
  const minutes = sanitizeLimitNumber(settings.dailyLimitMinutes, 5, 240, fallbackMinutes);
  const limitSeconds = settings.dailyLimitEnabled === true ? minutes * 60 : 0;
  const used = Number.isInteger(usedSeconds) && usedSeconds >= 0 ? usedSeconds : 0;
  return {
    ok: true,
    area: safeArea,
    usedSeconds: used,
    limitSeconds,
    limitReached: limitSeconds > 0 && used >= limitSeconds
  };
}

// Social time is one JSON object per local day ({ total, <platform> }) so a
// single storage key carries the shared budget AND the per-platform
// overrides. Broken values reset for the day - never a permanent lock.
function socialTimeStorageKey(nowMs) {
  return "purestateTime:social:" + localDateKey(nowMs);
}

function storedSocialTotals(nowMs, storeObj) {
  const raw = storeObj && storeObj[socialTimeStorageKey(nowMs)];
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return {};
  }
  const totals = {};
  for (const key of Object.keys(raw)) {
    if (Number.isInteger(raw[key]) && raw[key] >= 0) {
      totals[key] = raw[key];
    }
  }
  return totals;
}

function accumulateSocialTick(storeObj, platform, nowMs) {
  if (!storeObj || typeof storeObj !== "object" || !SOCIAL_MEDIA_PLATFORM_IDS.includes(platform)) {
    return { total: 0, platformSeconds: 0 };
  }
  const currentKey = socialTimeStorageKey(nowMs);
  const prefix = "purestateTime:social:";
  for (const key of Object.keys(storeObj)) {
    if (key.startsWith(prefix) && key !== currentKey) {
      delete storeObj[key];
    }
  }
  const totals = storedSocialTotals(nowMs, storeObj);
  // Eigenes Budget: die Plattform zaehlt nur fuer sich, nicht ins gemeinsame Limit.
  if (!SOCIAL_MEDIA_OWN_BUDGET_PLATFORM_IDS.includes(platform)) {
    totals.total = Math.min(Number.MAX_SAFE_INTEGER, (Number.isInteger(totals.total) ? totals.total : 0) + TIME_TICK_SECONDS);
  }
  totals[platform] = Math.min(Number.MAX_SAFE_INTEGER, (Number.isInteger(totals[platform]) ? totals[platform] : 0) + TIME_TICK_SECONDS);
  storeObj[currentKey] = totals;
  return { total: Number.isInteger(totals.total) ? totals.total : 0, platformSeconds: totals[platform] };
}

function socialTickResponse(pack, platform, totals) {
  const safePack = pack && typeof pack === "object" ? pack : emptyBrowserRulePack();
  const limits = safePack.socialMediaLimits && typeof safePack.socialMediaLimits === "object" ? safePack.socialMediaLimits : {};
  const budgetMinutes = sanitizeLimitNumber(limits.budgetMinutes, 5, 480, 60);
  const ownBudget = SOCIAL_MEDIA_OWN_BUDGET_PLATFORM_IDS.includes(platform);
  const budgetSeconds = !ownBudget && limits.budgetEnabled === true ? budgetMinutes * 60 : 0;
  const overrides = limits.platformLimits && typeof limits.platformLimits === "object" ? limits.platformLimits : {};
  const platformLimitSeconds = Number.isInteger(overrides[platform]) && overrides[platform] >= 5 && overrides[platform] <= 480
    ? overrides[platform] * 60
    : 0;
  const total = totals && Number.isInteger(totals.total) && totals.total >= 0 ? totals.total : 0;
  const platformSeconds = totals && Number.isInteger(totals.platformSeconds) && totals.platformSeconds >= 0 ? totals.platformSeconds : 0;
  return {
    ok: true,
    platform: SOCIAL_MEDIA_PLATFORM_IDS.includes(platform) ? platform : "",
    usedSecondsTotal: total,
    usedSecondsPlatform: platformSeconds,
    budgetSeconds,
    platformLimitSeconds,
    limitReached: (budgetSeconds > 0 && total >= budgetSeconds) ||
      (platformLimitSeconds > 0 && platformSeconds >= platformLimitSeconds)
  };
}

// Guard-authoritative budget reporting: every measured tick is mirrored to
// the guard's persistent per-day store via the native host, and enforcement
// prefers the guard total. The chrome.storage counter stays as a local tick
// buffer/cache, so clearing browser data, a fresh profile or a second
// browser no longer resets a daily budget on this machine.
function usageToken() {
  const bytes = new Uint8Array(16);
  if (globalThis.crypto && typeof globalThis.crypto.getRandomValues === "function") {
    globalThis.crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < bytes.length; i++) {
      bytes[i] = Math.floor(Math.random() * 256);
    }
  }
  let token = "";
  for (const byte of bytes) {
    token += byte.toString(16).padStart(2, "0");
  }
  return token;
}

// Shopping monthly order counter: relay one confirmed order (optional
// self-reported euro estimate) or a month query to the guard store.
async function reportShoppingOrder(amountEuroOrNull) {
  const message = {
    type: "usage",
    browser: companionBrowserName(),
    version: companionVersion(),
    action: "order",
    token: usageToken()
  };
  if (Number.isInteger(amountEuroOrNull) && amountEuroOrNull >= 0 && amountEuroOrNull <= 99999) {
    message.amountEuro = amountEuroOrNull;
  }
  return shoppingMonthResponse(await sendUsageMessageSafe(message));
}

// Betrag zu einer schon gezaehlten Bestellung nachtragen. Ohne Betrag gibt es
// nichts zu melden - die Nachricht entsteht dann gar nicht erst. Der Token ist
// die Buchungs-ID des Merkers (EXT-A06): eine Wiederholung derselben Buchung
// traegt denselben Token, und der Guard bucht sie nur einmal.
async function reportShoppingSpend(amountEuro, token) {
  if (!Number.isInteger(amountEuro) || amountEuro <= 0 || amountEuro > 99999 ||
      !USAGE_TOKEN_PATTERN.test(String(token || ""))) {
    return { ok: false, orders: 0, spend: 0 };
  }
  return shoppingMonthResponse(await sendUsageMessageSafe({
    type: "usage",
    browser: companionBrowserName(),
    version: companionVersion(),
    action: "spend",
    amountEuro: amountEuro,
    token: token
  }));
}

// EXT-A06: Merker fuer einen Kauf, der ohne lesbaren Betrag gezaehlt wurde.
// Frueher las, entfernte und buchte ihn jeder Tab selbst, mit einem neuen
// Token je Meldung - zwei Tabs derselben Kasse meldeten denselben Betrag
// zweimal. Jetzt gilt:
//   - Anlegen und Verbrauchen laufen nur hier, nacheinander (Promise-Kette).
//   - Der Merker traegt eine eigene Buchungs-ID; sie ist der Guard-Token.
//   - Lokal wird in EINEM Schreibvorgang gebucht und am Merker vermerkt, dann
//     gemeldet. Verbraucht wird der Merker erst nach Bestaetigung des Guards;
//     eine Wiederholung (Zeitueberschreitung, Neustart des Service Workers)
//     bucht lokal nichts mehr und meldet dieselbe ID mit demselben Betrag.
//   - Der Merker gehoert zu seiner Kasse (Host); eine andere offene Kasse
//     kann ihn nicht beanspruchen.
// ponytail: ein Merker-Platz fuer das ganze Profil - ein zweiter Kauf ohne
// Betrag vor dem Nachtrag des ersten ersetzt ihn. Liste je ID, falls das real
// vorkommt.
const SHOPPING_PENDING_SPEND_KEY = "purestatePendingSpend";
const SHOPPING_PENDING_SPEND_MS = 15 * 60 * 1000;
// Faellt der Guard aus, fragt jeder Kassentakt (1 s je Tab) erneut. Der
// native Host bekommt die Wiederholung hoechstens alle 30 s, mit derselben ID.
const SHOPPING_PENDING_SPEND_RETRY_MS = 30 * 1000;
const USAGE_TOKEN_PATTERN = /^[a-z0-9-]{8,40}$/;
let shoppingSettlementQueue = Promise.resolve();

function serializeShoppingSettlement(work) {
  const task = shoppingSettlementQueue.then(work);
  shoppingSettlementQueue = task.catch(() => {});
  return task;
}

function pendingSpendHost(value) {
  const host = String(value || "").trim().toLowerCase().replace(/^www\./, "");
  return /^[a-z0-9.-]{1,253}$/.test(host) ? host : "";
}

// Kassen wechseln zwischen www.shop.de und checkout.shop.de: gleicher Host
// oder Subdomain in einer der beiden Richtungen. Nie eine fremde Domain, und
// nie ueber eine Endung ohne Punkt (etwa "de").
function pendingSpendHostsRelated(markerHost, claimedHost) {
  if (typeof markerHost !== "string" || !markerHost || !claimedHost) {
    return false;
  }
  return markerHost === claimedHost ||
    (markerHost.includes(".") && claimedHost.endsWith("." + markerHost)) ||
    (claimedHost.includes(".") && markerHost.endsWith("." + claimedHost));
}

function rememberPendingShoppingSpend(host, nowMs) {
  const safeHost = pendingSpendHost(host);
  if (!safeHost) {
    return Promise.resolve();
  }
  return serializeShoppingSettlement(() => {
    const values = {};
    values[SHOPPING_PENDING_SPEND_KEY] = {
      id: usageToken(),
      host: safeHost,
      month: localDateKey(nowMs).slice(0, 7),
      until: nowMs + SHOPPING_PENDING_SPEND_MS
    };
    return setLocalStorageValues(values);
  });
}

function settlePendingShoppingSpend(host, amountEuro, nowMs) {
  const notSettled = { ok: false, orders: 0, spend: 0 };
  const claimedHost = pendingSpendHost(host);
  return serializeShoppingSettlement(async () => {
    const items = await readLocalStorageAll();
    const marker = items[SHOPPING_PENDING_SPEND_KEY];
    if (!marker || typeof marker !== "object") {
      return notSettled;
    }
    const month = localDateKey(nowMs).slice(0, 7);
    // Nur ein gueltiges Regelpaket darf "beide Monatsgrenzen aus" bezeugen;
    // ein Ausfall des Dienstes loescht den Merker nicht.
    const ruleResponse = await getLocalBrowserRulePack();
    const shopping = ruleResponse && ruleResponse.ok === true && ruleResponse.rules &&
      ruleResponse.rules.shopping && typeof ruleResponse.rules.shopping === "object"
      ? ruleResponse.rules.shopping
      : null;
    const monthlyLimitsOff = shopping !== null &&
      shopping.monthlyOrderLimitEnabled !== true && shopping.monthlyBudgetEnabled !== true;
    if (monthlyLimitsOff || !USAGE_TOKEN_PATTERN.test(String(marker.id || "")) ||
        marker.month !== month || !(Number.isFinite(marker.until) && nowMs <= marker.until)) {
      await removeLocalStorageKeys([SHOPPING_PENDING_SPEND_KEY]);
      return notSettled;
    }
    if (!pendingSpendHostsRelated(marker.host, claimedHost)) {
      return notSettled;
    }
    let booked = marker;
    const values = {};
    if (marker.localBooked !== true) {
      if (!Number.isInteger(amountEuro) || amountEuro <= 0 || amountEuro > 99999) {
        return notSettled;
      }
      const spendKey = "purestateSpend:" + month;
      const current = Number.isInteger(items[spendKey]) && items[spendKey] >= 0 ? items[spendKey] : 0;
      booked = Object.assign({}, marker, { amountEuro: amountEuro, localBooked: true, lastAttemptAt: nowMs });
      values[spendKey] = Math.min(Number.MAX_SAFE_INTEGER, current + amountEuro);
    } else {
      // Eine rueckwaerts gestellte Uhr drosselt nicht dauerhaft.
      if (Number.isFinite(marker.lastAttemptAt) && nowMs >= marker.lastAttemptAt &&
          nowMs - marker.lastAttemptAt < SHOPPING_PENDING_SPEND_RETRY_MS) {
        return notSettled;
      }
      booked = Object.assign({}, marker, { lastAttemptAt: nowMs });
    }
    values[SHOPPING_PENDING_SPEND_KEY] = booked;
    await setLocalStorageValues(values);
    const response = await reportShoppingSpend(booked.amountEuro, booked.id);
    if (response.ok) {
      await removeLocalStorageKeys([SHOPPING_PENDING_SPEND_KEY]);
    }
    return response;
  });
}

async function queryShoppingMonth() {
  return shoppingMonthResponse(await sendUsageMessageSafe({
    type: "usage",
    browser: companionBrowserName(),
    version: companionVersion(),
    action: "order-query"
  }));
}

async function sendUsageMessageSafe(message) {
  try {
    return await sendNativeMessage(message);
  } catch (error) {
    return null;
  }
}

function shoppingMonthResponse(response) {
  if (response && response.ok === true &&
      Number.isInteger(response.monthOrders) && response.monthOrders >= 0 &&
      Number.isInteger(response.monthSpendEuro) && response.monthSpendEuro >= 0) {
    return { ok: true, orders: response.monthOrders, spend: response.monthSpendEuro };
  }
  return { ok: false, orders: 0, spend: 0 };
}

async function reportUsageDelta(area, platform, deltaSeconds) {
  try {
    const response = await sendNativeMessage({
      type: "usage",
      browser: companionBrowserName(),
      version: companionVersion(),
      action: "report",
      area,
      platform: platform || "",
      deltaSeconds,
      token: usageToken()
    });
    if (response && response.ok === true &&
        Number.isInteger(response.usedSecondsTotal) && response.usedSecondsTotal >= 0 &&
        Number.isInteger(response.usedSecondsPlatform) && response.usedSecondsPlatform >= 0) {
      return response;
    }
  } catch (error) {
    // Native host unavailable: the local counter still enforces this
    // session; the companion fail-closed path covers full outages.
  }
  return null;
}

function enqueueSocialTick(platform, nowMs) {
  if (!SOCIAL_MEDIA_PLATFORM_IDS.includes(platform)) {
    return Promise.resolve({
      ok: false, platform: "", usedSecondsTotal: 0, usedSecondsPlatform: 0,
      budgetSeconds: 0, platformLimitSeconds: 0, limitReached: false
    });
  }
  const task = timeTickQueue.then(() => processSocialTick(platform, nowMs));
  timeTickQueue = task.catch(() => {});
  return task;
}

// EXT-A02: Gegenstueck zu readTimeState fuer Social Media. Liest denselben
// Stand, den ein Tick liefern wuerde - kein Zaehlen, kein Schreiben, keine
// Meldung an den Guard.
// Sicherheitsreview: Ohne gueltiges Regelpaket (nativer Host aus, 5 min
// gecacht) ist das leere Paket KEIN Stand - "ok, nicht erreicht" haette Zeit-
// und Unbekannt-Vorhang abgenommen. Die Abfrage laeuft ausserdem hinter bereits
// eingereihten Ticks, damit sie keinen aelteren Stand meldet.
function readSocialTimeState(platform, nowMs) {
  const noState = () => ({
    ok: false, platform: "", usedSecondsTotal: 0, usedSecondsPlatform: 0,
    budgetSeconds: 0, platformLimitSeconds: 0, limitReached: false
  });
  if (!SOCIAL_MEDIA_PLATFORM_IDS.includes(platform)) {
    return Promise.resolve(noState());
  }
  const task = timeTickQueue.then(async () => {
    const ruleResponse = await getLocalBrowserRulePack();
    if (!ruleResponse || ruleResponse.ok !== true || !ruleResponse.rules) {
      return noState();
    }
    const existing = storedSocialTotals(nowMs, await readLocalStorageAll());
    return socialTickResponse(ruleResponse.rules, platform, {
      total: Number.isInteger(existing.total) ? existing.total : 0,
      platformSeconds: Number.isInteger(existing[platform]) ? existing[platform] : 0
    });
  });
  timeTickQueue = task.catch(() => {});
  return task;
}

async function processSocialTick(platform, nowMs) {
  const ruleResponse = await getLocalBrowserRulePack();
  // Wie readSocialTimeState: ohne gueltige Regeln ist ein Takt kein Stand.
  // "ok, Limit 0" haette das Tageslimit waehrend eines Ausfalls aufgehoben.
  if (!ruleResponse || ruleResponse.ok !== true || !ruleResponse.rules) {
    return {
      ok: false, platform: "", usedSecondsTotal: 0, usedSecondsPlatform: 0,
      budgetSeconds: 0, platformLimitSeconds: 0, limitReached: false
    };
  }
  const pack = ruleResponse.rules;
  const items = await readLocalStorageAll();
  const beforeKeys = new Set(Object.keys(items));
  const existing = storedSocialTotals(nowMs, items);
  const initial = socialTickResponse(pack, platform, {
    total: Number.isInteger(existing.total) ? existing.total : 0,
    platformSeconds: Number.isInteger(existing[platform]) ? existing[platform] : 0
  });
  if (initial.budgetSeconds === 0 && initial.platformLimitSeconds === 0) {
    return initial;
  }

  const totals = accumulateSocialTick(items, platform, nowMs);
  const removedKeys = [];
  for (const key of beforeKeys) {
    if (!Object.prototype.hasOwnProperty.call(items, key)) {
      removedKeys.push(key);
    }
  }
  if (removedKeys.length > 0) {
    await removeLocalStorageKeys(removedKeys);
  }
  const currentKey = socialTimeStorageKey(nowMs);
  const authoritative = await reportUsageDelta("social", platform, TIME_TICK_SECONDS);
  if (authoritative) {
    const stored = items[currentKey] && typeof items[currentKey] === "object" ? items[currentKey] : {};
    if (authoritative.usedSecondsTotal > totals.total) {
      totals.total = authoritative.usedSecondsTotal;
      stored.total = totals.total;
    }
    if (authoritative.usedSecondsPlatform > totals.platformSeconds) {
      totals.platformSeconds = authoritative.usedSecondsPlatform;
      stored[platform] = totals.platformSeconds;
    }
    items[currentKey] = stored;
  }
  const update = {};
  update[currentKey] = items[currentKey];
  await setLocalStorageValues(update);
  return socialTickResponse(pack, platform, totals);
}

function enqueueTimeTick(area, nowMs) {
  if (area !== "shopping" && area !== "gambling") {
    return Promise.resolve({ ok: false, area: "", usedSeconds: 0, limitSeconds: 0, limitReached: false });
  }
  const task = timeTickQueue.then(() => processTimeTick(area, nowMs));
  timeTickQueue = task.catch(() => {});
  return task;
}

// Liest denselben Stand, den ein Tick zurueckgeben wuerde, ohne ihn zu
// veraendern - kein accumulateTimeTick, kein Schreiben, keine Meldung an den
// Guard. Wie readSocialTimeState: ohne gueltiges Regelpaket ok:false, und
// eingereiht hinter laufende Ticks.
function readTimeState(area, nowMs) {
  if (area !== "shopping" && area !== "gambling") {
    return Promise.resolve({ ok: false, area: "", usedSeconds: 0, limitSeconds: 0, limitReached: false });
  }
  const task = timeTickQueue.then(async () => {
    const ruleResponse = await getLocalBrowserRulePack();
    if (!ruleResponse || ruleResponse.ok !== true || !ruleResponse.rules) {
      return { ok: false, area, usedSeconds: 0, limitSeconds: 0, limitReached: false };
    }
    const items = await readLocalStorageAll();
    return timeTickResponse(area, ruleResponse.rules, storedTimeForDay(area, nowMs, items));
  });
  timeTickQueue = task.catch(() => {});
  return task;
}

async function processTimeTick(area, nowMs) {
  const ruleResponse = await getLocalBrowserRulePack();
  // Wie readTimeState: ohne gueltige Regeln ist ein Takt kein Stand.
  if (!ruleResponse || ruleResponse.ok !== true || !ruleResponse.rules) {
    return { ok: false, area, usedSeconds: 0, limitSeconds: 0, limitReached: false };
  }
  const pack = ruleResponse.rules;
  const items = await readLocalStorageAll();
  const beforeKeys = new Set(Object.keys(items));
  const initial = timeTickResponse(area, pack, storedTimeForDay(area, nowMs, items));
  if (initial.limitSeconds === 0) {
    return initial;
  }

  const usedSeconds = accumulateTimeTick(area, nowMs, items);
  const removedKeys = [];
  for (const key of beforeKeys) {
    if (!Object.prototype.hasOwnProperty.call(items, key)) {
      removedKeys.push(key);
    }
  }
  if (removedKeys.length > 0) {
    await removeLocalStorageKeys(removedKeys);
  }
  const currentKey = timeStorageKey(area, nowMs);
  let effectiveUsed = usedSeconds;
  const authoritative = await reportUsageDelta(area, "", TIME_TICK_SECONDS);
  if (authoritative && authoritative.usedSecondsTotal > effectiveUsed) {
    effectiveUsed = authoritative.usedSecondsTotal;
    items[currentKey] = effectiveUsed;
  }
  const update = {};
  update[currentKey] = items[currentKey];
  await setLocalStorageValues(update);
  return timeTickResponse(area, pack, effectiveUsed);
}

function readLocalStorageAll() {
  return new Promise((resolve, reject) => {
    try {
      if (!chrome.storage || !chrome.storage.local || typeof chrome.storage.local.get !== "function") {
        reject(new Error("Time storage unavailable."));
        return;
      }
      chrome.storage.local.get(null, (items) => {
        if (chrome.runtime && chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message || "Time storage unavailable."));
          return;
        }
        resolve(items && typeof items === "object" ? items : {});
      });
    } catch (error) {
      reject(error);
    }
  });
}

function setLocalStorageValues(values) {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.local.set(values, () => {
        if (chrome.runtime && chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message || "Time storage unavailable."));
          return;
        }
        resolve();
      });
    } catch (error) {
      reject(error);
    }
  });
}

function removeLocalStorageKeys(keys) {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.local.remove(keys, () => {
        if (chrome.runtime && chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message || "Time storage unavailable."));
          return;
        }
        resolve();
      });
    } catch (error) {
      reject(error);
    }
  });
}

// A canary token is a short machine-readable identifier like "pixiv" or
// "viewing-checkboxes" - never free text, never page content.
function sanitizeCanaryToken(value) {
  const token = String(value || "").trim().toLowerCase();
  return /^[a-z0-9][a-z0-9._-]{0,39}$/.test(token) ? token : "";
}

// Forward a selector-canary failure to the native host so it lands in the
// local diagnostic log. Deduplicated per site:check per hour (the content
// scripts throttle too, but each tab has its own throttle state). Best-effort
// diagnostics: a failed forward is dropped, never retried.
function forwardCanaryMiss(site, check) {
  const siteToken = sanitizeCanaryToken(site);
  const checkToken = sanitizeCanaryToken(check);
  if (!siteToken || !checkToken) {
    return;
  }
  const key = siteToken + ":" + checkToken;
  const now = Date.now();
  if (now - (canaryForwardLast.get(key) || 0) < CANARY_FORWARD_MIN_INTERVAL_MS) {
    return;
  }
  canaryForwardLast.set(key, now);
  sendNativeMessage({
    type: "canary",
    browser: companionBrowserName(),
    version: companionVersion(),
    check: key
  });
}

// Hostname-Form, streng: Buchstaben, Ziffern, Bindestrich, Punkt, hoechstens
// 253 Zeichen. Kein Schema, kein Pfad, kein Trennzeichen der Pipe-Grammatik.
const ADULT_HOST_SHAPE = /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/;

function sanitizeLearnedHost(value) {
  const host = String(value || "").trim().toLowerCase().replace(/^www\./, "");
  if (!host || host.length > 253 || !ADULT_HOST_SHAPE.test(host)) {
    return "";
  }
  return host;
}

function queueAdultLearnWork(task) {
  adultLearnQueueWork = adultLearnQueueWork.then(task, task);
  return adultLearnQueueWork;
}

function readAdultLearnRetryQueue() {
  return new Promise((resolve, reject) => {
    try {
      if (!chrome.storage || !chrome.storage.local || typeof chrome.storage.local.get !== "function") {
        reject(new Error("Adult learn retry storage unavailable."));
        return;
      }
      chrome.storage.local.get(ADULT_LEARN_RETRY_STORAGE_KEY, (items) => {
        if (chrome.runtime && chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message || "Adult learn retry storage unavailable."));
          return;
        }
        const raw = items && items[ADULT_LEARN_RETRY_STORAGE_KEY];
        const queue = {};
        let accepted = 0;
        if (raw && typeof raw === "object" && !Array.isArray(raw)) {
          for (const key of Object.keys(raw)) {
            const host = sanitizeLearnedHost(key);
            const entry = raw[key];
            if (!host || !entry || typeof entry !== "object") {
              continue;
            }
            queue[host] = {
              attempts: Number.isInteger(entry.attempts) && entry.attempts >= 0 ? Math.min(entry.attempts, 20) : 0,
              createdAt: Number.isFinite(entry.createdAt) && entry.createdAt > 0 ? entry.createdAt : Date.now(),
              nextAttemptAt: Number.isFinite(entry.nextAttemptAt) && entry.nextAttemptAt >= 0 ? entry.nextAttemptAt : 0
            };
            accepted += 1;
            if (accepted >= ADULT_LEARN_RETRY_CAP) {
              break;
            }
          }
        }
        resolve(queue);
      });
    } catch (error) {
      reject(error);
    }
  });
}

function writeAdultLearnRetryQueue(queue) {
  return new Promise((resolve, reject) => {
    try {
      if (!chrome.storage || !chrome.storage.local || typeof chrome.storage.local.set !== "function") {
        reject(new Error("Adult learn retry storage unavailable."));
        return;
      }
      chrome.storage.local.set({ [ADULT_LEARN_RETRY_STORAGE_KEY]: queue }, () => {
        if (chrome.runtime && chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message || "Adult learn retry storage unavailable."));
          return;
        }
        resolve();
      });
    } catch (error) {
      reject(error);
    }
  });
}

function adultLearnRetryDelay(attempts) {
  const exponent = Math.max(0, Math.min(6, attempts - 1));
  return Math.min(ADULT_LEARN_RETRY_BASE_MS * Math.pow(2, exponent), ADULT_LEARN_RETRY_MAX_MS);
}

function scheduleAdultLearnRetry(queue) {
  const entries = Object.values(queue || {});
  if (!entries.length) {
    return;
  }
  const earliest = Math.min(...entries.map((entry) => entry.nextAttemptAt || 0));
  try {
    chrome.alarms.create(ADULT_LEARN_RETRY_ALARM, { when: Math.max(Date.now() + 1000, earliest) });
  } catch {
  }
}

async function attemptAdultLearnHost(host, queue, now) {
  const response = await sendNativeMessage({ type: "learn", area: "adult", host });
  if (response && response.ok === true) {
    delete queue[host];
    return { ok: true, pending: false };
  }
  const entry = queue[host];
  entry.attempts += 1;
  entry.nextAttemptAt = now + adultLearnRetryDelay(entry.attempts);
  return { ok: false, pending: true };
}

function enqueueAdultLearnHost(host) {
  return queueAdultLearnWork(async () => {
    const queue = await readAdultLearnRetryQueue();
    const now = Date.now();
    if (!queue[host]) {
      const hosts = Object.keys(queue);
      if (hosts.length >= ADULT_LEARN_RETRY_CAP) {
        // BGW-004: Der Befund schlaegt vor, den AELTESTEN Eintrag zu
        // verdraengen statt den neuen abzulehnen. Das waere falsch, und der
        // bestehende Test "A full adult learning queue rejects admission
        // without deleting unacknowledged hosts" haelt genau dagegen:
        //
        // Ein abgelehnter neuer Host ist NICHT endgueltig verloren - der
        // Nutzer ist gerade auf der Seite, die Erkennung greift beim naechsten
        // Besuch erneut, und das Content-Skript meldet ihn wieder. Ein
        // verdraengter alter Eintrag dagegen ist weg: den meldet niemand mehr,
        // weil niemand mehr dort ist. Die Verdraengung wuerde also einen
        // sicheren Verlust gegen einen wiederholbaren tauschen.
        //
        // Was am Befund BLEIBT und hier behoben wird, ist die Stille: der Fall
        // stand nirgends. Nicht ueber forwardCanaryMiss melden - der Guard
        // nimmt nur die sechs zugeordneten Seiten an und wiese "background"
        // als unknown-site ab; eine Meldung, die nirgends ankommt, waere
        // schlimmer als keine. Der Service Worker hat eine eigene Konsole, und
        // die ist im Diagnosefall genau der Ort, an dem man nachsieht.
        console.warn(
          "[purestate] Lern-Warteschlange voll (" + ADULT_LEARN_RETRY_CAP +
          " unzustellbare Hosts): " + host +
          " wurde nicht aufgenommen und wird beim naechsten Besuch erneut gemeldet.");
        scheduleAdultLearnRetry(queue);
        return { ok: false, pending: false };
      }
      queue[host] = { attempts: 0, createdAt: now, nextAttemptAt: 0 };
      // Persist BEFORE the first native attempt. A service-worker teardown at
      // any later point leaves a retryable record instead of losing the host.
      await writeAdultLearnRetryQueue(queue);
    }
    if (queue[host].nextAttemptAt > now) {
      scheduleAdultLearnRetry(queue);
      return { ok: false, pending: true };
    }
    const result = await attemptAdultLearnHost(host, queue, now);
    await writeAdultLearnRetryQueue(queue);
    scheduleAdultLearnRetry(queue);
    return result;
  });
}

function retryPendingAdultLearnHosts() {
  return queueAdultLearnWork(async () => {
    const queue = await readAdultLearnRetryQueue();
    const now = Date.now();
    const due = Object.keys(queue)
      .filter((host) => queue[host].nextAttemptAt <= now)
      .sort((left, right) => queue[left].nextAttemptAt - queue[right].nextAttemptAt)
      .slice(0, ADULT_LEARN_RETRY_BATCH);
    for (const host of due) {
      await attemptAdultLearnHost(host, queue, Date.now());
    }
    if (due.length) {
      await writeAdultLearnRetryQueue(queue);
    }
    scheduleAdultLearnRetry(queue);
  });
}

function resumeAdultLearnRetries() {
  retryPendingAdultLearnHosts().catch(() => {});
}

async function getLocalBrowserRulePack() {
  if (localRulePackCache.response && Date.now() - localRulePackCache.checkedAt < LOCAL_RULE_PACK_TTL_MS) {
    return localRulePackCache.response;
  }

  const response = await sendNativeMessage({
    type: "rules",
    browser: companionBrowserName(),
    version: companionVersion()
  });
  const sanitized = await withLastValidRulePack({
    ok: !!(response && response.ok),
    rules: sanitizeBrowserRulePack(response && response.rules),
    source: response && response.ok ? "native-host" : "native-host-unavailable"
  });
  localRulePackCache = { checkedAt: Date.now(), response: sanitized };
  return sanitized;
}

// Ein gueltiges Paket wird gemerkt; bei einem Ausfall tritt das gemerkte an
// seine Stelle, solange es juenger als einen Tag ist. Eine Uhr, die vor dem
// Speichern steht, laesst es verfallen - in beiden Richtungen bleibt dann nur
// der Unbekannt-Weg, nie "kein Limit".
async function withLastValidRulePack(sanitized) {
  try {
    if (sanitized.ok) {
      await setLocalStorageValues({ [LAST_VALID_RULE_PACK_KEY]: { savedAt: Date.now(), rules: sanitized.rules } });
      return sanitized;
    }
    const stored = (await readLocalStorageAll())[LAST_VALID_RULE_PACK_KEY];
    const age = stored && Number.isFinite(stored.savedAt) ? Date.now() - stored.savedAt : -1;
    if (age >= 0 && age <= LAST_VALID_RULE_PACK_MAX_AGE_MS) {
      return { ok: true, rules: sanitizeBrowserRulePack(stored.rules), source: "last-known" };
    }
  } catch {
  }
  return sanitized;
}

function emptyBrowserRulePack() {
  const pack = {
    version: 2,
    areas: {
      "adult-content": { enabled: true, mode: "strict" },
      gambling: { enabled: false, mode: "off" },
      shopping: { enabled: false, mode: "off" },
      "social-media": { enabled: false, mode: "off" }
    },
    siteProtection: {},
    adult: {
      hostDomains: [],
      exemptHosts: []
    },
    bluesky: {
      adultSearchTerms: [],
      adultHashtags: [],
      adultTextTerms: [],
      adultLinkDomains: [],
      safeContextTerms: []
    },
    gambling: {
      searchTerms: [],
      urlKeywords: [],
      linkDomains: [],
      hostDomains: [],
      exemptHosts: []
    },
    shopping: {
      searchTerms: [],
      hostDomains: [],
      checkoutDelayEnabled: false,
      stimulusDampingEnabled: false,
      dealSearchBlockEnabled: false,
      curfewEnabled: false,
      curfewStart: "22:00",
      curfewEnd: "06:00",
      delayMinutes: 10,
      dailyLimitEnabled: false,
      dailyLimitMinutes: 30,
      monthlyOrderLimitEnabled: false,
      monthlyOrderLimit: 10,
      monthlyBudgetEnabled: false,
      monthlyBudgetEuro: 200
    },
    gamblingLimits: {
      dailyLimitEnabled: false,
      dailyLimitMinutes: 15
    },
    socialMediaLimits: {
      budgetEnabled: false,
      budgetMinutes: 60,
      platformLimits: {},
      blockedPlatforms: [],
      feedBlockedPlatforms: [],
      curfewEnabled: false,
      curfewStart: "22:00",
      curfewEnd: "06:00",
      reflectionEnabled: true,
      feedDampingEnabled: true,
      feedDampingScrolls: 50
    }
  };
  for (const site of SITE_PROTECTION_KEYS) {
    pack.siteProtection[site] = true;
  }
  return pack;
}

function sanitizeBrowserRulePack(rules) {
  const pack = emptyBrowserRulePack();
  const siteProtection = rules && typeof rules === "object" ? rules.siteProtection : null;
  if (siteProtection && typeof siteProtection === "object") {
    for (const site of SITE_PROTECTION_KEYS) {
      pack.siteProtection[site] = siteProtection[site] !== false;
    }
  }

  const areas = rules && typeof rules === "object" ? rules.areas : null;
  if (areas && typeof areas === "object") {
    // EXT-003 schlaegt vor, hier eine Positivliste zu benutzen wie ueberall
    // sonst im Bereiniger (siehe SITE_PROTECTION_KEYS). Das wird bewusst NICHT
    // gemacht, und der Grund steht im Test "Background passes through unknown
    // areas and the gentle mode generically": ein unbekannter Bereich wird
    // absichtlich durchgereicht, damit ein aelterer Companion mit einer
    // neueren App zusammenarbeitet, statt deren neuen Schutzbereich zu
    // verwerfen.
    //
    // Die Sorge des Befunds traegt hier nicht: die Werte werden streng
    // normalisiert - enabled nur aus === true, mode nur aus vier festen
    // Woertern, alles andere wird "off". Ein fremder Schluessel kann damit
    // weder Daten schmuggeln noch etwas einschalten, und gelesen wird er von
    // keinem Content-Skript (die kennen nur areas.gambling und areas.shopping).
    for (const key of Object.keys(areas)) {
      const area = areas[key];
      if (area && typeof area === "object") {
        const mode = ["off", "planned", "gentle", "strict"].includes(area.mode) ? area.mode : "off";
        pack.areas[key] = {
          enabled: area.enabled === true,
          mode: mode
        };
      }
    }
  }

  const adult = rules && typeof rules === "object" ? rules.adult : null;
  if (adult && typeof adult === "object") {
    pack.adult.hostDomains = sanitizeHostDomains(adult.hostDomains);
    pack.adult.exemptHosts = sanitizeHostDomains(adult.exemptHosts, 500);
  }

  const gambling = rules && typeof rules === "object" ? rules.gambling : null;
  if (gambling && typeof gambling === "object") {
    for (const key of ["searchTerms", "urlKeywords", "linkDomains"]) {
      pack.gambling[key] = sanitizeRuleTerms(gambling[key], key === "linkDomains" ? 128 : 64);
    }
    pack.gambling.hostDomains = sanitizeHostDomains(gambling.hostDomains);
    pack.gambling.exemptHosts = sanitizeHostDomains(gambling.exemptHosts);
  }

  const shopping = rules && typeof rules === "object" ? rules.shopping : null;
  if (shopping && typeof shopping === "object") {
    pack.shopping.searchTerms = sanitizeRuleTerms(shopping.searchTerms, 64);
    pack.shopping.hostDomains = sanitizeHostDomains(shopping.hostDomains);
    pack.shopping.checkoutDelayEnabled = shopping.checkoutDelayEnabled === true;
    pack.shopping.stimulusDampingEnabled = shopping.stimulusDampingEnabled === true;
    pack.shopping.dealSearchBlockEnabled = shopping.dealSearchBlockEnabled === true;
    pack.shopping.curfewEnabled = shopping.curfewEnabled === true;
    pack.shopping.curfewStart = sanitizeRuleTime(shopping.curfewStart, "22:00");
    pack.shopping.curfewEnd = sanitizeRuleTime(shopping.curfewEnd, "06:00");
    pack.shopping.delayMinutes = [2, 5, 10, 15].includes(shopping.delayMinutes) ? shopping.delayMinutes : 10;
    pack.shopping.dailyLimitEnabled = shopping.dailyLimitEnabled === true;
    pack.shopping.dailyLimitMinutes = sanitizeLimitNumber(shopping.dailyLimitMinutes, 5, 240, 30);
    pack.shopping.monthlyOrderLimitEnabled = shopping.monthlyOrderLimitEnabled === true;
    pack.shopping.monthlyOrderLimit = sanitizeLimitNumber(shopping.monthlyOrderLimit, 1, 99, 10);
    pack.shopping.monthlyBudgetEnabled = shopping.monthlyBudgetEnabled === true;
    pack.shopping.monthlyBudgetEuro = sanitizeLimitNumber(shopping.monthlyBudgetEuro, 1, 99999, 200);
  }

  const gamblingLimits = rules && typeof rules === "object" ? rules.gamblingLimits : null;
  if (gamblingLimits && typeof gamblingLimits === "object") {
    pack.gamblingLimits.dailyLimitEnabled = gamblingLimits.dailyLimitEnabled === true;
    pack.gamblingLimits.dailyLimitMinutes = sanitizeLimitNumber(gamblingLimits.dailyLimitMinutes, 5, 240, 15);
  }

  const socialMediaLimits = rules && typeof rules === "object" ? rules.socialMediaLimits : null;
  if (socialMediaLimits && typeof socialMediaLimits === "object") {
    pack.socialMediaLimits.budgetEnabled = socialMediaLimits.budgetEnabled === true;
    pack.socialMediaLimits.budgetMinutes = sanitizeLimitNumber(socialMediaLimits.budgetMinutes, 5, 480, 60);
    const platformLimits = socialMediaLimits.platformLimits;
    if (platformLimits && typeof platformLimits === "object" && !Array.isArray(platformLimits)) {
      for (const platform of SOCIAL_MEDIA_PLATFORM_IDS) {
        const minutes = platformLimits[platform];
        if (Number.isInteger(minutes) && minutes >= 5 && minutes <= 480) {
          // Ein eigenes Limit darf das gemeinsame Budget nicht uebersteigen - es sei
          // denn, die Plattform fuehrt ein eigenes Budget (Streaming).
          pack.socialMediaLimits.platformLimits[platform] =
            pack.socialMediaLimits.budgetEnabled && minutes > pack.socialMediaLimits.budgetMinutes &&
              !SOCIAL_MEDIA_OWN_BUDGET_PLATFORM_IDS.includes(platform)
              ? pack.socialMediaLimits.budgetMinutes
              : minutes;
        }
      }
    }
    for (const value of Array.isArray(socialMediaLimits.blockedPlatforms) ? socialMediaLimits.blockedPlatforms : []) {
      const platform = String(value || "").trim().toLowerCase();
      if (SOCIAL_MEDIA_PLATFORM_IDS.includes(platform) && !pack.socialMediaLimits.blockedPlatforms.includes(platform)) {
        pack.socialMediaLimits.blockedPlatforms.push(platform);
      }
    }
    for (const value of Array.isArray(socialMediaLimits.feedBlockedPlatforms) ? socialMediaLimits.feedBlockedPlatforms : []) {
      const platform = String(value || "").trim().toLowerCase();
      if (SOCIAL_MEDIA_FEED_ROUTE_PLATFORM_IDS.includes(platform) &&
          !pack.socialMediaLimits.blockedPlatforms.includes(platform) &&
          !pack.socialMediaLimits.feedBlockedPlatforms.includes(platform)) {
        pack.socialMediaLimits.feedBlockedPlatforms.push(platform);
      }
    }
    pack.socialMediaLimits.curfewEnabled = socialMediaLimits.curfewEnabled === true;
    pack.socialMediaLimits.curfewStart = sanitizeRuleTime(socialMediaLimits.curfewStart, "22:00");
    pack.socialMediaLimits.curfewEnd = sanitizeRuleTime(socialMediaLimits.curfewEnd, "06:00");
    pack.socialMediaLimits.reflectionEnabled = socialMediaLimits.reflectionEnabled !== false;
    pack.socialMediaLimits.feedDampingEnabled = socialMediaLimits.feedDampingEnabled !== false;
    pack.socialMediaLimits.feedDampingScrolls = sanitizeLimitNumber(socialMediaLimits.feedDampingScrolls, 5, 500, 50);
  }

  const bluesky = rules && typeof rules === "object" ? rules.bluesky : null;
  if (bluesky && typeof bluesky === "object") {
    for (const key of ["adultSearchTerms", "adultHashtags", "adultTextTerms", "adultLinkDomains", "safeContextTerms"]) {
      pack.bluesky[key] = sanitizeRuleTerms(bluesky[key], 64);
    }
  }
  return pack;
}

function sanitizeLimitNumber(value, min, max, fallback) {
  return Number.isInteger(value) && value >= min && value <= max ? value : fallback;
}

function sanitizeRuleTime(value, fallback) {
  const text = String(value || "").trim();
  return /^\d{1,2}:\d{2}$/.test(text) ? text : fallback;
}

function sanitizeRuleTerms(values, maxLength) {
  const result = [];
  for (const value of Array.isArray(values) ? values : []) {
    const term = String(value || "").trim().toLowerCase().replace(/^#/, "");
    if (term.length > 0 && term.length <= maxLength && /^[a-z0-9][a-z0-9+._ -]*$/.test(term) && !result.includes(term)) {
      result.push(term);
    }
    if (result.length >= 250) {
      break;
    }
  }
  return result;
}

// Host lists use a caller-provided capacity, but always retain the same strict
// hostname shape and linear-time deduplication. The explicit adult exemption
// contract is 500; every other dynamic host list retains the same safe cap.
function sanitizeHostDomains(values, maximumHosts = 500) {
  const result = [];
  const seen = new Set();
  for (const value of Array.isArray(values) ? values : []) {
    const host = String(value || "").trim().toLowerCase();
    if (host.length > 0 && host.length <= 253 && ADULT_HOST_SHAPE.test(host) && !seen.has(host)) {
      seen.add(host);
      result.push(host);
    }
    if (result.length >= maximumHosts) {
      break;
    }
  }
  return result;
}

async function checkBlueskyPosts(inputs) {
  const posts = [];
  const seen = new Set();

  for (const input of Array.isArray(inputs) ? inputs : []) {
    const post = normalizeBlueskyPost(input);
    if (post && !seen.has(post.key)) {
      seen.add(post.key);
      posts.push(post);
    }
  }

  const decisions = new Map();
  const missing = [];
  for (const post of posts) {
    const cached = blueskyDecisionCache.get(post.key);
    const ttl = cached && cached.decision.known ? CACHE_TTL_MS : UNKNOWN_CACHE_TTL_MS;
    if (cached && Date.now() - cached.checkedAt < ttl) {
      decisions.set(post.key, cached.decision);
    } else {
      missing.push(post);
    }
  }

  if (missing.length) {
    const fetched = await fetchBlueskyPostLabels(missing);
    for (const post of missing) {
      const decision = fetched.get(post.key) || {
        key: post.key,
        known: false,
        blocked: false,
        labels: [],
        source: "bluesky-post-unavailable"
      };
      blueskyDecisionCache.set(post.key, { checkedAt: Date.now(), decision });
      decisions.set(post.key, decision);
    }
  }

  return {
    decisions: posts.map((post) => decisions.get(post.key)),
    source: "bluesky-public-api"
  };
}

async function fetchBlueskyPostLabels(posts) {
  const profileToDid = new Map();
  const profiles = Array.from(new Set(posts.map((post) => post.profile)));
  for (let index = 0; index < profiles.length; index += BLUESKY_PROFILE_RESOLVE_BATCH_SIZE) {
    const batch = profiles.slice(index, index + BLUESKY_PROFILE_RESOLVE_BATCH_SIZE);
    const resolvedProfiles = await Promise.all(batch.map(async (profile) => ({
      profile,
      did: await resolveBlueskyProfile(profile)
    })));
    for (const resolvedProfile of resolvedProfiles) {
      if (resolvedProfile.did) {
        profileToDid.set(resolvedProfile.profile, resolvedProfile.did);
      }
    }
  }

  const resolved = posts
    .filter((post) => profileToDid.has(post.profile))
    .map((post) => ({
      key: post.key,
      uri: "at://" + profileToDid.get(post.profile) + "/app.bsky.feed.post/" + post.rkey
    }));
  if (!resolved.length) {
    return new Map();
  }

  const result = new Map();
  for (let index = 0; index < resolved.length; index += BLUESKY_POST_BATCH_SIZE) {
    const batchResult = await fetchBlueskyPostLabelBatch(
      resolved.slice(index, index + BLUESKY_POST_BATCH_SIZE)
    );
    for (const [key, decision] of batchResult) {
      result.set(key, decision);
    }
  }
  return result;
}

async function fetchBlueskyPostLabelBatch(resolved) {
  const params = new URLSearchParams();
  for (const post of resolved) {
    params.append("uris", post.uri);
  }

  try {
    const response = await fetch("https://public.api.bsky.app/xrpc/app.bsky.feed.getPosts?" + params.toString(), {
      credentials: "omit",
      cache: "no-store",
      redirect: "follow",
      headers: { "Accept": "application/json" }
    });
    if (!response.ok) {
      return new Map();
    }

    const payload = await response.json();
    const byUri = new Map(resolved.map((post) => [post.uri, post.key]));
    const result = new Map();
    for (const post of payload && Array.isArray(payload.posts) ? payload.posts : []) {
      const key = byUri.get(String(post && post.uri || ""));
      if (!key) {
        continue;
      }

      const labels = collectBlueskyLabels(post);
      result.set(key, {
        key,
        known: true,
        blocked: labels.some((label) => BLUESKY_ADULT_LABELS.has(label)),
        labels,
        source: "bluesky-public-api"
      });
    }
    return result;
  } catch {
    return new Map();
  }
}

async function resolveBlueskyProfile(profile) {
  const value = String(profile || "").trim().toLowerCase();
  if (/^did:[a-z0-9:._%-]+$/i.test(value)) {
    return value;
  }
  if (!/^[a-z0-9](?:[a-z0-9.-]{1,251}[a-z0-9])?$/i.test(value)) {
    return "";
  }

  const cached = blueskyHandleCache.get(value);
  if (cached && Date.now() - cached.checkedAt < 60 * 60 * 1000) {
    return cached.did;
  }

  try {
    const response = await fetch("https://public.api.bsky.app/xrpc/com.atproto.identity.resolveHandle?handle=" + encodeURIComponent(value), {
      credentials: "omit",
      cache: "no-store",
      headers: { "Accept": "application/json" }
    });
    if (!response.ok) {
      return "";
    }
    const payload = await response.json();
    const did = String(payload && payload.did || "").trim().toLowerCase();
    if (!/^did:[a-z0-9:._%-]+$/i.test(did)) {
      return "";
    }
    blueskyHandleCache.set(value, { checkedAt: Date.now(), did });
    return did;
  } catch {
    return "";
  }
}

function collectBlueskyLabels(post) {
  const labels = [];
  const add = (value) => {
    const normalized = String(value || "").trim().toLowerCase();
    if (normalized && !labels.includes(normalized)) {
      labels.push(normalized);
    }
  };

  const addFrom = (source) => {
    for (const label of source && Array.isArray(source.labels) ? source.labels : []) {
      add(label && (label.val || label.value));
    }
    const selfLabels = source && source.labels && Array.isArray(source.labels.values)
      ? source.labels.values
      : [];
    for (const label of selfLabels) {
      add(label && (label.val || label.value));
    }
  };

  const quoted = post && post.embed && post.embed.record && post.embed.record.record;
  for (const source of [
    post,
    post && post.author,
    post && post.record,
    quoted,
    quoted && quoted.author,
    quoted && quoted.record
  ]) {
    addFrom(source);
  }
  return labels;
}

function normalizeBlueskyPost(input) {
  const profile = String(input && input.profile || "").trim().toLowerCase();
  const rkey = String(input && input.rkey || "").trim();
  if ((!/^did:[a-z0-9:._%-]+$/i.test(profile) && !/^[a-z0-9](?:[a-z0-9.-]{1,251}[a-z0-9])?$/i.test(profile)) ||
      !/^[a-zA-Z0-9._~:-]{3,128}$/.test(rkey)) {
    return null;
  }
  return { profile, rkey, key: profile + "/" + rkey };
}

async function checkRedditPosts(inputs) {
  const postIds = [];
  const seen = new Set();

  for (const input of Array.isArray(inputs) ? inputs : []) {
    const postId = normalizePostId(input);
    if (postId && !seen.has(postId)) {
      seen.add(postId);
      postIds.push(postId);
    }

    if (postIds.length >= 50) {
      break;
    }
  }

  const decisions = new Map();
  const missing = [];

  for (const postId of postIds) {
    const cached = postDecisionCache.get(postId);
    const ttl = cached && cached.decision.known ? CACHE_TTL_MS : UNKNOWN_CACHE_TTL_MS;
    if (cached && Date.now() - cached.checkedAt < ttl) {
      decisions.set(postId, cached.decision);
    } else {
      missing.push(postId);
    }
  }

  if (missing.length) {
    const fetched = await fetchRedditPostMetadata(missing);
    for (const postId of missing) {
      const decision = fetched.get(postId) || {
        postId,
        known: false,
        blocked: false,
        source: "reddit-post-unavailable"
      };

      postDecisionCache.set(postId, { checkedAt: Date.now(), decision });
      decisions.set(postId, decision);
    }
  }

  return {
    decisions: postIds.map((postId) => decisions.get(postId)),
    source: "reddit-by-id"
  };
}

async function fetchRedditPostMetadata(postIds) {
  const fullNames = postIds.map((postId) => "t3_" + postId).join(",");
  const urls = [
    "https://www.reddit.com/by_id/" + fullNames + ".json?raw_json=1",
    "https://old.reddit.com/by_id/" + fullNames + ".json?raw_json=1"
  ];

  for (const url of urls) {
    try {
      const response = await fetch(url, {
        credentials: "include",
        cache: "no-store",
        redirect: "follow",
        headers: { "Accept": "application/json" }
      });

      if (!response.ok) {
        continue;
      }

      const payload = await response.json();
      const children = payload && payload.data && Array.isArray(payload.data.children)
        ? payload.data.children
        : [];
      const result = new Map();

      for (const child of children) {
        const data = child && child.data ? child.data : {};
        const postId = normalizePostId(data.id || data.name);
        if (!postId) {
          continue;
        }

        result.set(postId, {
          postId,
          known: true,
          blocked: isTrue(data.over_18) || isTrue(data.over18) || isTrue(data.isNsfw),
          source: "reddit-by-id"
        });
      }

      return result;
    } catch {
      // EGR-002: Hier stand, das Content-Skript halte unbekannte Vorschauen
      // bedeckt, wenn Reddit diese Abfrage abweist. Das ist FALSCH und war
      // schon falsch, als es geschrieben wurde: content.js gibt bei
      // state === "unknown" ausdruecklich frei (releaseMediaRoot), weil die
      // by-id-Abfrage bei grossen Feed-Stapeln ratenbegrenzt wird und dabei
      // harmlose Bilder verdeckte.
      //
      // Das VERHALTEN ist eine begruendete Entscheidung mit vier
      // Ersatzsignalen - dagegen ist nichts zu sagen. Der Schaden war der
      // Satz an dieser Stelle: wer die Abfrage anfasst, liest ihn und haelt
      // eine Ratenbegrenzung von Reddit fuer unkritisch abgedeckt. Genau so
      // ein Satz hat in diesem Projekt schon zweimal zu einem Fehlschluss
      // gefuehrt.
    }
  }

  return new Map();
}

async function checkRedditSubreddit(input) {
  const subreddit = normalizeSubreddit(input);
  if (!subreddit) {
    return { blocked: false, reason: "", source: "invalid" };
  }

  const cached = decisionCache.get(subreddit);
  if (cached && Date.now() - cached.checkedAt < CACHE_TTL_MS) {
    return cached.decision;
  }

  const localList = await getLocalSubredditList();
  if (localList.has(subreddit)) {
    return cacheDecision(subreddit, {
      blocked: true,
      reason: "Diese Reddit-Community steht auf der lokalen 18+-Liste.",
      source: "local-list"
    });
  }

  if (looksAdultByName(subreddit)) {
    return cacheDecision(subreddit, {
      blocked: true,
      reason: "Der Community-Name entspricht einer aktiven Erwachseneninhalts-Regel.",
      source: "name-rule"
    });
  }

  const metadataDecision = await checkRedditMetadata(subreddit);
  return cacheDecision(subreddit, metadataDecision);
}

async function getLocalSubredditList() {
  if (!localSubredditListPromise) {
    localSubredditListPromise = fetch(chrome.runtime.getURL("rules/nsfw-subreddits.txt"))
      .then((response) => {
        if (!response.ok) {
          throw new Error("Local Reddit list could not be loaded.");
        }

        return response.text();
      })
      .then(parseSubredditList);
  }

  return localSubredditListPromise;
}

function parseSubredditList(text) {
  const names = new Set();
  for (const rawLine of String(text || "").split(/\r?\n/)) {
    const normalized = normalizeSubreddit(rawLine);
    if (normalized) {
      names.add(normalized);
    }
  }

  return names;
}

async function checkRedditMetadata(subreddit) {
  const encoded = encodeURIComponent(subreddit);
  const urls = [
    "https://www.reddit.com/r/" + encoded + "/about.json?raw_json=1",
    "https://old.reddit.com/r/" + encoded + "/about.json?raw_json=1"
  ];

  for (const url of urls) {
    try {
      const response = await fetch(url, {
        credentials: "include",
        cache: "no-store",
        redirect: "follow",
        headers: { "Accept": "application/json" }
      });

      if (!response.ok) {
        continue;
      }

      const payload = await response.json();
      const data = payload && payload.data ? payload.data : {};
      const over18 = isTrue(data.over18) || isTrue(data.over_18) || isTrue(data.isNsfw);

      if (over18) {
        return {
          blocked: true,
          reason: "Reddit markiert diese Community als 18+.",
          source: "reddit-about"
        };
      }

      return {
        blocked: false,
        reason: "",
        source: "reddit-about"
      };
    } catch {
      // The page-side detector remains available when Reddit rejects this endpoint.
    }
  }

  return {
    blocked: false,
    reason: "",
    source: "reddit-about-unavailable"
  };
}

function looksAdultByName(subreddit) {
  if (SAFE_NAME_EXCEPTIONS.has(subreddit)) {
    return false;
  }

  const compact = subreddit.replace(/_/g, "");
  return ADULT_NAME_TERMS.some((term) => compact.includes(term));
}

function isTrue(value) {
  return value === true || value === "true" || value === 1 || value === "1";
}

function cacheDecision(subreddit, decision) {
  decisionCache.set(subreddit, {
    checkedAt: Date.now(),
    decision
  });

  return decision;
}

function normalizeSubreddit(input) {
  let value = String(input || "").trim().toLowerCase();
  value = value.replace(/^https?:\/\/(www\.|old\.|new\.)?reddit\.com\/r\//i, "");
  value = value.replace(/^\/?r\//i, "");
  value = value.split(/[/?#]/)[0];

  if (!/^[a-z0-9_]{2,32}$/.test(value)) {
    return "";
  }

  return value;
}

function normalizePostId(input) {
  let value = String(input || "").trim().toLowerCase();
  value = value.replace(/^t3_/, "");
  return /^[a-z0-9]{3,16}$/.test(value) ? value : "";
}
