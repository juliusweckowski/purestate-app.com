"use strict";

// Purestate shared adult-search blocklist + helpers.
//
// One canonical NSFW search-term list used by every site companion, so the list
// is extended in a single place. Loaded as the FIRST content script in each
// site's manifest entry; it publishes its helpers on globalThis so the sibling
// site scripts (which run in the same isolated world) can call them.
//
// `purestateIsAdultSearchText(text)` is the core test. Each site extracts the
// user's search term/tag from its own URL shape and asks this. The shared
// `purestateShowSearchOverlay` / `purestateInstantHide` give every site a
// consistent full-page block without duplicating overlay code.

(function () {
  // Build/load marker: prints once per page where the companion is active, so a
  // developer can confirm in DevTools whether the CURRENT extension build is
  // actually running (reloading an unpacked extension does not re-inject into
  // already-open tabs - the tab must also be reloaded). "purestate" tag makes it
  // easy to filter. Harmless in production; no page data is logged.
  try {
    const buildVersion = (typeof chrome !== "undefined" && chrome.runtime && typeof chrome.runtime.getManifest === "function")
      ? chrome.runtime.getManifest().version
      : "unbekannt";
    console.info("[purestate] companion build " + buildVersion + " aktiv");
  } catch {
  }

  // Clearly-adult search terms as regex fragments. Wrapped in word boundaries at
  // build time, so e.g. "sex" never matches "essex" and "anal" never matches
  // "canal". Extend HERE — it propagates to all sites.
  const TERMS = [
    "adult", "ahegao", "amateur", "anal", "bareback", "bbc porn", "bbw", "bdsm",
    "big\\s*ass", "big\\s*boobs?", "big\\s*cocks?", "big\\s*dicks?", "big\\s*tits?",
    "bimbo", "blow\\s*job", "blowie", "bondage", "bongacams", "boob(?:ies|s)?",
    "bordell", "breasts?",
    "breeding", "bukkake", "bumsen", "busty", "camgirls?", "camshow", "camsoda",
    "cameltoe", "chaturbate",
    "choke\\s*me", "clit", "clothoff", "cock(?:s|tribute)?", "coomer\\w*",
    "creampie", "cum(?:shot|tribute)?",
    "cunt", "deepnude", "deepthroat", "dick(?:s|\\s*pics?)?", "dildo", "doggystyle",
    "e621", "ecchi",
    "edging", "erome", "erotica?", "erotik", "escort", "explicit", "f95zone",
    "facial", "fansly", "fap(?:ping)?", "fapello",
    "femdom", "fetish", "fick\\w*", "findom", "fingering", "fleshlight", "footjob",
    "fotze", "fuck\\w*",
    "futanari", "gangbang", "gay\\s*porn", "gelbooru", "gonewild", "gone\\s*wild", "goon(?:er)?",
    "goon\\w*", "handjob", "hanime", "hardcore", "hentai", "horny", "huren?",
    "incest", "jav", "jerk\\s*off",
    "justforfans", "kink", "lewd", "livejasmin", "loyalfans", "manyvids", "masturbat(?:e|ion|ing)?", "milf",
    "motherless", "muschi", "myfreecams", "nackt\\w*", "naked", "nhentai",
    "nipples?", "nsfw\\w*", "nude(?:s|ity)?", "nudify\\w*", "nutten?", "nympho", "onlyfans", "orgasm",
    "paizuri", "pegging", "penis(?:es)?", "pimmel", "porno(?:graphy)?", "porn\\w*", "pron", "pussy", "realnsfw", "redgifs", "redtube", "rimjob",
    "rule\\s*?34", "r34", "sex(?:y|cam|tape|film\\w*|videos?|bilder|geschichten)?", "sissy", "skyhub", "slut(?:ty)?", "smut",
    "softcore", "spankbang", "spicysky", "squirt(?:ing)?", "strapon", "stripchat", "suck\\s*my", "swinger",
    "thirst\\s*trap", "thothub", "threesome", "tits", "titt(?:en|ies|y)", "topless", "twerk",
    "undress\\s*ai", "vagina", "wank", "whore", "xhamster", "xvideos", "xnxx", "xxx", "yiff", "youporn"
  ];

  const pattern = new RegExp("\\b(?:" + TERMS.join("|") + ")\\b", "i");

  // Aufklaerung, Medizin, Bildung, Biologie: Phrasen, die einen Begriff aus
  // TERMS enthalten, ohne eine Suche nach Erwachseneninhalten zu sein. Ohne sie
  // liefert "breast cancer" auf zehn Suchmaschinen einen Vollvorhang - der
  // Vorwurf, der am teuersten ist, weil er genau die Suchen trifft, bei denen
  // Hilfe gemeint war (Befund ASL-001).
  //
  // WICHTIG - warum das kein Schlupfloch ist: die Phrase wird aus dem Text
  // ENTFERNT und der Rest ganz normal geprueft. "breast cancer porn" bleibt
  // gesperrt. Eine Ausnahme kann damit nie mehr freigeben als ihre eigenen
  // Woerter.
  //
  // Wie NEVER_BLOCK_HOSTS in adult-detect.js: fest im CODE und per Test
  // gepinnt. Konfigurierbar hiesse leerbar, und eine leerbare Ausnahmeliste
  // fuer Aufklaerung ist genau der Schalter, den man im Impuls umlegt.
  const SAFE_PHRASES = [
    // Medizin
    "breasts?\\s*cancer", "breasts?\\s*exam(?:ination)?", "breasts?\\s*surger(?:y|ies)",
    "breasts?\\s*screening", "breasts?\\s*feeding", "sexual\\s*health",
    // Aufklaerung und Bildung
    "sex(?:ual)?\\s*education", "sex\\s*ed", "adult\\s*education", "adult\\s*learning",
    // Biologie: "naked" und das Praefixmuster "nackt\\w*" treffen sonst Tiere
    "naked\\s*mole\\s*rats?", "naked\\s*eye", "nacktmull\\w*", "nacktschnecken?",
    "nacktsamer\\w*"
  ];
  const safePhrasePattern = new RegExp("\\b(?:" + SAFE_PHRASES.join("|") + ")\\b", "gi");

  function stripSafePhrases(text) {
    return text.replace(safePhrasePattern, " ");
  }
  const GAMBLING_TERMS = [
    "casinos?", "online\\s*casinos?", "gluecksspiel\\w*", "sport\\s*wetten", "sportwetten",
    "wetten", "wett\\s*bonus", "wettbonus", "wettanbieter", "bookmakers?",
    "slots?", "slot\\s*machines?", "spielautomaten?", "poker", "online\\s*poker",
    "blackjack", "roulette", "jackpots?", "lotto", "lotterie", "crypto\\s*casinos?",
    "bitcoin\\s*casinos?", "playzilla", "no\\s*verification\\s*casino",
    "casino\\s*bonus", "free\\s*spins", "online\\s*slots", "slot\\s*games"
  ];
  const gamblingPattern = new RegExp("\\b(?:" + GAMBLING_TERMS.join("|") + ")\\b", "i");
  const GAMBLING_SAFE_CONTEXT = /\b(cast|lyrics|song|film|movie|book|history|research|color|palette|slot car|casino royale)\b/i;

  function normalize(text) {
    return String(text == null ? "" : text).replace(/[+_%\-]+/g, " ");
  }

  // Common leetspeak digit/symbol substitutions ("pr0n", "s3x", "t1ts"). The
  // decoded variant is tested IN ADDITION to the raw text, so digit-heavy safe
  // queries ("windows 10", "m4a", "1080p") stay unblocked unless the decoded
  // form itself becomes an adult term.
  const LEET_MAP = { "0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "$": "s", "@": "a" };

  function leetDecode(text) {
    return text.replace(/[013457$@]/g, function (ch) { return LEET_MAP[ch]; });
  }

  // The canonical test: does this free text contain an adult search term?
  globalThis.purestateIsAdultSearchText = function (text) {
    const normalized = normalize(text);
    return pattern.test(stripSafePhrases(normalized)) ||
      pattern.test(stripSafePhrases(leetDecode(normalized)));
  };

  // Tippen ist noch keine Suche. Solange ein Feld den Fokus hat, ist sein
  // letztes Wort unfertig: "anal" auf dem Weg zu "analysis", "cock" zu
  // "cocktail", "milf" zu "Milford". Live gemessen am 2026-10-06 (YouTube):
  // "tokyo ghoul season 1 anal" loeste den Vollvorhang aus, der den Fokus
  // nahm und die Seite inert machte - das Wort liess sich nicht zu Ende
  // tippen. Der offene Rest zaehlt erst nach einem Trennzeichen, bei
  // Fokusverlust oder nach dem Abschicken (dann entscheidet die Adresse).
  // Ohne Fokusinformation (Testattrappen, Fremdobjekte) gilt der volle Text.
  //
  // Autofokus ist kein Tippen: Eine Trefferseite nach POST-Suche kann ihr
  // vorbelegtes Feld selbst fokussieren. Solange auf dieser Seite noch keine
  // Nutzereingabe stattfand (navigator.userActivation, im echten Chromium
  // gemessen am 2026-10-06: auch in der isolierten Welt sichtbar, vor dem
  // ersten input-Ereignis schon gesetzt), steht dort eine abgeschickte Suche -
  // sonst liesse sich der Vorhang mit Autofokus umgehen. Fehlt die Angabe,
  // entscheidet wie bisher der Fokus allein.
  const OPEN_TOKEN = /[\p{L}\p{N}$@]+$/u;

  function purestateControlHasFocus(control) {
    try {
      const activation = globalThis.navigator && globalThis.navigator.userActivation;
      if (activation && activation.hasBeenActive === false) {
        return false;
      }
      if (control && typeof control.matches === "function" && control.matches(":focus-within")) {
        return true;
      }
      const doc = control && control.ownerDocument;
      return !!(doc && doc.activeElement === control);
    } catch {
      return false;
    }
  }

  globalThis.purestateSettledSearchText = function (control, text) {
    const value = String(text == null ? "" : text);
    return purestateControlHasFocus(control) ? value.replace(OPEN_TOKEN, "") : value;
  };

  globalThis.purestateIsGamblingSafeSearchContext = function (text) {
    const normalized = normalize(text);
    return GAMBLING_SAFE_CONTEXT.test(normalized);
  };

  globalThis.purestateIsGamblingSearchText = function (text) {
    const normalized = normalize(text);
    if (globalThis.purestateIsGamblingSafeSearchContext(normalized)) {
      return false;
    }
    return gamblingPattern.test(normalized);
  };

  // Expose the compiled pattern for sites that still keep a named constant.
  globalThis.purestateAdultSearchPattern = function () {
    return pattern;
  };

  // Returns the first matching adult search value among the given query params of
  // a URL, or null. Used by sites whose search term lives in a query string.
  globalThis.purestateAdultSearchParam = function (urlString, paramNames) {
    try {
      const url = new URL(urlString);
      for (const name of paramNames) {
        const value = url.searchParams.get(name);
        if (value && globalThis.purestateIsAdultSearchText(value)) {
          return value;
        }
      }
    } catch {
    }
    return null;
  };

  // Safe-search enforcement for engines with reliably documented URL params:
  // Bing (adlt=strict), DuckDuckGo (kp=1), Yandex (family=yes). Returns the
  // rewritten result-page URL, or "" when nothing needs to change (already
  // safe, not a result page, foreign host, non-http scheme) - the caller uses
  // "" as its loop-safety guard around location.replace. Google is enforced by
  // the ForceGoogleSafeSearch policy, Ecosia/Startpage have no documented
  // param and stay on the adult-term page block only.
  globalThis.purestateSafeSearchRedirectUrl = function (urlString) {
    let url;
    try {
      url = new URL(String(urlString || ""));
    } catch {
      return "";
    }
    if (url.protocol !== "http:" && url.protocol !== "https:") {
      return "";
    }
    const host = url.hostname.toLowerCase().replace(/^www\./, "");
    const path = url.pathname.toLowerCase();
    let param = "";
    let value = "";
    if (host === "bing.com" &&
      (path === "/search" || path === "/images/search" || path === "/videos/search")) {
      param = "adlt";
      value = "strict";
    } else if (host === "duckduckgo.com" && url.searchParams.get("q")) {
      param = "kp";
      value = "1";
    } else if ((host === "yandex.com" || host === "yandex.ru") && path.startsWith("/search")) {
      param = "family";
      value = "yes";
    } else {
      return "";
    }

    // Param names and values compare case-insensitively (Bing accepts
    // ADLT=Strict); every casing variant is replaced by one canonical pair.
    const variants = [];
    let alreadySafe = false;
    for (const [key, existing] of url.searchParams) {
      if (key.toLowerCase() === param) {
        variants.push(key);
        alreadySafe = String(existing).toLowerCase() === value;
      }
    }
    if (alreadySafe) {
      return "";
    }
    for (const key of variants) {
      url.searchParams.delete(key);
    }
    url.searchParams.append(param, value);
    return url.toString();
  };

  // Idempotent <style> injection shared by every site companion: skip if a style
  // with this id already exists, else create+id+text+append. Callers still build
  // their own CSS text; this only removes the repeated DOM boilerplate.
  globalThis.purestateInjectStyle = function (doc, styleId, cssText) {
    const target = doc || document;
    if (!target.documentElement || target.getElementById(styleId)) {
      return;
    }
    const style = target.createElement("style");
    style.id = styleId;
    style.textContent = cssText;
    target.documentElement.appendChild(style);
  };

  // Inject a document_start style that blanks the page so a blocked search never
  // flashes before the overlay is built. Idempotent.
  globalThis.purestateInstantHide = function (doc, styleId) {
    globalThis.purestateInjectStyle(doc, styleId, "body { visibility: hidden !important; }");
  };

  globalThis.purestateRemoveInstantHide = function (doc, styleId) {
    const target = doc || document;
    const style = target.getElementById && target.getElementById(styleId);
    if (style) {
      style.remove();
    }
  };

  // EXT-A04: Gemeinsamer Fokusvertrag der Vollvorhaenge (Muster wie die
  // Social-Reflexion). Die Knoepfe setzen mit all:unset auch den Fokusring
  // des Browsers zurueck, also bekommen sie einen eigenen, gegen Seiten-CSS
  // festen Ring. Der Vorhang nimmt den Fokus in seine erste Aktion, macht die
  // Geschwister inert und haelt Tab in sich. Escape bleibt bewusst ohne
  // Wirkung: verlassen wird die Seite nur ueber die Aktionen, und der Schutz
  // faellt nur, wenn sein Besitzer ihn legitim abraeumt (dann Release).
  function purestateFocusWithoutScroll(element) {
    try {
      element.focus({ preventScroll: true });
    } catch {
      try {
        element.focus();
      } catch {
      }
    }
  }

  function purestateRestoreAttribute(element, name, value) {
    if (value === null) {
      element.removeAttribute(name);
    } else {
      element.setAttribute(name, value);
    }
  }

  globalThis.purestateOverlayFocusRing = function (button, color, gapColor) {
    if (!button || typeof button.addEventListener !== "function") {
      return;
    }
    const shadow = gapColor
      ? "0 0 0 3px " + gapColor + ", 0 0 0 6px " + color
      : "0 0 0 3px " + color;
    button.addEventListener("focus", function () {
      button.style.setProperty("box-shadow", shadow, "important");
    });
    button.addEventListener("blur", function () {
      button.style.removeProperty("box-shadow");
    });
  };

  // Sicherheitsreview: Der inert-Zustand gehoert allen gehaltenen Vorhaengen
  // gemeinsam, nicht jedem einzeln. Frueher sicherte jeder Vorhang seine
  // Geschwister selbst - entfernte die Seite einen Vorhang ohne Release
  // (pixiv/React) oder schlossen zwei Vorhaenge in falscher Reihenfolge, blieb
  // die Seite inert. Jetzt: Ausgangswerte der Seite einmal gemerkt, bei jeder
  // Aenderung alles zurueckgeben und fuer die noch angehaengten Vorhaenge neu
  // setzen. Das Register liegt auf globalThis, weil adult-search-terms.js pro
  // Seite mehrfach eingespielt werden kann (mehrere Manifestbloecke) und alle
  // Einspielungen dieselbe isolierte Welt teilen.
  const focusHolds = globalThis.__purestateOverlayFocusHolds ||
    (globalThis.__purestateOverlayFocusHolds = { overlays: new Set(), inerted: new Map() });

  function purestateContainsHeldOverlay(element) {
    for (const held of focusHolds.overlays) {
      if (held === element || (typeof element.contains === "function" && element.contains(held))) {
        return true;
      }
    }
    return false;
  }

  function purestateRefreshFocusHolds() {
    for (const [element, original] of focusHolds.inerted) {
      purestateRestoreAttribute(element, "inert", original.inert);
      purestateRestoreAttribute(element, "aria-hidden", original.ariaHidden);
    }
    focusHolds.inerted.clear();
    for (const overlay of Array.from(focusHolds.overlays)) {
      if (overlay.isConnected === false) {
        focusHolds.overlays.delete(overlay);
        overlay.purestateFocusHeld = false;
      }
    }
    for (const overlay of focusHolds.overlays) {
      const parent = overlay.parentElement;
      for (const sibling of Array.from(parent && parent.children ? parent.children : [])) {
        if (purestateContainsHeldOverlay(sibling)) {
          continue;
        }
        if (!focusHolds.inerted.has(sibling)) {
          focusHolds.inerted.set(sibling, {
            inert: sibling.getAttribute("inert"),
            ariaHidden: sibling.getAttribute("aria-hidden")
          });
        }
        sibling.setAttribute("inert", "");
        sibling.setAttribute("aria-hidden", "true");
      }
    }
  }

  globalThis.purestateHoldOverlayFocus = function (doc, overlay, firstAction) {
    const target = doc || document;
    if (!overlay || overlay.purestateFocusHeld === true) {
      return;
    }
    overlay.purestateFocusHeld = true;
    if (overlay.getAttribute("role")) {
      overlay.setAttribute("aria-modal", "true");
    }
    overlay.purestatePreviousFocus = target.activeElement || null;
    focusHolds.overlays.add(overlay);
    purestateRefreshFocusHolds();
    overlay.addEventListener("keydown", function (event) {
      if (!event || event.key !== "Tab" || typeof overlay.querySelectorAll !== "function") {
        return;
      }
      const actions = Array.from(overlay.querySelectorAll("button")).filter(function (button) {
        return !button.disabled;
      });
      if (actions.length === 0) {
        return;
      }
      event.preventDefault();
      const current = actions.indexOf(target.activeElement);
      const next = event.shiftKey
        ? (current <= 0 ? actions.length - 1 : current - 1)
        : (current < 0 || current === actions.length - 1 ? 0 : current + 1);
      actions[next].focus();
    }, true);
    purestateFocusWithoutScroll(firstAction || overlay);
  };

  // Ohne (gehaltenen) Vorhang raeumt der Aufruf nur auf: abgehaengte Vorhaenge
  // fallen aus dem Register, und ohne verbleibenden Vorhang wird die Seite frei.
  globalThis.purestateReleaseOverlayFocus = function (overlay) {
    const held = !!overlay && overlay.purestateFocusHeld === true && focusHolds.overlays.has(overlay);
    if (held) {
      focusHolds.overlays.delete(overlay);
      overlay.purestateFocusHeld = false;
    }
    purestateRefreshFocusHolds();
    if (!held) {
      return;
    }
    const previous = overlay.purestatePreviousFocus;
    overlay.purestatePreviousFocus = null;
    if (previous && previous.isConnected !== false && typeof previous.focus === "function") {
      purestateFocusWithoutScroll(previous);
    }
  };

  // Whether the page context prefers a dark color scheme. Defensive: fixtures
  // and Node tests have no matchMedia; any failure means "light".
  function purestatePrefersDark(target) {
    try {
      const view = (target && target.defaultView) || (typeof window !== "undefined" ? window : null);
      return !!(view && typeof view.matchMedia === "function" && view.matchMedia("(prefers-color-scheme: dark)").matches);
    } catch {
      return false;
    }
  }
  // EXT-A07: Die Schwester-Skripte fragen typeof purestatePrefersDark - ohne
  // diese Veroeffentlichung blieben ihre Vorhaenge immer hell.
  globalThis.purestatePrefersDark = purestatePrefersDark;

  // Vorhang-Baukasten (docs/superpowers/specs/2026-09-15-vorhaenge-website-look-design.md):
  // Farben, Schrift und Bausteine der Website fuer jede Einblendung. Die Bauer
  // in den Site-Skripten behalten Verhalten, IDs und Fokusvertrag; von hier
  // kommt nur das Aussehen. Jede Deklaration traegt !important, weil die
  // Elemente in fremden Seiten stehen (Reddit setzt globale button-, ul- und
  // b-Regeln).
  const CURTAIN_PALETTES = {
    light: {
      bg: "#f3f5f5", surface: "#fafcfc", ink: "#0a1a31", soft: "#414d5e", faint: "#526077",
      line: "#d5deea", lineStrong: "#b8c5d5", accent: "#0e7472", bars: "#49c3bd",
      btn: "#0f1e33", btnInk: "#ffffff", btnHover: "#1c3357",
      warn: "#8a5a00", warnBg: "#efece3", shadow: "0 1px 2px rgb(15 30 51 / .07)"
    },
    dark: {
      bg: "#0a111d", surface: "#111b2c", ink: "#e8ecf1", soft: "#a8b4c6", faint: "#8391a7",
      line: "#202d43", lineStrong: "#2e3f5e", accent: "#49c3bd", bars: "#49c3bd",
      btn: "#49c3bd", btnInk: "#04121f", btnHover: "#63d4ce",
      warn: "#d9a441", warnBg: "#25292e", shadow: "0 1px 2px rgb(0 0 0 / .35)"
    }
  };
  const CURTAIN_FONTS = {
    fontText: "'Segoe UI Variable Text','Segoe UI',system-ui,sans-serif",
    fontDisplay: "'Segoe UI Variable Display','Segoe UI',system-ui,sans-serif",
    fontMono: "'Cascadia Mono',Consolas,ui-monospace,monospace"
  };
  // Breite, Hoehe, Abstand der zwei Pausebalken in px.
  const CURTAIN_BAR_SIZES = { lg: [10, 52, 12], sm: [7, 32, 8], xs: [3, 14, 3] };

  globalThis.purestateCurtainTheme = function (doc) {
    const palette = purestatePrefersDark(doc) ? CURTAIN_PALETTES.dark : CURTAIN_PALETTES.light;
    return Object.assign({}, palette, CURTAIN_FONTS);
  };

  globalThis.purestateCurtainCss = function (rules) {
    return rules.map(function (rule) {
      const colon = rule.indexOf(":");
      return rule.slice(0, colon) + ":" + rule.slice(colon + 1) + " !important";
    }).join(";");
  };

  // EXT-A05: Der Vorhang scrollt selbst, die Spalte zentriert sich per
  // margin:auto. align-items:center am Vorhang schnitt zu hohen Inhalt oben ab.
  globalThis.purestateCurtainOverlayCss = function (theme, extraRules) {
    return globalThis.purestateCurtainCss([
      "position:fixed", "inset:0", "z-index:2147483647",
      "display:flex", "overflow-y:auto", "overscroll-behavior:contain",
      "padding:24px", "box-sizing:border-box",
      "background:" + theme.bg, "color:" + theme.ink,
      "font-family:" + theme.fontText, "text-align:center",
      "pointer-events:all", "touch-action:pan-y", "outline:0",
      "visibility:visible", "opacity:1", "transform:none", "clip-path:none"
    ].concat(extraRules || []));
  };

  globalThis.purestateCurtainColumn = function (doc) {
    const column = doc.createElement("div");
    column.style.cssText = globalThis.purestateCurtainCss([
      "margin:auto", "width:100%", "max-width:544px", "box-sizing:border-box",
      "display:flex", "flex-direction:column", "align-items:center",
      "line-height:1.5", "visibility:visible"
    ]);
    return column;
  };

  globalThis.purestateCurtainBars = function (doc, theme, size) {
    const dimensions = CURTAIN_BAR_SIZES[size] || CURTAIN_BAR_SIZES.lg;
    const bars = doc.createElement("span");
    bars.setAttribute("aria-hidden", "true");
    bars.style.cssText = globalThis.purestateCurtainCss([
      "display:inline-flex", "gap:" + dimensions[2] + "px", "flex:none", "visibility:visible"
    ]);
    for (let index = 0; index < 2; index += 1) {
      const bar = doc.createElement("span");
      bar.style.cssText = globalThis.purestateCurtainCss([
        "display:block", "width:" + dimensions[0] + "px", "height:" + dimensions[1] + "px",
        "border-radius:999px", "background:" + theme.bars
      ]);
      bars.appendChild(bar);
    }
    return bars;
  };

  // Restzeit-Kaestchen unten rechts: gemeinsamer Baustein von Social Media,
  // Shopping und Gluecksspiel (Befund 2026-10-06: Shopping und Gluecksspiel
  // zaehlten laengst mit, zeigten aber nichts an). Es zeigt nur, es klickt
  // nicht durch (pointer-events:none) und liegt unter den Vollvorhaengen
  // (z-index 2147483647).
  globalThis.purestateFormatRemaining = function (seconds) {
    if (!Number.isInteger(seconds) || seconds < 0) {
      return "";
    }
    return "Noch " + Math.floor(seconds / 60) + ":" + String(seconds % 60).padStart(2, "0") + " min";
  };

  globalThis.purestateShowTimeBadge = function (doc, id, text) {
    const target = doc || document;
    if (!target.documentElement || !target.createElement) {
      return;
    }
    let badge = target.getElementById ? target.getElementById(id) : null;
    if (!badge) {
      const theme = globalThis.purestateCurtainTheme(target);
      badge = target.createElement("div");
      badge.id = id;
      badge.setAttribute("role", "status");
      badge.setAttribute("aria-live", "off");
      badge.style.cssText = globalThis.purestateCurtainCss([
        "position:fixed", "right:12px", "bottom:12px", "z-index:2147483645",
        "display:inline-flex", "align-items:center", "gap:7px",
        "padding:6px 12px", "border-radius:999px", "box-sizing:border-box",
        "background:" + theme.surface, "color:" + theme.ink,
        "border:1px solid " + theme.line, "box-shadow:" + theme.shadow,
        "font:13px " + theme.fontMono, "pointer-events:none"
      ]);
      badge.appendChild(globalThis.purestateCurtainBars(target, theme, "xs"));
      badge.purestateLabel = target.createElement("span");
      badge.appendChild(badge.purestateLabel);
      (target.body || target.documentElement).appendChild(badge);
    }
    if (badge.purestateLabel) {
      badge.purestateLabel.textContent = text;
    }
  };

  globalThis.purestateRemoveTimeBadge = function (doc, id) {
    const target = doc || document;
    if (!target.getElementById) {
      return;
    }
    const badge = target.getElementById(id);
    if (badge && badge.parentElement) {
      badge.parentElement.removeChild(badge);
    }
  };

  // Gewichtskontrast der Website: Titel 300, Schlusswort 600. Der Titel
  // behaelt den Text selbst und haengt nur das Schlusswort als Kind an - im
  // Browser liest aria-labelledby so den vollen Titel.
  globalThis.purestateCurtainTitle = function (doc, theme, id, text, size) {
    const value = String(text == null ? "" : text);
    const split = value.lastIndexOf(" ");
    const title = doc.createElement("div");
    if (id) {
      title.id = id;
    }
    title.style.cssText = globalThis.purestateCurtainCss([
      "margin:8px 0 0 0", "max-width:100%", "overflow-wrap:anywhere",
      "font-family:" + theme.fontDisplay,
      "font-size:" + (size === "dialog" ? "clamp(22px,3.4vw,28px)" : "clamp(24px,4vw,32px)"),
      "font-weight:" + (split < 0 ? "600" : "300"),
      "letter-spacing:" + (split < 0 ? "-.015em" : "-.022em"),
      "line-height:1.12", "color:" + theme.ink, "text-wrap:balance"
    ]);
    if (split < 0) {
      title.textContent = value;
      return title;
    }
    title.textContent = value.slice(0, split + 1);
    const strong = doc.createElement("span");
    strong.textContent = value.slice(split + 1);
    strong.style.cssText = globalThis.purestateCurtainCss(["font-weight:600", "letter-spacing:-.015em"]);
    title.appendChild(strong);
    return title;
  };

  globalThis.purestateCurtainText = function (doc, theme, text, variant) {
    if (variant === "list") {
      const list = doc.createElement("ul");
      list.style.cssText = globalThis.purestateCurtainCss([
        "margin:12px 0 0 0", "padding:0", "list-style:none", "text-align:left",
        "max-width:100%", "font-size:15px", "line-height:1.6", "color:" + theme.soft
      ]);
      for (const entry of Array.isArray(text) ? text : []) {
        const item = doc.createElement("li");
        item.style.cssText = globalThis.purestateCurtainCss(["margin:0", "padding:0", "list-style:none"]);
        const dash = doc.createElement("span");
        dash.textContent = "– ";
        dash.style.cssText = globalThis.purestateCurtainCss(["color:" + theme.faint]);
        const words = doc.createElement("span");
        words.textContent = entry;
        item.appendChild(dash);
        item.appendChild(words);
        list.appendChild(item);
      }
      return list;
    }
    const rules = {
      label: ["margin:20px 0 0 0", "font-family:" + theme.fontMono, "font-size:12px", "letter-spacing:.16em", "text-transform:uppercase", "color:" + theme.faint],
      detail: ["margin:12px 0 0 0", "font-size:16px", "line-height:1.6", "color:" + theme.soft, "text-wrap:pretty"],
      small: ["margin:6px 0 0 0", "font-size:14px", "line-height:1.5", "color:" + theme.faint, "text-wrap:pretty"],
      sub: ["margin:16px 0 0 0", "font-size:15px", "font-weight:600", "color:" + theme.ink],
      meta: ["margin:4px 0 0 0", "font-family:" + theme.fontMono, "font-size:13px", "color:" + theme.faint],
      count: ["margin:14px 0 0 0", "font-family:" + theme.fontMono, "font-size:40px", "font-variant-numeric:tabular-nums", "color:" + theme.ink]
    };
    const element = doc.createElement("div");
    element.textContent = String(text == null ? "" : text);
    element.style.cssText = globalThis.purestateCurtainCss(
      (rules[variant] || rules.detail).concat(["max-width:100%", "visibility:visible"]));
    return element;
  };

  globalThis.purestateCurtainActions = function (doc) {
    const actions = doc.createElement("div");
    actions.style.cssText = globalThis.purestateCurtainCss([
      "display:flex", "flex-wrap:wrap", "gap:10px", "justify-content:center",
      "margin:24px 0 0 0", "max-width:100%", "visibility:visible"
    ]);
    return actions;
  };

  // primary: der sichere Weg (Zurueck). secondary: Nebenweg. waiting: noch
  // gesperrter Nebenweg (Reflexion), bleibt klickbar und traegt nur Deckkraft.
  globalThis.purestateCurtainButton = function (doc, theme, text, variant) {
    const primary = variant !== "secondary" && variant !== "waiting";
    const fill = primary ? theme.btn : "transparent";
    const ink = primary ? theme.btnInk : theme.ink;
    const edge = primary ? theme.btn : theme.lineStrong;
    const button = doc.createElement("button");
    button.type = "button";
    button.textContent = text;
    button.style.cssText = globalThis.purestateCurtainCss([
      "all:unset", "display:flex", "align-items:center", "justify-content:center",
      "box-sizing:border-box", "min-height:44px", "width:auto", "min-width:0", "max-width:100%",
      "margin:0", "padding:0 22px", "border:1px solid " + edge, "border-radius:4px",
      "background:" + fill, "color:" + ink, "font:600 15px " + theme.fontText,
      "line-height:1.2", "text-align:center", "text-transform:none", "letter-spacing:normal",
      "cursor:pointer", "pointer-events:auto", "position:relative", "z-index:1",
      "opacity:" + (variant === "waiting" ? ".55" : "1"),
      "visibility:visible", "transform:none", "clip-path:none",
      // EXT-A05: scrollIntoView({block:"nearest"}) aligns this button flush
      // with the scrolling curtain's edge (0px to spare). The needed scroll
      // offset is a fractional pixel value (from text layout) that the
      // browser rounds to the nearest integer scrollTop - when it rounds
      // down, the button lands a fraction of a pixel past the edge and the
      // 320x180 reachability fixture reports it unreachable. scroll-margin
      // gives scrollIntoView slack far bigger than any such rounding error.
      "scroll-margin:8px"
    ]);
    button.addEventListener("mouseenter", function () {
      button.style.setProperty("border-color", primary ? theme.btnHover : theme.accent, "important");
      button.style.setProperty(primary ? "background" : "color", primary ? theme.btnHover : theme.accent, "important");
    });
    button.addEventListener("mouseleave", function () {
      button.style.setProperty("border-color", edge, "important");
      button.style.setProperty(primary ? "background" : "color", primary ? fill : ink, "important");
    });
    globalThis.purestateOverlayFocusRing(button, theme.accent, theme.bg);
    return button;
  };

  globalThis.purestateCurtainPlaceholder = function (doc, theme, title, detail, extraRules) {
    const placeholder = doc.createElement("div");
    placeholder.style.cssText = globalThis.purestateCurtainCss([
      "display:flex", "align-items:center", "justify-content:center", "gap:10px",
      "box-sizing:border-box", "padding:12px 14px", "border:1px solid " + theme.line,
      "border-radius:4px", "background:" + theme.surface, "color:" + theme.soft,
      "font-family:" + theme.fontText, "text-align:left"
    ].concat(extraRules || []));
    placeholder.appendChild(globalThis.purestateCurtainBars(doc, theme, "xs"));
    const copy = doc.createElement("span");
    copy.style.cssText = globalThis.purestateCurtainCss(["display:block", "min-width:0"]);
    const heading = doc.createElement("span");
    heading.textContent = title;
    heading.style.cssText = globalThis.purestateCurtainCss([
      "display:block", "font-size:14px", "font-weight:600", "line-height:1.35", "color:" + theme.ink,
      "overflow-wrap:anywhere"
    ]);
    copy.appendChild(heading);
    if (detail) {
      const note = doc.createElement("span");
      note.textContent = detail;
      note.style.cssText = globalThis.purestateCurtainCss([
        "display:block", "margin-top:2px", "font-size:13px", "line-height:1.4", "color:" + theme.soft
      ]);
      copy.appendChild(note);
    }
    placeholder.appendChild(copy);
    placeholder.purestateTitle = heading;
    return placeholder;
  };

  // Full-page block overlay shared by every site. Idempotent per overlayId.
  // Aussehen aus dem Vorhang-Baukasten; hell oder dunkel nach dem Farbschema
  // der Seite, damit nachts kein weisser Vollbildvorhang aufblitzt.
  globalThis.purestateShowSearchOverlay = function (doc, overlayId, message) {
    const target = doc || document;
    if (!target.documentElement || target.getElementById(overlayId)) {
      return;
    }
    const theme = globalThis.purestateCurtainTheme(target);
    target.documentElement.style.setProperty("overflow", "hidden", "important");
    if (target.body) {
      target.body.style.setProperty("overflow", "hidden", "important");
    }
    const overlay = target.createElement("div");
    overlay.id = overlayId;
    overlay.setAttribute("role", "alertdialog");
    overlay.setAttribute("aria-live", "assertive");
    overlay.setAttribute("aria-label", "Purestate Blockhinweis");
    overlay.setAttribute("aria-labelledby", overlayId + "-title");
    overlay.setAttribute("tabindex", "-1");
    overlay.style.cssText = globalThis.purestateCurtainOverlayCss(theme);

    const column = globalThis.purestateCurtainColumn(target);
    column.appendChild(globalThis.purestateCurtainBars(target, theme, "lg"));
    column.appendChild(globalThis.purestateCurtainText(target, theme, "Purestate", "label"));
    column.appendChild(globalThis.purestateCurtainTitle(target, theme, overlayId + "-title", "Inhalt blockiert", "curtain"));
    column.appendChild(globalThis.purestateCurtainText(target, theme, message, "detail"));

    // One safe way out instead of a dead end: navigate away from the blocked
    // page. Never a bypass - it only ever leaves the page. Die Knopfregeln aus
    // dem Baukasten halten das globale Button-CSS der Seite fern.
    const back = globalThis.purestateCurtainButton(target, theme, "Zurück", "primary");
    back.setAttribute("aria-label", "Zurück zur vorherigen Seite");
    const leaveBlockedPage = function (event) {
      if (event) {
        event.preventDefault();
        event.stopPropagation();
      }
      try {
        const view = target.defaultView || (typeof window !== "undefined" ? window : null);
        if (!view) {
          return;
        }
        // history.back() alone is unreliable on SPA sites (Reddit/pixiv): the
        // client router can re-render the same blocked route, so the overlay
        // just reappears and it feels like "nothing happened". Going to the
        // origin root is a guaranteed, always-safe exit that never lands back
        // on a blocked page.
        const origin = view.location.origin;
        if (view.history && view.history.length > 1) {
          view.history.back();
          view.setTimeout(function () {
            try {
              if (view.location.origin === origin) {
                view.location.assign(origin + "/");
              }
            } catch {
            }
          }, 250);
        } else {
          view.location.assign(view.location.origin + "/");
        }
      } catch {
      }
    };
    back.addEventListener("click", leaveBlockedPage, true);
    const actions = globalThis.purestateCurtainActions(target);
    actions.appendChild(back);
    column.appendChild(actions);

    overlay.appendChild(column);
    // Prefer <body> so the overlay is part of the accessibility tree (and still
    // visible: its own visibility:visible overrides a blanked body). Fall back to
    // <html> when the body is not parsed yet (document_start).
    (target.body || target.documentElement).appendChild(overlay);
    globalThis.purestateHoldOverlayFocus(target, overlay, back);
  };

  globalThis.purestateHideSearchOverlay = function (doc, overlayId, styleId) {
    const target = doc || document;
    if (!target.getElementById) {
      return;
    }
    if (styleId) {
      globalThis.purestateRemoveInstantHide(target, styleId);
    }
    const overlay = target.getElementById(overlayId);
    // Auch ohne gefundenen Vorhang: hat die Seite ihn selbst entfernt, gibt
    // dieser Aufruf den inert-Zustand frei.
    globalThis.purestateReleaseOverlayFocus(overlay);
    if (overlay) {
      overlay.remove();
      if (target.documentElement) {
        target.documentElement.style.removeProperty("overflow");
      }
      if (target.body) {
        target.body.style.removeProperty("overflow");
      }
    }
  };

  // --- Selector canary --------------------------------------------------------
  //
  // Every site module's protection is anchored on live-verified DOM selectors.
  // When a site redesign removes those anchors, the module silently degrades -
  // the worst failure mode for this product. The canary turns that silence into
  // a diagnostic signal: each module reports when it is ON the page where its
  // enforcement controls must exist but cannot find them. Failures flow via the
  // background worker to the native host, which logs them locally for
  // Get-Diagnostics.ps1. Diagnostics only - a canary bug must never affect
  // enforcement, so every entry point swallows its own errors.

  const CANARY_MESSAGE_TYPE = "purestate.canaryMiss";
  const BROWSER_RULES_GET = "purestate.getBrowserRules";
  const CANARY_REPORT_MIN_INTERVAL_MS = 60 * 60 * 1000;
  const canaryStreaks = new Map();
  const canaryLastReport = new Map();

  // Report one canary failure (throttled per site:check per hour). Safe to call
  // outside an extension context (browser fixtures, Node tests): it no-ops when
  // chrome.runtime.sendMessage is unavailable.
  globalThis.purestateCanaryReport = function (site, check) {
    try {
      const key = site + ":" + check;
      const now = Date.now();
      if (now - (canaryLastReport.get(key) || 0) < CANARY_REPORT_MIN_INTERVAL_MS) {
        return false;
      }
      canaryLastReport.set(key, now);
      if (typeof chrome !== "undefined" && chrome.runtime && typeof chrome.runtime.sendMessage === "function") {
        chrome.runtime.sendMessage({ type: CANARY_MESSAGE_TYPE, site, check }, () => {
          // Touch lastError so a missing background worker never logs an
          // unchecked-error warning; the report is best-effort anyway.
          void (chrome.runtime && chrome.runtime.lastError);
        });
      }
      return true;
    } catch {
      return false;
    }
  };

  // Streak-based observation, called once per module tick (or per self-heal
  // iframe cycle). Only a run of `threshold` consecutive misses while the
  // context is active reports a failure - a page that is still rendering, or a
  // single flaky tick, never fires. Leaving the context or finding the anchor
  // resets the streak.
  globalThis.purestateCanaryObserve = function (site, check, contextActive, found, threshold) {
    try {
      const key = site + ":" + check;
      if (!contextActive || found) {
        canaryStreaks.set(key, 0);
        return false;
      }
      const streak = (canaryStreaks.get(key) || 0) + 1;
      canaryStreaks.set(key, streak);
      if (streak === (threshold || 15)) {
        return globalThis.purestateCanaryReport(site, check);
      }
      return false;
    } catch {
      return false;
    }
  };

  // Ein Selbstheilungs-Rahmen sagt nur etwas ueber Auswahlregeln, wenn er
  // wirklich die Einstellungsseite zeigt. Ein abgewiesener Rahmen (Instagram
  // sendet X-Frame-Options: DENY) hat kein lesbares Dokument, und abgemeldet
  // leitet die Seite auf die Anmeldung um. Beides als Bruch zu zaehlen, liess
  // den Guard die ganze Seite 24 Stunden sperren (live 2026-09-18).
  globalThis.purestateSettingsFrameDocument = function (frame, settingsPath) {
    try {
      const doc = frame && frame.contentDocument;
      const pathname = doc && doc.location ? String(doc.location.pathname || "").toLowerCase() : "";
      return pathname.startsWith(settingsPath) ? doc : null;
    } catch {
      return null;
    }
  };

  globalThis.purestateIsSiteProtectionEnabled = function (site) {
    const siteKey = String(site || "").trim().toLowerCase();
    return new Promise((resolve) => {
      if (!siteKey || typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.id) {
        resolve(true);
        return;
      }

      try {
        chrome.runtime.sendMessage({ type: BROWSER_RULES_GET, site: siteKey }, (response) => {
          try {
            if (chrome.runtime.lastError) {
              resolve(true);
              return;
            }
            const siteProtection = response && response.rules && response.rules.siteProtection;
            resolve(!(siteProtection && siteProtection[siteKey] === false));
          } catch {
            resolve(true);
          }
        });
      } catch {
        resolve(true);
      }
    });
  };

  globalThis.purestateRunWhenSiteProtectionEnabled = function (site, start) {
    try {
      globalThis.purestateIsSiteProtectionEnabled(site).then((enabled) => {
        if (enabled && typeof start === "function") {
          try {
            start();
          } catch {
          }
        }
      });
    } catch {
      if (typeof start === "function") {
        try {
          start();
        } catch {
        }
      }
    }
  };
})();
