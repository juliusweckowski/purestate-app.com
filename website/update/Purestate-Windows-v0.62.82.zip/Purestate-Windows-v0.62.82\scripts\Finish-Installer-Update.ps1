param(
    [string]$PendingFile = "",
    [string]$DestinationFile = "",
    [string]$ExpectedSha256 = "",
    [string]$TokenFile = "",
    [string]$UpdateToken = "",
    [int]$WaitForProcessId = 0,
    [switch]$SelfTest
)

$ErrorActionPreference = "Stop"

if ($SelfTest) {
    Write-Output "Self-test OK."
    exit 0
}

if ([string]::IsNullOrWhiteSpace($PendingFile) -or
    [string]::IsNullOrWhiteSpace($DestinationFile) -or
    [string]::IsNullOrWhiteSpace($ExpectedSha256) -or
    [string]::IsNullOrWhiteSpace($TokenFile) -or
    [string]::IsNullOrWhiteSpace($UpdateToken)) {
    exit 2
}

function Test-CurrentUpdate {
    try {
        return (Test-Path -LiteralPath $TokenFile -PathType Leaf) -and
            ((Get-Content -Raw -LiteralPath $TokenFile).Trim() -eq $UpdateToken)
    }
    catch {
        return $false
    }
}

function Stop-StaleUpdate {
    try {
        if (Test-Path -LiteralPath $PendingFile -PathType Leaf) {
            Remove-Item -LiteralPath $PendingFile -Force
        }
    }
    catch {
    }

    exit 5
}

if (-not (Test-CurrentUpdate)) {
    Stop-StaleUpdate
}

for ($attempt = 0; $attempt -lt 480; $attempt++) {
    if (-not (Test-CurrentUpdate)) {
        Stop-StaleUpdate
    }

    if ($WaitForProcessId -le 0 -or -not (Get-Process -Id $WaitForProcessId -ErrorAction SilentlyContinue)) {
        break
    }

    Start-Sleep -Milliseconds 250
}

for ($attempt = 0; $attempt -lt 240; $attempt++) {
    try {
        if (-not (Test-CurrentUpdate)) {
            Stop-StaleUpdate
        }

        if (-not (Test-Path -LiteralPath $PendingFile -PathType Leaf)) {
            exit 3
        }

        $pendingHash = (Get-FileHash -LiteralPath $PendingFile -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($pendingHash -ne $ExpectedSha256.ToLowerInvariant()) {
            exit 4
        }

        [System.IO.File]::Copy($PendingFile, $DestinationFile, $true)
        $destinationHash = (Get-FileHash -LiteralPath $DestinationFile -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($destinationHash -ne $ExpectedSha256.ToLowerInvariant()) {
            throw "Hash mismatch after installer replacement."
        }

        [System.IO.File]::Delete($PendingFile)
        if (Test-CurrentUpdate) {
            [System.IO.File]::Delete($TokenFile)
        }
        exit 0
    }
    catch {
        Start-Sleep -Milliseconds 250
    }
}

exit 1
