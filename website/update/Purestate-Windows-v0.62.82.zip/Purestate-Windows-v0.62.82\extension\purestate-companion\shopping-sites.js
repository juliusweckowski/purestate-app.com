"use strict";

// Purestate shopping site configuration.
//
// One entry per supported shop: hostnames plus checkout-route patterns for the
// checkout-delay overlay. Shops rename checkout routes frequently, so a
// generic fallback pattern applies on every configured shop in addition to
// the per-site patterns. Damping selectors stay heuristic (text-based) so a
// shop redesign degrades to "no damping" instead of hiding real content.

(function () {
  const SITES = [
    { key: "amazon", hosts: ["amazon.de", "amazon.com"], checkout: [/\/gp\/buy/i, /\/checkout/i, /\/cart\/smart-wagon/i, /buy\/addressselect/i] },
    { key: "ebay", hosts: ["ebay.de"], checkout: [/\/rgc\//i, /pay\.ebay/i, /\/rxo/i] },
    { key: "otto", hosts: ["otto.de"], checkout: [/\/order/i, /\/kasse/i, /\/checkout/i] },
    { key: "zalando", hosts: ["zalando.de"], checkout: [/\/checkout/i, /\/kasse/i] },
    { key: "kleinanzeigen", hosts: ["kleinanzeigen.de"], checkout: [/buy-now/i, /\/bezahlen/i, /\/checkout/i] },
    { key: "mediamarkt", hosts: ["mediamarkt.de"], checkout: [/\/checkout/i, /\/kasse/i] },
    { key: "saturn", hosts: ["saturn.de"], checkout: [/\/checkout/i, /\/kasse/i] },
    { key: "temu", hosts: ["temu.com"], checkout: [/\/bgn_verification/i, /\/checkout/i, /\/order/i, /bgt_/i] },
    { key: "shein", hosts: ["shein.com"], checkout: [/\/checkout/i, /\/pay\//i, /\/order/i] },
    { key: "aliexpress", hosts: ["aliexpress.com"], checkout: [/\/p\/trade/i, /\/checkout/i, /confirm_order/i] },
    { key: "wish", hosts: ["wish.com"], checkout: [/\/cart/i, /\/checkout/i, /\/payment/i] },

    // Preisvergleichsportale. Die Inhaltserkennung sieht sie nicht: sie haben
    // keinen Warenkorb, oft kein Produkt-Markup (geizhals.de liefert gar
    // keins aus) und verlinken nur weiter. Fuers Stoebern sind sie trotzdem
    // die reinste Form - deshalb hier als kurze, stabile Liste. Ohne Kassen-
    // routen: gekauft wird auf dem Zielshop, nicht hier.
    { key: "idealo", hosts: ["idealo.de", "idealo.at"], checkout: [] },
    { key: "geizhals", hosts: ["geizhals.de", "geizhals.at", "geizhals.eu"], checkout: [] },
    { key: "billiger", hosts: ["billiger.de"], checkout: [] },
    { key: "guenstiger", hosts: ["guenstiger.de"], checkout: [] },
    { key: "preisvergleich", hosts: ["preisvergleich.de"], checkout: [] }
  ];

  const GENERIC_CHECKOUT = /(checkout|kasse|payment|bezahlen|order\/confirm|purchase)/i;

  // Plattformen sind keine Shops. Spiegel von SOCIAL_PLATFORM_DOMAINS in
  // social-media-content.js, ein Test haelt beide gleich: eine Domain gehoert
  // genau einem Bereich. Ohne diese Ausnahme reicht auf einer Plattform eine
  // einzige Seite mit Preis und Kaufen-Knopf (Produktregal, Werbung), und die
  // Inhaltserkennung merkt sich den ganzen Host 30 Tage lang als Shop. Live
  // gefunden am 2026-10-06: YouTube wurde so zum "gemerkten Shop", das Zuschauen
  // zaehlte als Shopping-Zeit, und Zeitlimit wie Sperrzeit des Shoppings legten
  // den Vorhang ueber YouTube, obwohl das Social-Media-Limit noch Zeit hatte.
  // FEST IM CODE wie NEVER_BLOCK_HOSTS und HELP_HOSTS: ausgenommen wird nur die
  // Inhaltserkennung; gepflegte und selbst eingetragene Shops gewinnen weiter.
  const NOT_SHOP_HOSTS = [
    "x.com", "twitter.com", "instagram.com", "tiktok.com",
    "pinterest.com", "pinterest.de", "pinterest.at", "pinterest.ch", "pinterest.fr",
    "pinterest.it", "pinterest.es", "pinterest.co.uk", "pinterest.ca",
    "pinterest.com.au", "pinterest.com.mx", "pinterest.jp", "pinterest.se",
    "tumblr.com", "bsky.app", "reddit.com", "youtube.com", "youtu.be",
    "netflix.com", "disneyplus.com", "primevideo.com", "max.com", "hbomax.com",
    "paramountplus.com", "tv.apple.com", "crunchyroll.com", "twitch.tv", "joyn.de",
    "plus.rtl.de", "dazn.com", "wowtv.de"
  ];

  // Stimulus-damping text heuristic: countdowns, scarcity claims, event-sale
  // banners and percent-off shouting. Applied only to small text elements,
  // never to product lists or main containers.
  // Live gefunden (2026-08-09, obi.de/angebote): der Countdown steht in
  // Geschwister-Spans, `textContent` klebt sie ohne Leerzeichen zusammen
  // ("Nur noch01Tag07Std"), optisch trennt sie nur CSS. Deshalb `\s*` statt
  // eines festen Leerzeichens vor der Zahl - eine Ziffer muss weiter folgen,
  // sonst faengt das Muster "nur nochmal nachsehen".
  // Die Wortstellung wechselt je Shop: obi.de schreibt "20 % Rabatt",
  // bergfreunde.de "Rabatt 40%" und "Rabattbis 20%" - beide Richtungen
  // gemessen am 2026-08-09. "sale" braucht Wortgrenzen, sonst verschwindet
  // die Marke "Salewa" von derselben Seite.
  const DAMPING_TEXT = /(nur noch\s*\d+|blitzangebot|befristetes angebot|nur f(?:ue|ü)r kurze zeit|deal des tages|blitzdeal|angebot endet|sale endet|spare\s*\d+\s*%|du sparst\s*\d+|rabatt\s*(?:bis\s*)?\d+\s*%|\d+\s*%\s*gespart|endet in|black friday|cyber monday|flash sale|\bsale\b|\d+\s*%\s*(rabatt|off)|\d+\s*%\s*[\wäöüß]*aktion|super\s+deals?|deals? des monats|jetzt\s+[\wäöüß]+\s+sichern|f(?:ue|ü)rs sparen|bald ausverkauft|fast ausverkauft|nur heute)/i;

  function normalizeShopHost(hostname) {
    return String(hostname || "").toLowerCase().replace(/^www\./, "");
  }

  function findShoppingSite(hostname) {
    const host = normalizeShopHost(hostname);
    for (const site of SITES) {
      for (const base of site.hosts) {
        if (host === base || host.endsWith("." + base)) {
          return site;
        }
      }
    }
    return null;
  }

  function notShopHost(hostname) {
    const host = normalizeShopHost(hostname);
    if (!host) {
      return false;
    }
    for (const entry of NOT_SHOP_HOSTS) {
      // Suffix-Semantik: exakt oder Unterdomain. Nie Teilzeichenkette, sonst
      // waere "youtube.com.shop.example" eine Plattform.
      if (host === entry || host.endsWith("." + entry)) {
        return true;
      }
    }
    return false;
  }

  // Dynamic shops from the rule pack (custom-shopping-domains.txt via the
  // native host) activate the module like a fixed site, but only the generic
  // checkout pattern applies - they have no curated per-shop routes.
  function shoppingHostMatches(hostname, extraDomains) {
    if (findShoppingSite(hostname)) {
      return true;
    }
    const host = normalizeShopHost(hostname);
    if (!host) {
      return false;
    }
    for (const value of Array.isArray(extraDomains) ? extraDomains : []) {
      const base = normalizeShopHost(value);
      if (base && (host === base || host.endsWith("." + base))) {
        return true;
      }
    }
    return false;
  }

  function shoppingCheckoutMatches(urlString, extraDomains) {
    let url;
    try {
      url = new URL(urlString);
    } catch {
      return false;
    }
    const probe = (url.pathname || "/") + (url.search || "");
    const site = findShoppingSite(url.hostname);
    if (!site) {
      return shoppingHostMatches(url.hostname, extraDomains) && GENERIC_CHECKOUT.test(probe);
    }
    for (const pattern of site.checkout) {
      if (pattern.test(probe) || pattern.test(url.hostname)) {
        return true;
      }
    }
    return GENERIC_CHECKOUT.test(probe);
  }

  globalThis.purestateShoppingSites = function () {
    return SITES.slice();
  };
  globalThis.purestateFindShoppingSite = findShoppingSite;
  globalThis.purestateShoppingNotShopHost = notShopHost;
  globalThis.purestateShoppingNotShopHosts = function () {
    return NOT_SHOP_HOSTS.slice();
  };
  globalThis.purestateShoppingHostMatches = shoppingHostMatches;
  globalThis.purestateShoppingCheckoutMatches = shoppingCheckoutMatches;
  globalThis.purestateShoppingGenericCheckout = GENERIC_CHECKOUT;
  globalThis.purestateShoppingDampingText = DAMPING_TEXT;
})();
