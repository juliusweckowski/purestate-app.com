using System;
using System.IO;
using System.Text;

namespace Purestate.Native
{
    internal static partial class Support
    {
        public static string BuildDomainReport(string input)
        {
            string domain = NormalizeDomain(input);
            StringBuilder report = new StringBuilder();
            report.AppendLine("Domain-Test");
            report.AppendLine("Eingabe: " + (input ?? string.Empty));
            report.AppendLine("Domain: " + domain);

            if (!IsValidDomain(domain))
            {
                report.AppendLine("Ergebnis: keine gueltige Domain.");
                return MaskUserPaths(report.ToString());
            }

            bool inLists = IsDomainInLists(domain);
            bool isAllowed = IsDomainAllowed(domain);
            bool inHosts = IsDomainInHostsBlock(domain);
            AppConfig config = LoadConfig();

            report.AppendLine("In Blocklisten: " + YesNo(inLists));
            report.AppendLine("In Allowlist: " + YesNo(isAllowed));
            report.AppendLine("In aktiver Hosts-Sperre: " + YesNo(inHosts));
            report.AppendLine("Lokale Sperrliste eingeschaltet: " + YesNo(config.HostsEnabled));
            report.AppendLine("Familien-DNS eingeschaltet: " + YesNo(config.FamilyDnsEnabled));
            report.AppendLine("DNS-Profil: " + DnsProfileLabel(config.DnsProfile));
            report.AppendLine("Browser-Richtlinien eingeschaltet: " + YesNo(config.BrowserPoliciesEnabled));

            if (isAllowed && inLists)
            {
                report.AppendLine("Bewertung: Konflikt. Die Domain ist gelistet, aber per Allowlist lokal freigegeben.");
            }
            else if (isAllowed)
            {
                report.AppendLine("Bewertung: Lokal freigegeben. Familien-DNS kann sie trotzdem blockieren.");
            }
            else if (inHosts)
            {
                report.AppendLine("Bewertung: Diese Domain ist lokal gesperrt.");
            }
            else if (inLists && config.HostsEnabled)
            {
                report.AppendLine("Bewertung: Diese Domain ist gelistet, die Sperre sollte nach Aktualisieren/Aktivieren greifen.");
            }
            else if (config.FamilyDnsEnabled)
            {
                report.AppendLine("Bewertung: Nicht lokal gelistet. Familien-DNS kann sie trotzdem blockieren, wenn der Anbieter sie erkennt.");
            }
            else
            {
                report.AppendLine("Bewertung: Nicht gesperrt. Fuege sie ueber die eigene Liste hinzu.");
            }

            return MaskUserPaths(report.ToString());
        }

        public static string BuildProtectionTestReport()
        {
            AppConfig config = LoadConfig();
            bool shouldProtect = ProtectionShouldBeActive(config);
            bool configExists = SafeFileExists(ConfigPath);
            bool service = ServiceRunning();
            bool hosts = HostsActive();
            bool dns = FamilyDnsActive();
            bool browser = BrowserPoliciesActive();
            bool browserHardening = BrowserHardeningActive();
            bool browserProxyHardening = BrowserProxyHardeningActive();
            bool mixedSite = MixedSitePoliciesActive();
            string proxyServer;
            bool proxyEnabled = WindowsProxyEnabled(out proxyServer);
            int bypassFirewallRules = CountBypassFirewallRules();
            int unsupportedBrowserRules = CountUnsupportedBrowserFirewallRules();
            bool watchdog = WatchdogTaskRegistered();
            int domains = CountDomains();
            int allowDomains = CountExistingAllowDomains();
            int allowConflicts = CountAllowConflictingDomains();
            int mixedSitePatterns = CountMixedSiteUrlPatterns();
            string[] samples = ReadSampleBlockDomains(5);
            System.Collections.Generic.List<string> problems = new System.Collections.Generic.List<string>();
            System.Collections.Generic.List<string> notes = new System.Collections.Generic.List<string>();

            StringBuilder report = new StringBuilder();
            report.AppendLine("Purestate Schutztest");
            report.AppendLine("Version: " + AppVersion);
            report.AppendLine("Zeitpunkt: " + DateTime.Now.ToString("s"));
            report.AppendLine("Dieser Test nimmt keine Aenderungen am System vor.");
            report.AppendLine();

            report.AppendLine("Konfiguration:");
            AppendProtectionCheck(report, problems, "Konfiguration vorhanden", configExists, "Konfiguration fehlt.");
            AppendProtectionCheck(report, problems, "Passwort eingerichtet", config.Password != null, "Passwort ist nicht eingerichtet.");
            report.AppendLine("- Passwort-Hinweis vorhanden: " + YesNo(!string.IsNullOrEmpty(config.PasswordHint)));
            report.AppendLine("- Schutz laut Konfiguration: " + (config.ProtectionEnabled ? "aktiv" : "pausiert"));
            report.AppendLine("- Schutz soll jetzt aktiv sein: " + YesNo(shouldProtect));
            report.AppendLine("- Pause: " + PauseDescription(config));
            report.AppendLine("- Zeitplan: " + ScheduleDescription(config));
            report.AppendLine("- Lokale Sperrliste eingeschaltet: " + YesNo(config.HostsEnabled));
            report.AppendLine("- Familien-DNS eingeschaltet: " + YesNo(config.FamilyDnsEnabled));
            report.AppendLine("- DNS-Profil: " + DnsProfileLabel(config.DnsProfile));
            report.AppendLine("- Browser-Richtlinien eingeschaltet: " + YesNo(config.BrowserPoliciesEnabled));
            report.AppendLine("- Umgehungsschutz eingeschaltet: " + YesNo(config.BypassBlockingEnabled));
            report.AppendLine("- Nicht unterstuetzte Browser blockieren: " + YesNo(config.UnsupportedBrowserBlockingEnabled));
            report.AppendLine("- Manipulationsschutz eingeschaltet: " + YesNo(config.TamperProtectionEnabled));
            report.AppendLine("- Sperrmodus eingeschaltet: " + YesNo(config.LockdownModeEnabled));
            report.AppendLine("- Abkuehlzeit vor Pause: " + YesNo(config.PauseCooldownEnabled));
            report.AppendLine("- URL-Regeln fuer gemischte Webseiten: " + mixedSitePatterns);
            report.AppendLine("- Erwachsene URL-Begriffe: " + CountAdultUrlKeywords());
            report.AppendLine();

            report.AppendLine("Technische Pruefungen:");
            AppendProtectionCheck(report, problems, "Dienst laeuft", !shouldProtect || service, "Schutzdienst laeuft nicht.");
            AppendProtectionCheck(report, problems, "Watchdog eingerichtet", watchdog, "Watchdog-Aufgabe fehlt.");
            // Befund #5: die Paketpruefung fragt nach den Dateien auf der
            // Platte (CountDomainFileEntries, unabhaengig vom Schutzbereich),
            // nicht nach "domains" - das zeigt nur, was gerade aktiv ist.
            AppendProtectionCheck(report, problems, "Blockliste geladen", CountDomainFileEntries() >= 250, "Blockliste ist leer oder zu klein.");
            // PKG-002: je Quelle pruefen, nicht auf die Summe - sonst deckt
            // eine grosse Quelle den Totalverlust einer anderen zu.
            AppendProtectionCheck(report, problems, "URL-Regeln geladen",
                CountMixedSiteUrlPatternFileEntries() >= MinMixedSiteUrlPatternFileEntries,
                "URL-Regeln fuer gemischte Webseiten fehlen oder sind zu klein.");
            AppendProtectionCheck(report, problems, "Erwachsene URL-Begriffe geladen",
                CountAdultUrlKeywords() >= MinAdultUrlKeywordEntries,
                "Die Stichwortdatei fuer Erwachsenen-URLs fehlt oder ist zu klein.");
            AppendProtectionCheck(report, problems, "NSFW-Subreddits geladen",
                CountNsfwSubreddits() >= MinNsfwSubredditEntries,
                "Die Liste der NSFW-Subreddits fehlt oder ist zu klein.");
            AppendProtectionCheck(report, problems, "Allowlist ohne Konflikte", allowConflicts == 0, "Allowlist enthaelt Domains aus der Blockliste.");
            AppendProtectionCheck(report, problems, "Sperrmodus aktiv", !shouldProtect || config.LockdownModeEnabled, "Sperrmodus ist nicht aktiv.");
            report.AppendLine("- Umgehungsschutz-Regeln: " + bypassFirewallRules);
            report.AppendLine("- Browser-Block-Regeln: " + unsupportedBrowserRules);
            report.AppendLine("- Windows-Proxy aktiv: " + YesNo(proxyEnabled));

            int videoGamesEnabledTargets;
            int videoGamesTotalTargets = 0;
            bool videoGamesTargetsReadable = true;
            try
            {
                videoGamesTotalTargets = CountVideoGameTargets(out videoGamesEnabledTargets);
            }
            catch (Exception)
            {
                videoGamesEnabledTargets = 0;
                videoGamesTargetsReadable = false;
            }
            report.AppendLine("- Videospiel-Schutz: " + VideoGamesStatusLabel(config));
            report.AppendLine("- Videospiel-Ziele konfiguriert: " + videoGamesTotalTargets + " (aktiv: " + videoGamesEnabledTargets + ")");
            if (config.VideoGamesProtectionEnabled)
            {
                AppendProtectionCheck(report, problems, "Videospiel-Zielliste lesbar", videoGamesTargetsReadable, "Videospiel-Zielliste ist nicht lesbar.");
                AppendProtectionCheck(report, problems, "Videospiel-Durchsetzung (Dienst laeuft)", service, "Videospiel-Schutz ist aktiv, aber der Schutzdienst laeuft nicht.");
                if (videoGamesTargetsReadable && videoGamesEnabledTargets == 0)
                {
                    notes.Add("Videospiel-Schutz ist aktiv, aber es sind keine aktiven Spielziele eingetragen.");
                }
            }

            if (shouldProtect && config.HostsEnabled)
            {
                AppendProtectionCheck(report, problems, "Hosts-Sperre aktiv", hosts, "Lokale Hosts-Sperre ist nicht aktiv.");
            }
            else
            {
                report.AppendLine("- Hosts-Sperre aktiv: " + YesNo(hosts) + " (nicht gefordert)");
            }

            if (shouldProtect && config.FamilyDnsEnabled)
            {
                AppendProtectionCheck(report, problems, "Familien-DNS aktiv", dns, "Familien-DNS ist nicht aktiv.");
            }
            else
            {
                report.AppendLine("- Familien-DNS aktiv: " + YesNo(dns) + " (nicht gefordert)");
            }

            if (shouldProtect && config.BrowserPoliciesEnabled)
            {
                AppendProtectionCheck(report, problems, "Browser-Richtlinien aktiv", browser, "Browser-Richtlinien sind nicht aktiv.");
                // Befund #5 / Spec 2.4: Get-MixedSiteUrlPatterns liefert ohne
                // den Bereich Erwachseneninhalte gar keine Muster mehr - ohne
                // den Bereich ist "nicht aktiv" also der Sollzustand, kein Fund.
                AppendProtectionCheck(report, problems, "Gemischte Webseiten geschuetzt", !config.AdultContentProtectionEnabled || mixedSite, "URL-Regeln fuer gemischte Webseiten sind nicht aktiv.");
                AppendProtectionCheck(report, problems, "Browser-Umgehungsschutz aktiv", browserHardening, "Browser-Umgehungsschutz ist nicht vollstaendig aktiv.");
                AppendProtectionCheck(report, problems, "Browser-Proxy gehaertet", browserProxyHardening, "Browser-Proxy-Schutz ist nicht aktiv.");
            }
            else
            {
                report.AppendLine("- Browser-Richtlinien aktiv: " + YesNo(browser) + " (nicht gefordert)");
                report.AppendLine("- Gemischte Webseiten geschuetzt: " + YesNo(mixedSite) + " (nicht gefordert)");
                report.AppendLine("- Browser-Umgehungsschutz aktiv: " + YesNo(browserHardening) + " (nicht gefordert)");
                report.AppendLine("- Browser-Proxy gehaertet: " + YesNo(browserProxyHardening) + " (nicht gefordert)");
            }

            if (shouldProtect && config.TamperProtectionEnabled)
            {
                AppendProtectionCheck(report, problems, "Windows-Proxy aus", !proxyEnabled, "Windows-Proxy oder PAC-Skript ist aktiv.");
            }
            else
            {
                report.AppendLine("- Windows-Proxy aus: " + YesNo(!proxyEnabled) + " (nicht gefordert)");
            }

            if (!shouldProtect)
            {
                notes.Add("Der Schutz ist pausiert. Der Test bewertet dann nur, ob Komponenten vorhanden sind.");
            }

            report.AppendLine();
            report.AppendLine("Beispielpruefungen aus der lokalen Sperrliste:");
            if (samples.Length == 0)
            {
                report.AppendLine("- Keine Beispieldomains gefunden.");
                problems.Add("Keine Beispieldomains fuer den Schutztest gefunden.");
            }
            else
            {
                int missingHosts = 0;
                for (int i = 0; i < samples.Length; i++)
                {
                    string domain = samples[i];
                    bool inLists = IsDomainInLists(domain);
                    bool isAllowed = IsDomainAllowed(domain);
                    bool inHosts = IsDomainInHostsBlock(domain);
                    report.AppendLine("- Beispiel " + (i + 1) + ": " + domain + " | Liste " + YesNo(inLists) + " | Allowlist " + YesNo(isAllowed) + " | Hosts " + YesNo(inHosts));

                    if (isAllowed)
                    {
                        notes.Add(domain + " ist lokal freigegeben und wird deshalb nicht per Hosts-Datei blockiert.");
                    }
                    // Befund #5: die Beispiele kommen ueberwiegend aus
                    // adult-domains.txt (ReadSampleBlockDomains) - fehlt genau
                    // diese Liste zu Recht (Bereich Erwachseneninhalte aus,
                    // AdultHostsFollowArea), ist das kein Fund.
                    else if (shouldProtect && config.HostsEnabled && hosts && !inHosts && AdultDomainListActive(config))
                    {
                        missingHosts++;
                    }
                }

                if (missingHosts > 0)
                {
                    problems.Add(missingHosts + " Beispieldomains fehlen in der aktiven Hosts-Sperre.");
                }
            }

            report.AppendLine();
            report.AppendLine("Zusammenfassung:");
            report.AppendLine("- Domains in Listen: " + domains);
            report.AppendLine("- Domains in Allowlist: " + allowDomains);
            report.AppendLine("- Allowlist-Konflikte: " + allowConflicts);
            report.AppendLine("- Umgehungshinweise: " + CountBypassRiskIndicators());
            report.AppendLine("- Browser-Haertung:");
            report.AppendLine(BrowserPolicySummary());
            report.AppendLine();

            if (problems.Count == 0)
            {
                report.AppendLine("Status: OK. Die geprueften Komponenten sehen plausibel aus.");
            }
            else
            {
                report.AppendLine("Status: Aktion empfohlen.");
                foreach (string problem in problems)
                {
                    report.AppendLine("- " + problem);
                }
            }

            if (notes.Count > 0)
            {
                report.AppendLine();
                report.AppendLine("Hinweise:");
                foreach (string note in UniqueStrings(notes))
                {
                    report.AppendLine("- " + note);
                }
            }

            report.AppendLine();
            report.AppendLine("Empfehlung:");
            if (problems.Count == 0)
            {
                report.AppendLine("- Den Schutztest nach Updates, neuen Browsern oder Netzwerktools erneut ausfuehren.");
            }
            else
            {
                report.AppendLine("- Reparieren ausfuehren und danach den Schutztest wiederholen.");
                report.AppendLine("- Bei Umgehungshinweisen den Umgehungscheck oeffnen.");
            }

            return MaskUserPaths(report.ToString());
        }

        public static string BuildRuleAuditReport()
        {
            RuleFileAudit adult = AuditRuleFile(Path.Combine(InstallDir, "rules", "adult-domains.txt"), "Haupt-Sperrliste");
            RuleFileAudit custom = AuditRuleFile(Path.Combine(InstallDir, "rules", "custom-domains.txt"), "Eigene Sperrliste");
            RuleFileAudit allow = AuditRuleFile(AllowDomainsPath(), "Allowlist");
            int mixedSitePatterns = CountMixedSiteUrlPatterns();
            int adultUrlKeywords = CountAdultUrlKeywords();
            int nsfwSubreddits = CountNsfwSubreddits();
            System.Collections.Generic.SortedSet<string> blockDomains = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            System.Collections.Generic.SortedSet<string> conflicts = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            System.Collections.Generic.SortedSet<string> crossDuplicates = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);

            AddDomainsToSet(blockDomains, adult.ValidDomains);
            foreach (string domain in custom.ValidDomains)
            {
                if (blockDomains.Contains(domain))
                {
                    crossDuplicates.Add(domain);
                }

                blockDomains.Add(domain);
            }

            foreach (string domain in allow.ValidDomains)
            {
                if (blockDomains.Contains(domain))
                {
                    conflicts.Add(domain);
                }
            }

            System.Collections.Generic.List<string> problems = new System.Collections.Generic.List<string>();
            AddRuleAuditProblems(problems, adult);
            AddRuleAuditProblems(problems, custom);
            AddRuleAuditProblems(problems, allow);
            if (mixedSitePatterns < 700) problems.Add("URL-Regeln fuer gemischte Webseiten fehlen oder sind zu klein.");
            if (adultUrlKeywords < 30) problems.Add("Erwachsene URL-Begriffe fehlen oder sind zu klein.");
            if (nsfwSubreddits < 60) problems.Add("Reddit-18+-Community-Liste fehlt oder ist zu klein.");
            if (crossDuplicates.Count > 0) problems.Add("Eigene Sperrliste enthaelt Domains, die schon in der Haupt-Sperrliste stehen.");
            if (conflicts.Count > 0) problems.Add("Allowlist enthaelt Domains, die gleichzeitig in einer Sperrliste stehen.");

            StringBuilder report = new StringBuilder();
            report.AppendLine("Purestate Regelcheck");
            report.AppendLine("Version: " + AppVersion);
            report.AppendLine("Zeitpunkt: " + DateTime.Now.ToString("s"));
            report.AppendLine("Dieser Check nimmt keine Aenderungen an den Listen vor.");
            report.AppendLine();

            AppendRuleAudit(report, adult);
            AppendRuleAudit(report, custom);
            AppendRuleAudit(report, allow);
            report.AppendLine("Gemischte Webseiten:");
            report.AppendLine("- URL-Regeln: " + mixedSitePatterns);
            report.AppendLine("- Erwachsene URL-Begriffe: " + adultUrlKeywords);
            report.AppendLine("- Reddit-18+-Communities: " + nsfwSubreddits);
            report.AppendLine("- Datei: " + MixedSiteUrlPatternsPath());
            report.AppendLine("- Begriffe: " + AdultUrlKeywordsPath());
            report.AppendLine("- Reddit-Liste: " + NsfwSubredditsPath());
            report.AppendLine();

            report.AppendLine("Uebergreifende Pruefungen:");
            report.AppendLine("- Domains in allen Sperrlisten zusammen: " + blockDomains.Count);
            report.AppendLine("- Eigene Domains schon in Hauptliste: " + crossDuplicates.Count);
            AppendLimitedValues(report, crossDuplicates, 10);
            report.AppendLine("- Allowlist-Konflikte mit Sperrlisten: " + conflicts.Count);
            AppendLimitedValues(report, conflicts, 10);
            report.AppendLine();

            report.AppendLine("Ergebnis:");
            if (problems.Count == 0)
            {
                report.AppendLine("Status: OK. Die Regeldateien sehen plausibel aus.");
            }
            else
            {
                report.AppendLine("Status: Pruefen empfohlen.");
                foreach (string problem in problems)
                {
                    report.AppendLine("- " + problem);
                }
            }

            report.AppendLine();
            report.AppendLine("Empfehlung:");
            if (problems.Count == 0)
            {
                report.AppendLine("- Nach groesseren Imports den Regelcheck erneut ausfuehren.");
            }
            else
            {
                report.AppendLine("- In der App Domains oder Allowlist oeffnen und dort Bereinigen nutzen.");
                report.AppendLine("- Konflikte bewusst entscheiden: Sperren oder lokal erlauben.");
                report.AppendLine("- Danach Schutztest oder Reparieren ausfuehren, damit aktive Regeln neu geschrieben werden.");
            }

            return MaskUserPaths(report.ToString());
        }

        // RPT-005: Untergrenze fuer die Manifestgroesse. Die ausgelieferte
        // Datei fuehrt ueber sechzig Eintraege; vierzig laesst Luft fuer eine
        // schlankere Zusammenstellung und faengt trotzdem jede Datei ab, die
        // abgeschnitten wurde oder nur halb gelesen werden konnte. Ein Test
        // haelt die Grenze gegen das echte Manifest, damit beide nicht
        // aufeinandertreffen.
        internal const int MinimumExpectedManifestFiles = 40;

        public static string BuildIntegrityReport()
        {
            IntegrityManifest manifest = LoadIntegrityManifest();

            // Drive the check from the build's integrity manifest so every
            // packaged file (including newer companion modules such as
            // TikTok/Pinterest/Instagram) is verified, instead of a
            // hand-maintained subset that silently drifts. Fall back to a fixed
            // core list only when no manifest is present (e.g. an old install).
            System.Collections.Generic.List<string> paths = new System.Collections.Generic.List<string>();
            if (manifest.Files.Count > 0)
            {
                foreach (string relative in manifest.Files.Keys)
                {
                    paths.Add(Path.Combine(InstallDir, relative));
                }
                paths.Sort(StringComparer.OrdinalIgnoreCase);
                string manifestSelf = Path.Combine(InstallDir, "PurestateManifest.txt");
                if (!paths.Exists(delegate (string candidate) { return string.Equals(candidate, manifestSelf, StringComparison.OrdinalIgnoreCase); }))
                {
                    paths.Add(manifestSelf);
                }
            }
            else
            {
                paths.AddRange(new[]
                {
                    Path.Combine(InstallDir, "Installieren.exe"),
                    Path.Combine(InstallDir, "Purestate.exe"),
                    Path.Combine(InstallDir, "PurestateUninstaller.exe"),
                    Path.Combine(InstallDir, "PurestateGuard.exe"),
                    Path.Combine(InstallDir, "PurestateNativeHost.exe"),
                    Path.Combine(InstallDir, "native-host", "com.purestate.companion.json"),
                    Path.Combine(InstallDir, "scripts", "Common.ps1"),
                    Path.Combine(InstallDir, "scripts", "Enforce-Protection.ps1"),
                    Path.Combine(InstallDir, "scripts", "Clear-Protection.ps1"),
                    Path.Combine(InstallDir, "scripts", "Watchdog.ps1"),
                    Path.Combine(InstallDir, "scripts", "Finish-Installer-Update.ps1"),
                    Path.Combine(InstallDir, "scripts", "Cancel-Installer-Updates.ps1"),
                    Path.Combine(InstallDir, "rules", "adult-domains.txt"),
                    Path.Combine(InstallDir, "rules", "custom-domains.txt"),
                    Path.Combine(InstallDir, "rules", "allow-domains.txt"),
                    Path.Combine(InstallDir, "rules", "mixed-site-url-patterns.txt"),
                    Path.Combine(InstallDir, "rules", "adult-url-keywords.txt"),
                    Path.Combine(InstallDir, "rules", "gambling-domains.txt"),
                    Path.Combine(InstallDir, "rules", "custom-gambling-domains.txt"),
                    Path.Combine(InstallDir, "rules", "gambling-url-keywords.txt"),
                    Path.Combine(InstallDir, "rules", "gambling-search-terms.txt"),
                    Path.Combine(InstallDir, "rules", "browser-companion-rules.txt"),
                    Path.Combine(InstallDir, "rules", "nsfw-subreddits.txt"),
                    Path.Combine(InstallDir, "rules", "bypass-app-keywords.txt"),
                    Path.Combine(InstallDir, "rules", "unsupported-browser-keywords.txt"),
                    Path.Combine(InstallDir, "extension", "purestate-companion", "manifest.json"),
                    Path.Combine(InstallDir, "extension", "purestate-companion", "background.js"),
                    Path.Combine(InstallDir, "extension", "purestate-companion", "content.js"),
                    Path.Combine(InstallDir, "extension", "purestate-companion", "x-content.js"),
                    Path.Combine(InstallDir, "extension", "purestate-companion", "bluesky-content.js"),
                    Path.Combine(InstallDir, "extension", "purestate-companion", "rules", "nsfw-subreddits.txt"),
                    Path.Combine(InstallDir, "extension", "purestate-companion", "README.txt"),
                    Path.Combine(InstallDir, "PurestateManifest.txt")
                });
            }

            System.Collections.Generic.List<string> problems = new System.Collections.Generic.List<string>();
            StringBuilder report = new StringBuilder();
            report.AppendLine("Purestate Integritaetscheck");
            report.AppendLine("Version: " + AppVersion);
            report.AppendLine("Zeitpunkt: " + DateTime.Now.ToString("s"));
            report.AppendLine("Installationsordner: " + InstallDir);
            report.AppendLine("Dieser Check liest nur Dateien und nimmt keine Aenderungen vor.");
            report.AppendLine();
            report.AppendLine("Manifest:");
            report.AppendLine("- Vorhanden: " + YesNo(manifest.Exists));
            report.AppendLine("- Version: " + (string.IsNullOrEmpty(manifest.AppVersion) ? "nicht eingetragen" : manifest.AppVersion));
            report.AppendLine("- Erwartete Dateien: " + manifest.Files.Count);
            if (!manifest.Exists)
            {
                problems.Add("Integritaetsmanifest fehlt.");
            }
            else if (!string.Equals(manifest.AppVersion, AppVersion, StringComparison.OrdinalIgnoreCase))
            {
                problems.Add("Integritaetsmanifest passt nicht zur App-Version.");
            }
            else if (manifest.Files.Count < MinimumExpectedManifestFiles)
            {
                // RPT-005: Der Check bestimmt seine Pruefliste AUS dem Manifest
                // - richtig so, eine handgepflegte Teilmenge driftet ab. Es
                // fehlte aber jede Untergrenze: enthielt das Manifest statt
                // ueber sechzig Eintraegen nur noch drei, wurden drei Dateien
                // geprueft, und wenn die stimmten, lautete das Fazit "Status:
                // OK. Die erwarteten Dateien passen zum Manifest." Eine
                // abgeschnittene oder halb gelesene Manifestdatei war von einer
                // kurzen nicht zu unterscheiden - und der Bericht sagte
                // ausgerechnet dann, alles sei in Ordnung.
                problems.Add("Integritaetsmanifest ist unvollstaendig: nur " + manifest.Files.Count +
                    " Eintraege, erwartet werden mindestens " + MinimumExpectedManifestFiles +
                    ". Der Check kann damit nicht aussagekraeftig sein.");
            }

            report.AppendLine();

            foreach (string path in paths)
            {
                AppendIntegrityFile(report, problems, path, manifest);
            }

            report.AppendLine("Zusatzpruefungen:");
            report.AppendLine("- Windows-App-Eintrag: " + YesNo(IsRegisteredInWindows()));
            report.AppendLine("- Watchdog-Aufgabe: " + YesNo(WatchdogTaskRegistered()));
            report.AppendLine("- Dienst laeuft: " + YesNo(ServiceRunning()));
            report.AppendLine("- Domains in Listen: " + CountDomains());
            report.AppendLine("- Domains in Allowlist: " + CountExistingAllowDomains());
            report.AppendLine();

            report.AppendLine("Ergebnis:");
            if (problems.Count == 0)
            {
                report.AppendLine("Status: OK. Die erwarteten Dateien passen zum Manifest.");
            }
            else
            {
                report.AppendLine("Status: Pruefen empfohlen.");
                foreach (string problem in problems)
                {
                    report.AppendLine("- " + problem);
                }
            }

            report.AppendLine();
            report.AppendLine("Empfehlung:");
            if (problems.Count == 0)
            {
                report.AppendLine("- Nach Updates oder manuellen Datei-Aenderungen erneut pruefen.");
            }
            else
            {
                report.AppendLine("- Installieren.exe erneut starten und Reparieren/Aktualisieren ausfuehren.");
                report.AppendLine("- Danach Schutztest und Integritaetscheck wiederholen.");
            }

            return MaskUserPaths(report.ToString());
        }

        public static string ReadRecentLogs(int maxLines)
        {
            StringBuilder result = new StringBuilder();
            AppendRecentLog(result, "Aktivitaet", ActivityLogPath, maxLines);
            result.AppendLine();
            AppendRecentLog(result, "Sicherheit", SecurityLogPath, maxLines);
            result.AppendLine();
            AppendRecentLog(result, "Dienst", ServiceLogPath, maxLines);
            return result.ToString();
        }

        public static string BuildBypassReport()
        {
            AppConfig config = LoadConfig();
            System.Collections.Generic.List<string> risks = new System.Collections.Generic.List<string>();
            string[] processes = FindRunningBypassProcesses();
            string[] adapters = FindBypassNetworkAdapters();
            string[] tools = FindInstalledBypassTools();
            string[] portableBrowsers = FindPortableBrowserHints();
            string[] unsupportedBrowsers = FindUnsupportedBrowserHints();
            string proxyServer;
            bool proxyEnabled = WindowsProxyEnabled(out proxyServer);
            int firewallRules = CountBypassFirewallRules();
            int browserFirewallRules = CountUnsupportedBrowserFirewallRules();

            if (processes.Length > 0) risks.Add("Laufende VPN/Tor/Proxy-Prozesse gefunden.");
            if (adapters.Length > 0) risks.Add("VPN- oder Tunnel-Netzwerkadapter gefunden.");
            if (tools.Length > 0) risks.Add("Bekannte Umgehungs-Tools sind installiert oder liegen in typischen Ordnern.");
            if (portableBrowsers.Length > 0) risks.Add("Portable Browser oder alternative Browser-Pakete gefunden.");
            if (unsupportedBrowsers.Length > 0) risks.Add("Nicht unterstuetzte Browser gefunden.");
            if (proxyEnabled) risks.Add("Windows-Proxy ist eingeschaltet.");
            if (!BrowserHardeningActive()) risks.Add("Browser-Umgehungsschutz ist nicht vollstaendig aktiv.");

            StringBuilder report = new StringBuilder();
            report.AppendLine("Purestate Umgehungscheck");
            report.AppendLine("Version: " + AppVersion);
            report.AppendLine("Zeitpunkt: " + DateTime.Now.ToString("s"));
            report.AppendLine("Status: " + (risks.Count == 0 ? "OK" : "Pruefen empfohlen"));
            report.AppendLine("Umgehungsschutz eingeschaltet: " + YesNo(config.BypassBlockingEnabled));
            report.AppendLine("Firewall-Regeln gegen Umgehung: " + firewallRules);
            report.AppendLine("Nicht unterstuetzte Browser blockieren: " + YesNo(config.UnsupportedBrowserBlockingEnabled));
            report.AppendLine("Firewall-Regeln gegen nicht unterstuetzte Browser: " + browserFirewallRules);
            report.AppendLine("Manipulationsschutz eingeschaltet: " + YesNo(config.TamperProtectionEnabled));
            report.AppendLine("Sperrmodus eingeschaltet: " + YesNo(config.LockdownModeEnabled));
            report.AppendLine("Abkuehlzeit vor Pause: " + YesNo(config.PauseCooldownEnabled));
            report.AppendLine();

            report.AppendLine("Gefundene Risiken:");
            if (risks.Count == 0)
            {
                report.AppendLine("- Keine typischen Umgehungshinweise erkannt.");
            }
            else
            {
                foreach (string risk in risks)
                {
                    report.AppendLine("- " + risk);
                }
            }

            report.AppendLine();
            AppendReportList(report, "Laufende Prozesse", processes, "Keine typischen Prozesse erkannt.");
            AppendReportList(report, "VPN-/Tunnel-Adapter", adapters, "Keine typischen Adapter erkannt.");
            AppendReportList(report, "Installierte Werkzeuge", tools, "Keine typischen Installationen gefunden.");
            AppendReportList(report, "Portable Browser Hinweise", portableBrowsers, "Keine typischen Dateien oder Ordner gefunden.");
            AppendReportList(report, "Nicht unterstuetzte Browser", unsupportedBrowsers, "Keine typischen nicht unterstuetzten Browser gefunden.");

            report.AppendLine("Windows-Proxy:");
            report.AppendLine("- Aktiv: " + YesNo(proxyEnabled));
            if (proxyEnabled && !string.IsNullOrEmpty(proxyServer))
            {
                report.AppendLine("- Server: " + proxyServer);
            }

            report.AppendLine();
            report.AppendLine("Browser-Schutz:");
            report.AppendLine("- Browser-Richtlinien aktiv: " + YesNo(BrowserPoliciesActive()));
            report.AppendLine("- Browser-Umgehungsschutz aktiv: " + YesNo(BrowserHardeningActive()));
            report.AppendLine("- Browser-Proxy gehaertet: " + YesNo(BrowserProxyHardeningActive()));
            report.AppendLine(BrowserPolicySummary());
            report.AppendLine();

            report.AppendLine("Empfehlungen:");
            if (risks.Count == 0)
            {
                report.AppendLine("- Regelmaessig erneut pruefen, besonders nach Browser- oder VPN-Installationen.");
            }
            else
            {
                report.AppendLine("- Normales Windows-Konto ohne Administrator-Rechte verwenden.");
                report.AppendLine("- Umgehungsschutz eingeschaltet lassen und Reparieren ausfuehren, damit Firewall-Regeln neu geschrieben werden.");
                report.AppendLine("- Nicht unterstuetzte Browser blockieren eingeschaltet lassen oder diese Browser entfernen.");
                report.AppendLine("- Manipulationsschutz eingeschaltet lassen und Reparieren ausfuehren, wenn ein Proxy aktiv ist.");
                report.AppendLine("- Tor, VPNs, Proxy-Tools und portable Browser entfernen, wenn sie nicht gebraucht werden.");
                report.AppendLine("- In Purestate die Browser-Richtlinien aktiv lassen und danach Reparieren ausfuehren.");
                report.AppendLine("- Router- oder Familienkontrollen als zweite Schutzschicht nutzen.");
            }

            return MaskUserPaths(report.ToString());
        }

        public static string BuildPackagePreflightReport(string packageDir)
        {
            string root = string.IsNullOrEmpty(packageDir) ? AppDomain.CurrentDomain.BaseDirectory : packageDir;
            try
            {
                root = Path.GetFullPath(root);
            }
            catch
            {
            }

            System.Collections.Generic.List<string> problems = new System.Collections.Generic.List<string>();
            System.Collections.Generic.List<string> notes = new System.Collections.Generic.List<string>();
            StringBuilder report = new StringBuilder();
            string systemDir = Environment.GetFolderPath(Environment.SpecialFolder.System);
            string installedVersion = ReadInstalledVersion();
            bool existingInstall = SafeFileExists(Path.Combine(InstallDir, "Purestate.exe")) || SafeFileExists(ConfigPath);

            report.AppendLine("Purestate Installationscheck");
            report.AppendLine("Version: " + AppVersion);
            report.AppendLine("Paketordner: " + root);
            report.AppendLine("Zielordner: " + InstallDir);
            report.AppendLine("Datenordner: " + DataDir);
            report.AppendLine("Dieser Check nimmt keine Aenderungen am System vor.");
            report.AppendLine();

            report.AppendLine("Windows:");
            AppendPreflightCheck(report, problems, "Administrator-Rechte", IsAdministrator(), "Installer laeuft nicht mit Administrator-Rechten.");
            AppendPreflightCheck(report, problems, "Windows-Systemordner", SafeDirectoryExists(systemDir), "Windows-Systemordner wurde nicht gefunden.");
            AppendPreflightCheck(report, problems, "PowerShell", SafeFileExists(PowerShellExecutablePath()), "PowerShell wurde nicht gefunden.");
            AppendPreflightCheck(report, problems, "Dienst-Werkzeug sc.exe", SafeFileExists(SystemToolPath("sc.exe")), "sc.exe wurde nicht gefunden.");
            AppendPreflightCheck(report, problems, "Aufgabenplanung schtasks.exe", SafeFileExists(SystemToolPath("schtasks.exe")), "schtasks.exe wurde nicht gefunden.");
            AppendPreflightCheck(report, problems, "DNS-Cache ipconfig.exe", SafeFileExists(SystemToolPath("ipconfig.exe")), "ipconfig.exe wurde nicht gefunden.");
            AppendPreflightCheck(report, problems, "Rechte-Werkzeug icacls.exe", SafeFileExists(SystemToolPath("icacls.exe")), "icacls.exe wurde nicht gefunden.");
            AppendPreflightCheck(report, problems, "DNS-Verwaltung in PowerShell", PowerShellCommandAvailable("Get-DnsClientServerAddress") && PowerShellCommandAvailable("Set-DnsClientServerAddress"), "PowerShell-DNS-Befehle fehlen. Familien-DNS kann dann nicht gesetzt werden.");
            AppendPreflightCheck(report, problems, "Firewall-Verwaltung in PowerShell", PowerShellCommandAvailable("Get-NetFirewallRule") && PowerShellCommandAvailable("New-NetFirewallRule"), "PowerShell-Firewall-Befehle fehlen. Umgehungstools koennen dann nicht per Firewall blockiert werden.");
            report.AppendLine("- .NET Runtime: " + Environment.Version);
            report.AppendLine();

            report.AppendLine("Paketdateien:");
            AppendPreflightCheck(report, problems, "Installieren.exe", FileExistsAndNotEmpty(Path.Combine(root, "Installieren.exe")), "Installieren.exe fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "Purestate.exe", FileExistsAndNotEmpty(Path.Combine(root, "Purestate.exe")), "Purestate.exe fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "PurestateUninstaller.exe", FileExistsAndNotEmpty(Path.Combine(root, "PurestateUninstaller.exe")), "PurestateUninstaller.exe fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "PurestateGuard.exe", FileExistsAndNotEmpty(Path.Combine(root, "PurestateGuard.exe")), "PurestateGuard.exe fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "PurestateNativeHost.exe", FileExistsAndNotEmpty(Path.Combine(root, "PurestateNativeHost.exe")), "Lokaler Companion-Host fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "native-host\\com.purestate.companion.json", FileExistsAndNotEmpty(Path.Combine(root, "native-host", "com.purestate.companion.json")), "Companion-Host-Manifest fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "PurestateManifest.txt", FileExistsAndNotEmpty(Path.Combine(root, "PurestateManifest.txt")), "Integritaetsmanifest fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "scripts\\Common.ps1", FileExistsAndNotEmpty(Path.Combine(root, "scripts", "Common.ps1")), "Common.ps1 fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "scripts\\Enforce-Protection.ps1", FileExistsAndNotEmpty(Path.Combine(root, "scripts", "Enforce-Protection.ps1")), "Enforce-Protection.ps1 fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "scripts\\Clear-Protection.ps1", FileExistsAndNotEmpty(Path.Combine(root, "scripts", "Clear-Protection.ps1")), "Clear-Protection.ps1 fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "scripts\\Watchdog.ps1", FileExistsAndNotEmpty(Path.Combine(root, "scripts", "Watchdog.ps1")), "Watchdog-Skript fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "scripts\\Finish-Installer-Update.ps1", FileExistsAndNotEmpty(Path.Combine(root, "scripts", "Finish-Installer-Update.ps1")), "Hilfsskript fuer Installer-Aktualisierungen fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "scripts\\Cancel-Installer-Updates.ps1", FileExistsAndNotEmpty(Path.Combine(root, "scripts", "Cancel-Installer-Updates.ps1")), "Hilfsskript zum Bereinigen alter Installer-Aktualisierungen fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "rules\\adult-domains.txt", FileExistsAndNotEmpty(Path.Combine(root, "rules", "adult-domains.txt")), "Haupt-Sperrliste fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "rules\\custom-domains.txt", SafeFileExists(Path.Combine(root, "rules", "custom-domains.txt")), "Eigene Sperrliste fehlt.");
            AppendPreflightCheck(report, problems, "rules\\allow-domains.txt", SafeFileExists(Path.Combine(root, "rules", "allow-domains.txt")), "Allowlist-Datei fehlt.");
            AppendPreflightCheck(report, problems, "rules\\mixed-site-url-patterns.txt", FileExistsAndNotEmpty(Path.Combine(root, "rules", "mixed-site-url-patterns.txt")), "URL-Regeln fuer gemischte Webseiten fehlen oder sind leer.");
            AppendPreflightCheck(report, problems, "rules\\adult-url-keywords.txt", FileExistsAndNotEmpty(Path.Combine(root, "rules", "adult-url-keywords.txt")), "Erwachsene URL-Begriffe fehlen oder sind leer.");
            AppendPreflightCheck(report, problems, "rules\\gambling-domains.txt", FileExistsAndNotEmpty(Path.Combine(root, "rules", "gambling-domains.txt")), "Gluecksspiel-Domainregeln fehlen oder sind leer.");
            AppendPreflightCheck(report, problems, "rules\\gambling-url-keywords.txt", FileExistsAndNotEmpty(Path.Combine(root, "rules", "gambling-url-keywords.txt")), "Gluecksspiel-URL-Begriffe fehlen oder sind leer.");
            AppendPreflightCheck(report, problems, "rules\\gambling-search-terms.txt", FileExistsAndNotEmpty(Path.Combine(root, "rules", "gambling-search-terms.txt")), "Gluecksspiel-Suchbegriffe fehlen oder sind leer.");
            AppendPreflightCheck(report, problems, "rules\\shopping-search-terms.txt", FileExistsAndNotEmpty(Path.Combine(root, "rules", "shopping-search-terms.txt")), "Shopping-Suchbegriffe fehlen oder sind leer.");
            AppendPreflightCheck(report, problems, "rules\\custom-shopping-domains.txt", SafeFileExists(Path.Combine(root, "rules", "custom-shopping-domains.txt")), "Eigene Shopping-Sperrliste fehlt.");
            AppendPreflightCheck(report, problems, "rules\\video-game-targets.txt", SafeFileExists(Path.Combine(root, "rules", "video-game-targets.txt")), "Videospiel-Zieldatei fehlt.");
            AppendPreflightCheck(report, problems, "rules\\browser-companion-rules.txt", FileExistsAndNotEmpty(Path.Combine(root, "rules", "browser-companion-rules.txt")), "Lokale Companion-Regeln fehlen oder sind leer.");
            AppendPreflightCheck(report, problems, "rules\\nsfw-subreddits.txt", FileExistsAndNotEmpty(Path.Combine(root, "rules", "nsfw-subreddits.txt")), "Reddit-18+-Community-Liste fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "rules\\bypass-app-keywords.txt", FileExistsAndNotEmpty(Path.Combine(root, "rules", "bypass-app-keywords.txt")), "Umgehungs-App-Begriffe fehlen oder sind leer.");
            AppendPreflightCheck(report, problems, "rules\\unsupported-browser-keywords.txt", FileExistsAndNotEmpty(Path.Combine(root, "rules", "unsupported-browser-keywords.txt")), "Begriffe fuer nicht unterstuetzte Browser fehlen oder sind leer.");
            AppendPreflightCheck(report, problems, "extension\\purestate-companion\\manifest.json", FileExistsAndNotEmpty(Path.Combine(root, "extension", "purestate-companion", "manifest.json")), "Purestate Companion Manifest fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "extension\\purestate-companion\\background.js", FileExistsAndNotEmpty(Path.Combine(root, "extension", "purestate-companion", "background.js")), "Purestate Companion Hintergrundmodul fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "extension\\purestate-companion\\content.js", FileExistsAndNotEmpty(Path.Combine(root, "extension", "purestate-companion", "content.js")), "Purestate Companion Seitenmodul fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "extension\\purestate-companion\\x-content.js", FileExistsAndNotEmpty(Path.Combine(root, "extension", "purestate-companion", "x-content.js")), "Purestate Companion X-Seitenmodul fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "extension\\purestate-companion\\bluesky-content.js", FileExistsAndNotEmpty(Path.Combine(root, "extension", "purestate-companion", "bluesky-content.js")), "Purestate Companion Bluesky-Seitenmodul fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "extension\\purestate-companion\\rules\\nsfw-subreddits.txt", FileExistsAndNotEmpty(Path.Combine(root, "extension", "purestate-companion", "rules", "nsfw-subreddits.txt")), "Purestate Companion Reddit-Liste fehlt oder ist leer.");
            AppendPreflightCheck(report, problems, "extension\\purestate-companion\\README.txt", FileExistsAndNotEmpty(Path.Combine(root, "extension", "purestate-companion", "README.txt")), "Purestate Companion Anleitung fehlt oder ist leer.");

            int packagedDomains = CountDomainsInPackageFile(Path.Combine(root, "rules", "adult-domains.txt"));
            int packagedMixedSitePatterns = CountEffectiveUrlPatterns(Path.Combine(root, "rules", "mixed-site-url-patterns.txt"), Path.Combine(root, "rules", "adult-url-keywords.txt"), Path.Combine(root, "rules", "nsfw-subreddits.txt"));
            int packagedAdultUrlKeywords = CountAdultUrlKeywordsInPackageFile(Path.Combine(root, "rules", "adult-url-keywords.txt"));
            int packagedNsfwSubreddits = CountNsfwSubredditsInPackageFile(Path.Combine(root, "rules", "nsfw-subreddits.txt"));
            int packagedBypassKeywords = CountKeywordLinesInPackageFile(Path.Combine(root, "rules", "bypass-app-keywords.txt"));
            int packagedUnsupportedBrowserKeywords = CountKeywordLinesInPackageFile(Path.Combine(root, "rules", "unsupported-browser-keywords.txt"));
            report.AppendLine("- Domains in Haupt-Sperrliste: " + packagedDomains);
            report.AppendLine("- URL-Regeln fuer gemischte Webseiten: " + packagedMixedSitePatterns);
            report.AppendLine("- Erwachsene URL-Begriffe: " + packagedAdultUrlKeywords);
            report.AppendLine("- Reddit-18+-Communities: " + packagedNsfwSubreddits);
            report.AppendLine("- Umgehungs-App-Begriffe: " + packagedBypassKeywords);
            report.AppendLine("- Nicht unterstuetzte Browser-Begriffe: " + packagedUnsupportedBrowserKeywords);
            if (packagedDomains < 100)
            {
                problems.Add("Haupt-Sperrliste enthaelt zu wenige Domains.");
            }
            if (packagedMixedSitePatterns < 700)
            {
                problems.Add("URL-Regeln fuer gemischte Webseiten enthalten zu wenige Muster.");
            }
            if (packagedAdultUrlKeywords < 30)
            {
                problems.Add("Erwachsene URL-Begriffe enthalten zu wenige Eintraege.");
            }
            if (packagedNsfwSubreddits < 60)
            {
                problems.Add("Reddit-18+-Community-Liste enthaelt zu wenige Eintraege.");
            }
            if (packagedBypassKeywords < 10)
            {
                problems.Add("Umgehungs-App-Begriffe enthalten zu wenige Eintraege.");
            }
            if (packagedUnsupportedBrowserKeywords < 10)
            {
                problems.Add("Begriffe fuer nicht unterstuetzte Browser enthalten zu wenige Eintraege.");
            }
            report.AppendLine();

            report.AppendLine("Skript-Selbsttests:");
            AppendPreflightCheck(report, problems, "Sperrskript", RunPackageScriptSelfTest(root, Path.Combine("scripts", "Enforce-Protection.ps1")), "Sperrskript-Selbsttest ist fehlgeschlagen.");
            AppendPreflightCheck(report, problems, "Aufraeumskript", RunPackageScriptSelfTest(root, Path.Combine("scripts", "Clear-Protection.ps1")), "Aufraeumskript-Selbsttest ist fehlgeschlagen.");
            AppendPreflightCheck(report, problems, "Watchdog-Skript", RunPackageScriptSelfTest(root, Path.Combine("scripts", "Watchdog.ps1")), "Watchdog-Selbsttest ist fehlgeschlagen.");
            report.AppendLine();

            report.AppendLine("Vorhandene Installation:");
            report.AppendLine("- Vorhanden: " + YesNo(existingInstall));
            report.AppendLine("- Windows-App-Eintrag: " + YesNo(IsRegisteredInWindows()));
            report.AppendLine("- Installierte Version: " + (installedVersion.Length == 0 ? "nicht eingetragen" : installedVersion));
            report.AppendLine("- Konfiguration vorhanden: " + YesNo(SafeFileExists(ConfigPath)));
            report.AppendLine("- Dienst laeuft aktuell: " + YesNo(ServiceRunning()));
            report.AppendLine("- Watchdog-Aufgabe vorhanden: " + YesNo(WatchdogTaskRegistered()));

            if (existingInstall && !SafeFileExists(ConfigPath))
            {
                notes.Add("Bestehende App-Dateien gefunden, aber keine Konfiguration. Beim Aktualisieren muss ein neues Passwort gesetzt werden.");
            }

            if (existingInstall && installedVersion.Length > 0 && !string.Equals(installedVersion, AppVersion, StringComparison.OrdinalIgnoreCase))
            {
                notes.Add("Installierte Version ist " + installedVersion + ". Der Installer kann auf " + AppVersion + " aktualisieren.");
            }

            report.AppendLine();
            report.AppendLine("Ergebnis:");
            if (problems.Count == 0)
            {
                report.AppendLine("Status: OK. Die Installation oder Aktualisierung kann gestartet werden.");
            }
            else
            {
                report.AppendLine("Status: Aktion noetig.");
                foreach (string problem in problems)
                {
                    report.AppendLine("- " + problem);
                }
            }

            if (notes.Count > 0)
            {
                report.AppendLine();
                report.AppendLine("Hinweise:");
                foreach (string note in notes)
                {
                    report.AppendLine("- " + note);
                }
            }

            return MaskUserPaths(report.ToString());
        }

        public static string BuildDiagnosticReport()
        {
            AppConfig config = LoadConfig();
            StringBuilder report = new StringBuilder();
            report.AppendLine("Purestate Diagnose");
            report.AppendLine("Version: " + AppVersion);
            report.AppendLine("Installationsordner: " + InstallDir);
            report.AppendLine("Konfiguration vorhanden: " + YesNo(File.Exists(ConfigPath)));
            report.AppendLine("Passwort-Hinweis vorhanden: " + YesNo(!string.IsNullOrEmpty(config.PasswordHint)));
            report.AppendLine("Schutz laut Konfiguration: " + (config.ProtectionEnabled ? "aktiv" : "pausiert"));
            report.AppendLine("Schutz soll jetzt aktiv sein: " + YesNo(ProtectionShouldBeActive(config)));
            report.AppendLine("Pause: " + PauseDescription(config));
            report.AppendLine("Zeitplan: " + ScheduleDescription(config));
            report.AppendLine("Hosts-Schutz eingeschaltet: " + YesNo(config.HostsEnabled));
            report.AppendLine("Familien-DNS eingeschaltet: " + YesNo(config.FamilyDnsEnabled));
            report.AppendLine("DNS-Profil: " + DnsProfileLabel(config.DnsProfile));
            report.AppendLine("Browser-Richtlinien eingeschaltet: " + YesNo(config.BrowserPoliciesEnabled));
            report.AppendLine("Umgehungsschutz eingeschaltet: " + YesNo(config.BypassBlockingEnabled));
            report.AppendLine("Nicht unterstuetzte Browser blockieren: " + YesNo(config.UnsupportedBrowserBlockingEnabled));
            report.AppendLine("Manipulationsschutz eingeschaltet: " + YesNo(config.TamperProtectionEnabled));
            report.AppendLine("Sperrmodus eingeschaltet: " + YesNo(config.LockdownModeEnabled));
            report.AppendLine("Abkuehlzeit vor Pause: " + YesNo(config.PauseCooldownEnabled));
            report.AppendLine("Dienst laeuft: " + YesNo(ServiceRunning()));
            report.AppendLine("Lokale Sperrliste aktiv: " + YesNo(HostsActive()));
            report.AppendLine("Familien-DNS aktiv: " + YesNo(FamilyDnsActive()));
            report.AppendLine("Browser-Richtlinien aktiv: " + YesNo(BrowserPoliciesActive()));
            report.AppendLine("Gemischte Webseiten geschuetzt: " + YesNo(MixedSitePoliciesActive()));
            report.AppendLine("Browser-Umgehungsschutz aktiv: " + YesNo(BrowserHardeningActive()));
            report.AppendLine("Browser-Proxy gehaertet: " + YesNo(BrowserProxyHardeningActive()));
            report.AppendLine("Windows-Proxy aktiv: " + YesNo(WindowsProxyActive()));
            report.AppendLine("Umgehungsschutz-Regeln: " + CountBypassFirewallRules());
            report.AppendLine("Browser-Block-Regeln: " + CountUnsupportedBrowserFirewallRules());
            report.AppendLine(BrowserPolicySummary());
            report.AppendLine("Umgehungshinweise: " + CountBypassRiskIndicators());
            report.AppendLine("Domains in Listen: " + CountDomains());
            report.AppendLine("Domains in Allowlist: " + CountAllowDomains());
            // RGL-007: Beide Zahlen, weil sie sich um den Faktor acht
            // unterscheiden und die eine fuer Firefox, die andere fuer
            // Chrome und Edge gilt.
            report.AppendLine("URL-Regeln fuer gemischte Webseiten: " + CountMixedSiteUrlPatterns() +
                " (davon in Chrome/Edge wirksam: " + CountChromiumMixedSiteUrlFilters() + ")");
            report.AppendLine("Erwachsene URL-Begriffe: " + CountAdultUrlKeywords());
            AppendVideoGamesDiagnostics(report, config);
            report.AppendLine("App-Eintrag in Windows: " + YesNo(IsRegisteredInWindows()));
            report.AppendLine("Watchdog-Aufgabe vorhanden: " + YesNo(WatchdogTaskRegistered()));
            report.AppendLine("Dienstdatei vorhanden: " + YesNo(File.Exists(Path.Combine(InstallDir, "PurestateGuard.exe"))));
            report.AppendLine("Verwaltungs-App vorhanden: " + YesNo(File.Exists(Path.Combine(InstallDir, "Purestate.exe"))));
            report.AppendLine("Deinstaller vorhanden: " + YesNo(File.Exists(Path.Combine(InstallDir, "PurestateUninstaller.exe"))));
            report.AppendLine();
            report.AppendLine(ReadRecentLogs(20));
            return MaskUserPaths(report.ToString());
        }

        public static string BuildHealthReport()
        {
            AppConfig config = LoadConfig();
            bool configExists = File.Exists(ConfigPath);
            bool serviceFile = File.Exists(Path.Combine(InstallDir, "PurestateGuard.exe"));
            bool appFile = File.Exists(Path.Combine(InstallDir, "Purestate.exe"));
            bool uninstallFile = File.Exists(Path.Combine(InstallDir, "PurestateUninstaller.exe"));
            bool service = ServiceRunning();
            bool hosts = HostsActive();
            bool dns = FamilyDnsActive();
            bool browser = BrowserPoliciesActive();
            bool mixedSite = MixedSitePoliciesActive();
            bool browserHardening = BrowserHardeningActive();
            bool browserProxyHardening = BrowserProxyHardeningActive();
            bool windowsProxy = WindowsProxyActive();
            int bypassFirewallRules = CountBypassFirewallRules();
            int bypassToolRisks = CountBypassToolIndicators();
            int unsupportedBrowserRules = CountUnsupportedBrowserFirewallRules();
            int unsupportedBrowserRisks = FindUnsupportedBrowserHints().Length;
            bool registered = IsRegisteredInWindows();
            bool watchdog = WatchdogTaskRegistered();
            int bypassRisks = CountBypassRiskIndicators();
            int mixedSitePatterns = CountMixedSiteUrlPatterns();
            bool shouldProtect = ProtectionShouldBeActive(config);

            System.Collections.Generic.List<string> problems = new System.Collections.Generic.List<string>();
            if (!configExists) problems.Add("Konfiguration fehlt.");
            if (config.Password == null) problems.Add("Passwort ist nicht eingerichtet.");
            if (!serviceFile || !appFile || !uninstallFile) problems.Add("Installationsdateien fehlen.");
            if (!registered) problems.Add("Windows-App-Eintrag fehlt.");
            if (!watchdog) problems.Add("Watchdog-Aufgabe fehlt.");
            if (bypassRisks > 0) problems.Add("Umgehungshinweise gefunden. Oeffne den Umgehungscheck.");

            if (shouldProtect)
            {
                if (!service) problems.Add("Schutzdienst laeuft nicht.");
                if (!config.LockdownModeEnabled) problems.Add("Sperrmodus ist nicht aktiv.");
                if (config.HostsEnabled && !hosts) problems.Add("Lokale Sperrliste ist nicht aktiv.");
                if (config.FamilyDnsEnabled && !dns) problems.Add("Familien-DNS ist nicht aktiv.");
                if (config.BrowserPoliciesEnabled && !browser) problems.Add("Browser-Richtlinien sind nicht aktiv.");
                // Befund #5 / Spec 2.4: wie in BuildProtectionTestReport - ohne
                // den Bereich Erwachseneninhalte liefert Get-MixedSiteUrlPatterns
                // keine Muster mehr, "nicht aktiv" ist dann kein Fund.
                if (config.BrowserPoliciesEnabled && config.AdultContentProtectionEnabled && !mixedSite) problems.Add("URL-Regeln fuer gemischte Webseiten sind nicht aktiv.");
                if (config.BrowserPoliciesEnabled && !browserHardening) problems.Add("Browser-Umgehungsschutz ist nicht aktiv.");
                if (config.BrowserPoliciesEnabled && !browserProxyHardening) problems.Add("Browser-Proxy-Schutz ist nicht aktiv.");
                if (config.TamperProtectionEnabled && windowsProxy) problems.Add("Windows-Proxy oder PAC-Skript ist aktiv.");
                if (config.BypassBlockingEnabled && bypassToolRisks > 0 && bypassFirewallRules == 0) problems.Add("Umgehungstools wurden gefunden, aber keine Firewall-Regeln sind aktiv.");
                if (config.UnsupportedBrowserBlockingEnabled && unsupportedBrowserRisks > 0 && unsupportedBrowserRules == 0) problems.Add("Nicht unterstuetzte Browser wurden gefunden, aber keine Browser-Block-Regeln sind aktiv.");
            }

            if (mixedSitePatterns < 700) problems.Add("URL-Regeln fuer gemischte Webseiten fehlen oder sind zu klein.");

            int videoGamesEnabledTargets = 0;
            int videoGamesTotalTargets = 0;
            bool videoGamesTargetsReadable = true;
            try
            {
                videoGamesTotalTargets = CountVideoGameTargets(out videoGamesEnabledTargets);
            }
            catch (Exception)
            {
                videoGamesTargetsReadable = false;
            }
            if (config.VideoGamesProtectionEnabled)
            {
                if (!videoGamesTargetsReadable) problems.Add("Videospiel-Zielliste ist nicht lesbar.");
                if (!service) problems.Add("Videospiel-Schutz ist aktiv, aber der Schutzdienst laeuft nicht.");
                if (videoGamesTargetsReadable && videoGamesEnabledTargets == 0) problems.Add("Videospiel-Schutz ist aktiv, aber es sind keine aktiven Spielziele eingetragen.");
            }

            StringBuilder report = new StringBuilder();
            report.AppendLine("Purestate Gesundheitscheck");
            report.AppendLine("Version: " + AppVersion);
            report.AppendLine("Status: " + (problems.Count == 0 ? "OK" : "Aktion empfohlen"));
            report.AppendLine();
            report.AppendLine("Konfiguration: " + YesNo(configExists));
            report.AppendLine("Passwort eingerichtet: " + YesNo(config.Password != null));
            report.AppendLine("Passwort-Hinweis vorhanden: " + YesNo(!string.IsNullOrEmpty(config.PasswordHint)));
            report.AppendLine("Schutz laut Konfiguration: " + (config.ProtectionEnabled ? "aktiv" : "pausiert"));
            report.AppendLine("Schutz soll jetzt aktiv sein: " + YesNo(shouldProtect));
            report.AppendLine("Pause: " + PauseDescription(config));
            report.AppendLine("Zeitplan: " + ScheduleDescription(config));
            report.AppendLine("Dienstdatei vorhanden: " + YesNo(serviceFile));
            report.AppendLine("Verwaltungs-App vorhanden: " + YesNo(appFile));
            report.AppendLine("Deinstaller vorhanden: " + YesNo(uninstallFile));
            report.AppendLine("Windows-App-Eintrag: " + YesNo(registered));
            report.AppendLine("Watchdog-Aufgabe: " + YesNo(watchdog));
            report.AppendLine("Dienst laeuft: " + YesNo(service));
            report.AppendLine("Hosts-Sperre aktiv: " + YesNo(hosts));
            report.AppendLine("Familien-DNS aktiv: " + YesNo(dns));
            report.AppendLine("DNS-Profil: " + DnsProfileLabel(config.DnsProfile));
            report.AppendLine("Browser-Richtlinien aktiv: " + YesNo(browser));
            report.AppendLine("Gemischte Webseiten geschuetzt: " + YesNo(mixedSite));
            report.AppendLine("Browser-Umgehungsschutz aktiv: " + YesNo(browserHardening));
            report.AppendLine("Browser-Proxy gehaertet: " + YesNo(browserProxyHardening));
            report.AppendLine("Manipulationsschutz eingeschaltet: " + YesNo(config.TamperProtectionEnabled));
            report.AppendLine("Sperrmodus eingeschaltet: " + YesNo(config.LockdownModeEnabled));
            report.AppendLine("Abkuehlzeit vor Pause: " + YesNo(config.PauseCooldownEnabled));
            report.AppendLine("Windows-Proxy aktiv: " + YesNo(windowsProxy));
            report.AppendLine("Umgehungsschutz eingeschaltet: " + YesNo(config.BypassBlockingEnabled));
            report.AppendLine("Umgehungsschutz-Regeln: " + bypassFirewallRules);
            report.AppendLine("Nicht unterstuetzte Browser blockieren: " + YesNo(config.UnsupportedBrowserBlockingEnabled));
            report.AppendLine("Browser-Block-Regeln: " + unsupportedBrowserRules);
            report.AppendLine(BrowserPolicySummary());
            report.AppendLine("Umgehungshinweise: " + bypassRisks);
            report.AppendLine("Domains in Allowlist: " + CountAllowDomains());
            report.AppendLine("URL-Regeln fuer gemischte Webseiten: " + mixedSitePatterns);
            report.AppendLine("Erwachsene URL-Begriffe: " + CountAdultUrlKeywords());
            report.AppendLine("Videospiel-Schutz: " + VideoGamesStatusLabel(config));
            report.AppendLine("Videospiel-Ziele konfiguriert: " + videoGamesTotalTargets + " (aktiv: " + videoGamesEnabledTargets + ")");
            report.AppendLine("Videospiel-Zielliste lesbar: " + YesNo(videoGamesTargetsReadable));
            report.AppendLine();

            if (problems.Count == 0)
            {
                report.AppendLine("Keine Probleme erkannt.");
            }
            else
            {
                report.AppendLine("Gefundene Probleme:");
                foreach (string problem in problems)
                {
                    report.AppendLine("- " + problem);
                }

                report.AppendLine();
                report.AppendLine("Empfehlung: Nutze den Reparieren-Knopf oder starte Installieren.exe erneut.");
            }

            return MaskUserPaths(report.ToString());
        }
    }
}
