"use strict";

const FOCUS_OVERLAY_ID = "purestate-focus-overlay";
const FOCUS_SOCIAL_HOSTS = [
  "x.com", "twitter.com", "instagram.com", "tiktok.com",
  "pinterest.com", "pinterest.de", "pinterest.at", "pinterest.ch", "pinterest.fr",
  "pinterest.it", "pinterest.es", "pinterest.co.uk", "pinterest.ca",
  "pinterest.com.au", "pinterest.com.mx", "pinterest.jp", "pinterest.se",
  "tumblr.com", "bsky.app", "reddit.com", "youtube.com", "youtu.be", "youtube-nocookie.com",
  "netflix.com", "disneyplus.com", "primevideo.com", "max.com", "hbomax.com",
  "paramountplus.com", "tv.apple.com", "crunchyroll.com", "twitch.tv", "joyn.de",
  "plus.rtl.de", "dazn.com", "wowtv.de"
];
const FOCUS_MUSIC_HOSTS = [
  "spotify.com", "music.apple.com", "music.amazon.de", "music.amazon.com",
  "deezer.com", "soundcloud.com", "tidal.com"
];
let focusRules = null;
let focusRefreshTimer = null;
let focusMediaTimer = null;
let focusRefreshKey = "";
let focusReloadRequested = false;

function focusHostBlocked(hostname, rules) {
  const host = String(hostname || "").trim().toLowerCase().replace(/\.$/, "");
  const matches = (domain) => host === domain || host.endsWith("." + domain);
  return FOCUS_SOCIAL_HOSTS.some(matches) || FOCUS_MUSIC_HOSTS.some(matches) ||
    !!globalThis.purestateFindShoppingSite(host) ||
    (Array.isArray(rules && rules.sites) && rules.sites.some(matches));
}

function focusCurtainLines(hostname, rules, nowMs) {
  const clock = (value) => {
    const date = new Date(value);
    return String(date.getHours()).padStart(2, "0") + ":" + String(date.getMinutes()).padStart(2, "0");
  };
  const host = String(hostname || "").replace(/^www\./, "");
  return [
    rules.breakMinutes > 0 && rules.edgeAtMs < rules.endAtMs
      ? host + " ist bis " + clock(rules.edgeAtMs) + " Uhr gesperrt, dann " + rules.breakMinutes + " Minuten Pause."
      : host + " ist bis zum Ende der Sitzung um " + clock(rules.endAtMs) + " Uhr gesperrt.",
    "Ende der Sitzung: " + clock(rules.endAtMs) + " Uhr",
    "Lässt sich nicht vorzeitig beenden."
  ];
}

function pauseFocusMedia() {
  try {
    for (const media of document.querySelectorAll("video, audio")) {
      try {
        if (!media.paused) { media.pause(); }
        media.muted = true;
      } catch {
      }
    }
  } catch {
  }
}

function renderFocusCurtain() {
  if (!focusRules || focusRules.phase !== "learn" || !focusHostBlocked(location.hostname, focusRules)) {
    return;
  }
  pauseFocusMedia();
  if (focusMediaTimer === null) { focusMediaTimer = setInterval(pauseFocusMedia, 1000); }
  if (!document.documentElement) { return; }
  const lines = focusCurtainLines(location.hostname, focusRules, Date.now());
  const existing = document.getElementById(FOCUS_OVERLAY_ID);
  if (existing) {
    lines.forEach((line, index) => { document.getElementById(FOCUS_OVERLAY_ID + "-line-" + index).textContent = line; });
    return;
  }
  purestateInstantHide(document, FOCUS_OVERLAY_ID + "-style");
  const theme = purestateCurtainTheme(document);
  const overlay = document.createElement("div");
  overlay.id = FOCUS_OVERLAY_ID;
  overlay.setAttribute("role", "alertdialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-labelledby", FOCUS_OVERLAY_ID + "-title");
  overlay.setAttribute("aria-describedby", FOCUS_OVERLAY_ID + "-line-0");
  overlay.setAttribute("tabindex", "-1");
  overlay.style.cssText = purestateCurtainOverlayCss(theme);
  const column = purestateCurtainColumn(document);
  column.appendChild(purestateCurtainBars(document, theme, "lg"));
  column.appendChild(purestateCurtainText(document, theme, "Purestate", "label"));
  column.appendChild(purestateCurtainTitle(document, theme, FOCUS_OVERLAY_ID + "-title", "Lernmodus läuft", "curtain"));
  lines.forEach((line, index) => {
    const text = purestateCurtainText(document, theme, line, "detail");
    text.id = FOCUS_OVERLAY_ID + "-line-" + index;
    column.appendChild(text);
  });
  overlay.appendChild(column);
  (document.body || document.documentElement).appendChild(overlay);
  purestateHoldOverlayFocus(document, overlay, overlay);
}

function removeFocusCurtain() {
  const overlay = document.getElementById(FOCUS_OVERLAY_ID);
  if (overlay) {
    overlay.remove();
    purestateRemoveInstantHide(document, FOCUS_OVERLAY_ID + "-style");
    purestateReleaseOverlayFocus(overlay);
  }
  if (focusMediaTimer !== null) { clearInterval(focusMediaTimer); focusMediaTimer = null; }
}

function scheduleFocusRefresh(delay) {
  if (focusRefreshTimer !== null) { clearTimeout(focusRefreshTimer); }
  focusRefreshTimer = setTimeout(() => {
    // Keep retrying even if the callback or native host never answers.
    scheduleFocusRefresh(15000);
    requestFocusRules();
  }, delay);
}

function applyFocusRules(response) {
  const next = response && response.rules && response.rules.focus;
  const authoritative = response && response.ok === true &&
    (response.source === "native-host" || response.source === "native-host-push");
  if (!next || !["learn", "break", "off"].includes(next.phase) ||
      (!authoritative && focusRules && focusRules.phase === "learn")) {
    return;
  }
  if (!authoritative && next.phase === "off") { return; }
  focusRules = next;
  if (next.phase === "learn" && focusHostBlocked(location.hostname, next)) {
    renderFocusCurtain();
  } else {
    removeFocusCurtain();
  }
  if (next.phase === "off") {
    if (focusRefreshKey !== "off") { scheduleFocusRefresh(15000); }
    focusRefreshKey = "off";
    return;
  }
  const key = next.phase + ":" + next.edgeAtMs;
  if (key !== focusRefreshKey) {
    focusRefreshKey = key;
    // The clock schedules a check; only a fresh guard phase can lift the curtain.
    scheduleFocusRefresh(Math.max(0, next.edgeAtMs - Date.now()));
  }
}

function requestFocusRules() {
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.id) {
      // A companion reload or update orphans this script: it never hears the guard
      // again, so its curtain would outlive the session. A reload hands the page to
      // the fresh script. Only under the curtain, where no input can be lost.
      if (!focusReloadRequested && document.getElementById(FOCUS_OVERLAY_ID)) {
        focusReloadRequested = true;
        location.reload();
      }
      return;
    }
    const pending = chrome.runtime.sendMessage({ type: "purestate.getBrowserRules", site: "focus" }, applyFocusRules);
    if (pending && typeof pending.then === "function") { pending.then(applyFocusRules).catch(() => {}); }
  } catch {
  }
}

function installFocusModule() {
  document.addEventListener("DOMContentLoaded", renderFocusCurtain);
  try {
    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener((message) => {
        if (message && message.type === "purestate.rulesUpdated") { applyFocusRules(message); }
        return false;
      });
    }
  } catch {
  }
  scheduleFocusRefresh(15000);
  requestFocusRules();
}

installFocusModule();
