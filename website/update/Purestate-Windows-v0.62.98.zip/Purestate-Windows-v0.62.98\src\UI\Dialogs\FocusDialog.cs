using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    internal static class FocusDialog
    {
        internal static string PreviewText(int minutes, int cycle, int pause, DateTime nowLocal)
        {
            string text = "Ende " + nowLocal.AddMinutes(minutes).ToString("HH:mm") + " Uhr";
            List<string> starts = new List<string>();
            foreach (int start in Support.FocusBreakStartMinutes(minutes, cycle, pause))
                starts.Add(nowLocal.AddMinutes(start).ToString("HH:mm"));
            if (starts.Count > 0)
                text += " · Pausen " + (starts.Count == 1 ? starts[0] : string.Join(", ", starts.GetRange(0, starts.Count - 1).ToArray()) + " und " + starts[starts.Count - 1]);
            return text;
        }

        internal static DialogShell Create(UiTheme theme, Action onChanged)
        {
            DialogShell shell = new DialogShell(theme, "Lernmodus",
                "Sperrt für eine gewählte Zeit alles Ablenkende. Lässt sich nicht vorzeitig beenden.",
                "Startet eine zeitlich begrenzte Lernsitzung oder erweitert die gesperrten Einträge.", true);
            shell.MarkSaved(); // List changes apply immediately; the duration is only a preview until Start.
            shell.SaveButton.Text = "Lernmodus starten";
            Ui.SetAccessibility(shell.SaveButton, "Lernmodus starten", "Startet die Sitzung verbindlich. Sie lässt sich nicht vorzeitig beenden.", AccessibleRole.PushButton);
            shell.CloseButtonControl.Text = "Schließen";
            Ui.SetAccessibility(shell.CloseButtonControl, "Schließen", "Schließt den Lernmodus-Dialog.", AccessibleRole.PushButton);
            Label statusLabel = shell.AddHint("Stand wird abgerufen …");

            shell.AddSection("Dauer und Pausen");
            int[] steps = new int[32];
            for (int index = 0; index < steps.Length; index++) { steps[index] = (index + 1) * 15; }
            ComboBox duration = Ui.StepsCombo(steps, 15, 480, 60, "Dauer in Minuten", "15 Minuten bis 8 Stunden in Schritten von 15 Minuten.");
            shell.Add(shell.Row(duration, Ui.WrapLabel(theme, "Minuten", Dpi.Px(160), true)));
            Control planCard = duration.Parent.Parent;
            ComboBox breaks = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Font = Ui.FontBody, Width = shell.InnerWidth };
            breaks.Items.AddRange(new object[] { "keine", "5 Minuten je halbe Stunde", "15 Minuten je Stunde" });
            breaks.SelectedIndex = 0;
            Ui.SetAccessibility(breaks, "Pausen", "Wählt keine Pause, 5 Minuten je halbe Stunde oder 15 Minuten je Stunde.", AccessibleRole.ComboBox);
            shell.Add(breaks);
            Label preview = shell.AddHint("");
            Ui.SetAccessibility(preview, "Vorschau", "Ende und Pausen bei einem Start jetzt.", AccessibleRole.StaticText);
            Action updatePreview = delegate
            {
                preview.Text = PreviewText(int.Parse(duration.Text, CultureInfo.InvariantCulture), breaks.SelectedIndex == 1 ? 30 : breaks.SelectedIndex == 2 ? 60 : 0,
                    breaks.SelectedIndex == 1 ? 5 : breaks.SelectedIndex == 2 ? 15 : 0, DateTime.Now);
                preview.AccessibleDescription = preview.Text;
            };
            duration.SelectedIndexChanged += delegate { updatePreview(); };
            breaks.SelectedIndexChanged += delegate { updatePreview(); };
            updatePreview();
            shell.AddHint("Laufende Spiele, Musikprogramme und Browser ohne Purestate-Companion werden geschlossen.");

            shell.AddSection("Gesperrte Webseiten und Programme");
            shell.AddHint("In Lernphasen gesperrt: Social Media/YouTube, Streaming, gepflegte Shops und Musik-Webseiten – auch wenn ihre Schutzbereiche ausgeschaltet sind.");
            Label ownCount = shell.AddHint("Eigene Einträge: 0");
            shell.AddHint("Eigene Einträge ergänzen die Ablenkungen, die Purestate bereits kennt. Änderungen an der Liste wirken sofort. Während einer Sitzung lässt sich die Liste nur erweitern.");
            ListBox list = new ListBox { Width = shell.InnerWidth, Height = Dpi.Px(144), Font = Ui.FontBody, IntegralHeight = false, HorizontalScrollbar = true };
            Ui.SetAccessibility(list, "Gesperrte Einträge", "Zusätzlich gesperrte Webseiten und Programme.", AccessibleRole.List);
            shell.Add(list);
            ComboBox kind = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Font = Ui.FontBody, Width = shell.InnerWidth };
            kind.Items.AddRange(new object[] { "Webseite", "Programm (.exe)" }); kind.SelectedIndex = 0;
            Ui.SetAccessibility(kind, "Art des Eintrags", "Wählt eine Webseite oder den Dateinamen eines Programms.", AccessibleRole.ComboBox);
            shell.Add(kind);
            shell.AddHint("Webseite oder Programm eingeben, zum Beispiel example.org oder game.exe.");
            TextBox value = new TextBox { Width = shell.InnerWidth, Font = Ui.FontBody, MaxLength = 1024 };
            Ui.SetAccessibility(value, "Webseite oder Programm", "Zum Beispiel example.org oder game.exe.", AccessibleRole.Text);
            shell.Add(value);
            Label error = shell.AddErrorLine();
            Button add = Ui.SecondaryButton(theme, "Eintrag hinzufügen", "Sperrt die eingegebene Webseite oder das Programm zusätzlich.");
            Button remove = Ui.SecondaryButton(theme, "Eintrag entfernen", "Entfernt den gewählten Eintrag vor Beginn einer Sitzung.");
            shell.Add(shell.Row(add, remove));

            FocusStatus status = null;
            bool busy = true;
            System.Windows.Forms.Timer previewTimer = new System.Windows.Forms.Timer { Interval = 15000 };
            previewTimer.Tick += delegate { if (!busy && status != null && status.Phase == "off") { updatePreview(); } };
            shell.Shown += delegate { previewTimer.Start(); };
            shell.Disposed += delegate { previewTimer.Dispose(); };
            Action updateControls = delegate
            {
                bool available = status != null && status.Available;
                bool active = available && status.Phase != "off";
                planCard.Visible = !active;
                shell.SaveButton.Visible = !active;
                remove.Visible = !active;
                shell.SaveButton.Enabled = !busy && available && !status.BetaExpired && status.Covered && !active;
                add.Enabled = !busy && available && !status.BetaExpired;
                remove.Enabled = !busy && available && !status.BetaExpired && !active && list.SelectedIndex >= 0;
                list.Enabled = kind.Enabled = value.Enabled = duration.Enabled = breaks.Enabled = !busy && available;
                shell.CloseButtonControl.Enabled = !busy;
                shell.UseWaitCursor = busy;
                shell.AcceptButton = active ? null : shell.SaveButton;
            };
            Action showStatus = delegate
            {
                string text = AdminForm.FocusStatusText(status, DateTime.Now);
                if (status != null && status.Available)
                {
                    if (status.BetaExpired) { text = Support.FocusErrorText("beta-expired"); }
                    else if (status.Phase == "off" && !status.Covered) { text = Support.FocusErrorText("no-companion"); }
                }
                Ui.SetDynamicText(statusLabel, text, "Lernmodus Status");
                statusLabel.Visible = status == null || !status.Available || status.Phase != "off" || !status.Covered || status.BetaExpired;
                updateControls();
            };
            Action<Action, Action> run = delegate(Action work, Action success)
            {
                if (busy) { return; }
                busy = true; shell.ClearError(error); updateControls();
                ThreadPool.QueueUserWorkItem(delegate
                {
                    Exception failure = null;
                    try { work(); } catch (Exception ex) { failure = ex; }
                    try
                    {
                        shell.BeginInvoke(new Action(delegate
                        {
                            busy = false;
                            updateControls();
                            if (failure == null) { success(); }
                            else
                            {
                                if (status == null) { Ui.SetDynamicText(statusLabel, "Stand gerade nicht abrufbar", "Lernmodus Status"); }
                                shell.ShowError(error, Support.FocusErrorText(failure is InvalidOperationException ? failure.Message : "unavailable"), value);
                            }
                            if (!shell.IsDisposed) { updateControls(); }
                        }));
                    }
                    catch (InvalidOperationException) { }
                });
            };
            Action<string> requireSuccess = delegate(string code) { if (!string.IsNullOrEmpty(code)) { throw new InvalidOperationException(code); } };
            List<string> currentEntries = new List<string>();
            Action<List<string>> showList = delegate(List<string> entries)
            {
                currentEntries = entries;
                ownCount.Text = "Eigene Einträge: " + entries.Count.ToString(CultureInfo.InvariantCulture);
                list.Items.Clear();
                foreach (string entry in entries)
                {
                    string[] parts = entry.Split(new[] { '=' }, 2);
                    list.Items.Add((parts[0] == "site" ? "Webseite: " : "Programm: ") + parts[1]);
                }
            };
            add.Click += delegate
            {
                string entryKind = kind.SelectedIndex == 0 ? "site" : "program";
                string entryValue = value.Text.Trim(); List<string> entries = null;
                run(delegate { requireSuccess(Support.AddFocusEntry(entryKind, entryValue)); entries = Support.QueryFocusList(); },
                    delegate { showList(entries); value.Clear(); if (onChanged != null) { onChanged(); } });
            };
            remove.Click += delegate
            {
                if (list.SelectedItem == null) { return; }
                string[] entry = currentEntries[list.SelectedIndex].Split(new[] { '=' }, 2); List<string> entries = null;
                run(delegate { requireSuccess(Support.RemoveFocusEntry(entry[0], entry[1])); entries = Support.QueryFocusList(); },
                    delegate { showList(entries); if (onChanged != null) { onChanged(); } });
            };
            shell.SaveButton.Click += delegate
            {
                int minutes = int.Parse(duration.Text, CultureInfo.InvariantCulture);
                int cycle = breaks.SelectedIndex == 1 ? 30 : breaks.SelectedIndex == 2 ? 60 : 0;
                int pause = breaks.SelectedIndex == 1 ? 5 : breaks.SelectedIndex == 2 ? 15 : 0;
                run(delegate { requireSuccess(Support.StartFocusSession(minutes, cycle, pause)); },
                    delegate { shell.DialogResult = DialogResult.OK; shell.Close(); if (onChanged != null) { onChanged(); } });
            };
            list.SelectedIndexChanged += delegate { updateControls(); };
            shell.FormClosing += delegate(object sender, FormClosingEventArgs e) { if (busy) { e.Cancel = true; } };
            shell.Shown += delegate
            {
                busy = false;
                List<string> entries = null; FocusStatus loaded = null;
                run(delegate { loaded = Support.QueryFocusStatus(); entries = Support.QueryFocusList(); },
                    delegate { status = loaded; showList(entries); showStatus(); shell.FinishLayout(); });
            };
            updateControls();
            shell.FinishLayout();
            return shell;
        }
    }
}
