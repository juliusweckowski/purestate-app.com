"use strict";

// Purestate shared shopping deal-search terms.
//
// Curated, low-ambiguity queries for the deal-search overlay while the
// shopping area is active. Bare "sale" or "deal" stay allowed on purpose -
// only clearly compulsive-shopping queries (coupons, discount codes, event
// sales) are matched. Loaded before search-content.js like
// adult-search-terms.js; publishes its helper on globalThis.

(function () {
  const TERMS = [
    "gutschein", "gutscheincode", "gutscheine", "rabattcode", "rabattcodes",
    "rabattaktion", "coupon", "couponcode", "coupons", "black friday",
    "cyber monday", "schnaeppchen", "schnäppchen", "blitzangebot",
    "flash sale", "cashback deal"
  ];

  function normalizeShoppingText(text) {
    return String(text || "")
      .toLowerCase()
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, " ")
      .trim();
  }

  const NORMALIZED_TERMS = [];
  for (const term of TERMS) {
    const normalized = normalizeShoppingText(term);
    if (normalized && !NORMALIZED_TERMS.includes(normalized)) {
      NORMALIZED_TERMS.push(normalized);
    }
  }

  globalThis.purestateShoppingDealTerms = function () {
    return NORMALIZED_TERMS.slice();
  };

  globalThis.purestateIsShoppingDealSearchText = function (text) {
    const normalized = normalizeShoppingText(text);
    if (!normalized) {
      return false;
    }
    const tokens = normalized.split(/\s+/);
    for (const term of NORMALIZED_TERMS) {
      if (term.includes(" ")) {
        if (normalized.includes(term)) {
          return true;
        }
      } else if (tokens.includes(term)) {
        return true;
      }
    }
    return false;
  };
})();
