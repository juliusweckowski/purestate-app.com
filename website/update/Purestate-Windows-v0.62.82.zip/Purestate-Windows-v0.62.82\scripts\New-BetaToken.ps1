<#
.SYNOPSIS
Erzeugt Freischaltcodes fuer die Beta.

.DESCRIPTION
Das Alphabet laesst I, O, 0 und 1 aus: die Codes werden am Telefon vorgelesen
und aus E-Mails abgetippt, und genau diese vier Zeichen verwechselt man dabei.
#>
[CmdletBinding()]
param(
    [int]$Count = 1
)

$alphabet = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ".ToCharArray()
$rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()

try {
    for ($i = 0; $i -lt $Count; $i++) {
        $groups = @()
        for ($g = 0; $g -lt 3; $g++) {
            $bytes = [byte[]]::new(4)
            $rng.GetBytes($bytes)
            $chars = foreach ($b in $bytes) { $alphabet[$b % $alphabet.Length] }
            $groups += (-join $chars)
        }

        "PS-BETA-" + ($groups -join "-")
    }
}
finally {
    $rng.Dispose()
}
