using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Pipes;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Timers;

namespace Purestate
{
    internal static class Program
    {
        private const string ServiceNameValue = "PurestateGuard";

        private static int Main(string[] args)
        {
            if (args.Length > 0 && args[0].Equals("--self-test", StringComparison.OrdinalIgnoreCase))
            {
                string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                string helper = Path.Combine(baseDir, "scripts", "Enforce-Protection.ps1");
                string installerUpdateHelper = Path.Combine(baseDir, "scripts", "Finish-Installer-Update.ps1");
                string installerUpdateCleanup = Path.Combine(baseDir, "scripts", "Cancel-Installer-Updates.ps1");
                string rules = Path.Combine(baseDir, "rules", "adult-domains.txt");
                string mixedSiteRules = Path.Combine(baseDir, "rules", "mixed-site-url-patterns.txt");
                string adultUrlKeywords = Path.Combine(baseDir, "rules", "adult-url-keywords.txt");
                string gamblingRules = Path.Combine(baseDir, "rules", "gambling-domains.txt");
                string browserCompanionRules = Path.Combine(baseDir, "rules", "browser-companion-rules.txt");
                string nsfwSubreddits = Path.Combine(baseDir, "rules", "nsfw-subreddits.txt");
                string bypassAppKeywords = Path.Combine(baseDir, "rules", "bypass-app-keywords.txt");
                string unsupportedBrowserKeywords = Path.Combine(baseDir, "rules", "unsupported-browser-keywords.txt");
                string extensionManifest = Path.Combine(baseDir, "extension", "purestate-companion", "manifest.json");
                string extensionBackground = Path.Combine(baseDir, "extension", "purestate-companion", "background.js");
                string extensionContent = Path.Combine(baseDir, "extension", "purestate-companion", "content.js");
                string extensionXContent = Path.Combine(baseDir, "extension", "purestate-companion", "x-content.js");
                string extensionXPageBridge = Path.Combine(baseDir, "extension", "purestate-companion", "x-page-bridge.js");
                string extensionBlueskyContent = Path.Combine(baseDir, "extension", "purestate-companion", "bluesky-content.js");
                string extensionRules = Path.Combine(baseDir, "extension", "purestate-companion", "rules", "nsfw-subreddits.txt");
                string nativeHost = Path.Combine(baseDir, "PurestateNativeHost.exe");
                string nativeHostManifest = Path.Combine(baseDir, "native-host", "com.purestate.companion.json");

                if (!File.Exists(helper))
                {
                    Console.Error.WriteLine("Missing helper script: " + helper);
                    return 1;
                }

                if (!File.Exists(installerUpdateHelper))
                {
                    Console.Error.WriteLine("Missing installer update helper script: " + installerUpdateHelper);
                    return 1;
                }

                if (!File.Exists(installerUpdateCleanup))
                {
                    Console.Error.WriteLine("Missing installer update cleanup script: " + installerUpdateCleanup);
                    return 1;
                }

                if (!File.Exists(rules))
                {
                    Console.Error.WriteLine("Missing rules file: " + rules);
                    return 1;
                }

                if (!File.Exists(mixedSiteRules))
                {
                    Console.Error.WriteLine("Missing mixed-site rules file: " + mixedSiteRules);
                    return 1;
                }

                if (!File.Exists(adultUrlKeywords))
                {
                    Console.Error.WriteLine("Missing adult URL keywords file: " + adultUrlKeywords);
                    return 1;
                }

                if (!File.Exists(gamblingRules))
                {
                    Console.Error.WriteLine("Missing gambling rules file: " + gamblingRules);
                    return 1;
                }

                if (!File.Exists(browserCompanionRules))
                {
                    Console.Error.WriteLine("Missing browser companion rules file: " + browserCompanionRules);
                    return 1;
                }

                if (!File.Exists(nsfwSubreddits))
                {
                    Console.Error.WriteLine("Missing Reddit NSFW subreddit file: " + nsfwSubreddits);
                    return 1;
                }

                if (!File.Exists(bypassAppKeywords))
                {
                    Console.Error.WriteLine("Missing bypass app keywords file: " + bypassAppKeywords);
                    return 1;
                }

                if (!File.Exists(unsupportedBrowserKeywords))
                {
                    Console.Error.WriteLine("Missing unsupported browser keywords file: " + unsupportedBrowserKeywords);
                    return 1;
                }

                if (!File.Exists(extensionManifest) || !File.Exists(extensionBackground) || !File.Exists(extensionContent) || !File.Exists(extensionXContent) || !File.Exists(extensionXPageBridge) || !File.Exists(extensionBlueskyContent) || !File.Exists(extensionRules))
                {
                    Console.Error.WriteLine("Missing Purestate companion extension files.");
                    return 1;
                }

                string heartbeatBrowser;
                string heartbeatVersion;
                if (!File.Exists(nativeHost) || !File.Exists(nativeHostManifest) ||
                    !GuardService.TryParseHeartbeatMessage("Chrome|0.61.40", out heartbeatBrowser, out heartbeatVersion) ||
                    GuardService.TryParseHeartbeatMessage("Other|0.61.40", out heartbeatBrowser, out heartbeatVersion))
                {
                    Console.Error.WriteLine("Purestate native heartbeat self-test failed.");
                    return 1;
                }

                if (!GuardService.IsTrustedHeartbeatClientProcess(nativeHost, baseDir) ||
                    GuardService.IsTrustedHeartbeatClientProcess(Path.Combine(baseDir, "OtherNativeHost.exe"), baseDir))
                {
                    Console.Error.WriteLine("Purestate native heartbeat client path self-test failed.");
                    return 1;
                }

                if (!GuardService.IsBrowserPreferencesFile(@"C:\Users\Test\Preferences") ||
                    !GuardService.IsBrowserPreferencesFile(@"C:\Users\Test\Secure Preferences") ||
                    GuardService.IsBrowserPreferencesFile(@"C:\Users\Test\History"))
                {
                    Console.Error.WriteLine("Browser profile watcher filter failed.");
                    return 1;
                }

                if (!GuardService.RunBrowserWatcherSelfTest())
                {
                    Console.Error.WriteLine("Browser profile watcher did not receive a preferences change.");
                    return 1;
                }

                string videoGamesSelfTestError = VideoGamesGuard.RunSelfTest();
                if (videoGamesSelfTestError.Length != 0)
                {
                    Console.Error.WriteLine("Purestate video-games guard self-test failed: " + videoGamesSelfTestError);
                    return 1;
                }

                string detectionSelfTestError = VideoGameDetection.RunSelfTest();
                if (detectionSelfTestError.Length != 0)
                {
                    Console.Error.WriteLine("Purestate video-game detection self-test failed: " + detectionSelfTestError);
                    return 1;
                }

                if (GuardService.IsCompanionExplicitlyDisabledJson("{\"extensions\":{\"settings\":{\"gmldhenkcnghfoapdnhkikfpgdmmnlok\":{\"state\":1,\"disable_reasons\":[]}}}}") ||
                    !GuardService.IsCompanionExplicitlyDisabledJson("{\"extensions\":{\"settings\":{\"gmldhenkcnghfoapdnhkikfpgdmmnlok\":{\"disable_reasons\":[1]}}}}") ||
                    !GuardService.IsCompanionExplicitlyDisabledJson("{\"extensions\":{\"settings\":{\"gmldhenkcnghfoapdnhkikfpgdmmnlok\":{\"state\":0}}}}") ||
                    GuardService.ManagedCompanionSettingsJson.IndexOf("force_installed", StringComparison.Ordinal) < 0)
                {
                    Console.Error.WriteLine("Direct companion fail-closed self-test failed.");
                    return 1;
                }

                Console.WriteLine("Self-test OK.");
                return 0;
            }

            if (Environment.UserInteractive)
            {
                Console.WriteLine("PurestateGuard is a Windows service.");
                Console.WriteLine("Use Install-Purestate.cmd to install it.");
                return 0;
            }

            ServiceBase.Run(new GuardService(ServiceNameValue));
            return 0;
        }
    }

    internal sealed partial class GuardService : ServiceBase
    {
        private const string CompanionStoreId = "gmldhenkcnghfoapdnhkikfpgdmmnlok";
        private const string CompanionUpdateUrl = "https://clients2.google.com/service/update2/crx";
        private const string HeartbeatPipeName = "PurestateCompanionHeartbeat";
        private const int HeartbeatPipeConnectionPollMilliseconds = 1000;
        // GRD-013: Mit einer einzigen Pipe-Instanz und einem seriellen
        // Bedienweg belegte ein Anrufer, der verbindet und nichts sendet, die
        // ganze Gegenstelle fuer die Dauer des Lesezeitlimits - und konnte
        // sofort wieder verbinden. Vier Instanzen mit je einem eigenen
        // Bedienfaden, und das Lesezeitlimit auf eine Sekunde: der echte
        // Companion sendet seine Zeile unmittelbar nach dem Verbinden.
        private const int HeartbeatPipeServerInstances = 4;
        private const int HeartbeatPipeReadTimeoutMilliseconds = 1000;
        // GRD-017: Die Grenze war fuer den zweifeldrigen Herzschlag bemessen
        // und blieb stehen, als die spaeteren Verben dazukamen. Die
        // learn-host-Zeile hat 49 feste Bytes, der Host durfte damit hoechstens
        // 78 Zeichen haben - waehrend Absender UND Behandler gegen 253 pruefen.
        // Ein langer Hostname wurde also nie gelernt, und der Companion bekam
        // nur ERROR. 512 Bytes decken die 253 mit Abstand; das Lesezeitlimit je
        // Nachricht deckelt den Aufwand ohnehin.
        private const int MaxHeartbeatMessageBytes = 512;
        private const int MaxChromiumUrlBlocklistEntries = 1000;
        private const int ProtectionHelperTimeoutMilliseconds = 90000;
        private const int MaxProtectionHelperLogChars = 8192;
        private const long MaxServiceLogBytes = 262144;
        private const int MaxServiceLogMessageChars = 2048;
        internal const string ManagedCompanionSettingsJson = "{\"gmldhenkcnghfoapdnhkikfpgdmmnlok\":{\"installation_mode\":\"force_installed\",\"update_url\":\"https://clients2.google.com/service/update2/crx\",\"toolbar_pin\":\"force_pinned\"}}";
        // The canonical settings object for our companion only (no outer map),
        // derived once from ManagedCompanionSettingsJson so the two never drift.
        private static readonly string ManagedCompanionEntryObject =
            ExtractJsonObjectForProperty(ManagedCompanionSettingsJson, CompanionStoreId);
        private static readonly string[][] DirectFailClosedFilterFields =
        {
            new[] { "reddit.com", "SiteRedditEnabled" },
            new[] { "x.com", "SiteXEnabled" },
            new[] { "twitter.com", "SiteXEnabled" },
            new[] { "bsky.app", "SiteBlueskyEnabled" },
            new[] { "tumblr.com", "SiteTumblrEnabled" },
            new[] { "deviantart.com", "SiteDeviantArtEnabled" },
            new[] { "pixiv.net", "SitePixivEnabled" },
            new[] { "newgrounds.com", "SiteNewgroundsEnabled" },
            new[] { "imgur.com", "SiteImgurEnabled" },
            new[] { "instagram.com", "SiteInstagramEnabled" },
            new[] { "tiktok.com", "SiteTikTokEnabled" },
            new[] { "pinterest.com", "SitePinterestEnabled" },
            // pinterest.com implicitly covers de.pinterest.com etc., but the
            // ccTLD domains are separate registrable hosts.
            new[] { "pinterest.de", "SitePinterestEnabled" },
            new[] { "pinterest.at", "SitePinterestEnabled" },
            new[] { "pinterest.ch", "SitePinterestEnabled" },
            new[] { "pinterest.fr", "SitePinterestEnabled" },
            new[] { "pinterest.it", "SitePinterestEnabled" },
            new[] { "pinterest.es", "SitePinterestEnabled" },
            new[] { "pinterest.co.uk", "SitePinterestEnabled" },
            new[] { "pinterest.ca", "SitePinterestEnabled" },
            new[] { "pinterest.com.au", "SitePinterestEnabled" },
            new[] { "pinterest.com.mx", "SitePinterestEnabled" },
            new[] { "pinterest.jp", "SitePinterestEnabled" },
            new[] { "pinterest.se", "SitePinterestEnabled" },
            // POL-003: Ein Hosteintrag deckt die Subdomains ab, nicht die
            // anderen Laender-TLDs. Ohne diese Zeilen bleibt google.de im
            // Fail-closed-Zustand offen - fuer eine deutschsprachige
            // Zielgruppe die Standardsuche. Dieselbe Liste steht in
            // Get-ChromiumFailClosedFilters.
            new[] { "google.com", "GamblingProtectionEnabled" },
            new[] { "google.de", "GamblingProtectionEnabled" },
            new[] { "google.at", "GamblingProtectionEnabled" },
            new[] { "google.ch", "GamblingProtectionEnabled" },
            new[] { "google.co.uk", "GamblingProtectionEnabled" },
            new[] { "google.fr", "GamblingProtectionEnabled" },
            new[] { "google.it", "GamblingProtectionEnabled" },
            new[] { "google.es", "GamblingProtectionEnabled" },
            new[] { "google.nl", "GamblingProtectionEnabled" },
            new[] { "google.pl", "GamblingProtectionEnabled" },
            new[] { "google.cz", "GamblingProtectionEnabled" },
            new[] { "google.dk", "GamblingProtectionEnabled" },
            new[] { "google.se", "GamblingProtectionEnabled" },
            new[] { "bing.com", "GamblingProtectionEnabled" },
            new[] { "duckduckgo.com", "GamblingProtectionEnabled" },
            new[] { "search.brave.com", "GamblingProtectionEnabled" },
            new[] { "search.yahoo.com", "GamblingProtectionEnabled" },
            new[] { "youtube.com", "GamblingProtectionEnabled" }
        };
        private readonly System.Timers.Timer timer;
        // 0 = frei, 1 = ein Takt laeuft. Siehe TCK-001 im Elapsed-Handler.
        private int tickRunning;
        private readonly System.Timers.Timer companionPolicyTimer;
        private readonly System.Timers.Timer browserDebounceTimer;
        private readonly System.Timers.Timer videoGamesProbeTimer;
        private readonly List<FileSystemWatcher> browserWatchers = new List<FileSystemWatcher>();
        private readonly object runSync = new object();
        private readonly object infrastructureSync = new object();
        private readonly Dictionary<string, DateTime> lastBrowserClosures = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
        private bool isRunning;
        private bool browserCheckPending;
        private volatile bool stopping;
        private readonly List<Thread> heartbeatThreads = new List<Thread>();
        // GRD-014: Der laufende Schutzhelfer, damit OnStop ihn abbrechen kann.
        // Seine Arbeit ist wiederholbar, ein Abbruch also unbedenklich.
        private Process runningProtectionHelper;

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetNamedPipeClientProcessId(IntPtr pipe, out uint clientProcessId);

        // ---- Authenticode-Selbstpruefung ---------------------------------------
        //
        // Erwarteter Antragsteller (CN=...) der Codesignatur. LEER bedeutet: es
        // ist noch kein Zertifikat beschafft, die Pruefung berichtet dann nur
        // und setzt nichts durch. Sobald hier ein Wert steht, ist er Teil der
        // signierten Binary und damit selbst gegen Aenderung geschuetzt.
        //
        // Ehrliche Grenze: Ein Administrator, der PurestateGuard.exe ersetzen
        // kann, kann auch diese Pruefung herauspatchen. Sie macht den Austausch
        // einzelner Komponenten nachweisbar und aufwendiger, nicht unmoeglich.
        internal const string ExpectedSignerSubject = "";

        private static readonly Guid WinTrustActionGenericVerifyV2 =
            new Guid("00AAC56B-CD44-11d0-8CC2-00C04FC295EE");

        private const uint WtdUiNone = 2;
        private const uint WtdRevokeNone = 0;
        private const uint WtdChoiceFile = 1;
        private const uint WtdStateActionVerify = 1;
        private const uint WtdStateActionClose = 2;
        private const uint WtdSaferFlag = 0x100;

        [StructLayout(LayoutKind.Sequential)]
        private struct WinTrustFileInfo
        {
            public uint cbStruct;
            [MarshalAs(UnmanagedType.LPWStr)] public string pcwszFilePath;
            public IntPtr hFile;
            public IntPtr pgKnownSubject;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct WinTrustData
        {
            public uint cbStruct;
            public IntPtr pPolicyCallbackData;
            public IntPtr pSIPClientData;
            public uint dwUIChoice;
            public uint fdwRevocationChecks;
            public uint dwUnionChoice;
            public IntPtr pFile;
            public uint dwStateAction;
            public IntPtr hWVTStateData;
            public IntPtr pwszURLReference;
            public uint dwProvFlags;
            public uint dwUIContext;
        }

        [DllImport("wintrust.dll", ExactSpelling = true, CharSet = CharSet.Unicode)]
        private static extern uint WinVerifyTrust(IntPtr hwnd, [MarshalAs(UnmanagedType.LPStruct)] Guid actionId, IntPtr data);

        // 0 = Datei ist signiert und die Signatur ist vertrauenswuerdig.
        // Jeder andere Wert beschreibt den Grund (nicht signiert, Kette nicht
        // vertrauenswuerdig, Datei veraendert).
        internal static uint VerifyAuthenticodeStatus(string path)
        {
            WinTrustFileInfo fileInfo = new WinTrustFileInfo
            {
                cbStruct = (uint)Marshal.SizeOf(typeof(WinTrustFileInfo)),
                pcwszFilePath = path,
                hFile = IntPtr.Zero,
                pgKnownSubject = IntPtr.Zero
            };

            IntPtr fileInfoPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(WinTrustFileInfo)));
            IntPtr dataPtr = IntPtr.Zero;
            try
            {
                Marshal.StructureToPtr(fileInfo, fileInfoPtr, false);

                WinTrustData data = new WinTrustData
                {
                    cbStruct = (uint)Marshal.SizeOf(typeof(WinTrustData)),
                    dwUIChoice = WtdUiNone,
                    // Keine Sperrlistenpruefung: sie braucht Netz, und der
                    // Guard darf ohne Internetverbindung nicht blockieren.
                    fdwRevocationChecks = WtdRevokeNone,
                    dwUnionChoice = WtdChoiceFile,
                    pFile = fileInfoPtr,
                    dwStateAction = WtdStateActionVerify,
                    dwProvFlags = WtdSaferFlag
                };

                dataPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(WinTrustData)));
                Marshal.StructureToPtr(data, dataPtr, false);

                uint result = WinVerifyTrust(IntPtr.Zero, WinTrustActionGenericVerifyV2, dataPtr);

                // Der Verify-Aufruf haelt einen Zustand offen, der explizit
                // geschlossen werden muss - sonst leckt der Prozess Handles.
                data = (WinTrustData)Marshal.PtrToStructure(dataPtr, typeof(WinTrustData));
                data.dwStateAction = WtdStateActionClose;
                Marshal.StructureToPtr(data, dataPtr, false);
                WinVerifyTrust(IntPtr.Zero, WinTrustActionGenericVerifyV2, dataPtr);

                return result;
            }
            catch (Exception)
            {
                return uint.MaxValue;
            }
            finally
            {
                if (dataPtr != IntPtr.Zero) { Marshal.FreeHGlobal(dataPtr); }
                Marshal.FreeHGlobal(fileInfoPtr);
            }
        }

        internal static string ReadSignerSubject(string path)
        {
            try
            {
                return System.Security.Cryptography.X509Certificates.X509Certificate
                    .CreateFromSignedFile(path).Subject;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        // Vollstaendige Bewertung einer Datei. Liefert true, wenn nichts zu
        // beanstanden ist, sonst false mit Begruendung.
        internal static bool CheckBinarySignature(string path, string expectedSubject, out string reason)
        {
            reason = string.Empty;

            if (!File.Exists(path))
            {
                reason = "Datei fehlt";
                return false;
            }

            uint status = VerifyAuthenticodeStatus(path);
            if (status != 0)
            {
                // Ohne beschafftes Zertifikat sind die eigenen Binaries
                // unsigniert. Das ist der heutige Auslieferungszustand und
                // kein Angriff - deshalb nur berichten, solange kein
                // Antragsteller erwartet wird.
                reason = string.IsNullOrEmpty(expectedSubject)
                    ? "nicht signiert oder Signatur nicht vertrauenswuerdig (0x" + status.ToString("X8") + ")"
                    : "Signatur ungueltig (0x" + status.ToString("X8") + ")";
                return string.IsNullOrEmpty(expectedSubject);
            }

            if (string.IsNullOrEmpty(expectedSubject))
            {
                return true;
            }

            string subject = ReadSignerSubject(path);
            if (subject.IndexOf(expectedSubject, StringComparison.OrdinalIgnoreCase) < 0)
            {
                reason = "fremder Herausgeber: " + subject;
                return false;
            }

            return true;
        }

        // Laeuft beim Dienststart. Schreibt das Ergebnis ins Sicherheits-
        // protokoll und setzt nichts durch, solange kein Antragsteller
        // erwartet wird - so bleibt der heutige unsignierte Stand lauffaehig.
        private static void CheckInstalledBinarySignatures()
        {
            try
            {
                string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                string[] names = new string[]
                {
                    "PurestateGuard.exe",
                    "Purestate.exe",
                    "PurestateUninstaller.exe",
                    "PurestateNativeHost.exe"
                };

                foreach (string name in names)
                {
                    string path = Path.Combine(baseDir, name);
                    string reason;
                    if (!CheckBinarySignature(path, ExpectedSignerSubject, out reason))
                    {
                        Log("Signaturpruefung fehlgeschlagen fuer " + name + ": " + reason);
                    }
                }
            }
            catch (Exception)
            {
                // Die Selbstpruefung darf den Dienststart nie verhindern.
            }
        }

        public GuardService(string serviceName)
        {
            ServiceName = serviceName;
            CanStop = true;
            CanShutdown = true;
            CanPauseAndContinue = false;
            AutoLog = true;

            timer = new System.Timers.Timer(30000);
            timer.AutoReset = true;
            timer.Elapsed += delegate
            {
                // TCK-001: System.Timers.Timer stellt auf Threadpool-Threads zu
                // und ueberspringt keinen Takt - dauert ein Lauf laenger als 30
                // Sekunden, laeuft der naechste gleichzeitig an. Einen Takt
                // auszulassen ist harmlos (der naechste kommt in 30 Sekunden),
                // zwei Laeufe uebereinander nicht.
                if (Interlocked.Exchange(ref tickRunning, 1) == 1)
                {
                    return;
                }

                try
                {
                    EnsureCriticalInfrastructure();
                    EnforceExplicitlyDisabledCompanions();
                    VideoGamesGuard.Run(Log);
                    RunProtectionHelper(false);
                }
                finally
                {
                    Interlocked.Exchange(ref tickRunning, 0);
                }
            };

            companionPolicyTimer = new System.Timers.Timer(CompanionPolicyBusyIntervalMilliseconds);
            companionPolicyTimer.AutoReset = true;
            companionPolicyTimer.Elapsed += delegate
            {
                EnsureManagedCompanionPolicies();
            };

            // GRD-010: Chromium schreibt Preferences und Secure Preferences
            // haeufig, und die Beobachter decken den ganzen User-Data-Baum jedes
            // Profils jedes Nutzers ab. Der entprellte Weg lief bis hierher
            // denselben schweren Koerper wie der 30-s-Takt, samt Aufgaben- und
            // Richtlinienreparatur. Beides hat einen eigenen Zeitgeber; hier
            // bleibt, was wirklich an der Profiländerung haengt. Zwei Sekunden
            // statt 350 Millisekunden fassen ausserdem eine Schreibserie
            // zusammen, statt sie einzeln zu bedienen.
            browserDebounceTimer = new System.Timers.Timer(2000);
            browserDebounceTimer.AutoReset = false;
            browserDebounceTimer.Elapsed += delegate
            {
                EnforceExplicitlyDisabledCompanions();
                RunProtectionHelper(true);
            };

            // Startfuehler fuer die Restzeit-Ansage beim Spielstart (Tester-Notiz
            // 2026-10-06): eigener Zeitgeber, weil der 30-Sekunden-Takt die Ansage
            // um bis zu eine halbe Minute verspaeten wuerde. Er rechnet nichts
            // selbst und kostet waehrend eines laufenden Spiels nichts - siehe
            // VideoGamesGuard.RunStartProbe.
            videoGamesProbeTimer = new System.Timers.Timer(5000);
            videoGamesProbeTimer.AutoReset = true;
            videoGamesProbeTimer.Elapsed += delegate
            {
                if (!stopping)
                {
                    VideoGamesGuard.RunStartProbe(Log);
                }
            };
        }

        // GRD-005: .NET meldet SERVICE_RUNNING erst, wenn OnStart zurueckkehrt -
        // der SCM wartet dafuer standardmaessig 30 Sekunden. Hier lief frueher
        // die komplette erste Durchsetzung synchron: Signaturpruefung,
        // Aufgabenanlage (10 s Abfrage + 15 s Anlage je Aufgabe) und der
        // Schutzhelfer mit 90 s Zeitlimit, zusammen bis zu ~150 s. Ueberschreitet
        // das die Frist, meldet Windows Fehler 1053, und die eingestellte
        // Wiederherstellung (restart/60000) macht daraus eine Schleife, die
        // jede Minute einen weiteren Durchsetzungslauf startet.
        //
        // Synchron bleibt nur, was den Dienst arbeitsfaehig macht: der
        // Herzschlag-Server (sonst gibt es fuer den Companion keine Gegenstelle)
        // und die Zeitgeber. Der Rest laeuft einmalig im Hintergrund - der
        // 30-Sekunden-Takt haette ihn ohnehin gleich danach ausgefuehrt.
        protected override void OnStart(string[] args)
        {
            stopping = false;
            heartbeatThreads.Clear();
            for (int index = 0; index < HeartbeatPipeServerInstances; index++)
            {
                Thread thread = new Thread(HeartbeatServerLoop);
                thread.IsBackground = true;
                thread.Start();
                heartbeatThreads.Add(thread);
            }
            InitializeBrowserWatchers();
            timer.Start();
            companionPolicyTimer.Start();
            videoGamesProbeTimer.Start();
            ThreadPool.QueueUserWorkItem(delegate { RunInitialEnforcement(); });
        }

        private void RunInitialEnforcement()
        {
            try
            {
                CheckInstalledBinarySignatures();
                EnsureCriticalInfrastructure();
                EnforceExplicitlyDisabledCompanions();
                VideoGamesGuard.Run(Log);
                RunProtectionHelper(false);
            }
            catch (Exception ex)
            {
                // Eine unbehandelte Ausnahme im ThreadPool beendet den ganzen
                // Prozess. Der naechste Takt versucht es in 30 Sekunden erneut.
                Log("Initial enforcement failed: " + ex.Message);
            }
        }

        protected override void OnStop()
        {
            // GRD-014: "Stop" hiess bisher nur "hoer auf einzuplanen". Der
            // Schutzhelfer lief als SYSTEM weiter - bis zu 90 Sekunden nachdem
            // Windows den Dienst als GESTOPPT meldete, was bei Deinstallation
            // und Aktualisierung genau das falsche Bild ergibt. Die Bedienfaeden
            // wurden als Hintergrundfaeden beim Prozessende hart abgeraeumt,
            // moeglicherweise zwischen Schreiben und Ersetzen einer
            // Zustandsdatei. Und ein Herunterfahren erreichte den Dienst mangels
            // CanShutdown gar nicht.
            stopping = true;
            timer.Stop();
            companionPolicyTimer.Stop();
            browserDebounceTimer.Stop();
            videoGamesProbeTimer.Stop();
            foreach (FileSystemWatcher watcher in browserWatchers)
            {
                watcher.Dispose();
            }
            browserWatchers.Clear();

            Process helper = runningProtectionHelper;
            if (helper != null)
            {
                try
                {
                    if (!helper.HasExited)
                    {
                        helper.Kill();
                    }
                }
                catch
                {
                    // Beendet, nie gestartet oder nicht mehr erreichbar - in
                    // allen drei Faellen gibt es nichts mehr abzubrechen.
                }
            }

            foreach (Thread thread in heartbeatThreads)
            {
                // Begrenzt: ein Faden, der nicht zurueckkehrt, darf das Stoppen
                // nicht aufhalten. Der Poll-Takt der Verbindungsschleife ist
                // eine Sekunde, drei sind also reichlich.
                thread.Join(3000);
            }
            heartbeatThreads.Clear();
        }

        protected override void OnShutdown()
        {
            OnStop();
        }

        internal static bool TryParseHeartbeatMessage(string message, out string browser, out string version)
        {
            browser = string.Empty;
            version = string.Empty;
            string[] parts = (message ?? string.Empty).Split('|');
            if (parts.Length != 2 || (parts[0] != "Chrome" && parts[0] != "Edge") ||
                !Regex.IsMatch(parts[1], @"^\d+\.\d+\.\d+$"))
            {
                return false;
            }
            browser = parts[0];
            version = parts[1];
            return true;
        }

        private void HeartbeatServerLoop()
        {
            while (!stopping)
            {
                try
                {
                    using (NamedPipeServerStream pipe = CreateHeartbeatPipe())
                    {
                        if (!WaitForHeartbeatConnection(pipe))
                        {
                            continue;
                        }

                        uint clientProcessId = GetHeartbeatClientProcessId(pipe);
                        string browser;
                        string version;
                        string heartbeatMessage = string.Empty;
                        string rejectionReason = string.Empty;
                        bool canRespond = true;
                        try
                        {
                            heartbeatMessage = ReadHeartbeatMessage(pipe);
                        }
                        catch (System.TimeoutException)
                        {
                            rejectionReason = "heartbeat read timed out";
                            canRespond = false;
                        }
                        catch (InvalidDataException ex)
                        {
                            rejectionReason = ex.Message;
                        }

                        if (string.IsNullOrWhiteSpace(rejectionReason) && IsUsageMessage(heartbeatMessage))
                        {
                            string usageResponse;
                            if (IsTrustedHeartbeatClient(clientProcessId, out rejectionReason))
                            {
                                lock (webUsageSync)
                                {
                                    usageResponse = HandleUsageMessage(
                                        heartbeatMessage,
                                        WebUsagePath,
                                        ReadClockAnchorLocal().ToString("yyyy-MM-dd"),
                                        webUsageTokens);
                                }
                            }
                            else
                            {
                                Log("Usage message rejected: " + rejectionReason);
                                usageResponse = "ERROR|untrusted-client";
                            }
                            WriteHeartbeatResponse(pipe, usageResponse);
                        }
                        else if (string.IsNullOrWhiteSpace(rejectionReason) && IsLearnHostMessage(heartbeatMessage))
                        {
                            string learnResponse;
                            if (IsTrustedHeartbeatClient(clientProcessId, out rejectionReason))
                            {
                                lock (learnHostSync)
                                {
                                    learnResponse = HandleLearnHostMessage(
                                        heartbeatMessage,
                                        LearnedAdultDomainsPath,
                                        learnHostTokens);
                                }
                            }
                            else
                            {
                                Log("Learn-host message rejected: " + rejectionReason);
                                learnResponse = "ERROR|untrusted-client";
                            }
                            WriteHeartbeatResponse(pipe, learnResponse);
                        }
                        else if (string.IsNullOrWhiteSpace(rejectionReason) && IsCanaryMessage(heartbeatMessage))
                        {
                            string canaryResponse;
                            if (IsTrustedHeartbeatClient(clientProcessId, out rejectionReason))
                            {
                                lock (infrastructureSync)
                                {
                                    // Befund #2: wie ReadActiveCanaryFailClosedDomains - ohne
                                    // den Bereich Erwachseneninhalte darf auch dieser Pfad
                                    // nichts sperren.
                                    bool policyChanged = HandleCanaryMessage(
                                        heartbeatMessage,
                                        CanaryFailClosedPath,
                                        ReadClockAnchorUtc(),
                                        delegate(string field) { return ReadSiteProtectionConfigBool(field, true) && ReadSiteProtectionConfigBool("AdultContentProtectionEnabled", true); },
                                        out canaryResponse);
                                    if (policyChanged)
                                    {
                                        ApplyCanaryFailClosedPolicy("Chrome", "Chrome canary fail-closed refreshed after selector canary miss.", true);
                                        ApplyCanaryFailClosedPolicy("Edge", "Edge canary fail-closed refreshed after selector canary miss.", true);
                                    }
                                }
                            }
                            else
                            {
                                Log("Canary message rejected: " + rejectionReason);
                                canaryResponse = "ERROR|untrusted-client";
                            }
                            WriteHeartbeatResponse(pipe, canaryResponse);
                        }
                        else if (string.IsNullOrWhiteSpace(rejectionReason) &&
                            TryParseHeartbeatMessage(heartbeatMessage, out browser, out version) &&
                            IsTrustedHeartbeatClient(clientProcessId, out rejectionReason))
                        {
                            WriteHeartbeat(browser, version);
                            WriteHeartbeatResponse(pipe, "OK");
                            lock (runSync)
                            {
                                browserDebounceTimer.Stop();
                                browserDebounceTimer.Start();
                            }
                        }
                        else
                        {
                            if (string.IsNullOrWhiteSpace(rejectionReason))
                            {
                                rejectionReason = "invalid heartbeat message";
                            }

                            Log("Heartbeat rejected: " + rejectionReason);
                            if (canRespond)
                            {
                                WriteHeartbeatResponse(pipe, "ERROR");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (!stopping)
                    {
                        Log("Heartbeat server error: " + ex.Message);
                        Thread.Sleep(1000);
                    }
                }
            }
        }

        private static NamedPipeServerStream CreateHeartbeatPipe()
        {
            PipeSecurity security = new PipeSecurity();
            security.AddAccessRule(new PipeAccessRule(
                new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null),
                PipeAccessRights.FullControl,
                AccessControlType.Allow));
            security.AddAccessRule(new PipeAccessRule(
                new SecurityIdentifier(WellKnownSidType.AuthenticatedUserSid, null),
                PipeAccessRights.ReadWrite,
                AccessControlType.Allow));
            return new NamedPipeServerStream(
                HeartbeatPipeName,
                PipeDirection.InOut,
                HeartbeatPipeServerInstances,
                PipeTransmissionMode.Byte,
                PipeOptions.Asynchronous,
                4096,
                4096,
                security);
        }

        private bool WaitForHeartbeatConnection(NamedPipeServerStream pipe)
        {
            IAsyncResult result = pipe.BeginWaitForConnection(null, null);
            WaitHandle waitHandle = result.AsyncWaitHandle;
            try
            {
                while (!stopping)
                {
                    if (waitHandle.WaitOne(HeartbeatPipeConnectionPollMilliseconds))
                    {
                        pipe.EndWaitForConnection(result);
                        return true;
                    }
                }

                return false;
            }
            catch (ObjectDisposedException)
            {
                return false;
            }
            finally
            {
                waitHandle.Close();
            }
        }

        // GRD-018: Gelesen wurde frueher EIN Byte je asynchroner Runde - bis zu
        // 128 Rundreisen und 128 Wartehandles je Nachricht. Mit der groesseren
        // Nachrichtengrenze aus GRD-017 waeren es 512 geworden. Jetzt liest eine
        // Runde, was da ist, und die Zeile wird im Speicher abgetrennt.
        //
        // Die drei Eigenschaften der alten Schleife bleiben: '\r' faellt weg,
        // '\n' beendet die Nachricht, und mehr als MaxHeartbeatMessageBytes
        // Nutzlast ist ein Fehler. Was nach dem '\n' im Puffer steht, wird wie
        // vorher verworfen - je Verbindung wird genau eine Zeile bedient.
        internal static string ReadHeartbeatMessage(PipeStream pipe)
        {
            byte[] buffer = new byte[MaxHeartbeatMessageBytes];
            using (MemoryStream message = new MemoryStream())
            {
                DateTime deadline = DateTime.UtcNow.AddMilliseconds(HeartbeatPipeReadTimeoutMilliseconds);
                while (true)
                {
                    int remaining = (int)Math.Ceiling((deadline - DateTime.UtcNow).TotalMilliseconds);
                    if (remaining <= 0)
                    {
                        throw new System.TimeoutException("Heartbeat message timed out.");
                    }

                    int free = MaxHeartbeatMessageBytes - (int)message.Length;
                    if (free <= 0)
                    {
                        throw new InvalidDataException("heartbeat message too long");
                    }

                    IAsyncResult result = pipe.BeginRead(buffer, 0, free, null, null);
                    WaitHandle waitHandle = result.AsyncWaitHandle;
                    try
                    {
                        if (!waitHandle.WaitOne(remaining))
                        {
                            throw new System.TimeoutException("Heartbeat message timed out.");
                        }

                        int read = pipe.EndRead(result);
                        if (read <= 0)
                        {
                            return Encoding.UTF8.GetString(message.ToArray());
                        }

                        for (int index = 0; index < read; index++)
                        {
                            byte value = buffer[index];
                            if (value == (byte)'\n')
                            {
                                return Encoding.UTF8.GetString(message.ToArray());
                            }

                            if (value != (byte)'\r')
                            {
                                message.WriteByte(value);
                            }
                        }
                    }
                    finally
                    {
                        // GRD-015: Das Schliessen hing frueher an "completed" -
                        // genau auf dem Zeitweg, den ein Anrufer ohne Daten
                        // beliebig oft ausloesen kann, blieb also je Verbindung
                        // ein Handle und eine offene Leseanforderung liegen. Das
                        // Schliessen ist ungefaehrlich, auch wenn die Leseanfrage
                        // noch laeuft: die Pipe wird auf diesem Weg unmittelbar
                        // danach verworfen.
                        waitHandle.Close();
                    }
                }
            }
        }

        private static void WriteHeartbeatResponse(NamedPipeServerStream pipe, string response)
        {
            try
            {
                byte[] bytes = Encoding.ASCII.GetBytes(BuildHeartbeatResponse(response) + "\n");
                pipe.Write(bytes, 0, bytes.Length);
                pipe.Flush();
            }
            catch
            {
            }
        }

        private static string BuildHeartbeatResponse(string response)
        {
            if (!string.Equals(response, "OK", StringComparison.Ordinal))
            {
                return response;
            }

            string adultMode = ReadSiteProtectionConfigBool("AdultContentProtectionEnabled", true) ? "strict" : "off";
            string gamblingMode = ReadEffectiveGamblingProtectionConfigBool() ? "strict" : "off";
            return "OK|adult-content=" + adultMode + "|gambling=" + gamblingMode;
        }

        private static uint GetHeartbeatClientProcessId(NamedPipeServerStream pipe)
        {
            uint processId;
            return GetNamedPipeClientProcessId(pipe.SafePipeHandle.DangerousGetHandle(), out processId) ? processId : 0;
        }

        private static bool IsTrustedHeartbeatClient(uint processId, out string rejectionReason)
        {
            rejectionReason = string.Empty;
            if (processId == 0)
            {
                rejectionReason = "client process id unavailable";
                return false;
            }

            try
            {
                using (Process client = Process.GetProcessById((int)processId))
                {
                    string clientPath = client.MainModule == null ? string.Empty : client.MainModule.FileName;
                    return IsTrustedHeartbeatClientProcess(
                        clientPath,
                        AppDomain.CurrentDomain.BaseDirectory,
                        out rejectionReason);
                }
            }
            catch (Exception ex)
            {
                rejectionReason = "client identity check failed: " + ex.Message;
                return false;
            }
        }

        // LEAD-002: Diese Ueberladung nahm frueher zusaetzlich parentProcessName
        // und browser entgegen und ignorierte beide. Zusammen mit der Zusage im
        // Threat Model ("only ... when it is launched by the expected browser
        // process") sah das nach einer Eltern-Prozess-Pruefung aus, die es nie
        // gab. Die Parameter sind weg, die Zusage ist korrigiert: geprueft wird
        // der Bildpfad, und sonst nichts.
        internal static bool IsTrustedHeartbeatClientProcess(string clientPath, string baseDir)
        {
            string rejectionReason;
            return IsTrustedHeartbeatClientProcess(clientPath, baseDir, out rejectionReason);
        }

        private static bool IsTrustedHeartbeatClientProcess(string clientPath, string baseDir, out string rejectionReason)
        {
            rejectionReason = string.Empty;
            if (string.IsNullOrWhiteSpace(clientPath))
            {
                rejectionReason = "client path missing";
                return false;
            }

            string expectedHost = Path.GetFullPath(Path.Combine(baseDir ?? string.Empty, "PurestateNativeHost.exe"));
            string actualHost;
            try
            {
                actualHost = Path.GetFullPath(clientPath);
            }
            catch
            {
                rejectionReason = "client path invalid";
                return false;
            }

            if (!string.Equals(actualHost, expectedHost, StringComparison.OrdinalIgnoreCase))
            {
                rejectionReason = "client host mismatch: " + actualHost;
                return false;
            }
            return true;
        }

        private static void EnsureDataDirectoryIsNotReparsePoint(string path)
        {
            if (!Directory.Exists(path))
            {
                return;
            }
            FileAttributes attributes = File.GetAttributes(path);
            if ((attributes & FileAttributes.ReparsePoint) != 0)
            {
                throw new InvalidOperationException("Das Purestate-Datenverzeichnis darf kein Verknuepfungs- oder Reparse-Punkt sein.");
            }
        }

        private static void WriteHeartbeat(string browser, string version)
        {
            string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Purestate");
            Directory.CreateDirectory(dataDir);
            EnsureDataDirectoryIsNotReparsePoint(dataDir);
            string path = Path.Combine(dataDir, browser.ToLowerInvariant() + "-companion-heartbeat.txt");
            File.WriteAllText(path, version + "|" + DateTime.UtcNow.ToString("o"), new UTF8Encoding(false));
        }

        private static void DeleteHeartbeat(string browser)
        {
            try
            {
                string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Purestate");
                EnsureDataDirectoryIsNotReparsePoint(dataDir);
                string path = Path.Combine(dataDir, browser.ToLowerInvariant() + "-companion-heartbeat.txt");
                if (File.Exists(path)) File.Delete(path);
            }
            catch (Exception ex)
            {
                // GRD-021: Dieses Loeschen IST das Signal an die
                // PowerShell-Seite, dass der Companion weg ist. Scheitert es,
                // steht dort weiter ein frischer Lebendbeweis, waehrend die
                // harte Sperre schon laeuft. Die Wirkung ist begrenzt - die
                // Datei veraltet von selbst nach
                // CompanionHeartbeatMaxAgeSeconds -, also eine Verzoegerung und
                // kein dauerhaftes Loch. Unsichtbar durfte sie trotzdem nicht
                // bleiben.
                Log("Heartbeat for " + browser + " could not be deleted (" + ex.GetType().Name +
                    "); the stale liveness file expires on its own.");
            }
        }

        internal static bool IsBrowserPreferencesFile(string path)
        {
            string name = Path.GetFileName(path ?? string.Empty);
            return name.Equals("Preferences", StringComparison.OrdinalIgnoreCase) ||
                name.Equals("Secure Preferences", StringComparison.OrdinalIgnoreCase);
        }

        // ---- Web time-budget usage store (persistent daily counters) ----------
        // Guard-authoritative daily seconds for the Social-Media/Shopping/
        // Gambling web budgets. The companion only measures foreground time and
        // reports deltas; the totals live in the ACL-protected data dir so
        // clearing browser data, a second browser or a fresh profile no longer
        // resets a "daily" budget. Missing/corrupt state fails open (0 used,
        // never a lockout); the day only ever rolls forward (clock-back safe).

        private const int MaxWebUsageReportSeconds = 120;
        private const long MaxWebUsageFileBytes = 8192;
        // GRD-019: Dieser Schutz gegen doppelt gesendete Meldungen ist ein
        // CACHE, keine gesicherte Eigenschaft, und das soll hier stehen statt
        // stillschweigend angenommen zu werden. Er liegt im Arbeitsspeicher,
        // gilt fuer Chrome und Edge gemeinsam und ist nach jedem Dienstneustart
        // leer. Zwei Folgen: nach einem Neustart bucht eine erneut gesendete
        // Bestellung ein zweites Mal, und ab der 65. verschraenkten Meldung
        // faellt die aelteste Kennung heraus.
        //
        // Beides geht in die STRENGE Richtung - es wird zu viel gezaehlt, nie
        // zu wenig -, deshalb bleibt es fuer die Beta so. Wer Genauigkeit
        // braucht, muss die letzten N Kennungen neben den Zaehlern
        // festschreiben, die sie schuetzen.
        private const int MaxWebUsageTokenHistory = 64;
        private static readonly object webUsageSync = new object();
        private static readonly List<string> webUsageTokens = new List<string>();

        internal sealed class WebUsageState
        {
            public string Day = string.Empty;
            public string Month = string.Empty;
            public int MonthOrders;
            public int MonthSpendEuro;
            public readonly Dictionary<string, int> Areas = new Dictionary<string, int>(StringComparer.Ordinal);
        }

        private static string WebUsagePath
        {
            get
            {
                string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Purestate");
                return Path.Combine(dataDir, "usage.json");
            }
        }

        internal static bool IsUsageMessage(string message)
        {
            string[] parts = (message ?? string.Empty).Split('|');
            return parts.Length >= 3 && (parts[2] == "usage-report" || parts[2] == "usage-query" ||
                parts[2] == "usage-order" || parts[2] == "usage-order-query" ||
                parts[2] == "usage-spend");
        }

        private static string MonthOfDay(string day)
        {
            return day != null && day.Length >= 7 ? day.Substring(0, 7) : string.Empty;
        }

        internal static WebUsageState LoadWebUsageState(string path, string currentDay)
        {
            string currentMonth = MonthOfDay(currentDay);
            try
            {
                if (!File.Exists(path))
                {
                    return new WebUsageState { Day = currentDay, Month = currentMonth };
                }

                FileInfo info = new FileInfo(path);
                if (info.Length > MaxWebUsageFileBytes)
                {
                    return new WebUsageState { Day = currentDay, Month = currentMonth };
                }

                string json = File.ReadAllText(path, Encoding.UTF8);
                Match dayMatch = Regex.Match(json, "\"day\"\\s*:\\s*\"(\\d{4}-\\d{2}-\\d{2})\"");
                if (!dayMatch.Success)
                {
                    return new WebUsageState { Day = currentDay, Month = currentMonth };
                }

                WebUsageState state = new WebUsageState { Day = currentDay, Month = currentMonth };
                string storedDay = dayMatch.Groups[1].Value;
                // Day and month roll independently, each only forward (a clock
                // turned back never grants a fresh budget or order allowance).
                if (!VideoGamesGuard.ShouldResetDay(storedDay, currentDay))
                {
                    state.Day = storedDay;
                    Match areasMatch = Regex.Match(json, "\"areas\"\\s*:\\s*\\{([^}]*)\\}");
                    if (areasMatch.Success)
                    {
                        foreach (Match entry in Regex.Matches(areasMatch.Groups[1].Value, "\"([a-z0-9:-]{1,64})\"\\s*:\\s*(\\d{1,9})"))
                        {
                            state.Areas[entry.Groups[1].Value] = int.Parse(entry.Groups[2].Value);
                        }
                    }
                }

                Match monthMatch = Regex.Match(json, "\"month\"\\s*:\\s*\"(\\d{4}-\\d{2})\"");
                if (monthMatch.Success)
                {
                    string storedMonth = monthMatch.Groups[1].Value;
                    if (!VideoGamesGuard.ShouldResetDay(storedMonth, currentMonth))
                    {
                        state.Month = storedMonth;
                        Match ordersMatch = Regex.Match(json, "\"monthOrders\"\\s*:\\s*(\\d{1,9})");
                        Match spendMatch = Regex.Match(json, "\"monthSpendEuro\"\\s*:\\s*(\\d{1,9})");
                        state.MonthOrders = ordersMatch.Success ? int.Parse(ordersMatch.Groups[1].Value) : 0;
                        state.MonthSpendEuro = spendMatch.Success ? int.Parse(spendMatch.Groups[1].Value) : 0;
                    }
                }
                return state;
            }
            catch
            {
                // Damaged runtime data: start fresh counters, never throw.
                return new WebUsageState { Day = currentDay, Month = currentMonth };
            }
        }

        internal static string BuildWebUsageJson(WebUsageState state)
        {
            StringBuilder json = new StringBuilder();
            json.Append("{\"day\":\"").Append(state.Day).Append("\",");
            json.Append("\"month\":\"").Append(state.Month).Append("\",");
            json.Append("\"monthOrders\":").Append(Math.Max(0, state.MonthOrders)).Append(',');
            json.Append("\"monthSpendEuro\":").Append(Math.Max(0, state.MonthSpendEuro)).Append(',');
            json.Append("\"areas\":{");
            List<string> keys = new List<string>(state.Areas.Keys);
            keys.Sort(StringComparer.Ordinal);
            for (int i = 0; i < keys.Count; i++)
            {
                if (i > 0)
                {
                    json.Append(',');
                }
                json.Append('"').Append(keys[i]).Append("\":").Append(Math.Max(0, state.Areas[keys[i]]));
            }
            json.Append("}}");
            return json.ToString();
        }

        // GRD-002: Der Rueckgabewert ist der Punkt. Frueher verschluckte diese
        // Methode jeden Fehler, und der Aufrufer hatte den Token schon
        // verbrannt: die Sekunden waren weg, der Companion bekam "OK" mit
        // Zahlen, die nie auf der Platte standen, und der identische zweite
        // Versuch galt als Dublette. Fuer jedes Web-Budget ist das die
        // fail-open-Richtung. SaveLearnedAdultHosts macht es eine Bildschirmhoehe
        // weiter unten laengst richtig.
        private static bool SaveWebUsageState(string path, WebUsageState state)
        {
            try
            {
                string json = BuildWebUsageJson(state);
                ReplaceFileAtomically(path, delegate(string temp)
                {
                    File.WriteAllText(temp, json, new UTF8Encoding(false));
                });
                return true;
            }
            catch
            {
                return false;
            }
        }

        private static bool IsValidUsageAreaAndPlatform(string area, string platform, bool platformRequired)
        {
            if (area != "social" && area != "shopping" && area != "gambling")
            {
                return false;
            }
            if (area != "social")
            {
                return platform.Length == 0;
            }
            if (platform.Length == 0)
            {
                return !platformRequired;
            }
            return Regex.IsMatch(platform, "^[a-z0-9-]{1,32}$");
        }

        private static string BuildUsageTotalsResponse(WebUsageState state, string area, string platform)
        {
            string totalKey = area == "social" ? "social:global" : area;
            int total;
            state.Areas.TryGetValue(totalKey, out total);
            int platformSeconds = 0;
            if (area == "social" && platform.Length > 0)
            {
                state.Areas.TryGetValue("social:" + platform, out platformSeconds);
            }
            return "OK|total=" + total + "|platform=" + platformSeconds;
        }

        // Message grammar (line-based, same pipe as the heartbeat):
        //   <browser>|<version>|usage-report|<area>|<platform>|<delta>|<token>
        //   <browser>|<version>|usage-query|<area>|<platform>
        internal static string HandleUsageMessage(string message, string usagePath, string currentDay, List<string> recentTokens)
        {
            string[] parts = (message ?? string.Empty).Split('|');
            if (parts.Length < 3)
            {
                return "ERROR|bad-usage-message";
            }
            if ((parts[0] != "Chrome" && parts[0] != "Edge") || !Regex.IsMatch(parts[1], @"^\d+\.\d+\.\d+$"))
            {
                return "ERROR|bad-usage-client";
            }

            if (parts[2] == "usage-query")
            {
                if (parts.Length != 5 || !IsValidUsageAreaAndPlatform(parts[3], parts[4], false))
                {
                    return "ERROR|bad-usage-message";
                }
                return BuildUsageTotalsResponse(LoadWebUsageState(usagePath, currentDay), parts[3], parts[4]);
            }

            if (parts[2] == "usage-order-query")
            {
                if (parts.Length != 3)
                {
                    return "ERROR|bad-usage-message";
                }
                WebUsageState queried = LoadWebUsageState(usagePath, currentDay);
                return "OK|orders=" + queried.MonthOrders + "|spend=" + queried.MonthSpendEuro;
            }

            // Shopping monthly order counter: every confirmed order counts one,
            // the euro amount is an optional self-reported estimate.
            //   <browser>|<version>|usage-order|<amountEuro-or-empty>|<token>
            if (parts[2] == "usage-order")
            {
                if (parts.Length != 5)
                {
                    return "ERROR|bad-usage-message";
                }
                string amountText = parts[3];
                if (amountText.Length > 0 && !Regex.IsMatch(amountText, "^\\d{1,5}$"))
                {
                    return "ERROR|bad-usage-amount";
                }
                if (!Regex.IsMatch(parts[4], "^[a-z0-9-]{8,40}$"))
                {
                    return "ERROR|bad-usage-token";
                }

                WebUsageState orderState = LoadWebUsageState(usagePath, currentDay);
                string orderToken = parts[4];
                if (!recentTokens.Contains(orderToken))
                {
                    recentTokens.Add(orderToken);
                    while (recentTokens.Count > MaxWebUsageTokenHistory)
                    {
                        recentTokens.RemoveAt(0);
                    }
                    orderState.MonthOrders = (int)Math.Min((long)orderState.MonthOrders + 1, int.MaxValue);
                    if (amountText.Length > 0)
                    {
                        orderState.MonthSpendEuro = (int)Math.Min((long)orderState.MonthSpendEuro + int.Parse(amountText), int.MaxValue);
                    }
                    if (!SaveWebUsageState(usagePath, orderState))
                    {
                        recentTokens.Remove(orderToken);
                        return "ERROR|usage-write-failed";
                    }
                }
                return "OK|orders=" + orderState.MonthOrders + "|spend=" + orderState.MonthSpendEuro;
            }

            // Nachtrag des Betrags zu einer bereits gezaehlten Bestellung.
            // Live gefunden (2026-08-07, Amazon): die Kaufverzoegerung greift auf
            // der ersten Kassenseite, die Summe steht erst einen Schritt spaeter.
            // Ueber usage-order liesse sich das nicht nachtragen - jede solche
            // Nachricht zaehlt eine weitere Bestellung.
            //   <browser>|<version>|usage-spend|<amountEuro>|<token>
            if (parts[2] == "usage-spend")
            {
                if (parts.Length != 5)
                {
                    return "ERROR|bad-usage-message";
                }
                // Der Betrag ist hier Pflicht: ohne ihn gaebe es nichts nachzutragen.
                if (!Regex.IsMatch(parts[3], "^\\d{1,5}$"))
                {
                    return "ERROR|bad-usage-amount";
                }
                if (!Regex.IsMatch(parts[4], "^[a-z0-9-]{8,40}$"))
                {
                    return "ERROR|bad-usage-token";
                }

                WebUsageState spendState = LoadWebUsageState(usagePath, currentDay);
                string spendToken = parts[4];
                if (!recentTokens.Contains(spendToken))
                {
                    recentTokens.Add(spendToken);
                    while (recentTokens.Count > MaxWebUsageTokenHistory)
                    {
                        recentTokens.RemoveAt(0);
                    }
                    spendState.MonthSpendEuro = (int)Math.Min((long)spendState.MonthSpendEuro + int.Parse(parts[3]), int.MaxValue);
                    if (!SaveWebUsageState(usagePath, spendState))
                    {
                        recentTokens.Remove(spendToken);
                        return "ERROR|usage-write-failed";
                    }
                }
                return "OK|orders=" + spendState.MonthOrders + "|spend=" + spendState.MonthSpendEuro;
            }

            if (parts[2] != "usage-report" || parts.Length != 7)
            {
                return "ERROR|bad-usage-message";
            }
            string area = parts[3];
            string platform = parts[4];
            if (!IsValidUsageAreaAndPlatform(area, platform, true))
            {
                return "ERROR|bad-usage-area";
            }
            if (!Regex.IsMatch(parts[5], "^\\d{1,6}$"))
            {
                return "ERROR|bad-usage-delta";
            }
            if (!Regex.IsMatch(parts[6], "^[a-z0-9-]{8,40}$"))
            {
                return "ERROR|bad-usage-token";
            }

            int delta = Math.Min(int.Parse(parts[5]), MaxWebUsageReportSeconds);
            WebUsageState state = LoadWebUsageState(usagePath, currentDay);
            string token = parts[6];
            if (delta > 0 && !recentTokens.Contains(token))
            {
                recentTokens.Add(token);
                while (recentTokens.Count > MaxWebUsageTokenHistory)
                {
                    recentTokens.RemoveAt(0);
                }

                string totalKey = area == "social" ? "social:global" : area;
                // Streaming fuehrt ein eigenes Budget (Tester-Notiz 2026-10-06): seine
                // Zeit zaehlt nur unter social:streaming, nicht ins gemeinsame
                // Social-Media-Limit. Gespiegelt in Support.SocialMediaOwnBudgetPlatformIds.
                if (!(area == "social" && platform == "streaming"))
                {
                    int current;
                    state.Areas.TryGetValue(totalKey, out current);
                    state.Areas[totalKey] = (int)Math.Min((long)current + delta, int.MaxValue);
                }
                if (area == "social")
                {
                    int platformCurrent;
                    state.Areas.TryGetValue("social:" + platform, out platformCurrent);
                    state.Areas["social:" + platform] = (int)Math.Min((long)platformCurrent + delta, int.MaxValue);
                }
                if (!SaveWebUsageState(usagePath, state))
                {
                    recentTokens.Remove(token);
                    return "ERROR|usage-write-failed";
                }
            }
            return BuildUsageTotalsResponse(state, area, platform);
        }

        // ---- Gelernte Erwachsenen-Hosts -------------------------------------------
        //
        // Der Companion meldet nur, was er selbst hart erkannt hat. Geschrieben wird
        // nach ProgramData, nicht in den Regelordner der Installation: der Ordner ist
        // Auslieferungsstand und wird beim Update ersetzt, ProgramData ist per icacls
        // auf SYSTEM und Administratoren gesperrt (NativeSupportEnforcement.cs:717).
        internal const int LearnedAdultDomainCap = 500;

        private static readonly object learnHostSync = new object();
        private static readonly List<string> learnHostTokens = new List<string>();

        // Dieselbe Liste wie NEVER_BLOCK_HOSTS in adult-detect.js, hier ein zweites
        // Mal: ein manipuliertes Content-Script soll bzga.de nicht in die
        // Systemsperre bekommen. Die Pruefung beim Erkennen allein reicht dafuer
        // nicht. Ein Test pinnt beide Listen gegeneinander (Purestate.Tests.ps1),
        // sonst bliebe die Doppelpflege unbemerkt auseinanderlaufen.
        private static readonly string[] LearnNeverBlockHosts =
        {
            "bzga.de",
            "profamilia.de",
            "loveline.de",
            "sextra.de",
            "liebesleben.de",
            "gesundheitsinformation.de",
            "bundesgesundheitsministerium.de",
            "wikipedia.org",
            "who.int",
            "telefonseelsorge.de"
        };

        // Dasselbe strenge Muster wie ADULT_HOST_SHAPE in background.js: nur
        // Kleinbuchstaben, Ziffern, Bindestrich und Punkt, kein Schema, kein Pfad.
        private static readonly Regex LearnHostShape =
            new Regex(@"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$");

        private static string LearnedAdultDomainsPath
        {
            get
            {
                string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Purestate");
                return Path.Combine(dataDir, "learned-adult-domains.txt");
            }
        }

        internal static bool IsLearnHostMessage(string message)
        {
            string[] parts = (message ?? string.Empty).Split('|');
            return parts.Length >= 3 && parts[2] == "learn-host";
        }

        private static bool IsLearnNeverBlockHost(string host)
        {
            foreach (string entry in LearnNeverBlockHosts)
            {
                // Suffix-Semantik: exakt oder Unterdomain, nie Teilzeichenkette.
                if (host == entry || host.EndsWith("." + entry, StringComparison.Ordinal))
                {
                    return true;
                }
            }
            return false;
        }

        // Kaputter Inhalt wird wie eine leere Datei behandelt: Zeilen, die nicht wie
        // ein Hostname aussehen, fallen beim Laden einfach heraus. Die kuratierten
        // Listen sollen weiterlaufen, auch wenn diese Datei beschaedigt ist.
        private static List<string> LoadLearnedAdultHosts(string path)
        {
            try
            {
                List<string> hosts = new List<string>();
                if (!File.Exists(path))
                {
                    return hosts;
                }
                foreach (string line in File.ReadAllLines(path, Encoding.UTF8))
                {
                    string host = line.Trim();
                    if (LearnHostShape.IsMatch(host))
                    {
                        hosts.Add(host);
                    }
                }
                return hosts;
            }
            catch
            {
                return new List<string>();
            }
        }

        // Gibt false zurueck, wenn nichts geschrieben wurde. Der Aufrufer meldet
        // das als Fehlschlag: ein "OK" auf eine Zeile, die nirgends steht, haette
        // dem Companion eine Sperre bestaetigt, die es nicht gibt.
        private static bool SaveLearnedAdultHosts(string path, List<string> hosts)
        {
            try
            {
                ReplaceFileAtomically(path, delegate(string temp)
                {
                    File.WriteAllLines(temp, hosts, new UTF8Encoding(false));
                });
                return true;
            }
            catch
            {
                return false;
            }
        }

        // Nachrichten-Grammatik (derselbe Pipe wie der Heartbeat):
        //   <browser>|<version>|learn-host|adult|<hostname>|<token>
        internal static string HandleLearnHostMessage(string message, string learnedPath, List<string> recentTokens)
        {
            string[] parts = (message ?? string.Empty).Split('|');
            if (parts.Length != 6 || parts[2] != "learn-host" || parts[3] != "adult")
            {
                return "IGNORED";
            }

            // Befund #3: gelernte Hosts sind Erwachseneninhalte-Feinfilter
            // (Spec 2.4) - ohne den Bereich selbst lernt der Guard nichts.
            if (!ReadSiteProtectionConfigBool("AdultContentProtectionEnabled", true))
            {
                return "IGNORED";
            }

            string host = parts[4];
            if (host.Length == 0 || host.Length > 253 || !LearnHostShape.IsMatch(host) || IsLearnNeverBlockHost(host))
            {
                return "IGNORED";
            }

            string token = parts[5];
            if (token.Length == 0)
            {
                return "IGNORED";
            }

            List<string> hosts = LoadLearnedAdultHosts(learnedPath);
            if (!recentTokens.Contains(token))
            {
                recentTokens.Add(token);
                while (recentTokens.Count > MaxWebUsageTokenHistory)
                {
                    recentTokens.RemoveAt(0);
                }
                // learnHostTokens ist nur ein In-Memory-Verlauf und leert sich bei
                // jedem Dienst-Neustart - derselbe Host wird also routinemaessig
                // unter einem frischen Token erneut gemeldet. Ohne diese Zeile wuerde
                // jede solche Wiederholung eine weitere Zeile anhaengen und mit der
                // Zeit echte, seltener besuchte Hosts aus den 500 Plaetzen verdraengen.
                // Remove-vor-Add haelt den Host zugleich am Ende jung, damit ein
                // aktiv wiederbesuchter Host nicht veraltet, waehrend ein einmaliger
                // Treffer aus der Vergangenheit haengen bleibt.
                hosts.Remove(host);
                hosts.Add(host);
                while (hosts.Count > LearnedAdultDomainCap)
                {
                    hosts.RemoveAt(0);
                }
                if (!SaveLearnedAdultHosts(learnedPath, hosts))
                {
                    // Das Token wieder freigeben, sonst waere der naechste Versuch
                    // fuer denselben Treffer als Doppelmeldung abgetan und der Host
                    // bliebe dauerhaft ungeschrieben.
                    recentTokens.Remove(token);
                    return "ERROR|learn-write-failed";
                }
            }
            return "OK|learned=" + hosts.Count;
        }

        private static string GetDevCompanionId()
        {
            // ENS-001: siehe NativeSupportEnforcement.cs - im ausgelieferten Bau
            // ist dieser Zweig nicht vorhanden, nicht nur ausgeschaltet.
#if !PURESTATE_DEV
            return string.Empty;
#else
            try
            {
                string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "dev-companion-id.txt");
                if (!File.Exists(path))
                {
                    return string.Empty;
                }

                string id = File.ReadAllText(path).Trim();
                return Regex.IsMatch(id, "^[a-p]{32}$") ? id : string.Empty;
            }
            catch
            {
                return string.Empty;
            }
#endif
        }

        internal static bool IsCompanionExplicitlyDisabledJson(string json)
        {
            return IsCompanionExplicitlyDisabledJson(json, CompanionStoreId);
        }

        internal static bool IsCompanionExplicitlyDisabledJson(string json, string extensionId)
        {
            if (string.IsNullOrWhiteSpace(extensionId))
            {
                return false;
            }

            string entry = ExtractJsonObjectForProperty(json ?? string.Empty, extensionId);
            if (entry.Length == 0)
            {
                return false;
            }

            Match reasons = Regex.Match(entry, "\\\"disable_reasons\\\"\\s*:\\s*(?<value>\\[[^\\]]*\\]|-?\\d+)", RegexOptions.IgnoreCase);
            if (reasons.Success && Regex.IsMatch(reasons.Groups["value"].Value, @"[1-9]\d*"))
            {
                return true;
            }

            Match state = Regex.Match(entry, "\\\"state\\\"\\s*:\\s*(?<value>-?\\d+)", RegexOptions.IgnoreCase);
            int stateValue;
            return state.Success && int.TryParse(state.Groups["value"].Value, out stateValue) && stateValue != 1;
        }

        // ENS-005: Ein IndexOf auf "<name>" trifft den Namen auch dann, wenn er
        // im WERT einer fremden Eigenschaft steht - etwa in einer
        // blocked_permissions-Liste oder einer override_update_url. Danach
        // entfernte der Aufrufer ein fremdes Objekt aus einer fremden
        // Richtlinie. Der Name zaehlt deshalb nur als Schluessel, wenn er eine
        // vollstaendige JSON-Zeichenkette ist, auf die ein ':' folgt.
        private static int FindJsonPropertyIndex(string json, string propertyName)
        {
            if (string.IsNullOrEmpty(json) || string.IsNullOrEmpty(propertyName))
            {
                return -1;
            }

            for (int index = 0; index < json.Length; index++)
            {
                if (json[index] != '"')
                {
                    continue;
                }

                int start = index;
                int cursor = index + 1;
                bool escaped = false;
                while (cursor < json.Length)
                {
                    char current = json[cursor];
                    if (escaped)
                    {
                        escaped = false;
                    }
                    else if (current == '\\')
                    {
                        escaped = true;
                    }
                    else if (current == '"')
                    {
                        break;
                    }

                    cursor++;
                }

                if (cursor >= json.Length)
                {
                    return -1;
                }

                string name = json.Substring(start + 1, cursor - start - 1);
                int after = cursor + 1;
                while (after < json.Length && char.IsWhiteSpace(json[after]))
                {
                    after++;
                }

                if (after < json.Length && json[after] == ':' &&
                    string.Equals(name, propertyName, StringComparison.OrdinalIgnoreCase))
                {
                    return start;
                }

                index = cursor;
            }

            return -1;
        }

        private static string ExtractJsonObjectForProperty(string json, string propertyName)
        {
            int property = FindJsonPropertyIndex(json, propertyName);
            if (property < 0)
            {
                return string.Empty;
            }
            int start = json.IndexOf('{', property + propertyName.Length + 2);
            if (start < 0)
            {
                return string.Empty;
            }

            int depth = 0;
            bool inString = false;
            bool escaped = false;
            for (int index = start; index < json.Length; index++)
            {
                char current = json[index];
                if (inString)
                {
                    if (escaped)
                    {
                        escaped = false;
                    }
                    else if (current == '\\')
                    {
                        escaped = true;
                    }
                    else if (current == '"')
                    {
                        inString = false;
                    }
                    continue;
                }
                if (current == '"')
                {
                    inString = true;
                }
                else if (current == '{')
                {
                    depth++;
                }
                else if (current == '}' && --depth == 0)
                {
                    return json.Substring(start, index - start + 1);
                }
            }
            return string.Empty;
        }

        internal static bool RunBrowserWatcherSelfTest()
        {
            string root = Path.Combine(Path.GetTempPath(), "PurestateBrowserWatcher-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(root);
            System.Threading.ManualResetEvent received = new System.Threading.ManualResetEvent(false);

            try
            {
                FileSystemEventHandler changed = delegate(object sender, FileSystemEventArgs args)
                {
                    if (IsBrowserPreferencesFile(args.FullPath))
                    {
                        received.Set();
                    }
                };
                RenamedEventHandler renamed = delegate(object sender, RenamedEventArgs args)
                {
                    if (IsBrowserPreferencesFile(args.FullPath))
                    {
                        received.Set();
                    }
                };

                using (FileSystemWatcher watcher = CreateBrowserWatcher(root, changed, renamed))
                {
                    File.WriteAllText(Path.Combine(root, "Secure Preferences"), "{}");
                    return received.WaitOne(3000);
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                received.Dispose();
                try
                {
                    Directory.Delete(root, true);
                }
                catch
                {
                }
            }
        }

        private static FileSystemWatcher CreateBrowserWatcher(string root, FileSystemEventHandler changed, RenamedEventHandler renamed)
        {
            FileSystemWatcher watcher = new FileSystemWatcher(root, "*Preferences");
            watcher.IncludeSubdirectories = true;
            watcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.CreationTime | NotifyFilters.Size;
            watcher.Changed += changed;
            watcher.Created += changed;
            watcher.Deleted += changed;
            watcher.Renamed += renamed;
            watcher.EnableRaisingEvents = true;
            return watcher;
        }

        private void InitializeBrowserWatchers()
        {
            try
            {
                string windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
                string drive = Path.GetPathRoot(windows);
                string usersRoot = Path.Combine(drive ?? "C:\\", "Users");
                if (!Directory.Exists(usersRoot))
                {
                    return;
                }

                foreach (string userDir in Directory.GetDirectories(usersRoot))
                {
                    AddBrowserWatcher(Path.Combine(userDir, @"AppData\Local\Google\Chrome\User Data"));
                    AddBrowserWatcher(Path.Combine(userDir, @"AppData\Local\Microsoft\Edge\User Data"));
                }
            }
            catch (Exception ex)
            {
                Log("Could not enumerate browser profiles: " + ex.Message);
            }
        }

        private void AddBrowserWatcher(string root)
        {
            if (!Directory.Exists(root))
            {
                return;
            }

            try
            {
                FileSystemWatcher watcher = CreateBrowserWatcher(root, OnBrowserProfileChanged, OnBrowserProfileRenamed);
                browserWatchers.Add(watcher);
            }
            catch (Exception ex)
            {
                Log("Could not watch browser profile " + root + ": " + ex.Message);
            }
        }

        private void EnsureCriticalInfrastructure()
        {
            EnsureManagedCompanionPolicies();
            lock (infrastructureSync)
            {
                try
                {
                    EnsureStartupTasks();
                }
                catch (Exception ex)
                {
                    Log("Critical infrastructure repair failed: " + ex.Message);
                }
            }
        }

        private void EnsureManagedCompanionPolicies()
        {
            // Nach dem Ablauf keine zwangsinstallierte, angepinnte Erweiterung
            // mehr nachziehen. Ohne dieses Gate liefe der 1-15-Sekunden-Takt
            // ewig weiter, ohne dass noch irgendetwas geschuetzt wird.
            if (IsBetaExpired())
            {
                return;
            }

            bool changed = false;
            lock (infrastructureSync)
            {
                try
                {
                    changed = EnsureManagedCompanionPolicy(@"SOFTWARE\Policies\Google\Chrome");
                    changed = EnsureManagedCompanionPolicy(@"SOFTWARE\Policies\Microsoft\Edge") || changed;
                }
                catch (Exception ex)
                {
                    Log("Managed companion policy repair failed: " + ex.Message);
                    // Ein Fehler ist ein Grund, genauer hinzusehen, nicht
                    // seltener.
                    changed = true;
                }
            }

            companionPolicyTimer.Interval = NextCompanionPolicyInterval(
                changed,
                VideoGameDetection.MonotonicNowUtc(),
                ref companionPolicyBurstUntil);
        }

        // GRD-011: Der Zeitgeber lief fest im Sekundentakt und oeffnete dafuer
        // rund um die Uhr Registry-Schluessel mit Schreibrecht - der Grund,
        // warum der Prozess nie zur Ruhe kam. Der Takt haengt jetzt daran, ob
        // es etwas zu reparieren gab: nach einer Aenderung eine Minute lang
        // sekuendlich, sonst alle 15 Sekunden. Ein Eingriff wird damit
        // weiterhin schnell zurueckgenommen, und ein zweiter Versuch trifft
        // sofort auf den schnellen Takt.
        internal const double CompanionPolicyIdleIntervalMilliseconds = 15000;
        internal const double CompanionPolicyBusyIntervalMilliseconds = 1000;
        private static readonly TimeSpan CompanionPolicyBurstDuration = TimeSpan.FromMinutes(1);
        private DateTime companionPolicyBurstUntil = DateTime.MinValue;

        internal static double NextCompanionPolicyInterval(bool changed, DateTime nowUtc, ref DateTime burstUntil)
        {
            if (changed)
            {
                burstUntil = nowUtc + CompanionPolicyBurstDuration;
            }

            return nowUtc < burstUntil
                ? CompanionPolicyBusyIntervalMilliseconds
                : CompanionPolicyIdleIntervalMilliseconds;
        }

        // Der Rueckgabewert sagt, ob dieser Lauf etwas geschrieben hat. Er
        // steuert den Taktwechsel des Richtlinien-Zeitgebers (GRD-011): nach
        // einer echten Reparatur wieder eine Minute im Sekundentakt, sonst der
        // ruhige Takt.
        private static bool EnsureManagedCompanionPolicy(string rootPath)
        {
            using (RegistryKey root = Registry.LocalMachine.CreateSubKey(rootPath))
            {
                if (root == null)
                {
                    throw new InvalidOperationException("Could not open browser policy root " + rootPath);
                }

                bool changed = false;
                string devId = GetDevCompanionId();
                if (!string.IsNullOrWhiteSpace(devId))
                {
                    RemoveManagedCompanionPolicy(root);
                    return false;
                }

                // Merge our companion entry into any existing ExtensionSettings
                // instead of overwriting the whole value, so managed devices
                // (school/company/family-safety) keep their other extension
                // policies.
                string currentSettings = Convert.ToString(root.GetValue("ExtensionSettings")) ?? string.Empty;
                string mergedSettings = MergeCompanionExtensionSettings(currentSettings);
                if (!string.Equals(currentSettings, mergedSettings, StringComparison.Ordinal))
                {
                    root.SetValue("ExtensionSettings", mergedSettings, RegistryValueKind.String);
                    changed = true;
                }
                using (RegistryKey forceList = root.CreateSubKey("ExtensionInstallForcelist"))
                {
                    if (forceList == null)
                    {
                        throw new InvalidOperationException("Could not open ExtensionInstallForcelist.");
                    }
                    // Add our force-install entry under a free numbered slot only
                    // if it is not already present, so we never clobber another
                    // organisation's entry that happens to sit at index "1".
                    string expectedForceInstall = CompanionStoreId + ";" + CompanionUpdateUrl;
                    if (!ForcelistContainsEntry(forceList, expectedForceInstall))
                    {
                        forceList.SetValue(NextForcelistSlot(forceList), expectedForceInstall, RegistryValueKind.String);
                        changed = true;
                    }
                }

                return changed;
            }
        }

        // Builds an ExtensionSettings value that force-installs our companion
        // while preserving every other managed extension already configured on
        // the machine. Uses string surgery (no JSON dependency, matching the
        // rest of this file) around the shared brace-matching extractor.
        internal static string MergeCompanionExtensionSettings(string current)
        {
            string trimmed = (current ?? string.Empty).Trim();
            if (trimmed.Length == 0 || !trimmed.StartsWith("{") || !trimmed.EndsWith("}"))
            {
                // Unset or not a JSON object we can safely merge into: write our
                // managed policy as-is so protection is still guaranteed.
                return ManagedCompanionSettingsJson;
            }

            string existing = ExtractJsonObjectForProperty(trimmed, CompanionStoreId);
            if (existing.Length > 0)
            {
                // Our key is present already: replace only its object with the
                // canonical one, leaving all other keys byte-for-byte intact.
                int keyIdx = FindJsonPropertyIndex(trimmed, CompanionStoreId);
                int objStart = keyIdx < 0 ? -1 : trimmed.IndexOf('{', keyIdx);
                if (objStart < 0)
                {
                    return ManagedCompanionSettingsJson;
                }
                return trimmed.Substring(0, objStart) + ManagedCompanionEntryObject +
                    trimmed.Substring(objStart + existing.Length);
            }

            // Our key is missing: insert it, preserving the existing keys.
            string ourFragment = "\"" + CompanionStoreId + "\":" + ManagedCompanionEntryObject;
            string inner = trimmed.Substring(1, trimmed.Length - 2).Trim();
            if (inner.Length == 0)
            {
                return "{" + ourFragment + "}";
            }
            return "{" + ourFragment + "," + inner + "}";
        }

        private static void RemoveManagedCompanionPolicy(RegistryKey root)
        {
            RemoveCompanionFromForcelist(root);
            RemoveCompanionFromExtensionSettings(root);
        }

        private static void RemoveCompanionFromForcelist(RegistryKey root)
        {
            bool removeEmptySubkey = false;
            using (RegistryKey forceList = root.OpenSubKey("ExtensionInstallForcelist", true))
            {
                if (forceList == null)
                {
                    return;
                }

                foreach (string name in forceList.GetValueNames())
                {
                    string value = Convert.ToString(forceList.GetValue(name)) ?? string.Empty;
                    if (string.Equals(value, CompanionStoreId, StringComparison.Ordinal) ||
                        value.StartsWith(CompanionStoreId + ";", StringComparison.Ordinal))
                    {
                        forceList.DeleteValue(name, false);
                    }
                }

                removeEmptySubkey = forceList.GetValueNames().Length == 0 && forceList.GetSubKeyNames().Length == 0;
            }

            if (removeEmptySubkey)
            {
                root.DeleteSubKeyTree("ExtensionInstallForcelist", false);
            }
        }

        private static void RemoveCompanionFromExtensionSettings(RegistryKey root)
        {
            string current = Convert.ToString(root.GetValue("ExtensionSettings")) ?? string.Empty;
            if (current.Trim().Length == 0)
            {
                return;
            }

            string remaining = RemoveCompanionKeyFromJson(current, CompanionStoreId);
            if (remaining == null)
            {
                return;
            }

            string trimmed = remaining.Trim();
            if (trimmed.Length == 0 || trimmed == "{}")
            {
                root.DeleteValue("ExtensionSettings", false);
            }
            else if (!string.Equals(trimmed, current.Trim(), StringComparison.Ordinal))
            {
                root.SetValue("ExtensionSettings", trimmed, RegistryValueKind.String);
            }
        }

        private static string RemoveCompanionKeyFromJson(string json, string key)
        {
            string trimmed = (json ?? string.Empty).Trim();
            if (!trimmed.StartsWith("{") || !trimmed.EndsWith("}"))
            {
                return null;
            }

            string entry = ExtractJsonObjectForProperty(trimmed, key);
            if (entry.Length == 0)
            {
                return trimmed;
            }

            int keyIdx = FindJsonPropertyIndex(trimmed, key);
            if (keyIdx < 0)
            {
                return trimmed;
            }
            int objStart = trimmed.IndexOf('{', keyIdx);
            if (objStart < 0)
            {
                return trimmed;
            }

            int removeStart = keyIdx;
            int removeEnd = objStart + entry.Length;

            int after = removeEnd;
            while (after < trimmed.Length && char.IsWhiteSpace(trimmed[after]))
            {
                after++;
            }
            if (after < trimmed.Length && trimmed[after] == ',')
            {
                removeEnd = after + 1;
            }
            else
            {
                int before = removeStart - 1;
                while (before >= 0 && char.IsWhiteSpace(trimmed[before]))
                {
                    before--;
                }
                if (before >= 0 && trimmed[before] == ',')
                {
                    removeStart = before;
                }
            }

            return (trimmed.Substring(0, removeStart) + trimmed.Substring(removeEnd)).Trim();
        }

        private static bool ForcelistContainsEntry(RegistryKey forceList, string entry)
        {
            foreach (string name in forceList.GetValueNames())
            {
                if (string.Equals(Convert.ToString(forceList.GetValue(name)), entry, StringComparison.Ordinal))
                {
                    return true;
                }
            }
            return false;
        }

        private static string NextForcelistSlot(RegistryKey forceList)
        {
            HashSet<string> used = new HashSet<string>(forceList.GetValueNames(), StringComparer.OrdinalIgnoreCase);
            for (int index = 1; index < 100000; index++)
            {
                string name = index.ToString(System.Globalization.CultureInfo.InvariantCulture);
                if (!used.Contains(name))
                {
                    return name;
                }
            }
            return "1";
        }

        // GRD-010: Diese Reparatur war fuer "einmal bei der Installation"
        // geschrieben und wurde als Abfrageschleife weiterverwendet. Sie startet
        // bedingungslos powershell.exe (Ordnerpruefung) und zweimal schtasks.exe
        // (/Query) - auf dem 30-s-Takt sind das rund 8000 bis 12000
        // Prozessstarts am Tag. Die Aufgabendateien selbst sind billig zu
        // pruefen; die teure Vollpruefung laeuft nur, wenn eine Datei fehlt oder
        // die letzte lange genug her ist. Sie bleibt noetig, weil die Dateien
        // auch verwaist dort liegen koennen, ohne dass der Planer sie kennt.
        private DateTime lastFullTaskVerification = DateTime.MinValue;
        private static readonly TimeSpan FullTaskVerificationInterval = TimeSpan.FromMinutes(5);

        internal static bool ShouldVerifyStartupTasks(bool taskFilesPresent, DateTime nowUtc, DateTime lastFullVerification)
        {
            return !taskFilesPresent || nowUtc - lastFullVerification >= FullTaskVerificationInterval;
        }

        private void EnsureStartupTasks()
        {
            string windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            string schtasks = Path.Combine(windows, "System32", "schtasks.exe");
            string powershell = Path.Combine(windows, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
            string watchdog = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "scripts", "Watchdog.ps1");
            if (!File.Exists(schtasks) || !File.Exists(powershell) || !File.Exists(watchdog))
            {
                return;
            }

            string taskFolder = Path.Combine(windows, "System32", "Tasks", "Purestate");
            bool taskFilesPresent =
                File.Exists(Path.Combine(taskFolder, "Watchdog")) &&
                File.Exists(Path.Combine(taskFolder, "Startup"));
            DateTime nowUtc = VideoGameDetection.MonotonicNowUtc();
            if (!ShouldVerifyStartupTasks(taskFilesPresent, nowUtc, lastFullTaskVerification))
            {
                return;
            }

            lastFullTaskVerification = nowUtc;
            string taskRun = "\\\"" + powershell + "\\\" -NoProfile -ExecutionPolicy Bypass -File \\\"" + watchdog + "\\\"";
            EnsureTaskSchedulerFolder(powershell);
            EnsureScheduledTask(schtasks, @"\Purestate\Watchdog", "/SC MINUTE /MO 5", taskRun);
            EnsureScheduledTask(schtasks, @"\Purestate\Startup", "/SC ONSTART /DELAY 0000:20", taskRun);
        }

        private static void EnsureTaskSchedulerFolder(string powershell)
        {
            // Der innere catch faengt den verwaisten Ordner ab: nach einer
            // Deinstallation koennen die Aufgabendateien unter
            // %WINDIR%\System32\Tasks\Purestate liegenbleiben, waehrend der
            // Planer den Ordner nicht mehr kennt. Dann scheitert GetFolder
            // (kennt ihn nicht) UND CreateFolder (Verzeichnis existiert,
            // 0x800700B7), und die Installation bricht ab. Live am 2026-08-04
            // getroffen. Der Zweig raeumt nur auf, wenn der Planer den Ordner
            // ohnehin nicht kennt - registrierte Aufgaben sind dort nie
            // betroffen, sonst haette GetFolder gegriffen.
            string script =
                "$scheduler = New-Object -ComObject 'Schedule.Service'; " +
                "$scheduler.Connect(); " +
                "try { $null = $scheduler.GetFolder('\\Purestate') } " +
                "catch { $root = $scheduler.GetFolder('\\'); " +
                "try { $null = $root.CreateFolder('Purestate') } " +
                "catch { Remove-Item -LiteralPath (Join-Path $env:WINDIR 'System32\\Tasks\\Purestate') -Recurse -Force -ErrorAction SilentlyContinue; " +
                "$null = $root.CreateFolder('Purestate') } }";
            string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));
            if (RunHiddenProcess(
                powershell,
                "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + encoded,
                10000) != 0)
            {
                throw new InvalidOperationException("Could not create the Purestate task scheduler folder.");
            }
        }

        private static void EnsureScheduledTask(string schtasks, string taskName, string schedule, string taskRun)
        {
            if (RunHiddenProcess(schtasks, "/Query /TN \"" + taskName + "\"", 10000) == 0)
            {
                return;
            }
            string arguments = "/Create /TN \"" + taskName + "\" " + schedule + " /RU SYSTEM /RL HIGHEST /TR \"" + taskRun + "\" /F";
            if (RunHiddenProcess(schtasks, arguments, 15000) != 0)
            {
                throw new InvalidOperationException("Could not create scheduled task " + taskName);
            }
        }

        private static int RunHiddenProcess(string fileName, string arguments, int timeoutMilliseconds)
        {
            using (Process process = Process.Start(new ProcessStartInfo
            {
                FileName = fileName,
                Arguments = arguments,
                UseShellExecute = false,
                CreateNoWindow = true
            }))
            {
                if (process == null)
                {
                    return -1;
                }
                if (!process.WaitForExit(timeoutMilliseconds))
                {
                    try { process.Kill(); } catch { }
                    return -1;
                }
                return process.ExitCode;
            }
        }

        private void EnforceExplicitlyDisabledCompanions()
        {
            // Nach dem Ablauf ist das Entfernen der Erweiterung kein Umgehen
            // mehr, sondern Aufraeumen. Ohne dieses Gate schriebe der Guard
            // dafuer eine frische URLBlocklist in beide Browser - eine neue
            // tote Sperre, NACH dem Ablauf angelegt.
            if (IsBetaExpired())
            {
                return;
            }

            try
            {
                string windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
                string usersRoot = Path.Combine(Path.GetPathRoot(windows) ?? "C:\\", "Users");
                foreach (string userDir in Directory.GetDirectories(usersRoot))
                {
                    CheckBrowserProfilesForDisabledCompanion("Chrome", Path.Combine(userDir, @"AppData\Local\Google\Chrome\User Data"));
                    CheckBrowserProfilesForDisabledCompanion("Edge", Path.Combine(userDir, @"AppData\Local\Microsoft\Edge\User Data"));
                }
            }
            catch (Exception ex)
            {
                Log("Direct companion state check failed: " + ex.Message);
            }
        }

        private void CheckBrowserProfilesForDisabledCompanion(string browser, string userDataRoot)
        {
            if (!Directory.Exists(userDataRoot))
            {
                return;
            }

            string devId = GetDevCompanionId();
            string disabledCheckId = string.IsNullOrWhiteSpace(devId) ? CompanionStoreId : devId;
            foreach (string profile in Directory.GetDirectories(userDataRoot))
            {
                string name = Path.GetFileName(profile);
                if (!name.Equals("Default", StringComparison.OrdinalIgnoreCase) && !name.StartsWith("Profile ", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }
                foreach (string fileName in new[] { "Preferences", "Secure Preferences" })
                {
                    string path = Path.Combine(profile, fileName);
                    // GRD-006: Der try gehoert um das LESEN. Umfasste er auch
                    // die Durchsetzung, fiel die staerkste Reaktion des
                    // Produkts - Sperrliste schreiben und Browser schliessen -
                    // spurlos aus: ein IOException aus der Registrierung sah
                    // aus wie eine nicht lesbare Datei.
                    bool companionDisabled = false;
                    try
                    {
                        companionDisabled = File.Exists(path) &&
                            IsCompanionExplicitlyDisabledJson(File.ReadAllText(path), disabledCheckId);
                    }
                    catch (IOException)
                    {
                    }
                    catch (UnauthorizedAccessException)
                    {
                    }

                    if (companionDisabled)
                    {
                        TryEnterDirectFailClosed(delegate { EnterDirectFailClosed(browser); }, Log);
                        return;
                    }
                }
            }
        }

        // Scheitert die Durchsetzung, muss das im Protokoll stehen: aus
        // service.log ist der Fehlschlag sonst nicht zu erkennen, und der
        // Browser laeuft ungesperrt weiter.
        internal static bool TryEnterDirectFailClosed(Action enforce, Action<string> log)
        {
            try
            {
                enforce();
                return true;
            }
            catch (Exception ex)
            {
                try
                {
                    log("Direct fail-closed failed: " + ex.Message);
                }
                catch
                {
                }
                return false;
            }
        }

        private void EnterDirectFailClosed(string browser)
        {
            DeleteHeartbeat(browser);
            ApplyDirectFailClosedPolicy(
                browser,
                browser + " was closed after an explicit Companion disable; direct fail-closed is active.",
                true);
        }

        private void ApplyDirectFailClosedPolicy(string browser, string logMessage, bool closeBrowser)
        {
            string policyRoot = browser.Equals("Chrome", StringComparison.OrdinalIgnoreCase)
                ? @"SOFTWARE\Policies\Google\Chrome"
                : @"SOFTWARE\Policies\Microsoft\Edge";
            EnsureManagedCompanionPolicy(policyRoot);
            string[] filters = GetDirectFailClosedFilters();
            // Zusammenfuehren statt loeschen: der Canary-Zwilling unten macht es
            // seit jeher so. Der Loeschweg nahm auch Purestates eigene, ueber
            // Set-PurestateManagedUrlList gepflegte Liste mit, bis der naechste
            // Durchsetzungslauf sie neu schrieb.
            AddUrlBlocklistEntries(policyRoot, filters);

            if (!closeBrowser)
            {
                Log(logMessage);
                return;
            }

            DateTime lastClosed;
            lock (lastBrowserClosures)
            {
                if (lastBrowserClosures.TryGetValue(browser, out lastClosed) && DateTime.UtcNow - lastClosed < TimeSpan.FromSeconds(30))
                {
                    return;
                }
                lastBrowserClosures[browser] = DateTime.UtcNow;
            }
            StopBrowserProcesses(browser);
            Log(logMessage);
        }

        private void ApplyCanaryFailClosedPolicy(string browser, string logMessage, bool closeBrowser)
        {
            // Auch der Canary-Weg legt nach dem Ablauf keine neue Sperrliste
            // mehr an.
            if (IsBetaExpired())
            {
                return;
            }

            string policyRoot = browser.Equals("Chrome", StringComparison.OrdinalIgnoreCase)
                ? @"SOFTWARE\Policies\Google\Chrome"
                : @"SOFTWARE\Policies\Microsoft\Edge";
            EnsureManagedCompanionPolicy(policyRoot);
            // GRD-008: Diese eine Aufrufstelle blieb bei der rohen Systemuhr
            // stehen, als der Anker eingefuehrt wurde. Der Schreiber und der
            // andere Leser messen am Anker - um jeden Uhrsprung herum waren die
            // beiden Pfade damit verschiedener Meinung darueber, ob eine Seite
            // gesperrt ist.
            // Befund #2: wie ReadActiveCanaryFailClosedDomains - ohne den
            // Bereich Erwachseneninhalte darf auch dieser Pfad nichts sperren.
            string[] filters = GetCanaryDirectFailClosedFilters(
                CanaryFailClosedPath,
                ReadClockAnchorUtc(),
                delegate(string field) { return ReadSiteProtectionConfigBool(field, true) && ReadSiteProtectionConfigBool("AdultContentProtectionEnabled", true); });
            if (filters.Length == 0)
            {
                Log(logMessage);
                return;
            }

            AddUrlBlocklistEntries(policyRoot, filters);

            if (!closeBrowser)
            {
                Log(logMessage);
                return;
            }

            DateTime lastClosed;
            lock (lastBrowserClosures)
            {
                if (lastBrowserClosures.TryGetValue(browser, out lastClosed) && DateTime.UtcNow - lastClosed < TimeSpan.FromSeconds(30))
                {
                    return;
                }
                lastBrowserClosures[browser] = DateTime.UtcNow;
            }
            StopBrowserProcesses(browser);
            Log(logMessage);
        }

        internal static string[] PrioritizeUrlBlocklistValues(string[] existingValues, string[] priorityValues, int maxEntries)
        {
            List<string> result = new List<string>();
            AddPrioritizedUrlBlocklistValues(result, priorityValues, maxEntries);
            AddPrioritizedUrlBlocklistValues(result, existingValues, maxEntries);
            return result.ToArray();
        }

        private static void AddPrioritizedUrlBlocklistValues(List<string> result, string[] values, int maxEntries)
        {
            if (maxEntries <= 0)
            {
                return;
            }

            foreach (string raw in values ?? new string[0])
            {
                if (result.Count >= maxEntries)
                {
                    return;
                }

                string value = (raw ?? string.Empty).Trim();
                if (string.IsNullOrWhiteSpace(value) || ContainsUrlBlocklistValue(result, value))
                {
                    continue;
                }

                result.Add(value);
            }
        }

        private static bool ContainsUrlBlocklistValue(List<string> values, string candidate)
        {
            foreach (string value in values)
            {
                if (string.Equals(value, candidate, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private static void AddUrlBlocklistEntries(string policyRoot, string[] filters)
        {
            using (RegistryKey root = Registry.LocalMachine.CreateSubKey(policyRoot))
            {
                if (root == null)
                {
                    return;
                }

                List<Tuple<int, string>> existingEntries = new List<Tuple<int, string>>();
                using (RegistryKey blockList = root.OpenSubKey("URLBlocklist"))
                {
                    if (blockList != null)
                    {
                        foreach (string name in blockList.GetValueNames())
                        {
                            int numericName;
                            if (!int.TryParse(name, NumberStyles.Integer, CultureInfo.InvariantCulture, out numericName))
                            {
                                continue;
                            }

                            string value = Convert.ToString(blockList.GetValue(name)) ?? string.Empty;
                            if (!string.IsNullOrWhiteSpace(value))
                            {
                                existingEntries.Add(new Tuple<int, string>(numericName, value));
                            }
                        }
                    }
                }

                existingEntries.Sort(delegate(Tuple<int, string> left, Tuple<int, string> right)
                {
                    return left.Item1.CompareTo(right.Item1);
                });
                List<string> existing = new List<string>();
                foreach (Tuple<int, string> entry in existingEntries)
                {
                    existing.Add(entry.Item2);
                }

                string[] finalValues = PrioritizeUrlBlocklistValues(
                    existing.ToArray(),
                    filters,
                    MaxChromiumUrlBlocklistEntries);
                try { root.DeleteSubKeyTree("URLBlocklist", false); } catch { }
                using (RegistryKey blockList = root.CreateSubKey("URLBlocklist"))
                {
                    if (blockList == null)
                    {
                        return;
                    }

                    for (int index = 0; index < finalValues.Length; index++)
                    {
                        blockList.SetValue(
                            (index + 1).ToString(CultureInfo.InvariantCulture),
                            finalValues[index],
                            RegistryValueKind.String);
                    }
                }
            }
        }

        private static string[] GetDirectFailClosedFilters()
        {
            List<string> filters = new List<string>();
            string[] unreadableFiles;
            bool gamblingEnabled = ReadEffectiveGamblingProtectionConfigBool();
            if (gamblingEnabled)
            {
                foreach (string domain in ReadGamblingDirectFailClosedDomains(out unreadableFiles))
                {
                    AddDirectFailClosedFilter(filters, domain);
                }
                LogUnreadableRuleFiles("gambling", unreadableFiles);
            }

            if (ReadSiteProtectionConfigBool("ShoppingProtectionEnabled", false))
            {
                foreach (string domain in ReadShoppingDirectFailClosedDomains(out unreadableFiles))
                {
                    AddDirectFailClosedFilter(filters, domain);
                }
                LogUnreadableRuleFiles("shopping", unreadableFiles);
            }

            if (ReadSiteProtectionConfigBool("SocialMediaProtectionEnabled", false))
            {
                foreach (string domain in GetSocialMediaBlockedDomains(
                    ReadSiteProtectionConfigString("SocialMediaBlockedPlatforms", string.Empty)))
                {
                    AddDirectFailClosedFilter(filters, domain);
                }

                // Selective feed block: distraction routes only, in the
                // URLBlocklist registry format host/path (implicit subdomain
                // matching), mirroring the browser-policy patterns.
                foreach (string filter in GetSocialMediaFeedBlockedFilters(
                    ReadSiteProtectionConfigString("SocialMediaFeedBlockedPlatforms", string.Empty)))
                {
                    AddDirectFailClosedFilter(filters, filter);
                }
            }

            // Cloud-gaming/browser-game surfaces: only while the video-games
            // area is enforced (enabled AND strict - gentle never gates the
            // web layer). xbox.com/play is a path route, valid in the
            // URLBlocklist registry format but impossible in hosts/DNS.
            if (ReadSiteProtectionConfigBool("VideoGamesProtectionEnabled", false) &&
                string.Equals(ReadSiteProtectionConfigString("VideoGamesProtectionMode", "planned"),
                    "strict", StringComparison.OrdinalIgnoreCase))
            {
                foreach (string domain in ReadVideoGamesDirectFailClosedDomains(out unreadableFiles))
                {
                    AddDirectFailClosedFilter(filters, domain);
                }
                LogUnreadableRuleFiles("video-games", unreadableFiles);
                AddDirectFailClosedFilter(filters, "xbox.com/play");
            }

            foreach (string domain in ReadActiveCanaryFailClosedDomains())
            {
                AddDirectFailClosedFilter(filters, domain);
            }

            // Befund #2: die Site*Enabled-Paare sind alle Feinfilter des
            // Bereichs Erwachseneninhalte (Spec 2.4, wie Get-SiteProtectionSettings
            // in PowerShell) - ohne den Bereich selbst darf auch dieser
            // Fail-closed-Pfad nichts sperren.
            bool adultAreaEnabled = ReadSiteProtectionConfigBool("AdultContentProtectionEnabled", true);
            foreach (string[] pair in DirectFailClosedFilterFields)
            {
                bool enabled = pair[1].Equals("GamblingProtectionEnabled", StringComparison.OrdinalIgnoreCase)
                    ? gamblingEnabled
                    : ReadSiteProtectionConfigBool(pair[1], true) && adultAreaEnabled;
                if (enabled)
                {
                    AddDirectFailClosedFilter(filters, pair[0]);
                }
            }
            return filters.ToArray();
        }

        private static void AddDirectFailClosedFilter(List<string> filters, string value)
        {
            if (filters.Count >= 1000 || string.IsNullOrWhiteSpace(value))
            {
                return;
            }

            foreach (string existing in filters)
            {
                if (string.Equals(existing, value, StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }
            }

            filters.Add(value);
        }

        // GRD-012: Alle drei Leser verschluckten einen Zugriffsfehler je Datei
        // und lieferten still, was bis dahin zusammenkam - beim ersten Treffer
        // also eine leere Sperrliste, ohne eine Zeile im Protokoll. "Keine
        // Regeln eingerichtet" und "Regeln nicht lesbar" waren nicht mehr zu
        // unterscheiden. Ein Leseweg fuer alle drei, und er nennt die Dateien,
        // die vorhanden, aber unlesbar waren.
        internal static string[] ReadRuleDomainFiles(string rulesRoot, string[] fileNames, out string[] unreadableFiles)
        {
            List<string> domains = new List<string>();
            List<string> unreadable = new List<string>();
            foreach (string fileName in fileNames)
            {
                string path = Path.Combine(rulesRoot, fileName);
                try
                {
                    if (!File.Exists(path))
                    {
                        continue;
                    }

                    foreach (string raw in File.ReadAllLines(path, Encoding.UTF8))
                    {
                        string domain = NormalizeRuleDomain(raw);
                        if (domain.Length > 0)
                        {
                            AddDirectFailClosedFilter(domains, domain);
                        }
                    }
                }
                catch (IOException)
                {
                    unreadable.Add(fileName);
                }
                catch (UnauthorizedAccessException)
                {
                    unreadable.Add(fileName);
                }
            }

            unreadableFiles = unreadable.ToArray();
            return domains.ToArray();
        }

        private static string RulesRoot
        {
            get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rules"); }
        }

        private static string[] ReadGamblingDirectFailClosedDomains(out string[] unreadableFiles)
        {
            return ReadRuleDomainFiles(
                RulesRoot,
                new[]
                {
                    "gambling-domains.txt",
                    "offshore-gambling-domains.txt",
                    "gambling-affiliate-domains.txt",
                    "custom-gambling-domains.txt"
                },
                out unreadableFiles);
        }

        private static string[] ReadVideoGamesDirectFailClosedDomains(out string[] unreadableFiles)
        {
            return ReadRuleDomainFiles(RulesRoot, new[] { "gaming-domains.txt" }, out unreadableFiles);
        }

        private static string[] ReadShoppingDirectFailClosedDomains(out string[] unreadableFiles)
        {
            return ReadRuleDomainFiles(RulesRoot, new[] { "custom-shopping-domains.txt" }, out unreadableFiles);
        }

        // Hoechstens eine Meldung je Datei und Stunde: der Aufrufer laeuft auf
        // dem 30-s-Takt und beim entprellten Preferences-Schreiben, das
        // Protokoll waere sonst in Minuten voll.
        private static readonly Dictionary<string, DateTime> lastRuleFileWarning =
            new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

        private static void LogUnreadableRuleFiles(string area, string[] unreadableFiles)
        {
            foreach (string fileName in unreadableFiles)
            {
                lock (lastRuleFileWarning)
                {
                    DateTime last;
                    if (lastRuleFileWarning.TryGetValue(fileName, out last) &&
                        VideoGameDetection.MonotonicNowUtc() - last < TimeSpan.FromHours(1))
                    {
                        continue;
                    }

                    lastRuleFileWarning[fileName] = VideoGameDetection.MonotonicNowUtc();
                }

                Log("Rule file rules\\" + fileName + " exists but could not be read; " + area +
                    " domains from it are missing from the direct fail-closed list.");
            }
        }

        private static string NormalizeRuleDomain(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw))
            {
                return string.Empty;
            }

            string value = raw.Trim().ToLowerInvariant();
            if (value.Length == 0 || value.StartsWith("#", StringComparison.Ordinal))
            {
                return string.Empty;
            }

            if (value.StartsWith("http://", StringComparison.Ordinal))
            {
                value = value.Substring("http://".Length);
            }
            else if (value.StartsWith("https://", StringComparison.Ordinal))
            {
                value = value.Substring("https://".Length);
            }

            int cut = value.IndexOfAny(new[] { '/', '\\', '?', '#' });
            if (cut >= 0)
            {
                value = value.Substring(0, cut);
            }

            int port = value.IndexOf(':');
            if (port >= 0)
            {
                value = value.Substring(0, port);
            }

            value = value.Trim().TrimEnd('.');
            if (value.StartsWith("www.", StringComparison.Ordinal))
            {
                value = value.Substring("www.".Length);
            }

            return Regex.IsMatch(value, @"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$")
                ? value
                : string.Empty;
        }

        private static bool ReadEffectiveGamblingProtectionConfigBool()
        {
            bool legacyEnabled = ReadSiteProtectionConfigBool("GamblingSupportEnabled", false);
            return legacyEnabled || ReadSiteProtectionConfigBool("GamblingProtectionEnabled", false);
        }

        // Fixed platform-to-domain map for the per-platform social media full
        // blocks. Kept local because the guard is also compiled standalone
        // (test fixture); Support.GetSocialMediaBlockedDomains and the
        // PowerShell Get-SocialMediaBlockedDomains mirror it, all pinned by
        // tests.
        private static string[] GetSocialMediaBlockedDomains(string blockedCsv)
        {
            List<string> result = new List<string>();
            foreach (string part in (blockedCsv ?? string.Empty).Split(','))
            {
                string platform = part.Trim().ToLowerInvariant();
                string[] domains;
                switch (platform)
                {
                    case "x": domains = new[] { "x.com", "twitter.com" }; break;
                    case "instagram": domains = new[] { "instagram.com" }; break;
                    case "tiktok": domains = new[] { "tiktok.com" }; break;
                    // BAS-006: Der Vollblock kannte nur .com, waehrend die
                    // Fail-closed-Liste derselben Plattform dreizehn Domains
                    // sperrt. Wer Pinterest bewusst vollstaendig sperrte,
                    // erreichte pinterest.de weiterhin - und zwar in der
                    // Richtung, die er ausdruecklich angefordert hat.
                    case "pinterest": domains = new[] { "pinterest.com", "pinterest.de", "pinterest.at", "pinterest.ch", "pinterest.fr", "pinterest.it", "pinterest.es", "pinterest.co.uk", "pinterest.ca", "pinterest.com.au", "pinterest.com.mx", "pinterest.jp", "pinterest.se" }; break;
                    case "tumblr": domains = new[] { "tumblr.com" }; break;
                    case "bluesky": domains = new[] { "bsky.app" }; break;
                    case "reddit": domains = new[] { "reddit.com" }; break;
                    case "youtube": domains = new[] { "youtube.com", "m.youtube.com", "youtu.be" }; break;
                    case "streaming": domains = new[] { "netflix.com", "disneyplus.com", "primevideo.com", "max.com", "hbomax.com", "paramountplus.com", "tv.apple.com", "crunchyroll.com", "twitch.tv", "joyn.de", "plus.rtl.de", "dazn.com", "wowtv.de" }; break;
                    default: continue;
                }

                foreach (string domain in domains)
                {
                    AddDirectFailClosedFilter(result, domain);
                }
            }
            return result.ToArray();
        }

        // Fixed route map of the selective feed block (distraction routes
        // only, rest of the platform stays usable). Kept local because the
        // guard is also compiled standalone (test fixture);
        // Support.GetSocialMediaFeedBlockedPatterns, the PowerShell
        // Get-SocialMediaFeedBlockedPatterns and the Companion route constant
        // mirror it, all pinned by tests.
        private static string[] GetSocialMediaFeedBlockedFilters(string feedCsv)
        {
            List<string> result = new List<string>();
            foreach (string part in (feedCsv ?? string.Empty).Split(','))
            {
                string platform = part.Trim().ToLowerInvariant();
                string[] hosts;
                string[] routes;
                switch (platform)
                {
                    case "instagram": hosts = new[] { "instagram.com" }; routes = new[] { "/reels", "/explore" }; break;
                    case "youtube": hosts = new[] { "youtube.com", "m.youtube.com" }; routes = new[] { "/shorts" }; break;
                    case "x": hosts = new[] { "x.com", "twitter.com" }; routes = new[] { "/explore" }; break;
                    case "reddit": hosts = new[] { "reddit.com" }; routes = new[] { "/r/popular", "/r/all" }; break;
                    case "tumblr": hosts = new[] { "tumblr.com" }; routes = new[] { "/explore" }; break;
                    default: continue;
                }

                foreach (string host in hosts)
                {
                    foreach (string route in routes)
                    {
                        AddDirectFailClosedFilter(result, host + route);
                    }
                }
            }
            return result.ToArray();
        }

        private static string ReadSiteProtectionConfigString(string name, string fallback)
        {
            string dataDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "Purestate");
            EnsureDataDirectoryIsNotReparsePoint(dataDir);
            try
            {
                string path = Path.Combine(dataDir, "config.json");
                if (!File.Exists(path))
                {
                    return fallback;
                }

                string json = File.ReadAllText(path, Encoding.UTF8);
                Match match = Regex.Match(json, "\\\"" + Regex.Escape(name) + "\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"");
                return match.Success ? match.Groups[1].Value : fallback;
            }
            catch
            {
                return fallback;
            }
        }

        private static bool ReadSiteProtectionConfigBool(string name, bool fallback)
        {
            string dataDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "Purestate");
            EnsureDataDirectoryIsNotReparsePoint(dataDir);
            try
            {
                string path = Path.Combine(dataDir, "config.json");
                if (!File.Exists(path))
                {
                    return fallback;
                }

                string json = File.ReadAllText(path, Encoding.UTF8);
                Match match = Regex.Match(json, "\\\"" + Regex.Escape(name) + "\\\"\\s*:\\s*(true|false)", RegexOptions.IgnoreCase);
                return match.Success ? bool.Parse(match.Groups[1].Value) : fallback;
            }
            catch
            {
                return fallback;
            }
        }

        // Ende dieser Programmfassung. DRITTE Kopie von Support.BetaBuildEndUtc
        // (src\NativeSupportAuthority.cs) und $script:BetaBuildEndUtc
        // (scripts\Common.ps1). PurestateGuard.exe wird ohne NativeSupport*.cs
        // gebaut (tools\Build-Release.ps1) und kann Support nicht
        // referenzieren, deshalb steht der Wert hier noch einmal. Ein
        // Quelltext-Vertrag in tests\Purestate.Tests.ps1 haelt alle drei gleich.
        internal const string BetaBuildEndUtc = "2027-03-31T00:00:00.0000000Z";

        // Die Freigabe-Markierung im Datenordner, geschrieben von
        // Invoke-EntitlementRelease ($script:EntitlementReleaseMarkerPath in
        // scripts\Common.ps1). Ein Quelltext-Vertrag in
        // tests\Purestate.Tests.ps1 haelt beide Namen gleich.
        internal const string EntitlementReleaseMarkerName = "beta-ended.marker";

        // Nach dem Ablauf setzt der Guard nichts mehr durch. Ohne dieses Gate
        // laufen die drei Schritte VOR RunProtectionHelper weiter: die
        // Companion-Richtlinien wuerden alle 1-15 Sekunden neu geschrieben (und
        // Disable-Protection entfernt sie nicht, das tut nur der Deinstaller),
        // der Videospiel-Schutz beendete weiter Spiele, und ein entfernter
        // Companion loeste eine frische URLBlocklist aus - eine neue tote
        // Sperre NACH dem Ablauf. Genau das schliesst Abschnitt 6 der
        // Spezifikation aus.
        //
        // RunProtectionHelper bleibt bewusst ungegated: dort gibt
        // Enable-Protection den Rechner frei (hosts, DNS, Proxy, Firewall,
        // Browser-Richtlinien). Wer diesen Takt mit abschaltet, verhindert die
        // Freigabe.
        //
        // Fehlerrichtung wie ueberall: fehlender, leerer oder unlesbarer Wert
        // laesst den Guard DURCHSETZEN. Nur ein lesbarer, erreichter Termin
        // schaltet ab - und auch der nur, wenn die Freigabe-Markierung liegt.
        //
        // Warum die Markierung: der Guard liest config.json roh und kann den
        // Integritaets-HMAC nicht pruefen. Ein von Hand hinter die
        // Fassungsgrenze gestellter Uhr-Anker liess ihn sonst einstellen,
        // obwohl die Konfiguration manipuliert war. Die Markierung schreibt nur
        // Invoke-EntitlementRelease (scripts\Common.ps1), und das laeuft nur,
        // wenn die GEPRUEFTE Konfiguration abgelaufen ist; der
        // nicht-abgelaufene Zweig von Enable-Protection raeumt sie wieder weg.
        // Damit gilt: manipuliert -> keine Freigabe -> keine Markierung ->
        // Guard setzt durch; echter Ablauf -> Markierung -> Guard haelt still;
        // Verlaengerung -> Termin in der Zukunft -> Guard setzt durch.
        //
        // Ein Administrator kann die Markierung selbst anlegen. Das ist
        // dieselbe Grenze wie ueberall: derselbe Angreifer kann den Dienst
        // schlicht beenden.
        internal static bool IsBetaExpired()
        {
            try
            {
                string dataDir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                    "Purestate");
                return IsBetaExpiredAt(
                    ReadClockAnchorUtc(),
                    ReadSiteProtectionConfigString("EntitledUntilUtc", string.Empty),
                    ReadSiteProtectionConfigString("EntitlementSignature", string.Empty),
                    File.Exists(Path.Combine(dataDir, EntitlementReleaseMarkerName)));
            }
            catch
            {
                // ReadSiteProtectionConfigString wirft, wenn der Datenordner eine
                // Abzweigung ist (EnsureDataDirectoryIsNotReparsePoint). Das Gate
                // steht in den Aufrufern VOR deren try/catch - ohne dieses
                // Auffangnetz waere eine untergeschobene Abzweigung ein Weg, den
                // Takt zu stoeren. Zweifel heisst durchsetzen.
                return false;
            }
        }

        // Die Signatur wird hier nur auf "vorhanden" geprueft, nicht
        // kryptografisch - der Guard hat weder den Serverschluessel noch RSA
        // dafuer. Dieselbe Bedingung wie im PowerShell-Spiegel
        // (Test-EntitlementExpired), damit Guard und Durchsetzungspfad nicht
        // auseinanderlaufen: sonst stellte der eine ein, waehrend der andere
        // weiter durchsetzt.
        internal static bool IsBetaExpiredAt(DateTime nowUtc, string entitledUntilUtc, string entitlementSignature, bool releaseMarkerExists)
        {
            if (!releaseMarkerExists)
            {
                return false;
            }

            DateTime buildEnd;
            if (TryReadGuardUtc(BetaBuildEndUtc, out buildEnd) && nowUtc >= buildEnd)
            {
                return true;
            }

            if (string.IsNullOrEmpty(entitlementSignature))
            {
                return false;
            }

            DateTime entitledUntil;
            if (!TryReadGuardUtc(entitledUntilUtc, out entitledUntil))
            {
                return false;
            }

            return nowUtc >= entitledUntil;
        }

        private static bool TryReadGuardUtc(string value, out DateTime utc)
        {
            utc = DateTime.MinValue;
            if (string.IsNullOrEmpty(value))
            {
                return false;
            }

            DateTime parsed;
            if (!DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out parsed))
            {
                return false;
            }

            utc = parsed.Kind == DateTimeKind.Utc ? parsed : parsed.ToUniversalTime();
            return true;
        }

        // Vertrauenswuerdige Uhr fuer die Gates des Guards. Der Anker wird vom
        // PowerShell-Durchsetzungspfad (Update-ClockAnchor in Common.ps1)
        // fortgeschrieben; der Guard liest ihn nur. Bewusst OHNE Support.*:
        // diese Datei wird von der Pester-Suite standalone ohne
        // NativeSupport*.cs kompiliert. Faellt auf die Systemuhr zurueck,
        // solange der Anker noch nie geschrieben wurde.
        internal static DateTime ReadClockAnchorUtc()
        {
            string dataDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "Purestate");
            try
            {
                string path = Path.Combine(dataDir, "config.json");
                if (!File.Exists(path))
                {
                    return DateTime.UtcNow;
                }

                string json = File.ReadAllText(path, Encoding.UTF8);
                Match match = Regex.Match(json, "\\\"ClockAnchorUtc\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"", RegexOptions.IgnoreCase);
                DateTime parsed;
                if (match.Success &&
                    DateTime.TryParse(match.Groups[1].Value, null, DateTimeStyles.RoundtripKind, out parsed))
                {
                    return parsed.Kind == DateTimeKind.Utc ? parsed : parsed.ToUniversalTime();
                }

                LogMissingClockAnchor("Der Anker fehlt in config.json oder ist nicht lesbar.");
            }
            catch (Exception ex)
            {
                LogMissingClockAnchor(ex.GetType().Name + " beim Lesen des Ankers.");
            }

            // GRD-020: Der Rueckfall auf die Systemuhr selbst ist richtig - der
            // Waechter darf an einem fehlenden Anker nicht haengenbleiben. Falsch
            // war, dass er lautlos passierte: fehlender Schluessel, unlesbarer
            // Wert, gesperrte Datei und Abzweigungsfehler endeten alle vier hier,
            // und der Schutz gegen das Verstellen der Uhr war damit ohne eine
            // Spur abgeschaltet. Ein zurueckgestellte Uhr gewinnt nichts (die
            // Tages- und Monatsgrenzen laufen nur vorwaerts), eine vorgestellte
            // dagegen sofort ein frisches Tagesbudget.
            return DateTime.UtcNow;
        }

        private static DateTime lastClockAnchorWarning = DateTime.MinValue;
        private static readonly object clockAnchorWarningSync = new object();

        private static void LogMissingClockAnchor(string reason)
        {
            lock (clockAnchorWarningSync)
            {
                DateTime now = VideoGameDetection.MonotonicNowUtc();
                if (now - lastClockAnchorWarning < TimeSpan.FromHours(1))
                {
                    return;
                }

                lastClockAnchorWarning = now;
            }

            Log("Clock anchor unavailable, falling back to the system clock: " + reason);
        }

        internal static DateTime ReadClockAnchorLocal()
        {
            return ReadClockAnchorUtc().ToLocalTime();
        }

        private static void StopBrowserProcesses(string browser)
        {
            string processName = browser.Equals("Chrome", StringComparison.OrdinalIgnoreCase) ? "chrome" : "msedge";
            Process[] processes = Process.GetProcessesByName(processName);
            foreach (Process process in processes)
            {
                try
                {
                    if (process.MainWindowHandle != IntPtr.Zero)
                    {
                        process.CloseMainWindow();
                    }
                }
                catch { }
                finally { process.Dispose(); }
            }

            // Der Dienst laeuft als LocalSystem in Session 0, der Browser in der
            // Sitzung des Nutzers. CloseMainWindow ist eine Fensternachricht und
            // kreuzt diese Grenze nicht (Befund L-10) - ohne den Umweg lief die
            // Schleife darunter IMMER voll aus und der Kill war in der Praxis
            // der einzige Ausgang, also genau der Tab-Verlust, den sie
            // verhindern soll.
            CloseBrowserInUserSession(processName);

            // 750 ms reichten fuer ein sauberes Beenden nicht: Chromium
            // schreibt in dieser Zeit seine Sitzung noch nicht fertig, der
            // anschliessende Kill kostete offene Tabs und ungespeicherte
            // Eingaben. Jetzt bis zu 8 Sekunden in kurzen Schritten, damit der
            // Regelfall sauber beendet.
            //
            // Der Kill bleibt als letzte Instanz: dieser Pfad laeuft nur, wenn
            // der Companion vorsaetzlich abgeschaltet wurde. Ein Browser, der
            // dann offen bleibt, waere die Umgehung selbst.
            for (int waited = 0; waited < 8000; waited += 250)
            {
                Thread.Sleep(250);
                Process[] pending = Process.GetProcessesByName(processName);
                foreach (Process process in pending)
                {
                    process.Dispose();
                }
                if (pending.Length == 0)
                {
                    return;
                }
            }

            foreach (Process process in Process.GetProcessesByName(processName))
            {
                try { process.Kill(); } catch { }
                finally { process.Dispose(); }
            }
        }

        // Bewusst kein zweiter Nachbau der Aufgabenlogik: der Weg ueber
        // Close-ChromiumBrowserInUserSession ist derselbe, den der
        // Durchsetzungslauf nutzt und der live gegengeprueft ist (taskkill ohne
        // /F, also weiterhin WM_CLOSE statt Hard-Kill). Scheitert hier etwas,
        // bleibt es beim bisherigen Verhalten - der Aufrufer wartet und killt
        // notfalls.
        private static void CloseBrowserInUserSession(string processName)
        {
            try
            {
                string windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
                string powershell = Path.Combine(windows, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
                string common = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "scripts", "Common.ps1");
                if (!File.Exists(powershell) || !File.Exists(common))
                {
                    return;
                }

                string script =
                    ". '" + common.Replace("'", "''") + "'; " +
                    "$processes = @(Get-Process -Name '" + processName + "' -ErrorAction SilentlyContinue); " +
                    "if ($processes.Count -gt 0) { " +
                    "Close-ChromiumBrowserInUserSession -ProcessName '" + processName + "' " +
                    "-RestartTarget (Get-BrowserRestartTarget -Processes $processes) | Out-Null }";
                string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));
                RunHiddenProcess(
                    powershell,
                    "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + encoded,
                    20000);
            }
            catch { }
        }

        private void OnBrowserProfileChanged(object sender, FileSystemEventArgs args)
        {
            if (!IsBrowserPreferencesFile(args.FullPath))
            {
                return;
            }

            lock (runSync)
            {
                browserDebounceTimer.Stop();
                browserDebounceTimer.Start();
            }
        }

        private void OnBrowserProfileRenamed(object sender, RenamedEventArgs args)
        {
            OnBrowserProfileChanged(sender, args);
        }

        private void RunProtectionHelper(bool browserOnly)
        {
            lock (runSync)
            {
                if (isRunning)
                {
                    if (browserOnly)
                    {
                        browserCheckPending = true;
                    }
                    return;
                }

                isRunning = true;
            }

            try
            {
                string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                string helper = Path.Combine(baseDir, "scripts", "Enforce-Protection.ps1");

                if (!File.Exists(helper))
                {
                    Log("Helper script not found: " + helper);
                    return;
                }

                string powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
                string arguments = "-NoProfile -ExecutionPolicy Bypass -File \"" + helper + "\" -Quiet" +
                    (browserOnly ? " -BrowserOnly" : string.Empty);

                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    FileName = powershell,
                    Arguments = arguments,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };

                using (Process process = Process.Start(startInfo))
                {
                    if (process == null)
                    {
                        Log("Could not start protection helper.");
                        return;
                    }

                    runningProtectionHelper = process;
                    StringBuilder output = new StringBuilder();
                    StringBuilder error = new StringBuilder();
                    process.OutputDataReceived += delegate (object sender, DataReceivedEventArgs e)
                    {
                        AppendProtectionHelperLine(output, e.Data);
                    };
                    process.ErrorDataReceived += delegate (object sender, DataReceivedEventArgs e)
                    {
                        AppendProtectionHelperLine(error, e.Data);
                    };
                    process.BeginOutputReadLine();
                    process.BeginErrorReadLine();

                    if (!process.WaitForExit(ProtectionHelperTimeoutMilliseconds))
                    {
                        try
                        {
                            process.Kill();
                            process.WaitForExit(5000);
                        }
                        catch
                        {
                        }

                        Log("Protection helper timed out.");
                        return;
                    }

                    process.WaitForExit();

                    if (process.ExitCode != 0)
                    {
                        Log("Protection helper failed with exit code " + process.ExitCode + ". " + error.ToString().Trim());
                    }
                    else if (!string.IsNullOrWhiteSpace(output.ToString()))
                    {
                        Log(output.ToString().Trim());
                    }
                }
            }
            catch (Exception ex)
            {
                Log("Service error: " + ex.Message);
            }
            finally
            {
                runningProtectionHelper = null;
                bool runPending;
                lock (runSync)
                {
                    isRunning = false;
                    runPending = browserCheckPending;
                    browserCheckPending = false;
                }

                if (runPending)
                {
                    System.Threading.ThreadPool.QueueUserWorkItem(delegate { RunProtectionHelper(true); });
                }
            }
        }

        private static void AppendProtectionHelperLine(StringBuilder builder, string line)
        {
            if (line == null || builder.Length >= MaxProtectionHelperLogChars)
            {
                return;
            }

            if (builder.Length > 0)
            {
                builder.AppendLine();
            }

            int remaining = MaxProtectionHelperLogChars - builder.Length;
            if (line.Length <= remaining)
            {
                builder.Append(line);
            }
            else
            {
                builder.Append(line.Substring(0, remaining));
            }
        }

        // GRD-023: AppendAllText oeffnet mit FileShare.Read - zwei Schreiber im
        // selben Augenblick geben eine Freigabeverletzung, die der leere catch
        // verschluckt. Und die Laengenpruefung samt WriteAllText ist ein
        // Lesen-Aendern-Schreiben, das zwei Faeden beide nehmen koennen. Mit
        // vier Bedienfaeden an der Herzschlag-Pipe (GRD-013) ist beides kein
        // Randfall mehr. Nur dieser Prozess schreibt in service.log, ein Riegel
        // im Prozess genuegt also.
        // GRD-016: Fuenf Stellen schrieben nach demselben Muster - Temp-Datei,
        // dann Replace oder Move - und keine davon raeumte die Temp-Datei auf,
        // wenn das Ersetzen scheiterte. Eine gesperrte usage.json waehrend einer
        // Sitzung hinterliess damit bei jedem Schreibversuch eine Datei mehr in
        // ProgramData, und nichts hat je wieder aufgeraeumt. Ein Weg fuer alle
        // fuenf, und er raeumt im finally auf.
        //
        // Der Aufrufer uebergibt, WIE geschrieben wird (WriteAllText,
        // WriteAllLines), weil das Zeilenende-Verhalten von WriteAllLines nicht
        // durch ein string.Join zu ersetzen ist, ohne die Datei zu veraendern.
        internal static void ReplaceFileAtomically(string path, Action<string> writeTo)
        {
            string tempPath = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                string directory = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                writeTo(tempPath);
                if (File.Exists(path))
                {
                    File.Replace(tempPath, path, null, true);
                }
                else
                {
                    File.Move(tempPath, path);
                }
            }
            finally
            {
                try
                {
                    if (File.Exists(tempPath))
                    {
                        File.Delete(tempPath);
                    }
                }
                catch
                {
                    // Bleibt die Temp-Datei liegen, ist das der Zustand von
                    // vorher - kein Grund, den Schreibfehler zu verdecken.
                }
            }
        }

        private static readonly object logSync = new object();

        private static void Log(string message)
        {
            lock (logSync)
            {
                try
                {
                    string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Purestate");
                    Directory.CreateDirectory(dataDir);
                    EnsureDataDirectoryIsNotReparsePoint(dataDir);
                    string logPath = Path.Combine(dataDir, "service.log");
                    string line = DateTime.Now.ToString("s") + " " + SanitizeServiceLogMessage(message);
                    FileInfo info = new FileInfo(logPath);
                    if (info.Exists && info.Length > MaxServiceLogBytes)
                    {
                        File.WriteAllText(logPath, line + Environment.NewLine, new UTF8Encoding(false));
                    }
                    else
                    {
                        File.AppendAllText(logPath, line + Environment.NewLine, new UTF8Encoding(false));
                    }
                }
                catch
                {
                }
            }
        }

        private static string SanitizeServiceLogMessage(string message)
        {
            string sanitized = (message ?? string.Empty)
                .Replace('\r', ' ')
                .Replace('\n', ' ')
                .Replace('\t', ' ')
                .Trim();
            if (sanitized.Length > MaxServiceLogMessageChars)
            {
                sanitized = sanitized.Substring(0, MaxServiceLogMessageChars);
            }
            return sanitized;
        }
    }
}
