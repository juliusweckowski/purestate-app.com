"use strict";

// Purestate pixiv companion.
//
// pixiv (www.pixiv.net) is a React SPA art platform with abundant R-18 content
// alongside a large body of all-ages art, so it is a mixed site: we keep the
// safe content usable and force pixiv's own server-side R-18 filtering on.
// Built from live real-DOM inspection of a logged-in account (2026-06-29).
//
// Primary protection — account viewing settings (robust, server-side):
//   /settings/viewing exposes three native checkboxes that, when OFF, make pixiv
//   filter restricted works everywhere server-side (feeds, search, and the
//   artwork pages themselves):
//     - input[name="sensitive_view_setting"]  "Display works that may contain
//                                               sensitive content"
//     - input[name="r18"]                      "Show explicit content (R-18)"
//     - input[name="r18g"]                     "Show ero-guro content (R-18G)"
//   They auto-save via React onChange (there is no separate Save button). We
//   keep all three OFF and block attempts to turn them ON. This mirrors the
//   Tumblr settings-enforcement model.
//
// Secondary protection — search mode safety:
//   pixiv search/tag URLs carry ?mode=safe|all|r18 (and r18g). We redirect the
//   explicit adult modes to mode=safe. With the account R-18 setting off this is
//   belt-and-suspenders, but it also blanks an adult search instantly.
//
// Per-post reveal backstop ("Show" cover button):
//   A restricted work that still reaches the page (e.g. an already-viewed item in
//   the History / recommendation rails) renders behind a sensitive-content cover
//   with a reveal button (real label observed live: "Show"). Pressing it un-gates
//   that single work client-side WITHOUT changing the account setting, so the
//   settings lock alone does not stop it. We click-guard and remove the reveal
//   control, matched on its short accessible text combined with a nearby
//   sensitivity marker (pixiv's class names are styled-component hashes and
//   unstable). Mirrors the DeviantArt "Show Deviation Anyway" backstop.
//
// Per-work content-level rating backstop (independent of the account setting):
//   The account viewing settings above are SERVER-SIDE and account-wide - changing
//   them from ANY device logged into the same pixiv account (e.g. a phone) takes
//   effect immediately, including on this already-"enforced" browser, with no
//   click or setting change happening here for us to guard against. Confirmed live
//   (2026-07-01): after flipping the R-18 setting via a phone on the same account,
//   a direct pixiv.net/artworks/<id> URL on the guarded PC rendered the work
//   normally, with its own "R-18"/"R-18G" tag still visible in the work's tag list
//   (pixiv tag links are always /tags/<tag>/..., already relied on above for the
//   search-mode handling). We blank the whole page with the shared overlay
//   whenever that exact tag is present anywhere on it, regardless of what the
//   account setting currently reports - so a same-account setting change made on
//   an uncontrolled device cannot un-gate a work page here.
//
// Account-wide self-heal (closes the exposure window, not just one page):
//   The direct enforcement above only fires when the three checkboxes are
//   present in THIS document (i.e. the user is on /settings/viewing in the
//   monitored browser) - it does nothing to correct a same-account setting
//   change made elsewhere while browsing a normal page. Ported from
//   DeviantArt's enforceDaAccountWide (already confirmed live to self-heal a
//   phone-side setting change within its throttle window - see
//   Handoff.md/CLAUDE.md): from any pixiv page that is not itself the settings
//   page, periodically load /settings/viewing in a hidden same-origin iframe
//   and force the checkboxes off there too, so a same-account change is
//   corrected again within PIXIV_ENFORCE_INTERVAL_MS instead of staying
//   flipped indefinitely (pixiv, unlike DeviantArt, previously had no such
//   account-wide correction at all).

const PIXIV_GUARDED_SETTING_NAMES = ["sensitive_view_setting", "r18", "r18g"];
const PIXIV_INSTANT_STYLE_ID = "purestate-pixiv-instant-style";
const PIXIV_LOCK_STYLE_ID = "purestate-pixiv-lock-style";
const PIXIV_SEARCH_OVERLAY_ID = "purestate-pixiv-search-overlay";
const PIXIV_SETTINGS_URL = "https://www.pixiv.net/settings/viewing";
const PIXIV_ENFORCE_FRAME_ID = "purestate-pixiv-enforce-frame";
const PIXIV_ENFORCE_INTERVAL_MS = 60000;

// Short reveal-button labels. Kept exact (anchored) so it never matches
// "Show more" / "Show all" / "Show comments". English plus Japanese ("表示する").
// Includes "Display": NSFW user pages show "Works that may contain sensitive
// content are not displayed" with a "Display" button that reveals the whole
// profile's restricted works at once.
const PIXIV_REVEAL_TEXT_PATTERN = /^(?:show|view|display|reveal|表示(?:する)?)$/i;
// A nearby sensitivity marker that confirms a "Show"/"View" button is a mature
// cover reveal and not an unrelated control. Required so we never nuke a generic
// "Show" button elsewhere on the site.
const PIXIV_SENSITIVE_CONTEXT_PATTERN =
  /R-?18G?\b|sensitive|may contain|may be inappropriate|explicit|わいせつ|閲覧注意/i;
// A work's own tag, matched against the exact (trimmed) text of a tag link - see
// the content-level rating backstop above.
const PIXIV_RATING_TAG_PATTERN = /^R-?18G?$/i;

let pixivObserver = null;
let pixivScanTimer = 0;
// PLT-004: Was der Beobachter gemeldet hat, und ob ein Vollbaumlauf faellig ist.
const pixivPendingRoots = [];
let pixivFullScanPending = false;
let pixivFullScanTicks = 0;
let lastPixivLocation = "";
let pixivEnforceInFlight = false;
let pixivLastEnforce = 0;
const pixivControlLastClick = new WeakMap();

purestateRunWhenSiteProtectionEnabled("pixiv", () => {
  installPixivInstantHide();
  installPixivLockStyle();
  installPixivSettingsGuard();
  installPixivMonitoring();
});

// At document_start: block an adult search TERM outright (overlay), or on an
// explicit adult MODE url blank the page and redirect to the safe mode so no
// restricted result paints.
function installPixivInstantHide() {
  if (!document.documentElement) {
    return;
  }
  if (applyPixivPageBlock()) {
    return;
  }
  if (isPixivAdultSearchUrl()) {
    purestateInstantHide(document, PIXIV_INSTANT_STYLE_ID);
    redirectPixivToSafe();
  }
}

// Extracts the user's search term from a pixiv search URL (the /tags/<tag>/ path
// segment or the ?word= query) and returns it if it is an adult search, else "".
function pixivAdultSearchTerm() {
  try {
    const url = new URL(location.href);
    if (!/(^|\.)pixiv\.net$/i.test(url.hostname)) {
      return "";
    }
    // pixiv search URLs come in two shapes: the tag route /tags/<tag>/... and
    // the /search?word=|q= form (the header search box uses ?q=). Check both
    // query params plus the tag path segment.
    const candidates = [
      url.searchParams.get("word") || "",
      url.searchParams.get("q") || ""
    ];
    const tag = url.pathname.match(/\/tags\/([^/?#]+)/i);
    if (tag) {
      candidates.push(decodeURIComponent(tag[1]));
    }
    for (const value of candidates) {
      if (value && purestateIsAdultSearchText(value)) {
        return value;
      }
    }
  } catch {
  }
  return "";
}

// True when the page carries an exact "R-18"/"R-18G" tag link, regardless of
// what the account viewing setting currently reports. Deliberately not scoped
// to artwork-detail URLs: a URL check would be easy to get wrong from reading
// pixiv's routing rather than live DOM (the exact mistake this backstop exists
// to avoid repeating - see the top-of-file note), and erring toward blocking a
// page that merely mentions the tag (e.g. a "related tags" suggestion widget)
// is the fail-closed direction Purestate already takes elsewhere. Should still
// be spot-checked live on an ordinary safe search/tag page to confirm it does
// not fire there.
function pixivViewedWorkRestricted(root) {
  const doc = root || document;
  for (const link of doc.querySelectorAll('a[href*="/tags/"]')) {
    if (PIXIV_RATING_TAG_PATTERN.test((link.textContent || "").trim())) {
      return true;
    }
  }
  return false;
}

// Block the page with the shared full-page overlay when it is an adult search OR
// the view of an R-18/R-18G-tagged work. Returns true when the page was blocked.
function applyPixivPageBlock() {
  const searchTerm = pixivAdultSearchTerm();
  const restrictedWork = !searchTerm && pixivViewedWorkRestricted();
  // EXT-A08: Hier standen Diagnoseausgaben mit dem erkannten Suchtext in
  // console.info und in data-Attributen am <html>. Die Sperre braucht davon
  // nichts, und ein Suchbegriff gehoert nicht in exportierbare Konsolenlogs.
  if (searchTerm || restrictedWork) {
    applyPixivBlockVisibility();
    purestateInstantHide(document, PIXIV_INSTANT_STYLE_ID);
    purestateShowSearchOverlay(
      document,
      PIXIV_SEARCH_OVERLAY_ID,
      pixivBlockMessage(searchTerm)
    );
    return true;
  }
  clearPixivBlockVisibility();
  purestateHideSearchOverlay(document, PIXIV_SEARCH_OVERLAY_ID, PIXIV_INSTANT_STYLE_ID);
  return false;
}

function pixivBlockMessage(searchTerm) {
  return searchTerm
    ? "Diese pixiv-Suche wurde durch Purestate blockiert."
    : "Dieser pixiv-Inhalt (R-18/R-18G) wurde durch Purestate blockiert.";
}

function restorePixivAdultSearchBlock() {
  const searchTerm = pixivAdultSearchTerm();
  if (!searchTerm) {
    return false;
  }
  applyPixivBlockVisibility();
  purestateInstantHide(document, PIXIV_INSTANT_STYLE_ID);
  purestateShowSearchOverlay(document, PIXIV_SEARCH_OVERLAY_ID, pixivBlockMessage(searchTerm));
  return true;
}

function applyPixivBlockVisibility() {
  try {
    if (document.documentElement && document.documentElement.style) {
      document.documentElement.style.setProperty("visibility", "hidden", "important");
    }
    if (document.body && document.body.style) {
      document.body.style.setProperty("visibility", "hidden", "important");
    }
  } catch {
  }
}

function clearPixivBlockVisibility() {
  try {
    if (document.documentElement && document.documentElement.style) {
      document.documentElement.style.removeProperty("visibility");
    }
    if (document.body && document.body.style) {
      document.body.style.removeProperty("visibility");
    }
  } catch {
  }
}

// Make the three guarded R-18 checkboxes (and their wrapping <label>s) literally
// un-clickable via CSS, so the user cannot even begin to toggle them on. The
// capture-phase guard stays as a backstop, and our enforcement uses a
// programmatic .click() which pointer-events:none does not block.
//
// PLT-003: Die einfachen Selektoren und die :has()-Form standen in EINER
// Gruppe. CSS verwirft bei einem unbekannten Selektor in einer Gruppe die
// GANZE Regel - ohne :has()-Unterstuetzung waere damit auch die einfache
// Sperre der Checkbox weg gewesen, nicht nur die des Labels. Heute praktisch
// folgenlos (Chromium kann :has() seit 105), aber die staerkere Regel darf
// nicht an der schwaecheren haengen. Zwei Regeln statt einer.
function installPixivLockStyle() {
  const einfach = [];
  const mitHas = [];
  for (const name of PIXIV_GUARDED_SETTING_NAMES) {
    einfach.push('input[name="' + name + '"]');
    mitHas.push('label:has(input[name="' + name + '"])');
  }
  const sperre = "{pointer-events:none !important;cursor:not-allowed !important;}";
  purestateInjectStyle(
    document,
    PIXIV_LOCK_STYLE_ID,
    einfach.join(",") + sperre + mitHas.join(",") + sperre
  );
}

function installPixivMonitoring() {
  applyPixivPageBlock();
  enforcePixivSettings(document);
  enforcePixivAccountWide();
  neutralizePixivReveal(document);
  pixivObserver = new MutationObserver((records) => schedulePixivScan(records));
  pixivObserver.observe(document.documentElement, { childList: true, subtree: true });
  setInterval(() => {
    const current = location.href;
    if (current !== lastPixivLocation) {
      lastPixivLocation = current;
      // SPA navigation: re-evaluate the adult mode redirect, then re-enforce.
      // The rating-tag page block below is re-checked on every tick regardless
      // of navigation, since a work's tag list can still be rendering
      // asynchronously right after the URL already changed.
      // NOTE: do NOT remove the instant-hide here for the non-adult-mode case.
      // An adult search *term* page is not an adult *mode* URL, so removing the
      // hide unconditionally flashed the results for one frame before
      // applyPixivPageBlock() re-blocked them. applyPixivPageBlock() below is
      // the single source of truth for the hide/overlay state (it adds the hide
      // when blocking and removes it when the page is safe), so let it decide.
      if (isPixivAdultSearchUrl()) {
        purestateInstantHide(document, PIXIV_INSTANT_STYLE_ID);
        if (redirectPixivToSafe()) {
          return;
        }
      }
      enforcePixivSettings(document);
    }
    applyPixivPageBlock();
    enforcePixivSettings(document);
    enforcePixivAccountWide();
    // PLT-004: Der Vollbaumlauf bleibt als Netz fuer alles, was ohne Mutation
    // erscheint, aber nur noch jeden zehnten Takt. Die Mutationen selbst
    // bearbeitet schedulePixivScan binnen 80 ms und nur auf ihrem Teilbaum.
    pixivFullScanTicks += 1;
    if (pixivFullScanTicks >= 10) {
      pixivFullScanTicks = 0;
      neutralizePixivReveal(document);
    }
    observePixivCanary();
  }, 1000);
}

// Selector canary (diagnostics only, see purestateCanaryObserve): when this
// document IS the settings page, the guarded R-18 checkboxes must exist.
// 15 consecutive 1s-tick misses report a selector break.
function observePixivCanary() {
  purestateCanaryObserve(
    "pixiv",
    "viewing-checkboxes",
    /^\/settings\/viewing/i.test(location.pathname || ""),
    PIXIV_GUARDED_SETTING_NAMES.some((name) =>
      !!document.querySelector("input[type='checkbox'][name='" + name + "']"))
  );
}

// Self-heal frame canary: the hidden iframe loaded PIXIV_SETTINGS_URL, so the
// guarded checkboxes must exist inside it by the end of the cycle. Three
// consecutive 60s cycles without them report a selector break (a single slow
// render never fires).
function observePixivFrameCanary(frame) {
  try {
    const doc = purestateSettingsFrameDocument(frame, "/settings/viewing");
    const found = !!(doc && doc.querySelector && PIXIV_GUARDED_SETTING_NAMES.some((name) =>
      doc.querySelector("input[type='checkbox'][name='" + name + "']")));
    purestateCanaryObserve("pixiv", "selfheal-frame", !!doc, found, 3);
  } catch {
  }
}

function schedulePixivScan(records) {
  restorePixivAdultSearchBlock();
  // PLT-004: Die gemeldeten Teilbaeume sammeln, statt gleich das ganze
  // Dokument abzulaufen. Meldet der Beobachter nichts Brauchbares, bleibt es
  // beim Vollbaumlauf - lieber einmal zu viel als ein uebersehener Knopf.
  if (records && records.length) {
    for (const record of records) {
      const added = (record && record.addedNodes) || [];
      for (const node of added) {
        if (node && node.nodeType === 1) {
          pixivPendingRoots.push(node);
        }
      }
    }
  } else {
    pixivFullScanPending = true;
  }

  if (pixivScanTimer) {
    return;
  }
  pixivScanTimer = setTimeout(() => {
    pixivScanTimer = 0;
    applyPixivPageBlock();
    enforcePixivSettings(document);
    const roots = pixivPendingRoots.splice(0, pixivPendingRoots.length);
    if (pixivFullScanPending || roots.length === 0) {
      pixivFullScanPending = false;
      neutralizePixivReveal(document);
      return;
    }
    for (const root of roots) {
      neutralizePixivRevealIn(root);
    }
  }, 80);
}

// --- Search mode safety ----------------------------------------------------

function isPixivAdultSearchUrl() {
  try {
    const url = new URL(location.href);
    if (!/(^|\.)pixiv\.net$/i.test(url.hostname)) {
      return false;
    }
    const mode = String(url.searchParams.get("mode") || "").toLowerCase();
    return mode === "r18" || mode === "r18g";
  } catch {
    return false;
  }
}

// Rewrites the explicit adult mode to mode=safe and navigates there. Returns
// true when a redirect was issued.
function redirectPixivToSafe() {
  try {
    const url = new URL(location.href);
    const mode = String(url.searchParams.get("mode") || "").toLowerCase();
    if (mode !== "r18" && mode !== "r18g") {
      return false;
    }
    url.searchParams.set("mode", "safe");
    location.replace(url.toString());
    return true;
  } catch {
    return false;
  }
}

// --- Account viewing-settings enforcement ----------------------------------

function pixivControlChecked(control) {
  if (typeof control.checked === "boolean") {
    return control.checked;
  }
  const aria = String(control.getAttribute && control.getAttribute("aria-checked") || "").toLowerCase();
  return aria === "true";
}

// Returns the guarded R-18 setting checkbox a click/keydown is targeting, or
// null. Accepts a hit on the checkbox itself or on its wrapping <label>.
function pixivGuardedSettingControl(target) {
  if (!target || typeof target.closest !== "function") {
    return null;
  }
  let control = null;
  if (typeof target.matches === "function" && target.matches("input[type='checkbox']")) {
    control = target;
  } else {
    const label = target.closest("label");
    if (label) {
      control = label.querySelector("input[type='checkbox']");
    }
  }
  if (control && PIXIV_GUARDED_SETTING_NAMES.includes(control.getAttribute("name"))) {
    return control;
  }
  return null;
}

function enforcePixivSettings(root) {
  if (!root || typeof root.querySelectorAll !== "function") {
    return;
  }
  for (const name of PIXIV_GUARDED_SETTING_NAMES) {
    const control = root.querySelector("input[type='checkbox'][name='" + name + "']");
    enforcePixivControlOff(control);
  }
}

// Turns a guarded control OFF if it is on, throttled per control so pixiv's
// React onChange handler can settle and we never fight our own click.
function enforcePixivControlOff(control) {
  if (!control || !pixivControlChecked(control)) {
    return;
  }
  const last = pixivControlLastClick.get(control) || 0;
  if (Date.now() - last < 1000) {
    return;
  }
  pixivControlLastClick.set(control, Date.now());
  try {
    control.click();
  } catch {
  }
}

// Account-wide self-heal: see the top-of-file note. From any pixiv page that
// does NOT itself have the guarded checkboxes in the DOM (direct enforcement
// above already covers that case), periodically load /settings/viewing in a
// hidden same-origin iframe and force them off there too. Ported from
// DeviantArt's enforceDaAccountWide/applyDaSafeModeInDoc - pixiv's checkboxes
// auto-save on click with no separate Save button, so this is simpler: a
// native .click() on each guarded control inside the iframe is enough.
function enforcePixivAccountWide() {
  if (document.querySelector("input[type='checkbox'][name='" + PIXIV_GUARDED_SETTING_NAMES[0] + "']")) {
    return;
  }
  const now = Date.now();
  if (pixivEnforceInFlight || now - pixivLastEnforce < PIXIV_ENFORCE_INTERVAL_MS) {
    return;
  }
  pixivEnforceInFlight = true;
  pixivLastEnforce = now;
  const existing = document.getElementById(PIXIV_ENFORCE_FRAME_ID);
  if (existing) {
    existing.remove();
  }
  const frame = document.createElement("iframe");
  frame.id = PIXIV_ENFORCE_FRAME_ID;
  frame.setAttribute("aria-hidden", "true");
  frame.style.cssText = "position:absolute!important;width:1px;height:1px;left:-9999px;top:-9999px;border:0;opacity:0;pointer-events:none;";
  frame.src = PIXIV_SETTINGS_URL;
  const finish = () => {
    pixivEnforceInFlight = false;
    try {
      frame.remove();
    } catch {
    }
  };
  frame.addEventListener("load", () => {
    setTimeout(() => {
      try {
        enforcePixivSettings(frame.contentDocument);
      } catch {
      }
      setTimeout(() => {
        observePixivFrameCanary(frame);
        finish();
      }, 1800);
    }, 600);
  });
  // Safety net in case the frame never loads (e.g. blocked by a framing policy).
  setTimeout(() => {
    if (pixivEnforceInFlight) {
      finish();
    }
  }, 9000);
  (document.body || document.documentElement).appendChild(frame);
}

function installPixivSettingsGuard() {
  const guard = (event) => {
    guardPixivSettingsClick(event);
    guardPixivRevealClick(event);
  };
  document.addEventListener("pointerdown", guard, true);
  document.addEventListener("click", guard, true);
  document.addEventListener("change", guardPixivSettingsClick, true);
  document.addEventListener("keydown", (event) => {
    if (!event || (event.key !== " " && event.key !== "Enter")) {
      return;
    }
    guard(event);
  }, true);
}

function guardPixivSettingsClick(event) {
  // Skip our own synthetic clicks so enforcement can flip controls off.
  if (event && event.isTrusted === false) {
    return;
  }
  const control = pixivGuardedSettingControl(event && event.target);
  if (!control) {
    return;
  }
  // Block only the unsafe direction: turning an R-18 setting ON (it is currently
  // off, so the activation would enable it).
  if (pixivControlChecked(control)) {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  if (event.stopImmediatePropagation) {
    event.stopImmediatePropagation();
  }
  setTimeout(() => enforcePixivSettings(document), 50);
}

// --- Per-post "Show" cover reveal guard ------------------------------------

// True when a sensitivity marker (R-18, "sensitive", etc.) sits near the
// control, confirming a short "Show"/"View" button is a mature cover reveal.
function pixivRevealHasSensitiveContext(node) {
  let current = node;
  for (let depth = 0; current && depth < 8; depth += 1) {
    const text = (current.textContent || "").slice(0, 400);
    if (text && PIXIV_SENSITIVE_CONTEXT_PATTERN.test(text)) {
      return true;
    }
    current = current.parentElement || null;
  }
  return false;
}

function pixivControlMatchesReveal(node) {
  if (!node || !node.getAttribute) {
    return false;
  }
  const tag = (node.tagName || "").toLowerCase();
  const role = node.getAttribute("role");
  if (tag !== "button" && tag !== "a" && role !== "button") {
    return false;
  }
  const text = (node.getAttribute("aria-label") || node.textContent || "").trim();
  if (!text || text.length > 24 || !PIXIV_REVEAL_TEXT_PATTERN.test(text)) {
    return false;
  }
  return pixivRevealHasSensitiveContext(node);
}

function pixivRevealControlFromPath(path) {
  if (!path || typeof path.length !== "number") {
    return null;
  }
  for (let i = 0; i < path.length; i += 1) {
    if (pixivControlMatchesReveal(path[i])) {
      return path[i];
    }
  }
  return null;
}

function pixivRevealControlFromEvent(target) {
  if (!target || !target.closest) {
    return null;
  }
  for (
    let node = target.closest('button, a, [role="button"]');
    node;
    node = node.parentElement && node.parentElement.closest
      ? node.parentElement.closest('button, a, [role="button"]')
      : null
  ) {
    if (pixivControlMatchesReveal(node)) {
      return node;
    }
  }
  return null;
}

// composedPath() exposes the real innermost target even when the reveal control
// is rendered inside a shadow root (where event.target is retargeted to the
// shadow host and closest() cannot reach the button).
function guardPixivRevealClick(event) {
  if (event && event.isTrusted === false) {
    return;
  }
  const path = event && typeof event.composedPath === "function"
    ? event.composedPath()
    : null;
  const control = pixivRevealControlFromPath(path)
    || pixivRevealControlFromEvent(event && event.target);
  if (!control) {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  if (event.stopImmediatePropagation) {
    event.stopImmediatePropagation();
  }
}

// Proactively remove reveal controls so a gated work cannot be un-gated even if
// the click guard is bypassed. Walks the light DOM plus any open shadow roots.
//
// PLT-004: Das ist ein Lauf ueber JEDES Element des Dokuments, und er lief im
// Sekundentakt UND bei jeder Mutation (80 ms entprellt). Zwei Aenderungen, beide
// ohne die Erkennung selbst anzutasten:
//   - Der Mutationsweg bearbeitet nur noch die gemeldeten Teilbaeume
//     (neutralizePixivRevealIn), nicht mehr das ganze Dokument. Genau dort ist
//     der neue Knopf ja aufgetaucht.
//   - Der Vollbaumlauf bleibt als Netz, aber nur noch jeden zehnten Takt. Er
//     faengt, was ohne Mutation erscheint - etwa ein Attribut, das sich an einem
//     laengst vorhandenen Knopf aendert (der Beobachter meldet keine Attribute).
function neutralizePixivRevealIn(node) {
  if (!node) {
    return;
  }
  if (node.nodeType === 1 && pixivControlMatchesReveal(node)) {
    disablePixivRevealControl(node);
  }
  neutralizePixivReveal(node);
}

function disablePixivRevealControl(el) {
  if (el.setAttribute) {
    el.setAttribute("disabled", "true");
  }
  if (el.style && el.style.setProperty) {
    el.style.setProperty("pointer-events", "none", "important");
    el.style.setProperty("display", "none", "important");
  }
}

function neutralizePixivReveal(doc) {
  if (!doc || typeof doc.querySelectorAll !== "function") {
    return;
  }
  for (const el of doc.querySelectorAll("*")) {
    if (pixivControlMatchesReveal(el)) {
      disablePixivRevealControl(el);
    }
    if (el.shadowRoot) {
      neutralizePixivReveal(el.shadowRoot);
    }
  }
}
