using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // Settings page: only settings that affect the whole app. There is no
    // second entry called "Einstellungen" anymore - the former kitchen-sink
    // dialog is split into two focused dialogs (Internetschutz, Zeitplan).
    internal sealed partial class AdminForm
    {
        private Button themeToggleButton;
        private TableLayoutPanel weakeningRow;
        private Label weakeningDescriptionLabel;
        private Button weakeningButton;
        private TableLayoutPanel authorityRow;
        private Label authorityTitleLabel;
        private Label authorityDescriptionLabel;
        private Button authorityButton;
        // Mehrere Geraete (Spec 2026-10-30, Abschnitt 3). Die Zeilen entstehen einmal; welche zu sehen sind,
        // bestimmt allein die Konfiguration (DeviceSyncEnabled), nie die Antwort des Waechters: "keine Antwort"
        // sieht aus wie "aus", ist es aber nicht - und "Abgleich einschalten" ueberschriebe dann den Code und
        // umginge die Wartefrist des Ausschaltens.
        private TableLayoutPanel deviceSyncOffRow;
        private TableLayoutPanel deviceSyncJoinRow;
        private TableLayoutPanel deviceSyncOnRow;
        private TableLayoutPanel deviceSyncCodeRow;
        private Label deviceSyncStatusLabel;
        private volatile bool deviceSyncRefreshRunning;
        private int deviceSyncRowsRevision;
        // Text der Zeile "Abgleich ist an", solange es keinen Stand gibt: beim Bau und nach dem Ausschalten.
        private const string DeviceSyncPlaceholder = "Wird automatisch aktualisiert.";

        // Zeigt den Zustand der Abschwaechungsfrist. Wird beim Aufbau, beim
        // Wechsel auf die Seite und nach jeder Aktion aktualisiert - bewusst
        // nicht im Sekundentakt: die Anzeige nennt Tage und Stunden, und ein
        // Konfigurationslesen gehoert nicht in einen Dauertimer.
        private void UpdateWeakeningRow()
        {
            if (weakeningDescriptionLabel == null || weakeningButton == null)
            {
                return;
            }

            AppConfig config = Support.LoadConfig();
            DateTime opensAt;
            DateTime closesAt;

            UpdateAuthorityRow(config);

            // Im Servermodus misst der Client die Frist nicht selbst. Es gibt
            // nur zwei Zustaende: eine gueltige Freigabe liegt vor, oder nicht.
            if (Support.IsServerAuthorityMode(config))
            {
                UpdateServerWeakeningRow(config);
                return;
            }

            int state = Support.EvaluateWeakeningRequest(config, Support.TrustedUtcNow(config), out opensAt, out closesAt);

            if (state == 1)
            {
                TimeSpan remaining = opensAt - Support.TrustedUtcNow(config);
                int days = (int)remaining.TotalDays;
                int hours = remaining.Hours;
                // Die kleine Stufe muss hier stehen, sonst erfaehrt niemand,
                // dass kleinere Lockerungen schon nach 24 Stunden gehen.
                DateTime minorOpensAt = opensAt.AddDays(-Support.WeakeningWaitDays).AddHours(Support.WeakeningMinorWaitHours);
                string minorHint = Support.TrustedUtcNow(config) < minorOpensAt
                    ? " Kleinere Lockerungen ab " + minorOpensAt.ToLocalTime().ToString("g") + "."
                    : " Kleinere Lockerungen sind bereits moeglich.";
                SetWeakeningRow("Noch " + days + " Tage, " + hours + " Stunden. Danach kannst du einen Tag lang lockern." + minorHint,
                    "Frist abbrechen");
            }
            else if (state == 2)
            {
                SetWeakeningRow("Du kannst noch bis " + closesAt.ToLocalTime().ToString("g") + " Einstellungen lockern.",
                    "Frist abbrechen");
            }
            else
            {
                SetWeakeningRow("Einen Schutzbereich abschalten oder abschwächen braucht sieben Tage Vorlauf; danach steht ein Tag lang offen, in dem du lockern kannst. Kleinere Lockerungen innerhalb eines Bereichs - ein Zeitlimit, eine Sperrzeit - gehen schon 24 Stunden nach dem Start der Frist.",
                    "Frist starten");
            }
        }

        // Im Servermodus ersetzt diese Anzeige die lokale. Sie nennt keine
        // Restzeit: die kennt nur der Server, und eine hier gerechnete waere
        // genau die Zahl, die der Nutzer stellen koennte.
        private void UpdateServerWeakeningRow(AppConfig config)
        {
            if (Support.IsGrantValid(config, Support.TrustedUtcNow(config)))
            {
                SetWeakeningRow("Der Server hat eine Freigabe erteilt. Du kannst jetzt Einstellungen lockern.",
                    "Freigabe abrufen");
                return;
            }

            SetWeakeningRow("Abschwächungen brauchen 72 Stunden, gemessen vom Server. Starte die Frist und rufe danach die Freigabe ab.",
                "Frist starten");
        }

        // Wie SetAuthorityRow: WrapLabel und CommandRow setzen die Namen fuer
        // Bildschirmleser einmal beim Bau der Zeile. Ohne diesen Setzer liest
        // ein Bildschirmleser in jedem Zustand den Platzhalter "Wird beim
        // Öffnen der Seite aktualisiert." und den ersten Knopftext.
        private void SetWeakeningRow(string description, string action)
        {
            Ui.SetDynamicText(weakeningDescriptionLabel, description, null);
            Ui.SetDynamicText(weakeningButton, action, null);
            Ui.SetAccessibility(weakeningRow, "Frist für Lockerungen", description, AccessibleRole.Grouping);
            Ui.SetAccessibility(weakeningDescriptionLabel, description, description, AccessibleRole.StaticText);
            Ui.SetAccessibility(weakeningButton, action, description, AccessibleRole.PushButton);
        }

        // Servermodus: Frist starten und Freigabe abrufen sind derselbe Knopf.
        // Der Server sagt, was gerade dran ist - der Client raet nicht.
        // DESK-09: bis zu zwei HTTP-Aufrufe mit je 15 s Zeitlimit - im
        // Hintergrund, damit die Verwaltung während der Anfrage reagiert.
        private void ToggleServerWeakeningRequest()
        {
            string message = null;
            RunAction("Frist für Lockerungen", delegate
            {
                string error;
                DateTime opensAt;

                if (Support.FetchGrant(out error))
                {
                    message = "Freigabe erhalten. Du kannst jetzt einen Tag lang lockern.";
                }
                else if (Support.RequestWeakening(out opensAt, out error))
                {
                    message = "Frist läuft. Ab " + opensAt.ToLocalTime().ToString("g") + " kannst du die Freigabe abrufen.";
                }
                else
                {
                    // Kein Netz ist kein Fehlerzustand, sondern eine Meldung.
                    message = error;
                }
            }, delegate (bool success)
            {
                if (success)
                {
                    ShowSaveFeedback(message);
                }
                UpdateWeakeningRow();
            });
        }

        // Freischalten und Verlassen sind derselbe Knopf: welcher Weg ansteht,
        // sagt der Modus. Zwei feste Zeilen waeren nach dem Freischalten in
        // derselben Sitzung falsch beschriftet - die Seite wird einmal gebaut.
        //
        // Der Titel wechselt mit: "Servermodus" nur fuer ein Geraet, das
        // wirklich im Servermodus ist. Seit die Einloesung den Modus nicht mehr
        // umschaltet (Support.ApplyRedeemedEntitlement), loest der Knopf eines
        // lokalen Geraets nur noch den Code ein oder verlaengert ihn.
        private void UpdateAuthorityRow(AppConfig config)
        {
            if (authorityRow == null || authorityTitleLabel == null || authorityDescriptionLabel == null || authorityButton == null)
            {
                return;
            }

            if (Support.IsServerAuthorityMode(config))
            {
                // Liegt eine gueltige Abschaltdatei vor, ist der Dienst zu
                // Ende. Dann auf einer Frist zu bestehen, die niemand mehr
                // verkuerzen kann, waere reine Haerte.
                if (Support.HasValidShutdownFile())
                {
                    SetAuthorityRow("Servermodus",
                        "Der Betreiber hat den Dienst eingestellt und das mit einer signierten Abschaltdatei bestätigt. Dieses Gerät kann jetzt ohne Frist zurück in den lokalen Modus. Der Schutz bleibt dabei unverändert aktiv.",
                        "Abschaltung anwenden");
                    return;
                }

                SetAuthorityRow("Servermodus",
                    "Dieses Gerät ist freigeschaltet. Der Weg zurück in den lokalen Modus braucht eine Freigabe des Servers: der Wechsel ist selbst eine Lockerung.",
                    "Servermodus verlassen");
                return;
            }

            SetAuthorityRow("Freischaltung",
                "Löst deinen Freischaltcode ein oder verlängert ihn mit demselben Code. Der Beta-Zeitraum gilt danach bis zum neuen Datum. An der Frist für Lockerungen ändert sich nichts.",
                "Freischalten");
        }

        // Die Namen fuer Bildschirmleser stehen sonst fest auf den Werten beim
        // Bau der Zeile - Titel "Freischaltung", Knopf "Freischalten" und ein
        // Platzhaltertext - und sagen nach einem Wechsel etwas anderes als die
        // sichtbare Beschriftung.
        private void SetAuthorityRow(string title, string description, string action)
        {
            Ui.SetDynamicText(authorityTitleLabel, title, null);
            Ui.SetDynamicText(authorityDescriptionLabel, description, null);
            Ui.SetDynamicText(authorityButton, action, null);
            Ui.SetAccessibility(authorityRow, title, description, AccessibleRole.Grouping);
            Ui.SetAccessibility(authorityDescriptionLabel, description, description, AccessibleRole.StaticText);
            Ui.SetAccessibility(authorityButton, action, description, AccessibleRole.PushButton);
        }

        private void ToggleAuthorityMode()
        {
            if (Support.IsServerAuthorityMode(Support.LoadConfig()))
            {
                if (Support.HasValidShutdownFile())
                {
                    ApplyAuthorityShutdown();
                    return;
                }

                LeaveServerAuthorityMode();
                return;
            }

            EnrollAuthorityDevice();
        }

        // Beim Start einmal nachsehen, ob der Betrieb eingestellt wurde. Nur im
        // Servermodus, nur wenn eine Adresse eingetragen ist - solange keine
        // existiert, passiert hier gar nichts. Im Hintergrund, damit ein
        // stiller Host das Fenster nicht aufhaelt. Angewendet wird nichts:
        // das bleibt eine Aktion des Nutzers, mit Passwort.
        private void StartShutdownFileCheck()
        {
            if (!Support.IsServerAuthorityMode(Support.LoadConfig()))
            {
                return;
            }

            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                bool received = false;
                try
                {
                    received = Support.TryFetchShutdownFile();
                }
                catch
                {
                }

                if (!received || !IsHandleCreated || IsDisposed)
                {
                    return;
                }

                try
                {
                    BeginInvoke(new Action(delegate { UpdateWeakeningRow(); }));
                }
                catch
                {
                }
            });
        }

        // Kein Abschwaechungsfenster: die Signatur des Betreibers ersetzt es.
        // Das Passwort bleibt, wie bei jeder Einstellungsaenderung.
        private void ApplyAuthorityShutdown()
        {
            if (!ConfirmPassword("Abschaltung anwenden"))
            {
                return;
            }

            RunAction("Abschaltung anwenden", delegate
            {
                string error;
                if (!Support.ApplyStoredShutdownFile(out error))
                {
                    throw new InvalidOperationException(error);
                }
            }, delegate (bool success)
            {
                if (success)
                {
                    ShowSaveFeedback("Die Abschaltung wurde angewendet. Dieses Gerät ist wieder im lokalen Modus.");
                }

                UpdateWeakeningRow();
            });
        }

        // Der Weg fuer den Fall, dass die Adresse laengst weg ist und jemand
        // die Datei aus einem Archiv oder von einem Dritten hat. Das Programm
        // laeuft erhoeht und liest sie von ueberall; geprueft wird sie
        // trotzdem gegen den eingebetteten Serverschluessel.
        private void ImportShutdownFile()
        {
            if (!Support.IsServerAuthorityMode(Support.LoadConfig()))
            {
                Ui.Inform(this, theme, "Abschaltdatei",
                    "Dieses Gerät ist nicht im Servermodus. Es gibt nichts anzuwenden.");
                return;
            }

            if (!ConfirmPassword("Abschaltdatei einlesen"))
            {
                return;
            }

            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Abschaltdatei einlesen";
                dialog.Filter = "Purestate Abschaltdatei|*.json|Alle Dateien|*.*";
                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }

                string path = dialog.FileName;
                RunAction("Abschaltdatei einlesen", delegate
                {
                    string error;
                    if (!Support.ApplyShutdownFileFromPath(path, out error))
                    {
                        throw new InvalidOperationException(error);
                    }
                }, delegate (bool success)
                {
                    if (success)
                    {
                        ShowSaveFeedback("Die Abschaltdatei wurde geprüft und angewendet. Dieses Gerät ist wieder im lokalen Modus.");
                    }

                    UpdateWeakeningRow();
                });
            }
        }

        // Der Rueckwechsel laeuft durch das gewoehnliche Abschwaechungs-Gate:
        // ohne gueltige Serverfreigabe lehnt Support ihn ab, und zwar mit
        // derselben Meldung wie jede andere gesperrte Lockerung.
        private void LeaveServerAuthorityMode()
        {
            if (!ConfirmPassword("Servermodus verlassen"))
            {
                return;
            }

            if (!Ui.Confirm(this, theme, "Servermodus verlassen",
                "Danach misst dieser PC die Frist für Lockerungen wieder selbst: sieben Tage statt 72 Stunden vom Server. Der Schutz bleibt unverändert aktiv.",
                "Verlassen", "Abbrechen"))
            {
                return;
            }

            RunAction("Servermodus verlassen",
                delegate { Support.LeaveServerAuthority(Support.TrustedLocalNow()); },
                delegate (bool success)
                {
                    if (success)
                    {
                        ShowSaveFeedback("Dieses Gerät ist wieder im lokalen Modus.");
                    }

                    UpdateWeakeningRow();
                });
        }

        // Loest einen Freischaltcode ein oder verlaengert ihn. Der Modus des
        // Geraets bleibt dabei, wie er ist (Support.ApplyRedeemedEntitlement).
        private void EnrollAuthorityDevice()
        {
            // Nur die eingebaute Fassungsgrenze sperrt die Freischaltung, nicht
            // eine abgelaufene Berechtigung: die Verlaengerung loest denselben
            // Code nach dem alten Ablauf erneut ein, um das neue Datum vom
            // Server zu holen. Support.IsBuildExpired ist deshalb bewusst NICHT
            // Support.IsEntitlementExpired.
            if (Support.IsBuildExpired(Support.LoadConfig()))
            {
                Ui.Inform(this, theme, "Gerät freischalten",
                    "Diese Beta-Fassung ist beendet und lässt sich nicht mehr freischalten. " +
                    "Bitte lade die neue Fassung von purestate-app.com.");
                return;
            }

            string token;
            if (!PromptText("Gerät freischalten", "Freischaltcode eingeben:", out token))
            {
                return;
            }

            // DESK-09: HTTP-Aufruf im Hintergrund statt im Klickhandler.
            string message = null;
            bool redeemed = false;
            RunAction("Gerät freischalten", delegate
            {
                string error;
                if (Support.EnrollDevice(token, out error))
                {
                    redeemed = true;
                    DateTime endsAtUtc;
                    message = Support.TryEffectiveEntitlementEnd(Support.LoadConfig(), out endsAtUtc)
                        ? "Freischaltcode eingelöst. Der Beta-Zeitraum gilt bis " + endsAtUtc.ToLocalTime().ToString("g") + ". An der Frist für Lockerungen ändert sich nichts."
                        : "Freischaltcode eingelöst. An der Frist für Lockerungen ändert sich nichts.";
                }
                else
                {
                    message = error;
                }
            }, delegate (bool success)
            {
                if (success)
                {
                    // Der Ablaufbildschirm hat keine Statuskarte. Erst nach
                    // erfolgreicher asynchroner Verlängerung den Neustarthinweis
                    // zeigen; direkt nach dem Klick ist noch nichts eingelöst.
                    if (redeemed && statusCard == null && !Support.IsEntitlementExpired(Support.LoadConfig()))
                    {
                        message += " Bitte öffne die Verwaltung erneut.";
                    }
                    ShowSaveFeedback(message);
                }
                UpdateWeakeningRow();
            });
        }

        private void ToggleWeakeningRequest()
        {
            AppConfig current = Support.LoadConfig();
            if (Support.IsServerAuthorityMode(current))
            {
                ToggleServerWeakeningRequest();
                return;
            }

            try
            {
                AppConfig config = current;
                DateTime opensAt;
                DateTime closesAt;
                if (Support.EvaluateWeakeningRequest(config, Support.TrustedUtcNow(config), out opensAt, out closesAt) == 0)
                {
                    DateTime readyAt = Support.BeginWeakeningRequest();
                    // GAT-001: Die Meldung nannte nur die grosse Frist. Das Gate
                    // kennt zwei - kleinere Lockerungen gehen schon nach 24
                    // Stunden -, und die Statuszeile sagt das auch. Nur
                    // ausgerechnet der Moment, in dem der Nutzer die Frist
                    // startet, verschwieg es: er ging davon aus, sieben Tage
                    // lang gar nichts aendern zu koennen.
                    DateTime minorReadyAt = readyAt
                        .AddDays(-Support.WeakeningWaitDays)
                        .AddHours(Support.WeakeningMinorWaitHours);
                    ShowSaveFeedback("Frist gestartet. Kleinere Lockerungen ab " +
                        minorReadyAt.ToLocalTime().ToString("g") + ", ab " +
                        readyAt.ToLocalTime().ToString("g") + " kannst du einen Tag lang alles lockern.");
                }
                else
                {
                    Support.CancelWeakeningRequest();
                    ShowSaveFeedback("Frist abgebrochen.");
                }
            }
            catch (Exception ex)
            {
                ShowErrorDialog("Frist für Lockerungen", ex);
            }

            UpdateWeakeningRow();
        }

        private void BuildDeviceSyncSection(TableLayoutPanel page)
        {
            AddSectionTitle(page, "Mehrere Geräte");
            deviceSyncOffRow = AddActionRow(page, "Abgleich ist aus",
                "Verbrauchte Zeit und Limits gelten nur auf diesem Gerät.",
                "Abgleich einschalten", delegate { EnableDeviceSync(); }, false);
            deviceSyncJoinRow = AddActionRow(page, "Code von einem anderen Gerät",
                "Gib den Code ein, den dein anderes Gerät anzeigt.",
                "Ich habe schon einen Code", delegate { JoinDeviceSync(); }, false);
            deviceSyncOnRow = AddActionRow(page, "Abgleich ist an",
                DeviceSyncPlaceholder,
                "Abgleich ausschalten", delegate { DisableDeviceSync(); }, false);
            TableLayoutPanel statusCopy = deviceSyncOnRow.GetControlFromPosition(0, 0) as TableLayoutPanel;
            deviceSyncStatusLabel = statusCopy == null ? null : statusCopy.GetControlFromPosition(0, 1) as Label;
            if (deviceSyncStatusLabel != null)
            {
                // Die Namen anderer Geraete sind Text, kein Tastaturkuerzel: ein & bliebe sonst weg.
                deviceSyncStatusLabel.UseMnemonic = false;
            }

            deviceSyncCodeRow = AddActionRow(page, "Kopplungscode",
                "Zeigt den Code, mit dem sich weitere Geräte verbinden.",
                "Code anzeigen", delegate { ShowDeviceSyncCode(); }, false);
            UpdateDeviceSyncRows();
        }

        private void UpdateDeviceSyncRows()
        {
            if (deviceSyncOffRow == null)
            {
                return;
            }

            bool on = Support.LoadConfig().DeviceSyncEnabled;
            deviceSyncRowsRevision++;
            UpdateDeviceSyncRows(on);
        }

        private void UpdateDeviceSyncRows(bool on)
        {
            deviceSyncOffRow.Visible = !on;
            deviceSyncJoinRow.Visible = !on;
            deviceSyncOnRow.Visible = on;
            deviceSyncCodeRow.Visible = on;
        }

        // Beim Oeffnen und im vorhandenen Fenstertakt: nur sichtbare Einstellungen lesen den lokalen Stand.
        // Die Pipe kann bis zu 10 s brauchen, also im Hintergrund wie
        // RunUpdateStartupTasks - nicht in RunAction: das sperrt alle Knoepfe und stoesst eine Statusabfrage an,
        // und ein stiller Abruf beim Oeffnen einer Seite soll weder das eine noch das andere.
        private void RefreshDeviceSync()
        {
            if (!Visible || WindowState == FormWindowState.Minimized || !string.Equals(currentPageKey, "settings", StringComparison.Ordinal))
            {
                return;
            }
            if (deviceSyncStatusLabel == null || deviceSyncRefreshRunning)
            {
                return;
            }

            deviceSyncRefreshRunning = true;
            int revision = deviceSyncRowsRevision;
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                DeviceSyncStatus status = null;
                AppConfig config = null;
                try
                {
                    AppConfig current = Support.LoadConfig();
                    if (current.DeviceSyncEnabled)
                    {
                        try { status = Support.QueryDeviceSyncStatus(); }
                        catch { }
                        current = Support.LoadConfig();
                    }
                    config = current;
                }
                catch
                {
                }

                try
                {
                    if (IsHandleCreated && !IsDisposed)
                    {
                        BeginInvoke(new Action(delegate
                        {
                            try
                            {
                                // Eine inzwischen abgeschlossene An-/Aus-Aktion hat Vorrang vor dieser Antwort.
                                if (revision != deviceSyncRowsRevision) { return; }
                                if (config == null)
                                {
                                    SetDeviceSyncRow("Der Stand der Geräte ist gerade nicht abrufbar.");
                                    return;
                                }
                                UpdateDeviceSyncRows(config.DeviceSyncEnabled);
                                ShowDeviceSyncStatus(status, config);
                            }
                            finally { deviceSyncRefreshRunning = false; }
                        }));
                        return;
                    }
                }
                catch
                {
                }
                deviceSyncRefreshRunning = false;
            });
        }

        // Setzt den Text der Zeile "Abgleich ist an": die Geraeteliste mit den Hinweisen oder, ohne Antwort des
        // Waechters, die Auskunft, dass es gerade keinen Stand gibt. Die Namen fuer Bildschirmleser ziehen mit
        // (wie SetWeakeningRow).
        private void ShowDeviceSyncStatus(DeviceSyncStatus status, AppConfig config)
        {
            if (IsDisposed || deviceSyncStatusLabel == null) { return; }
            if (!config.DeviceSyncEnabled)
            {
                return;
            }
            if (status == null || !status.UsageAvailable)
            {
                List<string> contacts = Support.DeviceSyncContactLines(status, Support.TrustedUtcNow(config));
                if (contacts.Count > 0)
                {
                    contacts.Add(string.Empty);
                    contacts.Add("Nutzungsdaten sind gerade nicht abrufbar.");
                }
                SetDeviceSyncRow(contacts.Count == 0 ? "Der Stand der Geräte ist gerade nicht abrufbar." : string.Join(Environment.NewLine, contacts.ToArray()));
                return;
            }

            // Der Waechter nennt bei Vollsperre und strengen Spielen "eigen 0"; dort gilt kein fremdes Limit.
            Support.DropInapplicableDeviceSyncLimits(status, config);
            List<string> lines = Support.DeviceSyncStatusLines(status, Support.TrustedUtcNow(config));
            // Die ersten Zeilen sind die Geraete (dieser PC, dann die anderen), danach kommen die Hinweise;
            // eine Leerzeile trennt beides.
            int devices = 1 + (status == null ? 0 : status.Peers.Count);
            if (lines.Count > devices)
            {
                lines.Insert(devices, string.Empty);
            }

            List<string> summary = Support.DeviceSyncUsageSummaryLines(status, config);
            if (summary.Count > 0)
            {
                summary.Add("Nach zuletzt bekanntem Abgleichstand. Andere Schutzregeln, etwa Sperrzeiten, gelten weiter.");
                summary.Add(string.Empty);
                summary.AddRange(lines);
                lines = summary;
            }
            string text = lines.Count == 0 ? "Der Stand der Geräte ist gerade nicht abrufbar." : string.Join(Environment.NewLine, lines.ToArray());
            SetDeviceSyncRow(text);
        }

        // Die einzige Stelle, die den Text der Zeile "Abgleich ist an" schreibt, samt den Namen fuer Bildschirmleser.
        private void SetDeviceSyncRow(string text)
        {
            if (deviceSyncStatusLabel == null)
            {
                return;
            }
            if (deviceSyncStatusLabel.Text == text)
            {
                return;
            }

            Ui.SetDynamicText(deviceSyncStatusLabel, text, null);
            Ui.SetAccessibility(deviceSyncOnRow, "Abgleich ist an", text, AccessibleRole.Grouping);
        }

        private void EnableDeviceSync()
        {
            if (!ConfirmPassword("Abgleich einschalten"))
            {
                return;
            }

            // Der Code entsteht hier und nicht im Hintergrundlauf: der Dialog danach zeigt genau ihn.
            string code = Support.GenerateDeviceSyncCode();
            TurnDeviceSyncOn(code, true);
        }

        // Der gemeinsame Teil von "Abgleich einschalten" und "Ich habe schon einen Code", nach dem Passwort.
        // showCode: das erste Geraet zeigt den Code nach dem Einschalten (Spec 3), ein weiteres hat ihn ja eingetippt.
        private void TurnDeviceSyncOn(string code, bool showCode)
        {
            RunAction("Abgleich einschalten", delegate
            {
                Support.EnableDeviceSyncGuarded(code, Support.TrustedLocalNow(), false);
            }, delegate (bool success)
            {
                UpdateDeviceSyncRows();
                if (success)
                {
                    RefreshDeviceSync();
                    if (showCode)
                    {
                        ShowDeviceSyncCode();
                    }
                }
            }, delegate (Exception failure)
            {
                ShowDeviceSyncFailure("Abgleich einschalten", failure);
            });
        }

        private void JoinDeviceSync()
        {
            string input;
            if (!PromptText("Ich habe schon einen Code", "Code von deinem anderen Gerät eingeben:", out input))
            {
                return;
            }

            // Das Pruefzeichen faengt Tippfehler, bevor etwas gespeichert oder das Passwort gefragt wird.
            string code;
            if (!Support.TryNormalizeDeviceSyncCode(input, out code))
            {
                Ui.Inform(this, theme, "Mehrere Geräte", "Das ist kein gültiger Code. Prüfe ihn auf dem anderen Gerät.");
                return;
            }

            if (!ConfirmPassword("Abgleich einschalten"))
            {
                return;
            }

            TurnDeviceSyncOn(code, false);
        }

        private void DisableDeviceSync()
        {
            if (!ConfirmPassword("Abgleich ausschalten"))
            {
                return;
            }

            if (!Ui.Confirm(this, theme, "Abgleich ausschalten",
                "Danach zählt jedes Gerät wieder für sich. Ein strengeres Limit von hier gilt auf den anderen Geräten noch bis zu 7 Tage.",
                "Ausschalten", "Abbrechen"))
            {
                return;
            }

            RunAction("Abgleich ausschalten", delegate
            {
                // Das Abschwaechungs-Gate lehnt ab, solange die Frist nicht offen ist: dann wirft dieser Aufruf, die
                // Meldung steht unten im Klartext, und der Code bleibt. Geloescht wird er erst danach - fehlt er bei
                // eingeschalteter Option, ist der Abgleich unterbrochen, nicht aus (Spec 8).
                Support.SetDeviceSyncEnabledGuarded(false, Support.TrustedLocalNow(), false);
                Support.DeleteDeviceSyncCode();
            }, delegate (bool success)
            {
                // Der Text der Zeile gehoert zu den Geraeten von eben: nach einem neuen Einschalten soll er nicht
                // stehen, bis die erste Antwort da ist.
                if (success)
                {
                    SetDeviceSyncRow(DeviceSyncPlaceholder);
                }

                UpdateDeviceSyncRows();
            }, delegate (Exception failure)
            {
                ShowDeviceSyncFailure("Abgleich ausschalten", failure);
            });
        }

        // Die Meldung einer Ablehnung (das Gate mit seiner Frist, das veraltete Einschalten, eine beschaedigte
        // Konfiguration) ist fuer Nutzer geschrieben und steht im Klartext. Jede andere Ausnahme (Schluesseldatei,
        // Konfigurationssperre) ist ein Fehler mit "Technische Details anzeigen": der Satz "Deine Eingaben sind noch
        // da" aus DescribeSaveFailure stimmte in diesen Wegen ohne Dialog nicht. Wie beim Pausieren und beim Backup.
        private void ShowDeviceSyncFailure(string name, Exception failure)
        {
            if (failure is InvalidOperationException)
            {
                Ui.Inform(this, theme, name, DescribeSaveFailure(failure));
                return;
            }

            ShowErrorDialog(name, failure);
        }

        // "Code anzeigen" und der Dialog nach dem ersten Einschalten. Ein Textfeld statt eines Labels: so laesst
        // sich der Code markieren und kopieren.
        private void ShowDeviceSyncCode()
        {
            string code = Support.ReadDeviceSyncCode();
            if (code.Length == 0)
            {
                Ui.Inform(this, theme, "Mehrere Geräte", "Der Code lässt sich gerade nicht lesen. Versuche es gleich noch einmal.");
                return;
            }

            using (DialogShell dialog = new DialogShell(theme, "Kopplungscode",
                "Gib diesen Code auf deinen anderen Geräten ein. Du findest ihn später hier wieder.",
                "Zeigt den Kopplungscode für den Abgleich zwischen Geräten.", false))
            {
                TextBox box = new TextBox { Text = code, ReadOnly = true, Font = Ui.FontMono, Width = Dpi.Px(400) };
                Ui.SetAccessibility(box, "Kopplungscode", "Der Code für deine anderen Geräte, zum Markieren und Kopieren.", AccessibleRole.Text);
                dialog.Add(box);
                dialog.FinishLayout();
                dialog.Shown += delegate { box.Focus(); box.SelectAll(); };
                dialog.ShowDialog(this);
            }
        }

        private void BuildSettingsPage()
        {
            TableLayoutPanel page = CreatePage("settings");
            AddPageTitle(page, "Einstellungen");
            AddPageHint(page, "Allgemeine Einstellungen für ganz Purestate. Die Schutzbereiche stellst du auf der Seite „Schutzbereiche“ ein.");

            AddSectionTitle(page, "Sicherheit");
            AddActionRow(page, "Passwort ändern",
                "Legt ein neues Purestate-Passwort und einen optionalen Hinweis fest.",
                "Ändern", delegate { ChangePassword(); }, false);

            AddSectionTitle(page, "Schutz im Internet");
            AddActionRow(page, "Internetschutz einstellen",
                "Webseiten auf diesem PC blockieren, zusätzlicher Internetfilter, Umgehungsschutz.",
                "Einstellen", delegate { ShowInternetProtectionSettings(); }, false);

            AddSectionTitle(page, "Zeitplan und Pausen");
            AddActionRow(page, "Zeitplan und Pausenregeln einstellen",
                "Schutz jeden Tag automatisch aktivieren und festlegen, ob Pausieren erlaubt ist.",
                "Einstellen", delegate { ShowScheduleSettings(); }, false);

            AddSectionTitle(page, "Einstellungen lockern");
            weakeningRow = AddActionRow(page, "Frist für Lockerungen",
                "Wird beim Öffnen der Seite aktualisiert.",
                "Frist starten", delegate { ToggleWeakeningRequest(); }, false);
            TableLayoutPanel weakeningCopy = weakeningRow.GetControlFromPosition(0, 0) as TableLayoutPanel;
            weakeningDescriptionLabel = weakeningCopy == null ? null : weakeningCopy.GetControlFromPosition(0, 1) as Label;
            weakeningButton = weakeningRow.GetControlFromPosition(1, 0) as Button;
            UpdateWeakeningRow();

            // AUTH-001: Solange keine Serveradresse eingetragen ist, gibt es
            // keinen Freischaltcode und keine Abschaltdatei - beide Zeilen
            // koennten nur in einer Fehlermeldung enden. Ein freigeschaltetes
            // Geraet sieht sie weiterhin, sonst faende es nicht zurueck.
            if (Support.ServerAuthorityUiAvailable(Support.LoadConfig()))
            {
                authorityRow = AddActionRow(page, "Freischaltung",
                    "Wird beim Öffnen der Seite aktualisiert.",
                    "Freischalten", delegate { ToggleAuthorityMode(); }, false);
                TableLayoutPanel authorityCopy = authorityRow.GetControlFromPosition(0, 0) as TableLayoutPanel;
                authorityTitleLabel = authorityCopy == null ? null : authorityCopy.GetControlFromPosition(0, 0) as Label;
                authorityDescriptionLabel = authorityCopy == null ? null : authorityCopy.GetControlFromPosition(0, 1) as Label;
                authorityButton = authorityRow.GetControlFromPosition(1, 0) as Button;
                UpdateAuthorityRow(Support.LoadConfig());

                // Die Abschaltdatei holt nur ein Geraet im Servermodus zurueck.
                // Fuer jedes andere - also jedes Beta-Geraet im lokalen Modus -
                // endete die Zeile in "Es gibt nichts anzuwenden".
                if (Support.IsServerAuthorityMode(Support.LoadConfig()))
                {
                    AddActionRow(page, "Abschaltdatei einlesen",
                        "Falls Purestate als Dienst eingestellt wird, veröffentlicht der Betreiber eine signierte Abschaltdatei. Sie holt dieses Gerät ohne Frist zurück in den lokalen Modus.",
                        "Datei wählen", delegate { ImportShutdownFile(); }, false);
                }
                StartShutdownFileCheck();
            }

            // Mehrere Geraete (Spec 2026-10-30): nur auf einem freigeschalteten Geraet. Ohne Geraeteschluessel
            // kennt der Server das Geraet nicht, und ein Abgleich bliebe ohne Wirkung.
            if (Support.TryReadDevicePublicKey().Length > 0)
            {
                BuildDeviceSyncSection(page);
            }

            AddSectionTitle(page, "Darstellung");
            themeToggleButton = Ui.SecondaryButton(theme,
                theme.IsDark ? "Helles Design einschalten" : "Dunkles Design einschalten",
                "Wechselt zwischen hellem und dunklem Purestate-Design.");
            themeToggleButton.Click += delegate { ToggleTheme(); };
            themeToggleButton.Enabled = !theme.IsHighContrast;
            page.Controls.Add(themeToggleButton);
            actionButtons.Add(themeToggleButton);
            if (theme.IsHighContrast)
            {
                AddPageHint(page, "Windows-Hochkontrast ist aktiv. Purestate verwendet dann automatisch deine Systemfarben.");
            }
            themeAppliers.Add(delegate
            {
                Ui.StyleSecondary(theme, themeToggleButton);
                Ui.SetDynamicText(themeToggleButton, theme.IsDark ? "Helles Design einschalten" : "Dunkles Design einschalten", null);
            });
        }
    }
}
