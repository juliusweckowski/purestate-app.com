using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace Purestate.Native
{
    internal sealed class VideoGameTarget
    {
        public bool Enabled = true;
        public bool Launcher;
        public string Name = string.Empty;
        public string Path = string.Empty;
    }

    // A "kein Spiel" exemption for the detection heuristic. Created only via
    // the app (password-gated) and effective 15 minutes after creation so it
    // can never rescue a running gaming session; the guard ignores entries
    // whose activation time has not been reached yet.
    internal sealed class VideoGameExemption
    {
        public DateTime ActivatesAtUtc;
        public string Path = string.Empty;
    }

    internal static partial class Support
    {
        public static string VideoGameTargetsPath()
        {
            return Path.Combine(InstallDir, "rules", "video-game-targets.txt");
        }

        // Runtime usage counter written by the guard (see
        // src\PurestateGuardVideoGames.cs, which owns the format). The app only
        // reads it for display; both sides parse defensively.
        public static string VideoGamesUsagePath
        {
            get { return Path.Combine(DataDir, "video-games-usage.json"); }
        }

        public static int NormalizeVideoGamesDailyLimitMinutes(int minutes)
        {
            return (minutes >= 5 && minutes <= 600) ? minutes : 60;
        }

        // Mode semantics for the video-games area: "off" (no monitoring),
        // "gentle" (daily runtime budget and curfew act on the configured
        // targets), "strict" (enabled targets are fully blocked). "planned" is
        // only the pre-0.62.29 placeholder value and never re-written once the
        // area has been configured.
        public static string NormalizeVideoGamesMode(string mode, bool enabled)
        {
            string value = (mode ?? string.Empty).Trim().ToLowerInvariant();
            if (!enabled)
            {
                return value == "planned" ? "planned" : "off";
            }

            return (value == "strict") ? "strict" : "gentle";
        }

        // TGT-004: Hier stand ein zweiter, oeffentlicher Setter, der bis auf
        // UpdateConfig statt UpdateConfigWithWeakeningGate identisch war - und
        // damit das Abschwaechungsfenster umging. Er hatte im ganzen
        // Repository KEINEN Aufrufer; der Dialog nutzt ausschliesslich die
        // Guarded-Fassung. Kein aktiver Fehler, aber eine geladene Waffe: die
        // naechste Oberflaeche haette zwei gleich aussehende Methoden
        // vorgefunden, von denen eine am Gate vorbeischreibt. Genau so
        // entstehen die Befunde aus 04-root-cause-weakening-gate.md.

        public static void SetVideoGamesSettingsGuarded(bool enabled, string mode, bool dailyLimitEnabled, int dailyLimitMinutes, bool curfewEnabled, string curfewStart, string curfewEnd, bool autoDetectEnabled, bool heuristicEnabled, DateTime localNow, bool devModeActive)
        {
            UpdateConfigWithWeakeningGate(delegate (AppConfig config)
            {
                config.VideoGamesProtectionEnabled = enabled;
                config.VideoGamesProtectionMode = enabled ? NormalizeVideoGamesMode(mode, true) : "off";
                config.VideoGamesDailyLimitEnabled = dailyLimitEnabled;
                config.VideoGamesDailyLimitMinutes = NormalizeVideoGamesDailyLimitMinutes(dailyLimitMinutes);
                config.VideoGamesCurfewEnabled = curfewEnabled;
                config.VideoGamesCurfewStart = NormalizeTimeText(curfewStart, "22:00");
                config.VideoGamesCurfewEnd = NormalizeTimeText(curfewEnd, "06:00");
                config.VideoGamesAutoDetectEnabled = autoDetectEnabled;
                config.VideoGamesHeuristicEnabled = autoDetectEnabled && heuristicEnabled;
            }, localNow, devModeActive);
        }

        public static void ThrowIfVideoGameTargetsWeakeningNotAllowed(IEnumerable<VideoGameTarget> currentTargets, IEnumerable<VideoGameTarget> nextTargets, DateTime localNow, bool devModeActive)
        {
            // Diese Pruefung bekommt keine Konfiguration gereicht, anders als
            // RequireProtectionWeakeningWindow. Ein Ladevorgang beim Speichern
            // eines Dialogs faellt nicht ins Gewicht.
            AppConfig config = LoadConfig();
            // Ein Spiel von der Liste nehmen ist eine kleine Abschwaechung:
            // der Bereich bleibt an, es faellt ein einzelnes Ziel weg. Damit
            // 24 Stunden statt sieben Tage.
            if (IsVideoGameTargetsWeakening(currentTargets, nextTargets) &&
                !IsProtectionWeakeningAllowed(config, localNow.ToUniversalTime(), devModeActive, false))
            {
                throw new InvalidOperationException(ProtectionWeakeningGateMessage(
                    "Videospiele: Zielliste", IsServerAuthorityMode(config), false));
            }
        }

        public static bool IsVideoGameTargetsWeakening(IEnumerable<VideoGameTarget> currentTargets, IEnumerable<VideoGameTarget> nextTargets)
        {
            HashSet<string> before = EnabledVideoGameTargetPathSet(currentTargets);
            HashSet<string> after = EnabledVideoGameTargetPathSet(nextTargets);
            foreach (string path in before)
            {
                if (!after.Contains(path))
                {
                    return true;
                }
            }
            return false;
        }

        private static HashSet<string> EnabledVideoGameTargetPathSet(IEnumerable<VideoGameTarget> targets)
        {
            HashSet<string> paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (VideoGameTarget target in targets ?? new VideoGameTarget[0])
            {
                if (target == null || !target.Enabled)
                {
                    continue;
                }

                string path = NormalizeVideoGameTargetPathForComparison(target.Path);
                if (path.Length > 0)
                {
                    paths.Add(path);
                }
            }
            return paths;
        }

        private static string NormalizeVideoGameTargetPathForComparison(string path)
        {
            try
            {
                return Path.GetFullPath((path ?? string.Empty).Trim());
            }
            catch
            {
                return string.Empty;
            }
        }

        // ---- Target safety validation ------------------------------------------

        // Core Windows / session / shell / security processes plus every
        // Purestate component. Matched by file name so a copy of e.g.
        // winlogon.exe outside System32 is refused too. Mirrored (and pinned by
        // tests) in src\PurestateGuardVideoGames.cs, which is compiled without
        // this assembly.
        private static readonly string[] CriticalTargetFileNames =
        {
            "smss.exe", "csrss.exe", "wininit.exe", "winlogon.exe", "services.exe",
            "lsass.exe", "svchost.exe", "dwm.exe", "explorer.exe", "taskmgr.exe",
            "conhost.exe", "cmd.exe", "powershell.exe", "powershell_ise.exe", "pwsh.exe",
            "regedit.exe", "mmc.exe", "msiexec.exe", "dllhost.exe", "runtimebroker.exe",
            "sihost.exe", "fontdrvhost.exe", "ctfmon.exe", "logonui.exe", "userinit.exe",
            "msmpeng.exe", "nissrv.exe", "mpcmdrun.exe", "securityhealthservice.exe",
            "securityhealthsystray.exe",
            "purestate.exe", "purestateguard.exe", "purestatenativehost.exe",
            "purestateuninstaller.exe", "installieren.exe"
        };

        // Well-known game platform launchers. Selecting one is allowed, but
        // only with an explicit launcher flag and a broad-impact warning in the
        // UI - never blocked by default.
        private static readonly string[] KnownGameLauncherFileNames =
        {
            "steam.exe", "epicgameslauncher.exe", "eadesktop.exe", "origin.exe",
            "ubisoftconnect.exe", "upc.exe", "battle.net.exe", "riotclientservices.exe",
            "riotclient.exe", "galaxyclient.exe"
        };

        public static bool IsKnownGameLauncherPath(string path)
        {
            string fileName;
            try
            {
                fileName = Path.GetFileName(path ?? string.Empty);
            }
            catch (ArgumentException)
            {
                return false;
            }
            foreach (string launcher in KnownGameLauncherFileNames)
            {
                if (string.Equals(fileName, launcher, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        public static string ValidateVideoGameTargetPath(string path)
        {
            return ValidateVideoGameTargetPath(
                path,
                Environment.GetFolderPath(Environment.SpecialFolder.Windows),
                InstallDir);
        }

        // Returns an empty string when the path is a safe target, otherwise a
        // user-readable German refusal reason. Directory-parameterized so tests
        // never depend on the real Windows / Program Files layout.
        internal static string ValidateVideoGameTargetPath(string path, string windowsDir, string installDir)
        {
            string trimmed = (path ?? string.Empty).Trim();
            if (trimmed.Length == 0)
            {
                return "Es wurde keine Programmdatei angegeben.";
            }

            string fullPath;
            try
            {
                if (!Path.IsPathRooted(trimmed))
                {
                    return "Bitte einen vollstaendigen Pfad zur Programmdatei angeben.";
                }
                fullPath = Path.GetFullPath(trimmed);
            }
            catch (Exception)
            {
                return "Der Pfad ist keine gueltige Programmdatei.";
            }

            string root = Path.GetPathRoot(fullPath) ?? string.Empty;
            if (root.Length < 2 || (root.Length == 2 && root[1] == System.IO.Path.VolumeSeparatorChar))
            {
                return "Bitte einen vollstaendigen Pfad zur Programmdatei angeben.";
            }

            if (!string.Equals(Path.GetExtension(fullPath), ".exe", StringComparison.OrdinalIgnoreCase))
            {
                return "Nur ausfuehrbare .exe-Dateien koennen als Spielziel gewaehlt werden.";
            }

            if (IsPathInsideDirectory(fullPath, windowsDir))
            {
                return "Programme aus Windows-Systemverzeichnissen koennen nicht als Spielziel gewaehlt werden.";
            }

            if (IsPathInsideDirectory(fullPath, installDir))
            {
                return "Purestate-Komponenten koennen nicht als Spielziel gewaehlt werden.";
            }

            string fileName = Path.GetFileName(fullPath);
            foreach (string critical in CriticalTargetFileNames)
            {
                if (string.Equals(fileName, critical, StringComparison.OrdinalIgnoreCase))
                {
                    return "\"" + fileName + "\" ist ein System-, Sicherheits- oder Purestate-Prozess und kann nicht als Spielziel gewaehlt werden.";
                }
            }

            return string.Empty;
        }

        private static bool IsPathInsideDirectory(string fullPath, string directory)
        {
            if (string.IsNullOrWhiteSpace(directory))
            {
                return false;
            }

            string normalizedDirectory;
            try
            {
                normalizedDirectory = Path.GetFullPath(directory)
                    .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            }
            catch (Exception)
            {
                return false;
            }

            return fullPath.StartsWith(normalizedDirectory, StringComparison.OrdinalIgnoreCase);
        }

        // ---- Target list persistence ---------------------------------------------

        // One target per line: "enabled|launcher|display name|full path".
        // Comments (#) and blank lines are ignored; malformed or unsafe lines
        // are dropped on read so a hand-edited file can never smuggle a
        // critical process into the kill list.
        public static string FormatVideoGameTargetLine(VideoGameTarget target)
        {
            if (target == null)
            {
                throw new ArgumentNullException("target");
            }

            return (target.Enabled ? "1" : "0") + "|" +
                (target.Launcher ? "1" : "0") + "|" +
                CleanVideoGameTargetName(target.Name) + "|" +
                target.Path;
        }

        public static VideoGameTarget ParseVideoGameTargetLine(string line)
        {
            return ParseVideoGameTargetLine(
                line,
                Environment.GetFolderPath(Environment.SpecialFolder.Windows),
                InstallDir);
        }

        internal static VideoGameTarget ParseVideoGameTargetLine(string line, string windowsDir, string installDir)
        {
            string trimmed = (line ?? string.Empty).Trim();
            if (trimmed.Length == 0 || trimmed.StartsWith("#"))
            {
                return null;
            }

            string[] parts = trimmed.Split(new[] { '|' }, 4);
            if (parts.Length != 4)
            {
                return null;
            }

            string path = parts[3].Trim();
            if (ValidateVideoGameTargetPath(path, windowsDir, installDir).Length != 0)
            {
                return null;
            }

            string fullPath;
            try
            {
                fullPath = Path.GetFullPath(path);
            }
            catch (Exception)
            {
                return null;
            }

            string name = CleanVideoGameTargetName(parts[2]);
            if (name.Length == 0)
            {
                name = Path.GetFileNameWithoutExtension(fullPath);
            }

            return new VideoGameTarget
            {
                Enabled = parts[0].Trim() == "1",
                Launcher = parts[1].Trim() == "1" || IsKnownGameLauncherPath(fullPath),
                Name = name,
                Path = fullPath
            };
        }

        public static string CleanVideoGameTargetName(string name)
        {
            string value = (name ?? string.Empty)
                .Replace('|', ' ')
                .Replace('\r', ' ')
                .Replace('\n', ' ')
                .Replace('\t', ' ')
                .Trim();
            while (value.Contains("  "))
            {
                value = value.Replace("  ", " ");
            }
            if (value.Length > 60)
            {
                value = value.Substring(0, 60).Trim();
            }
            return value;
        }

        public static List<VideoGameTarget> ReadVideoGameTargets()
        {
            return ReadVideoGameTargets(
                VideoGameTargetsPath(),
                Environment.GetFolderPath(Environment.SpecialFolder.Windows),
                InstallDir);
        }

        internal static List<VideoGameTarget> ReadVideoGameTargets(string path, string windowsDir, string installDir)
        {
            List<VideoGameTarget> targets = new List<VideoGameTarget>();
            if (!File.Exists(path))
            {
                return targets;
            }

            HashSet<string> seenPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string raw in File.ReadAllLines(path))
            {
                VideoGameTarget target = ParseVideoGameTargetLine(raw, windowsDir, installDir);
                if (target == null || !seenPaths.Add(target.Path))
                {
                    continue;
                }
                targets.Add(target);
            }
            return targets;
        }

        public static void WriteVideoGameTargets(IEnumerable<VideoGameTarget> targets)
        {
            WriteVideoGameTargets(
                targets,
                VideoGameTargetsPath(),
                Environment.GetFolderPath(Environment.SpecialFolder.Windows),
                InstallDir);
        }

        internal static void WriteVideoGameTargets(IEnumerable<VideoGameTarget> targets, string path, string windowsDir, string installDir)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("# Purestate Videospiel-Ziele");
            builder.AppendLine("# Format: aktiv(0/1)|launcher(0/1)|Name|vollstaendiger Pfad");
            HashSet<string> seenPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (VideoGameTarget target in targets ?? new VideoGameTarget[0])
            {
                if (target == null ||
                    ValidateVideoGameTargetPath(target.Path, windowsDir, installDir).Length != 0 ||
                    !seenPaths.Add(Path.GetFullPath(target.Path)))
                {
                    continue;
                }
                builder.AppendLine(FormatVideoGameTargetLine(new VideoGameTarget
                {
                    Enabled = target.Enabled,
                    Launcher = target.Launcher || IsKnownGameLauncherPath(target.Path),
                    Name = target.Name,
                    Path = Path.GetFullPath(target.Path)
                }));
            }

            string directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }
            File.WriteAllText(path, builder.ToString(), new UTF8Encoding(false));
        }

        public static int CountVideoGameTargets(out int enabledCount)
        {
            List<VideoGameTarget> targets = ReadVideoGameTargets();
            enabledCount = 0;
            foreach (VideoGameTarget target in targets)
            {
                if (target.Enabled)
                {
                    enabledCount++;
                }
            }
            return targets.Count;
        }

        // ---- "Kein Spiel"-Ausnahmen (Heuristik-Schicht) ----------------------------

        public const int VideoGameExemptionDelayMinutes = 15;

        public static string VideoGameExemptionsPath()
        {
            return Path.Combine(InstallDir, "rules", "video-game-exemptions.txt");
        }

        // Returns an empty string when the path may be exempted, otherwise a
        // user-readable German refusal reason. Deliberately more permissive
        // than the target validation: exempting a path only ever REDUCES what
        // the heuristic may touch, so rooted + .exe is enough.
        public static string ValidateVideoGameExemptionPath(string path)
        {
            string trimmed = (path ?? string.Empty).Trim();
            if (trimmed.Length == 0)
            {
                return "Es wurde keine Programmdatei angegeben.";
            }

            string fullPath;
            try
            {
                if (!Path.IsPathRooted(trimmed))
                {
                    return "Bitte einen vollstaendigen Pfad zur Programmdatei angeben.";
                }
                fullPath = Path.GetFullPath(trimmed);
            }
            catch (Exception)
            {
                return "Der Pfad ist keine gueltige Programmdatei.";
            }

            if (!string.Equals(Path.GetExtension(fullPath), ".exe", StringComparison.OrdinalIgnoreCase))
            {
                return "Nur ausfuehrbare .exe-Dateien koennen ausgenommen werden.";
            }

            return string.Empty;
        }

        // One exemption per line: "<ISO-8601-UTC>|<full path>". The guard has
        // its own defensive reader (ParseActiveExemptions in
        // src\PurestateGuardVideoGameDetection.cs); both sides drop malformed
        // lines.
        public static string FormatVideoGameExemptionLine(VideoGameExemption exemption)
        {
            if (exemption == null)
            {
                throw new ArgumentNullException("exemption");
            }

            return exemption.ActivatesAtUtc.ToUniversalTime().ToString("o") + "|" + exemption.Path;
        }

        public static VideoGameExemption ParseVideoGameExemptionLine(string line)
        {
            string trimmed = (line ?? string.Empty).Trim();
            if (trimmed.Length == 0 || trimmed.StartsWith("#"))
            {
                return null;
            }

            string[] parts = trimmed.Split(new[] { '|' }, 2);
            if (parts.Length != 2)
            {
                return null;
            }

            DateTime activatesAt;
            if (!DateTime.TryParse(parts[0].Trim(), null,
                System.Globalization.DateTimeStyles.RoundtripKind, out activatesAt))
            {
                return null;
            }

            string path = parts[1].Trim();
            if (ValidateVideoGameExemptionPath(path).Length != 0)
            {
                return null;
            }

            return new VideoGameExemption
            {
                ActivatesAtUtc = activatesAt.ToUniversalTime(),
                Path = Path.GetFullPath(path)
            };
        }

        public static List<VideoGameExemption> ReadVideoGameExemptions()
        {
            return ReadVideoGameExemptions(VideoGameExemptionsPath());
        }

        internal static List<VideoGameExemption> ReadVideoGameExemptions(string path)
        {
            List<VideoGameExemption> exemptions = new List<VideoGameExemption>();
            if (!File.Exists(path))
            {
                return exemptions;
            }

            HashSet<string> seenPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string raw in File.ReadAllLines(path))
            {
                VideoGameExemption exemption = ParseVideoGameExemptionLine(raw);
                if (exemption == null || !seenPaths.Add(exemption.Path))
                {
                    continue;
                }
                exemptions.Add(exemption);
            }
            return exemptions;
        }

        public static void WriteVideoGameExemptions(IEnumerable<VideoGameExemption> exemptions)
        {
            WriteVideoGameExemptions(exemptions, VideoGameExemptionsPath());
        }

        internal static void WriteVideoGameExemptions(IEnumerable<VideoGameExemption> exemptions, string path)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("# Purestate Videospiel-Ausnahmen (kein Spiel)");
            builder.AppendLine("# Format: aktivAbUtc|vollstaendiger Pfad");
            HashSet<string> seenPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (VideoGameExemption exemption in exemptions ?? new VideoGameExemption[0])
            {
                if (exemption == null ||
                    ValidateVideoGameExemptionPath(exemption.Path).Length != 0 ||
                    !seenPaths.Add(Path.GetFullPath(exemption.Path)))
                {
                    continue;
                }
                builder.AppendLine(FormatVideoGameExemptionLine(new VideoGameExemption
                {
                    ActivatesAtUtc = exemption.ActivatesAtUtc,
                    Path = Path.GetFullPath(exemption.Path)
                }));
            }

            string directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }
            File.WriteAllText(path, builder.ToString(), new UTF8Encoding(false));
        }

        // Adds an exemption that becomes effective in 15 minutes. Returns an
        // empty string on success, otherwise the German refusal reason. The
        // password gate lives in the UI caller - this method only handles the
        // delayed-activation rule.
        // TGT-003: Die Sicherung enthaelt den Aktivierungszeitpunkt. Eine
        // Sicherung, die aelter als die Frist ist, brachte damit sofort scharfe
        // Ausnahmen mit - die 15 Minuten wurden nicht umgangen, sie wurden
        // mitgesichert. Nach einer Wiederherstellung laeuft die Frist deshalb
        // neu, genau wie beim Eintragen von Hand.
        internal static List<VideoGameExemption> StampImportedVideoGameExemptions(
            IEnumerable<VideoGameExemption> exemptions, DateTime nowUtc)
        {
            List<VideoGameExemption> stamped = new List<VideoGameExemption>();
            foreach (VideoGameExemption exemption in exemptions ?? new List<VideoGameExemption>())
            {
                if (exemption == null)
                {
                    continue;
                }
                stamped.Add(new VideoGameExemption
                {
                    Path = exemption.Path,
                    ActivatesAtUtc = nowUtc.ToUniversalTime().AddMinutes(VideoGameExemptionDelayMinutes)
                });
            }
            return stamped;
        }

        public static string AddVideoGameExemption(string path)
        {
            string validationError = ValidateVideoGameExemptionPath(path);
            if (validationError.Length != 0)
            {
                return validationError;
            }

            string fullPath = Path.GetFullPath(path.Trim());
            List<VideoGameExemption> exemptions = ReadVideoGameExemptions();
            foreach (VideoGameExemption existing in exemptions)
            {
                if (string.Equals(existing.Path, fullPath, StringComparison.OrdinalIgnoreCase))
                {
                    return "Diese Programmdatei ist bereits als Ausnahme eingetragen.";
                }
            }

            exemptions.Add(new VideoGameExemption
            {
                ActivatesAtUtc = Support.TrustedUtcNow().AddMinutes(VideoGameExemptionDelayMinutes),
                Path = fullPath
            });
            WriteVideoGameExemptions(exemptions);
            WriteActivityLog("Video game exemption added (effective in " + VideoGameExemptionDelayMinutes + " minutes).");
            return string.Empty;
        }

        public static void RemoveVideoGameExemption(string path)
        {
            string fullPath;
            try
            {
                fullPath = Path.GetFullPath((path ?? string.Empty).Trim());
            }
            catch (Exception)
            {
                return;
            }

            List<VideoGameExemption> exemptions = ReadVideoGameExemptions();
            List<VideoGameExemption> kept = new List<VideoGameExemption>();
            foreach (VideoGameExemption exemption in exemptions)
            {
                if (!string.Equals(exemption.Path, fullPath, StringComparison.OrdinalIgnoreCase))
                {
                    kept.Add(exemption);
                }
            }

            if (kept.Count != exemptions.Count)
            {
                WriteVideoGameExemptions(kept);
                WriteActivityLog("Video game exemption removed.");
            }
        }

        // ---- Status / diagnostics --------------------------------------------------

        // Neutral technical status label for reports. Deliberately contains
        // only the mode and counts - never game names, paths, or usage values.
        public static string VideoGamesStatusLabel(AppConfig config)
        {
            if (config == null || !config.VideoGamesProtectionEnabled)
            {
                return string.Equals((config == null ? "planned" : config.VideoGamesProtectionMode), "planned", StringComparison.OrdinalIgnoreCase)
                    ? "aus (noch nicht konfiguriert)"
                    : "aus";
            }

            return string.Equals(config.VideoGamesProtectionMode, "strict", StringComparison.OrdinalIgnoreCase)
                ? "streng (Vollsperre)"
                : "sanft (Budget/Sperrzeit)";
        }

        public static void AppendVideoGamesDiagnostics(StringBuilder report, AppConfig config)
        {
            int enabledCount;
            int totalCount;
            bool targetsReadable = true;
            try
            {
                totalCount = CountVideoGameTargets(out enabledCount);
            }
            catch (Exception)
            {
                totalCount = 0;
                enabledCount = 0;
                targetsReadable = false;
            }

            report.AppendLine("Videospiel-Schutz: " + VideoGamesStatusLabel(config));
            report.AppendLine("Videospiel-Ziele konfiguriert: " + totalCount + " (aktiv: " + enabledCount + ")");
            report.AppendLine("Videospiel-Zielliste lesbar: " + YesNo(targetsReadable));
            report.AppendLine("Videospiel-Tagesbudget: " + (config != null && config.VideoGamesDailyLimitEnabled ? "aktiv" : "aus"));
            report.AppendLine("Videospiel-Sperrzeit: " + (config != null && config.VideoGamesCurfewEnabled ? "aktiv" : "aus"));
            report.AppendLine("Videospiel-Laufzeitstatus vorhanden: " + YesNo(File.Exists(VideoGamesUsagePath)));
        }

        // ---- Detected games (read-only view for the UI) ----------------------------

        // The guard owns %ProgramData%\Purestate\video-games-detected.json
        // (see src\PurestateGuardVideoGameDetection.cs); the app only displays
        // it. Key = source label (steam/epic/.../Heuristik), value = path.
        public static string VideoGamesDetectedPath
        {
            get { return Path.Combine(DataDir, "video-games-detected.json"); }
        }

        private const int VideoGamesDetectedDisplayMaxChars = 65536;

        public static List<KeyValuePair<string, string>> ReadVideoGameDetectedForDisplay()
        {
            return ReadVideoGameDetectedForDisplay(VideoGamesDetectedPath);
        }

        // TGT-006: Ueber dem Deckel gab es frueher GAR KEINE Anzeige. Diese
        // Liste ist der einzige Weg, den Pfad eines falsch eingestuften
        // Programms zu erfahren, und der Pfad ist die Voraussetzung fuer die
        // Ausnahme - der Ausfall traf also genau den Fall, in dem der Ausweg
        // gebraucht wird. Jetzt wird der Anfang der Datei gelesen und die
        // Kuerzung als eigener Eintrag benannt.
        internal static List<KeyValuePair<string, string>> ReadVideoGameDetectedForDisplay(string path)
        {
            try
            {
                if (!File.Exists(path))
                {
                    return new List<KeyValuePair<string, string>>();
                }

                FileInfo info = new FileInfo(path);
                if (info.Length > VideoGamesDetectedDisplayMaxChars)
                {
                    char[] buffer = new char[VideoGamesDetectedDisplayMaxChars];
                    int read;
                    using (StreamReader reader = new StreamReader(path, Encoding.UTF8))
                    {
                        read = reader.ReadBlock(buffer, 0, buffer.Length);
                    }

                    List<KeyValuePair<string, string>> shortened =
                        ParseVideoGameDetectedForDisplay(new string(buffer, 0, read));
                    shortened.Add(new KeyValuePair<string, string>(
                        "Hinweis",
                        "Nicht alle erkannten Programme passen in diese Anzeige. Die vollstaendige Liste steht in video-games-detected.json."));
                    return shortened;
                }

                return ParseVideoGameDetectedForDisplay(File.ReadAllText(path, Encoding.UTF8));
            }
            catch (Exception)
            {
                return new List<KeyValuePair<string, string>>();
            }
        }

        internal static List<KeyValuePair<string, string>> ParseVideoGameDetectedForDisplay(string json)
        {
            List<KeyValuePair<string, string>> entries = new List<KeyValuePair<string, string>>();
            try
            {
                foreach (Match entry in Regex.Matches(json ?? string.Empty,
                    "\\{\\s*\"Path\"\\s*:\\s*\"(?<path>(?:[^\"\\\\]|\\\\.)*)\"\\s*,\\s*\"Source\"\\s*:\\s*\"(?<source>(?:[^\"\\\\]|\\\\.)*)\"\\s*\\}"))
                {
                    string path = UnescapeDetectedJsonValue(entry.Groups["path"].Value);
                    string source = UnescapeDetectedJsonValue(entry.Groups["source"].Value);
                    if (path.Length != 0 && source.Length != 0)
                    {
                        entries.Add(new KeyValuePair<string, string>(source, path));
                    }
                }

                // TGT-006: "[^\]]*" endete an der ERSTEN eckigen Klammer -
                // und die ist in Windows-Pfaden erlaubt. Ein einziger Pfad mit
                // "]" schnitt den Rest der Heuristikliste ab. Das Ende des
                // Arrays wird deshalb an den Zeichenketten entlang gesucht.
                string heuristicBody = ReadJsonArrayBody(json ?? string.Empty, "HeuristicPaths");
                if (heuristicBody.Length != 0)
                {
                    foreach (Match entry in Regex.Matches(heuristicBody,
                        "\"(?<value>(?:[^\"\\\\]|\\\\.)*)\""))
                    {
                        string path = UnescapeDetectedJsonValue(entry.Groups["value"].Value);
                        if (path.Length != 0)
                        {
                            entries.Add(new KeyValuePair<string, string>("Heuristik", path));
                        }
                    }
                }
            }
            catch (Exception)
            {
                return new List<KeyValuePair<string, string>>();
            }
            return entries;
        }

        // Liefert den Rumpf des benannten Arrays. Die schliessende Klammer
        // zaehlt nur ausserhalb einer Zeichenkette; sonst beendet ein Pfad wie
        // "C:\Spiele\Klammer]Ordner\spiel.exe" das Array vorzeitig.
        internal static string ReadJsonArrayBody(string json, string name)
        {
            string text = json ?? string.Empty;
            int key = text.IndexOf("\"" + name + "\"", StringComparison.Ordinal);
            if (key < 0)
            {
                return string.Empty;
            }
            int open = text.IndexOf('[', key);
            if (open < 0)
            {
                return string.Empty;
            }

            bool inString = false;
            for (int index = open + 1; index < text.Length; index++)
            {
                char current = text[index];
                if (inString)
                {
                    if (current == '\\')
                    {
                        index++;
                    }
                    else if (current == '"')
                    {
                        inString = false;
                    }
                    continue;
                }
                if (current == '"')
                {
                    inString = true;
                }
                else if (current == ']')
                {
                    return text.Substring(open + 1, index - open - 1);
                }
            }

            // Abgeschnittene Datei: alles ab der Klammer ist das Beste, was da ist.
            return text.Substring(open + 1);
        }

        private static string UnescapeDetectedJsonValue(string value)
        {
            return (value ?? string.Empty).Replace("\\\"", "\"").Replace("\\\\", "\\").Trim();
        }

        // ---- Usage counter (read-only view for the UI) ----------------------------

        // Parses the guard's usage file. Returns 0 when the file is missing,
        // damaged, or refers to another local day - never throws. The value is
        // measured PROCESS RUNTIME of configured targets, not foreground play
        // time; every UI surface must label it accordingly.
        public static int ReadVideoGamesUsedMinutesToday()
        {
            return ReadVideoGamesUsedMinutesToday(
                VideoGamesUsagePath,
                Support.TrustedLocalNow().ToString("yyyy-MM-dd"),
                TryLoadIntegrityKey());
        }

        internal static int ReadVideoGamesUsedMinutesToday(string path, string localDay)
        {
            return ReadVideoGamesUsedMinutesToday(path, localDay, null);
        }

        // USG-001: Spiegelt PurestateGuardVideoGames.SplitUsageIntegrity /
        // ComputeUsageIntegrity. Der Waechter kompiliert eigenstaendig, deshalb
        // steht dieselbe Rechnung hier ein zweites Mal; ein Test haelt beide
        // Seiten aneinander.
        private static bool UsageIntegrityMatches(string json, byte[] key)
        {
            const string marker = ",\"Integrity\":\"";
            int index = (json ?? string.Empty).IndexOf(marker, StringComparison.Ordinal);
            if (index < 0)
            {
                return false;
            }

            int start = index + marker.Length;
            int end = json.IndexOf('"', start);
            if (end < 0)
            {
                return false;
            }

            string stored = json.Substring(start, end - start);
            string body = json.Substring(0, index) + "}";
            using (System.Security.Cryptography.HMACSHA256 hmac =
                new System.Security.Cryptography.HMACSHA256(key))
            {
                string expected = Convert.ToBase64String(
                    hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(body)));
                return string.Equals(stored, expected, StringComparison.Ordinal);
            }
        }

        // USG-001: Gibt -1 zurueck, wenn die Datei da ist, aber keine gueltige
        // Signatur traegt. Der Waechter behandelt denselben Fall als
        // aufgebrauchtes Budget; ohne dieses Signal wuerde die Oberflaeche
        // "noch 5 Minuten" anzeigen, waehrend Spiele beendet werden.
        internal static int ReadVideoGamesUsedMinutesToday(string path, string localDay, byte[] integrityKey)
        {
            try
            {
                if (!File.Exists(path))
                {
                    return 0;
                }

                FileInfo info = new FileInfo(path);
                if (info.Length > 4096)
                {
                    return 0;
                }

                string json = File.ReadAllText(path);
                Match dayMatch = Regex.Match(json, "\"Day\"\\s*:\\s*\"(?<value>[0-9-]{10})\"");
                Match usedMatch = Regex.Match(json, "\"UsedSeconds\"\\s*:\\s*(?<value>\\d{1,9})");
                if (!dayMatch.Success || !usedMatch.Success ||
                    !string.Equals(dayMatch.Groups["value"].Value, localDay, StringComparison.Ordinal))
                {
                    return 0;
                }

                int usedSeconds;
                if (!int.TryParse(usedMatch.Groups["value"].Value, out usedSeconds) || usedSeconds < 0)
                {
                    return 0;
                }

                if (integrityKey != null && !UsageIntegrityMatches(json, integrityKey))
                {
                    return -1;
                }

                return usedSeconds / 60;
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
}
