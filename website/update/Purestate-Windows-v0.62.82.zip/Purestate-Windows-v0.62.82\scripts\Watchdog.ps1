param(
    [switch]$SelfTest
)

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\Common.ps1"

if ($SelfTest) {
    if (-not (Test-Path -LiteralPath "$PSScriptRoot\Common.ps1")) {
        throw "Common.ps1 missing."
    }

    if (-not (Get-Command Protect-InstallFolderAcl -ErrorAction SilentlyContinue) -or
        -not (Get-Command Ensure-NativeMessagingHostRegistration -ErrorAction SilentlyContinue) -or
        -not (Get-Command Ensure-ManagedCompanionPolicy -ErrorAction SilentlyContinue) -or
        -not (Get-Command Ensure-WatchdogTask -ErrorAction SilentlyContinue) -or
        -not (Get-Command Ensure-AppRegistration -ErrorAction SilentlyContinue) -or
        -not (Get-Command Get-NormalizedPurestatePath -ErrorAction SilentlyContinue) -or
        -not (Get-Command Sync-BrowserCompanionPolicies -ErrorAction SilentlyContinue) -or
        -not (Get-Command Update-BrowserCompanionState -ErrorAction SilentlyContinue) -or
        -not (Get-Command Test-PurestateExtensionForBrowser -ErrorAction SilentlyContinue)) {
        throw "Self-protection functions are missing."
    }

    if ([string]::IsNullOrWhiteSpace($script:StartupTaskName)) {
        throw "Startup task contract is missing."
    }

    "Self-test OK."
    exit 0
}

try {
    # Waehrend einer Installation nicht dazwischenfunken. Der Watchdog wuerde
    # sonst mitten im Datei-Kopieren Get-Config aufrufen und eine bereits
    # migrierte Konfiguration mit noch alten Skripten lesen - das meldet
    # korrekt einen Integritaetsfehler, ist aber ein Fehlalarm und macht die
    # Meldung als Diagnosesignal wertlos. Der Marker laeuft nach 15 Minuten
    # ab, ein abgebrochener Installer legt den Watchdog also nicht lahm.
    if (Test-PurestateInstallInProgress) {
        Add-AppLog "Watchdog skipped because an install or update is in progress."
        exit 0
    }

    Protect-InstallFolderAcl
    Ensure-NativeMessagingHostRegistration
    Ensure-ManagedCompanionPolicy
    Ensure-WatchdogTask
    Ensure-AppRegistration
    # B-3: Ein bereits laufender Watchdog kann vor dem Installer-Marker
    # gestartet sein. Nach der Registrierung deshalb erneut pruefen.
    # Das verkleinert das Rennfenster, ersetzt aber keine gemeinsame Sperre.
    if (Test-PurestateInstallInProgress) {
        Add-AppLog "Watchdog skipped because an install or update is in progress."
        exit 0
    }

    $config = Get-Config
    if (-not $config.ProtectionEnabled) {
        if (Test-ScheduledProtectionActive -Config $config) {
            Add-AppLog "Scheduled protection window is active. Protection will be enforced."
            Enable-Protection
        } else {
            $pauseUntil = Get-PauseUntilUtc -Config $config
            # Nicht gegen die rohe Systemuhr: eine zurueckgestellte Uhr wuerde
            # das Pausenende sonst nie erreichen (Befund PS-001).
            if ($null -ne $pauseUntil -and $pauseUntil -le (Get-PauseExpiryNowUtc -Config $config)) {
                Invoke-WithConfigLock {
                    $lockedConfig = Get-Config
                    $lockedPauseUntil = Get-PauseUntilUtc -Config $lockedConfig
                    if ($null -ne $lockedPauseUntil -and $lockedPauseUntil -le (Get-PauseExpiryNowUtc -Config $lockedConfig)) {
                        $lockedConfig.ProtectionEnabled = $true
                        $lockedConfig.PauseUntilUtc = ""
                        Save-Config -Config $lockedConfig
                    }
                }
                Add-AppLog "Timed pause expired. Protection will be re-enabled."
                Enable-Protection
            } else {
                if ($null -ne $pauseUntil) {
                    Add-AppLog "Watchdog skipped because protection is paused until $($pauseUntil.ToString('s'))Z."
                } else {
                    Add-AppLog "Watchdog skipped because protection is paused."
                }

                exit 0
            }
        }
    }

    $service = Get-Service -Name $script:ServiceName -ErrorAction SilentlyContinue
    if ($null -eq $service) {
        Add-AppLog "Watchdog found no installed service."
        exit 0
    }

    if ($service.Status -ne "Running") {
        if (Test-PurestateInstallInProgress) {
            Add-AppLog "Watchdog skipped because an install or update is in progress."
            exit 0
        }

        Start-Service -Name $script:ServiceName
        Add-AppLog "Watchdog started service."
    }
} catch {
    Add-AppLog "Watchdog failed: $($_.Exception.Message)"
    exit 1
}
