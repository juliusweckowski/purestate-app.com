"use strict";

const BLUESKY_POSTS_CHECK = "purestate.checkBlueskyPosts";
const BROWSER_RULES_GET = "purestate.getBrowserRules";
const BLUESKY_SCAN_DELAY_MS = 120;
const BLUESKY_STYLE_ID = "purestate-bsky-shield-style";
const BLUESKY_ADULT_SEARCH_TERMS = [
  "adult",
  "anal",
  "bbw",
  "bdsm",
  "bigboob",
  "bigboobs",
  "bigtit",
  "bigtits",
  "blowjob",
  "boob",
  "boobies",
  "boobs",
  "breast",
  "breasts",
  "busty",
  "camgirl",
  "camgirls",
  "cock",
  "cocks",
  "cocktribute",
  "cum",
  "cumshot",
  "cumtribute",
  "dick",
  "dicks",
  "edging",
  "fetish",
  "femdom",
  "findom",
  "gonewild",
  "goon",
  "gooner",
  "goonsky",
  "hardcore",
  "hentai",
  "horny",
  "lewd",
  "masturbation",
  "milf",
  "naked",
  "nipples",
  "nsfw",
  "nsfwbsky",
  "nsfwcommunity",
  "nsfwsky",
  "nude",
  "nudes",
  "onlyfans",
  "penis",
  "penises",
  "porn",
  "porno",
  "pornography",
  "pussy",
  "realnsfw",
  "redgifs",
  "rule34",
  "sex",
  "sexy",
  "skyhub",
  "slut",
  "slutty",
  "softcore",
  "spicysky",
  "tits",
  "titties",
  "titty",
  "thirsttrap",
  "topless",
  "xxx"
];
const BLUESKY_WARNING_TERMS = [
  "adult content",
  "explicit sexual content",
  "nicht jugendfreie inhalte",
  "nudity",
  "nacktheit",
  "porn",
  "sexual content"
];
const BLUESKY_ADULT_HASHTAG_PATTERN = /(?:^|\s)#(?:adult|anal|bbw|bdsm|bigboobs?|bigtits?|blowjob|boob(?:ies|s)?|breasts?|busty|camgirls?|cocks?|cocktribute|cum(?:shot|tribute)?|dicks?|edging|femdom|fetish|findom|gonewild|goon(?:er|sky)?|hardcore|hentai|horny|lewd|masturbation|milf|naked|nipples?|nsfw(?:bsky|community|sky)?|nudes?|onlyfans|penis(?:es)?|porn(?:ography)?|pussy|r34|realnsfw|redgifs|rule34|sex(?:y)?|skyhub|slut(?:ty)?|softcore|spicysky|thirsttrap|tits|titties|topless|xxx)\b/i;
const BLUESKY_ADULT_TEXT_PATTERN = /\b(?:anal|bbw|bdsm|big\s*boobs?|big\s*tits?|blow\s*job|boob(?:ies|s)?|breasts?|busty|cock\s*(?:and\s*ball|tribute)|cum\s*(?:shot|tribute)|dick\s*pic|edging|explicit sexual content|full nudes?|hardcore|hentai|horny|huge cock|masturbation|milf|nipples?|onlyfans|porn(?:ography)?|pussy|r34|redgifs|rule\s*34|sexually explicit|slutty?|softcore|thirst\s*trap|titties|xxx)\b/i;
const BLUESKY_SAFE_CONTEXT_PATTERN = /\b(?:anti[- ]?porn|against porn|no[- ]?fap|porn addiction|porn recovery|pornfree|quit(?:ting)? porn)\b/i;
const BLUESKY_ADULT_LINK_PATTERN = /(?:2cams\.org|justfor\.fans|justforfans\.com|loyalfans\.com|manyvids\.com|onlyfans\.com|fansly\.com|redgifs\.com|pornhub\.com|xvideos\.com|xnxx\.com|rule34\.(?:xxx|paheal\.net)|chaturbate\.com|stripchat\.com)/i;

let blueskyScanTimer = 0;
let lastBlueskyLocation = "";
let blueskyRulePack = {
  bluesky: {
    adultSearchTerms: [],
    adultHashtags: [],
    adultTextTerms: [],
    adultLinkDomains: [],
    safeContextTerms: []
  }
};

function normalizeBlueskySearchText(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function normalizeBlueskyRuleTerms(values) {
  const result = [];
  for (const value of Array.isArray(values) ? values : []) {
    const term = normalizeBlueskySearchText(String(value || "").replace(/^#/, ""));
    if (term && term.length <= 64 && !result.includes(term)) {
      result.push(term);
    }
    if (result.length >= 250) {
      break;
    }
  }
  return result;
}

function normalizeBlueskyDomainRules(values) {
  const result = [];
  for (const value of Array.isArray(values) ? values : []) {
    const domain = String(value || "").trim().replace(/^https?:\/\//i, "").split(/[/?#]/)[0].toLowerCase();
    if (/^[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?$/.test(domain) && !result.includes(domain)) {
      result.push(domain);
    }
    if (result.length >= 250) {
      break;
    }
  }
  return result;
}

function applyBlueskyRulePack(response) {
  const rules = response && response.rules && response.rules.bluesky ? response.rules.bluesky : {};
  blueskyRulePack = {
    bluesky: {
      adultSearchTerms: normalizeBlueskyRuleTerms(rules.adultSearchTerms),
      adultHashtags: normalizeBlueskyRuleTerms(rules.adultHashtags),
      adultTextTerms: normalizeBlueskyRuleTerms(rules.adultTextTerms),
      adultLinkDomains: normalizeBlueskyDomainRules(rules.adultLinkDomains),
      safeContextTerms: normalizeBlueskyRuleTerms(rules.safeContextTerms)
    }
  };
}

function requestBlueskyRulePack() {
  try {
    const maybePromise = chrome.runtime.sendMessage({ type: BROWSER_RULES_GET, site: "bluesky" }, (response) => {
      applyBlueskyRulePack(response);
      scheduleBlueskyScan();
    });
    if (maybePromise && typeof maybePromise.then === "function") {
      maybePromise
        .then((response) => {
          applyBlueskyRulePack(response);
          scheduleBlueskyScan();
        })
        .catch(() => {});
    }
  } catch {
  }
}

function blueskyLocalTerms(key) {
  return blueskyRulePack && blueskyRulePack.bluesky && Array.isArray(blueskyRulePack.bluesky[key])
    ? blueskyRulePack.bluesky[key]
    : [];
}

function blueskySearchMatchesTerm(normalized, compact, term) {
  const normalizedTerm = normalizeBlueskySearchText(term);
  if (!normalizedTerm) {
    return false;
  }
  const compactTerm = normalizedTerm.replace(/\s+/g, "");
  return normalized.split(/\s+/).includes(normalizedTerm) ||
    (normalizedTerm.includes(" ") && normalized.includes(normalizedTerm)) ||
    compact === compactTerm ||
    (compactTerm.length >= 5 && compact.includes(compactTerm));
}

function blueskyTextHasLocalAdultHashtag(text) {
  const terms = blueskyLocalTerms("adultHashtags").map((term) => term.replace(/\s+/g, ""));
  if (!terms.length) {
    return false;
  }
  const matches = String(text || "").matchAll(/#([a-z0-9_+-]+)/ig);
  for (const match of matches) {
    const tag = normalizeBlueskySearchText(match[1]).replace(/\s+/g, "");
    if (terms.includes(tag)) {
      return true;
    }
  }
  return false;
}

function blueskyTextHasLocalTerm(text, key) {
  const normalized = normalizeBlueskySearchText(text);
  if (!normalized) {
    return false;
  }
  const tokens = new Set(normalized.split(/\s+/));
  for (const term of blueskyLocalTerms(key)) {
    if (term.includes(" ")) {
      if (normalized.includes(term)) {
        return true;
      }
    } else if (tokens.has(term)) {
      return true;
    }
  }
  return false;
}

function blueskyHasSafeContext(text) {
  return BLUESKY_SAFE_CONTEXT_PATTERN.test(text) || blueskyTextHasLocalTerm(text, "safeContextTerms");
}

function blueskyLinkMatchesLocalAdultDomain(href) {
  let hostname = "";
  try {
    hostname = new URL(String(href || ""), window.location.href).hostname.toLowerCase();
  } catch {
    return false;
  }
  if (!hostname) {
    return false;
  }
  return blueskyLocalTerms("adultLinkDomains").some((domain) => {
    const normalizedDomain = domain.replace(/\s+/g, "").toLowerCase();
    return hostname === normalizedDomain || hostname.endsWith("." + normalizedDomain);
  });
}

function blueskyAdultSearchFromLocation(href) {
  try {
    const url = new URL(String(href || ""), "https://bsky.app/");
    if (!/(^|\.)bsky\.app$/i.test(url.hostname)) {
      return false;
    }

    const values = [];
    if (/^\/search(?:\/|$)/i.test(url.pathname)) {
      values.push(url.searchParams.get("q") || "");
    }
    const hashtag = url.pathname.match(/^\/hashtag\/([^/?#]+)/i);
    if (hashtag) {
      values.push(decodeURIComponent(hashtag[1]));
    }

    return values.some((value) => {
      if (purestateIsAdultSearchText(value)) {
        return true;
      }
      const normalized = normalizeBlueskySearchText(value);
      const compact = normalized.replace(/\s+/g, "");
      return BLUESKY_ADULT_SEARCH_TERMS.concat(blueskyLocalTerms("adultSearchTerms")).some((term) =>
        blueskySearchMatchesTerm(normalized, compact, term)
      );
    });
  } catch {
    return false;
  }
}

function blueskyAdultSearchFromVisibleControls(root) {
  const scope = root && typeof root.querySelectorAll === "function" ? root : document;
  const controls = scope.querySelectorAll("input, textarea, [role='searchbox']");
  for (const control of controls) {
    const label = normalizeBlueskySearchText(
      String(control.getAttribute && control.getAttribute("aria-label") || "") + " " +
      String(control.getAttribute && control.getAttribute("placeholder") || "")
    );
    if (label && !/\b(search|suche|suchen)\b/.test(label)) {
      continue;
    }
    const value = normalizeBlueskySearchText(
      purestateSettledSearchText(control, String(control.value || "")) + " " +
      purestateSettledSearchText(control, String(control.textContent || ""))
    );
    if (purestateIsAdultSearchText(value)) {
      return true;
    }
    const compact = value.replace(/\s+/g, "");
    if (BLUESKY_ADULT_SEARCH_TERMS.concat(blueskyLocalTerms("adultSearchTerms")).some((term) =>
      blueskySearchMatchesTerm(value, compact, term)
    )) {
      return true;
    }
  }
  return false;
}

function blueskyPostIdentityFromHref(href) {
  try {
    const url = new URL(String(href || ""), "https://bsky.app/");
    if (!/(^|\.)bsky\.app$/i.test(url.hostname)) {
      return null;
    }
    const match = url.pathname.match(/^\/profile\/([^/]+)\/post\/([^/?#]+)/i);
    if (!match) {
      return null;
    }
    const profile = decodeURIComponent(match[1]).trim().toLowerCase();
    const rkey = decodeURIComponent(match[2]).trim();
    if (!profile || !rkey) {
      return null;
    }
    return { profile, rkey, key: profile + "/" + rkey };
  } catch {
    return null;
  }
}

function blueskyPostCardForLink(link) {
  if (!link || typeof link.closest !== "function") {
    return null;
  }
  const semantic = link.closest("[data-testid*='feedItem'], article, [role='article']");
  if (semantic) {
    return semantic;
  }

  // Bluesky currently renders a complete feed item as a non-anchor element
  // with role=link. The timestamp inside it is a separate anchor, so matching
  // every role=link would incorrectly select only the small header row.
  const interactiveCard = link.closest("[role='link']:not(a)");
  if (interactiveCard) {
    return interactiveCard;
  }

  let node = link.parentElement;
  let candidate = null;
  for (let depth = 0; node && depth < 7; depth++, node = node.parentElement) {
    const links = typeof node.querySelectorAll === "function"
      ? node.querySelectorAll("a[href*='/profile/'][href*='/post/']")
      : [];
    if (links.length > 1 && candidate) {
      break;
    }
    if (links.length === 1 && node.getBoundingClientRect && node.getBoundingClientRect().width > 200) {
      candidate = node;
    }
  }
  return candidate || link.parentElement;
}

// BSK-002: Diese Suche geht je Medium bis zu neun Vorfahren hoch und ruft je
// Ebene blueskyMediaElements (ein querySelectorAll) UND blueskyVisibleAdultText
// (das vollstaendige textContent des Vorfahren durch drei regulaere Ausdruecke
// plus alle Links) - quadratisch, wie RDT-003 und XCO-004. Bei drei Ausloesern,
// die alle das ganze Dokument pruefen, lief das dauernd neu.
//
// Das Ergebnis je Medium wird deshalb gemerkt. Ein WeakMap haelt den Knoten
// nicht am Leben: verschwindet das Medium aus dem Dokument, faellt der Eintrag
// mit ihm weg.
//
// NUR das positive Ergebnis wird gemerkt, und das ist Absicht - obwohl gerade
// die erfolglose Suche die teure ist. Bluesky rendert nach: ein Medium kann da
// sein, bevor die Erwachsenenwarnung seiner Karte im DOM steht. Wuerde das
// "keine Karte gefunden" gemerkt, fragte der Begleiter nie wieder nach, und
// aus einer Zwischenmessung waere ein dauerhaftes Urteil geworden. Eine
// Ersparnis, die eine Erkennungsluecke kostet, ist keine.
const blueskyCardCache = new WeakMap();

function blueskyPostCardForMedia(media) {
  if (!media || !media.parentElement) {
    return null;
  }

  const gemerkt = blueskyCardCache.get(media);
  // Nur benutzen, solange die gemerkte Karte noch im Dokument haengt und das
  // Medium wirklich enthaelt - eine neu gerenderte Zeitleiste tauscht die
  // Vorfahren aus.
  if (gemerkt && gemerkt.isConnected !== false && gemerkt.contains && gemerkt.contains(media)) {
    return gemerkt;
  }

  let node = media.parentElement;
  for (let depth = 0; node && depth < 9; depth++, node = node.parentElement) {
    const tagName = String(node.tagName || "").toLowerCase();
    if (tagName === "body" || tagName === "html") {
      break;
    }
    if (blueskyMediaElements(node).includes(media) &&
        (blueskyVisibleAdultWarning(node) || blueskyVisibleAdultText(node))) {
      blueskyCardCache.set(media, node);
      return node;
    }
  }
  // Bewusst NICHTS merken: siehe oben.
  return null;
}

function blueskyPostIdentitiesInCard(card) {
  if (!card || typeof card.querySelectorAll !== "function") {
    return [];
  }
  const identities = [];
  for (const link of card.querySelectorAll("a[href*='/profile/'][href*='/post/']")) {
    const identity = blueskyPostIdentityFromHref(link.getAttribute("href"));
    if (identity && !identities.some((item) => item.key === identity.key)) {
      identities.push(identity);
    }
  }
  return identities;
}

function blueskyVisibleCardKey(card) {
  const text = normalizeBlueskySearchText(card && card.textContent || "").slice(0, 180);
  return "__visible:" + text + "|media:" + blueskyMediaElements(card).length;
}

function blueskyMediaElements(card) {
  if (!card || typeof card.querySelectorAll !== "function") {
    return [];
  }
  const result = [];
  for (const element of card.querySelectorAll("video, img, [data-testid*='postImage'], [data-testid*='video']")) {
    if (result.includes(element)) {
      continue;
    }
    const tagName = String(element.tagName || "").toLowerCase();
    if (tagName === "img") {
      const label = String(element.getAttribute && element.getAttribute("aria-label") || "").toLowerCase();
      const src = String(element.getAttribute && element.getAttribute("src") || "").toLowerCase();
      const profileLink = element.closest && element.closest("a[href*='/profile/']:not([href*='/post/'])");
      if (profileLink || label.includes("avatar") || label.includes("profile") || src.includes("/avatar/")) {
        continue;
      }
    }
    result.push(element);
  }
  return result;
}

function blueskyVisibleAdultWarning(card) {
  if (!card || typeof card.querySelectorAll !== "function") {
    return false;
  }
  const candidates = card.querySelectorAll(
    "[data-testid*='contentHider'], [data-testid*='contentWarning'], [aria-label*='content warning'], [aria-label*='adult content'], button"
  );
  for (const candidate of candidates) {
    const text = normalizeBlueskySearchText(
      String(candidate.getAttribute && candidate.getAttribute("aria-label") || "") + " " +
      String(candidate.textContent || "")
    );
    if (BLUESKY_WARNING_TERMS.some((term) => text.includes(term))) {
      return true;
    }
  }
  return false;
}

function blueskyVisibleAdultText(card) {
  if (!card || typeof card.querySelectorAll !== "function") {
    return false;
  }
  const text = String(card.textContent || "");
  if (BLUESKY_ADULT_HASHTAG_PATTERN.test(text) || blueskyTextHasLocalAdultHashtag(text)) {
    return true;
  }
  if (!blueskyHasSafeContext(text) && (BLUESKY_ADULT_TEXT_PATTERN.test(text) || blueskyTextHasLocalTerm(text, "adultTextTerms"))) {
    return true;
  }
  for (const link of card.querySelectorAll("a[href]")) {
    const href = String(link.getAttribute && link.getAttribute("href") || "");
    if (BLUESKY_ADULT_LINK_PATTERN.test(href) || blueskyLinkMatchesLocalAdultDomain(href)) {
      return true;
    }
  }
  return false;
}

function installBlueskyShieldStyle() {
  purestateInjectStyle(
    document,
    BLUESKY_STYLE_ID,
    [
      "[data-purestate-bsky-state='blocked'] > :not([data-purestate-bsky-placeholder='true']) {",
      "  display: none !important;",
      "  visibility: hidden !important;",
      "}",
      "[data-purestate-bsky-state='blocked'] [data-purestate-bsky-placeholder='true'] {",
      "  display: flex !important;",
      "  visibility: visible !important;",
      "}",
      "[data-purestate-bsky-state='blocked'] {",
      "  overflow: hidden !important;",
      "}"
    ].join("\n")
  );
}

function ensureBlueskyPlaceholder(card, message) {
  let placeholder = card.querySelector("[data-purestate-bsky-placeholder='true']");
  if (!placeholder) {
    placeholder = purestateCurtainPlaceholder(
      document,
      purestateCurtainTheme(document),
      message,
      "",
      ["min-height:140px", "padding:20px"]
    );
    placeholder.setAttribute("data-purestate-bsky-placeholder", "true");
    card.insertBefore(placeholder, card.firstChild || null);
  }
  // Ein Platzhalter aus einer frueheren Skriptinstanz kennt purestateTitle
  // nicht; dann bleibt sein Text stehen, statt die Sperre abzubrechen.
  if (placeholder.purestateTitle) {
    placeholder.purestateTitle.textContent = message;
  }
  return placeholder;
}

function hideBlueskyCardContent(card, placeholder) {
  if (!card || !placeholder) {
    return;
  }
  for (const child of Array.from(card.children || [])) {
    if (child === placeholder) {
      continue;
    }
    if (!child.hasAttribute("data-purestate-bsky-child-display")) {
      child.setAttribute("data-purestate-bsky-child-display", child.style.display || "");
      child.setAttribute(
        "data-purestate-bsky-child-aria-hidden",
        child.hasAttribute("aria-hidden") ? child.getAttribute("aria-hidden") : "__missing__"
      );
    }
    child.style.setProperty("display", "none", "important");
    child.setAttribute("aria-hidden", "true");
  }
}

function releaseBlueskyCardContent(card) {
  for (const child of card.querySelectorAll("[data-purestate-bsky-child-display]")) {
    const previousDisplay = child.getAttribute("data-purestate-bsky-child-display") || "";
    const previousAriaHidden = child.getAttribute("data-purestate-bsky-child-aria-hidden") || "__missing__";
    child.style.removeProperty("display");
    if (previousDisplay) {
      child.style.setProperty("display", previousDisplay);
    }
    if (previousAriaHidden === "__missing__") {
      child.removeAttribute("aria-hidden");
    } else {
      child.setAttribute("aria-hidden", previousAriaHidden);
    }
    child.removeAttribute("data-purestate-bsky-child-display");
    child.removeAttribute("data-purestate-bsky-child-aria-hidden");
  }
}

function coverBlueskyCardMedia(card, message) {
  const media = blueskyMediaElements(card);
  for (const element of media) {
    if (!element.hasAttribute("data-purestate-bsky-display")) {
      element.setAttribute("data-purestate-bsky-display", element.style.display || "");
    }
    element.style.setProperty("display", "none", "important");
    if (typeof element.pause === "function") {
      try { element.pause(); } catch {}
    }
  }
  if (media.length || blueskyVisibleAdultWarning(card)) {
    ensureBlueskyPlaceholder(card, message);
  }
  return media.length;
}

function releaseBlueskyCardMedia(card) {
  releaseBlueskyCardContent(card);
  for (const element of card.querySelectorAll("[data-purestate-bsky-display]")) {
    const previous = element.getAttribute("data-purestate-bsky-display") || "";
    element.style.removeProperty("display");
    if (previous) {
      element.style.setProperty("display", previous);
    }
    element.removeAttribute("data-purestate-bsky-display");
  }
  const placeholder = card.querySelector("[data-purestate-bsky-placeholder='true']");
  if (placeholder && placeholder.parentNode) {
    placeholder.parentNode.removeChild(placeholder);
  }
  // BSK-004: Die beiden Attribute, die blockBlueskyCard entfernt hat, wieder
  // setzen - aber nur die, die vorher wirklich dastanden. Ein Video, das nie
  // "controls" hatte, bekommt hier keins.
  for (const element of card.querySelectorAll("[data-purestate-bsky-had-autoplay], [data-purestate-bsky-had-controls]")) {
    if (element.getAttribute("data-purestate-bsky-had-autoplay") === "true") {
      element.setAttribute("autoplay", "");
      element.removeAttribute("data-purestate-bsky-had-autoplay");
    }
    if (element.getAttribute("data-purestate-bsky-had-controls") === "true") {
      element.setAttribute("controls", "");
      element.removeAttribute("data-purestate-bsky-had-controls");
    }
  }

  card.removeAttribute("aria-disabled");
  if (card.getAttribute && card.getAttribute("role") === "link" && card.getAttribute("tabindex") === "-1") {
    card.removeAttribute("tabindex");
  }
  card.setAttribute("data-purestate-bsky-state", "safe");
}

function blockBlueskyCard(card, reason) {
  installBlueskyShieldStyle();
  card.setAttribute("data-purestate-bsky-state", "blocked");
  card.setAttribute("aria-disabled", "true");
  if (card.getAttribute && card.getAttribute("role") === "link") {
    card.setAttribute("tabindex", "-1");
  }
  const message = reason || "18+ Beitrag blockiert";
  coverBlueskyCardMedia(card, message);
  const placeholder = ensureBlueskyPlaceholder(card, message);
  hideBlueskyCardContent(card, placeholder);
  for (const element of card.querySelectorAll("video, audio")) {
    try { element.pause(); } catch {}
    // BSK-004: Merken, WAS entfernt wurde. Ohne diese Spur konnte die Freigabe
    // die Attribute nicht zurueckgeben - eine Karte, die erst gesperrt und
    // nach der Antwort des Verteilers als unbedenklich freigegeben wurde,
    // zeigte danach ein Video ohne Bedienelemente. Kein Schutzverlust, aber ein
    // Video, das sich nicht mehr steuern laesst, sieht aus wie ein Fehler des
    // Programms - und ist einer.
    if (element.hasAttribute && element.hasAttribute("autoplay")) {
      element.setAttribute("data-purestate-bsky-had-autoplay", "true");
    }
    if (element.hasAttribute && element.hasAttribute("controls")) {
      element.setAttribute("data-purestate-bsky-had-controls", "true");
    }
    element.removeAttribute("autoplay");
    element.removeAttribute("controls");
  }
}

function blueskyCombinedDecision(decisions) {
  const values = Array.isArray(decisions) ? decisions : [];
  if (values.some((decision) => decision && decision.blocked)) {
    return "blocked";
  }
  if (values.length && values.every((decision) => decision && decision.known && !decision.blocked)) {
    return "safe";
  }
  return "unknown";
}

function showBlueskySearchBlock() {
  purestateInstantHide(document, "purestate-bsky-page-style");
  purestateShowSearchOverlay(
    document,
    "purestate-bsky-page-block",
    "Diese Bluesky-Suche wurde durch Purestate blockiert."
  );
}

function clearBlueskySearchBlock() {
  purestateHideSearchOverlay(document, "purestate-bsky-page-block", "purestate-bsky-page-style");
}

function collectBlueskyCards(root) {
  const cards = new Map();
  const links = root && typeof root.querySelectorAll === "function"
    ? root.querySelectorAll("a[href*='/profile/'][href*='/post/']")
    : [];
  for (const link of links) {
    const identity = blueskyPostIdentityFromHref(link.getAttribute("href"));
    const card = blueskyPostCardForLink(link);
    if (!identity || !card) {
      continue;
    }
    let entry = cards.get(card);
    if (!entry) {
      entry = { identities: [], card };
      cards.set(card, entry);
    }
    if (!entry.identities.some((item) => item.key === identity.key)) {
      entry.identities.push(identity);
    }
  }
  const fallbackCandidates = root && typeof root.querySelectorAll === "function"
    ? root.querySelectorAll("[data-testid*='feedItem'], article, [role='article'], [role='link']:not(a)")
    : [];
  for (const candidate of fallbackCandidates) {
    if (blueskyCardAlreadyCollected(cards, candidate)) {
      continue;
    }
    const hasLocalAdultSignal = blueskyVisibleAdultWarning(candidate) || blueskyVisibleAdultText(candidate);
    if (!hasLocalAdultSignal) {
      continue;
    }
    const identities = blueskyPostIdentitiesInCard(candidate);
    cards.set(candidate, { identities, card: candidate });
  }
  const mediaElements = blueskyMediaElements(root || document);
  for (const media of mediaElements) {
    const card = blueskyPostCardForMedia(media);
    if (!card || blueskyCardAlreadyCollected(cards, card)) {
      continue;
    }
    const identities = blueskyPostIdentitiesInCard(card);
    cards.set(card, { identities, card });
  }
  return Array.from(cards.values());
}

function blueskyCardAlreadyCollected(cards, card) {
  for (const existing of cards.keys()) {
    if (existing === card ||
        (typeof existing.contains === "function" && existing.contains(card)) ||
        (typeof card.contains === "function" && card.contains(existing))) {
      return true;
    }
  }
  return false;
}

// EXT-A01: Eine Antwort gehoert zu der Beitragsidentitaet, fuer die sie
// angefragt wurde - nicht zu der DOM-Referenz. Bluesky kann Karten
// wiederverwenden; ein verspaetetes "safe" fuer Beitrag A durfte sonst die
// inzwischen gesperrte Karte B freigeben. Die Generation steht in einer
// WeakMap statt in einem Attribut, damit die Seite sie nicht nachstellen kann.
const blueskyCardGenerations = new WeakMap();
let blueskyScanGeneration = 0;

// Schluessel und Generation genuegen. isConnected gehoert bewusst nicht dazu:
// eine kurz abgehaengte und wieder eingehaengte Karte bekaeme sonst nie ihre
// eigene Antwort und bliebe dauerhaft verdeckt.
function blueskyPendingEntryCurrent(entry) {
  return entry.card.getAttribute("data-purestate-bsky-key") === entry.key &&
    blueskyCardGenerations.get(entry.card) === entry.generation;
}

async function scanBlueskyPosts(root) {
  enforceBlueskyAdultSetting(root || document);
  if (blueskyAdultSearchFromLocation(window.location.href) || blueskyAdultSearchFromVisibleControls(root || document)) {
    showBlueskySearchBlock();
    return;
  }
  clearBlueskySearchBlock();

  const cards = collectBlueskyCards(root || document);
  const pending = [];
  for (const entry of cards) {
    const state = entry.card.getAttribute("data-purestate-bsky-state");
    const currentKey = entry.card.getAttribute("data-purestate-bsky-key");
    const combinedKey = entry.identities.length
      ? entry.identities.map((identity) => identity.key).sort().join("|")
      : blueskyVisibleCardKey(entry.card);
    if (currentKey === combinedKey && (state === "safe" || state === "blocked" || state === "pending")) {
      continue;
    }
    entry.card.setAttribute("data-purestate-bsky-key", combinedKey);
    entry.card.setAttribute("data-purestate-bsky-state", "pending");
    blueskyScanGeneration += 1;
    blueskyCardGenerations.set(entry.card, blueskyScanGeneration);
    entry.key = combinedKey;
    entry.generation = blueskyScanGeneration;
    if (blueskyVisibleAdultWarning(entry.card) || blueskyVisibleAdultText(entry.card)) {
      blockBlueskyCard(entry.card, "18+ Beitrag blockiert");
      continue;
    }
    if (!entry.identities.length) {
      // Ohne Beitragskennung und ohne lokales Signal: eine zuvor nur zur
      // Pruefung verdeckte Karte wird wieder freigegeben. Eine schon gesperrte
      // Karte bleibt gesperrt - ein verschwundener Link ist kein Freibrief.
      if (state === "blocked") {
        blockBlueskyCard(entry.card, "18+ Beitrag blockiert");
      } else if (state === "pending" || state === "safe") {
        releaseBlueskyCardMedia(entry.card);
      } else {
        entry.card.setAttribute("data-purestate-bsky-state", "safe");
      }
      continue;
    }
    coverBlueskyCardMedia(entry.card, "Medien werden sicher geprüft");
    pending.push(entry);
  }

  if (!pending.length) {
    return;
  }

  let response;
  try {
    response = await chrome.runtime.sendMessage({
      type: BLUESKY_POSTS_CHECK,
      posts: pending.flatMap((entry) => entry.identities)
    });
  } catch {
    response = null;
  }

  const decisions = new Map();
  for (const decision of response && Array.isArray(response.decisions) ? response.decisions : []) {
    if (decision && decision.key) {
      decisions.set(decision.key, decision);
    }
  }
  let staleConnectedCard = false;
  for (const entry of pending) {
    // Veraltet: Karte abgehaengt, anderer Beitrag darin oder eine neuere
    // Pruefung unterwegs. Dann nichts anfassen - weder freigeben noch sperren.
    // Die Karte bleibt verdeckt, bis ihre eigene Antwort kommt.
    if (!blueskyPendingEntryCurrent(entry)) {
      staleConnectedCard = staleConnectedCard || entry.card.isConnected === true;
      continue;
    }
    const cardDecisions = entry.identities.map((identity) => decisions.get(identity.key));
    const combinedDecision = blueskyCombinedDecision(cardDecisions);
    if (combinedDecision === "blocked") {
      blockBlueskyCard(entry.card, "18+ Beitrag blockiert");
    } else if (combinedDecision === "safe") {
      releaseBlueskyCardMedia(entry.card);
    } else {
      // BSK-003: Hier fail-CLOSED, waehrend Reddit im selben Fall freigibt
      // (content.js, state === "unknown"). Beide Entscheidungen sind richtig,
      // aber nur eine war begruendet - deshalb hier die Gegenprobe:
      //
      // Reddit gibt frei, WEIL seine by-id-Abfrage bei grossen Feed-Stapeln
      // ratenbegrenzt wird und dabei harmlose Bilder verdeckte; dort tragen
      // vier Ersatzsignale die Erkennung. Die Bluesky-API drosselt nicht -
      // eine unschluessige Antwort heisst hier also wirklich "unbekannt", nicht
      // "gerade zu viele Anfragen". Ohne Ersatzsignal und ohne Drosselgrund
      // bleibt fail-closed.
      //
      // Die Regel an allen Stellen: fail-closed, AUSSER die Gegenstelle
      // drosselt nachweislich; dann fail-open mit benannten Ersatzsignalen.
      blockBlueskyCard(entry.card, "Medien konnten nicht sicher geprüft werden");
    }
  }
  if (staleConnectedCard) {
    scheduleBlueskyScan();
  }
}

function blueskyRevealAttempt(target) {
  if (!target || typeof target.closest !== "function") {
    return false;
  }
  if (target.closest("[data-purestate-bsky-state='blocked'], [data-purestate-bsky-placeholder='true']")) {
    return true;
  }
  const button = target.closest("button, [role='button']");
  if (!button) {
    return false;
  }
  const text = normalizeBlueskySearchText(button.textContent || button.getAttribute("aria-label") || "");
  if (!/(^| )(show|view|anzeigen|ansehen)( |$)/.test(text)) {
    return false;
  }
  const card = blueskyPostCardForLink(button) || button.parentElement;
  return blueskyVisibleAdultWarning(card);
}

function guardBlueskyReveal(event) {
  if (!blueskyRevealAttempt(event.target)) {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  event.stopImmediatePropagation();
}

// --- Adult-content account setting (bsky.app/moderation) --------------------
// The moderation page renders an "enable adult content" toggle as
//   <div role="checkbox" aria-checked aria-label="...Erwachsene.../...adult...">
// The emotion CSS classes are hashed and unstable, so the aria-label is the
// only reliable hook. We force it OFF and make it un-clickable.

let blueskyLastSettingClick = 0;

function blueskyAdultSettingControl(root) {
  const scope = root && typeof root.querySelectorAll === "function" ? root : document;
  for (const control of scope.querySelectorAll('[role="checkbox"][aria-label],[role="switch"][aria-label]')) {
    const label = String(control.getAttribute("aria-label") || "").toLowerCase();
    if (/erwachsen|adult/.test(label)) {
      return control;
    }
  }
  return null;
}

function blueskyControlIsOn(control) {
  return String(control.getAttribute("aria-checked") || "").toLowerCase() === "true";
}

function enforceBlueskyAdultSetting(root) {
  const control = blueskyAdultSettingControl(root);
  if (!control) {
    return;
  }
  // Lock it un-clickable for the user; our synthetic .click() still works
  // because pointer-events:none does not block programmatic clicks.
  if (control.style && control.style.setProperty) {
    control.style.setProperty("pointer-events", "none", "important");
    control.style.setProperty("cursor", "not-allowed", "important");
  }
  if (!blueskyControlIsOn(control)) {
    return;
  }
  const now = Date.now();
  if (now - blueskyLastSettingClick < 1000) {
    return;
  }
  blueskyLastSettingClick = now;
  try {
    control.click();
  } catch {
  }
}

function guardBlueskyAdultSettingClick(event) {
  // Our own enforcement flip is a synthetic click (isTrusted === false).
  if (event && event.isTrusted === false) {
    return;
  }
  const target = event && event.target;
  if (!target || typeof target.closest !== "function") {
    return;
  }
  const control = target.closest('[role="checkbox"][aria-label],[role="switch"][aria-label]');
  if (!control) {
    return;
  }
  const label = String(control.getAttribute("aria-label") || "").toLowerCase();
  if (!/erwachsen|adult/.test(label)) {
    return;
  }
  // Block only the unsafe direction: turning it ON while it is currently off.
  if (blueskyControlIsOn(control)) {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  if (event.stopImmediatePropagation) {
    event.stopImmediatePropagation();
  }
  setTimeout(() => enforceBlueskyAdultSetting(document), 50);
}

function scheduleBlueskyScan() {
  clearTimeout(blueskyScanTimer);
  blueskyScanTimer = setTimeout(() => scanBlueskyPosts(document), BLUESKY_SCAN_DELAY_MS);
}

function installBlueskyMonitoring() {
  installBlueskyShieldStyle();
  requestBlueskyRulePack();
  document.addEventListener("click", guardBlueskyReveal, true);
  document.addEventListener("click", guardBlueskyAdultSettingClick, true);
  document.addEventListener("pointerdown", guardBlueskyAdultSettingClick, true);
  document.addEventListener("keydown", (event) => {
    if (event && (event.key === " " || event.key === "Enter")) {
      guardBlueskyAdultSettingClick(event);
    }
  }, true);
  const observer = new MutationObserver(scheduleBlueskyScan);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  setInterval(() => {
    if (window.location.href !== lastBlueskyLocation) {
      lastBlueskyLocation = window.location.href;
      scheduleBlueskyScan();
    }
  }, 400);
  // BSK-002: Hier stand zusaetzlich ein BEDINGUNGSLOSER Sekundentakt
  // (setInterval(scheduleBlueskyScan, 1000)), der auch auf Seiten ohne einen
  // einzigen Beitrag das ganze Dokument abgesucht hat. Er ist gestrichen: der
  // Mutationsbeobachter haengt an documentElement mit subtree und sieht jede
  // Feedaenderung, der 400-ms-Wecker deckt den Adresswechsel ab. Damit bleiben
  // zwei Ausloeser statt drei, und keiner davon feuert im Leerlauf.
  scheduleBlueskyScan();
}

purestateRunWhenSiteProtectionEnabled("bluesky", () => {
  installBlueskyMonitoring();
});
