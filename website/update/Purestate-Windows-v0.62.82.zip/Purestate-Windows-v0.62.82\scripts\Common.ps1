﻿$script:ServiceName = "PurestateGuard"
$script:DisplayName = "Purestate Schutzdienst"
$script:WatchdogTaskName = "\Purestate\Watchdog"
$script:StartupTaskName = "\Purestate\Startup"
$script:DataDir = Join-Path $env:ProgramData "Purestate"
$script:ConfigPath = Join-Path $script:DataDir "config.json"
$script:IntegrityKeyPath = Join-Path $script:DataDir "integrity.key"
$script:DnsBackupPath = Join-Path $script:DataDir "dns-backup.json"
$script:EntitlementReleaseMarkerPath = Join-Path $script:DataDir "beta-ended.marker"
$script:ProxyBackupPath = Join-Path $script:DataDir "proxy-backup.json"
# PST-002: Die hosts-Datei ist die einzige Datei, die Purestate an einem
# fremden, systemweiten Ort vollstaendig ueberschreibt - und hatte als einzige
# keine Sicherung. Fremdeintraege fuer Entwicklungsumgebungen, interne Server
# oder Werbeblocker waeren nach einem Fehlschlag endgueltig weg.
$script:HostsBackupPath = Join-Path $script:DataDir "hosts-backup"
$script:BrowserCompanionStatePath = Join-Path $script:DataDir "browser-companion-state.json"
# RGL-006: Deckel der Stichwortdatei. Die C#-Seite spiegelt ihn.
$script:MaxAdultUrlKeywords = 300
$script:CompanionHeartbeatMaxAgeSeconds = 300
$script:CompanionBrowserStartupGraceSeconds = 300
$script:CompanionStoreId = "gmldhenkcnghfoapdnhkikfpgdmmnlok"
$script:CompanionStoreUpdateUrl = "https://clients2.google.com/service/update2/crx"
# Records exactly which URLBlocklist/WebsiteFilter entries Purestate added to
# each shared policy list, so enable/disable never touches third-party entries.
$script:ManagedListRecordPath = Join-Path $script:DataDir "managed-url-lists.json"
$script:LogPath = Join-Path $script:DataDir "activity.log"
$script:SecurityLogPath = Join-Path $script:DataDir "security.log"
$script:MaxLogBytes = 262144
$script:MaxLogLineChars = 2048
$script:MinimumPasswordLength = 12
$script:LongPassphraseLength = 20
$script:CurrentIntegritySchemaVersion = 15
# Ende dieser Programmfassung. Spiegelt Support.BetaBuildEndUtc in
# src\NativeSupportAuthority.cs - beide Werte muessen gleich sein, sonst
# widersprechen sich App und Durchsetzungsspiegel. Im Verkaufs-Build leer.
$script:BetaBuildEndUtc = "2027-03-31T00:00:00.0000000Z"
$script:PasswordPolicyMessage = "Das Passwort muss mindestens 12 Zeichen haben und entweder drei Zeichenarten enthalten oder eine lange Passphrase ab 20 Zeichen sein."
$script:HostsPath = Join-Path $env:SystemRoot "System32\drivers\etc\hosts"
$script:MarkerBegin = "# Purestate BEGIN"
$script:MarkerEnd = "# Purestate END"
# Reservierte Endung .invalid (RFC 2606): Platzhalter, wenn die effektive
# Sperrliste leer ist - siehe Enable-HostsProtection.
$script:HostsPlaceholderDomain = "purestate.invalid"
$script:DefaultDnsProfile = "CloudflareFamily"
# POL-001: Chromium wertet aus URLBlocklist hoechstens 1000 Eintraege aus. Die
# Musterlisten setzen denselben Deckel schon beim Erzeugen durch (dort als
# Literal, an 26 Stellen, absichtlich unangetastet - Enforce-Protection.ps1:61
# prueft hart auf genau 1000). Diese Konstante deckelt die Liste zusaetzlich
# beim SCHREIBEN, wo die Zusammenfuehrung mit Fremdeintraegen sie wieder
# verlaengert hat.
$script:MaxPolicyUrlListEntries = 1000
$script:BypassFirewallPrefix = "Purestate Bypass Block - "
$script:UnsupportedBrowserFirewallPrefix = "Purestate Unsupported Browser Block - "

function Get-AppRoot {
    return (Split-Path -Parent $PSScriptRoot)
}

# Dev-only escape hatch so a developer can test an unpacked (not-yet-
# Store-approved) Companion build without waiting out a Chrome Web Store
# review. Reads a single Chrome/Edge extension ID (32 lowercase a-p chars)
# from a file that must never ship: it lives outside source control
# (.gitignore'd) and tools\Test-ReleasePreflight.ps1 hard-fails the release
# build if the file is present, so it cannot leak into a public artifact.
# Absent, empty, or malformed content -> $null -> zero behavior change.
function Get-DevCompanionExtensionId {
    param([string]$AppRoot = (Get-AppRoot))

    # ENS-001: Diese Datei uebergibt die Companion-Vertrauensrolle an eine
    # beliebige entpackte Erweiterung und nimmt gleichzeitig die Store-
    # Erzwingung zurueck. Im ausgelieferten Bau darf sie deshalb nichts
    # bedeuten - sonst genuegt das Passwort, um die gesamte browserseitige
    # Schutzschicht gegen eine leere Erweiterung zu tauschen, ohne
    # Abschwaechungsfenster. Der Entwicklerbau erkennt sich an DEV-BUILD.txt,
    # die tools\Test-ReleasePreflight.ps1 in einem Release hart ablehnt.
    if (-not (Test-Path -LiteralPath (Join-Path $AppRoot "DEV-BUILD.txt") -PathType Leaf)) {
        return $null
    }

    $path = Join-Path $AppRoot "dev-companion-id.txt"
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        return $null
    }
    try {
        $id = (Get-Content -Raw -LiteralPath $path -ErrorAction Stop).Trim()
    } catch {
        return $null
    }
    if ($id -cnotmatch '^[a-p]{32}$') {
        return $null
    }
    return $id
}

function Assert-DataDirectoryIsNotReparsePoint {
    param([string]$Path = $script:DataDir)

    $fullPath = [System.IO.Path]::GetFullPath($Path)
    if (-not [System.IO.Directory]::Exists($fullPath)) {
        return
    }
    $attributes = [System.IO.File]::GetAttributes($fullPath)
    if (($attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "Das Purestate-Datenverzeichnis darf kein Verknuepfungs- oder Reparse-Punkt sein."
    }
}

function Ensure-DataDir {
    if (-not [System.IO.Directory]::Exists($script:DataDir)) {
        [System.IO.Directory]::CreateDirectory($script:DataDir) | Out-Null
    }
    Assert-DataDirectoryIsNotReparsePoint
}

function Add-AppLog {
    param([string]$Message)

    Add-CappedLogLine -Path $script:LogPath -Message $Message
}

# Mirrors the C# WriteSecurityLog target (security.log) so security-relevant
# events (integrity failures etc.) land in the same place from both languages.
# Spiegelt Support.IsInstallWindowActive. Waehrend einer laufenden
# Installation darf der Watchdog nicht dazwischenfunken: er wuerde eine schon
# migrierte Konfiguration mit noch alten Skripten lesen und einen
# Integritaets-Fehlalarm ins security.log schreiben.
#
# Ein unlesbarer, zu alter oder in der Zukunft liegender Marker gilt als
# "keine Installation" - im Zweifel arbeitet der Watchdog weiter, statt
# dauerhaft stillzustehen.
function Test-PurestateInstallInProgress {
    param(
        [string]$Path = (Join-Path $script:DataDir "install-in-progress.txt"),
        [int]$WindowMinutes = 15
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return $false
    }

    try {
        $raw = ([string](Get-Content -Raw -LiteralPath $Path)).Trim()
    } catch {
        return $false
    }

    $started = [datetime]::MinValue
    $styles = [System.Globalization.DateTimeStyles]::RoundtripKind
    if (-not [datetime]::TryParse($raw, [System.Globalization.CultureInfo]::InvariantCulture, $styles, [ref]$started)) {
        return $false
    }

    $startedUtc = $started.ToUniversalTime()
    $nowUtc = [DateTime]::UtcNow
    if ($nowUtc -lt $startedUtc) {
        return $false
    }

    return (($nowUtc - $startedUtc).TotalMinutes -lt $WindowMinutes)
}

function Add-SecurityLog {
    param([string]$Message)

    Add-CappedLogLine -Path $script:SecurityLogPath -Message $Message
    Write-PurestateWindowsEventLog -Message $Message
}

# BAS-001: Die C#-Seite schreibt Sicherheitsereignisse in ZWEI Senken, die
# PowerShell-Seite kannte nur die Textdatei - und hier entstehen genau die
# Ereignisse, die eine Manipulation anzeigen: HMAC-Bruch, fehlender
# Integritaetsschluessel, Vorwaertssprung der Systemuhr. Nach einem
# Integritaetsbruch ist die Konfiguration gesperrt, aber die Spur, wann und
# warum, konnte restlos verschwinden. Spiegelt MirrorSecurityEventToWindowsLog
# in src\NativeSupport.cs, einschliesslich des gemerkten Zustands: ein Kontext
# ohne Adminrechte kann die Quelle nicht anlegen und hoert nach dem ersten
# Versuch auf, es zu probieren.
# 0 = noch nicht geprueft, 1 = Quelle da, 2 = nicht verfuegbar.
$script:WindowsEventSourceState = 0

function Write-PurestateWindowsEventLog {
    param([string]$Message)

    if ($script:WindowsEventSourceState -eq 2) {
        return
    }

    try {
        if ($script:WindowsEventSourceState -eq 0) {
            if (-not [System.Diagnostics.EventLog]::SourceExists("Purestate")) {
                [System.Diagnostics.EventLog]::CreateEventSource("Purestate", "Application")
            }
            $script:WindowsEventSourceState = 1
        }

        $text = ([string]$Message -replace "[`r`n`t]+", " ").Trim()
        if ($text.Length -gt $script:MaxLogLineChars) {
            $text = $text.Substring(0, $script:MaxLogLineChars)
        }
        Write-EventLog -LogName Application -Source "Purestate" -EntryType Warning -EventId 1000 -Message $text -ErrorAction Stop
    } catch {
        $script:WindowsEventSourceState = 2
    }
}

function Add-CappedLogLine {
    param(
        [string]$Path,
        [string]$Message
    )

    try {
        Ensure-DataDir
        $text = [string]$Message
        $text = ($text -replace "[`r`n`t]+", " ").Trim()
        if ($text.Length -gt $script:MaxLogLineChars) {
            $text = $text.Substring(0, $script:MaxLogLineChars)
        }

        $line = ("{0} {1}" -f (Get-Date -Format "s"), $text)
        $encoding = New-Object System.Text.UTF8Encoding($false)
        $fullPath = [System.IO.Path]::GetFullPath($Path)
        $info = New-Object System.IO.FileInfo($fullPath)
        # BAS-001: Frueher ersetzte der Ueberlauf die GANZE Datei durch die
        # neue Zeile. Wer die Vorgeschichte loswerden wollte, musste sie also
        # nicht loeschen - das faellt auf -, es genuegte, sie vollzuschreiben.
        # Eine Generation bleibt jetzt liegen, wie in C# (NMH-003).
        if ($info.Exists -and $info.Length -gt $script:MaxLogBytes) {
            try {
                $previous = $fullPath + ".1"
                if (Test-Path -LiteralPath $previous) {
                    Remove-Item -LiteralPath $previous -Force
                }
                [System.IO.File]::Move($fullPath, $previous)
            } catch {
                # Haelt ein anderer Prozess die Datei offen, wird weiter
                # angehaengt: eine zu grosse Datei ist besser als eine
                # verlorene Zeile.
            }
        }

        # Geteiltes Schreiben: Dienst, App und Durchsetzungshelfer schreiben
        # gleichzeitig, und AppendAllText oeffnet ohne FileShare - die Zeile
        # ging im catch unten still verloren.
        $bytes = $encoding.GetBytes($line + [Environment]::NewLine)
        for ($versuch = 0; $versuch -lt 5; $versuch++) {
            try {
                $stream = New-Object System.IO.FileStream(
                    $fullPath,
                    [System.IO.FileMode]::Append,
                    [System.IO.FileAccess]::Write,
                    [System.IO.FileShare]::ReadWrite)
                try {
                    $stream.Write($bytes, 0, $bytes.Length)
                } finally {
                    $stream.Dispose()
                }
                break
            } catch [System.IO.IOException] {
                Start-Sleep -Milliseconds 20
            }
        }
    } catch {
    }
}

function Ensure-RegistryKey {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        # -Force creates missing intermediate keys (e.g. Policies\Google on a
        # machine without Chrome); without it New-Item throws ArgumentException.
        New-Item -Path $Path -Force | Out-Null
    }
}

function Test-IsAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-SystemToolPath {
    param([string]$Name)

    $path = Join-Path $env:SystemRoot ("System32\" + $Name)
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "$Name wurde nicht gefunden."
    }

    return $path
}

# Compares two dotted numeric version strings. Returns -1 if a < b, 0 if
# equal, 1 if a > b. Missing/non-numeric components count as 0. Kept
# byte-compatible with Support.CompareVersionStrings in NativeSupportProtectionAreas.cs.
function Compare-PurestateVersion {
    param([string]$A, [string]$B)

    $pa = ([string]$A).Split('.')
    $pb = ([string]$B).Split('.')
    $count = [Math]::Max($pa.Length, $pb.Length)
    for ($i = 0; $i -lt $count; $i++) {
        $va = 0
        $vb = 0
        if ($i -lt $pa.Length) { [void][int]::TryParse(([string]$pa[$i]).Trim(), [Globalization.NumberStyles]::None, [Globalization.CultureInfo]::InvariantCulture, [ref]$va) }
        if ($i -lt $pb.Length) { [void][int]::TryParse(([string]$pb[$i]).Trim(), [Globalization.NumberStyles]::None, [Globalization.CultureInfo]::InvariantCulture, [ref]$vb) }
        if ($va -ne $vb) {
            if ($va -lt $vb) { return -1 } else { return 1 }
        }
    }
    return 0
}

function Get-PurestateAppVersion {
    $manifest = Join-Path (Get-AppRoot) "PurestateManifest.txt"
    if (Test-Path -LiteralPath $manifest) {
        $line = Get-Content -LiteralPath $manifest | Where-Object { $_ -like "AppVersion=*" } | Select-Object -First 1
        if ($line) {
            return ([string]$line).Substring("AppVersion=".Length).Trim()
        }
    }
    return ""
}

function Protect-InstallFolderAcl {
    try {
        $root = Get-AppRoot
        if (-not (Test-Path -LiteralPath $root -PathType Container)) {
            return
        }

        $icacls = Get-SystemToolPath -Name "icacls.exe"
        & $icacls $root /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX' | Out-Null
    } catch {
        Add-AppLog "Install folder protection failed: $($_.Exception.Message)"
    }
}

function Get-NativeMessagingManifestPath {
    param([string]$BaseManifestPath, [string]$DevCompanionId = $null)

    $devId = if ($PSBoundParameters.ContainsKey('DevCompanionId')) { $DevCompanionId } else { Get-DevCompanionExtensionId }
    if ([string]::IsNullOrWhiteSpace($devId)) {
        return $BaseManifestPath
    }

    # Chrome enforces allowed_origins against the calling extension's actual
    # ID, so the unpacked dev build's own ID must appear there too, or
    # connectNative() is refused and no heartbeat can ever reach the Guard.
    # Written to ProgramData, never to the tracked manifest under source
    # control, so the checked-in file (and git status) stay untouched.
    try {
        $json = Get-Content -Raw -LiteralPath $BaseManifestPath -ErrorAction Stop | ConvertFrom-Json
        $origins = @(@($json.allowed_origins) + @("chrome-extension://$devId/") | Select-Object -Unique)
        $json.allowed_origins = $origins
        $baseManifestDir = Split-Path -Parent $BaseManifestPath
        if ([string]::IsNullOrWhiteSpace($baseManifestDir)) {
            $baseManifestDir = Get-AppRoot
        }
        # Chrome reads the native-host manifest as the signed-in Windows user.
        # ProgramData is intentionally private, so the dev copy must live next
        # to the normal manifest in the read-only install/source tree.
        $devManifestPath = Join-Path $baseManifestDir "com.purestate.companion.dev.json"
        $json | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $devManifestPath -Encoding UTF8
        Add-AppLog "DEV-MODUS: Native Messaging vertraut zusaetzlich einer lokal konfigurierten Erweiterung (dev-companion-id.txt). Nicht fuer Produktivgeraete."
        return $devManifestPath
    } catch {
        Add-AppLog "DEV-MODUS: dev-companion-id.txt konnte nicht angewendet werden: $($_.Exception.Message)"
        return $BaseManifestPath
    }
}

function Ensure-NativeMessagingHostRegistration {
    $manifest = Join-Path (Get-AppRoot) "native-host\com.purestate.companion.json"
    $hostExe = Join-Path (Get-AppRoot) "PurestateNativeHost.exe"
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf) -or -not (Test-Path -LiteralPath $hostExe -PathType Leaf)) {
        return
    }

    $manifestToRegister = Get-NativeMessagingManifestPath -BaseManifestPath $manifest

    foreach ($path in @(
        "HKLM:\SOFTWARE\Google\Chrome\NativeMessagingHosts\com.purestate.companion",
        "HKLM:\SOFTWARE\Microsoft\Edge\NativeMessagingHosts\com.purestate.companion",
        "HKLM:\SOFTWARE\WOW6432Node\Google\Chrome\NativeMessagingHosts\com.purestate.companion",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Edge\NativeMessagingHosts\com.purestate.companion"
    )) {
        Ensure-RegistryKey -Path $path
        Set-Item -Path $path -Value $manifestToRegister -Force
    }
}

function Merge-CompanionExtensionSettings {
    param([string]$Current)

    $ourEntry = [ordered]@{
        installation_mode = "force_installed"
        update_url = $script:CompanionStoreUpdateUrl
        toolbar_pin = "force_pinned"
    }

    $map = $null
    if (-not [string]::IsNullOrWhiteSpace($Current)) {
        try {
            $parsed = $Current | ConvertFrom-Json -ErrorAction Stop
            $map = [ordered]@{}
            foreach ($prop in $parsed.PSObject.Properties) {
                $map[$prop.Name] = $prop.Value
            }
        } catch {
            $map = $null
        }
    }

    if ($null -eq $map) {
        # Unset or not JSON we can safely merge into: write only our own entry.
        $map = [ordered]@{}
    }

    $map[$script:CompanionStoreId] = $ourEntry
    return ($map | ConvertTo-Json -Compress -Depth 8)
}

function Remove-CompanionKeyFromJson {
    param([string]$Json, [string]$Key)

    $source = if ($null -eq $Json) { "" } else { $Json }
    $trimmed = $source.Trim()
    if (-not $trimmed.StartsWith("{") -or -not $trimmed.EndsWith("}")) {
        return $null
    }

    try {
        $parsed = $trimmed | ConvertFrom-Json -ErrorAction Stop
        $map = [ordered]@{}
        $removed = $false
        foreach ($prop in $parsed.PSObject.Properties) {
            if ($prop.Name -eq $Key) {
                $removed = $true
                continue
            }
            $map[$prop.Name] = $prop.Value
        }
        if (-not $removed) {
            return $trimmed
        }
        return ($map | ConvertTo-Json -Compress -Depth 8)
    } catch {
        return $null
    }
}

function Set-ForcelistEntry {
    param(
        [string]$Path,
        [string]$Entry,
        [string]$Id
    )

    $used = @()
    $alreadyPresent = $false
    $key = Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
    if ($key) {
        foreach ($name in $key.GetValueNames()) {
            $used += [string]$name
            $val = [string]$key.GetValue($name)
            if ($val -eq $Entry -or $val -eq $Id -or $val.StartsWith($Id + ";")) {
                $alreadyPresent = $true
            }
        }
    }

    if ($alreadyPresent) {
        return
    }

    $slot = 1
    while ($used -contains ([string]$slot)) {
        $slot++
    }
    New-ItemProperty -Path $Path -Name ([string]$slot) -Value $Entry -PropertyType String -Force | Out-Null
}

function Remove-ForcelistEntry {
    param(
        [string]$Path,
        [string]$Id,
        [switch]$RequireComplete
    )

    $key = Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
    if (-not $key) {
        return
    }

    foreach ($name in $key.GetValueNames()) {
        $val = [string]$key.GetValue($name)
        if ($val -eq $Id -or $val.StartsWith($Id + ";")) {
            Remove-ItemProperty -LiteralPath $Path -Name $name -ErrorAction $(if ($RequireComplete) { "Stop" } else { "SilentlyContinue" })
        }
    }

    $key = Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
    if ($key -and $key.GetValueNames().Count -eq 0 -and $key.GetSubKeyNames().Count -eq 0) {
        Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# Ein Entwicklerbau erkennt sich an der Markierungsdatei, die
# tools\Build-Release.ps1 -Dev ins Paket legt. PowerShell kann die
# C#-Compilerkonstante PURESTATE_DEV nicht sehen, und der Release-Preflight
# lehnt ein Paket mit dieser Datei hart ab - sie kann also nie ausgeliefert
# werden.
function Test-PurestateDevBuild {
    return (Test-Path -LiteralPath (Join-Path (Get-AppRoot) "DEV-BUILD.txt") -PathType Leaf)
}

function Ensure-ManagedCompanionPolicy {
    # Im Entwicklerbau KEIN Store-Zwang: sonst installiert Chrome die
    # veroeffentlichte - und damit haeufig veraltete - Companion-Version neben
    # der lokal entpackten, und getestet wird der falsche Stand.
    #
    # Das schwaecht nichts ab: ohne die verwaltete Richtlinie gilt der
    # Companion als NICHT aktiv, und die Browser laufen in die
    # fail-closed-Sperrliste. Der Entwicklerbau wird dadurch strenger, nicht
    # milder. Wer die lokale Erweiterung auch fuer Native Messaging anerkannt
    # haben will, traegt ihre ID zusaetzlich in dev-companion-id.txt ein.
    $devId = Get-DevCompanionExtensionId
    if ((-not [string]::IsNullOrWhiteSpace($devId)) -or (Test-PurestateDevBuild)) {
        Remove-ManagedCompanionPolicy
        return
    }

    # Nach dem Ablauf keine zwangsinstallierte, angepinnte Erweiterung mehr:
    # Abschnitt 6 der Spezifikation schliesst eine tote Sperre ohne Verwaltung
    # aus. Die Sperre steht HIER und nicht in den Aufrufern, weil Watchdog.ps1
    # diese Funktion in jedem Lauf ungeprueft aufruft. Fehlerrichtung: eine
    # nicht ladbare Konfiguration gilt als NICHT abgelaufen - die Richtlinie
    # wird dann wie bisher geschrieben. Das deckt sich mit
    # GuardService.IsBetaExpired, sonst schriebe der Guard, was dieser Pfad
    # gerade entfernt.
    $expired = $false
    try {
        $expired = Test-EntitlementExpired -Config (Get-Config)
    } catch {
    }
    if ($expired) {
        Remove-ManagedCompanionPolicy
        return
    }

    foreach ($root in @(
        "HKLM:\SOFTWARE\Policies\Google\Chrome",
        "HKLM:\SOFTWARE\Policies\Microsoft\Edge"
    )) {
        Ensure-RegistryKey -Path $root
        $forceList = Join-Path $root "ExtensionInstallForcelist"
        Ensure-RegistryKey -Path $forceList
        # Add our force-install entry under a free slot only if absent, so we
        # never clobber another organisation's entry at index "1".
        Set-ForcelistEntry -Path $forceList -Entry ($script:CompanionStoreId + ";" + $script:CompanionStoreUpdateUrl) -Id $script:CompanionStoreId

        # Merge into any existing ExtensionSettings instead of overwriting it, so
        # managed devices keep their other extension policies.
        $existing = $null
        $existingProp = Get-ItemProperty -Path $root -Name "ExtensionSettings" -ErrorAction SilentlyContinue
        if ($existingProp) {
            $existing = [string]$existingProp.ExtensionSettings
        }
        $settings = Merge-CompanionExtensionSettings -Current $existing
        New-ItemProperty -Path $root -Name "ExtensionSettings" -Value $settings -PropertyType String -Force | Out-Null
    }
}

function Ensure-ScheduledTaskFolder {
    $scheduler = New-Object -ComObject "Schedule.Service"
    $scheduler.Connect()
    try {
        $scheduler.GetFolder("\Purestate") | Out-Null
    } catch {
        $root = $scheduler.GetFolder("\")
        try {
            $root.CreateFolder("Purestate") | Out-Null
        } catch {
            # Verwaiste Aufgabendateien einer alten Deinstallation: der Planer
            # kennt den Ordner nicht mehr, auf der Platte liegt er noch. Dann
            # scheitern GetFolder UND CreateFolder (0x800700B7) und jede
            # Neuinstallation bricht ab. Registrierte Aufgaben sind hier nie
            # betroffen - sonst haette GetFolder gegriffen.
            Remove-Item -LiteralPath (Join-Path $env:WINDIR "System32\Tasks\Purestate") -Recurse -Force -ErrorAction SilentlyContinue
            $root.CreateFolder("Purestate") | Out-Null
        }
    }
}

# BAS-002: Ausgewertet wird die XML-Ausgabe von schtasks, nicht der
# Anzeigetext - der ist lokalisiert ("Deaktiviert"/"Disabled"), das
# <Enabled>-Element nicht. Fehlt das Element, ist die Aufgabe aktiviert; so
# legt Windows sie an. Zwilling von Support.ScheduledTaskXmlIsEnabled.
function Test-ScheduledTaskXmlEnabled {
    param([string]$TaskXml)

    $xml = ([string]$TaskXml).Trim()
    if ($xml.Length -eq 0) {
        return $false
    }

    $match = [regex]::Match($xml, '(?i)<Enabled\s*>\s*(true|false)\s*</Enabled\s*>')
    if (-not $match.Success) {
        return $true
    }

    return ($match.Groups[1].Value.Trim().ToLowerInvariant() -eq "true")
}

function Ensure-WatchdogTask {
    $watchdog = Join-Path (Get-AppRoot) "scripts\Watchdog.ps1"
    if (-not (Test-Path -LiteralPath $watchdog -PathType Leaf)) {
        throw "Watchdog.ps1 wurde nicht gefunden."
    }

    $powershell = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
    $schtasks = Get-SystemToolPath -Name "schtasks.exe"
    # Windows PowerShell 5.1 maskiert eingebettete Anfuehrungszeichen nicht, wenn es ein
    # Programm aufruft: ohne \" zerfiele /TR in mehrere Argumente, schtasks meldete
    # "Ungueltige(s) Option/Argument", und die Reparatur der Aufgaben scheiterte stets
    # (VM 2026-10-06). Dieselbe Schreibweise wie bei den Aufgaben weiter unten in dieser Datei.
    $taskRun = '\"' + $powershell + '\" -NoProfile -ExecutionPolicy Bypass -File \"' + $watchdog + '\"'
    Ensure-ScheduledTaskFolder

    # BAS-002: Frueher wurde nur angelegt, wenn die Abfrage FEHLSCHLUG - also
    # wenn die Aufgabe fehlte. Eine vorhandene, aber deaktivierte Aufgabe
    # beantwortet die Abfrage erfolgreich, und danach wurde nie wieder etwas
    # repariert. /Create mit /F legt sie in beiden Faellen aktiviert neu an.
    $watchdogXml = (& $schtasks /Query /TN $script:WatchdogTaskName /XML ONE 2>$null | Out-String)
    if ($LASTEXITCODE -ne 0 -or -not (Test-ScheduledTaskXmlEnabled -TaskXml $watchdogXml)) {
        & $schtasks /Create /TN $script:WatchdogTaskName /SC MINUTE /MO 5 /RU SYSTEM /RL HIGHEST /TR $taskRun /F | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw "Die Purestate-Watchdog-Aufgabe konnte nicht registriert werden."
        }
    }

    $startupXml = (& $schtasks /Query /TN $script:StartupTaskName /XML ONE 2>$null | Out-String)
    if ($LASTEXITCODE -ne 0 -or -not (Test-ScheduledTaskXmlEnabled -TaskXml $startupXml)) {
        & $schtasks /Create /TN $script:StartupTaskName /SC ONSTART /DELAY 0000:20 /RU SYSTEM /RL HIGHEST /TR $taskRun /F | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw "Die Purestate-Startaufgabe konnte nicht registriert werden."
        }
    }
}

function Remove-ManagedCompanionPolicy {
    param([switch]$RequireComplete)

    foreach ($root in @(
        "HKLM:\SOFTWARE\Policies\Google\Chrome",
        "HKLM:\SOFTWARE\Policies\Microsoft\Edge"
    )) {
        $forceList = Join-Path $root "ExtensionInstallForcelist"
        Remove-ForcelistEntry -Path $forceList -Id $script:CompanionStoreId -RequireComplete:$RequireComplete

        $existingProp = Get-ItemProperty -LiteralPath $root -Name "ExtensionSettings" -ErrorAction SilentlyContinue
        if (-not $existingProp) {
            continue
        }

        $current = [string]$existingProp.ExtensionSettings
        $remaining = Remove-CompanionKeyFromJson -Json $current -Key $script:CompanionStoreId
        if ($null -eq $remaining) {
            continue
        }

        $trimmed = $remaining.Trim()
        if ($trimmed.Length -eq 0 -or $trimmed -eq "{}") {
            Remove-ItemProperty -LiteralPath $root -Name "ExtensionSettings" -ErrorAction $(if ($RequireComplete) { "Stop" } else { "SilentlyContinue" })
        } elseif ($trimmed -ne $current.Trim()) {
            New-ItemProperty -LiteralPath $root -Name "ExtensionSettings" -Value $trimmed -PropertyType String -Force | Out-Null
        }
    }
}

function Ensure-AppRegistration {
    try {
        $root = Get-AppRoot
        $app = Join-Path $root "Purestate.exe"
        $uninstaller = Join-Path $root "PurestateUninstaller.exe"
        if (-not (Test-Path -LiteralPath $app -PathType Leaf) -or -not (Test-Path -LiteralPath $uninstaller -PathType Leaf)) {
            return
        }

        $path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Purestate"
        Ensure-RegistryKey -Path $path
        New-ItemProperty -Path $path -Name "DisplayName" -Value "Purestate" -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $path -Name "DisplayVersion" -Value (Get-PurestateAppVersion) -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $path -Name "Publisher" -Value "Lokale Purestate-App" -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $path -Name "InstallLocation" -Value $root -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $path -Name "DisplayIcon" -Value ($app + ",0") -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $path -Name "UninstallString" -Value ('"' + $uninstaller + '"') -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $path -Name "NoRepair" -Value 1 -PropertyType DWord -Force | Out-Null
        New-ItemProperty -Path $path -Name "NoModify" -Value 1 -PropertyType DWord -Force | Out-Null
        New-ItemProperty -Path $path -Name "NoRemove" -Value 0 -PropertyType DWord -Force | Out-Null
        Remove-ItemProperty -Path $path -Name "ModifyPath" -ErrorAction SilentlyContinue
        Remove-ItemProperty -Path $path -Name "QuietUninstallString" -ErrorAction SilentlyContinue
    } catch {
        Add-AppLog "App registration protection failed: $($_.Exception.Message)"
    }
}

function Normalize-DnsProfile {
    param([string]$Profile)

    $value = ([string]$Profile).Trim().ToLowerInvariant()
    if ($value -eq "cleanbrowsing" -or $value -eq "cleanbrowsingfamily" -or $value -eq "cleanbrowsing family") {
        return "CleanBrowsingFamily"
    }

    if ($value -eq "opendns" -or $value -eq "opendnsfamily" -or $value -eq "opendnsfamilyshield" -or $value -eq "opendns familyshield") {
        return "OpenDnsFamilyShield"
    }

    return "CloudflareFamily"
}

function Get-DnsProfileLabel {
    param([string]$Profile)

    $normalized = Normalize-DnsProfile -Profile $Profile
    if ($normalized -eq "CleanBrowsingFamily") {
        return "CleanBrowsing Family"
    }

    if ($normalized -eq "OpenDnsFamilyShield") {
        return "OpenDNS FamilyShield"
    }

    return "Cloudflare Family"
}

function Get-FamilyDnsServers {
    param([string]$Profile)

    $normalized = Normalize-DnsProfile -Profile $Profile
    if ($normalized -eq "CleanBrowsingFamily") {
        return @("185.228.168.168", "185.228.169.168", "2a0d:2a00:1::", "2a0d:2a00:2::")
    }

    if ($normalized -eq "OpenDnsFamilyShield") {
        return @("208.67.222.123", "208.67.220.123", "2620:119:35::123", "2620:119:53::123")
    }

    return @("1.1.1.3", "1.0.0.3", "2606:4700:4700::1113", "2606:4700:4700::1003")
}

function Get-FamilyDnsIpv4Servers {
    param([string]$Profile)

    return @(Get-FamilyDnsServers -Profile $Profile | Where-Object { $_ -notmatch ":" })
}

function ConvertTo-PlainText {
    param([Security.SecureString]$SecureText)

    if ($null -eq $SecureText) {
        return ""
    }

    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureText)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
}

function Get-PasswordPolicyError {
    param(
        [string]$PlainText,
        [string]$Hint = ""
    )

    $value = [string]$PlainText
    if ($value.Length -lt $script:MinimumPasswordLength) {
        return $script:PasswordPolicyMessage
    }

    if ([string]::IsNullOrWhiteSpace($value) -or $value.Contains("`r") -or $value.Contains("`n")) {
        return "Das Passwort darf nicht leer sein und keine Zeilenumbrueche enthalten."
    }

    $hasLower = $false
    $hasUpper = $false
    $hasDigit = $false
    $hasSymbol = $false
    $allSame = $true
    $first = $value[0]
    foreach ($char in $value.ToCharArray()) {
        if ($char -ne $first) {
            $allSame = $false
        }
        if ([char]::IsLower($char)) {
            $hasLower = $true
        } elseif ([char]::IsUpper($char)) {
            $hasUpper = $true
        } elseif ([char]::IsDigit($char)) {
            $hasDigit = $true
        } else {
            $hasSymbol = $true
        }
    }

    if ($allSame) {
        return "Das Passwort darf nicht nur aus demselben Zeichen bestehen."
    }

    $categories = 0
    foreach ($flag in @($hasLower, $hasUpper, $hasDigit, $hasSymbol)) {
        if ($flag) { $categories++ }
    }
    if ($value.Length -lt $script:LongPassphraseLength -and $categories -lt 3) {
        return $script:PasswordPolicyMessage
    }

    $lowered = $value.ToLowerInvariant()
    if ($lowered.Contains("purestate") -or $lowered.Contains("password") -or $lowered.Contains("passwort")) {
        return "Das Passwort darf keine offensichtlichen Produkt- oder Passwortbegriffe enthalten."
    }

    $cleanHint = ([string]$Hint).Replace("`r", " ").Replace("`n", " ").Trim()
    while ($cleanHint.Contains("  ")) {
        $cleanHint = $cleanHint.Replace("  ", " ")
    }
    if ($cleanHint.Length -gt 0 -and $cleanHint.ToLowerInvariant().Contains($lowered)) {
        return "Der Passworthinweis darf das Passwort nicht enthalten."
    }

    return ""
}

function Assert-PasswordPolicy {
    param(
        [string]$PlainText,
        [string]$Hint = ""
    )

    $errorText = Get-PasswordPolicyError -PlainText $PlainText -Hint $Hint
    if (-not [string]::IsNullOrWhiteSpace($errorText)) {
        throw $errorText
    }
}

function New-PasswordRecord {
    param([string]$PlainText)

    Assert-PasswordPolicy -PlainText $PlainText

    $salt = New-Object byte[] 16
    $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
    $rng.GetBytes($salt)
    $rng.Dispose()

    $iterations = 180000
    $algorithm = "PBKDF2-SHA256"

    try {
        $derive = New-Object System.Security.Cryptography.Rfc2898DeriveBytes(
            $PlainText,
            $salt,
            $iterations,
            [System.Security.Cryptography.HashAlgorithmName]::SHA256
        )
    } catch {
        throw "PBKDF2-SHA256 is required for new Purestate password records. This Windows/.NET runtime does not expose the SHA256 Rfc2898DeriveBytes constructor."
    }

    try {
        $hash = $derive.GetBytes(32)
    } finally {
        $derive.Dispose()
    }

    return [pscustomobject]@{
        Algorithm = $algorithm
        Iterations = $iterations
        Salt = [Convert]::ToBase64String($salt)
        Hash = [Convert]::ToBase64String($hash)
    }
}

function Test-PasswordRecord {
    param(
        [pscustomobject]$Record,
        [string]$PlainText
    )

    if ($null -eq $Record) {
        return $false
    }

    $salt = [Convert]::FromBase64String($Record.Salt)
    $expected = [Convert]::FromBase64String($Record.Hash)
    $iterations = [int]$Record.Iterations

    if ($Record.Algorithm -eq "PBKDF2-SHA256") {
        $derive = New-Object System.Security.Cryptography.Rfc2898DeriveBytes(
            $PlainText,
            $salt,
            $iterations,
            [System.Security.Cryptography.HashAlgorithmName]::SHA256
        )
    } elseif ($Record.Algorithm -eq "PBKDF2-SHA1") {
        $derive = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($PlainText, $salt, $iterations)
    } else {
        return $false
    }

    try {
        $actual = $derive.GetBytes($expected.Length)
    } finally {
        $derive.Dispose()
    }

    if ($actual.Length -ne $expected.Length) {
        return $false
    }

    $diff = 0
    for ($i = 0; $i -lt $actual.Length; $i++) {
        $diff = $diff -bor ($actual[$i] -bxor $expected[$i])
    }

    return ($diff -eq 0)
}

function ConvertTo-IntegritySchemaVersion {
    param($Value)

    if ($null -eq $Value) {
        return 0
    }

    $typeCode = [Type]::GetTypeCode($Value.GetType())
    if ($typeCode -notin @(
        [TypeCode]::Byte,
        [TypeCode]::SByte,
        [TypeCode]::Int16,
        [TypeCode]::UInt16,
        [TypeCode]::Int32,
        [TypeCode]::UInt32,
        [TypeCode]::Int64,
        [TypeCode]::UInt64
    )) {
        return 0
    }

    $schemaVersion = 0
    $text = [Convert]::ToString($Value, [Globalization.CultureInfo]::InvariantCulture)
    if ([int]::TryParse(
        $text,
        [Globalization.NumberStyles]::None,
        [Globalization.CultureInfo]::InvariantCulture,
        [ref]$schemaVersion
    )) {
        return $schemaVersion
    }

    return 0
}

function Get-Config {
    Assert-DataDirectoryIsNotReparsePoint
    if (-not (Test-Path -LiteralPath $script:ConfigPath)) {
        return [pscustomobject]@{
            ProtectionEnabled = $true
            HostsEnabled = $true
            FamilyDnsEnabled = $true
            DnsProfile = $script:DefaultDnsProfile
            BrowserPoliciesEnabled = $true
            BypassBlockingEnabled = $true
            UnsupportedBrowserBlockingEnabled = $true
            TamperProtectionEnabled = $true
            # Vorgabe seit 2026-08-09 aus, siehe src\NativeSupport.cs. Die
            # Migration weiter unten setzt fuer Konfigurationen ohne den
            # Schluessel weiterhin $true - ein Update darf Schutz nicht still
            # abbauen.
            YouTubeRestrictEnabled = $false
            # Vorgabe false = bisheriges Modell (Liste haengt an der
            # Sperrliste, unabhaengig vom Schutzbereich). Siehe
            # src\NativeSupport.cs; Get-DomainList liest es seit c184009.
            AdultHostsFollowArea = $false
            SiteRedditEnabled = $true
            SiteXEnabled = $true
            SiteBlueskyEnabled = $true
            SiteTumblrEnabled = $true
            SiteDeviantArtEnabled = $true
            SitePixivEnabled = $true
            SiteNewgroundsEnabled = $true
            SiteImgurEnabled = $true
            SiteInstagramEnabled = $true
            SiteTikTokEnabled = $true
            SitePinterestEnabled = $true
            AdultContentProtectionEnabled = $true
            AdultContentProtectionMode = "strict"
            GamblingProtectionEnabled = $false
            GamblingProtectionMode = "off"
            ShoppingProtectionEnabled = $false
            ShoppingProtectionMode = "planned"
            ShoppingDelayDefaultMinutes = 10
            ShoppingCheckoutDelayEnabled = $true
            ShoppingStimulusDampingEnabled = $true
            ShoppingDealSearchBlockEnabled = $true
            ShoppingCurfewEnabled = $true
            ShoppingCurfewStart = "22:00"
            ShoppingCurfewEnd = "06:00"
            ShoppingDailyLimitEnabled = $true
            ShoppingDailyLimitMinutes = 30
            ShoppingMonthlyOrderLimitEnabled = $true
            ShoppingMonthlyOrderLimit = 10
            ShoppingMonthlyBudgetEnabled = $false
            ShoppingMonthlyBudgetEuro = 200
            GamblingDailyLimitEnabled = $true
            GamblingDailyLimitMinutes = 15
            SocialMediaDailyBudgetEnabled = $false
            SocialMediaDailyBudgetMinutes = 60
            SocialMediaPlatformLimits = ""
            SocialMediaBlockedPlatforms = ""
            SocialMediaFeedBlockedPlatforms = ""
            SocialMediaCurfewEnabled = $false
            SocialMediaCurfewStart = "22:00"
            SocialMediaCurfewEnd = "06:00"
            SocialMediaReflectionEnabled = $true
            SocialMediaFeedDampingEnabled = $true
            SocialMediaFeedDampingScrolls = 50
            VideoGamesProtectionEnabled = $false
            VideoGamesProtectionMode = "planned"
            VideoGamesDailyLimitEnabled = $false
            VideoGamesDailyLimitMinutes = 60
            VideoGamesCurfewEnabled = $false
            VideoGamesCurfewStart = "22:00"
            VideoGamesCurfewEnd = "06:00"
            VideoGamesAutoDetectEnabled = $false
            VideoGamesHeuristicEnabled = $false
            SocialMediaProtectionEnabled = $false
            SocialMediaProtectionMode = "planned"
            ProtectionAreaRulePackVersion = "1"
            GamblingSupportEnabled = $false
            GamblingSupportMode = "off"
            LockdownModeEnabled = $true
            PauseCooldownEnabled = $true
            PendingPauseUntilUtc = ""
            ScheduleEnabled = $false
            StrictModeEnabled = $false
            ScheduleStart = "22:00"
            ScheduleEnd = "06:00"
            PauseUntilUtc = ""
            PendingUninstallUntilUtc = ""
            UninstallApprovalExpiresUtc = ""
            PasswordHint = ""
            PasswordFailedAttempts = 0
            PasswordLockoutUntilUtc = ""
            InstalledVersion = ""
            WeakeningRequestedUtc = ""
            AuthorityMode = "local"
            PolicyVersion = 0
            WeakeningGrant = ""
            GrantSignature = ""
            EntitledUntilUtc = ""
            EntitlementSignature = ""
            EntitlementMaxDevices = 0
            CompanionGrace = ""
            ClockAnchorUtc = ""
            ClockTickAnchorMs = 0
            IntegritySchemaVersion = 0
            Integrity = ""
            Password = $null
        }
    }

    $rawJson = Get-Content -LiteralPath $script:ConfigPath -Raw
    try {
        $hasDuplicateProperty = Test-DuplicateTopLevelJsonProperty -Json $rawJson
    } catch {
        return New-CompromisedConfig -Reason "malformed config JSON"
    }

    if ($hasDuplicateProperty) {
        return New-CompromisedConfig -Reason "duplicate top-level config property"
    }

    try {
        $config = $rawJson | ConvertFrom-Json -ErrorAction Stop
    } catch {
        return New-CompromisedConfig -Reason "malformed config JSON"
    }
    $rawPropertyNames = @($config.PSObject.Properties | ForEach-Object { [string]$_.Name })
    Ensure-ConfigShape -Config $config
    Assert-ConfigIntegrity -Config $config -RawPropertyNames $rawPropertyNames
    return $config
}

function New-CompromisedConfig {
    param([string]$Reason)

    $config = [pscustomobject]@{}
    Ensure-ConfigShape -Config $config
    Set-SafeProtection -Config $config
    $config | Add-Member -NotePropertyName IntegrityCompromised -NotePropertyValue $true
    Add-SecurityLog ("Config integrity check failed - " + $Reason + ". Forcing full protection; password refused until reinstall.")
    return $config
}

function Test-DuplicateTopLevelJsonProperty {
    param([string]$Json)

    if ([string]::IsNullOrEmpty($Json)) {
        return $false
    }

    $propertyNames = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    $depth = 0
    for ($index = 0; $index -lt $Json.Length; $index++) {
        $current = $Json[$index]
        if ($current -eq '"') {
            $stringStart = $index
            $escaped = $false
            $index++
            while ($index -lt $Json.Length) {
                $current = $Json[$index]
                if ($escaped) {
                    $escaped = $false
                } elseif ($current -eq '\') {
                    $escaped = $true
                } elseif ($current -eq '"') {
                    break
                }
                $index++
            }

            if ($index -ge $Json.Length) {
                throw "Malformed JSON string."
            }

            if ($depth -ne 1) {
                continue
            }

            $separator = $index + 1
            while ($separator -lt $Json.Length -and [char]::IsWhiteSpace($Json[$separator])) {
                $separator++
            }
            if ($separator -ge $Json.Length -or $Json[$separator] -ne ':') {
                continue
            }

            try {
                $propertyName = [string]($Json.Substring($stringStart, $index - $stringStart + 1) | ConvertFrom-Json -ErrorAction Stop)
            } catch {
                throw "Malformed JSON property name."
            }
            if (-not $propertyNames.Add($propertyName)) {
                return $true
            }
            continue
        }

        if ($current -eq '{' -or $current -eq '[') {
            $depth++
        } elseif ($current -eq '}' -or $current -eq ']') {
            $depth--
            if ($depth -lt 0) {
                throw "Malformed JSON nesting."
            }
        }
    }

    if ($depth -ne 0) {
        throw "Malformed JSON nesting."
    }
    return $false
}

function Ensure-ConfigShape {
    param([pscustomobject]$Config)

    if ($null -eq $Config.PSObject.Properties["ProtectionEnabled"]) {
        $Config | Add-Member -NotePropertyName ProtectionEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["HostsEnabled"]) {
        $Config | Add-Member -NotePropertyName HostsEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["FamilyDnsEnabled"]) {
        $Config | Add-Member -NotePropertyName FamilyDnsEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["DnsProfile"]) {
        $Config | Add-Member -NotePropertyName DnsProfile -NotePropertyValue $script:DefaultDnsProfile
    } else {
        $Config.DnsProfile = Normalize-DnsProfile -Profile $Config.DnsProfile
    }

    if ($null -eq $Config.PSObject.Properties["BrowserPoliciesEnabled"]) {
        $Config | Add-Member -NotePropertyName BrowserPoliciesEnabled -NotePropertyValue $true
    } else {
        $Config.BrowserPoliciesEnabled = $true
    }

    if ($null -eq $Config.PSObject.Properties["BypassBlockingEnabled"]) {
        $Config | Add-Member -NotePropertyName BypassBlockingEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["UnsupportedBrowserBlockingEnabled"]) {
        $Config | Add-Member -NotePropertyName UnsupportedBrowserBlockingEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["TamperProtectionEnabled"]) {
        $Config | Add-Member -NotePropertyName TamperProtectionEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["YouTubeRestrictEnabled"]) {
        $Config | Add-Member -NotePropertyName YouTubeRestrictEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["AdultHostsFollowArea"]) {
        $Config | Add-Member -NotePropertyName AdultHostsFollowArea -NotePropertyValue $false
    }

    foreach ($propertyName in @(
        "SiteRedditEnabled",
        "SiteXEnabled",
        "SiteBlueskyEnabled",
        "SiteTumblrEnabled",
        "SiteDeviantArtEnabled",
        "SitePixivEnabled",
        "SiteNewgroundsEnabled",
        "SiteImgurEnabled",
        "SiteInstagramEnabled",
        "SiteTikTokEnabled",
        "SitePinterestEnabled"
    )) {
        if ($null -eq $Config.PSObject.Properties[$propertyName]) {
            $Config | Add-Member -NotePropertyName $propertyName -NotePropertyValue $true
        }
    }

    if ($null -eq $Config.PSObject.Properties["AdultContentProtectionEnabled"]) {
        $Config | Add-Member -NotePropertyName AdultContentProtectionEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["AdultContentProtectionMode"]) {
        $Config | Add-Member -NotePropertyName AdultContentProtectionMode -NotePropertyValue "strict"
    } elseif ($Config.AdultContentProtectionMode -notin @("off", "planned", "gentle", "strict")) {
        $Config.AdultContentProtectionMode = "strict"
    }

    # SHP-003: Der Support-Block steht vor dem Protection-Block, weil dessen
    # Vorgabe aus GamblingSupportEnabled abgeleitet wird.
    if ($null -eq $Config.PSObject.Properties["GamblingSupportEnabled"]) {
        $Config | Add-Member -NotePropertyName GamblingSupportEnabled -NotePropertyValue $false
    }

    if ($null -eq $Config.PSObject.Properties["GamblingSupportMode"]) {
        $Config | Add-Member -NotePropertyName GamblingSupportMode -NotePropertyValue "off"
    } elseif (-not ($Config.GamblingSupportMode -in @("off", "gentle", "strict"))) {
        $Config.GamblingSupportMode = if ([bool]$Config.GamblingSupportEnabled) { "gentle" } else { "off" }
    }

    if ($null -eq $Config.PSObject.Properties["GamblingProtectionEnabled"]) {
        $Config | Add-Member -NotePropertyName GamblingProtectionEnabled -NotePropertyValue ([bool]$Config.GamblingSupportEnabled)
    }

    if ($null -eq $Config.PSObject.Properties["GamblingProtectionMode"]) {
        $Config | Add-Member -NotePropertyName GamblingProtectionMode -NotePropertyValue ($(if ([bool]$Config.GamblingProtectionEnabled) { "strict" } else { "off" }))
    } elseif ($Config.GamblingProtectionMode -notin @("off", "planned", "gentle", "strict")) {
        $Config.GamblingProtectionMode = if ([bool]$Config.GamblingProtectionEnabled) { "strict" } else { "off" }
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingProtectionEnabled"]) {
        $Config | Add-Member -NotePropertyName ShoppingProtectionEnabled -NotePropertyValue $false
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingProtectionMode"]) {
        $Config | Add-Member -NotePropertyName ShoppingProtectionMode -NotePropertyValue "planned"
    } elseif ($Config.ShoppingProtectionMode -notin @("off", "planned", "gentle", "strict")) {
        $Config.ShoppingProtectionMode = "planned"
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingDelayDefaultMinutes"]) {
        $Config | Add-Member -NotePropertyName ShoppingDelayDefaultMinutes -NotePropertyValue 10
    } else {
        $delay = [int]$Config.ShoppingDelayDefaultMinutes
        if ($delay -notin @(2, 5, 10, 15)) {
            $delay = 10
        }
        $Config.ShoppingDelayDefaultMinutes = $delay
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingCheckoutDelayEnabled"]) {
        $Config | Add-Member -NotePropertyName ShoppingCheckoutDelayEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingStimulusDampingEnabled"]) {
        $Config | Add-Member -NotePropertyName ShoppingStimulusDampingEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingDealSearchBlockEnabled"]) {
        $Config | Add-Member -NotePropertyName ShoppingDealSearchBlockEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingCurfewEnabled"]) {
        $Config | Add-Member -NotePropertyName ShoppingCurfewEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingCurfewStart"]) {
        $Config | Add-Member -NotePropertyName ShoppingCurfewStart -NotePropertyValue "22:00"
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingCurfewEnd"]) {
        $Config | Add-Member -NotePropertyName ShoppingCurfewEnd -NotePropertyValue "06:00"
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingDailyLimitEnabled"]) {
        $Config | Add-Member -NotePropertyName ShoppingDailyLimitEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingDailyLimitMinutes"]) {
        $Config | Add-Member -NotePropertyName ShoppingDailyLimitMinutes -NotePropertyValue 30
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingMonthlyOrderLimitEnabled"]) {
        $Config | Add-Member -NotePropertyName ShoppingMonthlyOrderLimitEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingMonthlyOrderLimit"]) {
        $Config | Add-Member -NotePropertyName ShoppingMonthlyOrderLimit -NotePropertyValue 10
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingMonthlyBudgetEnabled"]) {
        $Config | Add-Member -NotePropertyName ShoppingMonthlyBudgetEnabled -NotePropertyValue $false
    }

    if ($null -eq $Config.PSObject.Properties["ShoppingMonthlyBudgetEuro"]) {
        $Config | Add-Member -NotePropertyName ShoppingMonthlyBudgetEuro -NotePropertyValue 200
    }

    if ($null -eq $Config.PSObject.Properties["GamblingDailyLimitEnabled"]) {
        $Config | Add-Member -NotePropertyName GamblingDailyLimitEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["GamblingDailyLimitMinutes"]) {
        $Config | Add-Member -NotePropertyName GamblingDailyLimitMinutes -NotePropertyValue 15
    }

    if ($null -eq $Config.PSObject.Properties["SocialMediaDailyBudgetEnabled"]) {
        $Config | Add-Member -NotePropertyName SocialMediaDailyBudgetEnabled -NotePropertyValue $false
    }

    if ($null -eq $Config.PSObject.Properties["SocialMediaDailyBudgetMinutes"]) {
        $Config | Add-Member -NotePropertyName SocialMediaDailyBudgetMinutes -NotePropertyValue 60
    }

    if ($null -eq $Config.PSObject.Properties["SocialMediaPlatformLimits"]) {
        $Config | Add-Member -NotePropertyName SocialMediaPlatformLimits -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["SocialMediaBlockedPlatforms"]) {
        $Config | Add-Member -NotePropertyName SocialMediaBlockedPlatforms -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["SocialMediaFeedBlockedPlatforms"]) {
        $Config | Add-Member -NotePropertyName SocialMediaFeedBlockedPlatforms -NotePropertyValue ""
    } else {
        $Config.SocialMediaFeedBlockedPlatforms = Get-NormalizedSocialMediaFeedBlockedPlatforms `
            -FeedCsv ([string]$Config.SocialMediaFeedBlockedPlatforms) `
            -BlockedCsv ([string]$Config.SocialMediaBlockedPlatforms)
    }

    if ($null -eq $Config.PSObject.Properties["SocialMediaCurfewEnabled"]) {
        $Config | Add-Member -NotePropertyName SocialMediaCurfewEnabled -NotePropertyValue $false
    }

    if ($null -eq $Config.PSObject.Properties["SocialMediaCurfewStart"]) {
        $Config | Add-Member -NotePropertyName SocialMediaCurfewStart -NotePropertyValue "22:00"
    }

    if ($null -eq $Config.PSObject.Properties["SocialMediaCurfewEnd"]) {
        $Config | Add-Member -NotePropertyName SocialMediaCurfewEnd -NotePropertyValue "06:00"
    }

    if ($null -eq $Config.PSObject.Properties["SocialMediaReflectionEnabled"]) {
        $Config | Add-Member -NotePropertyName SocialMediaReflectionEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["SocialMediaFeedDampingEnabled"]) {
        $Config | Add-Member -NotePropertyName SocialMediaFeedDampingEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["SocialMediaFeedDampingScrolls"]) {
        $Config | Add-Member -NotePropertyName SocialMediaFeedDampingScrolls -NotePropertyValue 50
    }

    if ($null -eq $Config.PSObject.Properties["VideoGamesProtectionEnabled"]) {
        $Config | Add-Member -NotePropertyName VideoGamesProtectionEnabled -NotePropertyValue $false
    }

    if ($null -eq $Config.PSObject.Properties["VideoGamesProtectionMode"]) {
        $Config | Add-Member -NotePropertyName VideoGamesProtectionMode -NotePropertyValue "planned"
    } elseif ($Config.VideoGamesProtectionMode -notin @("off", "planned", "gentle", "strict")) {
        $Config.VideoGamesProtectionMode = "planned"
    }

    if ($null -eq $Config.PSObject.Properties["VideoGamesDailyLimitEnabled"]) {
        $Config | Add-Member -NotePropertyName VideoGamesDailyLimitEnabled -NotePropertyValue $false
    }

    if ($null -eq $Config.PSObject.Properties["VideoGamesDailyLimitMinutes"]) {
        $Config | Add-Member -NotePropertyName VideoGamesDailyLimitMinutes -NotePropertyValue 60
    } else {
        $videoGamesMinutes = 0
        if (-not [int]::TryParse([string]$Config.VideoGamesDailyLimitMinutes, [ref]$videoGamesMinutes) -or
            $videoGamesMinutes -lt 5 -or $videoGamesMinutes -gt 600) {
            $videoGamesMinutes = 60
        }
        $Config.VideoGamesDailyLimitMinutes = $videoGamesMinutes
    }

    if ($null -eq $Config.PSObject.Properties["VideoGamesCurfewEnabled"]) {
        $Config | Add-Member -NotePropertyName VideoGamesCurfewEnabled -NotePropertyValue $false
    }

    if ($null -eq $Config.PSObject.Properties["VideoGamesCurfewStart"]) {
        $Config | Add-Member -NotePropertyName VideoGamesCurfewStart -NotePropertyValue "22:00"
    }

    if ($null -eq $Config.PSObject.Properties["VideoGamesCurfewEnd"]) {
        $Config | Add-Member -NotePropertyName VideoGamesCurfewEnd -NotePropertyValue "06:00"
    }

    if ($null -eq $Config.PSObject.Properties["VideoGamesAutoDetectEnabled"]) {
        $Config | Add-Member -NotePropertyName VideoGamesAutoDetectEnabled -NotePropertyValue $false
    }

    if ($null -eq $Config.PSObject.Properties["VideoGamesHeuristicEnabled"]) {
        $Config | Add-Member -NotePropertyName VideoGamesHeuristicEnabled -NotePropertyValue $false
    }

    if ($null -eq $Config.PSObject.Properties["SocialMediaProtectionEnabled"]) {
        $Config | Add-Member -NotePropertyName SocialMediaProtectionEnabled -NotePropertyValue $false
    }

    if ($null -eq $Config.PSObject.Properties["SocialMediaProtectionMode"]) {
        $Config | Add-Member -NotePropertyName SocialMediaProtectionMode -NotePropertyValue "planned"
    } elseif ($Config.SocialMediaProtectionMode -notin @("off", "planned", "gentle", "strict")) {
        $Config.SocialMediaProtectionMode = "planned"
    }

    if ($null -eq $Config.PSObject.Properties["ProtectionAreaRulePackVersion"]) {
        $Config | Add-Member -NotePropertyName ProtectionAreaRulePackVersion -NotePropertyValue "1"
    } elseif ([string]::IsNullOrWhiteSpace([string]$Config.ProtectionAreaRulePackVersion)) {
        $Config.ProtectionAreaRulePackVersion = "1"
    }

    if ($null -eq $Config.PSObject.Properties["LockdownModeEnabled"]) {
        $Config | Add-Member -NotePropertyName LockdownModeEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["PauseCooldownEnabled"]) {
        $Config | Add-Member -NotePropertyName PauseCooldownEnabled -NotePropertyValue $true
    }

    if ($null -eq $Config.PSObject.Properties["PendingPauseUntilUtc"]) {
        $Config | Add-Member -NotePropertyName PendingPauseUntilUtc -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["ScheduleEnabled"]) {
        $Config | Add-Member -NotePropertyName ScheduleEnabled -NotePropertyValue $false
    }

    if ($null -eq $Config.PSObject.Properties["StrictModeEnabled"]) {
        $Config | Add-Member -NotePropertyName StrictModeEnabled -NotePropertyValue $false
    }

    if ($null -eq $Config.PSObject.Properties["ScheduleStart"]) {
        $Config | Add-Member -NotePropertyName ScheduleStart -NotePropertyValue "22:00"
    }

    if ($null -eq $Config.PSObject.Properties["ScheduleEnd"]) {
        $Config | Add-Member -NotePropertyName ScheduleEnd -NotePropertyValue "06:00"
    }

    if ($null -eq $Config.PSObject.Properties["PauseUntilUtc"]) {
        $Config | Add-Member -NotePropertyName PauseUntilUtc -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["PendingUninstallUntilUtc"]) {
        $Config | Add-Member -NotePropertyName PendingUninstallUntilUtc -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["UninstallApprovalExpiresUtc"]) {
        $Config | Add-Member -NotePropertyName UninstallApprovalExpiresUtc -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["PasswordHint"]) {
        $Config | Add-Member -NotePropertyName PasswordHint -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["PasswordFailedAttempts"]) {
        $Config | Add-Member -NotePropertyName PasswordFailedAttempts -NotePropertyValue 0
    }

    if ($null -eq $Config.PSObject.Properties["PasswordLockoutUntilUtc"]) {
        $Config | Add-Member -NotePropertyName PasswordLockoutUntilUtc -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["InstalledVersion"]) {
        $Config | Add-Member -NotePropertyName InstalledVersion -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["WeakeningRequestedUtc"]) {
        $Config | Add-Member -NotePropertyName WeakeningRequestedUtc -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["AuthorityMode"]) {
        $Config | Add-Member -NotePropertyName AuthorityMode -NotePropertyValue "local"
    }

    if ($null -eq $Config.PSObject.Properties["PolicyVersion"]) {
        $Config | Add-Member -NotePropertyName PolicyVersion -NotePropertyValue 0
    }

    if ($null -eq $Config.PSObject.Properties["WeakeningGrant"]) {
        $Config | Add-Member -NotePropertyName WeakeningGrant -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["GrantSignature"]) {
        $Config | Add-Member -NotePropertyName GrantSignature -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["EntitledUntilUtc"]) {
        $Config | Add-Member -NotePropertyName EntitledUntilUtc -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["EntitlementSignature"]) {
        $Config | Add-Member -NotePropertyName EntitlementSignature -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["EntitlementMaxDevices"]) {
        $Config | Add-Member -NotePropertyName EntitlementMaxDevices -NotePropertyValue 0
    }

    if ($null -eq $Config.PSObject.Properties["CompanionGrace"]) {
        $Config | Add-Member -NotePropertyName CompanionGrace -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["ClockAnchorUtc"]) {
        $Config | Add-Member -NotePropertyName ClockAnchorUtc -NotePropertyValue ""
    }

    if ($null -eq $Config.PSObject.Properties["ClockTickAnchorMs"]) {
        $Config | Add-Member -NotePropertyName ClockTickAnchorMs -NotePropertyValue 0
    }

    if ($null -eq $Config.PSObject.Properties["IntegritySchemaVersion"]) {
        $Config | Add-Member -NotePropertyName IntegritySchemaVersion -NotePropertyValue 0
    } else {
        $Config.IntegritySchemaVersion = ConvertTo-IntegritySchemaVersion -Value $Config.IntegritySchemaVersion
    }

    if ($null -eq $Config.PSObject.Properties["Integrity"]) {
        $Config | Add-Member -NotePropertyName Integrity -NotePropertyValue ""
    }
}

function Invoke-WithConfigLock {
    param([scriptblock]$ScriptBlock)

    $mutex = New-ConfigMutex
    $locked = $false
    try {
        try {
            $locked = $mutex.WaitOne(10000)
        } catch [System.Threading.AbandonedMutexException] {
            $locked = $true
        }

        if (-not $locked) {
            throw "Die Purestate-Konfiguration ist gerade durch einen anderen Vorgang gesperrt."
        }

        & $ScriptBlock
    } finally {
        if ($locked) {
            $mutex.ReleaseMutex()
        }
        $mutex.Dispose()
    }
}

function New-ConfigMutex {
    $name = "Global\PurestateConfig"
    $createdNew = $false
    try {
        $security = New-Object System.Security.AccessControl.MutexSecurity
        $security.AddAccessRule((New-Object System.Security.AccessControl.MutexAccessRule(
            (New-Object System.Security.Principal.SecurityIdentifier([System.Security.Principal.WellKnownSidType]::LocalSystemSid, $null)),
            [System.Security.AccessControl.MutexRights]::FullControl,
            [System.Security.AccessControl.AccessControlType]::Allow
        )))
        $security.AddAccessRule((New-Object System.Security.AccessControl.MutexAccessRule(
            (New-Object System.Security.Principal.SecurityIdentifier([System.Security.Principal.WellKnownSidType]::BuiltinAdministratorsSid, $null)),
            [System.Security.AccessControl.MutexRights]::FullControl,
            [System.Security.AccessControl.AccessControlType]::Allow
        )))
        return New-Object System.Threading.Mutex($false, $name, [ref]$createdNew, $security)
    } catch [System.UnauthorizedAccessException] {
        return [System.Threading.Mutex]::OpenExisting(
            $name,
            [System.Security.AccessControl.MutexRights]::Synchronize -bor [System.Security.AccessControl.MutexRights]::Modify
        )
    }
}

# Spiegelt Support.WriteAllTextDurable aus src\NativeSupport.cs. Set-Content und
# File.WriteAllText legen den Inhalt nur im Dateisystem-Cache ab; nach einem
# unsauberen Herunterfahren behaelt die Datei ihre Groesse und verliert ihren
# Inhalt. Live gesehen am 2026-08-04: integrity.key und dns-backup.json
# bestanden nur noch aus NUL-Bytes, die signierte Config galt als kompromittiert
# und alle Einstellungen waren verloren.
function Set-DurableFileText {
    param(
        [string]$Path,
        [string]$Value
    )

    $encoding = New-Object System.Text.UTF8Encoding($false)
    $bytes = $encoding.GetBytes([string]$Value)
    $stream = New-Object System.IO.FileStream(
        [System.IO.Path]::GetFullPath($Path),
        [System.IO.FileMode]::Create,
        [System.IO.FileAccess]::Write,
        [System.IO.FileShare]::None)
    try {
        $stream.Write($bytes, 0, $bytes.Length)
        # $true = FlushFileBuffers, nicht nur der verwaltete Puffer.
        $stream.Flush($true)
    } finally {
        $stream.Dispose()
    }
}

function Set-TextFileAtomically {
    param(
        [string]$Path,
        [string]$Value
    )

    Assert-DataDirectoryIsNotReparsePoint
    $fullPath = [System.IO.Path]::GetFullPath($Path)
    $directory = [System.IO.Path]::GetDirectoryName($fullPath)
    if (-not [System.IO.Directory]::Exists($directory)) {
        [System.IO.Directory]::CreateDirectory($directory) | Out-Null
    }

    $tempPath = Join-Path $directory ("config." + [guid]::NewGuid().ToString("N") + ".tmp")
    try {
        Set-DurableFileText -Path $tempPath -Value $Value
        if ([System.IO.File]::Exists($fullPath)) {
            # PowerShell 5.1 marshals $null string arguments as "" which makes
            # File.Replace throw "invalid path format"; NullString passes a
            # real null (no backup file).
            [System.IO.File]::Replace($tempPath, $fullPath, [NullString]::Value, $true)
        } else {
            [System.IO.File]::Move($tempPath, $fullPath)
        }
    } catch {
        try {
            if ([System.IO.File]::Exists($tempPath)) {
                [System.IO.File]::Delete($tempPath)
            }
        } catch {
        }
        throw
    }
}

function ConvertTo-CanonicalBool {
    param($Value)
    if ([bool]$Value) { return "true" } else { return "false" }
}

function Get-EffectiveGamblingProtectionEnabled {
    param([pscustomobject]$Config)

    if ($null -eq $Config) {
        return $false
    }

    return ([bool]$Config.GamblingProtectionEnabled) -or ([bool]$Config.GamblingSupportEnabled)
}

function Get-EffectiveGamblingProtectionMode {
    param([pscustomobject]$Config)

    if (Get-EffectiveGamblingProtectionEnabled -Config $Config) {
        return "strict"
    }

    return "off"
}

function Normalize-GamblingProtectionState {
    param([pscustomobject]$Config)

    if ($null -eq $Config) {
        return
    }

    $Config.GamblingProtectionEnabled = Get-EffectiveGamblingProtectionEnabled -Config $Config
    $Config.GamblingProtectionMode = Get-EffectiveGamblingProtectionMode -Config $Config
    $Config.GamblingSupportEnabled = [bool]$Config.GamblingProtectionEnabled
    $Config.GamblingSupportMode = [string]$Config.GamblingProtectionMode
}

# Shopping and social media are friction areas: nothing anywhere enforces a
# strict gate for them, so their honest mode domain is off/planned/gentle and
# "strict" clamps to "gentle". Write/display paths only - a read clamp would
# flip the canonical text of legacy configs that carry a SIGNED "strict" into
# an integrity failure. C# mirror: NormalizeSoftProtectionAreaMode (pinned).
function Get-NormalizedSoftProtectionAreaMode {
    param(
        [string]$Mode,
        [string]$Fallback
    )

    $value = ([string]$Mode).Trim().ToLowerInvariant()
    if ($value -eq "strict") { return "gentle" }
    if ($value -in @("off", "planned", "gentle")) { return $value }
    $safe = ([string]$Fallback).Trim().ToLowerInvariant()
    if ($safe -eq "strict") { return "gentle" }
    if ($safe -in @("off", "planned", "gentle")) { return $safe }
    return "off"
}

function Test-ProtectionAreaEnabled {
    param([ValidateSet("adult-content", "gambling", "shopping", "video-games", "social-media")][string]$Area)

    $config = Get-Config
    switch ($Area) {
        "adult-content" {
            return [bool]$config.AdultContentProtectionEnabled -and [string]$config.AdultContentProtectionMode -eq "strict"
        }
        "gambling" {
            return (Get-EffectiveGamblingProtectionEnabled -Config $config) -and
                (Get-EffectiveGamblingProtectionMode -Config $config) -eq "strict"
        }
        "shopping" {
            return [bool]$config.ShoppingProtectionEnabled -and [string]$config.ShoppingProtectionMode -eq "strict"
        }
        "video-games" {
            return [bool]$config.VideoGamesProtectionEnabled -and [string]$config.VideoGamesProtectionMode -eq "strict"
        }
        "social-media" {
            return [bool]$config.SocialMediaProtectionEnabled -and [string]$config.SocialMediaProtectionMode -eq "strict"
        }
    }

    return $false
}

# Byte-for-byte identical to BuildConfigCanonical in src\NativeSupportLogic.cs:
# every line is "Key=Value" followed by a single LF (0x0A). Built with a
# StringBuilder and explicit [char]10 - NOT a multi-line "@(...) -join" - because
# a multi-line array literal whose elements mix "+" concatenation and "$(if...)"
# subexpressions collapses to a single space-joined string in Windows
# PowerShell, which silently swapped the LF separators for spaces. A
# cross-language oracle test (tests\Purestate.Tests.ps1 vs. PurestateLogicTests.cs)
# pins the exact HMAC on both sides so any drift breaks a test instead of
# force-enabling protection at runtime.
# Reihenfolge und Inhalt wie SocialMediaPlatformIds in
# src\NativeSupportConfig.cs - sie bestimmt die kanonische Form der beiden
# Plattformlisten.
$script:SocialMediaPlatformIds = @("x", "instagram", "tiktok", "pinterest", "tumblr", "bluesky", "reddit", "youtube", "streaming")

# Plattformen mit eigenem Zeitbudget (Streaming, Tester-Notiz 2026-10-06): ihre
# Zeit zaehlt nicht ins gemeinsame Social-Media-Limit, und ein eigenes Limit
# darf das gemeinsame Budget uebersteigen. Spiegelt
# Support.SocialMediaOwnBudgetPlatformIds in src\NativeSupportConfig.cs.
$script:SocialMediaOwnBudgetPlatformIds = @("streaming")

# SHP-001: C# normalisiert beim LESEN praktisch jedes Feld, Ensure-ConfigShape
# nur dort, wo jemand einen else-Zweig ergaenzt hat. Der HMAC laeuft in beiden
# Sprachen ueber die geformten Werte - fuer dieselbe Datei kamen damit zwei
# verschiedene Signaturen heraus, sobald ein Wert ausserhalb seines Bereichs
# lag, und der Prozess mit der abweichenden Rechnung erklaert die
# Konfiguration fuer kompromittiert. Die Normalisierung steht deshalb hier im
# Kanonisat, an EINER Stelle, wie es fuer AuthorityMode schon der Fall ist -
# so kann eine kuenftige Aenderung an Ensure-ConfigShape die Gleichheit nicht
# mehr brechen.
#
# Spiegelt NormalizeTimeText in src\NativeSupportLogic.cs.
function Get-CanonicalTimeText {
    param(
        [string]$Value,
        [string]$Fallback
    )

    $minuten = ConvertTo-TimeTextMinutes -Value $Value
    if ($null -eq $minuten) {
        $minuten = ConvertTo-TimeTextMinutes -Value $Fallback
    }
    if ($null -eq $minuten) {
        $minuten = 22 * 60
    }

    return ("{0:00}:{1:00}" -f [int][Math]::Floor($minuten / 60), [int]($minuten % 60))
}

function ConvertTo-TimeTextMinutes {
    param([string]$Value)

    $text = ([string]$Value).Trim()
    $treffer = [regex]::Match($text, '^(\d{1,2}):(\d{2})$')
    if (-not $treffer.Success) {
        return $null
    }

    $stunde = [int]$treffer.Groups[1].Value
    $minute = [int]$treffer.Groups[2].Value
    if ($stunde -lt 0 -or $stunde -gt 23 -or $minute -lt 0 -or $minute -gt 59) {
        return $null
    }
    return $stunde * 60 + $minute
}

# Spiegelt NormalizeDailyLimitMinutes / NormalizeMonthlyOrderLimit /
# NormalizeMonthlyBudgetEuro / NormalizeSocialMediaBudgetMinutes /
# NormalizeSocialMediaFeedDampingScrolls in src\NativeSupportConfig.cs - alle
# fuenf sind dieselbe Bereichspruefung mit anderen Grenzen.
function Get-CanonicalRangeInt {
    param(
        $Value,
        [int]$Minimum,
        [int]$Maximum,
        [int]$Fallback
    )

    $zahl = 0
    if (-not [int]::TryParse([string]$Value, [ref]$zahl)) {
        return $Fallback
    }
    if ($zahl -lt $Minimum -or $zahl -gt $Maximum) {
        return $Fallback
    }
    return $zahl
}

# Spiegelt NormalizeSocialMediaBlockedPlatforms: unbekannte Kennungen fallen
# weg, Doppelte auch, die Reihenfolge ist die von SocialMediaPlatformIds.
function Get-CanonicalSocialMediaBlockedPlatforms {
    param([string]$Csv)

    $gewaehlt = @()
    foreach ($part in ([string]$Csv) -split ",") {
        $platform = $part.Trim().ToLowerInvariant()
        if ($script:SocialMediaPlatformIds -contains $platform -and $gewaehlt -notcontains $platform) {
            $gewaehlt += $platform
        }
    }

    $geordnet = @()
    foreach ($platform in $script:SocialMediaPlatformIds) {
        if ($gewaehlt -contains $platform) {
            $geordnet += $platform
        }
    }
    return ($geordnet -join ",")
}

# Spiegelt NormalizeSocialMediaPlatformLimits: "plattform=minuten,...";
# unbekannte Plattformen, unlesbare oder ausserhalb liegende Minuten fallen
# weg, der erste Eintrag je Plattform gewinnt, und bei aktivem Tagesbudget darf
# eine Vorgabe nur strenger sein.
function Get-CanonicalSocialMediaPlatformLimits {
    param(
        [string]$Csv,
        [bool]$BudgetEnabled,
        $BudgetMinutes
    )

    $budget = Get-CanonicalRangeInt -Value $BudgetMinutes -Minimum 5 -Maximum 480 -Fallback 60
    $limits = @{}
    foreach ($part in ([string]$Csv) -split ",") {
        $paar = $part -split "="
        if ($paar.Count -ne 2) {
            continue
        }

        $platform = $paar[0].Trim().ToLowerInvariant()
        $minuten = 0
        if ($script:SocialMediaPlatformIds -notcontains $platform -or
            -not [int]::TryParse($paar[1].Trim(), [ref]$minuten) -or
            $minuten -lt 5 -or $minuten -gt 480 -or
            $limits.ContainsKey($platform)) {
            continue
        }

        if ($BudgetEnabled -and $minuten -gt $budget -and
            $script:SocialMediaOwnBudgetPlatformIds -notcontains $platform) {
            $minuten = $budget
        }
        $limits[$platform] = $minuten
    }

    $teile = @()
    foreach ($platform in $script:SocialMediaPlatformIds) {
        if ($limits.ContainsKey($platform)) {
            $teile += ($platform + "=" + $limits[$platform])
        }
    }
    return ($teile -join ",")
}

function Get-ConfigCanonical {
    param(
        [pscustomobject]$Config,
        [int]$SchemaVersion = 2,
        [bool]$IncludeSchemaLine = $true,
        [switch]$BetaSchema14
    )

    if ($BetaSchema14 -and $SchemaVersion -ne 14) {
        throw "The beta canonical variant only exists for schema 14."
    }

    $pw = $Config.Password
    $sb = New-Object System.Text.StringBuilder
    $append = {
        param([string]$Key, [string]$Value)
        [void]$sb.Append($Key).Append('=').Append([string]$Value).Append([char]10)
    }

    if ($IncludeSchemaLine) {
        & $append "IntegritySchemaVersion" ([string]$SchemaVersion)
    }
    & $append "ProtectionEnabled" (ConvertTo-CanonicalBool $Config.ProtectionEnabled)
    & $append "HostsEnabled" (ConvertTo-CanonicalBool $Config.HostsEnabled)
    & $append "FamilyDnsEnabled" (ConvertTo-CanonicalBool $Config.FamilyDnsEnabled)
    & $append "DnsProfile" ([string]$Config.DnsProfile)
    & $append "BypassBlockingEnabled" (ConvertTo-CanonicalBool $Config.BypassBlockingEnabled)
    & $append "UnsupportedBrowserBlockingEnabled" (ConvertTo-CanonicalBool $Config.UnsupportedBrowserBlockingEnabled)
    & $append "TamperProtectionEnabled" (ConvertTo-CanonicalBool $Config.TamperProtectionEnabled)
    & $append "SiteRedditEnabled" (ConvertTo-CanonicalBool $Config.SiteRedditEnabled)
    & $append "SiteXEnabled" (ConvertTo-CanonicalBool $Config.SiteXEnabled)
    & $append "SiteBlueskyEnabled" (ConvertTo-CanonicalBool $Config.SiteBlueskyEnabled)
    & $append "SiteTumblrEnabled" (ConvertTo-CanonicalBool $Config.SiteTumblrEnabled)
    & $append "SiteDeviantArtEnabled" (ConvertTo-CanonicalBool $Config.SiteDeviantArtEnabled)
    & $append "SitePixivEnabled" (ConvertTo-CanonicalBool $Config.SitePixivEnabled)
    & $append "SiteNewgroundsEnabled" (ConvertTo-CanonicalBool $Config.SiteNewgroundsEnabled)
    & $append "SiteImgurEnabled" (ConvertTo-CanonicalBool $Config.SiteImgurEnabled)
    & $append "SiteInstagramEnabled" (ConvertTo-CanonicalBool $Config.SiteInstagramEnabled)
    & $append "SiteTikTokEnabled" (ConvertTo-CanonicalBool $Config.SiteTikTokEnabled)
    & $append "SitePinterestEnabled" (ConvertTo-CanonicalBool $Config.SitePinterestEnabled)
    & $append "AdultContentProtectionEnabled" (ConvertTo-CanonicalBool $Config.AdultContentProtectionEnabled)
    & $append "AdultContentProtectionMode" ([string]$Config.AdultContentProtectionMode)
    & $append "GamblingProtectionEnabled" (ConvertTo-CanonicalBool (Get-EffectiveGamblingProtectionEnabled -Config $Config))
    & $append "GamblingProtectionMode" (Get-EffectiveGamblingProtectionMode -Config $Config)
    & $append "ShoppingProtectionEnabled" (ConvertTo-CanonicalBool $Config.ShoppingProtectionEnabled)
    & $append "ShoppingProtectionMode" ([string]$Config.ShoppingProtectionMode)
    & $append "ShoppingCheckoutDelayEnabled" (ConvertTo-CanonicalBool $Config.ShoppingCheckoutDelayEnabled)
    & $append "ShoppingStimulusDampingEnabled" (ConvertTo-CanonicalBool $Config.ShoppingStimulusDampingEnabled)
    & $append "ShoppingDealSearchBlockEnabled" (ConvertTo-CanonicalBool $Config.ShoppingDealSearchBlockEnabled)
    & $append "ShoppingCurfewEnabled" (ConvertTo-CanonicalBool $Config.ShoppingCurfewEnabled)
    & $append "ShoppingCurfewStart" (Get-CanonicalTimeText -Value ([string]$Config.ShoppingCurfewStart) -Fallback "22:00")
    & $append "ShoppingCurfewEnd" (Get-CanonicalTimeText -Value ([string]$Config.ShoppingCurfewEnd) -Fallback "06:00")
    if ($SchemaVersion -ge 2) {
        & $append "ShoppingDailyLimitEnabled" (ConvertTo-CanonicalBool $Config.ShoppingDailyLimitEnabled)
        & $append "ShoppingDailyLimitMinutes" ([string](Get-CanonicalRangeInt -Value $Config.ShoppingDailyLimitMinutes -Minimum 5 -Maximum 240 -Fallback 30))
        & $append "ShoppingMonthlyOrderLimitEnabled" (ConvertTo-CanonicalBool $Config.ShoppingMonthlyOrderLimitEnabled)
        & $append "ShoppingMonthlyOrderLimit" ([string](Get-CanonicalRangeInt -Value $Config.ShoppingMonthlyOrderLimit -Minimum 1 -Maximum 99 -Fallback 10))
        & $append "ShoppingMonthlyBudgetEnabled" (ConvertTo-CanonicalBool $Config.ShoppingMonthlyBudgetEnabled)
        & $append "ShoppingMonthlyBudgetEuro" ([string](Get-CanonicalRangeInt -Value $Config.ShoppingMonthlyBudgetEuro -Minimum 1 -Maximum 99999 -Fallback 200))
        & $append "GamblingDailyLimitEnabled" (ConvertTo-CanonicalBool $Config.GamblingDailyLimitEnabled)
        & $append "GamblingDailyLimitMinutes" ([string](Get-CanonicalRangeInt -Value $Config.GamblingDailyLimitMinutes -Minimum 5 -Maximum 240 -Fallback 15))
    }
    if ($SchemaVersion -ge 3) {
        & $append "SocialMediaDailyBudgetEnabled" (ConvertTo-CanonicalBool $Config.SocialMediaDailyBudgetEnabled)
        & $append "SocialMediaDailyBudgetMinutes" ([string](Get-CanonicalRangeInt -Value $Config.SocialMediaDailyBudgetMinutes -Minimum 5 -Maximum 480 -Fallback 60))
        & $append "SocialMediaPlatformLimits" (Get-CanonicalSocialMediaPlatformLimits -Csv ([string]$Config.SocialMediaPlatformLimits) -BudgetEnabled ([bool]$Config.SocialMediaDailyBudgetEnabled) -BudgetMinutes $Config.SocialMediaDailyBudgetMinutes)
        & $append "SocialMediaBlockedPlatforms" (Get-CanonicalSocialMediaBlockedPlatforms -Csv ([string]$Config.SocialMediaBlockedPlatforms))
        & $append "SocialMediaCurfewEnabled" (ConvertTo-CanonicalBool $Config.SocialMediaCurfewEnabled)
        & $append "SocialMediaCurfewStart" (Get-CanonicalTimeText -Value ([string]$Config.SocialMediaCurfewStart) -Fallback "22:00")
        & $append "SocialMediaCurfewEnd" (Get-CanonicalTimeText -Value ([string]$Config.SocialMediaCurfewEnd) -Fallback "06:00")
        & $append "SocialMediaReflectionEnabled" (ConvertTo-CanonicalBool $Config.SocialMediaReflectionEnabled)
        & $append "SocialMediaFeedDampingEnabled" (ConvertTo-CanonicalBool $Config.SocialMediaFeedDampingEnabled)
    }
    if ($SchemaVersion -ge 4) {
        & $append "SocialMediaFeedDampingScrolls" ([string](Get-CanonicalRangeInt -Value $Config.SocialMediaFeedDampingScrolls -Minimum 5 -Maximum 500 -Fallback 50))
    }
    if ($SchemaVersion -ge 5) {
        & $append "VideoGamesDailyLimitEnabled" (ConvertTo-CanonicalBool $Config.VideoGamesDailyLimitEnabled)
        & $append "VideoGamesDailyLimitMinutes" ([string][int]$Config.VideoGamesDailyLimitMinutes)
        & $append "VideoGamesCurfewEnabled" (ConvertTo-CanonicalBool $Config.VideoGamesCurfewEnabled)
        & $append "VideoGamesCurfewStart" (Get-CanonicalTimeText -Value ([string]$Config.VideoGamesCurfewStart) -Fallback "22:00")
        & $append "VideoGamesCurfewEnd" (Get-CanonicalTimeText -Value ([string]$Config.VideoGamesCurfewEnd) -Fallback "06:00")
    }
    if ($SchemaVersion -ge 6) {
        & $append "VideoGamesAutoDetectEnabled" (ConvertTo-CanonicalBool $Config.VideoGamesAutoDetectEnabled)
        & $append "VideoGamesHeuristicEnabled" (ConvertTo-CanonicalBool $Config.VideoGamesHeuristicEnabled)
    }
    & $append "VideoGamesProtectionEnabled" (ConvertTo-CanonicalBool $Config.VideoGamesProtectionEnabled)
    & $append "VideoGamesProtectionMode" ([string]$Config.VideoGamesProtectionMode)
    & $append "SocialMediaProtectionEnabled" (ConvertTo-CanonicalBool $Config.SocialMediaProtectionEnabled)
    & $append "SocialMediaProtectionMode" ([string]$Config.SocialMediaProtectionMode)
    & $append "ProtectionAreaRulePackVersion" ([string]$Config.ProtectionAreaRulePackVersion)
    & $append "LockdownModeEnabled" (ConvertTo-CanonicalBool $Config.LockdownModeEnabled)
    & $append "PauseCooldownEnabled" (ConvertTo-CanonicalBool $Config.PauseCooldownEnabled)
    & $append "ScheduleEnabled" (ConvertTo-CanonicalBool $Config.ScheduleEnabled)
    & $append "StrictModeEnabled" (ConvertTo-CanonicalBool $Config.StrictModeEnabled)
    & $append "ScheduleStart" (Get-CanonicalTimeText -Value ([string]$Config.ScheduleStart) -Fallback "22:00")
    & $append "ScheduleEnd" (Get-CanonicalTimeText -Value ([string]$Config.ScheduleEnd) -Fallback "06:00")
    & $append "PauseUntilUtc" ([string]$Config.PauseUntilUtc)
    & $append "PendingPauseUntilUtc" ([string]$Config.PendingPauseUntilUtc)
    & $append "PendingUninstallUntilUtc" ([string]$Config.PendingUninstallUntilUtc)
    & $append "UninstallApprovalExpiresUtc" ([string]$Config.UninstallApprovalExpiresUtc)
    & $append "PasswordFailedAttempts" ([string]([math]::Max(0, [int]$Config.PasswordFailedAttempts)))
    & $append "PasswordLockoutUntilUtc" ([string]$Config.PasswordLockoutUntilUtc)

    if ($null -eq $pw) {
        & $append "Password.Algorithm" ""
        & $append "Password.Iterations" "0"
        & $append "Password.Salt" ""
        & $append "Password.Hash" ""
    } else {
        & $append "Password.Algorithm" ([string]$pw.Algorithm)
        & $append "Password.Iterations" ([string][int]$pw.Iterations)
        & $append "Password.Salt" ([string]$pw.Salt)
        & $append "Password.Hash" ([string]$pw.Hash)
    }

    if ($SchemaVersion -ge 7) {
        & $append "InstalledVersion" ([string]$Config.InstalledVersion)
        & $append "ShoppingDelayDefaultMinutes" ([string][int]$Config.ShoppingDelayDefaultMinutes)
    }

    if ($SchemaVersion -ge 8) {
        & $append "SocialMediaFeedBlockedPlatforms" ([string]$Config.SocialMediaFeedBlockedPlatforms)
    }

    if ($SchemaVersion -ge 9) {
        & $append "ClockAnchorUtc" ([string]$Config.ClockAnchorUtc)
        & $append "ClockTickAnchorMs" ([string][int64]$Config.ClockTickAnchorMs)
    }

    if ($SchemaVersion -ge 10) {
        & $append "WeakeningRequestedUtc" ([string]$Config.WeakeningRequestedUtc)
    }

    if ($SchemaVersion -ge 11) {
        # Alles ausser einem ausdruecklichen "server" ist der lokale Modus -
        # genauso wie NormalizeAuthorityMode auf der C#-Seite. Ohne diese
        # Normalisierung ergaebe eine Konfiguration ohne den Schluessel hier ""
        # und dort "local", und die beiden Sprachen berechneten verschiedene
        # HMACs fuer dieselbe Datei.
        $authorityMode = "local"
        if ([string]::Equals([string]$Config.AuthorityMode, "server", [StringComparison]::OrdinalIgnoreCase)) {
            $authorityMode = "server"
        }
        & $append "AuthorityMode" $authorityMode
        & $append "PolicyVersion" ([string][int64]$Config.PolicyVersion)
        & $append "WeakeningGrant" ([string]$Config.WeakeningGrant)
        & $append "GrantSignature" ([string]$Config.GrantSignature)
        & $append "EntitledUntilUtc" ([string]$Config.EntitledUntilUtc)
    }

    if ($SchemaVersion -ge 12) {
        & $append "CompanionGrace" ([string]$Config.CompanionGrace)
    }

    if ($SchemaVersion -ge 13) {
        & $append "YouTubeRestrictEnabled" (ConvertTo-CanonicalBool $Config.YouTubeRestrictEnabled)
    }

    if ($SchemaVersion -ge 14 -and -not $BetaSchema14) {
        & $append "AdultHostsFollowArea" (ConvertTo-CanonicalBool $Config.AdultHostsFollowArea)
    }
    if ($SchemaVersion -ge 15 -or $BetaSchema14) {
        & $append "EntitlementSignature" ([string]$Config.EntitlementSignature)
        & $append "EntitlementMaxDevices" ([string][int]$Config.EntitlementMaxDevices)
    }

    return $sb.ToString()
}

function Get-ConfigIntegrity {
    param(
        [pscustomobject]$Config,
        [byte[]]$Key
    )

    $schemaVersion = ConvertTo-IntegritySchemaVersion -Value $Config.IntegritySchemaVersion
    if ($schemaVersion -eq $script:CurrentIntegritySchemaVersion) {
        return Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion $script:CurrentIntegritySchemaVersion
    }

    # Unversioned = the 0.62.18 on-disk format: schema-2 canonical WITHOUT a
    # schema line. Pinned to 2 on purpose - it must keep matching existing
    # signatures across future schema bumps.
    $canonical = Get-ConfigCanonical -Config $Config -SchemaVersion 2 -IncludeSchemaLine $false
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($canonical)
    $hmac = New-Object System.Security.Cryptography.HMACSHA256
    $hmac.Key = $Key
    try {
        $hash = $hmac.ComputeHash($bytes)
    } finally {
        $hmac.Dispose()
    }
    return [Convert]::ToBase64String($hash)
}

function Get-ConfigIntegrityForSchema {
    param(
        [pscustomobject]$Config,
        [byte[]]$Key,
        [int]$SchemaVersion,
        [switch]$BetaSchema14
    )

    # Schema 2 was the first version that wrote the schema line into the
    # canonical, so the floor is a fixed 2 - never relative to the current
    # schema (that would re-sign old schemas without their line and break
    # every existing config).
    $canonical = Get-ConfigCanonical -Config $Config -SchemaVersion $SchemaVersion -IncludeSchemaLine ($SchemaVersion -ge 2) -BetaSchema14:$BetaSchema14
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($canonical)
    $hmac = New-Object System.Security.Cryptography.HMACSHA256
    $hmac.Key = $Key
    try {
        $hash = $hmac.ComputeHash($bytes)
    } finally {
        $hmac.Dispose()
    }
    return [Convert]::ToBase64String($hash)
}

function Test-ConfigIntegrity {
    param(
        [pscustomobject]$Config,
        [byte[]]$Key,
        [string[]]$RawPropertyNames = @()
    )

    if ([string]::IsNullOrEmpty([string]$Config.Integrity)) {
        return $true
    }

    $schemaVersion = ConvertTo-IntegritySchemaVersion -Value $Config.IntegritySchemaVersion
    if ($schemaVersion -eq $script:CurrentIntegritySchemaVersion) {
        $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion $script:CurrentIntegritySchemaVersion
        return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
    }

    # Schema 14 was released with two different canonical forms. Authenticate
    # the exact original form and reject unsigned keys from the other branch.
    if ($schemaVersion -eq 14) {
        if ($RawPropertyNames -notcontains "EntitlementSignature" -and $RawPropertyNames -notcontains "EntitlementMaxDevices") {
            $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 14
            if ([string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)) {
                return $true
            }
        }
        if ($RawPropertyNames -notcontains "AdultHostsFollowArea") {
            $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 14 -BetaSchema14
            if ([string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)) {
                return $true
            }
        }
        return $false
    }

    # AdultHostsFollowArea is only signed from schema 14 on; on every older
    # acceptance path its presence means it was injected unsigned.
    if ($RawPropertyNames -contains "AdultHostsFollowArea") {
        return $false
    }

    # A valid schema-13 signature (0.62.70 .. 0.62.77) is accepted for
    # migration. Must run BEFORE the YouTubeRestrictEnabled absence check.
    # Die Berechtigungsschluessel sind erst ab Schema 14 signiert; auf jedem
    # aelteren Akzeptanzpfad bedeutet ihre Anwesenheit, dass sie unsigniert
    # injiziert wurden - ein selbst eingetragener Ablauftermin darf so nicht
    # durchrutschen.
    foreach ($entitlementKey in @("EntitlementSignature", "EntitlementMaxDevices")) {
        if ($RawPropertyNames -contains $entitlementKey) {
            return $false
        }
    }

    # A valid schema-13 signature (0.62.75) is accepted for migration. This
    # branch must run BEFORE the YouTubeRestrictEnabled absence check below:
    # schema-13 configs carry that key signed.
    if ($schemaVersion -eq 13) {
        $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 13
        return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
    }

    # YouTubeRestrictEnabled is only signed from schema 13 on; on every older
    # acceptance path its presence means it was injected unsigned - a switched
    # off YouTube filter must not slip through that way.
    if ($RawPropertyNames -contains "YouTubeRestrictEnabled") {
        return $false
    }

    # A valid schema-12 signature (0.62.62) is accepted for migration. This
    # branch must run BEFORE the CompanionGrace absence check below: schema-12
    # configs carry that key signed.
    if ($schemaVersion -eq 12) {
        $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 12
        return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
    }

    # CompanionGrace is only signed from schema 12 on; on every older
    # acceptance path its presence means it was injected unsigned - a
    # self-extended grace window would otherwise keep an arbitrarily old
    # companion valid.
    if ($RawPropertyNames -contains "CompanionGrace") {
        return $false
    }

    # A valid schema-11 signature (0.62.49) is accepted for migration. This
    # branch must run BEFORE the authority absence check below: schema-11
    # configs carry those keys signed.
    if ($schemaVersion -eq 11) {
        $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 11
        return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
    }

    # The authority keys are only signed from schema 11 on; on every older
    # acceptance path their presence means they were injected unsigned - a
    # planted grant or a rolled-back policy counter must not slip through.
    foreach ($authorityKey in @("AuthorityMode", "PolicyVersion", "WeakeningGrant", "GrantSignature", "EntitledUntilUtc")) {
        if ($RawPropertyNames -contains $authorityKey) {
            return $false
        }
    }

    # A valid schema-10 signature (0.62.48) is accepted for migration. This
    # branch must run BEFORE the WeakeningRequestedUtc absence check below:
    # schema-10 configs carry that key signed.
    if ($schemaVersion -eq 10) {
        $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 10
        return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
    }

    # WeakeningRequestedUtc is only signed from schema 10 on; on every older
    # acceptance path its presence means it was injected unsigned - a
    # pre-dated waiting period must not slip through.
    if ($RawPropertyNames -contains "WeakeningRequestedUtc") {
        return $false
    }

    # A valid schema-9 signature (0.62.47) is accepted for migration. This
    # branch must run BEFORE the ClockAnchorUtc absence check below: schema-9
    # configs carry the clock keys signed.
    if ($schemaVersion -eq 9) {
        $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 9
        return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
    }

    # ClockAnchorUtc is only signed from schema 9 on; on every older
    # acceptance path its presence means it was injected unsigned - a tampered
    # clock must not be smuggled past the check.
    if ($RawPropertyNames -contains "ClockAnchorUtc") {
        return $false
    }

    # A valid schema-8 signature (0.62.38-0.62.46) is accepted for migration.
    # This branch must run BEFORE the SocialMediaFeedBlockedPlatforms absence
    # check below: schema-8 configs carry that key signed.
    if ($schemaVersion -eq 8) {
        $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 8
        return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
    }

    # SocialMediaFeedBlockedPlatforms is only signed from schema 8 on; on
    # every older acceptance path (schema 7 included) its presence means it
    # was injected unsigned.
    if ($RawPropertyNames -contains "SocialMediaFeedBlockedPlatforms") {
        return $false
    }

    # A valid schema-7 signature (0.62.32-0.62.37) is accepted for migration.
    # This branch must run BEFORE the InstalledVersion absence check below:
    # schema-7 configs carry that key signed.
    if ($schemaVersion -eq 7) {
        $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 7
        return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
    }

    # InstalledVersion is only signed from schema 7 on; on every older
    # acceptance path its presence means it was injected unsigned.
    if ($RawPropertyNames -contains "InstalledVersion") {
        return $false
    }

    # A valid schema-6 signature (0.62.30/0.62.31) is accepted for migration.
    if ($schemaVersion -eq 6) {
        $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 6
        return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
    }

    # Video-games detection keys are only signed from schema 6 on; on every
    # older acceptance path (schema 5 included) their presence means they were
    # injected unsigned.
    foreach ($propertyName in @(
        "VideoGamesAutoDetectEnabled",
        "VideoGamesHeuristicEnabled"
    )) {
        if ($RawPropertyNames -contains $propertyName) {
            return $false
        }
    }

    # A valid schema-5 signature (0.62.29) is accepted for migration.
    if ($schemaVersion -eq 5) {
        $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 5
        return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
    }

    # Video-games limit keys are only signed from schema 5 on; on every older
    # acceptance path their presence means they were injected unsigned.
    foreach ($propertyName in @(
        "VideoGamesDailyLimitEnabled",
        "VideoGamesDailyLimitMinutes",
        "VideoGamesCurfewEnabled",
        "VideoGamesCurfewStart",
        "VideoGamesCurfewEnd"
    )) {
        if ($RawPropertyNames -contains $propertyName) {
            return $false
        }
    }

    # A valid schema-4 signature (0.62.22-0.62.28) is accepted for migration.
    if ($schemaVersion -eq 4) {
        $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 4
        return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
    }

    if ($schemaVersion -eq 3) {
        if ($RawPropertyNames -contains "SocialMediaFeedDampingScrolls") {
            return $false
        }
        $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 3
        return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
    }

    # Social-media keys are only signed from schema 3 on; on every older
    # acceptance path their presence means they were injected unsigned.
    foreach ($propertyName in @(
        "SocialMediaDailyBudgetEnabled",
        "SocialMediaDailyBudgetMinutes",
        "SocialMediaPlatformLimits",
        "SocialMediaBlockedPlatforms",
        "SocialMediaCurfewEnabled",
        "SocialMediaCurfewStart",
        "SocialMediaCurfewEnd",
        "SocialMediaReflectionEnabled",
        "SocialMediaFeedDampingEnabled",
        "SocialMediaFeedDampingScrolls"
    )) {
        if ($RawPropertyNames -contains $propertyName) {
            return $false
        }
    }

    # A valid schema-2 signature (0.62.19) is accepted for migration.
    if ($schemaVersion -eq 2) {
        $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 2
        return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
    }

    if ($schemaVersion -ne 0) {
        return $false
    }

    $expected = Get-ConfigIntegrity -Config $Config -Key $Key
    if ([string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)) {
        return $true
    }

    foreach ($propertyName in @(
        "ShoppingDailyLimitEnabled",
        "ShoppingDailyLimitMinutes",
        "ShoppingMonthlyOrderLimitEnabled",
        "ShoppingMonthlyOrderLimit",
        "ShoppingMonthlyBudgetEnabled",
        "ShoppingMonthlyBudgetEuro",
        "GamblingDailyLimitEnabled",
        "GamblingDailyLimitMinutes"
    )) {
        if ($RawPropertyNames -contains $propertyName) {
            return $false
        }
    }

    $expected = Get-ConfigIntegrityForSchema -Config $Config -Key $Key -SchemaVersion 1
    return [string]::Equals($expected, [string]$Config.Integrity, [StringComparison]::Ordinal)
}

function Get-IntegrityKey {
    Assert-DataDirectoryIsNotReparsePoint
    if (-not (Test-Path -LiteralPath $script:IntegrityKeyPath)) {
        return $null
    }
    try {
        $key = [Convert]::FromBase64String((Get-Content -LiteralPath $script:IntegrityKeyPath -Raw).Trim())
        if ($key.Length -ge 32) { return $key } else { return $null }
    } catch {
        return $null
    }
}

function Get-OrCreateIntegrityKey {
    $existing = Get-IntegrityKey
    if ($null -ne $existing) {
        return $existing
    }

    $key = New-Object byte[] 32
    $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
    $rng.GetBytes($key)
    $rng.Dispose()

    Ensure-DataDir
    # Durable: ohne den Schluessel ist jede signierte Config wertlos und die App
    # verlangt eine Neueinrichtung samt Verlust aller Einstellungen.
    Set-DurableFileText -Path $script:IntegrityKeyPath -Value ([Convert]::ToBase64String($key))
    return $key
}

# Forces every protection-relevant field to its safe (on) value and clears all
# pause/uninstall timers. Mirrors ForceSafeProtection in NativeSupportConfig.cs.
function Set-SafeProtection {
    param([pscustomobject]$Config)

    $Config.ProtectionEnabled = $true
    $Config.HostsEnabled = $true
    $Config.FamilyDnsEnabled = $true
    $Config.BypassBlockingEnabled = $true
    $Config.UnsupportedBrowserBlockingEnabled = $true
    $Config.TamperProtectionEnabled = $true
    foreach ($site in @(
        "SiteRedditEnabled", "SiteXEnabled", "SiteBlueskyEnabled", "SiteTumblrEnabled",
        "SiteDeviantArtEnabled", "SitePixivEnabled", "SiteNewgroundsEnabled",
        "SiteImgurEnabled", "SiteInstagramEnabled", "SiteTikTokEnabled", "SitePinterestEnabled"
    )) {
        $Config.$site = $true
    }
    # Gambling is an avoid-entirely category like adult content: a tampered
    # config must never leave it unblocked. Mirror ForceSafeProtection in
    # src\NativeSupportConfig.cs so both privileged readers agree on the
    # post-tamper state.
    $Config.GamblingProtectionEnabled = $true
    $Config.GamblingProtectionMode = "strict"
    if ($null -ne $Config.PSObject.Properties["GamblingSupportEnabled"]) { $Config.GamblingSupportEnabled = $false }
    if ($null -ne $Config.PSObject.Properties["GamblingSupportMode"]) { $Config.GamblingSupportMode = "off" }
    # All remaining protection areas are forced on monotonically with their
    # protective default values: a tampered config must never yield less
    # protection than any legitimate state. Field-for-field mirror of
    # ForceSafeProtection in src\NativeSupportConfig.cs (guarded, because a
    # hand-built or pre-schema config may lack the newer fields).
    foreach ($pair in @(
        @("AdultContentProtectionEnabled", $true),
        @("AdultContentProtectionMode", "strict"),
        @("ShoppingProtectionEnabled", $true),
        # Friction areas have no strict enforcement anywhere - "gentle" IS
        # their maximally protective mode; every feature below is still
        # forced on individually.
        @("ShoppingProtectionMode", "gentle"),
        @("ShoppingDelayDefaultMinutes", 10),
        @("ShoppingCheckoutDelayEnabled", $true),
        @("ShoppingStimulusDampingEnabled", $true),
        @("ShoppingDealSearchBlockEnabled", $true),
        @("ShoppingCurfewEnabled", $true),
        @("ShoppingCurfewStart", "22:00"),
        @("ShoppingCurfewEnd", "06:00"),
        @("ShoppingDailyLimitEnabled", $true),
        @("ShoppingDailyLimitMinutes", 30),
        @("ShoppingMonthlyOrderLimitEnabled", $true),
        @("ShoppingMonthlyOrderLimit", 10),
        @("ShoppingMonthlyBudgetEnabled", $true),
        @("ShoppingMonthlyBudgetEuro", 200),
        @("GamblingDailyLimitEnabled", $true),
        @("GamblingDailyLimitMinutes", 15),
        @("SocialMediaProtectionEnabled", $true),
        @("SocialMediaProtectionMode", "gentle"),
        @("SocialMediaDailyBudgetEnabled", $true),
        @("SocialMediaDailyBudgetMinutes", 60),
        @("SocialMediaPlatformLimits", ""),
        @("SocialMediaBlockedPlatforms", ""),
        @("SocialMediaFeedBlockedPlatforms", ""),
        @("SocialMediaCurfewEnabled", $true),
        @("SocialMediaCurfewStart", "22:00"),
        @("SocialMediaCurfewEnd", "06:00"),
        @("SocialMediaReflectionEnabled", $true),
        @("SocialMediaFeedDampingEnabled", $true),
        @("SocialMediaFeedDampingScrolls", 50),
        @("VideoGamesProtectionEnabled", $true),
        @("VideoGamesProtectionMode", "strict"),
        @("VideoGamesDailyLimitEnabled", $true),
        @("VideoGamesDailyLimitMinutes", 60),
        @("VideoGamesCurfewEnabled", $true),
        @("VideoGamesCurfewStart", "22:00"),
        @("VideoGamesCurfewEnd", "06:00"),
        @("VideoGamesAutoDetectEnabled", $true),
        @("VideoGamesHeuristicEnabled", $true)
    )) {
        if ($null -ne $Config.PSObject.Properties[$pair[0]]) { $Config.($pair[0]) = $pair[1] }
    }
    $Config.LockdownModeEnabled = $true
    $Config.PauseCooldownEnabled = $true
    $Config.PauseUntilUtc = ""
    $Config.PendingPauseUntilUtc = ""
    if ($null -ne $Config.PSObject.Properties["PendingUninstallUntilUtc"]) { $Config.PendingUninstallUntilUtc = "" }
    if ($null -ne $Config.PSObject.Properties["UninstallApprovalExpiresUtc"]) { $Config.UninstallApprovalExpiresUtc = "" }
}

# Only a config with an EMPTY Integrity field is trusted unverified (legacy /
# pre-signing install). If a config carries a signature it must verify: a
# mismatch OR a missing/invalid key means the file was changed outside
# Purestate, so the WHOLE config is untrusted - every protection field is
# forced safe and the config is marked compromised (Save-Config and
# Test-Password then refuse it, so the tampered values cannot be re-blessed and
# a swapped password hash cannot authenticate).
function Assert-ConfigIntegrity {
    param(
        [pscustomobject]$Config,
        [string[]]$RawPropertyNames = @()
    )

    if ($null -eq $Config.PSObject.Properties["IntegrityCompromised"]) {
        $Config | Add-Member -NotePropertyName IntegrityCompromised -NotePropertyValue $false
    }

    $stored = [string]$Config.Integrity
    if ([string]::IsNullOrEmpty($stored)) {
        # CFG-001/PS-002: Ohne Signatur ist nur der Erstlauf vor der
        # Passwortvergabe legitim - Save-Config schreibt immer eine. Ein
        # vorhandenes Passwort ohne Signatur heisst also: die Zeile wurde
        # entfernt. Dieselbe Bedingung steht in C#
        # (VerifyConfigIntegrityOnLoad); sie muss beidseitig gelten, sonst
        # setzt dieser Pfad weiter durch, was die App bereits ablehnt.
        if ($null -ne $Config.Password) {
            Add-SecurityLog "Config integrity check failed - signed config lost its integrity field. Forcing full protection; password refused until reinstall."
            Set-SafeProtection -Config $Config
            $Config.IntegrityCompromised = $true
        }
        return
    }

    $key = Get-IntegrityKey
    if ($null -eq $key) {
        Add-SecurityLog "Config integrity check failed - integrity key missing or invalid for a signed config. Forcing full protection; password refused until reinstall."
        Set-SafeProtection -Config $Config
        $Config.IntegrityCompromised = $true
        return
    }

    if (-not (Test-ConfigIntegrity -Config $Config -Key $key -RawPropertyNames $RawPropertyNames)) {
        Add-SecurityLog "Config integrity check failed - config.json HMAC mismatch (modified outside Purestate). Forcing full protection; password refused until reinstall."
        Set-SafeProtection -Config $Config
        $Config.IntegrityCompromised = $true
    }
}

function Remove-RetiredPersonalConfigProperties {
    param([pscustomobject]$Config)

    foreach ($propertyName in @(
        'GamblingResourceCountry', 'GamblingDelayDefaultMinutes', 'GamblingHelpResourcesEnabled',
        'GamblingSupportIncludeInBackup', 'ShoppingResourceCountry', 'ShoppingHelpResourcesEnabled',
        'ShoppingSupportIncludeInBackup', 'SocialMediaResourceCountry',
        'SocialMediaDelayDefaultMinutes', 'SocialMediaHelpResourcesEnabled',
        'SocialMediaSupportIncludeInBackup'
    )) {
        if ($null -ne $Config.PSObject.Properties[$propertyName]) {
            $Config.PSObject.Properties.Remove($propertyName)
        }
    }
}

function Save-Config {
    param([pscustomobject]$Config)

    Invoke-WithConfigLock {
        Ensure-DataDir
        Ensure-ConfigShape -Config $Config
        Normalize-GamblingProtectionState -Config $Config
        # Clamp the friction-area modes on the OBJECT before signing so
        # canonical text, HMAC and written file agree (write-path only; the
        # read path keeps accepting legacy signed "strict"). Mirror of
        # NormalizeSoftProtectionAreaState in src\NativeSupportProtectionAreas.cs.
        $Config.ShoppingProtectionMode = Get-NormalizedSoftProtectionAreaMode -Mode ([string]$Config.ShoppingProtectionMode) -Fallback "planned"
        $Config.SocialMediaProtectionMode = Get-NormalizedSoftProtectionAreaMode -Mode ([string]$Config.SocialMediaProtectionMode) -Fallback "planned"

        # Never write back a config that failed its integrity check - that would
        # re-bless the tampered values with a fresh HMAC. The runtime-only
        # IntegrityCompromised marker is also stripped so it is not serialized.
        if ($null -ne $Config.PSObject.Properties["IntegrityCompromised"]) {
            if ([bool]$Config.IntegrityCompromised) {
                throw "Die Purestate-Konfiguration wurde ausserhalb der App veraendert und ist gesperrt. Bitte installiere Purestate neu."
            }
            $Config.PSObject.Properties.Remove("IntegrityCompromised")
        }

        Remove-RetiredPersonalConfigProperties -Config $Config

        $key = Get-OrCreateIntegrityKey
        $Config.IntegritySchemaVersion = $script:CurrentIntegritySchemaVersion
        $Config.Integrity = Get-ConfigIntegrity -Config $Config -Key $key
        $json = ($Config | ConvertTo-Json -Depth 8) + [Environment]::NewLine
        Set-TextFileAtomically -Path $script:ConfigPath -Value $json
        Write-CompanionRuleState -Config $Config
    }
}

function Write-CompanionRuleState {
    # config.json is ACL-locked to Administrators+SYSTEM, but Chrome starts
    # the native host as the signed-in user. Mirror ONLY the non-sensitive
    # rule fields (area modes, shopping friction settings, per-site switches)
    # into a world-readable file the host reads and watches. Never passwords,
    # HMAC, lockout counters, or personal support data. Best effort: a failed
    # mirror write must never block the config save.
    param([pscustomobject]$Config)

    try {
        Ensure-DataDir
        $publicDir = Join-Path $script:DataDir "public"
        if (-not (Test-Path -LiteralPath $publicDir)) {
            New-Item -ItemType Directory -Path $publicDir -Force | Out-Null
        }
        try {
            & (Get-SystemToolPath "icacls.exe") $publicDir /grant "*S-1-5-32-545:(OI)(CI)RX" | Out-Null
        } catch {
        }

        $state = [ordered]@{
            AdultContentProtectionEnabled = [bool]$Config.AdultContentProtectionEnabled
            GamblingProtectionEnabled = [bool](Get-EffectiveGamblingProtectionEnabled -Config $Config)
            GamblingSupportEnabled = [bool]$Config.GamblingSupportEnabled
            ShoppingProtectionEnabled = [bool]$Config.ShoppingProtectionEnabled
            ShoppingCheckoutDelayEnabled = [bool]$Config.ShoppingCheckoutDelayEnabled
            ShoppingStimulusDampingEnabled = [bool]$Config.ShoppingStimulusDampingEnabled
            ShoppingDealSearchBlockEnabled = [bool]$Config.ShoppingDealSearchBlockEnabled
            ShoppingCurfewEnabled = [bool]$Config.ShoppingCurfewEnabled
            ShoppingCurfewStart = [string]$Config.ShoppingCurfewStart
            ShoppingCurfewEnd = [string]$Config.ShoppingCurfewEnd
            ShoppingDelayDefaultMinutes = [int]$Config.ShoppingDelayDefaultMinutes
            ShoppingDailyLimitEnabled = [bool]$Config.ShoppingDailyLimitEnabled
            ShoppingDailyLimitMinutes = [int]$Config.ShoppingDailyLimitMinutes
            ShoppingMonthlyOrderLimitEnabled = [bool]$Config.ShoppingMonthlyOrderLimitEnabled
            ShoppingMonthlyOrderLimit = [int]$Config.ShoppingMonthlyOrderLimit
            ShoppingMonthlyBudgetEnabled = [bool]$Config.ShoppingMonthlyBudgetEnabled
            ShoppingMonthlyBudgetEuro = [int]$Config.ShoppingMonthlyBudgetEuro
            GamblingDailyLimitEnabled = [bool]$Config.GamblingDailyLimitEnabled
            GamblingDailyLimitMinutes = [int]$Config.GamblingDailyLimitMinutes
            SocialMediaProtectionEnabled = [bool]$Config.SocialMediaProtectionEnabled
            SocialMediaDailyBudgetEnabled = [bool]$Config.SocialMediaDailyBudgetEnabled
            SocialMediaDailyBudgetMinutes = [int]$Config.SocialMediaDailyBudgetMinutes
            SocialMediaPlatformLimits = [string]$Config.SocialMediaPlatformLimits
            SocialMediaBlockedPlatforms = [string]$Config.SocialMediaBlockedPlatforms
            SocialMediaFeedBlockedPlatforms = [string]$Config.SocialMediaFeedBlockedPlatforms
            SocialMediaCurfewEnabled = [bool]$Config.SocialMediaCurfewEnabled
            SocialMediaCurfewStart = [string]$Config.SocialMediaCurfewStart
            SocialMediaCurfewEnd = [string]$Config.SocialMediaCurfewEnd
            SocialMediaReflectionEnabled = [bool]$Config.SocialMediaReflectionEnabled
            SocialMediaFeedDampingEnabled = [bool]$Config.SocialMediaFeedDampingEnabled
            SocialMediaFeedDampingScrolls = [int]$Config.SocialMediaFeedDampingScrolls
            SiteRedditEnabled = [bool]$Config.SiteRedditEnabled
            SiteXEnabled = [bool]$Config.SiteXEnabled
            SiteBlueskyEnabled = [bool]$Config.SiteBlueskyEnabled
            SiteTumblrEnabled = [bool]$Config.SiteTumblrEnabled
            SiteDeviantArtEnabled = [bool]$Config.SiteDeviantArtEnabled
            SitePixivEnabled = [bool]$Config.SitePixivEnabled
            SiteNewgroundsEnabled = [bool]$Config.SiteNewgroundsEnabled
            SiteImgurEnabled = [bool]$Config.SiteImgurEnabled
            SiteInstagramEnabled = [bool]$Config.SiteInstagramEnabled
            SiteTikTokEnabled = [bool]$Config.SiteTikTokEnabled
            SitePinterestEnabled = [bool]$Config.SitePinterestEnabled
            # Spiegel der vertrauenswuerdigen Uhr fuer den Native Host, der
            # config.json nicht lesen darf (NHR-001). Ohne ihn laufen die
            # Freigabefristen im Regelpaket an der rohen Systemuhr (CLK-004).
            ClockAnchorUtc = (Get-TrustedLocalNow -Config $Config).ToUniversalTime().ToString("o")
        }
        $stateJson = (([pscustomobject]$state) | ConvertTo-Json) + [Environment]::NewLine
        Set-TextFileAtomically -Path (Join-Path $publicDir "companion-rule-state.json") -Value $stateJson
    } catch {
        # MIR-001: Dieser Spiegel ist die PRIMAERE Quelle des Native Hosts -
        # config.json darf er nicht lesen. Scheitert das Schreiben, arbeitet der
        # Host still mit dem alten Stand weiter: eine gerade abgeschaltete
        # Ausnahme gilt dann noch, eine gerade eingeschaltete Sperre noch nicht.
        # Der leere catch bleibt richtig, ein misslungener Spiegel darf das
        # Speichern der Konfiguration nie blockieren. Stumm darf er nicht sein.
        try {
            Add-AppLog "Companion-Zustandsspiegel konnte nicht geschrieben werden: $($_.Exception.Message). Der Native Host arbeitet bis zum naechsten Speichern mit dem alten Stand."
        } catch {
        }
    }
}

function Initialize-Config {
    param([Security.SecureString]$Password)

    $plain = ConvertTo-PlainText -SecureText $Password
    Assert-PasswordPolicy -PlainText $plain

    $config = [pscustomobject]@{
        ProtectionEnabled = $true
        HostsEnabled = $true
        FamilyDnsEnabled = $true
        DnsProfile = $script:DefaultDnsProfile
        BrowserPoliciesEnabled = $true
        BypassBlockingEnabled = $true
        UnsupportedBrowserBlockingEnabled = $true
        TamperProtectionEnabled = $true
        YouTubeRestrictEnabled = $true
        SiteRedditEnabled = $true
        SiteXEnabled = $true
        SiteBlueskyEnabled = $true
        SiteTumblrEnabled = $true
        SiteDeviantArtEnabled = $true
        SitePixivEnabled = $true
        SiteNewgroundsEnabled = $true
        SiteImgurEnabled = $true
        SiteInstagramEnabled = $true
        SiteTikTokEnabled = $true
        SitePinterestEnabled = $true
        AdultContentProtectionEnabled = $true
        AdultContentProtectionMode = "strict"
        GamblingProtectionEnabled = $false
        GamblingProtectionMode = "off"
        ShoppingProtectionEnabled = $false
        ShoppingProtectionMode = "planned"
        ShoppingDelayDefaultMinutes = 10
        ShoppingCheckoutDelayEnabled = $true
        ShoppingStimulusDampingEnabled = $true
        ShoppingDealSearchBlockEnabled = $true
        ShoppingCurfewEnabled = $true
        ShoppingCurfewStart = "22:00"
        ShoppingCurfewEnd = "06:00"
        ShoppingDailyLimitEnabled = $true
        ShoppingDailyLimitMinutes = 30
        ShoppingMonthlyOrderLimitEnabled = $true
        ShoppingMonthlyOrderLimit = 10
        ShoppingMonthlyBudgetEnabled = $false
        ShoppingMonthlyBudgetEuro = 200
        GamblingDailyLimitEnabled = $true
        GamblingDailyLimitMinutes = 15
        SocialMediaDailyBudgetEnabled = $false
        SocialMediaDailyBudgetMinutes = 60
        SocialMediaPlatformLimits = ""
        SocialMediaBlockedPlatforms = ""
        SocialMediaFeedBlockedPlatforms = ""
        SocialMediaCurfewEnabled = $false
        SocialMediaCurfewStart = "22:00"
        SocialMediaCurfewEnd = "06:00"
        SocialMediaReflectionEnabled = $true
        SocialMediaFeedDampingEnabled = $true
        SocialMediaFeedDampingScrolls = 50
        VideoGamesProtectionEnabled = $false
        VideoGamesProtectionMode = "planned"
        SocialMediaProtectionEnabled = $false
        SocialMediaProtectionMode = "planned"
        ProtectionAreaRulePackVersion = "1"
        GamblingSupportEnabled = $false
        GamblingSupportMode = "off"
        LockdownModeEnabled = $true
        PauseCooldownEnabled = $true
        PendingPauseUntilUtc = ""
        ScheduleEnabled = $false
        StrictModeEnabled = $false
        ScheduleStart = "22:00"
        ScheduleEnd = "06:00"
        PauseUntilUtc = ""
        PasswordHint = ""
        Password = (New-PasswordRecord -PlainText $plain)
    }

    Save-Config -Config $config
}

function Set-ConfigProtectionEnabled {
    param([bool]$Enabled)

    Invoke-WithConfigLock {
        $config = Get-Config
        $config.ProtectionEnabled = $Enabled
        if ($Enabled) {
            $config.PauseUntilUtc = ""
            $config.PendingPauseUntilUtc = ""
        }
        Save-Config -Config $config
    }
}

function Get-PauseUntilUtc {
    param([pscustomobject]$Config)

    if ($null -eq $Config -or [string]::IsNullOrWhiteSpace([string]$Config.PauseUntilUtc)) {
        return $null
    }

    try {
        return ([DateTime]::Parse([string]$Config.PauseUntilUtc, $null, [Globalization.DateTimeStyles]::RoundtripKind)).ToUniversalTime()
    } catch {
        return $null
    }
}

function Convert-TimeTextToMinutes {
    param(
        [string]$Value,
        [int]$Fallback
    )

    $text = ([string]$Value).Trim()
    if ($text -match "^(\d{1,2}):(\d{2})$") {
        $hour = [int]$Matches[1]
        $minute = [int]$Matches[2]
        if ($hour -ge 0 -and $hour -le 23 -and $minute -ge 0 -and $minute -le 59) {
            return (($hour * 60) + $minute)
        }
    }

    return $Fallback
}

function Test-ScheduledProtectionActive {
    param([pscustomobject]$Config)

    Ensure-ConfigShape -Config $Config
    if (-not $Config.ScheduleEnabled) {
        return $false
    }

    $start = Convert-TimeTextToMinutes -Value $Config.ScheduleStart -Fallback (22 * 60)
    $end = Convert-TimeTextToMinutes -Value $Config.ScheduleEnd -Fallback (6 * 60)
    if ($start -eq $end) {
        return $false
    }

    $now = Get-TrustedLocalNow -Config $Config
    $current = ($now.Hour * 60) + $now.Minute
    if ($start -lt $end) {
        return ($current -ge $start -and $current -lt $end)
    }

    return ($current -ge $start -or $current -lt $end)
}

# Abgelaufen ist nur, was aus einer Quelle stammt, der zu trauen ist: der
# eingebauten Fassungsgrenze oder dem Ablauftermin aus der Konfiguration, den
# der Integritaets-HMAC deckt. Fehlender, leerer oder unlesbarer Wert laesst
# den Schutz AN - die unsichere Richtung waere hier das Abschalten.
#
# Anders als das C#-Gegenstueck (Support.IsEntitlementExpiredAt) prueft dieser
# Spiegel die RSA-Signatur nicht nach - er hat den eingebetteten
# Serverschluessel nicht. Er verlangt aber, dass ueberhaupt eine
# EntitlementSignature gespeichert ist. Genau dieser Fall - Termin verstrichen,
# gar keine Signatur da - lief vorher auseinander: PowerShell gab den Rechner
# frei, waehrend C# weiter "Schutz aktiv" meldete, in der Oberflaeche, im
# Statusbericht und gegenueber TryRestoreProtectionAfterFailedInstall. Ein
# ungeschuetzter Rechner, der sich als geschuetzt ausgibt.
#
# Bleibende Grenze: eine gespeicherte Signatur, die der eingebettete
# AuthorityServerPublicKey nicht verifiziert (Schluesseltausch, siehe
# docs\AUTHORITY-OPERATIONS.md), laesst diesen Spiegel "abgelaufen" sagen,
# waehrend C# "nicht abgelaufen" sagt. Der Spiegel kann das ohne RSA und ohne
# den Geraeteschluessel nicht entscheiden.
function Test-EntitlementExpired {
    param([pscustomobject]$Config)

    # Eine Konfiguration, die ihre Integritaetspruefung nicht besteht, ist nie
    # abgelaufen. Sie erzwingt allen Schutz (Set-SafeProtection) und darf auf
    # keinem Weg das Gegenteil ausloesen. Die Pruefung steht VOR der
    # Fassungsgrenze, weil die am Uhr-Anker gemessen wird - und der Anker ist
    # ein Feld in config.json. Haltbar ist das, weil eine kompromittierte
    # Konfiguration nie neu signiert zurueckgeschrieben wird (Save-Config wirft,
    # Update-ClockAnchor ueberspringt sie); die Manipulation bleibt also bei
    # jedem Laden erkennbar.
    if (($null -ne $Config) -and
        ($null -ne $Config.PSObject.Properties["IntegrityCompromised"]) -and
        [bool]$Config.IntegrityCompromised) {
        return $false
    }

    $styles = [System.Globalization.DateTimeStyles]::RoundtripKind
    $culture = [System.Globalization.CultureInfo]::InvariantCulture
    $nowUtc = (Get-TrustedLocalNow -Config $Config).ToUniversalTime()

    $buildEnd = [datetime]::MinValue
    if ([datetime]::TryParse($script:BetaBuildEndUtc, $culture, $styles, [ref]$buildEnd)) {
        if ($nowUtc -ge $buildEnd.ToUniversalTime()) {
            return $true
        }
    }

    if ($null -eq $Config) {
        return $false
    }

    Ensure-ConfigShape -Config $Config
    if ([string]::IsNullOrEmpty([string]$Config.EntitlementSignature)) {
        return $false
    }

    $until = [string]$Config.EntitledUntilUtc
    if ([string]::IsNullOrEmpty($until)) {
        return $false
    }

    $entitledUntil = [datetime]::MinValue
    if (-not [datetime]::TryParse($until, $culture, $styles, [ref]$entitledUntil)) {
        return $false
    }

    return ($nowUtc -ge $entitledUntil.ToUniversalTime())
}

function Test-ProtectionShouldRun {
    param([pscustomobject]$Config)

    Ensure-ConfigShape -Config $Config
    if (Test-EntitlementExpired -Config $Config) {
        return $false
    }

    return ($Config.ProtectionEnabled -or (Test-ScheduledProtectionActive -Config $Config))
}

function Set-ConfigPassword {
    param([Security.SecureString]$Password)

    $plain = ConvertTo-PlainText -SecureText $Password

    Invoke-WithConfigLock {
        $config = Get-Config
        Assert-PasswordPolicy -PlainText $plain -Hint $config.PasswordHint
        $config.Password = New-PasswordRecord -PlainText $plain
        Save-Config -Config $config
    }
}

function Test-Password {
    param([Security.SecureString]$Password)

    $config = Get-Config
    if (($null -ne $config.PSObject.Properties["IntegrityCompromised"]) -and [bool]$config.IntegrityCompromised) {
        # The stored hash is untrusted once the config fails its integrity check.
        return $false
    }

    if ($null -eq $config.Password) {
        return $false
    }

    $plain = ConvertTo-PlainText -SecureText $Password
    return (Test-PasswordRecord -Record $config.Password -PlainText $plain)
}

function Normalize-Domain {
    # Mirrors Support.NormalizeDomain in src\NativeSupportLogic.cs - keep both in sync.
    param([string]$Domain)

    $value = "$Domain".Trim().ToLowerInvariant()
    $value = $value -replace "^https?://", ""
    $value = ($value -split "/")[0].Trim()
    $value = $value.Trim('.')
    return $value
}

function Test-ValidDomain {
    # Mirrors Support.IsValidDomain in src\NativeSupportLogic.cs - keep both in sync.
    param([string]$Domain)

    return "$Domain" -match "^[a-z0-9.-]+\.[a-z]{2,}$"
}

function Get-DomainsFromRuleFiles {
    param([string[]]$Files)

    $domains = New-Object System.Collections.Generic.List[string]
    foreach ($file in $Files) {
        if (-not (Test-Path -LiteralPath $file)) {
            continue
        }

        foreach ($line in Get-Content -LiteralPath $file) {
            $raw = $line.Trim()
            if ($raw.Length -eq 0 -or $raw.StartsWith("#")) {
                continue
            }

            $clean = Normalize-Domain -Domain $raw
            if (Test-ValidDomain -Domain $clean) {
                $domains.Add($clean)
                if ($clean.StartsWith("www.")) {
                    $domains.Add($clean.Substring(4))
                } else {
                    $domains.Add("www.$clean")
                }
            }
        }
    }

    return @($domains | Sort-Object -Unique)
}

# Mirrort Support.FormatAdultLearnedExemptionLine in src\NativeSupportDomains.cs
# - synchron halten. Der Parametername "-Host" ist von aussen gewuenscht,
# intern heisst die Variable anders: "$Host" ist eine schreibgeschuetzte
# PowerShell-Automatikvariable und kann nicht ueberschrieben werden.
function Invoke-FormatAdultExemption {
    param(
        [Alias("Host")]
        [string]$ExemptHost,
        [DateTime]$ActivatesAtUtc
    )

    return "{0}|{1}" -f $ActivatesAtUtc.ToUniversalTime().ToString("o"), $ExemptHost
}

# Mirrort Support.ParseAdultLearnedExemptionLine in src\NativeSupportDomains.cs
# - synchron halten. Eine kaputte Zeile liefert $null statt einen Fehler zu
# werfen - der Aufrufer laesst die restlichen Zeilen einfach weiterlaufen.
function Invoke-ParseAdultExemption {
    param([string]$Line)

    $trimmed = "$Line".Trim()
    if ($trimmed.Length -eq 0 -or $trimmed.StartsWith("#")) {
        return $null
    }

    $parts = $trimmed -split '\|', 2
    if ($parts.Count -ne 2) {
        return $null
    }

    $activatesAt = [DateTime]::MinValue
    if (-not [DateTime]::TryParse($parts[0].Trim(), [Globalization.CultureInfo]::InvariantCulture,
            [Globalization.DateTimeStyles]::RoundtripKind, [ref]$activatesAt)) {
        return $null
    }

    $exemptHost = Normalize-Domain -Domain $parts[1]
    if (-not (Test-ValidDomain -Domain $exemptHost)) {
        return $null
    }

    return [pscustomobject]@{
        Host = $exemptHost
        ActivatesAtUtc = $activatesAt.ToUniversalTime()
    }
}

# Vom Companion gelernte Erwachsenen-Hosts (Task 4 schreibt die Datei nach
# ProgramData). Bewusst KEIN fail-closed auf "alles sperren": eine fehlende
# oder kaputte gelernte Datei darf den Bereich nicht ausweiten und darf ihn
# nicht abschalten - das ist eine bewusste Ausnahme von der sonstigen
# fail-closed-Regel des Projekts. Get-DomainsFromRuleFiles liefert das schon
# so: eine fehlende Datei ergibt leer, eine ungueltige Zeile faellt einzeln
# heraus, die kuratierten Listen tragen unveraendert weiter.
# Eine Frist darf sich durch Stellen der Systemuhr weder verlaengern noch
# vorziehen. Dafuer braucht es ZWEI Regeln, nicht eine (Befunde PS-001,
# CLK-001, CLK-004):
#
#   Get-LatestClockUtc   - wenn eine Erlaubnis ABLAEUFT (Pause, 30-Tage-
#                          Freigabe). Zurueckstellen verlaengert sonst beliebig.
#   Get-EarliestClockUtc - wenn eine Erlaubnis erst WIRKSAM wird (15-Minuten-
#                          Frist). Vorstellen zieht sie sonst vor.
#
# Wer die Uhr stellt, bewegt sich damit in beide Richtungen gegen sich selbst.
# Der Anker allein genuegt nicht: steht der Guard, steht der Anker - dann
# traegt die Systemuhr die Frist weiter.
function Get-LatestClockUtc {
    param(
        [DateTime]$AnchorUtc,
        [DateTime]$SystemUtc
    )

    if ($AnchorUtc -gt $SystemUtc) { return $AnchorUtc }
    return $SystemUtc
}

function Get-EarliestClockUtc {
    param(
        [DateTime]$AnchorUtc,
        [DateTime]$SystemUtc
    )

    if ($AnchorUtc -lt $SystemUtc) { return $AnchorUtc }
    return $SystemUtc
}

# Der Zeitpunkt, gegen den das Ende einer Pause geprueft wird. Die Pause ist
# eine Erlaubnis, also zaehlt die spaetere der beiden Uhren (PS-001): wer die
# Systemuhr zurueckstellt, verlaengert seine Pause sonst beliebig, und genau
# diese Frist ist die Reibung, um die es geht.
function Get-PauseExpiryNowUtc {
    param(
        [pscustomobject]$Config,
        [DateTime]$SystemUtc = [DateTime]::UtcNow
    )

    $anchorUtc = (Get-TrustedLocalNow -Config $Config).ToUniversalTime()
    return Get-LatestClockUtc -AnchorUtc $anchorUtc -SystemUtc $SystemUtc
}

function Get-LearnedAdultDomains {
    [CmdletBinding()]
    param(
        [string]$Path = (Join-Path $script:DataDir "learned-adult-domains.txt"),
        [string]$ExemptionsPath = (Join-Path (Get-AppRoot) "rules\adult-learned-exemptions.txt"),
        [DateTime]$SystemUtc = [DateTime]::UtcNow,
        [DateTime]$AnchorUtc = [DateTime]::MinValue
    )

    if ($AnchorUtc -eq [DateTime]::MinValue) {
        $AnchorUtc = (Get-TrustedLocalNow -Config (Get-Config)).ToUniversalTime()
    }

    $domains = Get-DomainsFromRuleFiles -Files @($Path)

    # Die Freigabe trifft NUR gelernte Hosts. Kuratierte Domains stehen in
    # eigenen Dateien und werden hier nie angefasst - sonst waere diese Datei
    # der Generalschluessel fuer den ganzen Schutzbereich.
    if (Test-Path -LiteralPath $ExemptionsPath) {
        # Wirksam wird die Freigabe nach der FRUEHEREN, abgelaufen ist sie nach
        # der SPAETEREN der beiden Uhren (CLK-001).
        $activationNowUtc = Get-EarliestClockUtc -AnchorUtc $AnchorUtc -SystemUtc $SystemUtc
        $expiryNowUtc = Get-LatestClockUtc -AnchorUtc $AnchorUtc -SystemUtc $SystemUtc
        $exempt = New-Object System.Collections.Generic.HashSet[string] ([StringComparer]::OrdinalIgnoreCase)
        $acceptedHosts = New-Object System.Collections.Generic.HashSet[string] ([StringComparer]::OrdinalIgnoreCase)
        foreach ($line in Get-Content -LiteralPath $ExemptionsPath) {
            $parsed = Invoke-ParseAdultExemption -Line $line
            if ($null -eq $parsed -or $parsed.ActivatesAtUtc -gt $activationNowUtc -or
                $parsed.ActivatesAtUtc -le $expiryNowUtc.AddDays(-30)) {
                continue
            }
            if ($acceptedHosts.Contains($parsed.Host)) {
                continue
            }
            if ($acceptedHosts.Count -ge 500) {
                break
            }
            [void]$acceptedHosts.Add($parsed.Host)
            [void]$exempt.Add($parsed.Host)
            if ($parsed.Host.StartsWith("www.")) {
                [void]$exempt.Add($parsed.Host.Substring(4))
            } else {
                [void]$exempt.Add("www.$($parsed.Host)")
            }
        }
        if ($exempt.Count -gt 0) {
            $domains = @($domains | Where-Object { -not $exempt.Contains($_) })
        }
    }

    return @($domains)
}

function Get-DomainList {
    $root = Get-AppRoot
    $config = Get-Config
    # Neuinstallationen ab Schema 14 (AdultHostsFollowArea): die Erwachsenen-
    # Liste haengt am Bereich. Bestehende Installationen behalten sie an der
    # Sperrliste - ein Update baut Schutz nie still ab.
    $files = @()
    if ([bool]$config.AdultContentProtectionEnabled -or -not [bool]$config.AdultHostsFollowArea) {
        $files += (Join-Path $root "rules\adult-domains.txt")
    }
    $files += (Join-Path $root "rules\custom-domains.txt")

    if (Test-ProtectionAreaEnabled -Area "gambling") {
        $files += (Join-Path $root "rules\gambling-domains.txt")
        $files += (Join-Path $root "rules\offshore-gambling-domains.txt")
        $files += (Join-Path $root "rules\gambling-affiliate-domains.txt")
        $files += (Join-Path $root "rules\custom-gambling-domains.txt")
    }

    # User-curated shopping blocklist: active while the shopping area itself is
    # on (gentle friction area). Deliberately keyed on the enabled flag, not on
    # mode "strict" - the shopping area never runs strict, but domains the user
    # explicitly blocked must still be enforced.
    if ([bool](Get-Config).ShoppingProtectionEnabled) {
        $files += (Join-Path $root "rules\custom-shopping-domains.txt")
    }

    # Cloud-gaming services and browser-game portals: only while the
    # video-games area is enforced (strict). The xbox.com/play route is NOT
    # here - hosts/DNS cannot block paths, that route lives only in the
    # browser-policy layer (Get-VideoGamesBlockedRoutePatterns).
    if (Test-ProtectionAreaEnabled -Area "video-games") {
        $files += (Join-Path $root "rules\gaming-domains.txt")
    }

    $domains = @(Get-DomainsFromRuleFiles -Files $files)

    # Gelernte Hosts nur, solange der Erwachsenenbereich ueberhaupt an ist -
    # gleiche Logik wie beim Shopping-Block oben: auf den Enabled-Schalter
    # gekeyed, nicht auf den Modus.
    if ([bool](Get-Config).AdultContentProtectionEnabled) {
        $domains += Get-LearnedAdultDomains
    }

    return @($domains | Sort-Object -Unique)
}

function Get-GamblingBlocklistDomains {
    # Gambling domains for the Chromium URLBlocklist. The hosts file already
    # blocks these, but a browser-level policy also holds when the OS hosts file
    # is bypassed (e.g. a browser's own Secure DNS). Only active while the
    # gambling area is enabled.
    if (-not (Test-ProtectionAreaEnabled -Area "gambling")) {
        return @()
    }

    $root = Get-AppRoot
    $files = @(
        (Join-Path $root "rules\gambling-domains.txt"),
        (Join-Path $root "rules\offshore-gambling-domains.txt"),
        (Join-Path $root "rules\gambling-affiliate-domains.txt"),
        (Join-Path $root "rules\custom-gambling-domains.txt")
    )

    # Bare-host form only: the Chromium URLBlocklist matches a host plus all of
    # its subdomains, so "bet365.com" already covers www.bet365.com. Drop the
    # www. duplicates Get-DomainsFromRuleFiles adds.
    return @(Get-DomainsFromRuleFiles -Files $files |
        Where-Object { -not $_.StartsWith("www.") } |
        Sort-Object -Unique)
}

function Get-AdultBlocklistDomains {
    # Kuratierte und gelernte Erwachsenen-Domains fuer die Chromium-Sperrliste.
    # Die hosts-Datei sperrt diese schon, aber eine Browser-Richtlinie haelt
    # auch dann, wenn ein Browser die hosts-Datei mit eigenem Secure-DNS
    # (DNS-over-HTTPS) umgeht. Gegatet auf den Enabled-Schalter, nicht den
    # Modus - gleiche Logik wie bei den gelernten Hosts in Get-DomainList.
    if (-not [bool](Get-Config).AdultContentProtectionEnabled) {
        return @()
    }

    $root = Get-AppRoot
    $files = @(
        (Join-Path $root "rules\adult-domains.txt"),
        (Join-Path $root "rules\custom-domains.txt")
    )

    $domains = @(Get-DomainsFromRuleFiles -Files $files) + @(Get-LearnedAdultDomains)

    # Bare-host form only, wie bei Get-GamblingBlocklistDomains: die
    # Chromium-Sperrliste deckt Unterdomains mit ab, www.-Dubletten waeren
    # verschenkte Plaetze im 1000er-Deckel.
    return @($domains |
        Where-Object { -not $_.StartsWith("www.") } |
        Sort-Object -Unique)
}

function Get-ShoppingBlocklistDomains {
    # User-curated shopping domains for the Chromium URLBlocklist. Mirrors
    # Get-GamblingBlocklistDomains but only carries the custom list: shopping
    # has no seeded domain lists, users pick their own problem shops.
    if (-not [bool](Get-Config).ShoppingProtectionEnabled) {
        return @()
    }

    $root = Get-AppRoot
    $files = @(
        (Join-Path $root "rules\custom-shopping-domains.txt")
    )

    return @(Get-DomainsFromRuleFiles -Files $files |
        Where-Object { -not $_.StartsWith("www.") } |
        Sort-Object -Unique)
}

function Get-VideoGamesBlocklistDomains {
    # Cloud-gaming/browser-game domains for the Chromium URLBlocklist and the
    # Firefox WebsiteFilter. Mirrors Get-GamblingBlocklistDomains (bare-host
    # form, implicit subdomain matching). Only while the video-games area is
    # enforced (strict).
    if (-not (Test-ProtectionAreaEnabled -Area "video-games")) {
        return @()
    }

    $root = Get-AppRoot
    $files = @(
        (Join-Path $root "rules\gaming-domains.txt")
    )

    return @(Get-DomainsFromRuleFiles -Files $files |
        Where-Object { -not $_.StartsWith("www.") } |
        Sort-Object -Unique)
}

function Get-VideoGamesBlockedRoutePatterns {
    # Xbox Cloud Gaming lives under xbox.com/play; blocking all of xbox.com
    # would take store/account down with it. Path routes are only possible in
    # the browser-policy layer - hosts/DNS deliberately carry no xbox entry.
    if (-not (Test-ProtectionAreaEnabled -Area "video-games")) {
        return @()
    }

    return @(
        "*://xbox.com/play*",
        "*://*.xbox.com/play*"
    )
}

# Platforms with a stable set of distraction routes for the selective feed
# block. Mirrors Support.SocialMediaFeedRoutePlatformIds (pinned by tests).
$script:SocialMediaFeedRoutePlatformIds = @("instagram", "youtube", "x", "reddit", "tumblr")

function Get-NormalizedSocialMediaFeedBlockedPlatforms {
    param(
        [string]$FeedCsv,
        [string]$BlockedCsv
    )

    # Unknown/non-routed ids are dropped; a platform under a FULL block never
    # stays in the feed list - the full block wins. Order mirrors the C#
    # normalizer (SocialMediaPlatformIds order).
    $fullBlocked = @()
    foreach ($part in ([string]$BlockedCsv) -split ",") {
        $fullBlocked += $part.Trim().ToLowerInvariant()
    }

    $requested = @()
    foreach ($part in ([string]$FeedCsv) -split ",") {
        $platform = $part.Trim().ToLowerInvariant()
        if ($script:SocialMediaFeedRoutePlatformIds -contains $platform -and
            $fullBlocked -notcontains $platform -and
            $requested -notcontains $platform) {
            $requested += $platform
        }
    }

    $ordered = @()
    foreach ($platform in @("x", "instagram", "tiktok", "pinterest", "tumblr", "bluesky", "reddit", "youtube")) {
        if ($requested -contains $platform) {
            $ordered += $platform
        }
    }
    return ($ordered -join ",")
}

function Get-SocialMediaBlockedDomains {
    # Domains of the per-platform social media full blocks for the Chromium
    # URLBlocklist / Firefox WebsiteFilter. Only carries platforms the user
    # explicitly blocked in the Social Media dialog; the domain map is fixed
    # and mirrored by Support.GetSocialMediaBlockedDomains in C#.
    $config = Get-Config
    if (-not [bool]$config.SocialMediaProtectionEnabled) {
        return @()
    }

    $map = @{
        "x" = @("x.com", "twitter.com")
        "instagram" = @("instagram.com")
        "tiktok" = @("tiktok.com")
        # BAS-006: Der Vollblock kannte nur .com, waehrend die Fail-closed-Liste
        # derselben Plattform dreizehn Domains sperrt. Wer Pinterest bewusst
        # vollstaendig sperrte, erreichte pinterest.de weiterhin.
        "pinterest" = @("pinterest.com", "pinterest.de", "pinterest.at", "pinterest.ch", "pinterest.fr", "pinterest.it", "pinterest.es", "pinterest.co.uk", "pinterest.ca", "pinterest.com.au", "pinterest.com.mx", "pinterest.jp", "pinterest.se")
        "tumblr" = @("tumblr.com")
        "bluesky" = @("bsky.app")
        "reddit" = @("reddit.com")
        "youtube" = @("youtube.com", "m.youtube.com", "youtu.be")
        # Streaming (Tester-Notiz 2026-10-06): nur im Browser, die Apps der Dienste
        # bleiben frei. Prime Video auf amazon.de fehlt absichtlich - die Domain
        # gehoert dem Shopping-Bereich.
        "streaming" = @("netflix.com", "disneyplus.com", "primevideo.com", "max.com", "hbomax.com", "paramountplus.com", "tv.apple.com", "crunchyroll.com", "twitch.tv", "joyn.de", "plus.rtl.de", "dazn.com", "wowtv.de")
    }

    $result = @()
    foreach ($part in ([string]$config.SocialMediaBlockedPlatforms) -split ",") {
        $platform = $part.Trim().ToLowerInvariant()
        if (-not $map.ContainsKey($platform)) {
            continue
        }
        foreach ($domain in $map[$platform]) {
            if ($result -notcontains $domain) {
                $result += $domain
            }
        }
    }
    return @($result)
}

function Get-SocialMediaFeedBlockedPatterns {
    # URL patterns of the selective feed block (distraction routes only, rest
    # of the platform stays usable) for the Chromium URLBlocklist / Firefox
    # WebsiteFilter. Route map is mirrored by
    # Support.GetSocialMediaFeedBlockedPatterns, the guard fail-closed filters
    # and the Companion route constant (pinned by tests).
    $config = Get-Config
    if (-not [bool]$config.SocialMediaProtectionEnabled) {
        return @()
    }

    $routeMap = @{
        "instagram" = @{ Hosts = @("instagram.com"); Routes = @("/reels", "/explore") }
        "youtube" = @{ Hosts = @("youtube.com", "m.youtube.com"); Routes = @("/shorts") }
        "x" = @{ Hosts = @("x.com", "twitter.com"); Routes = @("/explore") }
        "reddit" = @{ Hosts = @("reddit.com"); Routes = @("/r/popular", "/r/all") }
        "tumblr" = @{ Hosts = @("tumblr.com"); Routes = @("/explore") }
    }

    $result = @()
    foreach ($part in ([string]$config.SocialMediaFeedBlockedPlatforms) -split ",") {
        $platform = $part.Trim().ToLowerInvariant()
        if (-not $routeMap.ContainsKey($platform)) {
            continue
        }
        foreach ($routeHost in $routeMap[$platform].Hosts) {
            foreach ($route in $routeMap[$platform].Routes) {
                foreach ($pattern in @("*://$routeHost$route*", "*://*.$routeHost$route*")) {
                    if ($result -notcontains $pattern) {
                        $result += $pattern
                    }
                }
            }
        }
    }
    return @($result)
}

function Get-GamblingSearchPatterns {
    # Search-engine URLBlocklist patterns for gambling queries, mirroring the
    # adult search coverage. Without these, a gambling search (e.g. "online
    # casino") was not blocked at the policy level, and Google's search service
    # worker hangs on its warmup page before the results page (where the
    # Companion overlay would run) ever loads. A policy block short-circuits that
    # like it already does for adult searches. Only active while the gambling
    # area is enabled.
    if (-not (Test-ProtectionAreaEnabled -Area "gambling")) {
        return @()
    }

    # Curated, low-ambiguity gambling terms. Bare "casino" also covers "online
    # casino(s)". Deliberately omits highly ambiguous single words (poker, lotto,
    # roulette, blackjack, jackpot, slots) so common non-gambling searches are
    # not hard-blocked by the wildcard; the Companion still covers those with its
    # safe-context matcher.
    $keywords = @(
        "casino", "gluecksspiel", "sportwetten", "sportwette", "spielautomaten",
        "wettbonus", "wettanbieter", "tipico", "bet365", "bwin", "unibet"
    )

    $templates = @(
        "*://www.google.*/search*{0}*",
        "*://www.bing.com/search*{0}*",
        "*://www.bing.com/images/search*{0}*",
        "*://www.bing.com/videos/search*{0}*",
        "*://duckduckgo.com/*q=*{0}*",
        "*://search.brave.com/search*{0}*",
        "*://search.yahoo.com/search*{0}*",
        "*://*.search.yahoo.com/search*{0}*",
        "*://yandex.com/search*{0}*",
        "*://www.ecosia.org/search*{0}*",
        "*://www.startpage.com/sp/search*{0}*",
        "*://www.qwant.com/*q=*{0}*",
        "*://metager.org/meta/*{0}*",
        "*://www.youtube.com/results*{0}*"
    )

    $patterns = @()
    foreach ($keyword in $keywords) {
        foreach ($template in $templates) {
            $patterns += ($template -f $keyword)
        }
    }
    return @($patterns)
}

function Get-ShoppingSearchPatterns {
    # Search-engine URLBlocklist patterns for deal/coupon queries, mirroring the
    # gambling search coverage. Only active while the shopping area with
    # deal-search blocking is enabled. Deliberately curated and low-ambiguity:
    # bare "sale" or "deal" stay allowed; only clearly compulsive-shopping
    # queries are policy-blocked. The Companion overlay covers softer
    # combinations on the results page itself.
    $config = Get-Config
    if (-not ([bool]$config.ShoppingProtectionEnabled -and [bool]$config.ShoppingDealSearchBlockEnabled)) {
        return @()
    }

    $keywords = @(
        "gutschein", "gutscheincode", "rabattcode", "rabattaktion",
        "coupon", "couponcode", "black friday", "cyber monday",
        "schnaeppchen", "blitzangebot", "flash sale", "cashback deal"
    )

    $templates = @(
        "*://www.google.*/search*{0}*",
        "*://www.bing.com/search*{0}*",
        "*://duckduckgo.com/*q=*{0}*",
        "*://search.brave.com/search*{0}*",
        "*://search.yahoo.com/search*{0}*",
        "*://*.search.yahoo.com/search*{0}*",
        "*://yandex.com/search*{0}*",
        "*://www.ecosia.org/search*{0}*",
        "*://www.startpage.com/sp/search*{0}*",
        "*://www.qwant.com/*q=*{0}*",
        "*://metager.org/meta/*{0}*"
    )

    $patterns = @()
    foreach ($keyword in $keywords) {
        $encoded = $keyword -replace ' ', '*'
        foreach ($template in $templates) {
            $patterns += ($template -f $encoded)
        }
    }
    return @($patterns)
}

function Get-AllowDomainList {
    $root = Get-AppRoot
    $file = Join-Path $root "rules\allow-domains.txt"
    if (-not (Test-Path -LiteralPath $file)) {
        return @()
    }

    return Get-DomainsFromRuleFiles -Files @($file)
}

function Get-HostsRaw {
    if (Test-Path -LiteralPath $script:HostsPath) {
        return Get-Content -LiteralPath $script:HostsPath -Raw
    }

    return ""
}

function Remove-ManagedHostsBlock {
    param([string]$Content)

    $begin = [regex]::Escape($script:MarkerBegin)
    $end = [regex]::Escape($script:MarkerEnd)
    $pattern = "(?ms)^$begin\r?\n.*?^$end\r?\n?"
    return [regex]::Replace($Content, $pattern, "").TrimEnd()
}

# Sichert den Zustand VOR dem ersten Purestate-Schreibvorgang. Nur einmal: ein
# zweiter Lauf wuerde die bereits erzwungene Datei als "Original" festhalten -
# derselbe Fehler, den Backup-DnsSettings ausdruecklich vermeidet.
function Backup-HostsFileOnce {
    param([string]$Path)

    try {
        if ([string]::IsNullOrEmpty($script:HostsBackupPath) -or
            -not [System.IO.File]::Exists($Path) -or
            [System.IO.File]::Exists($script:HostsBackupPath)) {
            return
        }

        Ensure-DataDir
        Set-DurableFileText -Path $script:HostsBackupPath -Value ([System.IO.File]::ReadAllText($Path))
    } catch {
        # Best effort: eine fehlende Sicherung darf die Durchsetzung nicht
        # aufhalten, sie wird nur protokolliert.
        Add-AppLog "Hosts backup failed: $($_.Exception.Message)"
    }
}

# PST-002: Frueher genuegte die Startmarke irgendwo im Text. Eine Datei, die ein
# abgerissener Schreibvorgang auf die Marke gekuerzt hat, meldete damit "lokale
# Sperrliste aktiv" - und daraus wurde der gruene Gesamtstatus. Verlangt sind
# beide Marken und dazwischen mindestens eine Sperrzeile. Spiegelt
# Support.HostsBlockActive in src\NativeSupportStatus.cs.
function Test-HostsBlockActive {
    param([string]$Content)

    $text = [string]$Content
    $begin = $text.IndexOf($script:MarkerBegin, [StringComparison]::Ordinal)
    if ($begin -lt 0) {
        return $false
    }
    $end = $text.IndexOf($script:MarkerEnd, $begin, [StringComparison]::Ordinal)
    if ($end -lt 0) {
        return $false
    }

    $block = $text.Substring($begin, $end - $begin)
    return [bool]([regex]::IsMatch($block, '(?m)^\s*\d{1,3}(\.\d{1,3}){3}\s+\S'))
}

# PST-001: Dieselbe Definition wie Support.FamilyDnsActiveForAdapters in
# src\NativeSupportStatus.cs - aktiv ist das Familien-DNS genau dann, wenn JEDER
# verkehrstragende Adapter (Up und mit Standardgateway) einen Familienserver
# traegt. Vorher genuegte EIN Treffer auf EINER anderen Adaptermenge: der Laptop
# aus dem Dock und das aufgebaute VPN sahen damit gruen aus.
function Test-FamilyDnsActiveForAdapters {
    param(
        [string[]]$FamilyServers,
        $Adapters
    )

    $family = @()
    foreach ($server in @($FamilyServers)) {
        $wert = ([string]$server).Trim()
        if ($wert.Length -gt 0 -and $family -notcontains $wert) {
            $family += $wert
        }
    }
    if ($family.Count -eq 0) {
        return $false
    }

    $sawCarrier = $false
    foreach ($adapter in @($Adapters)) {
        if (-not [bool]$adapter.IsUp -or -not [bool]$adapter.HasGateway) {
            continue
        }

        $sawCarrier = $true
        $filtered = $false
        foreach ($dns in @($adapter.DnsServers)) {
            if ($family -contains ([string]$dns).Trim()) {
                $filtered = $true
                break
            }
        }
        if (-not $filtered) {
            return $false
        }
    }

    return $sawCarrier
}

# Liest dieselbe Quelle wie die C#-Seite: alle Schnittstellen des Systems, nicht
# nur die von Get-ManagedAdapters ausgewaehlten. Sonst kann die Anzeige den
# Adapter, der die Aufloesung wirklich traegt, gar nicht sehen (NET-001).
function Get-DnsAdapterStates {
    $states = @()
    foreach ($nic in [System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces()) {
        try {
            $properties = $nic.GetIPProperties()
            $dns = @()
            foreach ($address in $properties.DnsAddresses) {
                $dns += $address.ToString()
            }
            $states += [pscustomobject]@{
                IsUp = ($nic.OperationalStatus -eq [System.Net.NetworkInformation.OperationalStatus]::Up)
                HasGateway = ($properties.GatewayAddresses.Count -gt 0)
                DnsServers = $dns
            }
        } catch {
        }
    }
    return $states
}

function Set-AsciiTextFile {
    param(
        [string]$Path,
        [string]$Value
    )

    $fullPath = [System.IO.Path]::GetFullPath($Path)
    $directory = [System.IO.Path]::GetDirectoryName($fullPath)

    if (-not [System.IO.Directory]::Exists($directory)) {
        throw "Der Ordner wurde nicht gefunden: $directory"
    }

    # Die hosts-Datei wird staendig von Fremdprozessen kurz geoeffnet -
    # Virenscanner, DNS-Client, Editoren. Ein einzelner Schreibversuch liess
    # deshalb den gesamten Durchsetzungslauf mit Exit 1 scheitern; am
    # 2026-07-31 stand das zweimal im service.log. Die Sperre ist fast immer
    # nach Millisekunden weg, also kurz wiederholen statt aufgeben.
    $attempts = 5
    # HST-001: Der Durchsetzungslauf schrieb die hosts-Datei in JEDEM Takt neu,
    # auch wenn sich kein einziges Zeichen geaendert hatte - alle 30 Sekunden
    # eine Datei in System32\drivers\etc. Jeder Schreibvorgang konkurriert
    # dort mit Virenscanner und DNS-Client um dieselbe Datei; am 2026-08-31
    # sind daran in acht Stunden drei Durchsetzungsschritte gescheitert
    # ("bereits von einem anderen Prozess verwendet"), obwohl nichts zu tun
    # war. Ist der Inhalt schon derselbe, wird nicht geschrieben. Manipulation
    # aendert den Inhalt und wird deshalb weiterhin in jedem Takt repariert.
    $desiredBytes = [System.Text.Encoding]::Default.GetBytes([string]$Value)
    try {
        if ([System.IO.File]::Exists($fullPath)) {
            $currentBytes = [System.IO.File]::ReadAllBytes($fullPath)
            if ($currentBytes.Length -eq $desiredBytes.Length) {
                $identisch = $true
                for ($i = 0; $i -lt $desiredBytes.Length; $i++) {
                    if ($currentBytes[$i] -ne $desiredBytes[$i]) {
                        $identisch = $false
                        break
                    }
                }
                if ($identisch) {
                    return
                }
            }
        }
    } catch {
        # Nicht lesbar heisst nicht "unveraendert": dann wird geschrieben.
    }
    # NET-008: Das ReadOnly-Attribut wurde entfernt und nie zurueckgesetzt -
    # auch nicht nach einer Deinstallation. Manche Sicherheitsprodukte und
    # Gruppenrichtlinien setzen es bewusst, um genau die Aenderung zu
    # verhindern, die hier vorgenommen wird; Purestate nahm ihnen den Schutz
    # dauerhaft weg. Gemerkt wird es hier, zurueckgesetzt im finally unten -
    # auch wenn das Schreiben scheitert.
    $readOnlyEntfernt = $false
    try {
    for ($attempt = 1; $attempt -le $attempts; $attempt++) {
        try {
            if ([System.IO.File]::Exists($fullPath)) {
                $attributes = [System.IO.File]::GetAttributes($fullPath)
                if (($attributes -band [System.IO.FileAttributes]::ReadOnly) -ne 0) {
                    [System.IO.File]::SetAttributes($fullPath, ($attributes -bxor [System.IO.FileAttributes]::ReadOnly))
                    $readOnlyEntfernt = $true
                }
            }

            # PST-002/NET-009: WriteAllText kuerzt die Zieldatei zuerst und
            # schreibt dann. Bricht der Vorgang dazwischen ab - Stromausfall,
            # harter Neustart -, ist der urspruengliche Inhalt weg,
            # einschliesslich aller Fremdeintraege. Geschrieben wird deshalb in
            # eine Temporaerdatei im SELBEN Verzeichnis und danach in einem
            # Schritt ersetzt; File.Replace behaelt die ACL der Zieldatei, was
            # bei der hosts-Datei zaehlt.
            Backup-HostsFileOnce -Path $fullPath

            $temp = $fullPath + ".purestate-tmp"
            $stream = New-Object System.IO.FileStream(
                $temp,
                [System.IO.FileMode]::Create,
                [System.IO.FileAccess]::Write,
                [System.IO.FileShare]::None)
            try {
                # NET-006: Geschrieben wurde als reines ASCII - und
                # Encoding.ASCII ersetzt JEDES Zeichen ueber 0x7F durch "?".
                # Durch diese Wandlung lief nicht nur der eigene Block, sondern
                # der GESAMTE Dateiinhalt, bei jedem Aktivieren und Deaktivieren.
                # Aus dem Fremdkommentar "# Firmenproxy fuer Aussenstelle" (mit
                # echten Umlauten) wurde beim ersten Schutzstart dauerhaft
                # "# Firmenproxy f?r Au?enstelle". Wiederherstellbar ist das
                # nicht.
                #
                # Gelesen wird mit "Get-Content -Raw", also in der Vorgabe von
                # PowerShell 5.1: der ANSI-Codepage. Geschrieben wird jetzt mit
                # derselben - am 2026-08-22 nachgemessen, dass der Weg damit
                # byte-genau ist, auch fuer die fuenf in Windows-1252
                # undefinierten Bytes (0x81, 0x8D, 0x8F, 0x90, 0x9D). Die von
                # Purestate erzeugten Zeilen sind reines ASCII und in beiden
                # Kodierungen byte-gleich; fuer sie aendert sich nichts.
                $stream.Write($desiredBytes, 0, $desiredBytes.Length)
                # $true = FlushFileBuffers, nicht nur der verwaltete Puffer.
                $stream.Flush($true)
            } finally {
                $stream.Dispose()
            }

            if ([System.IO.File]::Exists($fullPath)) {
                [System.IO.File]::Replace($temp, $fullPath, [NullString]::Value, $true)
            } else {
                [System.IO.File]::Move($temp, $fullPath)
            }
            return
        } catch {
            try {
                $temp = $fullPath + ".purestate-tmp"
                if ([System.IO.File]::Exists($temp)) {
                    [System.IO.File]::Delete($temp)
                }
            } catch {
            }
            if ($attempt -eq $attempts) {
                throw "Die Datei konnte nicht geschrieben werden: $fullPath. $($_.Exception.Message)"
            }
            Start-Sleep -Milliseconds (150 * $attempt)
        }
    }
    } finally {
        # NET-008: Das Attribut gehoert dem System, nicht Purestate. Auch wenn
        # das Schreiben scheitert oder die Schleife per return verlassen wird.
        if ($readOnlyEntfernt) {
            try {
                if ([System.IO.File]::Exists($fullPath)) {
                    $jetzt = [System.IO.File]::GetAttributes($fullPath)
                    if (($jetzt -band [System.IO.FileAttributes]::ReadOnly) -eq 0) {
                        [System.IO.File]::SetAttributes($fullPath, ($jetzt -bor [System.IO.FileAttributes]::ReadOnly))
                    }
                }
            } catch {
            }
        }
    }
}

# Die MITGELIEFERTEN Sperrlisten. Getrennt von den selbst eingetragenen
# (custom-*.txt) und den gelernten Hosts, weil nur die zweite Gruppe per
# Allowlist wieder aufhebbar sein darf.
function Get-CuratedDomainList {
    $root = Get-AppRoot
    return @(Get-DomainsFromRuleFiles -Files @(
        (Join-Path $root "rules\adult-domains.txt"),
        (Join-Path $root "rules\gambling-domains.txt"),
        (Join-Path $root "rules\offshore-gambling-domains.txt"),
        (Join-Path $root "rules\gambling-affiliate-domains.txt"),
        (Join-Path $root "rules\gaming-domains.txt")
    ))
}

# Was am Ende wirklich in die hosts-Datei geht: Sperrliste minus Allowlist -
# aber die Allowlist hebt KURATIERTE Domains nicht auf (Befund DOM-003). Sonst
# nimmt ein einziger Eintrag in einer ungezeichneten Datei eine kuratierte
# Erwachsenen- oder Gluecksspieldomain sofort aus der Sperre, am
# Abschwaechungsfenster vorbei. Dieselbe Trennlinie zieht die
# Erwachsenen-Freigabe bereits (sie erreicht die kuratierten Listen gar nicht).
# Eigene Funktion, damit die Regel ohne Schreibzugriff auf die hosts-Datei
# geprueft werden kann.
# RC-001: Eine beantragte Ruecknahme aus der EIGENEN Sperrliste wirkt erst nach
# 15 Minuten. Die Frist wird hier beim LESEN ausgewertet, nicht durch Umschreiben
# der Datei: so gibt es keinen zweiten Schreiber neben der App, und ein
# Durchsetzungslauf kann die Freigabe nicht verschlucken. Das Aufraeumen der
# abgearbeiteten Eintraege ist reine Hygiene und bleibt der App ueberlassen
# (Support.ApplyDueCustomDomainRemovals).
#
# Gemessen wird mit der vertrauenswuerdigen Uhr - eine vorgestellte Systemuhr
# darf die Wartezeit nicht abkuerzen.
function Get-DueCustomDomainRemovals {
    param(
        [string]$Path = (Join-Path (Get-AppRoot) "rules\custom-domain-removals.txt"),
        [DateTime]$NowUtc = [DateTime]::MinValue
    )

    if ($NowUtc -eq [DateTime]::MinValue) {
        $NowUtc = (Get-TrustedLocalNow -Config (Get-Config)).ToUniversalTime()
    }
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return @()
    }

    $due = New-Object System.Collections.Generic.List[string]
    foreach ($raw in (Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)) {
        $line = ([string]$raw).Trim()
        if ($line.Length -eq 0 -or $line.StartsWith("#")) {
            continue
        }
        $parts = $line.Split('|', 2)
        if ($parts.Count -ne 2) {
            continue
        }
        $activatesAt = [datetime]::MinValue
        $styles = [System.Globalization.DateTimeStyles]::RoundtripKind
        if (-not [datetime]::TryParse($parts[0].Trim(), [System.Globalization.CultureInfo]::InvariantCulture, $styles, [ref]$activatesAt)) {
            continue
        }
        if ($activatesAt.ToUniversalTime() -le $NowUtc) {
            $due.Add(([string]$parts[1]).Trim().ToLowerInvariant())
        }
    }
    return @($due)
}

function Get-EffectiveHostsBlockDomains {
    $allowDomains = @(Get-AllowDomainList)
    $curated = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($domain in Get-CuratedDomainList) {
        [void]$curated.Add([string]$domain)
    }

    # Faellige Ruecknahmen betreffen ausschliesslich selbst eingetragene
    # Domains; eine kuratierte kann so nicht freigegeben werden.
    $released = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($domain in Get-DueCustomDomainRemovals) {
        if (-not $curated.Contains([string]$domain)) {
            [void]$released.Add([string]$domain)
        }
    }

    return @(Get-DomainList | Where-Object {
        (-not $released.Contains([string]$_)) -and
        ($curated.Contains([string]$_) -or $allowDomains -notcontains $_)
    })
}

function Enable-HostsProtection {
    $domains = @(Get-EffectiveHostsBlockDomains)
    if ($domains.Count -eq 0) {
        # Alles aus oder nur Bereiche ohne Domainliste: der Block bleibt mit
        # genau einem Platzhalter stehen, damit "Block vorhanden = Schicht
        # aktiv" (HostsBlockActive) weiter gilt. .invalid ist reserviert.
        $domains = @($script:HostsPlaceholderDomain)
    }

    $content = Get-HostsRaw
    $cleanContent = Remove-ManagedHostsBlock -Content $content
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add($script:MarkerBegin)
    $lines.Add("# Managed by Purestate. Use the app to remove this block.")

    foreach ($domain in $domains) {
        $lines.Add("0.0.0.0 $domain")
        if (-not $domain.StartsWith("www.") -and $domain -ne $script:HostsPlaceholderDomain) {
            $lines.Add("0.0.0.0 www.$domain")
        }
    }

    $lines.Add($script:MarkerEnd)
    $newContent = ($cleanContent + "`r`n`r`n" + ($lines -join "`r`n") + "`r`n").TrimStart("`r", "`n")
    Set-AsciiTextFile -Path $script:HostsPath -Value $newContent
}

function Disable-HostsProtection {
    $content = Get-HostsRaw
    $cleanContent = Remove-ManagedHostsBlock -Content $content
    Set-AsciiTextFile -Path $script:HostsPath -Value ($cleanContent + "`r`n")
}

# NET-001: Die Auswahl verlangte frueher HardwareInterface -eq $true. Genau
# dieses Merkmal ist bei VPN-, WSL2-, Docker- und Hyper-V-Adaptern $false - also
# bei den Adaptern, ueber die der Verkehr auf solchen Rechnern tatsaechlich
# laeuft. Der DNS-Layer war dort wirkungslos, waehrend die Anzeige "aktiv"
# meldete. Gemeint war "kein Loopback", und das steht jetzt ausdruecklich da:
# ifType 24 ist Software-Loopback (IANA ifType), die Beschreibung faengt
# Pseudoadapter ab, die den Typ nicht sauber melden.
function Get-ManagedAdapters {
    $adapters = Get-NetAdapter -ErrorAction Stop |
        Where-Object {
            $_.Status -eq "Up" -and
            $_.ifType -ne 24 -and
            $_.InterfaceDescription -notmatch "Loopback"
        }

    return @($adapters)
}

# Pure merge: keep every existing backup entry untouched (it holds the true
# pre-enforcement DNS) and append only interface+family pairs not yet backed
# up. This is what lets an adapter that first appears AFTER protection was
# already enforced still get its original DNS captured, so Restore-DnsSettings
# can put it back instead of leaving it on the forced family DNS. Existing
# entries are never overwritten with a (possibly already-forced) current
# reading.
function Merge-DnsBackupItems {
    param(
        [object[]]$Existing = @(),
        [object[]]$Current = @()
    )

    $seen = @{}
    $merged = New-Object System.Collections.Generic.List[object]
    foreach ($group in @(@($Existing), @($Current))) {
        foreach ($item in $group) {
            if ($null -eq $item) { continue }
            $key = "$($item.InterfaceIndex)|$($item.AddressFamily)"
            if (-not $seen.ContainsKey($key)) {
                $seen[$key] = $true
                $merged.Add($item)
            }
        }
    }

    return $merged.ToArray()
}

# NET-002: Alle bekannten Familien-DNS-Adressen, ueber alle drei Profile. Ein
# Adapter, der NUR solche Server traegt, hat keinen sicherungswuerdigen
# Originalzustand mehr - er zeigt bereits das, was Purestate erzwungen hat.
function Get-AllFamilyDnsServers {
    return @(
        @("CloudflareFamily", "CleanBrowsingFamily", "OpenDnsFamilyShield") |
            ForEach-Object { Get-FamilyDnsServers -Profile $_ } |
            Sort-Object -Unique
    )
}

# Wahr nur, wenn ueberhaupt Server gesetzt sind und JEDER davon ein bekannter
# Familien-DNS ist. Ein Mischzustand (eigener Server plus Familien-DNS) wird
# gesichert, denn der eigene Anteil ist echt.
function Test-DnsServersAreEnforced {
    param([string[]]$ServerAddresses)

    $servers = @($ServerAddresses | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($servers.Count -eq 0) {
        return $false
    }

    $known = @(Get-AllFamilyDnsServers)
    foreach ($server in $servers) {
        if ($known -notcontains ([string]$server).Trim()) {
            return $false
        }
    }

    return $true
}

function Backup-DnsSettings {
    Ensure-DataDir

    $existingItems = @()
    if (Test-Path -LiteralPath $script:DnsBackupPath) {
        try {
            $existing = Get-Content -LiteralPath $script:DnsBackupPath -Raw | ConvertFrom-Json
            $existingItems = @($existing.Items)
        } catch {
            # NET-002: Frueher galt der Originalzustand hier als "nie gesichert".
            # Die Wachstumsbedingung unten sah dann jeden Adapter als neu und
            # schrieb den BEREITS ERZWUNGENEN Familien-DNS als vermeintlichen
            # Originalzustand - nach der Deinstallation blieb der Rechner darauf
            # stehen. Die unlesbare Datei wird deshalb beiseitegelegt statt
            # ueberschrieben, und die Schleife unten nimmt erzwungene Server gar
            # nicht erst auf.
            $existingItems = @()
            $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
            $corruptPath = "$($script:DnsBackupPath).corrupt-$stamp"
            try {
                Move-Item -LiteralPath $script:DnsBackupPath -Destination $corruptPath -Force
                Add-SecurityLog "DNS backup unreadable, kept aside as $(Split-Path -Leaf $corruptPath)."
            } catch {
                Add-AppLog "DNS backup unreadable and could not be set aside: $($_.Exception.Message)"
            }
        }
    }

    $current = @()
    foreach ($adapter in Get-ManagedAdapters) {
        foreach ($family in @("IPv4", "IPv6")) {
            try {
                $dns = Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily $family -ErrorAction Stop
                if (Test-DnsServersAreEnforced -ServerAddresses @($dns.ServerAddresses)) {
                    # Hier steht schon der erzwungene Familien-DNS. Ihn zu
                    # sichern hiesse, ihn spaeter "wiederherzustellen".
                    continue
                }
                $current += [pscustomobject]@{
                    InterfaceAlias = $adapter.Name
                    InterfaceIndex = $adapter.ifIndex
                    AddressFamily = $family
                    ServerAddresses = @($dns.ServerAddresses)
                }
            } catch {
                Add-AppLog "DNS backup skipped for $($adapter.Name) $($family): $($_.Exception.Message)"
            }
        }
    }

    $items = @(Merge-DnsBackupItems -Existing $existingItems -Current $current)

    # Only rewrite when the file is new or grew, so repeated enforcement never
    # clobbers the original values with the forced family DNS.
    if (-not (Test-Path -LiteralPath $script:DnsBackupPath) -or $items.Count -gt @($existingItems).Count) {
        # Durable: geht diese Sicherung verloren, bleibt der Rechner nach einer
        # Deinstallation auf dem erzwungenen Familien-DNS stehen.
        Set-DurableFileText -Path $script:DnsBackupPath -Value ([pscustomobject]@{
            CreatedAt = (Get-Date).ToString("o")
            Items = @($items)
        } | ConvertTo-Json -Depth 8)
    }
}

function Enable-DnsProtection {
    param([string]$Profile)

    Backup-DnsSettings
    $servers = @(Get-FamilyDnsServers -Profile $Profile)
    $ipv4Servers = @(Get-FamilyDnsIpv4Servers -Profile $Profile)
    $label = Get-DnsProfileLabel -Profile $Profile

    foreach ($adapter in Get-ManagedAdapters) {
        try {
            Set-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -ServerAddresses $servers -ErrorAction Stop
        } catch {
            try {
                Set-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -ServerAddresses $ipv4Servers -ErrorAction Stop
            } catch {
                Add-AppLog "DNS protection failed for $($adapter.Name) using $($label): $($_.Exception.Message)"
            }
        }
    }

    Add-AppLog "DNS protection enforced with $($label)."
}

# NET-003: Liefert den Index, auf den wiederhergestellt werden darf, oder $null.
# Vorrang hat der Alias (stabil), der gesicherte Index ist der Rueckfall - aber
# nur, solange ihn kein anderer Adapter uebernommen hat.
function Resolve-DnsRestoreInterfaceIndex {
    param(
        [string]$InterfaceAlias,
        [int]$BackupIndex
    )

    $adapters = @()
    try {
        $adapters = @(Get-NetAdapter -ErrorAction Stop)
    } catch {
        # Ohne Adapterliste bleibt nur der gesicherte Index; das ist das
        # Verhalten von vor NET-003 und immer noch besser als gar nichts.
        return $BackupIndex
    }

    if (-not [string]::IsNullOrWhiteSpace($InterfaceAlias)) {
        $byAlias = @($adapters | Where-Object { $_.Name -eq $InterfaceAlias })
        if ($byAlias.Count -gt 0) {
            return [int]$byAlias[0].ifIndex
        }
    }

    # Alias weg: der gesicherte Index taugt nur, wenn ihn niemand sonst traegt.
    $byIndex = @($adapters | Where-Object { [int]$_.ifIndex -eq $BackupIndex })
    if ($byIndex.Count -eq 0) {
        return $BackupIndex
    }

    return $null
}

function Restore-DnsSettings {
    param([switch]$RequireComplete)

    Assert-DataDirectoryIsNotReparsePoint
    if (-not (Test-Path -LiteralPath $script:DnsBackupPath)) {
        # Ohne Sicherung nur zuruecksetzen, was Purestates Familien-DNS traegt.
        # Eigene Server - Pi-hole, NextDNS, ein VPN - hat Purestate nie gesetzt;
        # sie auf automatisch zu stellen hiesse, sie zu loeschen. Nach "alles aus
        # nach der Installation" fehlt die Sicherung meistens.
        $allSucceeded = $true
        foreach ($adapter in Get-ManagedAdapters) {
            try {
                $erzwungen = $false
                foreach ($family in @("IPv4", "IPv6")) {
                    $dns = Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily $family -ErrorAction Stop
                    if (Test-DnsServersAreEnforced -ServerAddresses @($dns.ServerAddresses)) {
                        $erzwungen = $true
                    }
                }
                if (-not $erzwungen) {
                    continue
                }
                Set-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -ResetServerAddresses -ErrorAction Stop
            } catch {
                Add-AppLog "DNS reset failed for $($adapter.Name): $($_.Exception.Message)"
                $allSucceeded = $false
            }
        }

        if ($RequireComplete -and -not $allSucceeded) { throw "DNS reset did not complete." }
        return
    }

    $backup = Get-Content -LiteralPath $script:DnsBackupPath -Raw | ConvertFrom-Json
    $groups = @($backup.Items) | Group-Object -Property InterfaceIndex
    $allSucceeded = $true
    # Ein Adapter, den es gerade nicht gibt - Dock, USB-Netz, WSL, VPN-Tunnel -,
    # haelt die Sicherung fuer die Deinstallation am Leben, macht die Rueckgabe
    # aber nicht unvollstaendig: auf ihm wird nichts durchgesetzt. Zaehlte er
    # fuer -RequireComplete, schriebe die Beta-Freigabe nie ihre Markierung und
    # liefe alle 30 Sekunden erneut.
    $failed = $false
    # Was noch aussteht, bleibt in der Sicherung - und nur das: sonst setzte
    # jede spaetere Rueckgabe die schon zurueckgegebenen Adapter erneut.
    $offen = @()

    foreach ($group in $groups) {
        $backupIndex = [int]$group.Name
        $alias = ""
        $serversWithValues = @()
        $automaticFamilies = @()

        foreach ($entry in @($group.Group)) {
            if (-not $alias) { $alias = [string]$entry.InterfaceAlias }
            $entryServers = @(@($entry.ServerAddresses) | Where-Object { $_ })
            if ($entryServers.Count -gt 0) {
                $serversWithValues += $entryServers
            } else {
                $automaticFamilies += [string]$entry.AddressFamily
            }
        }

        # NET-007: Hier stand "Sort-Object -Unique". Das sortiert ALPHABETISCH
        # als Zeichenkette: aus "192.168.1.10, 10.0.0.1" (primaer, sekundaer)
        # wurde "10.0.0.1, 192.168.1.10". Bei DNS ist die Reihenfolge nicht
        # kosmetisch - der erste Server wird bevorzugt, der zweite ist der
        # Ausfallweg. In einem Firmennetz mit einem internen und einem externen
        # Resolver kann die Vertauschung dazu fuehren, dass interne Namen nicht
        # mehr aufgeloest werden. Die Sortierung erfuellte hier keinen Zweck
        # ausser dem Entdoppeln; das geht auch mit erhaltener Reihenfolge.
        $gesehen = @{}
        $inReihenfolge = @()
        foreach ($server in $serversWithValues) {
            $schluessel = [string]$server
            if (-not $gesehen.ContainsKey($schluessel)) {
                $gesehen[$schluessel] = $true
                $inReihenfolge += $schluessel
            }
        }
        $serversWithValues = @($inReihenfolge)

        # NET-003: ifIndex wechselt bei Treiberwechsel, Docking oder einem neuen
        # virtuellen Adapter. Zuerst ueber den stabilen Alias aufloesen; nur wenn
        # es den nicht mehr gibt, den gesicherten Index benutzen - und auch das
        # nur, wenn ihn inzwischen kein anderer Adapter traegt. Sonst landen die
        # Server des einen Adapters auf einem fremden.
        $interfaceIndex = Resolve-DnsRestoreInterfaceIndex -InterfaceAlias $alias -BackupIndex $backupIndex
        if ($null -eq $interfaceIndex) {
            Add-AppLog "DNS restore skipped for '$alias' (index $backupIndex): adapter not found or index now belongs to another adapter."
            $allSucceeded = $false
            $offen += @($group.Group)
            continue
        }

        try {
            if ($serversWithValues.Count -eq 0) {
                # Every family was on automatic (DHCP): reset both at once.
                Set-DnsClientServerAddress -InterfaceIndex $interfaceIndex -ResetServerAddresses -ErrorAction Stop
            } else {
                # Restore the families that had explicit servers (the cmdlet
                # infers the family per address), then reset any family that was
                # on automatic. Set-DnsClientServerAddress cannot target a single
                # family, so a per-family reset goes through netsh.
                Set-DnsClientServerAddress -InterfaceIndex $interfaceIndex -ServerAddresses $serversWithValues -ErrorAction Stop
                foreach ($family in @($automaticFamilies | Sort-Object -Unique)) {
                    Reset-DnsFamilyToAutomatic -InterfaceAlias $alias -AddressFamily $family
                }
            }
        } catch {
            Add-AppLog "DNS restore failed for interface $($interfaceIndex): $($_.Exception.Message)"
            $allSucceeded = $false
            $offen += @($group.Group)
            # Resolve-DnsRestoreInterfaceIndex liefert fuer einen verschwundenen
            # Alias den alten Index; das Fehlen zeigt sich erst hier.
            if (Get-NetIPInterface -InterfaceIndex $interfaceIndex -ErrorAction SilentlyContinue) {
                $failed = $true
            }
        }
    }

    # Keep the backup unless every interface restored cleanly, so a partial
    # failure can be retried instead of losing the original configuration.
    if ($allSucceeded) {
        Remove-Item -LiteralPath $script:DnsBackupPath -Force -ErrorAction SilentlyContinue
    } else {
        Add-AppLog "DNS backup kept because at least one interface could not be fully restored."
        if ($offen.Count -lt @($backup.Items).Count) {
            Set-DurableFileText -Path $script:DnsBackupPath -Value ([pscustomobject]@{
                CreatedAt = $backup.CreatedAt
                Items = @($offen)
            } | ConvertTo-Json -Depth 8)
        }
    }
    if ($RequireComplete -and $failed) {
        throw "DNS restore did not complete."
    }
}

# Wahr, sobald ein Adapter aus der DNS-Sicherung wieder da ist. Nur dann lohnt
# nach der Beta-Freigabe eine Rueckgabe - sonst schriebe jeder Takt dieselbe
# Fehlerzeile.
function Test-DnsBackupHasPresentAdapter {
    try {
        $backup = Get-Content -LiteralPath $script:DnsBackupPath -Raw | ConvertFrom-Json
        foreach ($group in @($backup.Items) | Group-Object -Property InterfaceIndex) {
            $alias = [string]@($group.Group)[0].InterfaceAlias
            $index = Resolve-DnsRestoreInterfaceIndex -InterfaceAlias $alias -BackupIndex ([int]$group.Name)
            if ($null -ne $index -and (Get-NetIPInterface -InterfaceIndex $index -ErrorAction SilentlyContinue)) {
                return $true
            }
        }
    } catch {
    }
    return $false
}

function Reset-DnsFamilyToAutomatic {
    param(
        [string]$InterfaceAlias,
        [string]$AddressFamily
    )

    if ([string]::IsNullOrWhiteSpace($InterfaceAlias)) {
        return
    }

    $context = if ($AddressFamily -match "6") { "ipv6" } else { "ipv4" }
    $netsh = Get-SystemToolPath -Name "netsh.exe"
    & $netsh "interface" $context "set" "dnsservers" ("name=" + $InterfaceAlias) "source=dhcp" | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "netsh konnte $context-DNS fuer '$InterfaceAlias' nicht auf automatisch zuruecksetzen (Exit $LASTEXITCODE)."
    }
}

function Get-CurrentProcessSid {
    try {
        return [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    } catch {
        return ""
    }
}

function Get-ProxyInternetSettingsPath {
    # HKCU is correct when the interactive (elevated) user runs enforcement, but
    # when the guard/watchdog runs as SYSTEM, HKCU is SYSTEM's own hive - not the
    # person using the PC. Resolve the interactive user's loaded hive in that
    # case. Returns $null when running as SYSTEM and the user cannot be resolved,
    # so callers skip rather than edit the wrong account's proxy settings.
    $suffix = "Software\Microsoft\Windows\CurrentVersion\Internet Settings"

    $currentSid = $null
    try {
        $currentSid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    } catch {
    }

    if ($currentSid -ne "S-1-5-18") {
        return "HKCU:\$suffix"
    }

    try {
        $userName = (Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop).UserName
        if ([string]::IsNullOrWhiteSpace($userName)) {
            return $null
        }
        $account = New-Object System.Security.Principal.NTAccount($userName)
        $sid = $account.Translate([System.Security.Principal.SecurityIdentifier]).Value
        if ([string]::IsNullOrWhiteSpace($sid) -or -not (Test-Path -LiteralPath "Registry::HKEY_USERS\$sid")) {
            return $null
        }
        return "Registry::HKEY_USERS\$sid\$suffix"
    } catch {
        return $null
    }
}

# NET-005: Es gab genau einen Sicherungsslot fuer die ganze Maschine,
# abgeschaltet wird der Proxy aber beim GERADE angemeldeten Nutzer. Auf einem
# Familienrechner verlor damit jeder weitere Nutzer seine Netzwerkeinstellungen,
# ohne dass es je eine Sicherung davon gab. Der Slot haengt deshalb am Hive.
function Get-ProxyBackupSlotPath {
    param([string]$RegistryPath)

    $sid = ""
    $treffer = [regex]::Match([string]$RegistryPath, '^Registry::HKEY_USERS\\([^\\]+)\\')
    if ($treffer.Success) {
        $sid = $treffer.Groups[1].Value
    } else {
        try {
            $sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
        } catch {
        }
    }

    if ([string]::IsNullOrWhiteSpace($sid)) {
        return $script:ProxyBackupPath
    }

    return Join-Path ([System.IO.Path]::GetDirectoryName($script:ProxyBackupPath)) ("proxy-backup-" + $sid + ".json")
}

function Get-ProxyBackupFiles {
    $ordner = [System.IO.Path]::GetDirectoryName($script:ProxyBackupPath)
    if (-not (Test-Path -LiteralPath $ordner)) {
        return @()
    }
    return @(Get-ChildItem -LiteralPath $ordner -Filter "proxy-backup*.json" -File -ErrorAction SilentlyContinue)
}

function Backup-ProxySettings {
    Ensure-DataDir

    $path = Get-ProxyInternetSettingsPath
    if (-not $path) {
        Add-AppLog "Proxy backup skipped: interactive user hive could not be resolved."
        return
    }

    $backupPath = Get-ProxyBackupSlotPath -RegistryPath $path
    if (Test-Path -LiteralPath $backupPath) {
        return
    }

    # Eine Sicherung im alten Dateinamen deckt diesen Hive schon ab; sonst
    # entstuende ein zweiter Slot fuer denselben Nutzer.
    if ((Test-Path -LiteralPath $script:ProxyBackupPath) -and $backupPath -ne $script:ProxyBackupPath) {
        try {
            $vorhanden = Get-Content -LiteralPath $script:ProxyBackupPath -Raw | ConvertFrom-Json
            if ([string]$vorhanden.RegistryPath -eq [string]$path) {
                return
            }
        } catch {
        }
    }

    $properties = @("ProxyEnable", "ProxyServer", "ProxyOverride", "AutoConfigURL", "AutoDetect")
    $items = @()

    try {
        $key = Get-ItemProperty -Path $path -ErrorAction SilentlyContinue
        foreach ($name in $properties) {
            $value = $null
            $hasValue = $false
            if ($null -ne $key -and $null -ne $key.PSObject.Properties[$name]) {
                $value = $key.PSObject.Properties[$name].Value
                $hasValue = $true
            }

            $kind = "String"
            if ($name -eq "ProxyEnable" -or $name -eq "AutoDetect") {
                $kind = "DWord"
            }

            $items += [pscustomobject]@{
                Name = $name
                HasValue = $hasValue
                Kind = $kind
                Value = [string]$value
            }
        }
    } catch {
        Add-AppLog "Proxy backup failed: $($_.Exception.Message)"
    }

    # NET-004: Haltbar schreiben wie die DNS-Sicherung seit 0.62.65. Geht diese
    # Datei verloren oder bleibt sie abgeschnitten, kommt der Nutzer nie wieder
    # an seine Proxy-Einstellungen - waehrend die Durchsetzung sie alle
    # 30 Sekunden weiter auf 0 setzt.
    Set-DurableFileText -Path $backupPath -Value ([pscustomobject]@{
        CreatedAt = (Get-Date).ToString("o")
        RegistryPath = $path
        Items = $items
    } | ConvertTo-Json -Depth 8)
}

function Disable-WindowsProxy {
    Backup-ProxySettings

    $path = Get-ProxyInternetSettingsPath
    if (-not $path) {
        Add-AppLog "Proxy disable skipped: interactive user hive could not be resolved."
        return
    }
    try {
        Ensure-RegistryKey -Path $path
        # Nur schreiben und protokollieren, wenn wirklich etwas abweicht: der
        # Durchsetzungslauf kommt alle 30 Sekunden wieder und hat das Protokoll
        # sonst mit Meldungen ueber unveraenderte Werte gefuellt (Befund L-12).
        $key = Get-ItemProperty -Path $path -ErrorAction SilentlyContinue
        $changed = $false

        foreach ($name in @("ProxyEnable", "AutoDetect")) {
            $current = $null
            if ($null -ne $key -and $null -ne $key.PSObject.Properties[$name]) {
                $current = $key.PSObject.Properties[$name].Value
            }
            if ($current -ne 0) {
                New-ItemProperty -Path $path -Name $name -Value 0 -PropertyType DWord -Force | Out-Null
                $changed = $true
            }
        }

        foreach ($name in @("ProxyServer", "ProxyOverride", "AutoConfigURL")) {
            if ($null -ne $key -and $null -ne $key.PSObject.Properties[$name]) {
                Remove-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue
                $changed = $true
            }
        }

        if ($changed) {
            Add-AppLog "Windows proxy settings disabled while protection is active."
        }
    } catch {
        Add-AppLog "Windows proxy disable failed: $($_.Exception.Message)"
    }
}

function Restore-WindowsProxy {
    param([switch]$RequireComplete)

    Assert-DataDirectoryIsNotReparsePoint
    foreach ($datei in Get-ProxyBackupFiles) {
        Restore-ProxyBackupFile -BackupFile $datei.FullName -RequireComplete:$RequireComplete
    }
}

# Wohin eine Proxy-Sicherung zurueckgehoert. Installer und App sichern als
# Nutzer und speichern dabei "HKCU:\...". Als SYSTEM - der Waechter bei der
# Beta-Freigabe - waere HKCU der Hive von SYSTEM: die Rueckgabe "gelaenge"
# dort, die Sicherung waere weg, und der Nutzer bliebe auf dem erzwungenen
# Proxy. Wem die Sicherung gehoert, steht im Dateinamen
# (Get-ProxyBackupSlotPath). Ohne gespeicherten Pfad gilt der angemeldete Nutzer.
function Resolve-ProxyBackupRegistryPath {
    param([string]$RegistryPath, [string]$BackupFile)

    if ([string]::IsNullOrWhiteSpace($RegistryPath)) {
        return Get-ProxyInternetSettingsPath
    }
    if ($RegistryPath.StartsWith("HKCU:\", [StringComparison]::OrdinalIgnoreCase) -and (Get-CurrentProcessSid) -eq "S-1-5-18") {
        $eigentuemer = [regex]::Match([System.IO.Path]::GetFileName($BackupFile), '^proxy-backup-(S-[0-9-]+)\.json$')
        if ($eigentuemer.Success) {
            return "Registry::HKEY_USERS\" + $eigentuemer.Groups[1].Value + "\" + $RegistryPath.Substring(6)
        }
        return Get-ProxyInternetSettingsPath
    }
    return $RegistryPath
}

# Ob eine Proxy-Sicherung jetzt zurueckgegeben werden kann: der Hive ihres
# Kontos ist geladen. Nach der Beta-Freigabe wird nur das abgefragt, damit ein
# abgemeldetes Konto nicht in jedem Takt eine Fehlerzeile erzeugt.
function Test-ProxyBackupHiveLoaded {
    param([string]$BackupFile)

    try {
        $backup = Get-Content -LiteralPath $BackupFile -Raw | ConvertFrom-Json
        $path = Resolve-ProxyBackupRegistryPath -RegistryPath ([string]$backup.RegistryPath) -BackupFile $BackupFile
        if (-not $path) {
            return $false
        }
        if ($path -like "Registry::HKEY_USERS\*") {
            return (Test-Path -LiteralPath (($path -split '\\')[0..1] -join '\'))
        }
        return $true
    } catch {
        return $false
    }
}

# NET-004: Eine unlesbare Sicherung liess den Nutzer bisher im Zwangszustand
# stehen - der Wiederherstellungsversuch scheiterte beim Parsen, die Datei blieb
# liegen und der naechste Versuch scheiterte genauso, waehrend die Durchsetzung
# den Proxy weiter abschaltete. Sie wird deshalb beiseitegelegt und die
# Registrywerte gehen auf den Windows-Standard zurueck, nicht auf Purestates
# Zwangswerte.
function Restore-ProxyBackupFile {
    param([string]$BackupFile, [switch]$RequireComplete)

    if (-not (Test-Path -LiteralPath $BackupFile)) {
        return
    }

    $backup = $null
    try {
        $backup = Get-Content -LiteralPath $BackupFile -Raw | ConvertFrom-Json
    } catch {
        Add-AppLog "Proxy backup is unreadable: $($_.Exception.Message)"
    }

    if ($null -eq $backup) {
        $beiseite = "$BackupFile.corrupt-" + (Get-Date).ToString("yyyyMMddHHmmss")
        try {
            Move-Item -LiteralPath $BackupFile -Destination $beiseite -Force -ErrorAction Stop
        } catch {
            if ($RequireComplete) { throw }
        }
        Reset-WindowsProxyToDefaults -RequireComplete:$RequireComplete
        return
    }

    $succeeded = $true
    try {
        # Restore into the same hive the backup was taken from; fall back to the
        # resolved interactive-user hive for backups written before this field.
        $path = Resolve-ProxyBackupRegistryPath -RegistryPath ([string]$backup.RegistryPath) -BackupFile $BackupFile
        if (-not $path) {
            Add-AppLog "Proxy restore skipped: target hive could not be resolved; backup kept."
            if ($RequireComplete) { throw "Proxy target hive could not be resolved." }
            return
        }

        # Die Sicherung eines anderen, gerade nicht angemeldeten Kontos: sein
        # Hive ist nicht geladen. Fuer -RequireComplete kein Fehler, sonst hinge
        # die Beta-Freigabe, bis sich genau dieses Konto anmeldet. Ist niemand
        # angemeldet, wird dagegen gewartet - dann koennte es der Tester selbst
        # sein. Die Sicherung bleibt fuer die Deinstallation.
        if ($RequireComplete -and $path -like "Registry::HKEY_USERS\*") {
            $hive = ($path -split '\\')[0..1] -join '\'
            if (-not (Test-Path -LiteralPath $hive) -and (Get-ProxyInternetSettingsPath)) {
                Add-AppLog "Proxy restore deferred: the account's hive is not loaded; backup kept."
                return
            }
        }

        Ensure-RegistryKey -Path $path
        foreach ($entry in @($backup.Items)) {
            $name = [string]$entry.Name
            if ([string]::IsNullOrWhiteSpace($name)) {
                continue
            }

            if (-not [bool]$entry.HasValue) {
                if (-not $RequireComplete -or (Get-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue)) {
                    Remove-ItemProperty -Path $path -Name $name -ErrorAction $(if ($RequireComplete) { "Stop" } else { "SilentlyContinue" })
                }
                continue
            }

            if ([string]$entry.Kind -eq "DWord") {
                $number = 0
                [int]::TryParse([string]$entry.Value, [ref]$number) | Out-Null
                New-ItemProperty -Path $path -Name $name -Value $number -PropertyType DWord -Force | Out-Null
            } else {
                New-ItemProperty -Path $path -Name $name -Value ([string]$entry.Value) -PropertyType String -Force | Out-Null
            }
        }
    } catch {
        Add-AppLog "Windows proxy restore failed: $($_.Exception.Message)"
        $succeeded = $false
    }

    # Keep the backup if the restore did not complete, so it can be retried.
    if ($succeeded) {
        Remove-Item -LiteralPath $BackupFile -Force -ErrorAction SilentlyContinue
    } else {
        Add-AppLog "Proxy backup kept because restore did not complete."
    }
    if ($RequireComplete -and (-not $succeeded -or (Test-Path -LiteralPath $BackupFile))) {
        throw "Proxy restore did not complete."
    }
}

# Der Auslieferungszustand von Windows: kein fester Proxy, automatische Suche
# an. Purestates Zwangszustand hat AutoDetect auf 0 - wer darauf stehen bleibt,
# hat kein Netz und keinen Hinweis warum.
function Reset-WindowsProxyToDefaults {
    param([switch]$RequireComplete)

    $path = Get-ProxyInternetSettingsPath
    if (-not $path) {
        Add-AppLog "Proxy reset to Windows defaults skipped: target hive could not be resolved."
        if ($RequireComplete) { throw "Proxy target hive could not be resolved." }
        return
    }

    try {
        Ensure-RegistryKey -Path $path
        New-ItemProperty -Path $path -Name "ProxyEnable" -Value 0 -PropertyType DWord -Force | Out-Null
        New-ItemProperty -Path $path -Name "AutoDetect" -Value 1 -PropertyType DWord -Force | Out-Null
        foreach ($name in @("ProxyServer", "ProxyOverride", "AutoConfigURL")) {
            if (-not $RequireComplete -or (Get-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue)) {
                Remove-ItemProperty -Path $path -Name $name -ErrorAction $(if ($RequireComplete) { "Stop" } else { "SilentlyContinue" })
            }
        }
        Add-AppLog "Proxy settings reset to Windows defaults because the backup was unreadable."
    } catch {
        Add-AppLog "Proxy reset to Windows defaults failed: $($_.Exception.Message)"
        if ($RequireComplete) { throw }
    }
}

function Get-NsfwSubreddits {
    $path = Join-Path (Get-AppRoot) "rules\nsfw-subreddits.txt"
    $names = @()

    if (-not (Test-Path -LiteralPath $path)) {
        return @()
    }

    foreach ($raw in Get-Content -LiteralPath $path) {
        $line = ([string]$raw).Trim().ToLowerInvariant()
        if ($line.Length -eq 0 -or $line.StartsWith("#")) {
            continue
        }

        $line = $line -replace "^/r/", ""
        $line = $line -replace "^r/", ""
        if ($line -notmatch "^[a-z0-9_]{2,32}$") {
            continue
        }

        if ($names -notcontains $line) {
            $names += $line
        }

        if ($names.Count -ge 180) {
            break
        }
    }

    return @($names)
}

function Add-RedditSubredditPatterns {
    param(
        [ref]$Patterns,
        [string[]]$Subreddits,
        [hashtable]$SiteSettings = $null
    )

    # Two forms cover every consumer: the bare host matches all subdomains in the
    # Chromium URLBlocklist format (implicit subdomain matching), and the
    # *.reddit.com match pattern covers host + subdomains for the Firefox
    # WebsiteFilter. The old explicit www./old./new. templates were redundant
    # and burned 3 of the 1000 Chromium rule slots per subreddit.
    $templates = @(
        "*://reddit.com/r/{0}*",
        "*://*.reddit.com/r/{0}*"
    )

    foreach ($subreddit in $Subreddits) {
        foreach ($template in $templates) {
            Add-MixedSitePattern -Patterns $Patterns -Pattern ($template -f $subreddit) -SiteSettings $SiteSettings

            if ($Patterns.Value.Count -ge 1000) {
                return
            }
        }
    }
}

# RGL-001: Laeuft das Musterbudget aus, fehlen ab da Regeln - bisher lautlos.
# Eine Zeile ins Anwendungsprotokoll macht "Regeln passen nicht mehr" ueberhaupt
# erst bemerkbar.
function Write-MixedSitePatternBudgetLog {
    Add-AppLog "Mixed-site URL pattern budget of 1000 exhausted; later rules were not generated."
}

# RGL-004: Die ausgelieferte Datei hat 144 Zeilen und besteht die Pruefung
# vollstaendig. Das Kontingent laesst also reichlich Luft nach oben und deckelt
# nur den Fall, dass die Datei entgleist.
$script:MixedSiteFileQuota = 400
$script:MixedSitePatternMaxLength = 200

function Test-MixedSitePatternLine {
    param([string]$Line)

    $line = ([string]$Line).Trim()
    if ($line.Length -eq 0 -or $line.StartsWith("#")) {
        return $false
    }

    if ($line.Length -gt $script:MixedSitePatternMaxLength) {
        return $false
    }

    return ($line.IndexOf("://", [StringComparison]::OrdinalIgnoreCase) -ge 0) -or $line.StartsWith("<")
}

function Get-MixedSiteUrlPatterns {
    # Bereich aus heisst keine Muster - dieselbe Regel wie beim Hauptschalter
    # (Spec 2.4).
    if (-not [bool](Get-Config).AdultContentProtectionEnabled) {
        return @()
    }

    $path = Join-Path (Get-AppRoot) "rules\mixed-site-url-patterns.txt"
    $keywords = Get-AdultUrlKeywords
    $nsfwSubreddits = Get-NsfwSubreddits
    $patterns = @()

    # RGL-002: einmal lesen und durchreichen, damit abgeschaltete Bereiche gar
    # keine Plaetze mehr belegen. Der nachgelagerte Filter an den Rueckgabe-
    # punkten bleibt als Netz stehen.
    $siteSettings = Get-SiteProtectionSettings

    if (Test-Path -LiteralPath $path) {
        # RGL-004: Diese Datei war die ERSTE Quelle und durfte unbegrenzt und
        # ungeprueft schoepfen - jede Zeile, die nicht leer und kein Kommentar
        # war. 1000 Muellzeilen am Dateianfang haetten damit die gesamte
        # Erwachsenen-Kernabdeckung verdraengt, und der Diagnosezaehler in
        # NativeSupportPackage.cs haette es nicht gemeldet, weil er dieselbe
        # Datei schaerfer liest und die verdraengte Kernabdeckung trotzdem
        # mitzaehlt. Zwei Leser derselben Datei mit verschiedenen Regeln, und
        # die massgebliche Seite war die laxere. Jetzt dieselbe Pruefung wie im
        # Spiegel, plus ein Kontingent.
        $ausDerDatei = 0
        foreach ($raw in Get-Content -LiteralPath $path) {
            $line = ([string]$raw).Trim()
            if (-not (Test-MixedSitePatternLine -Line $line)) {
                continue
            }

            if ($ausDerDatei -ge $script:MixedSiteFileQuota) {
                break
            }

            $ausDerDatei++
            Add-MixedSitePattern -Patterns ([ref]$patterns) -Pattern $line -SiteSettings $siteSettings
        }
    }

    Add-CoreAdultCoveragePatterns -Patterns ([ref]$patterns) -SiteSettings $siteSettings
    if ($patterns.Count -ge 1000) {
        Write-MixedSitePatternBudgetLog
        return @(Filter-MixedSitePatternsBySiteProtection -Patterns $patterns)
    }

    Add-RedditSubredditPatterns -Patterns ([ref]$patterns) -Subreddits $nsfwSubreddits -SiteSettings $siteSettings
    if ($patterns.Count -ge 1000) {
        Write-MixedSitePatternBudgetLog
        return @(Filter-MixedSitePatternsBySiteProtection -Patterns $patterns)
    }

    # Each route ships as a bare-host form (Chromium URLBlocklist: implicit
    # subdomain matching) plus a *.host match pattern (Firefox WebsiteFilter).
    # The old explicit old.reddit.com templates were redundant with *.reddit.com.
    $priorityTemplates = @(
        "*://reddit.com/r/*{0}*",
        "*://*.reddit.com/r/*{0}*",
        "*://reddit.com/search*{0}*",
        "*://*.reddit.com/search*{0}*",
        "*://twitter.com/search*{0}*",
        "*://*.twitter.com/search*{0}*",
        "*://twitter.com/hashtag/*{0}*",
        "*://*.twitter.com/hashtag/*{0}*",
        "*://x.com/search*{0}*",
        "*://*.x.com/search*{0}*",
        "*://x.com/hashtag/*{0}*",
        "*://*.x.com/hashtag/*{0}*",
        "*://bsky.app/search*{0}*",
        "*://bsky.app/hashtag/*{0}*"
    )

    $secondaryTemplates = @(
        "*://*.tumblr.com/tagged/*{0}*",
        "*://*.tumblr.com/search/*{0}*",
        "*://www.google.*/search*{0}*",
        "*://www.bing.com/search*{0}*",
        "*://www.bing.com/images/search*{0}*",
        "*://www.bing.com/videos/search*{0}*",
        "*://duckduckgo.com/*q=*{0}*",
        "*://search.brave.com/search*{0}*",
        "*://search.yahoo.com/search*{0}*",
        "*://*.search.yahoo.com/search*{0}*",
        "*://yandex.com/search*{0}*",
        "*://yandex.com/images/search*{0}*",
        "*://www.ecosia.org/search*{0}*",
        "*://www.startpage.com/sp/search*{0}*",
        "*://www.qwant.com/*q=*{0}*",
        "*://metager.org/meta/*{0}*",
        "*://www.youtube.com/results*{0}*",
        "*://www.youtube.com/hashtag/*{0}*",
        "*://www.tiktok.com/search*{0}*",
        "*://www.tiktok.com/tag/*{0}*",
        "*://www.instagram.com/explore/tags/*{0}*",
        "*://www.instagram.com/explore/search*{0}*",
        "*://*.pinterest.*/search/pins/*{0}*",
        "*://imgur.com/search*{0}*",
        "*://imgur.com/t/*{0}*",
        "*://giphy.com/search/*{0}*"
    )

    # RGL-001: Die Schleifen liefen frueher Stichwort-aussen/Vorlage-innen. Weil
    # die drei vorherigen Quellen schon 824 der 1000 Plaetze belegen, bekamen die
    # ersten zwoelf Stichwoerter alle vierzehn Vorlagen - und die restlichen 87
    # gar keine. Welche durchkamen, entschied das Alphabet: "bareback" ja,
    # "porn", "hentai", "nude", "onlyfans", "chaturbate" nein, also genau die
    # Begriffe, fuer die die Datei angelegt wurde.
    #
    # Vorlage aussen, Stichwort innen: jetzt bekommt jedes Stichwort seine erste
    # Route, bevor irgendeines die zweite bekommt. Laeuft das Budget aus, fehlt
    # allen die Vertiefung statt einigen die Sperre.
    foreach ($template in $priorityTemplates) {
        foreach ($keyword in $keywords) {
            Add-MixedSitePattern -Patterns ([ref]$patterns) -Pattern ($template -f $keyword) -SiteSettings $siteSettings

            if ($patterns.Count -ge 1000) {
                Write-MixedSitePatternBudgetLog
                return @(Filter-MixedSitePatternsBySiteProtection -Patterns $patterns)
            }
        }
    }

    foreach ($template in $secondaryTemplates) {
        foreach ($keyword in $keywords) {
            Add-MixedSitePattern -Patterns ([ref]$patterns) -Pattern ($template -f $keyword) -SiteSettings $siteSettings

            if ($patterns.Count -ge 1000) {
                Write-MixedSitePatternBudgetLog
                return @(Filter-MixedSitePatternsBySiteProtection -Patterns $patterns)
            }
        }
    }

    return @(Filter-MixedSitePatternsBySiteProtection -Patterns $patterns)
}

function Get-CoreAdultUrlKeywords {
    return @(
        "nsfw",
        "porn",
        "porno",
        "hentai",
        "nude",
        "nudes",
        "naked",
        "onlyfans",
        "fansly",
        "redgifs",
        "rule34",
        "r34",
        "xxx",
        "xvideos",
        "xnxx",
        "blowjob",
        "boobs",
        "tits",
        "pussy",
        "cock",
        "dick",
        "cum",
        "milf",
        "gonewild"
    )
}

function Get-CoreAdultCoverageTemplates {
    return @(
        "*://www.google.*/search*{0}*",
        "*://www.bing.com/search*{0}*",
        "*://www.bing.com/images/search*{0}*",
        "*://www.bing.com/videos/search*{0}*",
        "*://duckduckgo.com/*q=*{0}*",
        "*://search.brave.com/search*{0}*",
        "*://search.yahoo.com/search*{0}*",
        "*://*.search.yahoo.com/search*{0}*",
        "*://yandex.com/search*{0}*",
        "*://yandex.com/images/search*{0}*",
        "*://www.ecosia.org/search*{0}*",
        "*://www.startpage.com/sp/search*{0}*",
        "*://www.qwant.com/*q=*{0}*",
        "*://metager.org/meta/*{0}*",
        "*://www.youtube.com/results*{0}*",
        "*://www.youtube.com/hashtag/*{0}*",
        "*://www.tiktok.com/search*{0}*",
        "*://www.tiktok.com/tag/*{0}*",
        "*://www.instagram.com/explore/tags/*{0}*",
        "*://*.pinterest.*/search/pins/*{0}*",
        "*://giphy.com/search/*{0}*"
    )
}

function Add-CoreAdultCoveragePatterns {
    param(
        [ref]$Patterns,
        [hashtable]$SiteSettings = $null
    )

    foreach ($keyword in Get-CoreAdultUrlKeywords) {
        foreach ($template in Get-CoreAdultCoverageTemplates) {
            Add-MixedSitePattern -Patterns $Patterns -Pattern ($template -f $keyword) -SiteSettings $SiteSettings
        }
    }
}

function Get-AdultUrlKeywords {
    $path = Join-Path (Get-AppRoot) "rules\adult-url-keywords.txt"
    $keywords = @()

    if (-not (Test-Path -LiteralPath $path)) {
        return @()
    }

    foreach ($raw in Get-Content -LiteralPath $path) {
        $line = ([string]$raw).Trim().ToLowerInvariant()
        if ($line.Length -eq 0 -or $line.StartsWith("#")) {
            continue
        }

        if ($line -notmatch "^[a-z0-9-]{3,32}$") {
            continue
        }

        if ($keywords -notcontains $line) {
            $keywords += $line
        }

        # RGL-006: Der Deckel lag bei 100, und die ausgelieferte Datei hat
        # GENAU 100 gueltige Zeilen - er ist also erreicht, nicht bald
        # erreicht. Der 101. Eintrag wurde nicht gelesen, nicht gemeldet, nicht
        # protokolliert, waehrend README.txt weiter sagt, man koenne Begriffe
        # ergaenzen. Der Deckel schuetzt nur vor einer entgleisten Datei; wie
        # viele Muster daraus werden, begrenzt ohnehin Add-MixedSitePattern.
        # Also hoeher - und wenn er doch greift, sagt er es.
        if ($keywords.Count -ge $script:MaxAdultUrlKeywords) {
            Add-AppLog "Stichwortdatei abgeschnitten: mehr als $($script:MaxAdultUrlKeywords) gueltige Zeilen in rules\adult-url-keywords.txt, der Rest wird nicht gelesen."
            break
        }
    }

    return @($keywords)
}

function Get-GamblingUrlKeywords {
    $path = Join-Path (Get-AppRoot) "rules\gambling-url-keywords.txt"
    $keywords = @()

    if (-not (Test-Path -LiteralPath $path)) {
        return @()
    }

    foreach ($raw in Get-Content -LiteralPath $path) {
        $line = ([string]$raw).Trim().ToLowerInvariant()
        if ($line.Length -eq 0 -or $line.StartsWith("#")) {
            continue
        }

        if ($line -match "^[a-z0-9-]{3,32}$" -and $keywords -notcontains $line) {
            $keywords += $line
        }

        if ($keywords.Count -ge 40) {
            break
        }
    }

    return @($keywords)
}

function Add-MixedSitePattern {
    param(
        [ref]$Patterns,
        [string]$Pattern,
        [hashtable]$SiteSettings = $null
    )

    if ($Patterns.Value.Count -ge 1000) {
        return
    }

    # RGL-002: Der Bereichsfilter lief frueher NACH dem Deckel. Muster eines
    # abgeschalteten Bereichs wurden also erzeugt, belegten ihre Plaetze,
    # verdraengten andere ueber die 1000er-Grenze - und wurden danach verworfen.
    # Reddit aus kostete so 292 Plaetze, die niemand nachfuellte. Deshalb hier,
    # beim Erzeugen. Die Einstellungen werden durchgereicht, weil
    # Get-SiteProtectionSettings die Konfiguration liest und pro Muster ein
    # Dateizugriff waere.
    if ($null -ne $SiteSettings) {
        $site = Get-PatternSiteKey -Pattern $Pattern
        if ($site -and $SiteSettings.ContainsKey($site) -and -not $SiteSettings[$site]) {
            return
        }
    }

    if ($Patterns.Value -notcontains $Pattern) {
        $Patterns.Value += $Pattern
    }
}

function Set-PolicyStringList {
    param(
        [string]$Path,
        [string]$ListName,
        [string[]]$Values
    )

    $listPath = Join-Path $Path $ListName

    if ($Values.Count -eq 0) {
        Remove-Item -Path $listPath -Recurse -Force -ErrorAction SilentlyContinue
        return
    }

    # Den Schluessel NICHT loeschen und neu anlegen. Haelt ein anderer Prozess
    # noch ein Handle darauf - Gruppenrichtlinien-Dienst, laufender Browser -,
    # steht er danach als "pending deletion" da: New-Item meldet Erfolg, das
    # anschliessende Schreiben der Werte scheitert mit "Pfad nicht gefunden".
    # Genau das stand am 2026-07-31 im activity.log fuer Edge (URLBlocklist)
    # und Firefox (WebsiteFilter\Block), waehrend die Liste kurz darauf
    # trotzdem gefuellt war.
    #
    # -Force legt fehlende Zwischenschluessel an (Firefox' ListName
    # "WebsiteFilter\Block" ueberspannt einen auf einer Maschine ohne
    # vorherige Richtlinien).
    if (-not (Test-Path -LiteralPath $listPath)) {
        New-Item -Path $listPath -Force | Out-Null
    }

    # POL-005: Frueher wurde jeder Wert bei jedem Durchsetzungslauf neu
    # geschrieben - bei Chrome und Edge zusammen rund 2000 Registry-Vorgaenge
    # alle 30 Sekunden, obwohl sich fast nie etwas aendert. Der Ist-Stand kostet
    # einen Lesevorgang; stimmt er ueberein, ist nichts zu tun.
    $istStand = @(Get-PolicyStringListValues -Path $listPath)
    if ($istStand.Count -eq $Values.Count) {
        $gleich = $true
        for ($i = 0; $i -lt $Values.Count; $i++) {
            if (-not [string]::Equals($istStand[$i], $Values[$i], [StringComparison]::Ordinal)) {
                $gleich = $false
                break
            }
        }
        if ($gleich) {
            return
        }
    }

    # Muss geschrieben werden, dann nur die abweichenden Nummern.
    for ($i = 0; $i -lt $Values.Count; $i++) {
        if ($i -lt $istStand.Count -and [string]::Equals($istStand[$i], $Values[$i], [StringComparison]::Ordinal)) {
            continue
        }
        New-ItemProperty -Path $listPath -Name ([string]($i + 1)) -Value $Values[$i] -PropertyType String -Force | Out-Null
    }

    # Ueberzaehlige Nummern aus einem frueheren, laengeren Stand entfernen.
    # Ohne das bliebe nach einer kuerzeren Liste ein Rest stehen.
    $key = Get-Item -LiteralPath $listPath -ErrorAction SilentlyContinue
    if ($key) {
        foreach ($name in @($key.GetValueNames())) {
            if ($name -match '^\d+$' -and [int]$name -gt $Values.Count) {
                Remove-ItemProperty -LiteralPath $listPath -Name $name -Force -ErrorAction SilentlyContinue
            }
        }
    }
}

function Get-PolicyStringListValues {
    param([string]$Path)

    $key = Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
    if (-not $key) {
        return @()
    }

    $entries = @()
    foreach ($name in $key.GetValueNames()) {
        if ($name -match '^\d+$') {
            $entries += [pscustomobject]@{
                Index = [int]$name
                Value = [string]$key.GetValue($name)
            }
        }
    }
    return @($entries | Sort-Object Index | ForEach-Object { $_.Value })
}

function Get-ManagedListRecord {
    Assert-DataDirectoryIsNotReparsePoint
    if (-not (Test-Path -LiteralPath $script:ManagedListRecordPath)) {
        return @{}
    }
    try {
        $parsed = Get-Content -Raw -LiteralPath $script:ManagedListRecordPath | ConvertFrom-Json
        $record = @{}
        foreach ($prop in $parsed.PSObject.Properties) {
            $record[$prop.Name] = @($prop.Value)
        }
        return $record
    } catch {
        return @{}
    }
}

# POL-006: Dieser Datensatz haelt fest, welche Eintraege Purestate in die
# geteilte Browser-Sperrliste geschrieben hat - geht er verloren, bleiben genau
# diese Eintraege beim Abschalten oder Deinstallieren stehen. Geschrieben wurde
# er mit Set-Content: das kuerzt die Zieldatei zuerst und schreibt dann, ein
# Abbruch dazwischen laesst sie leer oder halb. Und ein Fehlschlag verschwand
# im leeren catch, also ohne jede Spur.
#
# Es gibt eine Rueckfallebene (Remove-PurestateManagedUrlList faellt
# inhaltsbasiert nach), aber die ist ihrerseits gedeckelt (POL-004) - beide
# zusammen sind der Grund, warum Purestate-Eintraege Deinstallationen
# ueberlebt haben.
function Save-ManagedListRecord {
    param([hashtable]$Record)

    try {
        Ensure-DataDir
        # Set-TextFileAtomically gibt es im Projekt schon: Temporaerdatei,
        # FlushFileBuffers, dann Replace - und es raeumt die Temporaerdatei bei
        # einem Fehlschlag selbst weg.
        Set-TextFileAtomically -Path $script:ManagedListRecordPath -Value ($Record | ConvertTo-Json -Depth 6)
    } catch {
        # Der Fehlschlag darf den Aufrufer nicht umwerfen - er steht mitten im
        # Durchsetzungslauf -, aber er darf auch nicht spurlos bleiben.
        try {
            Add-AppLog "Besitzdatensatz der Browser-Sperrliste konnte nicht geschrieben werden: $($_.Exception.Message)"
        } catch {
        }
    }
}

# Alles, was Purestate ueberhaupt in eine geteilte Browser-Sperrliste
# schreiben kann - unabhaengig davon, welche Bereiche gerade an sind.
#
# Der Besitzdatensatz allein reicht beim Entfernen nicht: er kennt nur den
# zuletzt geschriebenen Stand. Ein abgeschalteter Bereich, eine zwischen zwei
# Versionen geaenderte Domainliste oder ein Schreibvorgang des Guards
# (PurestateGuardService.cs schreibt URLBlocklist direkt und fuehrt keinen
# Datensatz) hinterlaesst eigene Eintraege, die anschliessend als
# Fremdeintraege gelten und jede Deinstallation ueberleben. Live gefunden am
# 2026-08-02: Edge behielt 19, Firefox 17 eigene Eintraege.
function Get-PurestateUrlPatternUniverse {
    $savedConfigPath = $script:ConfigPath
    $probeConfig = Join-Path ([System.IO.Path]::GetTempPath()) ("Purestate-Universe-" + [guid]::NewGuid().ToString("N") + ".json")

    try {
        [pscustomobject]@{
            ProtectionEnabled = $true
            AdultContentProtectionEnabled = $true
            GamblingProtectionEnabled = $true
            GamblingProtectionMode = "strict"
            ShoppingProtectionEnabled = $true
            ShoppingDealSearchBlockEnabled = $true
            SocialMediaProtectionEnabled = $true
            SocialMediaBlockedPlatforms = "x,instagram,tiktok,pinterest,tumblr,bluesky,reddit,youtube,streaming"
            SocialMediaFeedBlockedPlatforms = "instagram,youtube,x,reddit,tumblr"
            VideoGamesProtectionEnabled = $true
            VideoGamesProtectionMode = "strict"
            SiteRedditEnabled = $true
            SiteXEnabled = $true
            SiteBlueskyEnabled = $true
            SiteTumblrEnabled = $true
            SiteDeviantArtEnabled = $true
            SitePixivEnabled = $true
            SiteNewgroundsEnabled = $true
            SiteImgurEnabled = $true
            SiteInstagramEnabled = $true
            SiteTikTokEnabled = $true
            SitePinterestEnabled = $true
        } | ConvertTo-Json | Set-Content -LiteralPath $probeConfig -Encoding UTF8

        $script:ConfigPath = $probeConfig
        $basePatterns = @(Get-MixedSiteUrlPatterns)
        return @(@(Merge-ChromiumUrlFilters -BasePatterns $basePatterns -FailClosed $true) +
                 @(Merge-BrowserUrlPatterns -BasePatterns $basePatterns -FailClosed $true) |
                 Sort-Object -Unique)
    } finally {
        $script:ConfigPath = $savedConfigPath
        Remove-Item -LiteralPath $probeConfig -Force -ErrorAction SilentlyContinue
    }
}

# Adds Purestate's patterns to a shared browser blocklist (URLBlocklist /
# WebsiteFilter\Block) while preserving any third-party entries. The set we add
# is recorded so a later enable/disable can replace or remove exactly our
# entries and nothing else.
function Set-PurestateManagedUrlList {
    param(
        [string]$Path,
        [string]$ListName,
        [string[]]$Values
    )

    $listPath = Join-Path $Path $ListName
    $recordKey = $ListName + "@" + $Path
    $record = Get-ManagedListRecord
    $previouslyOurs = @()
    if ($record.ContainsKey($recordKey)) {
        $previouslyOurs = @($record[$recordKey])
    }

    $existing = @(Get-PolicyStringListValues -Path $listPath)
    $preserved = @($existing | Where-Object { $previouslyOurs -notcontains $_ })

    # POL-001: Merge-ChromiumUrlFilters vergibt das 1000-Eintraege-Budget nach
    # Prioritaet (Fail-closed, Canary, Gluecksspiel, Erwachsene, Shopping,
    # Social, Videospiele, Basismuster). Frueher standen hier die Fremdeintraege
    # VORNE und die Gesamtlaenge blieb ungedeckelt - auf einem verwalteten
    # Rechner fiel damit still der Schwanz der eigenen Liste aus der Auswertung,
    # waehrend die Anzeige "geschuetzt" meldete. Jetzt: eigene Regeln zuerst,
    # Fremdbestand fuellt den Rest, hart auf den Deckel gekuerzt.
    # POL-005: -notcontains ueber ein wachsendes Array ist quadratisch, bei 1000
    # Eintraegen rund 500.000 Zeichenkettenvergleiche je Lauf und Browser.
    $gesehen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
    $liste = New-Object 'System.Collections.Generic.List[string]'
    foreach ($value in @($Values)) { if ($gesehen.Add($value)) { $liste.Add($value) } }
    foreach ($value in $preserved) { if ($gesehen.Add($value)) { $liste.Add($value) } }
    $final = @($liste.ToArray())

    if ($final.Count -gt $script:MaxPolicyUrlListEntries) {
        $verloren = $final.Count - $script:MaxPolicyUrlListEntries
        Add-SecurityLog "URLBlocklist cap reached in $ListName at $($Path): $($preserved.Count) third-party entries present, $verloren entries dropped beyond the $($script:MaxPolicyUrlListEntries) limit."
        $final = @($final | Select-Object -First $script:MaxPolicyUrlListEntries)
    }

    Set-PolicyStringList -Path $Path -ListName $ListName -Values $final
    $record[$recordKey] = @($Values)
    Save-ManagedListRecord -Record $record

    # Liefert, OB sich die Liste geaendert hat. Der Aufrufer startet nur dann
    # den Browser neu: eine geschriebene, aber unveraenderte Liste darf keinen
    # Neustart ausloesen, sonst schliesst der Watchdog alle paar Minuten die
    # Fenster des Nutzers.
    return (@(Compare-Object -ReferenceObject @($existing) -DifferenceObject @($final) -SyncWindow 0).Count -gt 0)
}

# Removes only the entries Purestate previously added to a shared browser
# blocklist. If nothing else remains the list key is deleted; otherwise the
# third-party entries are rewritten untouched.
function Remove-PurestateManagedUrlList {
    param(
        [string]$Path,
        [string]$ListName,
        [switch]$RequireComplete
    )

    $listPath = Join-Path $Path $ListName
    $recordKey = $ListName + "@" + $Path
    $record = Get-ManagedListRecord
    $ours = @()
    if ($record.ContainsKey($recordKey)) {
        $ours = @($record[$recordKey])
    }

    # Besitz zusaetzlich nach Inhalt, nicht nur nach Datensatz. Scheitert das
    # Erzeugen der Musterliste (fehlende Regeldateien beim Entfernen), bleibt
    # es beim Datensatz - lieber ein Rest zu viel als eine abgebrochene
    # Aufraeumroutine.
    try {
        $ours = @(@($ours) + @(Get-PurestateUrlPatternUniverse) | Sort-Object -Unique)
    } catch {
        Add-AppLog "URL list ownership by content unavailable: $($_.Exception.Message)"
    }

    if (Test-Path -LiteralPath $listPath) {
        $existing = @(Get-PolicyStringListValues -Path $listPath)
        $remaining = @($existing | Where-Object { $ours -notcontains $_ })
        if ($remaining.Count -eq 0) {
            Remove-Item -Path $listPath -Recurse -Force -ErrorAction $(if ($RequireComplete) { "Stop" } else { "SilentlyContinue" })
        } else {
            Set-PolicyStringList -Path $Path -ListName $ListName -Values $remaining
        }
    }

    if ($record.ContainsKey($recordKey)) {
        $record.Remove($recordKey)
        Save-ManagedListRecord -Record $record
    }
}

function Get-SiteProtectionSettings {
    $config = Get-Config
    # Feinfilter wirken nur, solange der Bereich Erwachseneninhalte selbst an
    # ist (Spec 2.4) - der Hauptschalter, nicht die einzelne Seite, entscheidet.
    $adult = [bool]$config.AdultContentProtectionEnabled
    return @{
        reddit = $adult -and [bool]$config.SiteRedditEnabled
        x = $adult -and [bool]$config.SiteXEnabled
        bluesky = $adult -and [bool]$config.SiteBlueskyEnabled
        tumblr = $adult -and [bool]$config.SiteTumblrEnabled
        deviantart = $adult -and [bool]$config.SiteDeviantArtEnabled
        pixiv = $adult -and [bool]$config.SitePixivEnabled
        newgrounds = $adult -and [bool]$config.SiteNewgroundsEnabled
        imgur = $adult -and [bool]$config.SiteImgurEnabled
        instagram = $adult -and [bool]$config.SiteInstagramEnabled
        tiktok = $adult -and [bool]$config.SiteTikTokEnabled
        pinterest = $adult -and [bool]$config.SitePinterestEnabled
    }
}

function Get-PatternSiteKey {
    param([string]$Pattern)

    $value = ([string]$Pattern).ToLowerInvariant()
    if ($value -match "reddit\.com") { return "reddit" }
    if ($value -match "(^|[*.\/])(?:x|twitter)\.com") { return "x" }
    if ($value -match "bsky\.app") { return "bluesky" }
    if ($value -match "tumblr\.com") { return "tumblr" }
    if ($value -match "deviantart\.com") { return "deviantart" }
    if ($value -match "pixiv\.net") { return "pixiv" }
    if ($value -match "newgrounds\.com") { return "newgrounds" }
    if ($value -match "imgur\.com") { return "imgur" }
    if ($value -match "instagram\.com") { return "instagram" }
    if ($value -match "tiktok\.com") { return "tiktok" }
    if ($value -match "pinterest\.") { return "pinterest" }
    return ""
}

function Filter-MixedSitePatternsBySiteProtection {
    param([string[]]$Patterns)

    $settings = Get-SiteProtectionSettings
    $result = @()
    foreach ($pattern in @($Patterns)) {
        $site = Get-PatternSiteKey -Pattern $pattern
        if ($site -and $settings.ContainsKey($site) -and -not $settings[$site]) {
            continue
        }
        $result += $pattern
    }
    return @($result)
}

function Get-PurestateFailClosedPatterns {
    $patterns = @(
        "*://reddit.com/*",
        "*://*.reddit.com/*",
        "*://x.com/*",
        "*://*.x.com/*",
        "*://twitter.com/*",
        "*://*.twitter.com/*",
        "*://bsky.app/*",
        "*://*.bsky.app/*",
        "*://tumblr.com/*",
        "*://*.tumblr.com/*",
        "*://deviantart.com/*",
        "*://*.deviantart.com/*",
        "*://pixiv.net/*",
        "*://*.pixiv.net/*",
        "*://newgrounds.com/*",
        "*://*.newgrounds.com/*",
        "*://imgur.com/*",
        "*://*.imgur.com/*",
        "*://instagram.com/*",
        "*://*.instagram.com/*",
        "*://tiktok.com/*",
        "*://*.tiktok.com/*",
        "*://pinterest.com/*",
        "*://*.pinterest.com/*",
        "*://pinterest.de/*",
        "*://*.pinterest.de/*",
        "*://pinterest.at/*",
        "*://*.pinterest.at/*",
        "*://pinterest.ch/*",
        "*://*.pinterest.ch/*",
        "*://pinterest.fr/*",
        "*://*.pinterest.fr/*",
        "*://pinterest.it/*",
        "*://*.pinterest.it/*",
        "*://pinterest.es/*",
        "*://*.pinterest.es/*",
        "*://pinterest.co.uk/*",
        "*://*.pinterest.co.uk/*",
        "*://pinterest.ca/*",
        "*://*.pinterest.ca/*",
        "*://pinterest.com.au/*",
        "*://*.pinterest.com.au/*",
        "*://pinterest.com.mx/*",
        "*://*.pinterest.com.mx/*",
        "*://pinterest.jp/*",
        "*://*.pinterest.jp/*",
        "*://pinterest.se/*",
        "*://*.pinterest.se/*"
    )

    if (Test-ProtectionAreaEnabled -Area "gambling") {
        $patterns += @(
            "*://www.google.*/*",
            "*://www.bing.com/*",
            "*://duckduckgo.com/*",
            "*://search.brave.com/*",
            "*://search.yahoo.com/*",
            "*://*.search.yahoo.com/*",
            "*://www.youtube.com/*"
        )
    }

    return @(Filter-MixedSitePatternsBySiteProtection -Patterns $patterns)
}

function Get-ChromiumFailClosedFilters {
    $result = @(Filter-MixedSitePatternsBySiteProtection -Patterns @(
        "reddit.com",
        "x.com",
        "twitter.com",
        "bsky.app",
        "tumblr.com",
        "deviantart.com",
        "pixiv.net",
        "newgrounds.com",
        "imgur.com",
        "instagram.com",
        "tiktok.com",
        "pinterest.com",
        "pinterest.de",
        "pinterest.at",
        "pinterest.ch",
        "pinterest.fr",
        "pinterest.it",
        "pinterest.es",
        "pinterest.co.uk",
        "pinterest.ca",
        "pinterest.com.au",
        "pinterest.com.mx",
        "pinterest.jp",
        "pinterest.se"
    ))

    if (Test-ProtectionAreaEnabled -Area "gambling") {
        # POL-003: Die Firefox-Form sperrt ueber ihr Sternchenmuster jede
        # Google-TLD (siehe Get-PurestateFailClosedPatterns). Chromium kann das
        # nicht: ein blanker Host trifft alle
        # Subdomains, aber keine andere TLD - "google.com" laesst google.de
        # offen, fuer eine deutschsprachige Zielgruppe die Standardsuche.
        # Vollstaendigkeit ueber alle Google-TLDs ist mit dieser Syntax nicht
        # erreichbar; aufgefuehrt sind der deutschsprachige Raum und die
        # Nachbarlaender, wie es fuer Pinterest oben schon geschieht.
        foreach ($failClosedHost in @("google.com", "google.de", "google.at", "google.ch", "google.co.uk", "google.fr", "google.it", "google.es", "google.nl", "google.pl", "google.cz", "google.dk", "google.se", "bing.com", "duckduckgo.com", "search.brave.com", "search.yahoo.com", "youtube.com")) {
            if ($result -notcontains $failClosedHost) {
                $result += $failClosedHost
            }
        }
    }

    return @($result)
}

function Get-CanaryFailClosedStatePath {
    return (Join-Path $script:DataDir "canary-fail-closed.json")
}

function Get-CanaryFailClosedSiteInfo {
    param([string]$Site)

    switch (([string]$Site).Trim().ToLowerInvariant()) {
        "pixiv" { return [pscustomobject]@{ Site = "pixiv"; Domain = "pixiv.net"; SiteProtectionField = "SitePixivEnabled" } }
        "deviantart" { return [pscustomobject]@{ Site = "deviantart"; Domain = "deviantart.com"; SiteProtectionField = "SiteDeviantArtEnabled" } }
        "instagram" { return [pscustomobject]@{ Site = "instagram"; Domain = "instagram.com"; SiteProtectionField = "SiteInstagramEnabled" } }
        "imgur" { return [pscustomobject]@{ Site = "imgur"; Domain = "imgur.com"; SiteProtectionField = "SiteImgurEnabled" } }
        "newgrounds" { return [pscustomobject]@{ Site = "newgrounds"; Domain = "newgrounds.com"; SiteProtectionField = "SiteNewgroundsEnabled" } }
        "tumblr" { return [pscustomobject]@{ Site = "tumblr"; Domain = "tumblr.com"; SiteProtectionField = "SiteTumblrEnabled" } }
        default { return $null }
    }
}

function Test-CanaryFailClosedCheckToken {
    param([string]$Check)

    return -not [string]::IsNullOrWhiteSpace($Check) -and $Check -match '^[a-z0-9][a-z0-9._-]{0,39}$'
}

function Test-CanaryFailClosedSiteEnabled {
    param([string]$SiteProtectionField)

    try {
        $config = Get-Config
        # Befund #2: die Feinfilter, die der Kanarienvogel hier absichert, sind
        # alle Erwachseneninhalte-Feinfilter (Spec 2.4) - ohne den Bereich
        # selbst darf auch der Kanarienvogel nichts sperren, wie
        # Get-SiteProtectionSettings.
        if (-not [bool]$config.AdultContentProtectionEnabled) {
            return $false
        }
        if ($null -ne $config.PSObject.Properties[$SiteProtectionField]) {
            return [bool]$config.($SiteProtectionField)
        }
    } catch {
    }
    return $true
}

function Get-ActiveCanaryFailClosedDomains {
    param(
        [string]$Path = (Get-CanaryFailClosedStatePath),
        # POL-002: Der Vorgabewert war die rohe Systemuhr, und kein einziger
        # Produktionsaufrufer hat etwas anderes uebergeben. Die Canary-Sperre
        # ist die Antwort darauf, dass ein Erkennungsskript nicht mehr greift -
        # also genau der Zustand, in dem der Nutzer motiviert ist, sie
        # loszuwerden, und sie kostete ihn eine Uhrumstellung um 24 Stunden.
        # Massgeblich ist der vom Durchsetzungspfad fortgeschriebene Anker.
        [DateTime]$NowUtc = ((Get-TrustedLocalNow -Config (Get-Config)).ToUniversalTime()),
        [switch]$IgnoreSiteSwitches
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf -ErrorAction SilentlyContinue)) {
        return @()
    }

    try {
        $state = Get-Content -Raw -LiteralPath $Path -ErrorAction Stop | ConvertFrom-Json
        $result = @()
        foreach ($entry in @($state.entries)) {
            $siteInfo = Get-CanaryFailClosedSiteInfo -Site ([string]$entry.site)
            if ($null -eq $siteInfo) {
                continue
            }
            if ([string]$entry.domain -ne $siteInfo.Domain -or [string]$entry.siteProtectionField -ne $siteInfo.SiteProtectionField) {
                continue
            }
            if (-not $IgnoreSiteSwitches -and -not (Test-CanaryFailClosedSiteEnabled -SiteProtectionField $siteInfo.SiteProtectionField)) {
                continue
            }
            $checks = @($entry.checks)
            if ($checks.Count -eq 0) {
                continue
            }
            $checksValid = $true
            foreach ($check in $checks) {
                if (-not (Test-CanaryFailClosedCheckToken -Check ([string]$check))) {
                    $checksValid = $false
                    break
                }
            }
            if (-not $checksValid) {
                continue
            }
            $blockUntilUtc = [DateTime]::MinValue
            if (-not [DateTime]::TryParse(
                [string]$entry.blockUntilUtc,
                [Globalization.CultureInfo]::InvariantCulture,
                [Globalization.DateTimeStyles]::RoundtripKind,
                [ref]$blockUntilUtc
            )) {
                continue
            }
            if ($blockUntilUtc.ToUniversalTime() -le $NowUtc.ToUniversalTime()) {
                continue
            }
            if ($result -notcontains $siteInfo.Domain) {
                $result += $siteInfo.Domain
            }
        }
        return @($result | Sort-Object -Unique)
    } catch {
        return @()
    }
}

# Uebersetzt ein Firefox-Match-Pattern in die Chromium-URLBlocklist-Form.
# Gibt $null zurueck, wenn das Muster dort nicht ausdrueckbar ist.
#
# Chromiums Parser kennt "[schema://][.]host[:port][/pfad]" und sonst nichts:
# ein "*" ist nur als ganzer Host erlaubt, niemals innerhalb eines Hosts oder
# eines Pfades; ein Pfad trifft immer als Praefix. Firefox' WebsiteFilter will
# dagegen Match-Patterns ("*://*.reddit.com/r/*nsfw*"). Bis 0.62.62 wurden
# beide Listen in der Firefox-Form erzeugt, weshalb Chrome und Edge 976 von
# 1000 Eintraegen still verworfen haben (Befund L-5 in
# docs\LIVE-VALIDATION.md, live gemessen am 2026-08-02).
#
# ponytail: Stichwort-Suchrouten ("/search*porn*", "/r/*nsfw*") fallen hier
# bewusst heraus - Chromium kann "Pfad enthaelt X" nicht, und ein Abschneiden
# am Sternchen wuerde jede Google-Suche bzw. jedes Subreddit sperren. Diese
# Schicht deckt in Chrome der erzwungene SafeSearch plus der Companion ab.
# Aufwertung, falls jemand sie zurueckholen will: Chromiums Query-Form
# "google.com/search@q=porn*" trifft Suchanfragen, die MIT dem Stichwort
# beginnen. Sie ist NICHT live verifiziert - genau die Sorte Annahme, die
# L-5 verursacht hat - und braucht je Suchmaschine den Query-Schluessel
# (q, text, search_query) sowie eine TLD-Liste fuer google.* / pinterest.*.
# Vor dem Einbau erst im echten Chrome messen.
function ConvertTo-ChromiumUrlFilter {
    param([string]$Pattern)

    $value = ([string]$Pattern).Trim()
    if ($value.Length -eq 0) {
        return $null
    }

    $scheme = ""
    $rest = $value
    $separator = $value.IndexOf("://")
    if ($separator -ge 0) {
        $scheme = $value.Substring(0, $separator)
        $rest = $value.Substring($separator + 3)
        if ($scheme -eq "*") {
            # "jedes Schema" schreibt Chromium, indem es keins nennt.
            $scheme = ""
        } elseif ($scheme.Contains("*")) {
            return $null
        }
    }

    $hostPart = $rest
    $pathPart = ""
    $slash = $rest.IndexOf("/")
    if ($slash -ge 0) {
        $hostPart = $rest.Substring(0, $slash)
        $pathPart = $rest.Substring($slash)
    }

    # Ein blanker Host trifft in Chromium auch alle Subdomains, die
    # "*.host"-Form derselben Regel faellt also darauf zusammen.
    if ($hostPart.StartsWith("*.")) {
        $hostPart = $hostPart.Substring(2)
    }
    if ($hostPart.Length -eq 0 -or $hostPart.Contains("*")) {
        return $null
    }

    # Das abschliessende "*" ist implizit (Praefixtreffer); ein "*" irgendwo
    # sonst im Pfad ist nicht uebersetzbar.
    $pathPart = $pathPart.TrimEnd("*").TrimEnd("/")
    if ($pathPart.Contains("*")) {
        return $null
    }

    if ($scheme.Length -gt 0) {
        return ($scheme + "://" + $hostPart + $pathPart)
    }
    return ($hostPart + $pathPart)
}

function Add-ChromiumUrlFilter {
    param(
        [ref]$Filters,
        [string]$Value
    )

    $filter = ConvertTo-ChromiumUrlFilter -Pattern $Value
    if (-not $filter) {
        return
    }
    if ($Filters.Value -notcontains $filter) {
        $Filters.Value += $filter
    }
}

function Merge-ChromiumUrlFilters {
    param(
        [string[]]$BasePatterns,
        [bool]$FailClosed
    )

    # Jeder Eintrag laeuft durch ConvertTo-ChromiumUrlFilter: die Quellen
    # liefern teils Match-Patterns, teils schon die native Form, und nur die
    # native Form wertet Chromium ueberhaupt aus.
    $result = @()
    if ($FailClosed) {
        foreach ($filter in Get-ChromiumFailClosedFilters) {
            Add-ChromiumUrlFilter -Filters ([ref]$result) -Value $filter
        }
    }

    foreach ($canaryDomain in Get-ActiveCanaryFailClosedDomains) {
        if ($result.Count -ge 1000) {
            break
        }
        Add-ChromiumUrlFilter -Filters ([ref]$result) -Value $canaryDomain
    }

    # Gambling domains and gambling search patterns sit ahead of the base
    # patterns so they are never dropped by the 1000-entry policy cap when the
    # gambling area is on.
    foreach ($gamblingDomain in Get-GamblingBlocklistDomains) {
        if ($result.Count -ge 1000) {
            break
        }
        Add-ChromiumUrlFilter -Filters ([ref]$result) -Value $gamblingDomain
    }

    foreach ($gamblingPattern in Get-GamblingSearchPatterns) {
        if ($result.Count -ge 1000) {
            break
        }
        Add-ChromiumUrlFilter -Filters ([ref]$result) -Value $gamblingPattern
    }

    # Erwachsenen-Domains stehen nach Gluecksspiel und vor Shopping - siehe
    # Kommentar oben: Gluecksspiel darf durch diese Quelle nicht vom
    # 1000er-Deckel abgeschnitten werden.
    foreach ($adultDomain in Get-AdultBlocklistDomains) {
        if ($result.Count -ge 1000) {
            break
        }
        Add-ChromiumUrlFilter -Filters ([ref]$result) -Value $adultDomain
    }

    foreach ($shoppingDomain in Get-ShoppingBlocklistDomains) {
        if ($result.Count -ge 1000) {
            break
        }
        Add-ChromiumUrlFilter -Filters ([ref]$result) -Value $shoppingDomain
    }

    foreach ($shoppingPattern in Get-ShoppingSearchPatterns) {
        if ($result.Count -ge 1000) {
            break
        }
        Add-ChromiumUrlFilter -Filters ([ref]$result) -Value $shoppingPattern
    }

    foreach ($socialDomain in Get-SocialMediaBlockedDomains) {
        if ($result.Count -ge 1000) {
            break
        }
        Add-ChromiumUrlFilter -Filters ([ref]$result) -Value $socialDomain
    }

    foreach ($socialFeedPattern in Get-SocialMediaFeedBlockedPatterns) {
        if ($result.Count -ge 1000) {
            break
        }
        Add-ChromiumUrlFilter -Filters ([ref]$result) -Value $socialFeedPattern
    }

    foreach ($gamingEntry in @(Get-VideoGamesBlocklistDomains) + @(Get-VideoGamesBlockedRoutePatterns)) {
        if ($result.Count -ge 1000) {
            break
        }
        Add-ChromiumUrlFilter -Filters ([ref]$result) -Value $gamingEntry
    }

    foreach ($pattern in @($BasePatterns)) {
        if ($result.Count -ge 1000) {
            break
        }
        Add-ChromiumUrlFilter -Filters ([ref]$result) -Value $pattern
    }
    return @($result)
}

# BAS-003: Firefox' WebsiteFilter nimmt ausschliesslich Match-Patterns. Ein
# blanker Hostname wird still verworfen - sichtbar nur in der Browser-Konsole
# als "Invalid pattern on WebsiteFilter. Block: x.com". Die Chromium-Seite
# will genau umgekehrt die blanke Hostform, deshalb liefern
# Get-SocialMediaBlockedDomains und Get-VideoGamesBlocklistDomains sie so -
# und beide landeten unveraendert in der Firefox-Liste. Wirkung: die
# Social-Media-Vollsperre und die Videospiel-Domains galten in Firefox gar
# nicht, und dort gibt es keine zweite Schicht (die hosts-Datei traegt nur die
# kuratierte Erwachsenenliste). Live gemessen am 2026-08-24.
#
# Die Umwandlung sitzt bewusst in Merge-BrowserUrlPatterns statt an den
# einzelnen Quellen: so ist jede kuenftige Hostliste automatisch mit erfasst.
function Expand-FirefoxMatchPattern {
    param([string]$Entry)

    $value = ([string]$Entry).Trim()
    if ($value.Length -eq 0) {
        return @()
    }
    if ($value.Contains("://")) {
        return @($value)
    }

    # $host waere die automatische Variable der PowerShell-Sitzung.
    $slash = $value.IndexOf("/")
    if ($slash -lt 0) {
        $hostPart = $value
        $pathPart = "/*"
    } else {
        $hostPart = $value.Substring(0, $slash)
        $pathPart = $value.Substring($slash) + "*"
    }

    if ($hostPart.Length -eq 0) {
        return @()
    }

    return @("*://$hostPart$pathPart", "*://*.$hostPart$pathPart")
}

function Merge-BrowserUrlPatterns {
    param(
        [string[]]$BasePatterns,
        [bool]$FailClosed
    )

    $result = @()
    if ($FailClosed) {
        foreach ($pattern in Get-PurestateFailClosedPatterns) {
            if ($result -notcontains $pattern) {
                $result += $pattern
            }
        }
    }

    foreach ($gamblingPattern in Get-GamblingSearchPatterns) {
        if ($result.Count -ge 1000) {
            break
        }
        if ($result -notcontains $gamblingPattern) {
            $result += $gamblingPattern
        }
    }

    foreach ($shoppingPattern in Get-ShoppingSearchPatterns) {
        if ($result.Count -ge 1000) {
            break
        }
        if ($result -notcontains $shoppingPattern) {
            $result += $shoppingPattern
        }
    }

    foreach ($socialDomain in Get-SocialMediaBlockedDomains) {
        if ($result.Count -ge 1000) {
            break
        }
        if ($result -notcontains $socialDomain) {
            $result += $socialDomain
        }
    }

    foreach ($socialFeedPattern in Get-SocialMediaFeedBlockedPatterns) {
        if ($result.Count -ge 1000) {
            break
        }
        if ($result -notcontains $socialFeedPattern) {
            $result += $socialFeedPattern
        }
    }

    foreach ($gamingEntry in @(Get-VideoGamesBlocklistDomains) + @(Get-VideoGamesBlockedRoutePatterns)) {
        if ($result.Count -ge 1000) {
            break
        }
        if ($result -notcontains $gamingEntry) {
            $result += $gamingEntry
        }
    }

    foreach ($pattern in @($BasePatterns)) {
        if ($result.Count -ge 1000) {
            break
        }
        if ($result -notcontains $pattern) {
            $result += $pattern
        }
    }

    # BAS-003: Erst hier, damit jede Quelle erfasst ist. Die Reihenfolge
    # bleibt erhalten - der Deckel schneidet am Ende ab, wo die unwichtigsten
    # Eintraege stehen.
    $expanded = @()
    foreach ($entry in $result) {
        foreach ($firefoxPattern in (Expand-FirefoxMatchPattern -Entry $entry)) {
            if ($expanded.Count -ge 1000) {
                break
            }
            if ($expanded -notcontains $firefoxPattern) {
                $expanded += $firefoxPattern
            }
        }
        if ($expanded.Count -ge 1000) {
            break
        }
    }

    return @($expanded)
}

function Get-NormalizedPurestatePath {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return ""
    }

    try {
        return [IO.Path]::GetFullPath($Path).TrimEnd('\', '/')
    } catch {
        return ""
    }
}

function Test-ChromiumStoreExtensionPath {
    param(
        [string]$Path,
        [string]$ExpectedExtensionId,
        [string]$ExpectedVersion
    )

    if ([string]::IsNullOrWhiteSpace($Path) -or
        [string]::IsNullOrWhiteSpace($ExpectedExtensionId) -or
        [string]::IsNullOrWhiteSpace($ExpectedVersion)) {
        return $false
    }

    $normalized = ([string]$Path).Trim().Replace('/', '\')
    $escapedId = [regex]::Escape($ExpectedExtensionId)
    $escapedVersion = [regex]::Escape($ExpectedVersion)
    return $normalized -match "(^|\\+)$escapedId\\+$escapedVersion(?:_\d+)?$"
}

# Alter des letzten brauchbaren Herzschlags in Sekunden, oder -1, wenn es
# keinen gibt: Datei fehlt, ist unlesbar, nennt eine andere Version, oder traegt
# einen Zeitpunkt aus der Zukunft. Getrennt von der Ja/Nein-Frage, weil der
# Rueckfall in Test-PurestateExtensionForBrowser das Alter selbst braucht
# (CMP-001) - ein abgelaufener Herzschlag von vor vier Minuten sagt etwas
# anderes als gar keiner.
function Get-PurestateCompanionHeartbeatAgeSeconds {
    [CmdletBinding()]
    param(
        [ValidateSet("Chrome", "Edge")][string]$Browser,
        [string]$ExpectedVersion,
        [DateTime]$SystemUtc = [DateTime]::UtcNow,
        [DateTime]$AnchorUtc = [DateTime]::MinValue
    )

    if ($AnchorUtc -eq [DateTime]::MinValue) {
        $AnchorUtc = (Get-TrustedLocalNow -Config (Get-Config)).ToUniversalTime()
    }

    Assert-DataDirectoryIsNotReparsePoint
    $path = Join-Path $script:DataDir ($Browser.ToLowerInvariant() + "-companion-heartbeat.txt")
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        return -1
    }
    try {
        $parts = ([string](Get-Content -Raw -LiteralPath $path)).Trim().Split('|')
        if ($parts.Count -ne 2 -or $parts[0] -ne $ExpectedVersion) {
            return -1
        }
        $checkedAt = [DateTime]::Parse($parts[1], [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::RoundtripKind).ToUniversalTime()
        # Der Herzschlag ist der Lebendbeweis des Companions, und sein Alter ist
        # eine ablaufende Erlaubnis: es zaehlt die SPAETERE der beiden Uhren
        # (CLK-003/HBT-001). Sonst macht eine zurueckgestellte Systemuhr aus
        # einem stundenalten Herzschlag einen taufrischen, und der Companion
        # gilt dauerhaft als lebend, obwohl er weg ist.
        $ageNowUtc = Get-LatestClockUtc -AnchorUtc $AnchorUtc -SystemUtc $SystemUtc
        $age = ($ageNowUtc - $checkedAt).TotalSeconds
        if ($age -lt -30) {
            return -1
        }
        if ($age -lt 0) {
            return 0
        }
        return [double]$age
    } catch {
        return -1
    }
}

function Test-PurestateCompanionHeartbeat {
    [CmdletBinding()]
    param(
        [ValidateSet("Chrome", "Edge")][string]$Browser,
        [string]$ExpectedVersion,
        [DateTime]$SystemUtc = [DateTime]::UtcNow,
        [DateTime]$AnchorUtc = [DateTime]::MinValue
    )

    $age = Get-PurestateCompanionHeartbeatAgeSeconds -Browser $Browser -ExpectedVersion $ExpectedVersion -SystemUtc $SystemUtc -AnchorUtc $AnchorUtc
    return ($age -ge 0 -and $age -le $script:CompanionHeartbeatMaxAgeSeconds)
}

function Get-PurestateExtensionPreferenceState {
    param(
        [string]$Path,
        [string]$ExpectedExtensionPath,
        [string]$ExpectedVersion,
        [string]$ExpectedExtensionId = $script:CompanionStoreId
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return "Missing"
    }

    try {
        $preferences = Get-Content -Raw -LiteralPath $Path | ConvertFrom-Json
        $settings = $preferences.extensions.settings
        if ($null -eq $settings) {
            return "Missing"
        }

        foreach ($property in $settings.PSObject.Properties) {
            $entry = $property.Value
            $name = [string]$entry.manifest.name
            $version = [string]$entry.manifest.version
            $extensionPath = [string]$entry.path
            $normalizedPath = Get-NormalizedPurestatePath -Path $extensionPath
            $normalizedExpectedPath = Get-NormalizedPurestatePath -Path $ExpectedExtensionPath
            $pathPresent = -not [string]::IsNullOrWhiteSpace($normalizedPath)
            $pathMatches = $pathPresent -and $normalizedPath.Equals($normalizedExpectedPath, [StringComparison]::OrdinalIgnoreCase)
            $storePathMatches = $property.Name -eq $ExpectedExtensionId -and
                (Test-ChromiumStoreExtensionPath -Path $extensionPath -ExpectedExtensionId $ExpectedExtensionId -ExpectedVersion $ExpectedVersion)
            $manifestMatches = $name -eq "Purestate Companion" -and $version -eq $ExpectedVersion
            $storeIdentityMatches = $property.Name -eq $ExpectedExtensionId -and ($manifestMatches -or $storePathMatches)
            if (-not $storeIdentityMatches -and -not $pathMatches -and -not ((-not $pathPresent) -and $manifestMatches)) {
                continue
            }

            $stateProperty = $entry.PSObject.Properties["state"]
            $disableReasonsProperty = $entry.PSObject.Properties["disable_reasons"]
            $state = 0
            $disableReasons = 0
            $hasState = $null -ne $stateProperty -and [int]::TryParse([string]$stateProperty.Value, [ref]$state)
            $hasDisableReasons = $null -ne $disableReasonsProperty -and [int]::TryParse([string]$disableReasonsProperty.Value, [ref]$disableReasons)

            if (($hasDisableReasons -and $disableReasons -ne 0) -or ($hasState -and $state -ne 1)) {
                return "Inactive"
            }
            if ($hasState -and $state -eq 1) {
                return "Active"
            }

            # Chrome may split identity and active state across its two preference files.
            return "IdentityOnly"
        }
    } catch {
        return "Unreadable"
    }

    return "Missing"
}

function Test-PurestateExtensionInPreferencesFile {
    param(
        [string]$Path,
        [string]$ExpectedExtensionPath,
        [string]$ExpectedVersion
    )

    return (Get-PurestateExtensionPreferenceState -Path $Path -ExpectedExtensionPath $ExpectedExtensionPath -ExpectedVersion $ExpectedVersion) -eq "Active"
}

function Test-PurestateExtensionInProfile {
    param(
        [string]$ProfilePath,
        [string]$ExpectedExtensionPath,
        [string]$ExpectedVersion,
        [string]$ExpectedExtensionId = $script:CompanionStoreId
    )

    $securePreferences = Join-Path $ProfilePath "Secure Preferences"
    $secureState = "Missing"
    if (Test-Path -LiteralPath $securePreferences -PathType Leaf) {
        $secureState = Get-PurestateExtensionPreferenceState -Path $securePreferences -ExpectedExtensionPath $ExpectedExtensionPath -ExpectedVersion $ExpectedVersion -ExpectedExtensionId $ExpectedExtensionId
    }

    $preferencesState = Get-PurestateExtensionPreferenceState -Path (Join-Path $ProfilePath "Preferences") -ExpectedExtensionPath $ExpectedExtensionPath -ExpectedVersion $ExpectedVersion -ExpectedExtensionId $ExpectedExtensionId
    if ($secureState -in @("Inactive", "Unreadable") -or $preferencesState -in @("Inactive", "Unreadable")) {
        return $false
    }
    if ($secureState -eq "Active" -or $preferencesState -eq "Active") {
        return $true
    }

    if ($secureState -eq "IdentityOnly" -or $preferencesState -eq "IdentityOnly") {
        $storePath = Join-Path $ProfilePath ("Extensions\" + $ExpectedExtensionId)
        return @(Get-ChildItem -LiteralPath $storePath -Directory -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -eq $ExpectedVersion -or $_.Name -like ($ExpectedVersion + "_*") }).Count -gt 0
    }
    return $false
}

# Relaxed profile check for the DEV companion id only (see
# Get-DevCompanionExtensionId). An unpacked ("Load unpacked") extension is a
# deliberate developer trust anchor - the operator pasted its exact id - and
# Chrome does NOT write a `manifest` node, `version`, or the canonical app
# path into Preferences for an unpacked load (it re-reads the folder each
# start), so the strict store-identity match in Test-PurestateExtensionInProfile
# can never confirm it. Here presence of the settings entry, not explicitly
# disabled, is sufficient. Still fail-closed: an explicit disable (state != 1
# or a non-zero disable_reasons) returns $false, exactly like the store path.
function Test-PurestateDevExtensionInProfile {
    param(
        [string]$ProfilePath,
        [string]$DevExtensionId
    )

    if ([string]::IsNullOrWhiteSpace($DevExtensionId)) {
        return $false
    }

    foreach ($fileName in @("Secure Preferences", "Preferences")) {
        $path = Join-Path $ProfilePath $fileName
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            continue
        }
        try {
            $prefs = Get-Content -Raw -LiteralPath $path | ConvertFrom-Json
            $settings = $prefs.extensions.settings
            if ($null -eq $settings) {
                continue
            }
            $entryProperty = $settings.PSObject.Properties[$DevExtensionId]
            if ($null -eq $entryProperty) {
                continue
            }

            $entry = $entryProperty.Value
            $stateProperty = $entry.PSObject.Properties["state"]
            $disableReasonsProperty = $entry.PSObject.Properties["disable_reasons"]
            $state = 0
            $disableReasons = 0
            $hasState = $null -ne $stateProperty -and [int]::TryParse([string]$stateProperty.Value, [ref]$state)
            $hasDisableReasons = $null -ne $disableReasonsProperty -and [int]::TryParse([string]$disableReasonsProperty.Value, [ref]$disableReasons)

            if (($hasDisableReasons -and $disableReasons -ne 0) -or ($hasState -and $state -ne 1)) {
                return $false
            }
            return $true
        } catch {
            continue
        }
    }
    return $false
}

function Get-ChromiumUserDataRoots {
    param([ValidateSet("Chrome", "Edge")][string]$Browser)

    $relative = if ($Browser -eq "Chrome") {
        "AppData\Local\Google\Chrome\User Data"
    } else {
        "AppData\Local\Microsoft\Edge\User Data"
    }

    $roots = @()
    $usersRoot = Join-Path $env:SystemDrive "Users"
    if (Test-Path -LiteralPath $usersRoot -PathType Container) {
        foreach ($user in Get-ChildItem -LiteralPath $usersRoot -Directory -Force -ErrorAction SilentlyContinue) {
            if ($user.Name -in @("All Users", "Default", "Default User", "Public")) {
                continue
            }
            $candidate = Join-Path $user.FullName $relative
            if ((Test-Path -LiteralPath $candidate -PathType Container) -and $roots -notcontains $candidate) {
                $roots += $candidate
            }
        }
    }

    return @($roots)
}

function Test-NumericRegistryValueObjectContains {
    param(
        $ValueObject,
        [string]$ExpectedValue
    )

    if ($null -eq $ValueObject -or [string]::IsNullOrEmpty($ExpectedValue)) {
        return $false
    }
    foreach ($property in $ValueObject.PSObject.Properties) {
        if ($property.Name -match '^\d+$' -and [string]$property.Value -eq $ExpectedValue) {
            return $true
        }
    }
    return $false
}

function Test-PurestateManagedCompanionPolicy {
    param([ValidateSet("Chrome", "Edge")][string]$Browser)

    $root = if ($Browser -eq "Chrome") {
        "HKLM:\SOFTWARE\Policies\Google\Chrome"
    } else {
        "HKLM:\SOFTWARE\Policies\Microsoft\Edge"
    }
    try {
        $settingsJson = [string](Get-ItemProperty -LiteralPath $root -ErrorAction Stop).ExtensionSettings
        $settings = $settingsJson | ConvertFrom-Json
        $property = $settings.PSObject.Properties[$script:CompanionStoreId]
        if ($null -eq $property -or
            [string]$property.Value.installation_mode -ne "force_installed" -or
            [string]$property.Value.update_url -ne $script:CompanionStoreUpdateUrl) {
            return $false
        }

        $forceList = Join-Path $root "ExtensionInstallForcelist"
        $forceListValues = Get-ItemProperty -LiteralPath $forceList -ErrorAction Stop
        return Test-NumericRegistryValueObjectContains `
            -ValueObject $forceListValues `
            -ExpectedValue ($script:CompanionStoreId + ";" + $script:CompanionStoreUpdateUrl)
    } catch {
        return $false
    }
}

# HBT-001/CLK-003, live gemessen am 2026-08-30: hier stand
# `[DateTime]::UtcNow - $process.StartTime` - die rohe Uhr auf BEIDEN Seiten.
# Der Audit vermutete die Luecke beim Herzschlag; der ist laengst gehaertet
# (Get-PurestateCompanionHeartbeatAgeSeconds rechnet mit der spaeteren der
# beiden Uhren und weist Zeitstempel aus der Zukunft ab). Verjuengt wurde
# stattdessen der BROWSER: eine um 741 s zurueckgestellte Systemuhr liess sein
# errechnetes Alter unter die Startgnadenfrist fallen, der Rueckfall trug wieder,
# und die Vollsperre loeste sich. Gemessen: nach dem Zurueckstellen 90 s frei,
# und wiederholtes Zurueckstellen alle 45 s hielt 5 von 10 Runden offen.
#
# Jetzt gilt dieselbe Regel wie beim Herzschlag: es zaehlt die SPAETERE der
# beiden Uhren. Der Anker waechst monoton, eine zurueckgestellte Systemuhr kann
# den Browser damit nicht mehr juenger machen.
function Get-ChromiumBrowserProcessAgeSeconds {
    param(
        [ValidateSet("Chrome", "Edge")][string]$Browser,
        [DateTime]$SystemUtc = [DateTime]::UtcNow,
        [DateTime]$AnchorUtc = [DateTime]::MinValue
    )

    if ($AnchorUtc -eq [DateTime]::MinValue) {
        $AnchorUtc = (Get-TrustedLocalNow -Config (Get-Config)).ToUniversalTime()
    }
    $nowUtc = Get-LatestClockUtc -AnchorUtc $AnchorUtc -SystemUtc $SystemUtc

    $processName = if ($Browser -eq "Chrome") { "chrome" } else { "msedge" }
    $ages = @()
    foreach ($process in @(Get-Process -Name $processName -ErrorAction SilentlyContinue)) {
        try {
            # Ein negatives Alter (Startzeit unter einer vorgestellten Uhr
            # geschrieben) darf NICHT durchschlagen: -1 bedeutet an der
            # Auswertungsstelle "kein Browser laeuft" und damit "nichts zu
            # sperren". Ein laufender Browser mit krummer Startzeit gilt
            # deshalb als uralt genug, nicht als abwesend.
            $seconds = ($nowUtc - $process.StartTime.ToUniversalTime()).TotalSeconds
            if ($seconds -lt 0) { $seconds = 0 }
            $ages += $seconds
        } catch {
        }
    }
    if ($ages.Count -eq 0) {
        return -1
    }
    return [double](($ages | Measure-Object -Maximum).Maximum)
}

# Die zusaetzlich zugelassene Companion-Version, solange die Uebergangsfrist
# nach einem App-Update laeuft. Spiegelt Support.ActiveCompanionGraceVersion.
# Gemessen mit der vertrauenswuerdigen Uhr, nicht mit der Systemuhr.
function Get-ActiveCompanionGraceVersion {
    param([pscustomobject]$Config = $null)

    if ($null -eq $Config) {
        $Config = Get-Config
    }
    if ($null -eq $Config) {
        return ""
    }

    $stored = [string]$Config.CompanionGrace
    if ([string]::IsNullOrEmpty($stored)) {
        return ""
    }

    $parts = $stored.Split('|')
    if ($parts.Count -ne 2 -or [string]::IsNullOrEmpty($parts[0])) {
        return ""
    }

    $until = [datetime]::MinValue
    $styles = [System.Globalization.DateTimeStyles]::RoundtripKind
    if (-not [datetime]::TryParse($parts[1], [System.Globalization.CultureInfo]::InvariantCulture, $styles, [ref]$until)) {
        return ""
    }

    $nowUtc = (Get-TrustedLocalNow -Config $Config).ToUniversalTime()
    if ($nowUtc -ge ([datetime]::SpecifyKind($until, [System.DateTimeKind]::Utc))) {
        return ""
    }

    return $parts[0]
}

function Test-PurestateExtensionForBrowser {
    param(
        [ValidateSet("Chrome", "Edge")][string]$Browser,
        [string[]]$UserDataRoots = @(),
        [string]$ExpectedExtensionPath = "",
        [string]$ExpectedVersion = "",
        $HeartbeatPresent = $null,
        $ManagedPolicyPresent = $null,
        [double]$BrowserProcessAgeSeconds = -2,
        [double]$HeartbeatAgeSeconds = -2,
        [string]$DevCompanionId = $null,
        [string]$GraceVersion = $null,
        [bool]$StartupGraceSpent = $false
    )

    # Uebergangsfrist nach einem App-Update: der Store liefert die passende
    # Companion-Version erst nach seiner Pruefung aus. Wie bei DevCompanionId
    # unterscheidet PSBoundParameters "nicht uebergeben" (Produktivpfad, selbst
    # ermitteln) von einem ausdruecklichen Wert (Tests). Nennt ein Aufrufer
    # eine ExpectedVersion ohne GraceVersion, will er genau diese geprueft
    # haben - dann bleibt es beim heutigen Verhalten.
    $grace = if ($PSBoundParameters.ContainsKey('GraceVersion')) {
        $GraceVersion
    } elseif ($PSBoundParameters.ContainsKey('ExpectedVersion')) {
        ""
    } else {
        Get-ActiveCompanionGraceVersion
    }

    if (-not [string]::IsNullOrWhiteSpace($grace)) {
        $arguments = @{} + $PSBoundParameters
        $arguments.Remove('GraceVersion') | Out-Null
        $arguments['ExpectedVersion'] = if ([string]::IsNullOrWhiteSpace($ExpectedVersion)) { Get-PurestateAppVersion } else { $ExpectedVersion }
        if (Test-PurestateExtensionForBrowser @arguments) {
            return $true
        }
        $arguments['ExpectedVersion'] = $grace
        return (Test-PurestateExtensionForBrowser @arguments)
    }

    if ([string]::IsNullOrWhiteSpace($ExpectedExtensionPath)) {
        $ExpectedExtensionPath = Join-Path (Get-AppRoot) "extension\purestate-companion"
    }
    if ([string]::IsNullOrWhiteSpace($ExpectedVersion)) {
        $ExpectedVersion = Get-PurestateAppVersion
    }
    if ([string]::IsNullOrWhiteSpace($ExpectedVersion)) {
        return $false
    }

    $roots = @($UserDataRoots)
    if ($roots.Count -eq 0) {
        $roots = @(Get-ChromiumUserDataRoots -Browser $Browser)
    }

    # PSBoundParameters distinguishes "not passed" (auto-detect, production
    # default) from an explicit "" (tests forcing dev mode off) without
    # touching the filesystem in unrelated test runs.
    $devId = if ($PSBoundParameters.ContainsKey('DevCompanionId')) { $DevCompanionId } else { Get-DevCompanionExtensionId }
    $devModeActive = -not [string]::IsNullOrWhiteSpace($devId)

    $profileCount = 0
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root -PathType Container)) {
            continue
        }
        foreach ($profile in @(Get-ChildItem -LiteralPath $root -Directory -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -eq "Default" -or $_.Name -like "Profile *" })) {
            $profileCount++
            # Strict store-identity check first (unchanged production behavior),
            # then - only if a dev id is configured - the relaxed unpacked check.
            $profileMatched = Test-PurestateExtensionInProfile -ProfilePath $profile.FullName -ExpectedExtensionPath $ExpectedExtensionPath -ExpectedVersion $ExpectedVersion -ExpectedExtensionId $script:CompanionStoreId
            if (-not $profileMatched -and $devModeActive) {
                $profileMatched = Test-PurestateDevExtensionInProfile -ProfilePath $profile.FullName -DevExtensionId $devId
            }
            if (-not $profileMatched) {
                return $false
            }
        }
    }

    if ($profileCount -eq 0) {
        return $false
    }

    # A current heartbeat proves the Native Messaging path is alive, but it is
    # not the only proof that the Store-served Companion protection is present.
    # The managed Web Store install plus matching active profile is the primary
    # browser-protection contract; otherwise a transient native-host failure can
    # create a Chrome-close loop even though content scripts are force-installed.
    $heartbeatActive = if ($null -ne $HeartbeatPresent) {
        [bool]$HeartbeatPresent
    } else {
        Test-PurestateCompanionHeartbeat -Browser $Browser -ExpectedVersion $ExpectedVersion
    }
    if ($heartbeatActive) {
        # CMP-003: Ein gueltiger Herzschlag ist der Beweis, dass die Kette wieder
        # traegt. Damit ist der Merker aus einem frueheren Zwangsneustart erledigt
        # - sonst bekaeme dieser Browser nie wieder eine Startgnadenfrist, auch
        # nicht bei einem ganz normalen spaeteren Start durch den Nutzer.
        if (-not $PSBoundParameters.ContainsKey('HeartbeatPresent')) {
            Set-CompanionGraceSpentBrowser -Browser $Browser -Spent $false
        }
        return $true
    }

    $managedPolicyActive = if ($null -ne $ManagedPolicyPresent) {
        [bool]$ManagedPolicyPresent
    } else {
        Test-PurestateManagedCompanionPolicy -Browser $Browser
    }
    if (-not $managedPolicyActive) {
        return $false
    }

    # CMP-001: Die verwaltete Richtlinie schreibt Purestate selbst. Sie belegt,
    # dass die Erweiterung INSTALLIERT ist - nicht, dass sie LAEUFT. Als
    # unbefristeter Ersatz fuer den Herzschlag hiess das: faellt der Native Host
    # weg, laedt der Companion keinen Regelsatz mehr, die Vollsperre unterbleibt
    # trotzdem, und niemand meldet etwas. Der Rueckfall bleibt fuer den Fall, den
    # er wirklich loest - der Browser ist gerade gestartet und die
    # Native-Messaging-Kette noch nicht warm -, und er endet danach.
    #
    # CMP-002: Damit traegt die Startgnadenfrist endlich eine Entscheidung,
    # statt nur als Konstante mit Selbsttest herumzuliegen.
    $browserAge = if ($PSBoundParameters.ContainsKey('BrowserProcessAgeSeconds')) {
        $BrowserProcessAgeSeconds
    } else {
        Get-ChromiumBrowserProcessAgeSeconds -Browser $Browser
    }

    # Das Herzschlagalter wird nur gebraucht, wenn die Startgnadenfrist schon
    # abgelaufen ist - sonst bliebe die Datei bei jedem Durchsetzungslauf umsonst
    # gelesen.
    $heartbeatAge = if ($PSBoundParameters.ContainsKey('HeartbeatAgeSeconds')) {
        $HeartbeatAgeSeconds
    } elseif ($browserAge -ge 0 -and $browserAge -ge $script:CompanionBrowserStartupGraceSeconds) {
        Get-PurestateCompanionHeartbeatAgeSeconds -Browser $Browser -ExpectedVersion $ExpectedVersion
    } else {
        -1
    }

    # CMP-003: Wie bei DevCompanionId und GraceVersion unterscheidet
    # PSBoundParameters "nicht uebergeben" (Produktivpfad, selbst ermitteln) von
    # einem ausdruecklichen Wert (Tests).
    $graceSpent = if ($PSBoundParameters.ContainsKey('StartupGraceSpent')) {
        [bool]$StartupGraceSpent
    } else {
        (Get-CompanionGraceSpentBrowsers) -contains $Browser
    }

    return (Test-CompanionPolicyFallbackValid -BrowserProcessAgeSeconds $browserAge -HeartbeatAgeSeconds $heartbeatAge -StartupGraceSpent $graceSpent)
}

# Die eigentliche Regel des Rueckfalls, getrennt von allem Datei- und
# Registry-Zugriff: so kann der Selbsttest in Enforce-Protection.ps1 das
# Verhalten pruefen statt nur den Wert einer Konstanten (CMP-002).
function Test-CompanionPolicyFallbackValid {
    [CmdletBinding()]
    param(
        [double]$BrowserProcessAgeSeconds,
        [double]$HeartbeatAgeSeconds,
        [bool]$StartupGraceSpent = $false
    )

    $startupGrace = $script:CompanionBrowserStartupGraceSeconds

    # Laeuft gar kein Browser, gibt es nichts zu filtern, und der naechste Start
    # bekommt seine Gnadenfrist. Haerter zu urteilen wuerde nur
    # Durchsetzungslaeufe bei geschlossenem Browser verunsichern.
    if ($BrowserProcessAgeSeconds -lt 0) {
        return $true
    }

    # CMP-003, live gemessen am 2026-08-30: die Startgnadenfrist galt fuer JEDEN
    # jungen Browserprozess - auch fuer einen, den Purestate soeben SELBST
    # geschlossen und wieder geoeffnet hatte, weil der Herzschlag fehlte. Damit
    # stellte der Eingriff die Bedingung wieder her, unter der er nicht sperren
    # muss: Sperre nach 300 s, Schliessen, Neustart, wieder jung, wieder frei.
    # Gemessen ueber 15 Minuten mit totem Companion: 5 Neustarts, gesperrt in
    # 3 von 30 Abtastungen - der Schutz war rund 90 % der Zeit abwesend, und der
    # Browser schloss sich alle fuenfeinhalb Minuten.
    #
    # Die Gnade gilt jetzt nur noch fuer einen Start, den Purestate NICHT selbst
    # ausgeloest hat. Sie ist damit weiterhin da, wofuer sie gedacht war - der
    # Nutzer oeffnet den Browser, die Native-Messaging-Kette ist noch nicht warm -,
    # und sie ist genau dort weg, wo sie sich vorher selbst erneuerte. Ein
    # gueltiger Herzschlag loescht den Merker wieder (Test-PurestateExtensionForBrowser).
    if (-not $StartupGraceSpent -and $BrowserProcessAgeSeconds -lt $startupGrace) {
        return $true
    }

    # Ein Herzschlag, der eben erst abgelaufen ist, ist ein Aussetzer und kein
    # Ausfall: dafuer traegt die Richtlinie noch eine Gnadenfrist lang.
    return ($HeartbeatAgeSeconds -ge 0 -and
        $HeartbeatAgeSeconds -lt ($startupGrace + $script:CompanionHeartbeatMaxAgeSeconds))
}

function Test-ChromiumFailClosedPolicy {
    param([string]$PolicyPath)

    $expectedFilters = @(Get-ChromiumFailClosedFilters)
    if ($expectedFilters.Count -eq 0) {
        return $true
    }

    $listPath = Join-Path $PolicyPath "URLBlocklist"
    if (-not (Test-Path -LiteralPath $listPath)) {
        return $false
    }

    try {
        # BRW-001: Chromium wertet hoechstens 1000 Eintraege aus. Diese Pruefung
        # fragte frueher nur, ob der Wert IRGENDWO im Schluessel steht - ein
        # Eintrag auf Position 1200 haette die Sperre also als aktiv gemeldet,
        # obwohl der Browser ihn nie sieht. Die Kanarienvogel-Schwester dreissig
        # Zeilen weiter macht es laengst richtig (Get-PolicyStringListValues
        # liefert nach Nummer sortiert).
        $values = @(Get-PolicyStringListValues -Path $listPath | Select-Object -First 1000)
        foreach ($filter in $expectedFilters) {
            if ($values -notcontains $filter) {
                return $false
            }
        }
        return $true
    } catch {
        return $false
    }
}

function Test-ChromiumCanaryFailClosedPolicy {
    param([string]$PolicyPath)

    $expectedFilters = @(Get-ActiveCanaryFailClosedDomains)
    if ($expectedFilters.Count -eq 0) {
        return $true
    }

    $listPath = Join-Path $PolicyPath "URLBlocklist"
    if (-not (Test-Path -LiteralPath $listPath)) {
        return $false
    }

    try {
        $values = @(Get-PolicyStringListValues -Path $listPath | Select-Object -First 1000)
        foreach ($filter in $expectedFilters) {
            if ($values -notcontains $filter) {
                return $false
            }
        }
        return $true
    } catch {
        return $false
    }
}

function Test-BrowserCompanionPolicySyncNeeded {
    param(
        [bool]$ChromeActive,
        [bool]$EdgeActive,
        [bool]$ChromeFailClosed,
        [bool]$EdgeFailClosed,
        [bool]$ChromeCanaryFailClosed = $true,
        [bool]$EdgeCanaryFailClosed = $true
    )

    # Befund #4: nichts direkt zu sperren (z. B. frische Installation, alle
    # Bereiche aus) passt zu jedem Companion-Zustand - sonst meldete jeder
    # Herzschlag bei aktivem Companion faelschlich "Sync noetig", weil
    # Test-ChromiumFailClosedPolicy fuer eine leere Erwartung immer $true
    # liefert und das hier gegen den Companion-Zustand verglichen wurde.
    $nichtsErwartet = (@(Get-ChromiumFailClosedFilters).Count -eq 0)
    return (-not $nichtsErwartet -and ((-not $ChromeActive) -ne $ChromeFailClosed)) -or
        (-not $nichtsErwartet -and ((-not $EdgeActive) -ne $EdgeFailClosed)) -or
        (-not $ChromeCanaryFailClosed) -or
        (-not $EdgeCanaryFailClosed)
}

function Get-BrowserCompanionState {
    Assert-DataDirectoryIsNotReparsePoint
    if (-not (Test-Path -LiteralPath $script:BrowserCompanionStatePath -PathType Leaf)) {
        return $null
    }

    try {
        $state = Get-Content -Raw -LiteralPath $script:BrowserCompanionStatePath | ConvertFrom-Json
        if ($null -eq $state.PSObject.Properties["ChromeActive"] -or
            $null -eq $state.PSObject.Properties["EdgeActive"]) {
            return $null
        }
        return $state
    } catch {
        return $null
    }
}

function Get-BrowserCompanionStateChanges {
    param(
        $PreviousState,
        [bool]$ChromeActive,
        [bool]$EdgeActive,
        [string]$ExpectedVersion
    )

    $changes = @()
    if ($null -eq $PreviousState) {
        $changes += "Chrome"
        $changes += "Edge"
        return @($changes)
    }

    if ([string]$PreviousState.Version -ne $ExpectedVersion) {
        $changes += "Chrome"
        $changes += "Edge"
    }
    if ([bool]$PreviousState.ChromeActive -ne $ChromeActive) { $changes += "Chrome" }
    if ([bool]$PreviousState.EdgeActive -ne $EdgeActive) { $changes += "Edge" }
    return @($changes | Select-Object -Unique)
}

function Get-BrowserCompanionUnsafeStateChanges {
    param(
        $PreviousState,
        [bool]$ChromeActive,
        [bool]$EdgeActive
    )

    $changes = @()
    if ($null -eq $PreviousState) {
        if (-not $ChromeActive) { $changes += "Chrome" }
        if (-not $EdgeActive) { $changes += "Edge" }
        return @($changes)
    }
    if ([bool]$PreviousState.ChromeActive -and -not $ChromeActive) { $changes += "Chrome" }
    if ([bool]$PreviousState.EdgeActive -and -not $EdgeActive) { $changes += "Edge" }
    return @($changes)
}

function Get-BrowserFailClosedPolicyRefreshTargets {
    param(
        [bool]$ChromeActive,
        [bool]$EdgeActive,
        [bool]$ChromeFailClosed,
        [bool]$EdgeFailClosed,
        [bool]$ChromeCanaryFailClosed = $true,
        [bool]$EdgeCanaryFailClosed = $true
    )

    $targets = @()
    if ((-not $ChromeActive -and -not $ChromeFailClosed) -or (-not $ChromeCanaryFailClosed)) { $targets += "Chrome" }
    if ((-not $EdgeActive -and -not $EdgeFailClosed) -or (-not $EdgeCanaryFailClosed)) { $targets += "Edge" }
    return @($targets)
}

function Save-BrowserCompanionState {
    param(
        [bool]$ChromeActive,
        [bool]$EdgeActive,
        [string]$ExpectedVersion
    )

    Ensure-DataDir
    # BRW-003: Geschrieben wurde mit Set-Content - das kuerzt die Zieldatei
    # zuerst. Bricht der Vorgang ab, ist die JSON-Datei unvollstaendig, der
    # Leser faengt den Parserfehler ab und liefert $null - und "$null" heisst
    # an der Auswertungsstelle "es gab keinen Vorzustand", also gilt jeder
    # gerade inaktive Browser als frisch abgeschwaecht. Kosten tut das keinen
    # Schutz (die Richtung ist die strenge), aber es schliesst dem Nutzer
    # unangekuendigt Chrome UND Edge. Set-TextFileAtomically gibt es im Projekt
    # schon; das war die vierte Fundstelle desselben vergessenen Schritts.
    $json = [pscustomobject]@{
        ChromeActive = $ChromeActive
        EdgeActive = $EdgeActive
        Version = $ExpectedVersion
        CheckedAtUtc = [DateTime]::UtcNow.ToString("o")
    } | ConvertTo-Json
    Set-TextFileAtomically -Path $script:BrowserCompanionStatePath -Value $json
}

# Programm und angemeldeter Besitzer eines laufenden Browsers. Beides muss VOR
# dem Schliessen feststehen: danach gibt es den Prozess nicht mehr, und ohne
# Besitzer laesst sich der Browser nicht im Kontext des angemeldeten Nutzers
# zurueckholen (Dienst und App laufen als SYSTEM bzw. erhoeht - ein von dort
# gestarteter Browser haette das falsche Profil).
function Get-BrowserRestartTarget {
    param([System.Diagnostics.Process[]]$Processes)

    foreach ($process in @($Processes)) {
        $path = ""
        try { $path = [string]$process.Path } catch { }
        if ([string]::IsNullOrEmpty($path)) {
            continue
        }

        $owner = ""
        try {
            $wmi = Get-CimInstance -ClassName Win32_Process -Filter "ProcessId = $($process.Id)" -ErrorAction Stop
            $result = Invoke-CimMethod -InputObject $wmi -MethodName GetOwner -ErrorAction Stop
            if ($result.ReturnValue -eq 0 -and -not [string]::IsNullOrEmpty($result.User)) {
                $owner = if ([string]::IsNullOrEmpty($result.Domain)) { $result.User } else { $result.Domain + "\" + $result.User }
            }
        } catch { }

        if (-not [string]::IsNullOrEmpty($owner)) {
            # BRW-006: Die Sitzungskennung entscheidet spaeter, wessen Browser
            # gezaehlt wird. Ohne sie sah die Wartebedingung die Chrome-Prozesse
            # ALLER angemeldeten Nutzer.
            $sessionId = -1
            try { $sessionId = [int]$process.SessionId } catch { }
            return [pscustomobject]@{ Path = $path; Owner = $owner; SessionId = $sessionId }
        }
    }

    return $null
}

# Argumente fuer die Einmalaufgabe, die den Browser im Nutzerkontext
# zurueckholt. /IT laeuft mit dem interaktiven Token des angemeldeten Nutzers,
# deshalb ohne gespeichertes Passwort. --restore-last-session bringt die Tabs
# der beendeten Sitzung zurueck, ohne die Startseiten-Einstellung des Nutzers
# dauerhaft zu aendern.
function Get-BrowserRestartTaskArguments {
    param(
        [string]$TaskName,
        [string]$ExecutablePath,
        [string]$Owner
    )

    # KEINE aeusseren Anfuehrungszeichen: PowerShell setzt sie beim Aufruf
    # selbst um jedes Argument mit Leerzeichen. Mit eigenen kamen sie doppelt
    # an, schtasks zerlegte den Pfad an "Program Files" und meldete
    # "Ungueltige(s) Option/Argument" - live beim Installieren gefunden.
    # Die inneren \" bleiben noetig, damit schtasks Programm und Argument
    # trennt.
    return @(
        "/Create", "/TN", $TaskName,
        "/SC", "ONCE", "/ST", "23:59",
        "/RU", $Owner, "/IT",
        "/TR", ('\"' + $ExecutablePath + '\" --restore-last-session'),
        "/F"
    )
}

# Argumente fuer die Einmalaufgabe, die den Browser im Nutzerkontext schliesst.
# Befund L-10 (live 2026-08-05): der Durchsetzungslauf des Dienstes laeuft als
# LocalSystem in Session 0, der Browser in der Sitzung des Nutzers.
# CloseMainWindow ist eine Fensternachricht und kreuzt diese Grenze NICHT - der
# Aufruf meldet Erfolg, das Fenster bleibt offen, die 10-Sekunden-Schleife
# laeuft leer aus. Gemessen: drei Takte hintereinander "postponed", derselbe
# Aufruf aus einer Aufgabe im Nutzerkontext schloss Chrome in einer Sekunde.
#
# taskkill OHNE /F schickt dasselbe WM_CLOSE wie CloseMainWindow, also kein
# Hard-Kill und keine verlorenen Tabs. Der naheliegende Weg ueber
# powershell -EncodedCommand scheitert: schtasks nimmt fuer /TR hoechstens 261
# Zeichen, der kodierte Einzeiler ist laenger.
function Get-BrowserCloseTaskArguments {
    param(
        [string]$TaskName,
        [string]$ProcessName,
        [string]$Owner
    )

    $taskkill = Join-Path $env:SystemRoot "System32\taskkill.exe"

    # Quoting wie in Get-BrowserRestartTaskArguments: keine aeusseren
    # Anfuehrungszeichen, innen \" um den Programmpfad.
    return @(
        "/Create", "/TN", $TaskName,
        "/SC", "ONCE", "/ST", "23:59",
        "/RU", $Owner, "/IT",
        "/TR", ('\"' + $taskkill + '\" /IM ' + $ProcessName + '.exe'),
        "/F"
    )
}

function Close-ChromiumBrowserInUserSession {
    param(
        [string]$ProcessName,
        $RestartTarget
    )

    if ($null -eq $RestartTarget) {
        return $false
    }

    # Wie beim Neustart: darf den Aufrufer unter keinen Umstaenden abbrechen.
    # Gelingt die Aufgabe nicht, bleibt es beim Versuch per CloseMainWindow und
    # der Lauf verschiebt den Refresh wie bisher.
    $previousPreference = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $schtasks = Get-SystemToolPath -Name "schtasks.exe"
    $taskName = "\Purestate\BrowserClose"
    try {
        $arguments = @(Get-BrowserCloseTaskArguments -TaskName $taskName -ProcessName $ProcessName -Owner $RestartTarget.Owner)
        $createOutput = (& $schtasks @arguments 2>&1) -join " "
        if ($LASTEXITCODE -ne 0) {
            Add-AppLog "Browser close task could not be created: $createOutput"
            return $false
        }

        $runOutput = (& $schtasks @("/Run", "/TN", $taskName) 2>&1) -join " "
        if ($LASTEXITCODE -ne 0) {
            Add-AppLog "Browser close task could not be started: $runOutput"
            return $false
        }

        return $true
    } catch {
        Add-AppLog "Browser close in user session failed: $($_.Exception.Message)"
        return $false
    } finally {
        & $schtasks @("/Delete", "/TN", $taskName, "/F") 2>&1 | Out-Null
        $ErrorActionPreference = $previousPreference
    }
}

function Restore-ChromiumBrowserSession {
    param(
        [ValidateSet("Chrome", "Edge")][string]$Browser,
        $RestartTarget
    )

    if ($null -eq $RestartTarget) {
        Add-AppLog "$Browser could not be restarted automatically (no owner or path)."
        return $false
    }

    # Der Neustart ist Komfort, kein Schutz. Er darf unter KEINEN Umstaenden
    # den Aufrufer abbrechen: schtasks schreibt auch bei harmlosen Faellen auf
    # stderr, und unter $ErrorActionPreference = "Stop" wird daraus eine
    # Ausnahme. Genau so hat ein fehlgeschlagener Neustart am 2026-08-02 die
    # komplette Installation abgebrochen.
    $previousPreference = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $schtasks = Get-SystemToolPath -Name "schtasks.exe"
    $taskName = "\Purestate\BrowserRestart"
    try {
        $arguments = @(Get-BrowserRestartTaskArguments -TaskName $taskName -ExecutablePath $RestartTarget.Path -Owner $RestartTarget.Owner)
        $createOutput = (& $schtasks @arguments 2>&1) -join " "
        if ($LASTEXITCODE -ne 0) {
            Add-AppLog "$Browser restart task could not be created: $createOutput"
            return $false
        }

        $runOutput = (& $schtasks @("/Run", "/TN", $taskName) 2>&1) -join " "
        if ($LASTEXITCODE -ne 0) {
            Add-AppLog "$Browser restart task could not be started: $runOutput"
            return $false
        }

        Add-AppLog "$Browser was restarted with the previous session."
        return $true
    } catch {
        Add-AppLog "$Browser restart failed: $($_.Exception.Message)"
        return $false
    } finally {
        & $schtasks @("/Delete", "/TN", $taskName, "/F") 2>&1 | Out-Null
        $ErrorActionPreference = $previousPreference
    }
}

# Ein aufgeschobener Richtlinien-Refresh muss den Lauf ueberleben. Ohne diesen
# Marker haengt die Wiederholung daran, dass sich die Sperrliste ERNEUT aendert -
# das passiert nie, weil die Registry beim ersten Versuch schon geschrieben war.
# Der Browser erzwingt dann die alte Liste bis zu seinem eigenen Refresh weiter.
# Live gemessen am 2026-08-04: eine Erwachsenen-Freigabe war in hosts, Registry
# und Companion wirksam, blieb in Chrome aber gesperrt.
function Get-PendingPolicyRefreshPath {
    return (Join-Path $script:DataDir "pending-policy-refresh.txt")
}

# CMP-003: Merker fuer "dieser Browser wurde von Purestate selbst neu gestartet,
# die Startgnadenfrist ist damit verbraucht". Gleiche Form wie der Merker fuer
# den aufgeschobenen Refresh: eine Zeile je Browser, Datei weg heisst leer.
function Get-CompanionGraceSpentPath {
    return (Join-Path $script:DataDir "companion-grace-spent.txt")
}

function Get-CompanionGraceSpentBrowsers {
    $path = Get-CompanionGraceSpentPath
    if (-not (Test-Path -LiteralPath $path)) {
        return @()
    }
    try {
        return @(Get-Content -LiteralPath $path -ErrorAction Stop |
            ForEach-Object { $_.Trim() } |
            Where-Object { $_ -eq "Chrome" -or $_ -eq "Edge" } |
            Select-Object -Unique)
    } catch {
        return @()
    }
}

function Set-CompanionGraceSpentBrowser {
    param(
        [ValidateSet("Chrome", "Edge")][string]$Browser,
        [bool]$Spent
    )

    $browsers = @(Get-CompanionGraceSpentBrowsers | Where-Object { $_ -ne $Browser })
    if ($Spent) {
        $browsers = @($browsers) + @($Browser)
    }

    $path = Get-CompanionGraceSpentPath
    try {
        if (@($browsers).Count -eq 0) {
            Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
        } else {
            Set-Content -LiteralPath $path -Value @($browsers) -Encoding UTF8
        }
    } catch {
        # Wie beim Refresh-Merker: ein Schreibfehler darf die Durchsetzung nicht
        # stoppen, aber er darf auch nicht stumm bleiben. Faellt der Merker aus,
        # ist der Zustand wieder der von CMP-003.
        try {
            Add-AppLog "Merker fuer die verbrauchte Startgnadenfrist ($Browser) konnte nicht geschrieben werden: $($_.Exception.Message)"
        } catch {
        }
    }
}

function Get-PendingPolicyRefreshBrowsers {
    $path = Get-PendingPolicyRefreshPath
    if (-not (Test-Path -LiteralPath $path)) {
        return @()
    }
    try {
        return @(Get-Content -LiteralPath $path -ErrorAction Stop |
            ForEach-Object { $_.Trim() } |
            Where-Object { $_ -eq "Chrome" -or $_ -eq "Edge" } |
            Select-Object -Unique)
    } catch {
        return @()
    }
}

function Set-PendingPolicyRefreshBrowser {
    param(
        [ValidateSet("Chrome", "Edge")][string]$Browser,
        [bool]$Pending
    )

    $browsers = @(Get-PendingPolicyRefreshBrowsers | Where-Object { $_ -ne $Browser })
    if ($Pending) {
        $browsers = @($browsers) + @($Browser)
    }

    $path = Get-PendingPolicyRefreshPath
    try {
        if (@($browsers).Count -eq 0) {
            Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
        } else {
            Set-Content -LiteralPath $path -Value @($browsers) -Encoding UTF8
        }
    } catch {
        # Ein fehlgeschlagener Marker darf die Durchsetzung nie stoppen - der
        # leere catch bleibt also richtig. Er darf aber nicht STUMM sein:
        # BRW-004. Dieser Merker ist die Korrektur fuer den live gemessenen
        # Befund L-9 (eine Freigabe war ueberall wirksam und blieb in Chrome
        # trotzdem gesperrt). Scheitert das Schreiben, geht der aufgeschobene
        # Refresh verloren und der Zustand ist exakt wieder L-9 - bisher ohne
        # eine Zeile, an der man das haette erkennen koennen.
        try {
            Add-AppLog "Merker fuer den aufgeschobenen Richtlinien-Refresh ($Browser) konnte nicht geschrieben werden: $($_.Exception.Message)"
        } catch {
        }
    }
}

# Die Browser, die dieser Lauf neu laden muss: die mit geaenderter Sperrliste
# PLUS die, deren Refresh ein frueherer Lauf nicht durchbekommen hat.
function Get-PolicyRefreshBrowsers {
    param([string[]]$ChangedBrowsers)

    return @(@($ChangedBrowsers) + @(Get-PendingPolicyRefreshBrowsers) |
        Where-Object { $_ } |
        Select-Object -Unique)
}

# BRW-006: Ohne Sitzungskennung (kein ermittelter Besitzer) bleibt es beim
# alten Verhalten - alle Prozesse zaehlen.
function Select-BrowserProcessesInSession {
    param(
        $Processes,
        [int]$SessionId
    )

    if ($SessionId -lt 0) {
        return @($Processes)
    }

    return @(@($Processes) | Where-Object { $_.SessionId -eq $SessionId })
}

function Stop-ChromiumBrowserForPolicyRefresh {
    param([ValidateSet("Chrome", "Edge")][string]$Browser)

    $processName = if ($Browser -eq "Chrome") { "chrome" } else { "msedge" }
    $processes = @(Get-Process -Name $processName -ErrorAction SilentlyContinue)
    if ($processes.Count -eq 0) {
        # Kein laufender Browser: der naechste Start liest die aktuelle
        # Richtlinie ohnehin, ein gemerkter Refresh waere dann nur ein
        # ueberfluessiges Schliessen der ersten Sitzung.
        Set-PendingPolicyRefreshBrowser -Browser $Browser -Pending $false
        return $false
    }

    $restartTarget = Get-BrowserRestartTarget -Processes $processes

    # BRW-006: Nur die Sitzung, die auch die Schliess-Aufgabe bekommt. Sonst
    # schliesst der Lauf die Fenster eines zweiten angemeldeten Nutzers mit,
    # und die Wartebedingung zaehlt dessen Prozesse gegen den Refresh - der
    # Merker bliebe "pending" und jeder Lauf schloesse den ersten Nutzer erneut.
    $sessionId = if ($null -ne $restartTarget) { [int]$restartTarget.SessionId } else { -1 }
    $sessionProcesses = @(Select-BrowserProcessesInSession -Processes $processes -SessionId $sessionId)

    foreach ($process in @($sessionProcesses | Where-Object { $_.MainWindowHandle -ne 0 })) {
        try { $process.CloseMainWindow() | Out-Null } catch {}
    }

    # Aus dem Dienst erreicht die Zeile darueber kein Fenster (Befund L-10,
    # Session-Grenze). Der Weg ueber den Nutzerkontext holt genau das nach;
    # laeuft der Lauf ohnehin schon in der Sitzung des Nutzers, ist der
    # Browser hier meist bereits am Beenden und die Aufgabe findet nichts mehr.
    Close-ChromiumBrowserInUserSession -ProcessName $processName -RestartTarget $restartTarget | Out-Null

    # Frueher: 1,5 Sekunden warten, dann Stop-Process -Force. Der harte Abbruch
    # kostete ungespeicherte Eingaben und liess Chromium beim naechsten Start
    # die Absturzwiederherstellung zeigen. Jetzt bekommt der Browser Zeit zum
    # sauberen Beenden; bleibt er offen (Nachfrage zu ungespeicherten Daten),
    # wird NICHT abgeschossen - der naechste Durchlauf versucht es erneut.
    $deadline = [DateTime]::UtcNow.AddSeconds(10)
    do {
        Start-Sleep -Milliseconds 500
        $remaining = @(Select-BrowserProcessesInSession -Processes @(Get-Process -Name $processName -ErrorAction SilentlyContinue) -SessionId $sessionId)
    } while ($remaining.Count -gt 0 -and [DateTime]::UtcNow -lt $deadline)

    if ($remaining.Count -gt 0) {
        Set-PendingPolicyRefreshBrowser -Browser $Browser -Pending $true
        Add-AppLog "$Browser stayed open; policy refresh postponed to the next pass."
        return $false
    }

    Set-PendingPolicyRefreshBrowser -Browser $Browser -Pending $false
    Add-AppLog "$Browser was closed once so the changed Companion policy is loaded on restart."
    # CMP-003: Der gleich neu geoeffnete Prozess ist zwar jung, aber es ist kein
    # Start des Nutzers - die Native-Messaging-Kette hatte ihre Chance bereits.
    # Ohne diesen Merker begaenne die Startgnadenfrist hier von vorn, und der
    # Kreislauf aus Sperre, Schliessen und Neustart liefe endlos weiter.
    Set-CompanionGraceSpentBrowser -Browser $Browser -Spent $true
    Restore-ChromiumBrowserSession -Browser $Browser -RestartTarget $restartTarget | Out-Null
    return $true
}

function Update-BrowserCompanionState {
    param(
        [bool]$ChromeActive,
        [bool]$EdgeActive,
        [bool]$RestartChangedBrowsers
    )

    $previous = Get-BrowserCompanionState
    $expectedVersion = Get-PurestateAppVersion
    $changes = @(Get-BrowserCompanionStateChanges -PreviousState $previous -ChromeActive $ChromeActive -EdgeActive $EdgeActive -ExpectedVersion $expectedVersion)
    $unsafeChanges = @(Get-BrowserCompanionUnsafeStateChanges -PreviousState $previous -ChromeActive $ChromeActive -EdgeActive $EdgeActive)
    Save-BrowserCompanionState -ChromeActive $ChromeActive -EdgeActive $EdgeActive -ExpectedVersion $expectedVersion

    if ($RestartChangedBrowsers) {
        foreach ($browser in $unsafeChanges) {
            Stop-ChromiumBrowserForPolicyRefresh -Browser $browser | Out-Null
        }
    }
    return @($changes)
}

function Sync-BrowserCompanionPolicies {
    param([bool]$RestartChangedBrowsers = $true)

    # Repair the managed install contract on every fast browser pass. A stale
    # fail-closed URL list must never hide a missing Companion install policy.
    Ensure-NativeMessagingHostRegistration
    Ensure-ManagedCompanionPolicy

    $chromeActive = Test-PurestateExtensionForBrowser -Browser Chrome
    $edgeActive = Test-PurestateExtensionForBrowser -Browser Edge
    $chromeFailClosed = Test-ChromiumFailClosedPolicy -PolicyPath "HKLM:\SOFTWARE\Policies\Google\Chrome"
    $edgeFailClosed = Test-ChromiumFailClosedPolicy -PolicyPath "HKLM:\SOFTWARE\Policies\Microsoft\Edge"
    $chromeCanaryFailClosed = Test-ChromiumCanaryFailClosedPolicy -PolicyPath "HKLM:\SOFTWARE\Policies\Google\Chrome"
    $edgeCanaryFailClosed = Test-ChromiumCanaryFailClosedPolicy -PolicyPath "HKLM:\SOFTWARE\Policies\Microsoft\Edge"
    $refreshTargets = @(Get-BrowserFailClosedPolicyRefreshTargets -ChromeActive $chromeActive -EdgeActive $edgeActive -ChromeFailClosed $chromeFailClosed -EdgeFailClosed $edgeFailClosed -ChromeCanaryFailClosed $chromeCanaryFailClosed -EdgeCanaryFailClosed $edgeCanaryFailClosed)

    $policyChanged = Test-BrowserCompanionPolicySyncNeeded -ChromeActive $chromeActive -EdgeActive $edgeActive -ChromeFailClosed $chromeFailClosed -EdgeFailClosed $edgeFailClosed -ChromeCanaryFailClosed $chromeCanaryFailClosed -EdgeCanaryFailClosed $edgeCanaryFailClosed
    if ($policyChanged) {
        Add-AppLog "Companion state and browser policy differ. ChromeActive=$chromeActive EdgeActive=$edgeActive. Browser policies will be synchronized."
        $refreshTargets = @(@($refreshTargets) + @(Enable-BrowserPolicies -ChromeActive $chromeActive -EdgeActive $edgeActive) | Select-Object -Unique)
    }

    $stateChanges = @(Update-BrowserCompanionState -ChromeActive $chromeActive -EdgeActive $edgeActive -RestartChangedBrowsers $RestartChangedBrowsers)
    if ($RestartChangedBrowsers) {
        foreach ($browser in $refreshTargets) {
            Stop-ChromiumBrowserForPolicyRefresh -Browser $browser | Out-Null
        }
    }
    return ($policyChanged -or $stateChanges.Count -gt 0)
}

# B-2: Frueher startete jedes Speichern die Browser neu, weil der Abriss die
# Sperrliste immer "geaendert" hatte. Jetzt nur noch bei echter Aenderung -
# auch dann, wenn sich nur ein Einzelwert wie ForceYouTubeRestrict aendert,
# sonst greift der Schalter im offenen Browser erst nach dem naechsten
# Richtlinien-Neuladen.
function Set-ConditionalPolicyValue {
    param(
        [string]$Path,
        [string]$Name,
        [bool]$Enabled,
        [int]$Value
    )

    $current = (Get-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction SilentlyContinue).$Name
    if ($Enabled) {
        if ($null -ne $current -and [int]$current -eq $Value) {
            return $false
        }
        New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType DWord -Force | Out-Null
        return $true
    }
    if ($null -eq $current) {
        return $false
    }
    Remove-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue
    return $true
}

# Liefert die Chromium-Browser, deren Sperrliste sich bei diesem Lauf
# tatsaechlich geaendert hat. Der Aufrufer laedt genau diese neu - eine
# Einstellungsaenderung soll sofort greifen, ohne dass der Nutzer warten muss,
# bis Chromium seine Richtlinien von sich aus neu liest.
function Enable-BrowserPolicies {
    # BRW-005: Der Companion-Zustand wurde je Lauf vier Mal ermittelt - zwei Mal
    # fuer die Entscheidung, einmal je Browser fuer die geschriebene Sperrliste.
    # Zwischen den Aufrufen kann der Heartbeat ablaufen, dann widersprechen sich
    # Sperrliste, Protokoll und gespeicherter Zustand. Wer den Zustand schon
    # kennt, reicht ihn durch.
    param(
        [object]$ChromeActive = $null,
        [object]$EdgeActive = $null
    )

    Ensure-ManagedCompanionPolicy
    if ($null -eq $ChromeActive) { $ChromeActive = Test-PurestateExtensionForBrowser -Browser Chrome }
    if ($null -eq $EdgeActive) { $EdgeActive = Test-PurestateExtensionForBrowser -Browser Edge }
    $config = Get-Config
    $changedBrowsers = @()
    $mixedSitePatterns = Get-MixedSiteUrlPatterns
    $chromiumTargets = @(
        @{
            Path = "HKLM:\SOFTWARE\Policies\Google\Chrome"
            PrivateModeName = "IncognitoModeAvailability"
            ProfilePolicyName = "BrowserAddPersonEnabled"
            Browser = "Chrome"
        },
        @{
            Path = "HKLM:\SOFTWARE\Policies\Microsoft\Edge"
            PrivateModeName = "InPrivateModeAvailability"
            ProfilePolicyName = "BrowserAddProfileEnabled"
            Browser = "Edge"
        }
    )

    foreach ($target in $chromiumTargets) {
        try {
            $path = $target.Path
            Ensure-RegistryKey -Path $path
            New-ItemProperty -Path $path -Name "DnsOverHttpsMode" -Value "off" -PropertyType String -Force | Out-Null
            New-ItemProperty -Path $path -Name "ProxyMode" -Value "direct" -PropertyType String -Force | Out-Null
            New-ItemProperty -Path $path -Name "SafeBrowsingProtectionLevel" -Value 2 -PropertyType DWord -Force | Out-Null
            New-ItemProperty -Path $path -Name $target.PrivateModeName -Value 1 -PropertyType DWord -Force | Out-Null
            New-ItemProperty -Path $path -Name "BrowserGuestModeEnabled" -Value 0 -PropertyType DWord -Force | Out-Null
            New-ItemProperty -Path $path -Name $target.ProfilePolicyName -Value 0 -PropertyType DWord -Force | Out-Null
            $policyChanged = $false
            # Bereich Erwachseneninhalte aus: WEG statt 0, gleiches Muster wie
            # ForceYouTubeRestrict direkt darunter (eine gesetzte Richtlinie
            # sperrt die Einstellung im Browser).
            if (Set-ConditionalPolicyValue -Path $path -Name "ForceGoogleSafeSearch" -Enabled ([bool]$config.AdultContentProtectionEnabled) -Value 1) {
                $policyChanged = $true
            }
            # Moderate YouTube restricted mode (1): filters adult/offensive
            # videos without the strict mode's heavy overblocking. Abschaltbar
            # seit Schema 13 - der Filter sperrt regelmaessig harmlose Videos
            # aus. Beim Abschalten muss der Wert WEG, nicht auf 0: eine
            # gesetzte Richtlinie sperrt die Einstellung im Browser, und "0"
            # hiesse "aus, und der Nutzer darf es nicht mehr aendern".
            if (Set-ConditionalPolicyValue -Path $path -Name "ForceYouTubeRestrict" -Enabled ([bool]$config.YouTubeRestrictEnabled) -Value 1) {
                $policyChanged = $true
            }
            if ($target.Browser -eq "Edge") {
                # Edge-only policy (Chrome has no Bing safe-search policy):
                # 2 = strict Bing SafeSearch. Chromium-side backstop for the
                # companion's adlt=strict URL rewrite.
                if (Set-ConditionalPolicyValue -Path $path -Name "ForceBingSafeSearch" -Enabled ([bool]$config.AdultContentProtectionEnabled) -Value 2) {
                    $policyChanged = $true
                }
            }
            $extensionActive = if ($target.Browser -eq "Chrome") { [bool]$ChromeActive } else { [bool]$EdgeActive }
            $browserPatterns = Merge-ChromiumUrlFilters -BasePatterns $mixedSitePatterns -FailClosed (-not $extensionActive)
            $listChanged = Set-PurestateManagedUrlList -Path $path -ListName "URLBlocklist" -Values $browserPatterns
            if ($policyChanged -or $listChanged) {
                $changedBrowsers += $target.Browser
            }
        } catch {
            Add-AppLog "Browser policy failed for $($path): $($_.Exception.Message)"
        }
    }

    try {
        $firefoxRoot = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"
        Ensure-RegistryKey -Path $firefoxRoot
        New-ItemProperty -Path $firefoxRoot -Name "DisablePrivateBrowsing" -Value 1 -PropertyType DWord -Force | Out-Null
        $firefoxPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS"
        Ensure-RegistryKey -Path $firefoxPath
        New-ItemProperty -Path $firefoxPath -Name "Enabled" -Value 0 -PropertyType DWord -Force | Out-Null
        New-ItemProperty -Path $firefoxPath -Name "Locked" -Value 1 -PropertyType DWord -Force | Out-Null
        $firefoxProxyPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\Proxy"
        Ensure-RegistryKey -Path $firefoxProxyPath
        New-ItemProperty -Path $firefoxProxyPath -Name "Mode" -Value "none" -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $firefoxProxyPath -Name "Locked" -Value 1 -PropertyType DWord -Force | Out-Null
        $firefoxPatterns = Merge-BrowserUrlPatterns -BasePatterns $mixedSitePatterns -FailClosed $true
        # Firefox bleibt bewusst aussen vor: es liest Richtlinien nur beim
        # Start und kennt kein Gegenstueck zu --restore-last-session. Ein
        # erzwungener Neustart koennte hier Sitzungen kosten, statt sie zu
        # retten - die Aenderung greift beim naechsten Firefox-Start.
        Set-PurestateManagedUrlList -Path $firefoxRoot -ListName "WebsiteFilter\Block" -Values $firefoxPatterns | Out-Null
    } catch {
        Add-AppLog "Firefox policy failed: $($_.Exception.Message)"
    }

    return @($changedBrowsers)
}

function Disable-BrowserPolicies {
    param([switch]$RequireComplete)

    $policyTargets = @(
        @{
            Path = "HKLM:\SOFTWARE\Policies\Google\Chrome"
            PrivateModeName = "IncognitoModeAvailability"
            ProfilePolicyName = "BrowserAddPersonEnabled"
        },
        @{
            Path = "HKLM:\SOFTWARE\Policies\Microsoft\Edge"
            PrivateModeName = "InPrivateModeAvailability"
            ProfilePolicyName = "BrowserAddProfileEnabled"
        }
    )

    foreach ($target in $policyTargets) {
        $path = $target.Path
        foreach ($name in @("DnsOverHttpsMode", "ProxyMode", "SafeBrowsingProtectionLevel", $target.PrivateModeName, $target.ProfilePolicyName, "BrowserGuestModeEnabled", "ForceGoogleSafeSearch", "ForceYouTubeRestrict", "ForceBingSafeSearch")) {
            try {
                if (-not $RequireComplete -or (Get-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue)) {
                    Remove-ItemProperty -Path $path -Name $name -ErrorAction $(if ($RequireComplete) { "Stop" } else { "SilentlyContinue" })
                }
            } catch {
                if ($RequireComplete) { throw }
            }
        }

        # Remove only the URLBlocklist entries we added; keep third-party ones.
        Remove-PurestateManagedUrlList -Path $path -ListName "URLBlocklist" -RequireComplete:$RequireComplete
    }

    try {
        $firefox = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"
        if (-not $RequireComplete -or (Get-ItemProperty -Path $firefox -Name "DisablePrivateBrowsing" -ErrorAction SilentlyContinue)) {
            Remove-ItemProperty -Path $firefox -Name "DisablePrivateBrowsing" -ErrorAction $(if ($RequireComplete) { "Stop" } else { "SilentlyContinue" })
        }
        foreach ($child in @("DNSOverHTTPS", "Proxy")) {
            $childPath = Join-Path $firefox $child
            if (-not $RequireComplete -or (Test-Path -LiteralPath $childPath)) {
                Remove-Item -Path $childPath -Recurse -Force -ErrorAction $(if ($RequireComplete) { "Stop" } else { "SilentlyContinue" })
            }
        }
        # Remove only our own Firefox block entries; keep third-party ones.
        Remove-PurestateManagedUrlList -Path $firefox -ListName "WebsiteFilter\Block" -RequireComplete:$RequireComplete
    } catch {
        if ($RequireComplete) { throw }
    }
}

function Get-BypassAppKeywords {
    $path = Join-Path (Get-AppRoot) "rules\bypass-app-keywords.txt"
    $keywords = @()

    if (-not (Test-Path -LiteralPath $path)) {
        return @()
    }

    foreach ($raw in Get-Content -LiteralPath $path) {
        $line = ([string]$raw).Trim().ToLowerInvariant()
        if ($line.Length -eq 0 -or $line.StartsWith("#")) {
            continue
        }

        if ($line -match "^[a-z0-9-]{3,32}$" -and $keywords -notcontains $line) {
            $keywords += $line
        }
    }

    return @($keywords)
}

# Ein Stichwort trifft nur als GANZES WORT. Vorher wurde als Teilzeichenkette
# gegen den vollstaendigen Pfad geprueft, und jeder Treffer bekommt eine
# Firewallregel: "tor" sperrte damit Illustrator.exe, TortoiseGitProc.exe und
# jedes Programm unter C:\Users\Viktor (RUL-001). Der C#-Zwilling
# (src\NativeSupportBypass.cs:334-387) loest dasselbe zweistufig - kurzes Token
# nur als exakter Prozessname, im Pfad nur mehrwortige Phrasen; die Wortgrenze
# deckt beide Stufen ab und laesst die Stichwortdateien unveraendert.
function Test-RuleKeywordInPath {
    param(
        [string]$Path,
        [string[]]$Keywords
    )

    $value = ([string]$Path).ToLowerInvariant()
    foreach ($keyword in $Keywords) {
        $term = ([string]$keyword).Trim().ToLowerInvariant()
        if ($term.Length -eq 0) {
            continue
        }

        # Nur BUCHSTABEN sind Wortgrenze, Ziffern nicht: sonst faellt
        # "psiphon3.exe" aus der Erkennung, waehrend "Illustrator.exe" (Buchstabe
        # vor "tor") weiterhin sauber durchfaellt.
        if ($value -match ('(?<![a-z])' + [regex]::Escape($term) + '(?![a-z])')) {
            return $true
        }
    }

    return $false
}

function Test-BypassPath {
    param(
        [string]$Path,
        [string[]]$Keywords
    )

    return Test-RuleKeywordInPath -Path $Path -Keywords $Keywords
}

function Add-ExistingBypassCandidate {
    param(
        [System.Collections.Generic.List[string]]$Paths,
        [string]$Path
    )

    try {
        if ((Test-Path -LiteralPath $Path -PathType Leaf) -and -not $Paths.Contains($Path)) {
            $Paths.Add($Path)
        }
    } catch {
    }
}

function Get-BypassExecutableCandidates {
    $keywords = Get-BypassAppKeywords
    $paths = New-Object System.Collections.Generic.List[string]

    $programRoots = @(
        $env:ProgramFiles,
        ${env:ProgramFiles(x86)},
        $env:LocalAppData
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }

    $relativeExecutables = @(
        "Tor Browser\Browser\firefox.exe",
        "Mullvad Browser\Browser\firefox.exe",
        "OpenVPN\bin\openvpn.exe",
        "WireGuard\wireguard.exe",
        "Tailscale\tailscale-ipn.exe",
        "ZeroTier\One\zerotier-one_x64.exe",
        "ZeroTier\One\zerotier_desktop_ui.exe",
        "LogMeIn Hamachi\hamachi-2-ui.exe",
        "NordVPN\NordVPN.exe",
        "Proton VPN\ProtonVPN.exe",
        "ProtonVPN\ProtonVPN.exe",
        "Surfshark\Surfshark.exe",
        "ExpressVPN\expressvpn-ui\ExpressVPN.exe",
        "Windscribe\Windscribe.exe",
        "Psiphon\psiphon3.exe",
        "UltraSurf\u.exe"
    )

    foreach ($root in $programRoots) {
        foreach ($relative in $relativeExecutables) {
            Add-ExistingBypassCandidate -Paths $paths -Path (Join-Path $root $relative)
        }
    }

    try {
        foreach ($process in Get-Process -ErrorAction SilentlyContinue) {
            $path = ""
            try {
                $path = [string]$process.Path
            } catch {
            }

            if (-not [string]::IsNullOrWhiteSpace($path) -and (Test-BypassPath -Path $path -Keywords $keywords) -and -not $paths.Contains($path)) {
                $paths.Add($path)
            }

            if ($paths.Count -ge 80) {
                break
            }
        }
    } catch {
    }

    return @($paths | Sort-Object -Unique)
}

# Billige Vorabfrage fuer den Abgleich (B-2): Get-NetFirewallRule mit Muster
# kostete in der VM 31 s, auch ohne einen einzigen Treffer. Die COM-
# Schnittstelle liefert dieselben Namen (Rule.Name ist der Anzeigename) in
# einem Bruchteil davon. Geht keine der beiden Schnittstellen, lieber $true:
# dann versucht der Abbau es und meldet selbst, wenn er scheitert.
function Test-PurestateFirewallRulesPresent {
    param([Parameter(Mandatory = $true)][string]$Prefix)

    try {
        $policy = New-Object -ComObject HNetCfg.FwPolicy2
        foreach ($rule in @($policy.Rules)) {
            if (([string]$rule.Name).StartsWith($Prefix, [StringComparison]::OrdinalIgnoreCase)) {
                return $true
            }
        }
        return $false
    } catch {
    }

    try {
        if (Get-Command Get-NetFirewallRule -ErrorAction SilentlyContinue) {
            # M5: SilentlyContinue verschluckte einen Fehlschlag der Abfrage
            # selbst und lieferte dann eine leere Liste statt eines Fehlers -
            # die Funktion meldete "keine Regel da", obwohl sie es nicht
            # wissen konnte. Stop laesst einen solchen Fehler ins catch
            # durchfallen, das wie vorgesehen auf den letzten Ausweg $true faellt.
            return (@(Get-NetFirewallRule -DisplayName "$Prefix*" -ErrorAction Stop).Count -gt 0)
        }
    } catch {
    }

    return $true
}

# BYP-002 / FWL-002: Der Ersatzweg gab dem Sternchen an netsh weiter -
# "netsh advfirewall firewall delete rule name=" kennt aber KEINE Platzhalter,
# der Parameter will einen exakten Regelnamen oder "all". Der Aufruf suchte
# damit eine Regel, die woertlich "Purestate Bypass Block - *" heisst, fand
# nichts, und die Meldung darueber verschwand in Out-Null. Wo der Zweig je
# greift (Server Core, abgespecktes Image, defektes NetSecurity-Modul), blieben
# die Blockregeln stehen: der Nutzer sucht dann an der falschen Stelle, warum
# sein VPN nicht mehr laeuft, und nach einer Deinstallation ist es ein
# Rueckstand am System.
#
# Der Ersatz laeuft ueber die Firewall-COM-Schnittstelle statt ueber netsh.
# Der Grund ist nicht Eleganz: die Ausgabe von "netsh ... show rule name=all"
# ist LOKALISIERT ("Rule Name:" gegen "Regelname:"), ein Parser darauf waere
# auf einem deutschen Windows sofort falsch. Die COM-Schnittstelle gibt Namen
# als Daten zurueck und ist auf jedem Windows mit Firewall vorhanden, auch ohne
# das NetSecurity-Modul.
function Remove-PurestateFirewallRulesByPrefix {
    param([Parameter(Mandatory = $true)][string]$Prefix, [switch]$RequireComplete)

    try {
        if (Get-Command Get-NetFirewallRule -ErrorAction SilentlyContinue) {
            if ($RequireComplete) {
                # Query all rules so an empty matching set is success, while
                # a failed query/removal cannot masquerade as an empty set.
                Get-NetFirewallRule -ErrorAction Stop |
                    Where-Object { ([string]$_.DisplayName).StartsWith($Prefix, [StringComparison]::OrdinalIgnoreCase) } |
                    Remove-NetFirewallRule -ErrorAction Stop
            } else {
                Get-NetFirewallRule -DisplayName "$Prefix*" -ErrorAction SilentlyContinue |
                    Remove-NetFirewallRule -ErrorAction SilentlyContinue
            }
            return
        }
    } catch {
    }

    try {
        $policy = New-Object -ComObject HNetCfg.FwPolicy2
        $namen = @($policy.Rules |
            Where-Object { ([string]$_.Name).StartsWith($Prefix, [StringComparison]::OrdinalIgnoreCase) } |
            ForEach-Object { [string]$_.Name } |
            Select-Object -Unique)
        foreach ($name in $namen) {
            # Mehrere Regeln koennen denselben Namen tragen; Remove nimmt sie
            # zusammen, ein Aufruf je Name genuegt.
            try { $policy.Rules.Remove($name) } catch { if ($RequireComplete) { throw } }
        }
        return
    } catch {
    }

    # Weder Cmdlet noch COM: die Regeln bleiben stehen. Das gehoert ins
    # Protokoll, statt still zu misslingen - "vorhanden mit wirksam verwechselt"
    # ist genau die Falle, um die es hier geht.
    try {
        Add-SecurityLog -Message "Firewallregeln mit Praefix '$Prefix' konnten nicht entfernt werden: weder Get-NetFirewallRule noch die Firewall-COM-Schnittstelle sind verfuegbar."
    } catch {
    }
    if ($RequireComplete) { throw "Firewallregeln mit Praefix '$Prefix' konnten nicht vollstaendig entfernt werden." }
}

function Disable-BypassBlocking {
    param([switch]$RequireComplete)
    Remove-PurestateFirewallRulesByPrefix -Prefix $script:BypassFirewallPrefix -RequireComplete:$RequireComplete
}

# Die Programme, die derzeit hinter den Regeln mit diesem Praefix stehen.
# $null heisst "nicht feststellbar" - dann wird wie frueher neu gebaut.
# BYP-001: Eine Regel, die abgeschaltet wurde oder auf "Allow" steht, sperrt
# nichts. Frueher verglich der Aufrufer nur die Menge der Programmpfade und
# kehrte dann zurueck - eine deaktivierte Regel galt damit dauerhaft als
# vorhanden und wurde nie repariert. Genau der Angreifer des Bedrohungsmodells
# kommt an diesen Schalter (wf.msc, ein Klick).
function Select-EffectiveFirewallRules {
    param([object[]]$Rules)

    # Kein Komma-Wrap: der wuerde aus einer leeren Liste ein einelementiges
    # Array machen. Die Aufrufer normalisieren ohnehin mit @(...).
    return @(@($Rules) | Where-Object {
        $null -ne $_ -and
        ([string]$_.Enabled).Trim().ToLowerInvariant() -eq "true" -and
        ([string]$_.Action).Trim().ToLowerInvariant() -eq "block"
    })
}

function Get-PurestateFirewallRulePrograms {
    param([string]$Prefix)

    try {
        if (-not (Get-Command Get-NetFirewallRule -ErrorAction SilentlyContinue)) {
            return $null
        }
        $rules = @(Select-EffectiveFirewallRules -Rules @(
            Get-NetFirewallRule -DisplayName ($Prefix + "*") -ErrorAction SilentlyContinue))
        if ($rules.Count -eq 0) {
            # Komma-Wrap: eine zurueckgegebene leere Liste wuerde sonst zu
            # $null zerfallen und "keine Regeln" hiesse dann faelschlich
            # "nicht feststellbar" - der Aufrufer baute jedes Mal neu.
            return ,@()
        }
        return ,@($rules |
            Get-NetFirewallApplicationFilter -ErrorAction SilentlyContinue |
            ForEach-Object { [string]$_.Program })
    } catch {
        return $null
    }
}

# Mengenvergleich: Reihenfolge, Gross-/Kleinschreibung und Doppelte sind egal,
# Pfade vergleicht Windows ohnehin ohne Ruecksicht auf die Schreibweise.
function Test-PurestateFirewallProgramsMatch {
    param(
        [string[]]$Existing,
        [string[]]$Wanted
    )

    $left = @(@($Existing) | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() } | Where-Object { $_.Length -gt 0 } | Sort-Object -Unique)
    $right = @(@($Wanted) | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() } | Where-Object { $_.Length -gt 0 } | Sort-Object -Unique)
    if ($left.Count -ne $right.Count) {
        return $false
    }
    for ($i = 0; $i -lt $left.Count; $i++) {
        if ($left[$i] -ne $right[$i]) {
            return $false
        }
    }
    return $true
}

function Enable-BypassBlocking {
    $candidates = @(Get-BypassExecutableCandidates)

    # Steht der gewuenschte Satz schon in der Firewall, ist nichts zu tun.
    # Frueher loeschte jeder Durchsetzungslauf alle Regeln und legte sie neu
    # an - alle 30 Sekunden, gemessen 3,6 s pro Lauf, dazu eine Logzeile je
    # Programm. Die Reparatur bleibt: weicht der Satz ab, weil jemand eine
    # Regel entfernt oder hinzugefuegt hat, wird komplett neu gebaut.
    $existing = Get-PurestateFirewallRulePrograms -Prefix $script:BypassFirewallPrefix
    if ($null -ne $existing -and (Test-PurestateFirewallProgramsMatch -Existing $existing -Wanted $candidates)) {
        return
    }

    Disable-BypassBlocking

    if ($candidates.Count -eq 0) {
        Add-AppLog "Bypass protection found no known executables to block."
        return
    }

    $index = 1
    foreach ($path in $candidates) {
        try {
            $name = $script:BypassFirewallPrefix + $index
            if (Get-Command New-NetFirewallRule -ErrorAction SilentlyContinue) {
                New-NetFirewallRule -DisplayName $name -Direction Outbound -Program $path -Action Block -Profile Any -Enabled True -ErrorAction Stop | Out-Null
            } else {
                $netsh = Get-SystemToolPath -Name "netsh.exe"
                & $netsh advfirewall firewall add rule name="$name" dir=out action=block program="$path" enable=yes profile=any | Out-Null
            }

            Add-AppLog "Bypass protection blocked network access for $path."
            $index++
        } catch {
            Add-AppLog "Bypass protection failed for $($path): $($_.Exception.Message)"
        }
    }
}

function Get-UnsupportedBrowserKeywords {
    $path = Join-Path (Get-AppRoot) "rules\unsupported-browser-keywords.txt"
    $keywords = @()

    if (-not (Test-Path -LiteralPath $path)) {
        return @()
    }

    foreach ($raw in Get-Content -LiteralPath $path) {
        $line = ([string]$raw).Trim().ToLowerInvariant()
        if ($line.Length -eq 0 -or $line.StartsWith("#")) {
            continue
        }

        if ($line -match "^[a-z0-9-]{3,32}$" -and $keywords -notcontains $line) {
            $keywords += $line
        }
    }

    return @($keywords)
}

function Test-UnsupportedBrowserPath {
    param(
        [string]$Path,
        [string[]]$Keywords
    )

    # Wortgenau wie beim Umgehungsschutz (BYP-004: bis hierhin eine
    # zeichengleiche Dublette von Test-BypassPath).
    return Test-RuleKeywordInPath -Path $Path -Keywords $Keywords
}

function Add-ExistingUnsupportedBrowserCandidate {
    param(
        [System.Collections.Generic.List[string]]$Paths,
        [string]$Path
    )

    try {
        if ((Test-Path -LiteralPath $Path -PathType Leaf) -and -not $Paths.Contains($Path)) {
            $Paths.Add($Path)
        }
    } catch {
    }
}

function Get-UnsupportedBrowserExecutableCandidates {
    $keywords = Get-UnsupportedBrowserKeywords
    $paths = New-Object System.Collections.Generic.List[string]

    $programRoots = @(
        $env:ProgramFiles,
        ${env:ProgramFiles(x86)},
        $env:LocalAppData
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }

    $relativeExecutables = @(
        "BraveSoftware\Brave-Browser\Application\brave.exe",
        "Opera\launcher.exe",
        "Opera GX\launcher.exe",
        "Vivaldi\Application\vivaldi.exe",
        "LibreWolf\librewolf.exe",
        "Waterfox\waterfox.exe",
        "AVAST Software\Browser\Application\AvastBrowser.exe",
        "AVG\Browser\Application\AVGBrowser.exe",
        "CCleaner Browser\Application\CCleanerBrowser.exe",
        "DuckDuckGo\DuckDuckGo.exe",
        "Epic Privacy Browser\epic.exe",
        "Maxthon\Bin\Maxthon.exe",
        "SeaMonkey\seamonkey.exe",
        "Yandex\YandexBrowser\Application\browser.exe",
        "UCBrowser\Application\UCBrowser.exe",
        "Pale Moon\palemoon.exe"
    )

    foreach ($root in $programRoots) {
        foreach ($relative in $relativeExecutables) {
            Add-ExistingUnsupportedBrowserCandidate -Paths $paths -Path (Join-Path $root $relative)
        }
    }

    try {
        foreach ($process in Get-Process -ErrorAction SilentlyContinue) {
            $path = ""
            try {
                $path = [string]$process.Path
            } catch {
            }

            if (-not [string]::IsNullOrWhiteSpace($path) -and (Test-UnsupportedBrowserPath -Path $path -Keywords $keywords) -and -not $paths.Contains($path)) {
                $paths.Add($path)
            }

            if ($paths.Count -ge 80) {
                break
            }
        }
    } catch {
    }

    return @($paths | Sort-Object -Unique)
}

function Disable-UnsupportedBrowserBlocking {
    param([switch]$RequireComplete)
    Remove-PurestateFirewallRulesByPrefix -Prefix $script:UnsupportedBrowserFirewallPrefix -RequireComplete:$RequireComplete
}

function Enable-UnsupportedBrowserBlocking {
    $candidates = @(Get-UnsupportedBrowserExecutableCandidates)

    # Gleiche Begruendung wie in Enable-BypassBlocking: nur bauen, wenn sich
    # der Programmsatz geaendert hat. Ohne installierten Fremdbrowser stand
    # hier bisher alle 30 Sekunden eine Logzeile, obwohl es nichts zu sperren
    # gab.
    $existing = Get-PurestateFirewallRulePrograms -Prefix $script:UnsupportedBrowserFirewallPrefix
    if ($null -ne $existing -and (Test-PurestateFirewallProgramsMatch -Existing $existing -Wanted $candidates)) {
        return
    }

    Disable-UnsupportedBrowserBlocking

    if ($candidates.Count -eq 0) {
        Add-AppLog "Unsupported browser protection found no known executables to block."
        return
    }

    $index = 1
    foreach ($path in $candidates) {
        try {
            $name = $script:UnsupportedBrowserFirewallPrefix + $index
            if (Get-Command New-NetFirewallRule -ErrorAction SilentlyContinue) {
                New-NetFirewallRule -DisplayName $name -Direction Outbound -Program $path -Action Block -Profile Any -Enabled True -ErrorAction Stop | Out-Null
            } else {
                $netsh = Get-SystemToolPath -Name "netsh.exe"
                & $netsh advfirewall firewall add rule name="$name" dir=out action=block program="$path" enable=yes profile=any | Out-Null
            }

            Add-AppLog "Unsupported browser protection blocked network access for $path."
            $index++
        } catch {
            Add-AppLog "Unsupported browser protection failed for $($path): $($_.Exception.Message)"
        }
    }
}

function Flush-DnsCache {
    try {
        $ipconfig = Get-SystemToolPath -Name "ipconfig.exe"
        & $ipconfig /flushdns | Out-Null
    } catch {
        Add-AppLog "DNS cache flush failed: $($_.Exception.Message)"
    }
}

# Massgebliche Uhr fuer Gates im Durchsetzungsspiegel. Entspricht
# Support.TrustedLocalNow() in C#: liefert den vom Durchsetzungspfad
# fortgeschriebenen Anker, nicht die Systemuhr. Faellt auf die Systemuhr
# zurueck, solange der Anker noch nie geschrieben wurde.
function Get-TrustedLocalNow {
    param([pscustomobject]$Config)

    if ($null -ne $Config -and -not [string]::IsNullOrEmpty([string]$Config.ClockAnchorUtc)) {
        $parsed = [datetime]::MinValue
        # NUR RoundtripKind. Kombiniert mit AdjustToUniversal (oder
        # AssumeLocal/AssumeUniversal) wirft .NET ArgumentException - das hat
        # in 0.62.48 den Anker nach dem ersten Schreiben eingefroren. Der
        # gespeicherte Wert ist ISO-8601 mit Z, RoundtripKind liefert also
        # bereits DateTimeKind.Utc.
        $styles = [System.Globalization.DateTimeStyles]::RoundtripKind
        if ([datetime]::TryParse([string]$Config.ClockAnchorUtc, [System.Globalization.CultureInfo]::InvariantCulture, $styles, [ref]$parsed)) {
            return ([datetime]::SpecifyKind($parsed, [System.DateTimeKind]::Utc)).ToLocalTime()
        }
    }

    return (Get-Date)
}

# Millisekunden seit Systemstart, EINSCHLIESSLICH Schlaf und Ruhezustand, und
# unabhaengig von der Systemuhr. Stopwatch und QueryUnbiasedInterruptTime
# zaehlen Schlafzeit nicht mit - jedes Aufklappen eines Laptops saehe damit wie
# ein Uhrsprung aus und wuerde die Wartefristen einfrieren.
# [Environment]::TickCount ist Int32 und laeuft nach ~24,9 Tagen ueber.
# ponytail: Add-Type kompiliert beim ersten Aufruf je Prozess (~150 ms), und
# der Durchsetzungshelfer ist pro Tick ein neuer Prozess. Falls das je stoert,
# den Typ in eine vorkompilierte Hilfsassembly ziehen.
function Get-MonotonicTickMs {
    if (-not ([System.Management.Automation.PSTypeName]'Purestate.NativeClock').Type) {
        Add-Type -Namespace Purestate -Name NativeClock -MemberDefinition @'
[DllImport("kernel32.dll")]
public static extern ulong GetTickCount64();
'@
    }

    return [int64][Purestate.NativeClock]::GetTickCount64()
}

# Schreibt die vertrauenswuerdige Uhr fort. Der C#-Guard kann das nicht: seine
# Dateien werden von der Pester-Suite standalone ohne NativeSupport*.cs
# kompiliert und haben keinen signierenden Schreibpfad fuer config.json.
# Spiegelt Support.ComputeNextClockAnchor, das in C# per Unit-Test gepinnt ist.
function Update-ClockAnchor {
    try {
        $config = Get-Config
        if (($null -ne $config.PSObject.Properties["IntegrityCompromised"]) -and [bool]$config.IntegrityCompromised) {
            return
        }

        $ticksNow = Get-MonotonicTickMs
        $wallNow = [datetime]::UtcNow

        $anchor = $wallNow
        $parsed = [datetime]::MinValue
        # NUR RoundtripKind. Kombiniert mit AdjustToUniversal (oder
        # AssumeLocal/AssumeUniversal) wirft .NET ArgumentException - das hat
        # in 0.62.48 den Anker nach dem ersten Schreiben eingefroren. Der
        # gespeicherte Wert ist ISO-8601 mit Z, RoundtripKind liefert also
        # bereits DateTimeKind.Utc.
        $styles = [System.Globalization.DateTimeStyles]::RoundtripKind
        if (-not [string]::IsNullOrEmpty([string]$config.ClockAnchorUtc) -and
            [datetime]::TryParse([string]$config.ClockAnchorUtc, [System.Globalization.CultureInfo]::InvariantCulture, $styles, [ref]$parsed)) {
            $anchor = [datetime]::SpecifyKind($parsed, [System.DateTimeKind]::Utc)
        }

        $lastTicks = [int64]$config.ClockTickAnchorMs
        $jumpDetected = $false

        if ($lastTicks -le 0 -or $ticksNow -lt $lastTicks) {
            # Keine Historie, oder GetTickCount64 ist nach einem Neustart auf 0
            # zurueckgefallen: uebernehmen ohne Sprungpruefung. Das ist die
            # dokumentierte Restluecke - eine bei gestopptem Dienst gestellte
            # Uhr ist von einem regulaeren Herunterfahren nicht unterscheidbar.
            $next = if ($wallNow -gt $anchor) { $wallNow } else { $anchor }
        } else {
            $monotonicSeconds = ($ticksNow - $lastTicks) / 1000.0
            $wallSeconds = ($wallNow - $anchor).TotalSeconds
            if ($wallSeconds -gt ($monotonicSeconds + 60.0)) {
                $jumpDetected = $true
                $next = $anchor.AddSeconds($monotonicSeconds)
            } elseif ($wallNow -gt $anchor) {
                $next = $wallNow
            } else {
                $next = $anchor
            }
        }

        if ($jumpDetected) {
            Add-SecurityLog "Uhrmanipulation erkannt: Vorwaertssprung der Systemuhr wird nicht als Wartezeit gutgeschrieben."
        }

        $nextText = $next.ToString("o")
        if (-not [string]::Equals([string]$config.ClockAnchorUtc, $nextText, [StringComparison]::Ordinal) -or
            [int64]$config.ClockTickAnchorMs -ne $ticksNow) {
            $config.ClockAnchorUtc = $nextText
            $config.ClockTickAnchorMs = $ticksNow
            Save-Config -Config $config
        }
    } catch {
        # Die Uhrfortschreibung darf die Durchsetzung nie stoppen.
    }
}

# Spiegel von Invoke-CleanupStep fuer den AUFBAU (Befund ENF-001). Der Abbau
# kapselt seit einem Live-Befund jeden Schritt einzeln; der Aufbau tat es nicht.
# Warf der erste Schritt, blieben alle folgenden Schutzschichten ungesetzt - und
# weil jedes Speichern erst abraeumt und dann neu aufbaut (INS-001), blieb der
# Rechner ganz ohne Schutz zurueck, direkt nachdem der Nutzer "gespeichert"
# gelesen hatte.
#
# Wichtig: das macht einen Fehlschlag leiser, deshalb steht er jetzt in BEIDEN
# Protokollen, und die Schlusszeile sagt, dass nicht alles steht. Was danach
# wirklich aktiv ist, leitet die Statusanzeige ohnehin aus dem echten
# Systemzustand ab, nicht aus dieser Zeile.
function Invoke-EnforcementStep {
    param(
        [string]$Name,
        [scriptblock]$Step
    )

    try {
        & $Step
        return $true
    } catch {
        Add-AppLog "Enforcement step '$Name' failed: $($_.Exception.Message)"
        Add-SecurityLog "Durchsetzungsschritt '$Name' fehlgeschlagen: $($_.Exception.Message)"
        return $false
    }
}

# Gibt den Rechner frei, wenn die Fassung abgelaufen ist: hosts-Eintrag, DNS,
# Proxy, Firewallregeln, Browser-Richtlinien. Die Markierung sorgt dafuer, dass
# das nicht in jedem Takt erneut passiert.
#
# Der Guard liest dieselbe Markierung (GuardService.IsBetaExpired) und haelt
# erst still, wenn sie liegt: er kann den Integritaets-HMAC nicht pruefen, und
# die Markierung ist der Beleg, dass die GEPRUEFTE Konfiguration abgelaufen
# ist. Sie darf deshalb nur hier entstehen, und erst nach dem Rueckbau.
function Invoke-EntitlementRelease {
    param([string]$MarkerPath = $script:EntitlementReleaseMarkerPath)

    if (Test-Path -LiteralPath $MarkerPath) {
        return $false
    }

    $allSucceeded = Disable-Protection -RestoreDns -PassThru
    # Disable-Protection nimmt die Zwangsinstallation des Companions nicht mit.
    # Ensure-ManagedCompanionPolicy entfernt sie nach dem Ablauf auch, aber
    # erst im naechsten Watchdog-Lauf; so ist die Freigabe sofort vollstaendig.
    $allSucceeded = (Invoke-CleanupStep "Companion-Zwangsinstallation" { Remove-ManagedCompanionPolicy -RequireComplete }) -and $allSucceeded
    if (-not $allSucceeded) {
        Add-SecurityLog "Beta-Rueckbau unvollstaendig: der naechste Lauf versucht es erneut."
        return $false
    }
    Set-Content -LiteralPath $MarkerPath -Value ([datetime]::UtcNow.ToString("o")) -Encoding utf8 -ErrorAction Stop
    Add-SecurityLog "Beta-Zeitraum abgelaufen: Schutz zurueckgenommen."
    return $true
}

# Die Markierung gehoert an den Ablauftermin, nicht an den Rechner. Nach einer
# Verlaengerung (derselbe Code, neues Datum) baut Enable-Protection alles wieder
# auf; bliebe die Markierung liegen, gaebe der naechste Ablauf NICHTS mehr frei
# und genau die tote Sperre stuende da, die Abschnitt 6 der Spezifikation
# ausschliesst. Deshalb: "genau einmal je Ablauftermin".
function Remove-EntitlementReleaseMarker {
    param([string]$MarkerPath = $script:EntitlementReleaseMarkerPath)

    if (Test-Path -LiteralPath $MarkerPath) {
        Remove-Item -LiteralPath $MarkerPath -Force -ErrorAction SilentlyContinue
    }
}

# Was die Beta-Freigabe uebersprungen hat, weil es gerade fehlte - ein Adapter
# aus der DNS-Sicherung, die Proxy-Sicherung eines abgemeldeten Kontos -,
# bekommt seine Einstellungen zurueck, sobald es wieder da ist. Nach der
# Markierung haelt der Guard still; ohne diesen Weg bliebe ein wieder
# eingesteckter Adapter bis zur Deinstallation auf dem Familien-DNS. Vorher
# wird nur geprueft, ob etwas da ist: kein Takt setzt Adapter neu oder schreibt
# eine Fehlerzeile, solange nichts zurueckzugeben ist.
function Restore-EntitlementReleaseLeftovers {
    if ((Test-Path -LiteralPath $script:DnsBackupPath) -and (Test-DnsBackupHasPresentAdapter)) {
        try {
            Restore-DnsSettings
        } catch {
            Add-AppLog "DNS restore after the beta release failed: $($_.Exception.Message)"
        }
    }

    foreach ($datei in Get-ProxyBackupFiles) {
        if (Test-ProxyBackupHiveLoaded -BackupFile $datei.FullName) {
            try {
                Restore-ProxyBackupFile -BackupFile $datei.FullName
            } catch {
                Add-AppLog "Proxy restore after the beta release failed: $($_.Exception.Message)"
            }
        }
    }
}

function Enable-Protection {
    param([switch]$Reconcile)
    Update-ClockAnchor
    $config = Get-Config
    Ensure-AppRegistration
    Ensure-WatchdogTask

    # Abgelaufene Fassung: den Rechner einmal freigeben und danach nichts mehr
    # durchsetzen. Ein stehengebliebener hosts-Block ohne Verwaltung waere
    # schlimmer als gar kein Schutz. Das laeuft hier und nicht im Guard, weil
    # PurestateGuard.exe ohne NativeSupport*.cs gebaut wird und Support nicht
    # referenzieren kann.
    if (Test-EntitlementExpired -Config $config) {
        if (Test-Path -LiteralPath $script:EntitlementReleaseMarkerPath) {
            Restore-EntitlementReleaseLeftovers
        } else {
            Invoke-EntitlementRelease | Out-Null
        }
        return
    }

    # Nicht abgelaufen: eine Markierung aus einem frueheren Ablauf muss weg,
    # sonst gaebe der naechste Ablauf nach dieser Verlaengerung nichts frei.
    Remove-EntitlementReleaseMarker

    if (-not (Test-ProtectionShouldRun -Config $config)) {
        return
    }

    $allSucceeded = $true

    # B-2: Der Abgleich beim Speichern baut ausgeschaltete Schichten ZUERST ab,
    # nur wenn noch etwas da ist. Ein Zeitlimit trifft dann nur noch den
    # Aufbau, den der Waechter in seinem naechsten Takt ohnehin nachholt -
    # abbauen tut der Waechter nie. Ohne -Reconcile (Waechter) laeuft hier
    # nichts, auch keine der Pruefungen.
    if ($Reconcile) {
        if (-not $config.HostsEnabled) {
            $allSucceeded = (Invoke-EnforcementStep "Hosts-Datei (aus)" {
                if (Test-HostsBlockActive -Content (Get-HostsRaw)) { Disable-HostsProtection }
            }) -and $allSucceeded
        }
        if (-not $config.TamperProtectionEnabled) {
            $allSucceeded = (Invoke-EnforcementStep "Windows-Proxy (Rueckgabe)" {
                if (@(Get-ProxyBackupFiles).Count -gt 0) { Restore-WindowsProxy }
            }) -and $allSucceeded
        }
        if (-not $config.BypassBlockingEnabled) {
            $allSucceeded = (Invoke-EnforcementStep "Umgehungsschutz (aus)" {
                if (Test-PurestateFirewallRulesPresent -Prefix $script:BypassFirewallPrefix) { Disable-BypassBlocking }
            }) -and $allSucceeded
        }
        if (-not $config.UnsupportedBrowserBlockingEnabled) {
            $allSucceeded = (Invoke-EnforcementStep "Nicht unterstuetzte Browser (aus)" {
                if (Test-PurestateFirewallRulesPresent -Prefix $script:UnsupportedBrowserFirewallPrefix) { Disable-UnsupportedBrowserBlocking }
            }) -and $allSucceeded
        }
    }

    if ($config.HostsEnabled) {
        $allSucceeded = (Invoke-EnforcementStep "Hosts-Datei" { Enable-HostsProtection }) -and $allSucceeded
    }

    if ($config.FamilyDnsEnabled) {
        $allSucceeded = (Invoke-EnforcementStep "Familien-DNS" { Enable-DnsProtection -Profile $config.DnsProfile }) -and $allSucceeded
    } elseif (Test-Path -LiteralPath $script:DnsBackupPath) {
        # Schalter aus heisst: der erzwungene Familien-DNS muss weg. Die
        # Rueckgabe lief bisher nur bei der Deinstallation, also blieb der
        # Adapter nach dem Abschalten dauerhaft statisch auf dem Familien-DNS
        # stehen (Befund L-11). Nur mit vorhandener Sicherung - ohne sie wuerde
        # jeder Durchlauf einen selbst gesetzten DNS des Nutzers auf DHCP
        # zuruecksetzen.
        $allSucceeded = (Invoke-EnforcementStep "DNS-Ruecknahme" { Restore-DnsSettings }) -and $allSucceeded
    }

    # Dieser Schritt liefert als einziger einen Wert weiter, deshalb hier
    # try/catch statt Invoke-EnforcementStep - ein Umweg ueber eine
    # Skriptvariable waere teurer als die vier Zeilen.
    $changedBrowsers = @()
    try {
        $chromeActive = Test-PurestateExtensionForBrowser -Browser Chrome
        $edgeActive = Test-PurestateExtensionForBrowser -Browser Edge
        $changedBrowsers = @(Enable-BrowserPolicies -ChromeActive $chromeActive -EdgeActive $edgeActive)
        Update-BrowserCompanionState -ChromeActive $chromeActive -EdgeActive $edgeActive -RestartChangedBrowsers $true | Out-Null
    } catch {
        Add-AppLog "Enforcement step 'Browserrichtlinien' failed: $($_.Exception.Message)"
        Add-SecurityLog "Durchsetzungsschritt 'Browserrichtlinien' fehlgeschlagen: $($_.Exception.Message)"
        $allSucceeded = $false
    }

    # Eine geaenderte Sperrliste wirkt erst, wenn Chromium sie neu liest. Damit
    # eine Einstellung sofort nach dem Speichern greift, laedt der betroffene
    # Browser gleich neu - mit Sitzungswiederherstellung, siehe
    # Stop-ChromiumBrowserForPolicyRefresh. Lief der Browser bereits durch die
    # Companion-Zustandsaenderung oben neu, findet der Aufruf keine Prozesse
    # mehr und tut nichts.
    $refreshBrowsers = @(Get-PolicyRefreshBrowsers -ChangedBrowsers $changedBrowsers)
    foreach ($browser in $refreshBrowsers) {
        try {
            Stop-ChromiumBrowserForPolicyRefresh -Browser $browser | Out-Null
        } catch {
            Add-AppLog "Browser refresh for $browser failed: $($_.Exception.Message)"
        }
    }

    if ($config.TamperProtectionEnabled) {
        $allSucceeded = (Invoke-EnforcementStep "Windows-Proxy" { Disable-WindowsProxy }) -and $allSucceeded
    }

    if ($config.BypassBlockingEnabled) {
        $allSucceeded = (Invoke-EnforcementStep "Umgehungsschutz" { Enable-BypassBlocking }) -and $allSucceeded
    }

    if ($config.UnsupportedBrowserBlockingEnabled) {
        $allSucceeded = (Invoke-EnforcementStep "Nicht unterstuetzte Browser" { Enable-UnsupportedBrowserBlocking }) -and $allSucceeded
    }

    $allSucceeded = (Invoke-EnforcementStep "DNS-Cache" { Flush-DnsCache }) -and $allSucceeded

    if ($allSucceeded) {
        Add-AppLog "Protection enforced."
    } else {
        Add-AppLog "Protection enforced with errors - see security.log."
    }
}

# Fuehrt einen Aufraeumschritt aus und laesst einen Fehlschlag die folgenden
# Schritte NICHT verhindern. Beim Entfernen zaehlt, dass moeglichst viel
# zurueckgenommen wird - ein Abbruch nach dem ersten Fehler hinterlaesst
# Systemaenderungen, die der Nutzer ohne Purestate kaum noch findet.
function Invoke-CleanupStep {
    param(
        [string]$Name,
        [scriptblock]$Step
    )

    try {
        $ErrorActionPreference = "Stop"
        & $Step | Out-Null
        return $true
    } catch {
        Add-AppLog "Cleanup step '$Name' failed: $($_.Exception.Message)"
        Add-SecurityLog "Aufraeumschritt '$Name' fehlgeschlagen: $($_.Exception.Message)"
        return $false
    }
}

function Disable-Protection {
    param([switch]$RestoreDns, [switch]$PassThru)

    Assert-DataDirectoryIsNotReparsePoint

    # Jeder Schritt einzeln gekapselt. Die fruehere Fassung rief die Schritte
    # direkt hintereinander auf: ein Fehler in den Browserrichtlinien, im
    # Umgehungsschutz oder in der Browsersperre brach die Funktion ab, BEVOR
    # die DNS-Rueckgabe an die Reihe kam. Nach der Deinstallation blieb das
    # System dann dauerhaft auf dem erzwungenen Family-DNS - live gefunden.
    $allSucceeded = $true
    $allSucceeded = (Invoke-CleanupStep "Hosts-Datei" { Disable-HostsProtection }) -and $allSucceeded
    $allSucceeded = (Invoke-CleanupStep "Browserrichtlinien" { Disable-BrowserPolicies -RequireComplete:$PassThru }) -and $allSucceeded
    $allSucceeded = (Invoke-CleanupStep "Umgehungsschutz" { Disable-BypassBlocking -RequireComplete:$PassThru }) -and $allSucceeded
    $allSucceeded = (Invoke-CleanupStep "Browsersperre" { Disable-UnsupportedBrowserBlocking -RequireComplete:$PassThru }) -and $allSucceeded

    if ($RestoreDns) {
        $allSucceeded = (Invoke-CleanupStep "DNS-Rueckgabe" { Restore-DnsSettings -RequireComplete:$PassThru }) -and $allSucceeded
        $allSucceeded = (Invoke-CleanupStep "Proxy-Rueckgabe" { Restore-WindowsProxy -RequireComplete:$PassThru }) -and $allSucceeded
    }

    $allSucceeded = (Invoke-CleanupStep "DNS-Zwischenspeicher" { Flush-DnsCache }) -and $allSucceeded

    if ($allSucceeded) {
        Add-AppLog "Protection removed."
    } else {
        Add-AppLog "Protection removed with errors - see security.log."
    }
    if ($PassThru) { return $allSucceeded }
}

function Get-ProtectionStatus {
    $hostsOn = $false
    $dnsOn = $false
    $serviceOn = $false

    try {
        $hostsOn = Test-HostsBlockActive -Content (Get-HostsRaw)
    } catch {
    }

    try {
        $config = Get-Config
        $familyServers = @(Get-FamilyDnsServers -Profile $config.DnsProfile)
        $dnsOn = Test-FamilyDnsActiveForAdapters -FamilyServers $familyServers -Adapters (Get-DnsAdapterStates)
    } catch {
    }

    try {
        $svc = Get-Service -Name $script:ServiceName -ErrorAction Stop
        $serviceOn = ($svc.Status -eq "Running")
    } catch {
    }

    return [pscustomobject]@{
        HostsActive = $hostsOn
        DnsActive = $dnsOn
        ServiceRunning = $serviceOn
    }
}
