using System;
using System.Collections.Generic;
using System.IO;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace Purestate.Native
{
    internal static partial class Support
    {
        private const string ConfigMutexName = @"Global\PurestateConfig";

        public static AppConfig LoadConfig()
        {
            if (!File.Exists(ConfigPath))
            {
                return new AppConfig();
            }

            return LoadConfigFromJson(File.ReadAllText(ConfigPath));
        }

        // Der Rumpf getrennt vom Dateizugriff, damit Tests eine Konfiguration
        // als Text hineingeben koennen, statt die echte Installation unter
        // ProgramData anzufassen.
        internal static AppConfig LoadConfigFromJson(string json)
        {
            List<TopLevelJsonProperty> topLevelProperties;
            if (!TryReadTopLevelJsonProperties(json, out topLevelProperties))
            {
                return MarkConfigCompromised(new AppConfig(), "malformed config JSON");
            }
            if (HasDuplicateTopLevelJsonProperties(topLevelProperties))
            {
                return MarkConfigCompromised(new AppConfig(), "duplicate top-level config property");
            }

            AppConfig config = new AppConfig();
            config.ProtectionEnabled = ReadBool(json, "ProtectionEnabled", true);
            config.HostsEnabled = ReadBool(json, "HostsEnabled", true);
            config.FamilyDnsEnabled = ReadBool(json, "FamilyDnsEnabled", true);
            config.DnsProfile = NormalizeDnsProfile(ReadString(json, "DnsProfile"));
            config.BrowserPoliciesEnabled = true;
            config.BypassBlockingEnabled = ReadBool(json, "BypassBlockingEnabled", true);
            config.UnsupportedBrowserBlockingEnabled = ReadBool(json, "UnsupportedBrowserBlockingEnabled", true);
            config.TamperProtectionEnabled = ReadBool(json, "TamperProtectionEnabled", true);
            config.YouTubeRestrictEnabled = ReadBool(json, "YouTubeRestrictEnabled", true);
            config.AdultHostsFollowArea = ReadBool(json, "AdultHostsFollowArea", false);
            config.SiteRedditEnabled = ReadBool(json, "SiteRedditEnabled", true);
            config.SiteXEnabled = ReadBool(json, "SiteXEnabled", true);
            config.SiteBlueskyEnabled = ReadBool(json, "SiteBlueskyEnabled", true);
            config.SiteTumblrEnabled = ReadBool(json, "SiteTumblrEnabled", true);
            config.SiteDeviantArtEnabled = ReadBool(json, "SiteDeviantArtEnabled", true);
            config.SitePixivEnabled = ReadBool(json, "SitePixivEnabled", true);
            config.SiteNewgroundsEnabled = ReadBool(json, "SiteNewgroundsEnabled", true);
            config.SiteImgurEnabled = ReadBool(json, "SiteImgurEnabled", true);
            config.SiteInstagramEnabled = ReadBool(json, "SiteInstagramEnabled", true);
            config.SiteTikTokEnabled = ReadBool(json, "SiteTikTokEnabled", true);
            config.SitePinterestEnabled = ReadBool(json, "SitePinterestEnabled", true);
            config.AdultContentProtectionEnabled = ReadBool(json, "AdultContentProtectionEnabled", true);
            config.AdultContentProtectionMode = NormalizeProtectionAreaMode(ReadString(json, "AdultContentProtectionMode"), "strict");
            config.GamblingProtectionEnabled = ReadBool(json, "GamblingProtectionEnabled", ReadBool(json, "GamblingSupportEnabled", false));
            config.GamblingProtectionMode = NormalizeProtectionAreaMode(ReadString(json, "GamblingProtectionMode"), config.GamblingProtectionEnabled ? "strict" : "off");
            config.ShoppingProtectionEnabled = ReadBool(json, "ShoppingProtectionEnabled", false);
            config.ShoppingProtectionMode = NormalizeProtectionAreaMode(ReadString(json, "ShoppingProtectionMode"), "planned");
            config.ShoppingDelayDefaultMinutes = NormalizeGamblingDelayMinutes(ReadInt(json, "ShoppingDelayDefaultMinutes", 10));
            config.ShoppingCheckoutDelayEnabled = ReadBool(json, "ShoppingCheckoutDelayEnabled", true);
            config.ShoppingStimulusDampingEnabled = ReadBool(json, "ShoppingStimulusDampingEnabled", true);
            config.ShoppingDealSearchBlockEnabled = ReadBool(json, "ShoppingDealSearchBlockEnabled", true);
            config.ShoppingCurfewEnabled = ReadBool(json, "ShoppingCurfewEnabled", true);
            config.ShoppingCurfewStart = NormalizeTimeText(ReadString(json, "ShoppingCurfewStart"), "22:00");
            config.ShoppingCurfewEnd = NormalizeTimeText(ReadString(json, "ShoppingCurfewEnd"), "06:00");
            config.ShoppingDailyLimitEnabled = ReadBool(json, "ShoppingDailyLimitEnabled", true);
            config.ShoppingDailyLimitMinutes = NormalizeDailyLimitMinutes(ReadInt(json, "ShoppingDailyLimitMinutes", 30), 30);
            config.ShoppingMonthlyOrderLimitEnabled = ReadBool(json, "ShoppingMonthlyOrderLimitEnabled", true);
            config.ShoppingMonthlyOrderLimit = NormalizeMonthlyOrderLimit(ReadInt(json, "ShoppingMonthlyOrderLimit", 10));
            config.ShoppingMonthlyBudgetEnabled = ReadBool(json, "ShoppingMonthlyBudgetEnabled", false);
            config.ShoppingMonthlyBudgetEuro = NormalizeMonthlyBudgetEuro(ReadInt(json, "ShoppingMonthlyBudgetEuro", 200));
            config.GamblingDailyLimitEnabled = ReadBool(json, "GamblingDailyLimitEnabled", true);
            config.GamblingDailyLimitMinutes = NormalizeDailyLimitMinutes(ReadInt(json, "GamblingDailyLimitMinutes", 15), 15);
            config.SocialMediaDailyBudgetEnabled = ReadBool(json, "SocialMediaDailyBudgetEnabled", false);
            config.SocialMediaDailyBudgetMinutes = NormalizeSocialMediaBudgetMinutes(ReadInt(json, "SocialMediaDailyBudgetMinutes", 60));
            config.SocialMediaPlatformLimits = NormalizeSocialMediaPlatformLimits(ReadString(json, "SocialMediaPlatformLimits"), config.SocialMediaDailyBudgetEnabled, config.SocialMediaDailyBudgetMinutes);
            config.SocialMediaBlockedPlatforms = NormalizeSocialMediaBlockedPlatforms(ReadString(json, "SocialMediaBlockedPlatforms"));
            config.SocialMediaFeedBlockedPlatforms = NormalizeSocialMediaFeedBlockedPlatforms(ReadString(json, "SocialMediaFeedBlockedPlatforms"), config.SocialMediaBlockedPlatforms);
            config.SocialMediaCurfewEnabled = ReadBool(json, "SocialMediaCurfewEnabled", false);
            config.SocialMediaCurfewStart = NormalizeTimeText(ReadString(json, "SocialMediaCurfewStart"), "22:00");
            config.SocialMediaCurfewEnd = NormalizeTimeText(ReadString(json, "SocialMediaCurfewEnd"), "06:00");
            config.SocialMediaReflectionEnabled = ReadBool(json, "SocialMediaReflectionEnabled", true);
            config.SocialMediaFeedDampingEnabled = ReadBool(json, "SocialMediaFeedDampingEnabled", true);
            config.SocialMediaFeedDampingScrolls = NormalizeSocialMediaFeedDampingScrolls(ReadInt(json, "SocialMediaFeedDampingScrolls", 50));
            config.VideoGamesProtectionEnabled = ReadBool(json, "VideoGamesProtectionEnabled", false);
            config.VideoGamesProtectionMode = NormalizeProtectionAreaMode(ReadString(json, "VideoGamesProtectionMode"), "planned");
            config.VideoGamesDailyLimitEnabled = ReadBool(json, "VideoGamesDailyLimitEnabled", false);
            config.VideoGamesDailyLimitMinutes = NormalizeVideoGamesDailyLimitMinutes(ReadInt(json, "VideoGamesDailyLimitMinutes", 60));
            config.VideoGamesCurfewEnabled = ReadBool(json, "VideoGamesCurfewEnabled", false);
            config.VideoGamesCurfewStart = NormalizeTimeText(ReadString(json, "VideoGamesCurfewStart"), "22:00");
            config.VideoGamesCurfewEnd = NormalizeTimeText(ReadString(json, "VideoGamesCurfewEnd"), "06:00");
            config.VideoGamesAutoDetectEnabled = ReadBool(json, "VideoGamesAutoDetectEnabled", false);
            config.VideoGamesHeuristicEnabled = ReadBool(json, "VideoGamesHeuristicEnabled", false);
            config.SocialMediaProtectionEnabled = ReadBool(json, "SocialMediaProtectionEnabled", false);
            config.SocialMediaProtectionMode = NormalizeProtectionAreaMode(ReadString(json, "SocialMediaProtectionMode"), "planned");
            config.ProtectionAreaRulePackVersion = ReadString(json, "ProtectionAreaRulePackVersion");
            if (string.IsNullOrWhiteSpace(config.ProtectionAreaRulePackVersion))
            {
                config.ProtectionAreaRulePackVersion = "1";
            }
            config.GamblingSupportEnabled = ReadBool(json, "GamblingSupportEnabled", false);
            config.GamblingSupportMode = NormalizeImpulseAreaMode(ReadString(json, "GamblingSupportMode"), config.GamblingSupportEnabled ? "gentle" : "off");
            config.LockdownModeEnabled = ReadBool(json, "LockdownModeEnabled", true);
            config.PauseCooldownEnabled = ReadBool(json, "PauseCooldownEnabled", true);
            config.ScheduleEnabled = ReadBool(json, "ScheduleEnabled", false);
            config.StrictModeEnabled = ReadBool(json, "StrictModeEnabled", false);
            config.ScheduleStart = NormalizeTimeText(ReadString(json, "ScheduleStart"), "22:00");
            config.ScheduleEnd = NormalizeTimeText(ReadString(json, "ScheduleEnd"), "06:00");
            config.PauseUntilUtc = ReadString(json, "PauseUntilUtc");
            config.PendingPauseUntilUtc = ReadString(json, "PendingPauseUntilUtc");
            config.PendingUninstallUntilUtc = ReadString(json, "PendingUninstallUntilUtc");
            config.UninstallApprovalExpiresUtc = ReadString(json, "UninstallApprovalExpiresUtc");
            config.PasswordHint = ReadString(json, "PasswordHint");
            config.PasswordFailedAttempts = Math.Max(0, ReadInt(json, "PasswordFailedAttempts", 0));
            config.PasswordLockoutUntilUtc = ReadString(json, "PasswordLockoutUntilUtc");
            config.InstalledVersion = ReadString(json, "InstalledVersion");
            config.WeakeningRequestedUtc = ReadString(json, "WeakeningRequestedUtc");
            config.AuthorityMode = NormalizeAuthorityMode(ReadString(json, "AuthorityMode"));
            config.PolicyVersion = Math.Max(0, ReadLong(json, "PolicyVersion", 0));
            config.WeakeningGrant = ReadString(json, "WeakeningGrant");
            config.GrantSignature = ReadString(json, "GrantSignature");
            config.EntitledUntilUtc = ReadString(json, "EntitledUntilUtc");
            config.EntitlementSignature = ReadString(json, "EntitlementSignature");
            config.EntitlementMaxDevices = (int)ReadLong(json, "EntitlementMaxDevices", 0);
            config.CompanionGrace = ReadString(json, "CompanionGrace");
            config.ClockAnchorUtc = ReadString(json, "ClockAnchorUtc");
            config.ClockTickAnchorMs = ReadLong(json, "ClockTickAnchorMs", 0);
            config.IntegritySchemaVersion = ReadIntegritySchemaVersion(json, topLevelProperties);
            config.Integrity = ReadString(json, "Integrity");

            string algorithm = ReadString(json, "Algorithm");
            string salt = ReadString(json, "Salt");
            string hash = ReadString(json, "Hash");
            int iterations = ReadInt(json, "Iterations", 180000);

            if (!string.IsNullOrEmpty(algorithm) && !string.IsNullOrEmpty(salt) && !string.IsNullOrEmpty(hash))
            {
                config.Password = new PasswordRecord
                {
                    Algorithm = algorithm,
                    Iterations = iterations,
                    Salt = salt,
                    Hash = hash
                };
            }

            return VerifyConfigIntegrityOnLoad(config, topLevelProperties);
        }

        // Verifies the stored HMAC against the freshly computed one. Only a
        // config with an EMPTY Integrity field is trusted unverified (legacy /
        // pre-signing install; it gets stamped on the next save). If a config
        // carries a signature it must verify: a mismatch OR a missing/invalid
        // key means the file was changed outside Purestate (or the key was
        // deleted to disable the check), and the WHOLE config is then untrusted
        // - not just ProtectionEnabled.
        //
        // SHP-004, damit sich niemand auf ein zu grosses Wort verlaesst:
        // "WHOLE config" heisst jedes Feld, das eine Entscheidung traegt - und
        // das sind alle bis auf sechs. Die Ausnahmen und ihre Gruende stehen
        // ueber BuildConfigCanonical in NativeSupportLogic.cs; PasswordHint ist
        // eine davon. Ihn zu aendern bricht die Signatur nicht. Ein Angriff
        // ergibt sich daraus nicht - wer config.json schreiben kann, hat
        // Adminrechte, und der Hinweis verraet das Passwort nicht -, aber die
        // Zusage muss stimmen, sonst irrt der Naechste, der sich auf sie
        // beruft. ConfigCanonicalFieldCoverageTests haelt die Ausnahmeliste
        // gegen die wirklichen Felder.
        private static AppConfig VerifyConfigIntegrityOnLoad(AppConfig config, IList<TopLevelJsonProperty> topLevelProperties)
        {
            if (string.IsNullOrEmpty(config.Integrity))
            {
                // CFG-001: Der Zweig existiert fuer den Erstlauf, bevor ein
                // Passwort vergeben wurde - dort gibt es noch nichts zu
                // signieren. Er unterschied aber nicht zwischen "noch nie
                // gespeichert" und "Signatur entfernt": eine geloeschte Zeile
                // hob die ganze Pruefung auf, ohne den Schluessel zu brauchen.
                // SaveConfigUnlocked verweigert das Speichern ohne Passwort und
                // schreibt immer eine Signatur - ein Passwort ohne Signatur kann
                // also nicht von Purestate stammen.
                //
                // Die PowerShell-Seite traegt dieselbe Bedingung
                // (Assert-ConfigIntegrity in scripts\Common.ps1). Einseitig
                // waere schlimmer als gar nicht: die App wuerde ablehnen,
                // waehrend die Durchsetzung weiter durchsetzt (PS-002).
                if (config.Password != null)
                {
                    return MarkConfigCompromised(config, "signed config lost its integrity field");
                }

                return config;
            }

            byte[] key = TryLoadIntegrityKey();
            if (key == null)
            {
                // Die Sperren sind in beiden Faellen dieselben - ohne Schluessel
                // ist eine signierte Config nicht mehr pruefbar, egal warum.
                // Aber die Ursachen sind verschieden, und das Protokoll ist das
                // Einzige, was das spaeter noch sagen kann: eine Datei aus
                // lauter Nullbytes ist Speicherschaden nach einem unsauberen
                // Herunterfahren (gemessen 2026-08-04, siehe NativeSupport.cs),
                // kein Angriff. Wer im Support nach einem Angreifer sucht, den
                // es nie gab, sucht am falschen Ende (INS-002).
                return MarkConfigCompromised(config, IntegrityKeyFileLooksDestroyed()
                    ? "integrity key file is empty or all-NUL (storage damage, e.g. unclean shutdown)"
                    : "integrity key missing or invalid for a signed config");
            }

            if (config.IntegritySchemaVersion == CurrentIntegritySchemaVersion)
            {
                return VerifyDeclaredSchema(config, key, CurrentIntegritySchemaVersion);
            }

            // Schema 14 existed in two independent release lines. Authenticate
            // precisely that line's canonical form; fields from the other line
            // must be absent, even when their value would be a harmless default.
            if (config.IntegritySchemaVersion == 14)
            {
                bool adultVariant = EntitlementSignaturePropertyIsAbsent(topLevelProperties)
                    && EntitlementMaxDevicesPropertyIsAbsent(topLevelProperties)
                    && string.Equals(config.Integrity, ComputeConfigIntegrityForSchema(config, key, 14), StringComparison.Ordinal);
                bool betaVariant = AdultHostsFollowAreaPropertyIsAbsent(topLevelProperties)
                    && string.Equals(config.Integrity, ComputeConfigIntegrityForSchema(config, key, 14, true), StringComparison.Ordinal);
                if (adultVariant || betaVariant)
                {
                    return config;
                }
                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // No schema <= 13 signed any of these fields.
            if (!AdultHostsFollowAreaPropertyIsAbsent(topLevelProperties)
                || !EntitlementSignaturePropertyIsAbsent(topLevelProperties)
                || !EntitlementMaxDevicesPropertyIsAbsent(topLevelProperties))
            {
                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // A valid schema-13 signature (0.62.70 bis 0.62.77) is accepted for
            // migration. This branch must run BEFORE the YouTubeRestrict
            // absence check below: schema-13 configs carry that key signed.
            if (config.IntegritySchemaVersion == 13)
            {
                if (MatchesSchema13(config, key))
                {
                    return config;
                }

                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // Der YouTubeRestrictEnabled-Schluessel ist erst ab Schema 13
            // signiert. Auf jedem aelteren Akzeptanzpfad bedeutet seine
            // Anwesenheit, dass er unsigniert injiziert wurde - ein
            // abgeschalteter YouTube-Filter darf so nicht durchrutschen.
            if (!YouTubeRestrictPropertyIsAbsent(topLevelProperties))
            {
                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // A valid schema-12 signature (0.62.62) is accepted for migration.
            // This branch must run BEFORE the CompanionGrace absence check
            // below: schema-12 configs carry that key signed.
            if (config.IntegritySchemaVersion == 12)
            {
                if (MatchesSchema12(config, key))
                {
                    return config;
                }

                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // Der CompanionGrace-Schluessel ist erst ab Schema 12 signiert. Auf
            // jedem aelteren Akzeptanzpfad bedeutet seine Anwesenheit, dass er
            // unsigniert injiziert wurde - eine selbst verlaengerte
            // Uebergangsfrist wuerde sonst einen beliebig alten Companion
            // gueltig halten.
            if (!CompanionGracePropertyIsAbsent(topLevelProperties))
            {
                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // A valid schema-11 signature (0.62.49) is accepted for migration.
            // This branch must run BEFORE the authority absence check below:
            // schema-11 configs carry those keys signed.
            if (config.IntegritySchemaVersion == 11)
            {
                if (MatchesSchema11(config, key))
                {
                    return config;
                }

                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // Die Autoritaets-Schluessel sind erst ab Schema 11 signiert. Auf
            // jedem aelteren Akzeptanzpfad bedeutet ihre Anwesenheit, dass sie
            // unsigniert injiziert wurden - eine untergeschobene Freigabe oder
            // ein zurueckgedrehter Policy-Zaehler darf so nicht durchrutschen.
            if (!AuthorityPropertiesAreAllAbsent(topLevelProperties))
            {
                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // A valid schema-10 signature (0.62.48) is accepted for migration.
            // This branch must run BEFORE the WeakeningRequestedUtc absence
            // check below: schema-10 configs carry that key signed.
            if (config.IntegritySchemaVersion == 10)
            {
                if (MatchesSchema10(config, key))
                {
                    return config;
                }

                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // Der WeakeningRequestedUtc-Schluessel ist erst ab Schema 10
            // signiert. Auf jedem aelteren Akzeptanzpfad bedeutet seine
            // Anwesenheit, dass er unsigniert injiziert wurde - eine
            // vorgezogene Frist darf so nicht durchrutschen.
            if (!WeakeningRequestedPropertyIsAbsent(topLevelProperties))
            {
                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // A valid schema-9 signature (0.62.47) is accepted for migration.
            // This branch must run BEFORE the ClockAnchor absence check below:
            // schema-9 configs carry the clock keys signed.
            if (config.IntegritySchemaVersion == 9)
            {
                if (MatchesSchema9(config, key))
                {
                    return config;
                }

                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // Der ClockAnchorUtc-Schluessel ist erst ab Schema 9 signiert. Auf
            // jedem aelteren Akzeptanzpfad bedeutet seine Anwesenheit, dass er
            // unsigniert injiziert wurde - eine gestellte Uhr darf so nicht an
            // der Pruefung vorbeigeschmuggelt werden.
            if (!ClockAnchorPropertyIsAbsent(topLevelProperties))
            {
                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // A valid schema-8 signature (0.62.38-0.62.46) is accepted for
            // migration. This branch must run BEFORE the
            // SocialMediaFeedBlockedPlatforms absence check below: schema-8
            // configs carry that key signed.
            if (config.IntegritySchemaVersion == 8)
            {
                if (MatchesSchema8(config, key))
                {
                    return config;
                }

                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // The SocialMediaFeedBlockedPlatforms key is only signed from
            // schema 8 on; on every older acceptance path (schema 7 included)
            // its presence means it was injected unsigned and must not be
            // smuggled past the check.
            if (!SocialMediaFeedBlockedPlatformsPropertyIsAbsent(topLevelProperties))
            {
                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // A valid schema-7 signature (0.62.32-0.62.37) is accepted for
            // migration. This branch must run BEFORE the InstalledVersion
            // absence check below: schema-7 configs carry that key signed.
            if (config.IntegritySchemaVersion == 7)
            {
                if (MatchesSchema7(config, key))
                {
                    return config;
                }

                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // The InstalledVersion key is only signed from schema 7 on; on every
            // older acceptance path its presence means it was injected unsigned
            // and must not be smuggled past the check.
            if (!InstalledVersionPropertyIsAbsent(topLevelProperties))
            {
                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // A valid schema-6 signature (0.62.30/0.62.31) is accepted for
            // migration.
            if (config.IntegritySchemaVersion == 6)
            {
                if (MatchesSchema6(config, key))
                {
                    return config;
                }

                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // The video-games detection keys are only signed from schema 6 on;
            // on every older acceptance path (schema 5 included) their
            // presence means they were injected unsigned and must not be
            // smuggled past the check.
            if (!VideoGamesDetectionPropertiesAreAllAbsent(topLevelProperties))
            {
                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // A valid schema-5 signature (0.62.29) is accepted for migration.
            if (config.IntegritySchemaVersion == 5)
            {
                if (MatchesSchema5(config, key))
                {
                    return config;
                }

                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // The video-games limit keys are only signed from schema 5 on; on
            // every older acceptance path their presence means they were
            // injected unsigned and must not be smuggled past the check.
            if (!VideoGamesLimitPropertiesAreAllAbsent(topLevelProperties))
            {
                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // A valid schema-4 signature (0.62.22-0.62.28) is accepted for
            // migration.
            if (config.IntegritySchemaVersion == 4)
            {
                if (MatchesSchema4(config, key))
                {
                    return config;
                }

                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // A valid schema-3 signature (0.62.21) is accepted for migration,
            // but ONLY when the schema-4 feed-damping threshold was not
            // injected unsigned.
            if (config.IntegritySchemaVersion == 3)
            {
                if (SocialMediaFeedDampingScrollPropertyIsAbsent(topLevelProperties) && MatchesSchema3(config, key))
                {
                    return config;
                }

                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            // A valid schema-2 signature (0.62.19) is accepted for migration,
            // but ONLY when none of the schema-3 social-media keys were
            // injected: they would be unsigned under schema 2 and must not be
            // smuggled past the check. Same rule guards the unversioned
            // (0.62.18) and schema-1 acceptance paths below.
            if (config.IntegritySchemaVersion == 2)
            {
                if (SocialMediaLimitPropertiesAreAllAbsent(topLevelProperties) && MatchesSchema2(config, key))
                {
                    return config;
                }

                return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
            }

            if (config.IntegritySchemaVersion != 0)
            {
                return MarkConfigCompromised(config, "unsupported integrity schema");
            }

            if (SocialMediaLimitPropertiesAreAllAbsent(topLevelProperties) && MatchesUnversioned062018(config, key))
            {
                return config;
            }

            if (SocialMediaLimitPropertiesAreAllAbsent(topLevelProperties) &&
                LegacyLimitPropertiesAreAllAbsent(topLevelProperties) &&
                MatchesSchema1(config, key))
            {
                return config;
            }

            return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
        }

        private static AppConfig VerifyDeclaredSchema(AppConfig config, byte[] key, int schemaVersion)
        {
            string expected = ComputeConfigIntegrityForSchema(config, key, schemaVersion);
            if (string.Equals(expected, config.Integrity, StringComparison.Ordinal))
            {
                return config;
            }

            return MarkConfigCompromised(config, "config.json HMAC mismatch (modified outside Purestate)");
        }

        private static bool MatchesUnversioned062018(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrity(config, key), config.Integrity, StringComparison.Ordinal);
        }

        private static bool MatchesSchema1(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrityForSchema(config, key, 1), config.Integrity, StringComparison.Ordinal);
        }

        private static bool MatchesSchema2(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrityForSchema(config, key, 2), config.Integrity, StringComparison.Ordinal);
        }

        private static bool MatchesSchema3(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrityForSchema(config, key, 3), config.Integrity, StringComparison.Ordinal);
        }

        private static bool MatchesSchema4(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrityForSchema(config, key, 4), config.Integrity, StringComparison.Ordinal);
        }

        private static bool MatchesSchema5(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrityForSchema(config, key, 5), config.Integrity, StringComparison.Ordinal);
        }

        private static bool MatchesSchema6(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrityForSchema(config, key, 6), config.Integrity, StringComparison.Ordinal);
        }

        private static bool MatchesSchema7(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrityForSchema(config, key, 7), config.Integrity, StringComparison.Ordinal);
        }

        private static bool MatchesSchema8(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrityForSchema(config, key, 8), config.Integrity, StringComparison.Ordinal);
        }

        private static bool MatchesSchema9(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrityForSchema(config, key, 9), config.Integrity, StringComparison.Ordinal);
        }

        private static bool AdultHostsFollowAreaPropertyIsAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "AdultHostsFollowArea", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        private static bool MatchesSchema12(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrityForSchema(config, key, 12), config.Integrity, StringComparison.Ordinal);
        }

        private static bool MatchesSchema13(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrityForSchema(config, key, 13), config.Integrity, StringComparison.Ordinal);
        }

        private static bool YouTubeRestrictPropertyIsAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "YouTubeRestrictEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        private static bool MatchesSchema11(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrityForSchema(config, key, 11), config.Integrity, StringComparison.Ordinal);
        }

        private static bool CompanionGracePropertyIsAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "CompanionGrace", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        private static bool MatchesSchema10(AppConfig config, byte[] key)
        {
            return string.Equals(ComputeConfigIntegrityForSchema(config, key, 10), config.Integrity, StringComparison.Ordinal);
        }

        private static bool AuthorityPropertiesAreAllAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "AuthorityMode", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "PolicyVersion", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "WeakeningGrant", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "GrantSignature", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "EntitledUntilUtc", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        private static bool WeakeningRequestedPropertyIsAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "WeakeningRequestedUtc", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        private static bool ClockAnchorPropertyIsAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "ClockAnchorUtc", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "ClockTickAnchorMs", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        private static bool SocialMediaFeedBlockedPlatformsPropertyIsAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "SocialMediaFeedBlockedPlatforms", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        private static bool EntitlementSignaturePropertyIsAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "EntitlementSignature", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }

            return true;
        }

        private static bool EntitlementMaxDevicesPropertyIsAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "EntitlementMaxDevices", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }

            return true;
        }

        private static bool InstalledVersionPropertyIsAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "InstalledVersion", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        private static bool VideoGamesDetectionPropertiesAreAllAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "VideoGamesAutoDetectEnabled", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "VideoGamesHeuristicEnabled", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        private static bool VideoGamesLimitPropertiesAreAllAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "VideoGamesDailyLimitEnabled", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "VideoGamesDailyLimitMinutes", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "VideoGamesCurfewEnabled", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "VideoGamesCurfewStart", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "VideoGamesCurfewEnd", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        private static bool SocialMediaFeedDampingScrollPropertyIsAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "SocialMediaFeedDampingScrolls", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        private static bool SocialMediaLimitPropertiesAreAllAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "SocialMediaDailyBudgetEnabled", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "SocialMediaDailyBudgetMinutes", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "SocialMediaPlatformLimits", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "SocialMediaBlockedPlatforms", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "SocialMediaCurfewEnabled", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "SocialMediaCurfewStart", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "SocialMediaCurfewEnd", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "SocialMediaReflectionEnabled", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "SocialMediaFeedDampingEnabled", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "SocialMediaFeedDampingScrolls", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        private static bool LegacyLimitPropertiesAreAllAbsent(IList<TopLevelJsonProperty> topLevelProperties)
        {
            foreach (TopLevelJsonProperty property in topLevelProperties)
            {
                if (string.Equals(property.Name, "ShoppingDailyLimitEnabled", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "ShoppingDailyLimitMinutes", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "ShoppingMonthlyOrderLimitEnabled", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "ShoppingMonthlyOrderLimit", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "ShoppingMonthlyBudgetEnabled", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "ShoppingMonthlyBudgetEuro", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "GamblingDailyLimitEnabled", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(property.Name, "GamblingDailyLimitMinutes", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
            return true;
        }

        // A tampered config is fully untrusted: force EVERY protection toggle to
        // its safe (on) value, clear all pause/uninstall timers, and set the
        // runtime IntegrityCompromised flag. That flag makes VerifyPassword
        // refuse the (untrusted) stored hash and makes SaveConfigUnlocked refuse
        // to write - so the tampered values can never be re-blessed with a fresh
        // HMAC. Recovery is a clean reinstall (see PurestateInstaller).
        internal static AppConfig MarkConfigCompromised(AppConfig config, string reason)
        {
            WriteSecurityLog("Config integrity check failed - " + reason + ". Forcing full protection; password refused until reinstall.");
            ForceSafeProtection(config);
            config.IntegrityCompromised = true;
            return config;
        }

        // Sets the protection-relevant fields to their maximally protective
        // values and clears every timer that could weaken or bypass protection.
        // Pure and testable; used by the tamper path.
        internal static void ForceSafeProtection(AppConfig config)
        {
            config.ProtectionEnabled = true;
            config.HostsEnabled = true;
            config.FamilyDnsEnabled = true;
            config.BypassBlockingEnabled = true;
            config.UnsupportedBrowserBlockingEnabled = true;
            config.TamperProtectionEnabled = true;
            // YouTubeRestrictEnabled bewusst NICHT erzwungen: die Vorgabe ist
            // seit 2026-08-09 aus, und der Manipulationspfad darf sie nicht
            // durch die Hintertuer zurueckholen. Das PowerShell-Gegenstueck
            // Set-SafeProtection fasst das Feld ohnehin nie an - damit stimmen
            // beide privilegierten Leser jetzt ueberein.
            config.SiteRedditEnabled = true;
            config.SiteXEnabled = true;
            config.SiteBlueskyEnabled = true;
            config.SiteTumblrEnabled = true;
            config.SiteDeviantArtEnabled = true;
            config.SitePixivEnabled = true;
            config.SiteNewgroundsEnabled = true;
            config.SiteImgurEnabled = true;
            config.SiteInstagramEnabled = true;
            config.SiteTikTokEnabled = true;
            config.SitePinterestEnabled = true;
            config.AdultContentProtectionEnabled = true;
            config.AdultContentProtectionMode = "strict";
            config.GamblingProtectionEnabled = true;
            config.GamblingProtectionMode = "strict";
            // Budget areas are forced on monotonically like gambling: a
            // tampered config must never yield less protection than any
            // legitimate state. Mirrored by Set-SafeProtection in
            // scripts\Common.ps1. Shopping and social media are friction
            // areas without any strict enforcement - "gentle" IS their
            // maximally protective mode; every feature below is still forced
            // on individually.
            config.ShoppingProtectionEnabled = true;
            config.ShoppingProtectionMode = "gentle";
            config.ShoppingDelayDefaultMinutes = 10;
            config.ShoppingCheckoutDelayEnabled = true;
            config.ShoppingStimulusDampingEnabled = true;
            config.ShoppingDealSearchBlockEnabled = true;
            config.ShoppingCurfewEnabled = true;
            config.ShoppingCurfewStart = "22:00";
            config.ShoppingCurfewEnd = "06:00";
            config.ShoppingDailyLimitEnabled = true;
            config.ShoppingDailyLimitMinutes = 30;
            config.ShoppingMonthlyOrderLimitEnabled = true;
            config.ShoppingMonthlyOrderLimit = 10;
            config.ShoppingMonthlyBudgetEnabled = true;
            config.ShoppingMonthlyBudgetEuro = 200;
            config.GamblingDailyLimitEnabled = true;
            config.GamblingDailyLimitMinutes = 15;
            config.SocialMediaDailyBudgetEnabled = true;
            config.SocialMediaDailyBudgetMinutes = 60;
            config.SocialMediaPlatformLimits = string.Empty;
            config.SocialMediaBlockedPlatforms = string.Empty;
            config.SocialMediaFeedBlockedPlatforms = string.Empty;
            config.SocialMediaCurfewEnabled = true;
            config.SocialMediaCurfewStart = "22:00";
            config.SocialMediaCurfewEnd = "06:00";
            config.SocialMediaReflectionEnabled = true;
            config.SocialMediaFeedDampingEnabled = true;
            config.SocialMediaFeedDampingScrolls = 50;
            config.VideoGamesProtectionEnabled = true;
            config.VideoGamesProtectionMode = "strict";
            config.VideoGamesDailyLimitEnabled = true;
            config.VideoGamesDailyLimitMinutes = 60;
            config.VideoGamesCurfewEnabled = true;
            config.VideoGamesCurfewStart = "22:00";
            config.VideoGamesCurfewEnd = "06:00";
            config.VideoGamesAutoDetectEnabled = true;
            config.VideoGamesHeuristicEnabled = true;
            config.SocialMediaProtectionEnabled = true;
            config.SocialMediaProtectionMode = "gentle";
            config.ProtectionAreaRulePackVersion = "1";
            config.GamblingSupportEnabled = false;
            config.GamblingSupportMode = "off";
            config.LockdownModeEnabled = true;
            config.PauseCooldownEnabled = true;
            config.PauseUntilUtc = string.Empty;
            config.PendingPauseUntilUtc = string.Empty;
            config.PendingUninstallUntilUtc = string.Empty;
            config.UninstallApprovalExpiresUtc = string.Empty;
        }

        // Vorhanden, aber ohne Inhalt: entweder Laenge null oder ausschliesslich
        // Nullbytes. Beides kann kein Schreibvorgang von Purestate erzeugen -
        // der Base64-Text hat immer Zeichen.
        private static bool IntegrityKeyFileLooksDestroyed()
        {
            try
            {
                if (!File.Exists(IntegrityKeyPath))
                {
                    return false;
                }

                byte[] raw = File.ReadAllBytes(IntegrityKeyPath);
                foreach (byte value in raw)
                {
                    if (value != 0)
                    {
                        return false;
                    }
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        private static byte[] TryLoadIntegrityKey()
        {
            try
            {
                if (!File.Exists(IntegrityKeyPath))
                {
                    return null;
                }

                byte[] key = Convert.FromBase64String(File.ReadAllText(IntegrityKeyPath).Trim());
                return key.Length >= 32 ? key : null;
            }
            catch
            {
                return null;
            }
        }

        // Called only inside the config lock (from SaveConfigUnlocked), so the
        // create-if-missing is serialized across processes and both C# and the
        // PowerShell writer converge on the same key file.
        private static byte[] LoadOrCreateIntegrityKey()
        {
            byte[] existing = TryLoadIntegrityKey();
            if (existing != null)
            {
                return existing;
            }

            byte[] key = new byte[32];
            using (RandomNumberGenerator rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(key);
            }

            EnsureDataDir();
            // Durable: ohne den Schluessel ist jede signierte Config wertlos und
            // die App verlangt eine Neueinrichtung samt Verlust aller Einstellungen.
            WriteAllTextDurable(IntegrityKeyPath, Convert.ToBase64String(key));
            return key;
        }

        public static void SaveConfig(AppConfig config)
        {
            WithConfigLock(delegate
            {
                SaveConfigUnlocked(config);
            });
        }

        public static void UpdateConfig(Action<AppConfig> update)
        {
            if (update == null)
            {
                throw new ArgumentNullException("update");
            }

            WithConfigLock(delegate
            {
                AppConfig config = LoadConfig();
                update(config);
                SaveConfigUnlocked(config);
            });
        }

        private static void UpdateConfigWithWeakeningGate(Action<AppConfig> update, DateTime localNow, bool devModeActive)
        {
            if (update == null)
            {
                throw new ArgumentNullException("update");
            }

            WithConfigLock(delegate
            {
                AppConfig config = LoadConfig();
                AppConfig before = config.Clone();
                update(config);
                ApplyAreaDependencies(before, config);
                RequireProtectionWeakeningWindow(before, config, localNow, devModeActive);
                SaveConfigUnlocked(config);
            });
        }

        // Neuinstallation: noch nichts an. Die Voreinstellungen INNERHALB der
        // Bereiche (Shopping 30 Minuten, Feinfilter pro Webseite, DNS-Profil)
        // bleiben - sie gelten, sobald der Nutzer den Bereich einschaltet.
        // AppConfig selbst bleibt schuetzend: eine fehlende config.json ist
        // nie "alles aus".
        public static void ApplyFreshInstallDefaults(AppConfig config)
        {
            config.AdultContentProtectionEnabled = false;
            config.AdultContentProtectionMode = "off";
            config.GamblingProtectionEnabled = false;
            config.GamblingProtectionMode = "off";
            config.GamblingSupportEnabled = false;
            config.GamblingSupportMode = "off";
            config.GamblingDailyLimitEnabled = false;
            config.ShoppingProtectionEnabled = false;
            config.SocialMediaProtectionEnabled = false;
            config.VideoGamesProtectionEnabled = false;
            config.HostsEnabled = false;
            config.FamilyDnsEnabled = false;
            config.BypassBlockingEnabled = false;
            config.UnsupportedBrowserBlockingEnabled = false;
            config.BrowserPoliciesEnabled = true;
            config.TamperProtectionEnabled = true;
            config.AdultHostsFollowArea = true;
        }

        // Was der Installer bei jedem Lauf setzt. Filter (Sperrliste, DNS,
        // VPN- und Browser-Sperre) erzwingt er nicht mehr: ein Update behaelt
        // die gespeicherten Werte, eine Neuinstallation beginnt mit allem aus.
        public static void ApplyInstallerConfig(AppConfig config, bool freshInstall)
        {
            config.InstalledVersion = AppVersion;
            config.ProtectionEnabled = true;
            config.BrowserPoliciesEnabled = true;
            config.TamperProtectionEnabled = true;
            config.LockdownModeEnabled = true;
            config.PauseCooldownEnabled = true;
            config.PauseUntilUtc = string.Empty;
            if (freshInstall)
            {
                ApplyFreshInstallDefaults(config);
            }
        }

        // "version|bisUtc". Eine Zeile ohne Zeilenvorschub, damit sie ohne
        // JSON-Maskierung in config.json passt.
        public static string FormatCompanionGrace(string version, DateTime untilUtc)
        {
            return version + "|" + untilUtc.ToUniversalTime().ToString("o");
        }

        public static bool TryParseCompanionGrace(string stored, out string version, out DateTime untilUtc)
        {
            version = string.Empty;
            untilUtc = DateTime.MinValue;

            if (string.IsNullOrEmpty(stored))
            {
                return false;
            }

            string[] parts = stored.Split('|');
            if (parts.Length != 2 || parts[0].Length == 0)
            {
                return false;
            }

            if (!TryReadUtc(parts[1], out untilUtc))
            {
                return false;
            }

            version = parts[0];
            return true;
        }

        // Die zusaetzlich zugelassene Companion-Version, solange die Frist
        // laeuft. Leer, sobald sie abgelaufen ist - dann greift wieder die
        // Vollsperre. Gemessen mit der vertrauenswuerdigen Uhr: eine
        // vorgestellte Systemuhr darf die Frist nicht verlaengern, und ein
        // eingefrorener Anker haelt sie hoechstens kuerzer.
        public static string ActiveCompanionGraceVersion(AppConfig config, DateTime nowUtc)
        {
            string version;
            DateTime untilUtc;
            if (config == null || !TryParseCompanionGrace(config.CompanionGrace, out version, out untilUtc))
            {
                return string.Empty;
            }

            return nowUtc < untilUtc ? version : string.Empty;
        }

        // Beim Versionswechsel gesetzt: der Store liefert die passende
        // Companion-Version erst nach seiner Pruefung aus. Ohne diese Frist
        // waeren bis dahin alle gemischten Seiten voll gesperrt.
        //
        // Eine bereits laufende Frist wird dabei ueberschrieben, nicht
        // verlaengert: es gilt immer nur die unmittelbare Vorgaengerversion,
        // sonst haelte eine Kette schneller Updates eine sehr alte Version
        // beliebig lange gueltig.
        public static void StartCompanionGrace(AppConfig config, string newVersion, DateTime nowUtc)
        {
            if (config == null)
            {
                return;
            }

            string previous = config.InstalledVersion;
            if (string.IsNullOrEmpty(previous) ||
                string.Equals(previous, newVersion, StringComparison.Ordinal))
            {
                // Neuinstallation oder Reparaturlauf derselben Version: es gibt
                // keinen Vorgaenger, den man noch zulassen muesste.
                return;
            }

            config.CompanionGrace = FormatCompanionGrace(previous, nowUtc.AddDays(CompanionGraceDays));
        }

        // Das Fenster ist offen zwischen "angefordert + 7 Tage" und weitere
        // 24 Stunden danach. Gemessen wird ueber die vertrauenswuerdige Uhr,
        // damit ein Vorstellen der Systemuhr die Frist nicht verkuerzt.
        public static bool IsWeakeningWindowOpen(AppConfig config, DateTime nowUtc)
        {
            return IsWeakeningWindowOpen(config, nowUtc, true);
        }

        public static bool IsWeakeningWindowOpen(AppConfig config, DateTime nowUtc, bool major)
        {
            // Im Servermodus misst der Client die Frist NICHT selbst. Die
            // Existenz einer gueltigen Signatur ist der Beweis, dass sie
            // abgelaufen ist. Ohne Freigabe bleibt das Fenster zu - auch ohne
            // Netz, auch bei abgelaufenem Anspruch, unbegrenzt lange.
            if (IsServerAuthorityMode(config))
            {
                return IsGrantValid(config, nowUtc);
            }

            DateTime requested;
            if (config == null || !TryReadUtc(config.WeakeningRequestedUtc, out requested))
            {
                return false;
            }

            DateTime majorOpensAt = requested.AddDays(WeakeningWaitDays);
            DateTime closesAt = majorOpensAt.AddHours(WeakeningWindowHours);
            DateTime opensAt = major ? majorOpensAt : requested.AddHours(WeakeningMinorWaitHours);
            return nowUtc >= opensAt && nowUtc < closesAt;
        }

        // devModeActive existiert nur noch fuer die Tests, die damit den Zweig
        // "Fenster offen" ohne Zeitmanipulation ansteuern. Der ausgelieferte
        // Pfad uebergibt ueberall fest false.
        //
        // Bis 0.62.50 kam der Wert aus IsDevModeActive(), also aus der blossen
        // Anwesenheit von dev-companion-id.txt. Damit schaltete eine Datei in
        // Program Files das gesamte Gate ab - fuer einen Angreifer mit
        // Administratorrechten, und genau der ist der gewaehlte Angreifer.
        public static bool IsProtectionWeakeningAllowed(AppConfig config, DateTime nowUtc, bool devModeActive)
        {
            return IsProtectionWeakeningAllowed(config, nowUtc, devModeActive, true);
        }

        public static bool IsProtectionWeakeningAllowed(AppConfig config, DateTime nowUtc, bool devModeActive, bool major)
        {
            return devModeActive || DevUnlockActive || IsWeakeningWindowOpen(config, nowUtc, major);
        }

        // 0 = keine oder abgelaufene Anfrage, 1 = Frist laeuft, 2 = Fenster
        // offen. Ein abgelaufener Zeitstempel wird bewusst NICHT geleert:
        // dasselbe Schreiben koennte eine Abschwaechung im offenen Fenster
        // sein, und ein falsch gesetzter Grenzfall wuerde das Fenster mitten
        // im Speichern schliessen. Stehen zu lassen kostet nichts, weil hier
        // ohnehin gegen das Intervall geprueft wird.
        public static int EvaluateWeakeningRequest(AppConfig config, DateTime nowUtc, out DateTime opensAtUtc, out DateTime closesAtUtc)
        {
            opensAtUtc = DateTime.MinValue;
            closesAtUtc = DateTime.MinValue;

            DateTime requested;
            if (config == null || !TryReadUtc(config.WeakeningRequestedUtc, out requested))
            {
                return 0;
            }

            opensAtUtc = requested.AddDays(WeakeningWaitDays);
            closesAtUtc = opensAtUtc.AddHours(WeakeningWindowHours);

            if (nowUtc < opensAtUtc)
            {
                return 1;
            }

            return nowUtc < closesAtUtc ? 2 : 0;
        }

        // Eine Frist zu starten aendert nichts am Schutz und braucht deshalb
        // kein Gate - sonst braeuchte man eine Frist, um eine Frist zu
        // beginnen. Laeuft bereits eine Anfrage, wird sie NICHT neu gestartet:
        // sonst wuerde ein zweiter Klick eine fast abgelaufene Frist
        // versehentlich zuruecksetzen.
        public static DateTime BeginWeakeningRequest()
        {
            return WithConfigLock(delegate
            {
                AppConfig config = LoadConfig();
                DateTime now = TrustedUtcNow(config);
                DateTime opensAt;
                DateTime closesAt;
                if (EvaluateWeakeningRequest(config, now, out opensAt, out closesAt) != 0)
                {
                    return opensAt;
                }

                config.WeakeningRequestedUtc = now.ToString("o");
                SaveConfigUnlocked(config);
                return now.AddDays(WeakeningWaitDays);
            });
        }

        // Abbrechen ist eine Verstaerkung und daher jederzeit erlaubt.
        public static void CancelWeakeningRequest()
        {
            UpdateConfig(delegate (AppConfig config) { config.WeakeningRequestedUtc = string.Empty; });
        }

        // Nennt die ausloesende Einstellung, sonst steht der Nutzer vor einer
        // Ablehnung ohne zu wissen, welcher Schalter sie verursacht hat.
        //
        // Der Modus gehoert bewusst in die Signatur statt als Vorgabewert: im
        // Servermodus oeffnet die lokale Sieben-Tage-Frist gar nichts, und ein
        // Verweis auf sie schickt den Nutzer auf einen Weg, den es dort nicht
        // gibt. Jeder Aufrufer hat die Konfiguration ohnehin in der Hand.
        public static string ProtectionWeakeningGateMessage(string reason, bool serverAuthority)
        {
            return ProtectionWeakeningGateMessage(reason, serverAuthority, true);
        }

        public static string ProtectionWeakeningGateMessage(string reason, bool serverAuthority, bool major)
        {
            string subject = string.IsNullOrEmpty(reason)
                ? "Diese Aenderung"
                : ("Die Aenderung an \"" + reason + "\"");
            string path;
            if (serverAuthority)
            {
                path = "Starte dafuer unter Einstellungen die Frist und rufe danach die Freigabe ab: der Server erteilt sie 72 Stunden spaeter, dann kannst du einen Tag lang lockern.";
            }
            else if (major)
            {
                path = "Starte dafuer unter Einstellungen die Frist: sieben Tage spaeter kannst du einen Tag lang lockern.";
            }
            else
            {
                path = "Starte dafuer unter Einstellungen die Frist: 24 Stunden spaeter ist diese kleinere Lockerung moeglich.";
            }
            return subject + " wuerde den Schutz abschwaechen. " + path + " Schutz staerken bleibt jederzeit moeglich.";
        }

        // Signatur bewusst unveraendert: die Dialoge reichen weiterhin
        // Support.TrustedLocalNow() durch, und "before" ist die geltende
        // Konfiguration, aus der das Fenster abgeleitet wird.
        public static void RequireProtectionWeakeningWindow(AppConfig before, AppConfig after, DateTime localNow, bool devModeActive)
        {
            string reason;
            if (!IsProtectionWeakening(before, after, out reason))
            {
                return;
            }

            // Bei mehreren Aenderungen auf einmal entscheidet die schwerste:
            // IsMajorProtectionWeakening prueft unabhaengig vom ersten
            // gefundenen Grund, sonst koennte eine grosse Abschwaechung im
            // Windschatten einer kleinen nach 24 Stunden durchgehen.
            bool major = IsMajorProtectionWeakening(before, after);
            if (!IsProtectionWeakeningAllowed(before, localNow.ToUniversalTime(), devModeActive, major))
            {
                throw new InvalidOperationException(
                    ProtectionWeakeningGateMessage(reason, IsServerAuthorityMode(before), major));
            }
        }

        public static bool IsProtectionWeakening(AppConfig current, AppConfig next)
        {
            string reason;
            return IsProtectionWeakening(current, next, out reason);
        }

        // Liefert zusaetzlich die AUSLOESENDE Einstellung, damit die
        // Fehlermeldung sie benennen kann. Ohne das sagt das Gate nur "diese
        // Aenderung wuerde den Schutz abschwaechen", und weder Nutzer noch
        // Entwickler sehen welches der ueber vierzig Felder gemeint ist.
        // Die Bezeichnungen entsprechen dem, was in der Oberflaeche steht.
        // Grosse Abschwaechung: ein Schutz verschwindet ganz oder faellt in
        // einen schwaecheren Modus. Alles andere ist klein - der Bereich
        // bleibt an, nur ein Parameter wird milder. Die Unterscheidung
        // steuert die Wartefrist (sieben Tage gegen 24 Stunden) und sonst
        // nichts: klein heisst nicht ungeprueft.
        public static bool IsMajorProtectionWeakening(AppConfig current, AppConfig next)
        {
            AppConfig before;
            AppConfig after;
            NormalizeWeakeningPair(current, next, out before, out after);
            string reason = string.Empty;
            return IsMajorWeakening(before, after, ref reason);
        }

        private static void NormalizeWeakeningPair(AppConfig current, AppConfig next, out AppConfig before, out AppConfig after)
        {
            if (current == null)
            {
                current = new AppConfig();
            }
            if (next == null)
            {
                next = new AppConfig();
            }

            before = current.Clone();
            after = next.Clone();
            NormalizeGamblingProtectionState(before);
            NormalizeGamblingProtectionState(after);
            NormalizeSoftProtectionAreaState(before);
            NormalizeSoftProtectionAreaState(after);
        }

        public static bool IsProtectionWeakening(AppConfig current, AppConfig next, out string reason)
        {
            reason = string.Empty;

            AppConfig before;
            AppConfig after;
            NormalizeWeakeningPair(current, next, out before, out after);

            if (IsMajorWeakening(before, after, ref reason))
            {
                return true;
            }

            return IsMinorWeakening(before, after, ref reason);
        }

        // Die harten Faelle. Bewusst eine eigene Methode statt einer zweiten
        // Feldliste: eine Kopie wuerde beim naechsten neuen Schalter
        // auseinanderlaufen, und dann waere eine grosse Abschwaechung
        // stillschweigend nach 24 Stunden moeglich.
        private static bool IsMajorWeakening(AppConfig before, AppConfig after, ref string reason)
        {
            // Der Rueckfall auf lokale Autoritaet ist selbst eine
            // Abschwaechung: er loest die Geraetebindung und ersetzt die
            // servergemessene Frist durch eine, die der Nutzer stellen kann.
            // Er laeuft deshalb ueber dasselbe Fenster wie jede andere - und
            // im Servermodus oeffnet dieses Fenster nur eine Serverfreigabe.
            if (Weakens(ref reason, "Serverautoritaet",
                IsServerAuthorityMode(before) && !IsServerAuthorityMode(after))) return true;
            if (Weakens(ref reason, "Schutz aktiv", WeakensBoolean(before.ProtectionEnabled, after.ProtectionEnabled))) return true;
            if (Weakens(ref reason, "Webseiten auf diesem PC blockieren", WeakensBoolean(before.HostsEnabled, after.HostsEnabled))) return true;
            if (Weakens(ref reason, "Zusaetzlicher Internetfilter (DNS)", WeakensBoolean(before.FamilyDnsEnabled, after.FamilyDnsEnabled))) return true;
            if (Weakens(ref reason, "Umgehungsschutz", WeakensBoolean(before.BypassBlockingEnabled, after.BypassBlockingEnabled))) return true;
            if (Weakens(ref reason, "Nicht unterstuetzte Browser blockieren", WeakensBoolean(before.UnsupportedBrowserBlockingEnabled, after.UnsupportedBrowserBlockingEnabled))) return true;
            if (Weakens(ref reason, "Manipulationsschutz", WeakensBoolean(before.TamperProtectionEnabled, after.TamperProtectionEnabled))) return true;
            // DESK-03: Sperrmodus und Wartezeit sind gemeinsam EINE Pausenregel
            // mit drei Stufen (sofort < nach Wartezeit < nicht moeglich). Einzeln
            // verglichen galt "nicht moeglich -> nach Wartezeit" (Wartezeit
            // aus -> an) nicht als Lockerung, und die staerkste Wahl ab "nach
            // Wartezeit" (Wartezeit an -> aus) wurde als Abschwaechung abgelehnt.
            if (Weakens(ref reason, "Pausenregel (Sperrmodus/Wartezeit)",
                PauseModeFromFlags(after.LockdownModeEnabled, after.PauseCooldownEnabled) <
                PauseModeFromFlags(before.LockdownModeEnabled, before.PauseCooldownEnabled))) return true;

            // Vor den Webseiten-Regeln: die Feinfilter haengen am Bereich, beim
            // Ausschalten soll die Meldung den Bereich nennen, nicht Reddit.
            if (Weakens(ref reason, "Erwachsenenschutz", WeakensProtectionArea(before.AdultContentProtectionEnabled, before.AdultContentProtectionMode, after.AdultContentProtectionEnabled, after.AdultContentProtectionMode, false, "strict"))) return true;
            if (Weakens(ref reason, "Seitenschutz Reddit", WeakensBoolean(SiteFilterEffective(before, before.SiteRedditEnabled), SiteFilterEffective(after, after.SiteRedditEnabled)))) return true;
            if (Weakens(ref reason, "Seitenschutz X/Twitter", WeakensBoolean(SiteFilterEffective(before, before.SiteXEnabled), SiteFilterEffective(after, after.SiteXEnabled)))) return true;
            if (Weakens(ref reason, "Seitenschutz Bluesky", WeakensBoolean(SiteFilterEffective(before, before.SiteBlueskyEnabled), SiteFilterEffective(after, after.SiteBlueskyEnabled)))) return true;
            if (Weakens(ref reason, "Seitenschutz Tumblr", WeakensBoolean(SiteFilterEffective(before, before.SiteTumblrEnabled), SiteFilterEffective(after, after.SiteTumblrEnabled)))) return true;
            if (Weakens(ref reason, "Seitenschutz DeviantArt", WeakensBoolean(SiteFilterEffective(before, before.SiteDeviantArtEnabled), SiteFilterEffective(after, after.SiteDeviantArtEnabled)))) return true;
            if (Weakens(ref reason, "Seitenschutz pixiv", WeakensBoolean(SiteFilterEffective(before, before.SitePixivEnabled), SiteFilterEffective(after, after.SitePixivEnabled)))) return true;
            if (Weakens(ref reason, "Seitenschutz Newgrounds", WeakensBoolean(SiteFilterEffective(before, before.SiteNewgroundsEnabled), SiteFilterEffective(after, after.SiteNewgroundsEnabled)))) return true;
            if (Weakens(ref reason, "Seitenschutz Imgur", WeakensBoolean(SiteFilterEffective(before, before.SiteImgurEnabled), SiteFilterEffective(after, after.SiteImgurEnabled)))) return true;
            if (Weakens(ref reason, "Seitenschutz Instagram", WeakensBoolean(SiteFilterEffective(before, before.SiteInstagramEnabled), SiteFilterEffective(after, after.SiteInstagramEnabled)))) return true;
            if (Weakens(ref reason, "Seitenschutz TikTok", WeakensBoolean(SiteFilterEffective(before, before.SiteTikTokEnabled), SiteFilterEffective(after, after.SiteTikTokEnabled)))) return true;
            if (Weakens(ref reason, "Seitenschutz Pinterest", WeakensBoolean(SiteFilterEffective(before, before.SitePinterestEnabled), SiteFilterEffective(after, after.SitePinterestEnabled)))) return true;

            if (Weakens(ref reason, "Gluecksspiel-Schutz", WeakensProtectionArea(EffectiveGamblingProtectionEnabled(before), EffectiveGamblingProtectionMode(before), EffectiveGamblingProtectionEnabled(after), EffectiveGamblingProtectionMode(after), false, "off"))) return true;
            if (Weakens(ref reason, "Shopping-Schutz", WeakensProtectionArea(before.ShoppingProtectionEnabled, before.ShoppingProtectionMode, after.ShoppingProtectionEnabled, after.ShoppingProtectionMode, true, "planned"))) return true;
            if (Weakens(ref reason, "Social-Media-Schutz", WeakensProtectionArea(before.SocialMediaProtectionEnabled, before.SocialMediaProtectionMode, after.SocialMediaProtectionEnabled, after.SocialMediaProtectionMode, true, "planned"))) return true;
            if (Weakens(ref reason, "Videospiel-Schutz", WeakensProtectionArea(before.VideoGamesProtectionEnabled, NormalizeVideoGamesMode(before.VideoGamesProtectionMode, before.VideoGamesProtectionEnabled), after.VideoGamesProtectionEnabled, NormalizeVideoGamesMode(after.VideoGamesProtectionMode, after.VideoGamesProtectionEnabled), false, "planned"))) return true;

            return false;
        }

        // Detailparameter innerhalb eines Bereichs, der an bleibt.
        private static bool IsMinorWeakening(AppConfig before, AppConfig after, ref string reason)
        {
            // Klein und nicht gross: der Erwachsenenschutz bleibt vollstaendig
            // stehen (hosts, DNS, Sperrlisten, SafeSearch, Companion). Es
            // faellt ein Zusatzfilter von YouTube weg, der ohnehin
            // regelmaessig Harmloses sperrt.
            if (Weakens(ref reason, "YouTube: eingeschraenkter Modus", WeakensBoolean(before.YouTubeRestrictEnabled, after.YouTubeRestrictEnabled))) return true;

            if (Weakens(ref reason, "Shopping: Wartezeit vor dem Kauf", WeakensBoolean(before.ShoppingCheckoutDelayEnabled, after.ShoppingCheckoutDelayEnabled))) return true;
            if (Weakens(ref reason, "Shopping: ruhigere Shop-Seiten", WeakensBoolean(before.ShoppingStimulusDampingEnabled, after.ShoppingStimulusDampingEnabled))) return true;
            if (Weakens(ref reason, "Shopping: Angebotssuche blockieren", WeakensBoolean(before.ShoppingDealSearchBlockEnabled, after.ShoppingDealSearchBlockEnabled))) return true;
            if (Weakens(ref reason, "Shopping: Sperrzeit", WeakensWindow(before.ShoppingCurfewEnabled, before.ShoppingCurfewStart, before.ShoppingCurfewEnd, after.ShoppingCurfewEnabled, after.ShoppingCurfewStart, after.ShoppingCurfewEnd, "22:00", "06:00"))) return true;
            if (Weakens(ref reason, "Shopping: Dauer der Wartezeit", before.ShoppingCheckoutDelayEnabled && after.ShoppingCheckoutDelayEnabled &&
                NormalizeGamblingDelayMinutes(after.ShoppingDelayDefaultMinutes) < NormalizeGamblingDelayMinutes(before.ShoppingDelayDefaultMinutes))) return true;
            if (Weakens(ref reason, "Shopping: Tageslimit", WeakensUpperLimit(before.ShoppingDailyLimitEnabled, NormalizeDailyLimitMinutes(before.ShoppingDailyLimitMinutes, 30), after.ShoppingDailyLimitEnabled, NormalizeDailyLimitMinutes(after.ShoppingDailyLimitMinutes, 30)))) return true;
            if (Weakens(ref reason, "Shopping: Monatslimit fuer Bestellungen", WeakensUpperLimit(before.ShoppingMonthlyOrderLimitEnabled, NormalizeMonthlyOrderLimit(before.ShoppingMonthlyOrderLimit), after.ShoppingMonthlyOrderLimitEnabled, NormalizeMonthlyOrderLimit(after.ShoppingMonthlyOrderLimit)))) return true;
            if (Weakens(ref reason, "Shopping: Monatsbudget", WeakensUpperLimit(before.ShoppingMonthlyBudgetEnabled, NormalizeMonthlyBudgetEuro(before.ShoppingMonthlyBudgetEuro), after.ShoppingMonthlyBudgetEnabled, NormalizeMonthlyBudgetEuro(after.ShoppingMonthlyBudgetEuro)))) return true;

            // Das Companion-Tageslimit greift nur, solange die strenge Sperre
            // AUS ist - bei aktiver Sperre ist es ohnehin abgeschaltet. Im
            // Dialog sind "Aus", "Zeitlimit" und "komplette Sperre" dieselben
            // drei Radioknoepfe, der Wechsel auf die Sperre schaltet das Limit
            // also zwangslaeufig ab. Ohne diese Ausnahme meldete der
            // Feldvergleich ausgerechnet die staerkste Einstellung als
            // Abschwaechung und machte sie unerreichbar. Der umgekehrte Weg
            // (Sperre -> Zeitlimit) bleibt eine Abschwaechung und wird oben
            // von WeakensProtectionArea erfasst.
            if (Weakens(ref reason, "Gluecksspiel: Tageslimit", !EffectiveGamblingProtectionEnabled(after) &&
                WeakensUpperLimit(before.GamblingDailyLimitEnabled, NormalizeDailyLimitMinutes(before.GamblingDailyLimitMinutes, 15), after.GamblingDailyLimitEnabled, NormalizeDailyLimitMinutes(after.GamblingDailyLimitMinutes, 15)))) return true;

            if (Weakens(ref reason, "Social Media: Tagesbudget", WeakensUpperLimit(before.SocialMediaDailyBudgetEnabled, NormalizeSocialMediaBudgetMinutes(before.SocialMediaDailyBudgetMinutes), after.SocialMediaDailyBudgetEnabled, NormalizeSocialMediaBudgetMinutes(after.SocialMediaDailyBudgetMinutes)))) return true;
            if (Weakens(ref reason, "Social Media: Limits einzelner Plattformen", WeakensSocialMediaPlatformLimits(before, after))) return true;
            if (Weakens(ref reason, "Social Media: gesperrte Plattformen", WeakensCsvSet(NormalizeSocialMediaBlockedPlatforms(before.SocialMediaBlockedPlatforms), NormalizeSocialMediaBlockedPlatforms(after.SocialMediaBlockedPlatforms)))) return true;
            if (Weakens(ref reason, "Social Media: gesperrte Feeds", WeakensCsvSet(
                NormalizeSocialMediaFeedBlockedPlatforms(before.SocialMediaFeedBlockedPlatforms, before.SocialMediaBlockedPlatforms),
                NormalizeSocialMediaFeedBlockedPlatforms(after.SocialMediaFeedBlockedPlatforms, after.SocialMediaBlockedPlatforms)))) return true;
            if (Weakens(ref reason, "Social Media: Sperrzeit", WeakensWindow(before.SocialMediaCurfewEnabled, before.SocialMediaCurfewStart, before.SocialMediaCurfewEnd, after.SocialMediaCurfewEnabled, after.SocialMediaCurfewStart, after.SocialMediaCurfewEnd, "22:00", "06:00"))) return true;
            if (Weakens(ref reason, "Social Media: Reflexionsfrage", WeakensBoolean(before.SocialMediaReflectionEnabled, after.SocialMediaReflectionEnabled))) return true;
            if (Weakens(ref reason, "Social Media: Feed-Bremse", WeakensBoolean(before.SocialMediaFeedDampingEnabled, after.SocialMediaFeedDampingEnabled))) return true;
            if (Weakens(ref reason, "Social Media: Scroll-Schwelle der Feed-Bremse", WeakensUpperLimit(before.SocialMediaFeedDampingEnabled, NormalizeSocialMediaFeedDampingScrolls(before.SocialMediaFeedDampingScrolls), after.SocialMediaFeedDampingEnabled, NormalizeSocialMediaFeedDampingScrolls(after.SocialMediaFeedDampingScrolls)))) return true;

            if (Weakens(ref reason, "Videospiele: Tageslimit", WeakensUpperLimit(before.VideoGamesDailyLimitEnabled, NormalizeVideoGamesDailyLimitMinutes(before.VideoGamesDailyLimitMinutes), after.VideoGamesDailyLimitEnabled, NormalizeVideoGamesDailyLimitMinutes(after.VideoGamesDailyLimitMinutes)))) return true;
            if (Weakens(ref reason, "Videospiele: Sperrzeit", WeakensWindow(before.VideoGamesCurfewEnabled, before.VideoGamesCurfewStart, before.VideoGamesCurfewEnd, after.VideoGamesCurfewEnabled, after.VideoGamesCurfewStart, after.VideoGamesCurfewEnd, "22:00", "06:00"))) return true;
            if (Weakens(ref reason, "Videospiele: automatische Spielerkennung", WeakensBoolean(before.VideoGamesAutoDetectEnabled, after.VideoGamesAutoDetectEnabled))) return true;
            if (Weakens(ref reason, "Videospiele: Verhaltenserkennung", WeakensBoolean(before.VideoGamesHeuristicEnabled, after.VideoGamesHeuristicEnabled))) return true;

            if (Weakens(ref reason, "Zeitplan", WeakensWindow(before.ScheduleEnabled, before.ScheduleStart, before.ScheduleEnd, after.ScheduleEnabled, after.ScheduleStart, after.ScheduleEnd, "22:00", "06:00"))) return true;
            if (Weakens(ref reason, "Strenger Modus im Zeitplan", before.ScheduleEnabled && ScheduleWindowMinutes(before.ScheduleStart, before.ScheduleEnd, "22:00", "06:00") > 0 &&
                before.StrictModeEnabled && !after.StrictModeEnabled)) return true;

            return false;
        }

        private static bool Weakens(ref string reason, string label, bool weakened)
        {
            if (!weakened)
            {
                return false;
            }

            reason = label;
            return true;
        }

        private static bool WeakensBoolean(bool before, bool after)
        {
            return before && !after;
        }

        private static bool WeakensUpperLimit(bool beforeEnabled, int beforeValue, bool afterEnabled, int afterValue)
        {
            if (!beforeEnabled)
            {
                return false;
            }
            if (!afterEnabled)
            {
                return true;
            }
            return afterValue > beforeValue;
        }

        // Webseiten-Feinfilter wirken nur bei eingeschaltetem Bereich
        // Erwachseneninhalte. Verglichen wird, was wirkt: nach einer
        // Neuinstallation (Bereich aus, Haekchen gesetzt) galt "Bereich an,
        // eine Seite abgewaehlt" sonst als Abschwaechung mit sieben Tagen
        // Frist, obwohl der Schutz nur steigt.
        private static bool SiteFilterEffective(AppConfig config, bool siteEnabled)
        {
            return config.AdultContentProtectionEnabled && siteEnabled;
        }

        private static bool WeakensProtectionArea(bool beforeEnabled, string beforeMode, bool afterEnabled, string afterMode, bool softMode, string fallback)
        {
            return ProtectionAreaRank(beforeEnabled, beforeMode, softMode, fallback) >
                ProtectionAreaRank(afterEnabled, afterMode, softMode, fallback);
        }

        private static int ProtectionAreaRank(bool enabled, string mode, bool softMode, string fallback)
        {
            if (!enabled)
            {
                return 0;
            }

            string normalized = softMode ? NormalizeSoftProtectionAreaMode(mode, fallback) : NormalizeProtectionAreaMode(mode, fallback);
            if (normalized == "strict") return 3;
            if (normalized == "gentle") return 2;
            if (normalized == "planned") return 1;
            return 0;
        }

        private static bool WeakensWindow(bool beforeEnabled, string beforeStart, string beforeEnd, bool afterEnabled, string afterStart, string afterEnd, string fallbackStart, string fallbackEnd)
        {
            if (!beforeEnabled)
            {
                return false;
            }

            int beforeMinutes = ScheduleWindowMinutes(beforeStart, beforeEnd, fallbackStart, fallbackEnd);
            if (beforeMinutes == 0)
            {
                return false;
            }

            if (!afterEnabled)
            {
                return true;
            }

            int afterMinutes = ScheduleWindowMinutes(afterStart, afterEnd, fallbackStart, fallbackEnd);
            if (afterMinutes < beforeMinutes)
            {
                return true;
            }

            string normalizedBeforeStart = NormalizeTimeText(beforeStart, fallbackStart);
            string normalizedBeforeEnd = NormalizeTimeText(beforeEnd, fallbackEnd);
            string normalizedAfterStart = NormalizeTimeText(afterStart, fallbackStart);
            string normalizedAfterEnd = NormalizeTimeText(afterEnd, fallbackEnd);
            return afterMinutes == beforeMinutes &&
                (!string.Equals(normalizedBeforeStart, normalizedAfterStart, StringComparison.Ordinal) ||
                 !string.Equals(normalizedBeforeEnd, normalizedAfterEnd, StringComparison.Ordinal));
        }

        private static int ScheduleWindowMinutes(string startText, string endText, string fallbackStart, string fallbackEnd)
        {
            int start;
            int end;
            if (!TryParseTimeText(NormalizeTimeText(startText, fallbackStart), out start) ||
                !TryParseTimeText(NormalizeTimeText(endText, fallbackEnd), out end) ||
                start == end)
            {
                return 0;
            }

            return start < end ? end - start : (24 * 60 - start) + end;
        }

        private static bool WeakensCsvSet(string beforeCsv, string afterCsv)
        {
            HashSet<string> before = CsvSet(beforeCsv);
            HashSet<string> after = CsvSet(afterCsv);
            foreach (string value in before)
            {
                if (!after.Contains(value))
                {
                    return true;
                }
            }
            return false;
        }

        private static HashSet<string> CsvSet(string csv)
        {
            HashSet<string> values = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string part in (csv ?? string.Empty).Split(','))
            {
                string value = part.Trim().ToLowerInvariant();
                if (value.Length > 0)
                {
                    values.Add(value);
                }
            }
            return values;
        }

        private static bool WeakensSocialMediaPlatformLimits(AppConfig before, AppConfig after)
        {
            Dictionary<string, int> beforeLimits = ParseSocialMediaPlatformLimitMap(
                NormalizeSocialMediaPlatformLimits(before.SocialMediaPlatformLimits, before.SocialMediaDailyBudgetEnabled, before.SocialMediaDailyBudgetMinutes));
            Dictionary<string, int> afterLimits = ParseSocialMediaPlatformLimitMap(
                NormalizeSocialMediaPlatformLimits(after.SocialMediaPlatformLimits, after.SocialMediaDailyBudgetEnabled, after.SocialMediaDailyBudgetMinutes));

            foreach (KeyValuePair<string, int> entry in beforeLimits)
            {
                int afterMinutes;
                if (!afterLimits.TryGetValue(entry.Key, out afterMinutes) || afterMinutes > entry.Value)
                {
                    return true;
                }
            }
            return false;
        }

        private static Dictionary<string, int> ParseSocialMediaPlatformLimitMap(string csv)
        {
            Dictionary<string, int> limits = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (string part in (csv ?? string.Empty).Split(','))
            {
                string[] pair = part.Split('=');
                int minutes;
                if (pair.Length == 2 && int.TryParse(pair[1].Trim(), out minutes))
                {
                    limits[pair[0].Trim().ToLowerInvariant()] = minutes;
                }
            }
            return limits;
        }

        private static void SaveConfigUnlocked(AppConfig config)
        {
            if (config.IntegrityCompromised)
            {
                throw new InvalidOperationException("Die Purestate-Konfiguration wurde ausserhalb der App veraendert und ist gesperrt. Bitte installiere Purestate neu.");
            }

            if (config.Password == null)
            {
                throw new InvalidOperationException("Es ist noch kein Passwort eingerichtet.");
            }

            NormalizeGamblingProtectionState(config);
            // Clamp the friction-area modes on the OBJECT before signing so
            // canonical text, HMAC and written file agree (write-path only;
            // the read path keeps accepting legacy signed "strict").
            NormalizeSoftProtectionAreaState(config);
            config.IntegritySchemaVersion = CurrentIntegritySchemaVersion;
            EnsureDataDir();
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("{");
            builder.AppendLine("  \"ProtectionEnabled\": " + ToJsonBool(config.ProtectionEnabled) + ",");
            builder.AppendLine("  \"HostsEnabled\": " + ToJsonBool(config.HostsEnabled) + ",");
            builder.AppendLine("  \"FamilyDnsEnabled\": " + ToJsonBool(config.FamilyDnsEnabled) + ",");
            builder.AppendLine("  \"DnsProfile\": \"" + EscapeJson(NormalizeDnsProfile(config.DnsProfile)) + "\",");
            builder.AppendLine("  \"BrowserPoliciesEnabled\": " + ToJsonBool(config.BrowserPoliciesEnabled) + ",");
            builder.AppendLine("  \"BypassBlockingEnabled\": " + ToJsonBool(config.BypassBlockingEnabled) + ",");
            builder.AppendLine("  \"UnsupportedBrowserBlockingEnabled\": " + ToJsonBool(config.UnsupportedBrowserBlockingEnabled) + ",");
            builder.AppendLine("  \"TamperProtectionEnabled\": " + ToJsonBool(config.TamperProtectionEnabled) + ",");
            builder.AppendLine("  \"YouTubeRestrictEnabled\": " + ToJsonBool(config.YouTubeRestrictEnabled) + ",");
            builder.AppendLine("  \"AdultHostsFollowArea\": " + ToJsonBool(config.AdultHostsFollowArea) + ",");
            builder.AppendLine("  \"SiteRedditEnabled\": " + ToJsonBool(config.SiteRedditEnabled) + ",");
            builder.AppendLine("  \"SiteXEnabled\": " + ToJsonBool(config.SiteXEnabled) + ",");
            builder.AppendLine("  \"SiteBlueskyEnabled\": " + ToJsonBool(config.SiteBlueskyEnabled) + ",");
            builder.AppendLine("  \"SiteTumblrEnabled\": " + ToJsonBool(config.SiteTumblrEnabled) + ",");
            builder.AppendLine("  \"SiteDeviantArtEnabled\": " + ToJsonBool(config.SiteDeviantArtEnabled) + ",");
            builder.AppendLine("  \"SitePixivEnabled\": " + ToJsonBool(config.SitePixivEnabled) + ",");
            builder.AppendLine("  \"SiteNewgroundsEnabled\": " + ToJsonBool(config.SiteNewgroundsEnabled) + ",");
            builder.AppendLine("  \"SiteImgurEnabled\": " + ToJsonBool(config.SiteImgurEnabled) + ",");
            builder.AppendLine("  \"SiteInstagramEnabled\": " + ToJsonBool(config.SiteInstagramEnabled) + ",");
            builder.AppendLine("  \"SiteTikTokEnabled\": " + ToJsonBool(config.SiteTikTokEnabled) + ",");
            builder.AppendLine("  \"SitePinterestEnabled\": " + ToJsonBool(config.SitePinterestEnabled) + ",");
            builder.AppendLine("  \"AdultContentProtectionEnabled\": " + ToJsonBool(config.AdultContentProtectionEnabled) + ",");
            builder.AppendLine("  \"AdultContentProtectionMode\": \"" + EscapeJson(NormalizeProtectionAreaMode(config.AdultContentProtectionMode, "strict")) + "\",");
            builder.AppendLine("  \"GamblingProtectionEnabled\": " + ToJsonBool(config.GamblingProtectionEnabled) + ",");
            builder.AppendLine("  \"GamblingProtectionMode\": \"" + EscapeJson(config.GamblingProtectionMode) + "\",");
            builder.AppendLine("  \"ShoppingProtectionEnabled\": " + ToJsonBool(config.ShoppingProtectionEnabled) + ",");
            builder.AppendLine("  \"ShoppingProtectionMode\": \"" + EscapeJson(NormalizeProtectionAreaMode(config.ShoppingProtectionMode, "planned")) + "\",");
            builder.AppendLine("  \"ShoppingDelayDefaultMinutes\": " + NormalizeGamblingDelayMinutes(config.ShoppingDelayDefaultMinutes) + ",");
            builder.AppendLine("  \"ShoppingCheckoutDelayEnabled\": " + ToJsonBool(config.ShoppingCheckoutDelayEnabled) + ",");
            builder.AppendLine("  \"ShoppingStimulusDampingEnabled\": " + ToJsonBool(config.ShoppingStimulusDampingEnabled) + ",");
            builder.AppendLine("  \"ShoppingDealSearchBlockEnabled\": " + ToJsonBool(config.ShoppingDealSearchBlockEnabled) + ",");
            builder.AppendLine("  \"ShoppingCurfewEnabled\": " + ToJsonBool(config.ShoppingCurfewEnabled) + ",");
            builder.AppendLine("  \"ShoppingCurfewStart\": \"" + EscapeJson(NormalizeTimeText(config.ShoppingCurfewStart, "22:00")) + "\",");
            builder.AppendLine("  \"ShoppingCurfewEnd\": \"" + EscapeJson(NormalizeTimeText(config.ShoppingCurfewEnd, "06:00")) + "\",");
            builder.AppendLine("  \"ShoppingDailyLimitEnabled\": " + ToJsonBool(config.ShoppingDailyLimitEnabled) + ",");
            builder.AppendLine("  \"ShoppingDailyLimitMinutes\": " + NormalizeDailyLimitMinutes(config.ShoppingDailyLimitMinutes, 30) + ",");
            builder.AppendLine("  \"ShoppingMonthlyOrderLimitEnabled\": " + ToJsonBool(config.ShoppingMonthlyOrderLimitEnabled) + ",");
            builder.AppendLine("  \"ShoppingMonthlyOrderLimit\": " + NormalizeMonthlyOrderLimit(config.ShoppingMonthlyOrderLimit) + ",");
            builder.AppendLine("  \"ShoppingMonthlyBudgetEnabled\": " + ToJsonBool(config.ShoppingMonthlyBudgetEnabled) + ",");
            builder.AppendLine("  \"ShoppingMonthlyBudgetEuro\": " + NormalizeMonthlyBudgetEuro(config.ShoppingMonthlyBudgetEuro) + ",");
            builder.AppendLine("  \"GamblingDailyLimitEnabled\": " + ToJsonBool(config.GamblingDailyLimitEnabled) + ",");
            builder.AppendLine("  \"GamblingDailyLimitMinutes\": " + NormalizeDailyLimitMinutes(config.GamblingDailyLimitMinutes, 15) + ",");
            builder.AppendLine("  \"SocialMediaDailyBudgetEnabled\": " + ToJsonBool(config.SocialMediaDailyBudgetEnabled) + ",");
            builder.AppendLine("  \"SocialMediaDailyBudgetMinutes\": " + NormalizeSocialMediaBudgetMinutes(config.SocialMediaDailyBudgetMinutes) + ",");
            builder.AppendLine("  \"SocialMediaPlatformLimits\": \"" + EscapeJson(NormalizeSocialMediaPlatformLimits(config.SocialMediaPlatformLimits, config.SocialMediaDailyBudgetEnabled, config.SocialMediaDailyBudgetMinutes)) + "\",");
            builder.AppendLine("  \"SocialMediaBlockedPlatforms\": \"" + EscapeJson(NormalizeSocialMediaBlockedPlatforms(config.SocialMediaBlockedPlatforms)) + "\",");
            builder.AppendLine("  \"SocialMediaFeedBlockedPlatforms\": \"" + EscapeJson(NormalizeSocialMediaFeedBlockedPlatforms(config.SocialMediaFeedBlockedPlatforms, config.SocialMediaBlockedPlatforms)) + "\",");
            builder.AppendLine("  \"SocialMediaCurfewEnabled\": " + ToJsonBool(config.SocialMediaCurfewEnabled) + ",");
            builder.AppendLine("  \"SocialMediaCurfewStart\": \"" + EscapeJson(NormalizeTimeText(config.SocialMediaCurfewStart, "22:00")) + "\",");
            builder.AppendLine("  \"SocialMediaCurfewEnd\": \"" + EscapeJson(NormalizeTimeText(config.SocialMediaCurfewEnd, "06:00")) + "\",");
            builder.AppendLine("  \"SocialMediaReflectionEnabled\": " + ToJsonBool(config.SocialMediaReflectionEnabled) + ",");
            builder.AppendLine("  \"SocialMediaFeedDampingEnabled\": " + ToJsonBool(config.SocialMediaFeedDampingEnabled) + ",");
            builder.AppendLine("  \"SocialMediaFeedDampingScrolls\": " + NormalizeSocialMediaFeedDampingScrolls(config.SocialMediaFeedDampingScrolls) + ",");
            builder.AppendLine("  \"VideoGamesProtectionEnabled\": " + ToJsonBool(config.VideoGamesProtectionEnabled) + ",");
            builder.AppendLine("  \"VideoGamesProtectionMode\": \"" + EscapeJson(NormalizeProtectionAreaMode(config.VideoGamesProtectionMode, "planned")) + "\",");
            builder.AppendLine("  \"VideoGamesDailyLimitEnabled\": " + ToJsonBool(config.VideoGamesDailyLimitEnabled) + ",");
            builder.AppendLine("  \"VideoGamesDailyLimitMinutes\": " + NormalizeVideoGamesDailyLimitMinutes(config.VideoGamesDailyLimitMinutes) + ",");
            builder.AppendLine("  \"VideoGamesCurfewEnabled\": " + ToJsonBool(config.VideoGamesCurfewEnabled) + ",");
            builder.AppendLine("  \"VideoGamesCurfewStart\": \"" + EscapeJson(NormalizeTimeText(config.VideoGamesCurfewStart, "22:00")) + "\",");
            builder.AppendLine("  \"VideoGamesCurfewEnd\": \"" + EscapeJson(NormalizeTimeText(config.VideoGamesCurfewEnd, "06:00")) + "\",");
            builder.AppendLine("  \"VideoGamesAutoDetectEnabled\": " + ToJsonBool(config.VideoGamesAutoDetectEnabled) + ",");
            builder.AppendLine("  \"VideoGamesHeuristicEnabled\": " + ToJsonBool(config.VideoGamesHeuristicEnabled) + ",");
            builder.AppendLine("  \"SocialMediaProtectionEnabled\": " + ToJsonBool(config.SocialMediaProtectionEnabled) + ",");
            builder.AppendLine("  \"SocialMediaProtectionMode\": \"" + EscapeJson(NormalizeProtectionAreaMode(config.SocialMediaProtectionMode, "planned")) + "\",");
            builder.AppendLine("  \"ProtectionAreaRulePackVersion\": \"" + EscapeJson(string.IsNullOrWhiteSpace(config.ProtectionAreaRulePackVersion) ? "1" : config.ProtectionAreaRulePackVersion.Trim()) + "\",");
            builder.AppendLine("  \"GamblingSupportEnabled\": " + ToJsonBool(config.GamblingSupportEnabled) + ",");
            builder.AppendLine("  \"GamblingSupportMode\": \"" + EscapeJson(NormalizeImpulseAreaMode(config.GamblingSupportMode, config.GamblingSupportEnabled ? "gentle" : "off")) + "\",");
            builder.AppendLine("  \"LockdownModeEnabled\": " + ToJsonBool(config.LockdownModeEnabled) + ",");
            builder.AppendLine("  \"PauseCooldownEnabled\": " + ToJsonBool(config.PauseCooldownEnabled) + ",");
            builder.AppendLine("  \"ScheduleEnabled\": " + ToJsonBool(config.ScheduleEnabled) + ",");
            builder.AppendLine("  \"StrictModeEnabled\": " + ToJsonBool(config.StrictModeEnabled) + ",");
            builder.AppendLine("  \"ScheduleStart\": \"" + EscapeJson(NormalizeTimeText(config.ScheduleStart, "22:00")) + "\",");
            builder.AppendLine("  \"ScheduleEnd\": \"" + EscapeJson(NormalizeTimeText(config.ScheduleEnd, "06:00")) + "\",");
            builder.AppendLine("  \"PauseUntilUtc\": \"" + EscapeJson(config.PauseUntilUtc) + "\",");
            builder.AppendLine("  \"PendingPauseUntilUtc\": \"" + EscapeJson(config.PendingPauseUntilUtc) + "\",");
            builder.AppendLine("  \"PendingUninstallUntilUtc\": \"" + EscapeJson(config.PendingUninstallUntilUtc) + "\",");
            builder.AppendLine("  \"UninstallApprovalExpiresUtc\": \"" + EscapeJson(config.UninstallApprovalExpiresUtc) + "\",");
            builder.AppendLine("  \"PasswordHint\": \"" + EscapeJson(CleanPasswordHint(config.PasswordHint)) + "\",");
            builder.AppendLine("  \"PasswordFailedAttempts\": " + Math.Max(0, config.PasswordFailedAttempts) + ",");
            builder.AppendLine("  \"PasswordLockoutUntilUtc\": \"" + EscapeJson(config.PasswordLockoutUntilUtc) + "\",");
            builder.AppendLine("  \"InstalledVersion\": \"" + EscapeJson(config.InstalledVersion) + "\",");
            builder.AppendLine("  \"WeakeningRequestedUtc\": \"" + EscapeJson(config.WeakeningRequestedUtc) + "\",");
            builder.AppendLine("  \"AuthorityMode\": \"" + EscapeJson(NormalizeAuthorityMode(config.AuthorityMode)) + "\",");
            builder.AppendLine("  \"PolicyVersion\": " + Math.Max(0, config.PolicyVersion).ToString(System.Globalization.CultureInfo.InvariantCulture) + ",");
            builder.AppendLine("  \"WeakeningGrant\": \"" + EscapeJson(config.WeakeningGrant) + "\",");
            builder.AppendLine("  \"GrantSignature\": \"" + EscapeJson(config.GrantSignature) + "\",");
            builder.AppendLine("  \"EntitledUntilUtc\": \"" + EscapeJson(config.EntitledUntilUtc) + "\",");
            builder.AppendLine("  \"EntitlementSignature\": \"" + EscapeJson(config.EntitlementSignature) + "\",");
            builder.AppendLine("  \"EntitlementMaxDevices\": " + config.EntitlementMaxDevices.ToString(System.Globalization.CultureInfo.InvariantCulture) + ",");
            builder.AppendLine("  \"CompanionGrace\": \"" + EscapeJson(config.CompanionGrace) + "\",");
            builder.AppendLine("  \"ClockAnchorUtc\": \"" + EscapeJson(config.ClockAnchorUtc) + "\",");
            builder.AppendLine("  \"ClockTickAnchorMs\": " + config.ClockTickAnchorMs.ToString(System.Globalization.CultureInfo.InvariantCulture) + ",");
            builder.AppendLine("  \"IntegritySchemaVersion\": " + config.IntegritySchemaVersion + ",");
            byte[] integrityKey = LoadOrCreateIntegrityKey();
            string integrity = ComputeConfigIntegrity(config, integrityKey);
            builder.AppendLine("  \"Integrity\": \"" + EscapeJson(integrity) + "\",");
            builder.AppendLine("  \"Password\": {");
            builder.AppendLine("    \"Algorithm\": \"" + EscapeJson(config.Password.Algorithm) + "\",");
            builder.AppendLine("    \"Iterations\": " + config.Password.Iterations + ",");
            builder.AppendLine("    \"Salt\": \"" + EscapeJson(config.Password.Salt) + "\",");
            builder.AppendLine("    \"Hash\": \"" + EscapeJson(config.Password.Hash) + "\"");
            builder.AppendLine("  }");
            builder.AppendLine("}");
            WriteConfigTextAtomic(builder.ToString());
            WriteCompanionRuleState(config);
        }

        // config.json is ACL-hardened to Administrators+SYSTEM (0.61.47), but
        // Chrome starts the native host under the plain user account, so the
        // host silently fell back to area defaults ("shopping off") no matter
        // what was configured. This mirror carries ONLY the non-sensitive
        // fields the browser rule pack needs (area modes, shopping friction
        // settings, per-site switches) into a world-readable file the host can
        // read and watch. Never passwords, HMAC, timers, or support data.
        public static string CompanionRuleStatePath
        {
            get { return Path.Combine(DataDir, "public", "companion-rule-state.json"); }
        }

        public static void WriteCompanionRuleState(AppConfig config)
        {
            try
            {
                WriteCompanionRuleState(config, CompanionRuleStatePath, true);
            }
            catch (Exception ex)
            {
                // Best effort: a failed mirror write must never block a config
                // save; the host then keeps its safe defaults.
                //
                // CFG-003: Der catch darf bleiben, aber nicht lautlos. Schlaegt
                // der Spiegel fehl, arbeitet der Browser ab dem naechsten Start
                // mit veralteten oder Vorgabe-Regeln - ohne diese Zeile gab es
                // dafuer keine einzige Spur.
                try
                {
                    WriteSecurityLog("Companion rule mirror could not be written: " + ex.Message);
                }
                catch
                {
                }
            }
        }

        internal static void WriteCompanionRuleState(AppConfig config, string path, bool applyAcl)
        {
            if (config == null)
            {
                config = new AppConfig();
            }

            string directory = Path.GetDirectoryName(Path.GetFullPath(path));
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
                if (applyAcl)
                {
                    GrantUsersReadAccess(directory);
                }
            }

            StringBuilder builder = new StringBuilder();
            builder.AppendLine("{");
            builder.AppendLine("  \"AdultContentProtectionEnabled\": " + ToJsonBool(config.AdultContentProtectionEnabled) + ",");
            builder.AppendLine("  \"GamblingProtectionEnabled\": " + ToJsonBool(EffectiveGamblingProtectionEnabled(config)) + ",");
            builder.AppendLine("  \"GamblingSupportEnabled\": " + ToJsonBool(config.GamblingSupportEnabled) + ",");
            builder.AppendLine("  \"ShoppingProtectionEnabled\": " + ToJsonBool(config.ShoppingProtectionEnabled) + ",");
            builder.AppendLine("  \"ShoppingCheckoutDelayEnabled\": " + ToJsonBool(config.ShoppingCheckoutDelayEnabled) + ",");
            builder.AppendLine("  \"ShoppingStimulusDampingEnabled\": " + ToJsonBool(config.ShoppingStimulusDampingEnabled) + ",");
            builder.AppendLine("  \"ShoppingDealSearchBlockEnabled\": " + ToJsonBool(config.ShoppingDealSearchBlockEnabled) + ",");
            builder.AppendLine("  \"ShoppingCurfewEnabled\": " + ToJsonBool(config.ShoppingCurfewEnabled) + ",");
            builder.AppendLine("  \"ShoppingCurfewStart\": \"" + EscapeJson(NormalizeTimeText(config.ShoppingCurfewStart, "22:00")) + "\",");
            builder.AppendLine("  \"ShoppingCurfewEnd\": \"" + EscapeJson(NormalizeTimeText(config.ShoppingCurfewEnd, "06:00")) + "\",");
            builder.AppendLine("  \"ShoppingDelayDefaultMinutes\": " + NormalizeGamblingDelayMinutes(config.ShoppingDelayDefaultMinutes) + ",");
            builder.AppendLine("  \"ShoppingDailyLimitEnabled\": " + ToJsonBool(config.ShoppingDailyLimitEnabled) + ",");
            builder.AppendLine("  \"ShoppingDailyLimitMinutes\": " + NormalizeDailyLimitMinutes(config.ShoppingDailyLimitMinutes, 30) + ",");
            builder.AppendLine("  \"ShoppingMonthlyOrderLimitEnabled\": " + ToJsonBool(config.ShoppingMonthlyOrderLimitEnabled) + ",");
            builder.AppendLine("  \"ShoppingMonthlyOrderLimit\": " + NormalizeMonthlyOrderLimit(config.ShoppingMonthlyOrderLimit) + ",");
            builder.AppendLine("  \"ShoppingMonthlyBudgetEnabled\": " + ToJsonBool(config.ShoppingMonthlyBudgetEnabled) + ",");
            builder.AppendLine("  \"ShoppingMonthlyBudgetEuro\": " + NormalizeMonthlyBudgetEuro(config.ShoppingMonthlyBudgetEuro) + ",");
            builder.AppendLine("  \"GamblingDailyLimitEnabled\": " + ToJsonBool(config.GamblingDailyLimitEnabled) + ",");
            builder.AppendLine("  \"GamblingDailyLimitMinutes\": " + NormalizeDailyLimitMinutes(config.GamblingDailyLimitMinutes, 15) + ",");
            builder.AppendLine("  \"SocialMediaProtectionEnabled\": " + ToJsonBool(config.SocialMediaProtectionEnabled) + ",");
            builder.AppendLine("  \"SocialMediaDailyBudgetEnabled\": " + ToJsonBool(config.SocialMediaDailyBudgetEnabled) + ",");
            builder.AppendLine("  \"SocialMediaDailyBudgetMinutes\": " + NormalizeSocialMediaBudgetMinutes(config.SocialMediaDailyBudgetMinutes) + ",");
            builder.AppendLine("  \"SocialMediaPlatformLimits\": \"" + EscapeJson(NormalizeSocialMediaPlatformLimits(config.SocialMediaPlatformLimits, config.SocialMediaDailyBudgetEnabled, config.SocialMediaDailyBudgetMinutes)) + "\",");
            builder.AppendLine("  \"SocialMediaBlockedPlatforms\": \"" + EscapeJson(NormalizeSocialMediaBlockedPlatforms(config.SocialMediaBlockedPlatforms)) + "\",");
            builder.AppendLine("  \"SocialMediaFeedBlockedPlatforms\": \"" + EscapeJson(NormalizeSocialMediaFeedBlockedPlatforms(config.SocialMediaFeedBlockedPlatforms, config.SocialMediaBlockedPlatforms)) + "\",");
            builder.AppendLine("  \"SocialMediaCurfewEnabled\": " + ToJsonBool(config.SocialMediaCurfewEnabled) + ",");
            builder.AppendLine("  \"SocialMediaCurfewStart\": \"" + EscapeJson(NormalizeTimeText(config.SocialMediaCurfewStart, "22:00")) + "\",");
            builder.AppendLine("  \"SocialMediaCurfewEnd\": \"" + EscapeJson(NormalizeTimeText(config.SocialMediaCurfewEnd, "06:00")) + "\",");
            builder.AppendLine("  \"SocialMediaReflectionEnabled\": " + ToJsonBool(config.SocialMediaReflectionEnabled) + ",");
            builder.AppendLine("  \"SocialMediaFeedDampingEnabled\": " + ToJsonBool(config.SocialMediaFeedDampingEnabled) + ",");
            builder.AppendLine("  \"SocialMediaFeedDampingScrolls\": " + NormalizeSocialMediaFeedDampingScrolls(config.SocialMediaFeedDampingScrolls) + ",");
            builder.AppendLine("  \"SiteRedditEnabled\": " + ToJsonBool(config.SiteRedditEnabled) + ",");
            builder.AppendLine("  \"SiteXEnabled\": " + ToJsonBool(config.SiteXEnabled) + ",");
            builder.AppendLine("  \"SiteBlueskyEnabled\": " + ToJsonBool(config.SiteBlueskyEnabled) + ",");
            builder.AppendLine("  \"SiteTumblrEnabled\": " + ToJsonBool(config.SiteTumblrEnabled) + ",");
            builder.AppendLine("  \"SiteDeviantArtEnabled\": " + ToJsonBool(config.SiteDeviantArtEnabled) + ",");
            builder.AppendLine("  \"SitePixivEnabled\": " + ToJsonBool(config.SitePixivEnabled) + ",");
            builder.AppendLine("  \"SiteNewgroundsEnabled\": " + ToJsonBool(config.SiteNewgroundsEnabled) + ",");
            builder.AppendLine("  \"SiteImgurEnabled\": " + ToJsonBool(config.SiteImgurEnabled) + ",");
            builder.AppendLine("  \"SiteInstagramEnabled\": " + ToJsonBool(config.SiteInstagramEnabled) + ",");
            builder.AppendLine("  \"SiteTikTokEnabled\": " + ToJsonBool(config.SiteTikTokEnabled) + ",");
            builder.AppendLine("  \"SitePinterestEnabled\": " + ToJsonBool(config.SitePinterestEnabled) + ",");
            // Der Native Host laeuft im Nutzerkonto und kann config.json nicht
            // lesen (NHR-001). Ohne diesen Spiegel misst er die Freigabefristen
            // an der rohen Systemuhr (CLK-004). Der Anker ist ein blosser
            // Zeitstempel - keine Frist, kein Geheimnis, und damit anders als
            // die Werte, die hier ausdruecklich nicht stehen duerfen.
            builder.AppendLine("  \"ClockAnchorUtc\": \"" + EscapeJson(TrustedUtcNow(config).ToString("o")) + "\"");
            builder.AppendLine("}");

            // CFG-003: Dieser Spiegel ist die EINZIGE Quelle, aus der der
            // unprivilegierte Native Host die Bereichs- und Seitenschalter
            // liest - config.json ist fuer ihn per ACL unlesbar. Ein
            // abgebrochener Schreibvorgang (Stromausfall, voller Datentraeger)
            // hinterliess hier eine halbe Datei, und der Host faellt darauf auf
            // seine Vorgabewerte zurueck. Temp + Replace wie bei config.json.
            string tempPath = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                WriteAllTextDurable(tempPath, builder.ToString());
                if (File.Exists(path))
                {
                    File.Replace(tempPath, path, null, true);
                }
                else
                {
                    File.Move(tempPath, path);
                }
            }
            catch
            {
                try
                {
                    if (File.Exists(tempPath))
                    {
                        File.Delete(tempPath);
                    }
                }
                catch
                {
                }

                throw;
            }
        }

        private static void GrantUsersReadAccess(string directory)
        {
            try
            {
                System.Security.AccessControl.DirectorySecurity security = System.IO.Directory.GetAccessControl(directory);
                security.AddAccessRule(new System.Security.AccessControl.FileSystemAccessRule(
                    new System.Security.Principal.SecurityIdentifier(System.Security.Principal.WellKnownSidType.BuiltinUsersSid, null),
                    System.Security.AccessControl.FileSystemRights.ReadAndExecute | System.Security.AccessControl.FileSystemRights.ListDirectory,
                    System.Security.AccessControl.InheritanceFlags.ContainerInherit | System.Security.AccessControl.InheritanceFlags.ObjectInherit,
                    System.Security.AccessControl.PropagationFlags.None,
                    System.Security.AccessControl.AccessControlType.Allow));
                System.IO.Directory.SetAccessControl(directory, security);
            }
            catch
            {
                // Without the ACL grant the host simply keeps safe defaults;
                // never fail the save over it.
            }
        }

        private static void WithConfigLock(Action action)
        {
            WithConfigLock(delegate
            {
                action();
                return 0;
            });
        }

        private static T WithConfigLock<T>(Func<T> action)
        {
            using (Mutex mutex = CreateConfigMutex())
            {
                bool locked = false;
                try
                {
                    try
                    {
                        locked = mutex.WaitOne(TimeSpan.FromSeconds(10));
                    }
                    catch (AbandonedMutexException)
                    {
                        locked = true;
                    }

                    if (!locked)
                    {
                        throw new TimeoutException("Die Purestate-Konfiguration ist gerade durch einen anderen Vorgang gesperrt.");
                    }

                    return action();
                }
                finally
                {
                    if (locked)
                    {
                        mutex.ReleaseMutex();
                    }
                }
            }
        }

        private static Mutex CreateConfigMutex()
        {
            bool createdNew;
            try
            {
                return new Mutex(false, ConfigMutexName, out createdNew, BuildConfigMutexSecurity());
            }
            catch (UnauthorizedAccessException)
            {
                return Mutex.OpenExisting(ConfigMutexName, MutexRights.Synchronize | MutexRights.Modify);
            }
        }

        private static MutexSecurity BuildConfigMutexSecurity()
        {
            MutexSecurity security = new MutexSecurity();
            security.AddAccessRule(new MutexAccessRule(
                new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null),
                MutexRights.FullControl,
                AccessControlType.Allow));
            security.AddAccessRule(new MutexAccessRule(
                new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null),
                MutexRights.FullControl,
                AccessControlType.Allow));
            return security;
        }

        private static void WriteConfigTextAtomic(string text)
        {
            string tempPath = ConfigPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                // Erst die Zwischendatei auf die Platte zwingen, dann
                // umbenennen: ein Replace auf eine nur im Cache stehende Datei
                // taeuscht Haltbarkeit vor, die ein Stromausfall widerlegt.
                WriteAllTextDurable(tempPath, text);
                if (File.Exists(ConfigPath))
                {
                    File.Replace(tempPath, ConfigPath, null, true);
                }
                else
                {
                    File.Move(tempPath, ConfigPath);
                }
            }
            catch
            {
                try
                {
                    if (File.Exists(tempPath))
                    {
                        File.Delete(tempPath);
                    }
                }
                catch
                {
                }

                throw;
            }
        }

        public static void SetProtectionEnabled(bool enabled)
        {
            UpdateConfig(delegate (AppConfig config)
            {
                if (config.Password == null)
                {
                    throw new InvalidOperationException("Es ist noch kein Passwort eingerichtet.");
                }

                config.ProtectionEnabled = enabled;
                if (enabled)
                {
                    config.PauseUntilUtc = string.Empty;
                    config.PendingPauseUntilUtc = string.Empty;
                }
            });
        }

        public static void SetProtectionPaused(int minutes)
        {
            UpdateConfig(delegate (AppConfig config)
            {
                if (config.Password == null)
                {
                    throw new InvalidOperationException("Es ist noch kein Passwort eingerichtet.");
                }

                DateTime nowUtc = TrustedUtcNow(config);
                DateTime nextReadyAt;
                switch (DecidePause(config, nowUtc, DevUnlockActive, out nextReadyAt))
                {
                    case PauseRejectedStrictSchedule:
                        throw new InvalidOperationException("Der strenge Zeitplan ist gerade aktiv. Pausieren ist in dieser Zeit nicht erlaubt.");
                    case PauseRejectedLockdown:
                        throw new InvalidOperationException("Der Sperrmodus ist aktiv. Pausieren ist im vorgesehenen Schutzmodus nicht erlaubt.");
                    case PauseCooldownStarted:
                        config.PendingPauseUntilUtc = nextReadyAt.ToString("o");
                        SaveConfigUnlocked(config);
                        throw new PauseCooldownStartedException(nextReadyAt);
                }

                config.ProtectionEnabled = false;
                config.PauseUntilUtc = minutes > 0
                    ? nowUtc.AddMinutes(minutes).ToString("o")
                    : string.Empty;
                config.PendingPauseUntilUtc = string.Empty;
            });
        }

        // DESK-03: Die Pausenregel hat drei echte Zustaende, gespeichert in
        // zwei Flags. Die Wartezeit wirkt nur zusammen mit dem Sperrmodus.
        public const int PauseModeImmediate = 0;
        public const int PauseModeAfterCooldown = 1;
        public const int PauseModeForbidden = 2;

        public static int PauseModeFromFlags(bool lockdownModeEnabled, bool pauseCooldownEnabled)
        {
            if (!lockdownModeEnabled)
            {
                return PauseModeImmediate;
            }
            return pauseCooldownEnabled ? PauseModeAfterCooldown : PauseModeForbidden;
        }

        // Bleibt die Auswahl beim gespeicherten Modus, bleiben beide Flags
        // unveraendert - sonst meldete das Abschwaechungs-Gate eine Aenderung,
        // die niemand gemacht hat (etwa Wartezeit an -> aus bei "sofort").
        public static void PauseFlagsForMode(int mode, bool storedLockdown, bool storedCooldown, out bool lockdownModeEnabled, out bool pauseCooldownEnabled)
        {
            lockdownModeEnabled = storedLockdown;
            pauseCooldownEnabled = storedCooldown;
            if (mode == PauseModeFromFlags(storedLockdown, storedCooldown))
            {
                return;
            }
            lockdownModeEnabled = mode != PauseModeImmediate;
            if (mode != PauseModeImmediate)
            {
                pauseCooldownEnabled = mode == PauseModeAfterCooldown;
            }
        }

        public const int PauseAllowed = 0;
        public const int PauseRejectedStrictSchedule = 1;
        public const int PauseRejectedLockdown = 2;
        public const int PauseCooldownStarted = 3;

        // Reine Entscheidung von SetProtectionPaused, ohne Schreiben. nowUtc ist
        // die vertrauenswuerdige Uhr (TrustedUtcNow) - daraus leiten sich
        // Zeitplan und "Schutz soll aktiv sein" genauso ab wie zuvor.
        // Eine noch laufende Wartezeit startet erneut (unveraendertes Verhalten).
        internal static int DecidePause(AppConfig config, DateTime nowUtc, bool devUnlockActive, out DateTime readyAtUtc)
        {
            readyAtUtc = DateTime.MinValue;
            bool scheduleActive = IsScheduleActiveAt(config, nowUtc.ToLocalTime());
            if (config.StrictModeEnabled && scheduleActive && !devUnlockActive)
            {
                return PauseRejectedStrictSchedule;
            }

            if (config.LockdownModeEnabled && (config.ProtectionEnabled || scheduleActive) && !devUnlockActive)
            {
                if (!config.PauseCooldownEnabled)
                {
                    return PauseRejectedLockdown;
                }

                DateTime pendingUntil;
                if (!TryReadPendingPauseUntil(config, out pendingUntil) || pendingUntil > nowUtc)
                {
                    readyAtUtc = nowUtc.AddMinutes(10);
                    return PauseCooldownStarted;
                }
            }

            return PauseAllowed;
        }

        public static DateTime BeginUninstallCooldown()
        {
            return WithConfigLock(delegate
            {
                AppConfig config = LoadConfig();
                if (config.Password == null)
                {
                    throw new InvalidOperationException("Es ist noch kein Passwort eingerichtet.");
                }

                int remainingSeconds;
                // MonotonicUtcNow und nicht TrustedUtcNow: der Ausstieg darf
                // nie einfrieren, sonst verhindert ein gestoppter Guard das
                // Entfernen dauerhaft.
                int state = EvaluateUninstallCooldown(config, MonotonicUtcNow(), out remainingSeconds);
                DateTime existingReadyAt;
                if ((state == 1 || state == 2) && TryReadUtc(config.PendingUninstallUntilUtc, out existingReadyAt))
                {
                    return existingReadyAt;
                }

                // Zustand 2 ohne gespeicherten Termin heisst: die Fassung ist
                // abgelaufen, die Wartefrist entfaellt. Ohne diese Zeile fiele
                // der Fall durch und schriebe eine frische Siebentagesmarke -
                // genau die Frist, die der Ablauf aussetzt. Heute unerreichbar
                // (UninstallForm ruft nur bei Zustand 0), aber gelegt.
                if (state == 2)
                {
                    return MonotonicUtcNow();
                }

                DateTime readyAt = MonotonicUtcNow().AddDays(UninstallWaitDays);
                config.PendingUninstallUntilUtc = readyAt.ToString("o");
                config.UninstallApprovalExpiresUtc = readyAt.AddHours(UninstallApprovalWindowHours).ToString("o");
                SaveConfigUnlocked(config);
                return readyAt;
            });
        }

        public static int GetUninstallCooldownState(out int remainingSeconds)
        {
            remainingSeconds = 0;
            if (DevUnlockActive)
            {
                // 2 = Abkuehlzeit vorbei, Freigabefenster offen.
                return 2;
            }

            int stateRemainingSeconds = 0;
            int state = WithConfigLock(delegate
            {
                AppConfig config = LoadConfig();
                int evaluated = EvaluateUninstallCooldown(config, MonotonicUtcNow(), out stateRemainingSeconds);
                if (evaluated == 0 && (!string.IsNullOrEmpty(config.PendingUninstallUntilUtc) || !string.IsNullOrEmpty(config.UninstallApprovalExpiresUtc)))
                {
                    config.PendingUninstallUntilUtc = string.Empty;
                    config.UninstallApprovalExpiresUtc = string.Empty;
                    SaveConfigUnlocked(config);
                }

                return evaluated;
            });
            remainingSeconds = stateRemainingSeconds;
            return state;
        }

        // Password verification with a persistent, HMAC-protected lockout. All
        // interactive password prompts route through here so the per-dialog
        // "3 tries then close" limit cannot be bypassed by simply reopening the
        // dialog. While locked out the correct password is not even hashed.
        public static PasswordCheckResult VerifyPasswordThrottled(string password, out int lockoutRemainingSeconds)
        {
            lockoutRemainingSeconds = 0;
            if (DevUnlockActive)
            {
                return PasswordCheckResult.Success;
            }

            AppConfig config = LoadConfig();
            if (config.IntegrityCompromised)
            {
                // Untrusted config: refuse without touching disk (writing the
                // attempt counter would hit the save guard and throw).
                WriteSecurityLog("Password attempt refused: config integrity compromised.");
                return PasswordCheckResult.WrongPassword;
            }

            if (config.Password == null)
            {
                return PasswordCheckResult.WrongPassword;
            }

            DateTime now = TrustedUtcNow(config);
            DateTime lockoutUntil;
            if (TryReadUtc(config.PasswordLockoutUntilUtc, out lockoutUntil) && lockoutUntil > now)
            {
                lockoutRemainingSeconds = (int)Math.Ceiling((lockoutUntil - now).TotalSeconds);
                WriteSecurityLog("Password attempt refused: locked out for " + lockoutRemainingSeconds + "s.");
                return PasswordCheckResult.LockedOut;
            }

            if (VerifyPassword(password))
            {
                if (config.PasswordFailedAttempts != 0 || !string.IsNullOrEmpty(config.PasswordLockoutUntilUtc))
                {
                    UpdateConfig(delegate (AppConfig c)
                    {
                        c.PasswordFailedAttempts = 0;
                        c.PasswordLockoutUntilUtc = string.Empty;
                    });
                }
                return PasswordCheckResult.Success;
            }

            int remaining = 0;
            UpdateConfig(delegate (AppConfig c)
            {
                c.PasswordFailedAttempts = Math.Max(0, c.PasswordFailedAttempts) + 1;
                int lockoutSeconds = ComputePasswordLockoutSeconds(c.PasswordFailedAttempts);
                if (lockoutSeconds > 0)
                {
                    c.PasswordLockoutUntilUtc = TrustedUtcNow(c).AddSeconds(lockoutSeconds).ToString("o");
                    remaining = lockoutSeconds;
                }
                else
                {
                    c.PasswordLockoutUntilUtc = string.Empty;
                }
            });

            lockoutRemainingSeconds = remaining;
            return PasswordCheckResult.WrongPassword;
        }

        public static void SetPassword(string password)
        {
            UpdateConfig(delegate (AppConfig config)
            {
                EnsurePasswordPolicy(password, config.PasswordHint);
                config.Password = NewPasswordRecord(password);
                config.PendingUninstallUntilUtc = string.Empty;
                config.UninstallApprovalExpiresUtc = string.Empty;
            });
        }

        public static void SetPassword(string password, string hint)
        {
            UpdateConfig(delegate (AppConfig config)
            {
                EnsurePasswordPolicy(password, hint);
                config.Password = NewPasswordRecord(password);
                config.PasswordHint = CleanPasswordHint(hint);
                config.PendingUninstallUntilUtc = string.Empty;
                config.UninstallApprovalExpiresUtc = string.Empty;
            });
        }


        // TGT-004: Hier standen SIEBEN oeffentliche Setter, die bis auf
        // UpdateConfig statt UpdateConfigWithWeakeningGate mit ihren
        // Guarded-Zwillingen identisch waren - sie schrieben also am
        // Abschwaechungsfenster vorbei. KEINER hatte im ganzen Repository einen
        // Aufrufer; die Dialoge nutzen ausschliesslich die Guarded-Fassungen
        // (teils unter anderem Namen, etwa SetGamblingSettingsGuarded).
        //
        // Der Befund nennt nur den Videospiel-Fall. Nachgezaehlt waren es
        // sieben. Kein aktiver Fehler, aber sieben geladene Waffen: die
        // naechste Oberflaeche haette zwei gleich aussehende Methoden
        // vorgefunden, von denen eine am Gate vorbeischreibt. Genau so
        // entstehen die Befunde aus 04-root-cause-weakening-gate.md. Ein Test
        // in tests\Purestate.Tests.ps1 haelt fest, dass keine zurueckkommt.

        public static void SetFeatureSettingsGuarded(bool hostsEnabled, bool familyDnsEnabled, string dnsProfile, bool bypassBlockingEnabled, bool unsupportedBrowserBlockingEnabled, bool tamperProtectionEnabled, bool youTubeRestrictEnabled, bool lockdownModeEnabled, bool pauseCooldownEnabled, bool scheduleEnabled, bool strictModeEnabled, string scheduleStart, string scheduleEnd, DateTime localNow, bool devModeActive)
        {
            UpdateConfigWithWeakeningGate(delegate (AppConfig config)
            {
                if (config.Password == null)
                {
                    throw new InvalidOperationException("Es ist noch kein Passwort eingerichtet.");
                }

                config.HostsEnabled = hostsEnabled;
                config.FamilyDnsEnabled = familyDnsEnabled;
                config.DnsProfile = NormalizeDnsProfile(dnsProfile);
                // INS-004: Fest an, seit die Browser-Richtlinien Pflicht sind.
                // Der Parameter, der hier frueher stand, wurde durchgereicht,
                // serialisiert, exportiert - und dann verworfen. Ein Parameter,
                // der eine Faehigkeit vortaeuscht, die es nicht gibt, ist beim
                // naechsten Umbau eine Falle.
                config.BrowserPoliciesEnabled = true;
                config.BypassBlockingEnabled = bypassBlockingEnabled;
                config.UnsupportedBrowserBlockingEnabled = unsupportedBrowserBlockingEnabled;
                config.TamperProtectionEnabled = tamperProtectionEnabled;
                config.YouTubeRestrictEnabled = youTubeRestrictEnabled;
                config.LockdownModeEnabled = lockdownModeEnabled;
                config.PauseCooldownEnabled = pauseCooldownEnabled;
                if (!pauseCooldownEnabled)
                {
                    config.PendingPauseUntilUtc = string.Empty;
                }
                config.ScheduleEnabled = scheduleEnabled;
                config.StrictModeEnabled = strictModeEnabled;
                config.ScheduleStart = NormalizeTimeText(scheduleStart, "22:00");
                config.ScheduleEnd = NormalizeTimeText(scheduleEnd, "06:00");
            }, localNow, devModeActive);
        }


        public static void SetSiteProtectionSettingsGuarded(bool adultEnabled, bool redditEnabled, bool xEnabled, bool blueskyEnabled, bool tumblrEnabled, bool deviantArtEnabled, bool pixivEnabled, bool newgroundsEnabled, bool imgurEnabled, bool instagramEnabled, bool tikTokEnabled, bool pinterestEnabled, DateTime localNow, bool devModeActive)
        {
            UpdateConfigWithWeakeningGate(delegate (AppConfig config)
            {
                if (config.Password == null)
                {
                    throw new InvalidOperationException("Es ist noch kein Passwort eingerichtet.");
                }

                config.AdultContentProtectionEnabled = adultEnabled;
                config.AdultContentProtectionMode = adultEnabled ? "strict" : "off";
                config.SiteRedditEnabled = redditEnabled;
                config.SiteXEnabled = xEnabled;
                config.SiteBlueskyEnabled = blueskyEnabled;
                config.SiteTumblrEnabled = tumblrEnabled;
                config.SiteDeviantArtEnabled = deviantArtEnabled;
                config.SitePixivEnabled = pixivEnabled;
                config.SiteNewgroundsEnabled = newgroundsEnabled;
                config.SiteImgurEnabled = imgurEnabled;
                config.SiteInstagramEnabled = instagramEnabled;
                config.SiteTikTokEnabled = tikTokEnabled;
                config.SitePinterestEnabled = pinterestEnabled;
            }, localNow, devModeActive);
        }


        public static void SetGamblingSettingsGuarded(bool enabled, bool dailyLimitEnabled, int dailyLimitMinutes, DateTime localNow, bool devModeActive)
        {
            UpdateConfigWithWeakeningGate(delegate (AppConfig config)
            {
                config.GamblingProtectionEnabled = enabled;
                config.GamblingProtectionMode = enabled ? "strict" : "off";
                config.GamblingSupportEnabled = enabled;
                config.GamblingSupportMode = enabled ? "strict" : "off";
                config.GamblingDailyLimitEnabled = dailyLimitEnabled;
                config.GamblingDailyLimitMinutes = NormalizeDailyLimitMinutes(dailyLimitMinutes, 15);
            }, localNow, devModeActive);
        }

        public static int NormalizeDailyLimitMinutes(int minutes, int fallback)
        {
            return (minutes >= 5 && minutes <= 240) ? minutes : fallback;
        }

        public static int NormalizeMonthlyOrderLimit(int value)
        {
            return (value >= 1 && value <= 99) ? value : 10;
        }

        public static int NormalizeMonthlyBudgetEuro(int value)
        {
            return (value >= 1 && value <= 99999) ? value : 200;
        }


        public static void SetGamblingDailyLimit(bool enabled, int minutes)
        {
            UpdateConfig(delegate (AppConfig config)
            {
                config.GamblingDailyLimitEnabled = enabled;
                config.GamblingDailyLimitMinutes = NormalizeDailyLimitMinutes(minutes, 15);
            });
        }

        public static void SetShoppingSettingsGuarded(bool enabled, bool checkoutDelayEnabled, bool stimulusDampingEnabled, bool dealSearchBlockEnabled, bool curfewEnabled, string curfewStart, string curfewEnd, bool dailyEnabled, int dailyMinutes, bool orderLimitEnabled, int orderLimit, bool budgetEnabled, int budgetEuro, DateTime localNow, bool devModeActive)
        {
            UpdateConfigWithWeakeningGate(delegate (AppConfig config)
            {
                config.ShoppingProtectionEnabled = enabled;
                config.ShoppingProtectionMode = enabled ? "gentle" : "off";
                config.ShoppingCheckoutDelayEnabled = checkoutDelayEnabled;
                config.ShoppingStimulusDampingEnabled = stimulusDampingEnabled;
                config.ShoppingDealSearchBlockEnabled = dealSearchBlockEnabled;
                config.ShoppingCurfewEnabled = curfewEnabled;
                config.ShoppingCurfewStart = NormalizeTimeText(curfewStart, "22:00");
                config.ShoppingCurfewEnd = NormalizeTimeText(curfewEnd, "06:00");
                config.ShoppingDailyLimitEnabled = dailyEnabled;
                config.ShoppingDailyLimitMinutes = NormalizeDailyLimitMinutes(dailyMinutes, 30);
                config.ShoppingMonthlyOrderLimitEnabled = orderLimitEnabled;
                config.ShoppingMonthlyOrderLimit = NormalizeMonthlyOrderLimit(orderLimit);
                config.ShoppingMonthlyBudgetEnabled = budgetEnabled;
                config.ShoppingMonthlyBudgetEuro = NormalizeMonthlyBudgetEuro(budgetEuro);
            }, localNow, devModeActive);
        }

        public static readonly string[] SocialMediaPlatformIds = new[]
        {
            "x", "instagram", "tiktok", "pinterest", "tumblr", "bluesky", "reddit", "youtube", "streaming"
        };

        // Plattformen mit eigenem Zeitbudget (Streaming, Tester-Notiz 2026-10-06):
        // ihre Zeit zaehlt nicht ins gemeinsame Social-Media-Limit, und ein eigenes
        // Limit darf das gemeinsame Budget uebersteigen. Sonst frisst ein einziger
        // Film das Limit fuer alles andere. Gespiegelt in PurestateNativeHost.cs,
        // PurestateGuardService.cs (Zaehler), scripts\Common.ps1 und im Companion
        // (SOCIAL_MEDIA_OWN_BUDGET_PLATFORM_IDS); durch Tests gepinnt.
        public static readonly string[] SocialMediaOwnBudgetPlatformIds = new[] { "streaming" };

        public static bool IsSocialMediaOwnBudgetPlatform(string id)
        {
            foreach (string platform in SocialMediaOwnBudgetPlatformIds)
            {
                if (string.Equals(platform, (id ?? string.Empty).Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        public static bool IsKnownSocialMediaPlatform(string id)
        {
            foreach (string platform in SocialMediaPlatformIds)
            {
                if (string.Equals(platform, (id ?? string.Empty).Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        public static int NormalizeSocialMediaBudgetMinutes(int minutes)
        {
            return (minutes >= 5 && minutes <= 480) ? minutes : 60;
        }

        public static int NormalizeSocialMediaFeedDampingScrolls(int scrolls)
        {
            return (scrolls >= 5 && scrolls <= 500) ? scrolls : 50;
        }

        // CSV "platform=minutes,...": unknown platform ids and non-integer or
        // out-of-range minutes are dropped; with an active budget an override
        // may only be stricter, so larger values are capped to the budget.
        // Output is deduplicated (first entry wins) and ordered like
        // SocialMediaPlatformIds so the canonical form is deterministic.
        public static string NormalizeSocialMediaPlatformLimits(string csv, bool budgetEnabled, int budgetMinutes)
        {
            int normalizedBudget = NormalizeSocialMediaBudgetMinutes(budgetMinutes);
            System.Collections.Generic.Dictionary<string, int> limits = new System.Collections.Generic.Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (string part in (csv ?? string.Empty).Split(','))
            {
                string[] pair = part.Split('=');
                if (pair.Length != 2)
                {
                    continue;
                }

                string platform = pair[0].Trim().ToLowerInvariant();
                int minutes;
                if (!IsKnownSocialMediaPlatform(platform) ||
                    !int.TryParse(pair[1].Trim(), out minutes) ||
                    minutes < 5 || minutes > 480 ||
                    limits.ContainsKey(platform))
                {
                    continue;
                }

                if (budgetEnabled && minutes > normalizedBudget && !IsSocialMediaOwnBudgetPlatform(platform))
                {
                    minutes = normalizedBudget;
                }

                limits[platform] = minutes;
            }

            StringBuilder result = new StringBuilder();
            foreach (string platform in SocialMediaPlatformIds)
            {
                int minutes;
                if (!limits.TryGetValue(platform, out minutes))
                {
                    continue;
                }

                if (result.Length > 0)
                {
                    result.Append(',');
                }
                result.Append(platform).Append('=').Append(minutes);
            }
            return result.ToString();
        }

        // CSV of platform ids: unknown ids dropped, deduplicated, ordered like
        // SocialMediaPlatformIds for a deterministic canonical form.
        public static string NormalizeSocialMediaBlockedPlatforms(string csv)
        {
            System.Collections.Generic.HashSet<string> blocked = new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string part in (csv ?? string.Empty).Split(','))
            {
                string platform = part.Trim().ToLowerInvariant();
                if (IsKnownSocialMediaPlatform(platform))
                {
                    blocked.Add(platform);
                }
            }

            StringBuilder result = new StringBuilder();
            foreach (string platform in SocialMediaPlatformIds)
            {
                if (!blocked.Contains(platform))
                {
                    continue;
                }

                if (result.Length > 0)
                {
                    result.Append(',');
                }
                result.Append(platform);
            }
            return result.ToString();
        }

        // Platforms with a stable set of distraction routes for the selective
        // feed block. TikTok/Pinterest (whole platform is the feed) and
        // Bluesky (unstable routes) are deliberately not offered.
        public static readonly string[] SocialMediaFeedRoutePlatformIds = new[]
        {
            "instagram", "youtube", "x", "reddit", "tumblr"
        };

        public static bool IsSocialMediaFeedRoutePlatform(string id)
        {
            foreach (string platform in SocialMediaFeedRoutePlatformIds)
            {
                if (string.Equals(platform, id, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        // CSV of routed platform ids for the selective feed block: unknown and
        // non-routed ids dropped, deduplicated, ordered like
        // SocialMediaPlatformIds. A platform under a FULL block never stays in
        // the feed list - the full block wins.
        public static string NormalizeSocialMediaFeedBlockedPlatforms(string csv, string blockedCsv)
        {
            System.Collections.Generic.HashSet<string> fullBlocked = new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string part in (blockedCsv ?? string.Empty).Split(','))
            {
                fullBlocked.Add(part.Trim().ToLowerInvariant());
            }

            System.Collections.Generic.HashSet<string> feedBlocked = new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string part in (csv ?? string.Empty).Split(','))
            {
                string platform = part.Trim().ToLowerInvariant();
                if (IsSocialMediaFeedRoutePlatform(platform) && !fullBlocked.Contains(platform))
                {
                    feedBlocked.Add(platform);
                }
            }

            StringBuilder result = new StringBuilder();
            foreach (string platform in SocialMediaPlatformIds)
            {
                if (!feedBlocked.Contains(platform))
                {
                    continue;
                }

                if (result.Length > 0)
                {
                    result.Append(',');
                }
                result.Append(platform);
            }
            return result.ToString();
        }



        public static void SetSocialMediaSettingsGuarded(bool enabled, bool budgetEnabled, int budgetMinutes, string platformLimits, string blockedPlatforms, string feedBlockedPlatforms, bool curfewEnabled, string curfewStart, string curfewEnd, bool reflectionEnabled, bool feedDampingEnabled, int feedDampingScrolls, DateTime localNow, bool devModeActive)
        {
            UpdateConfigWithWeakeningGate(delegate (AppConfig config)
            {
                config.SocialMediaProtectionEnabled = enabled;
                config.SocialMediaProtectionMode = enabled ? "gentle" : "off";
                config.SocialMediaDailyBudgetEnabled = budgetEnabled;
                config.SocialMediaDailyBudgetMinutes = NormalizeSocialMediaBudgetMinutes(budgetMinutes);
                config.SocialMediaPlatformLimits = NormalizeSocialMediaPlatformLimits(platformLimits, budgetEnabled, budgetMinutes);
                config.SocialMediaBlockedPlatforms = NormalizeSocialMediaBlockedPlatforms(blockedPlatforms);
                config.SocialMediaFeedBlockedPlatforms = NormalizeSocialMediaFeedBlockedPlatforms(feedBlockedPlatforms, config.SocialMediaBlockedPlatforms);
                config.SocialMediaCurfewEnabled = curfewEnabled;
                config.SocialMediaCurfewStart = NormalizeTimeText(curfewStart, "22:00");
                config.SocialMediaCurfewEnd = NormalizeTimeText(curfewEnd, "06:00");
                config.SocialMediaReflectionEnabled = reflectionEnabled;
                config.SocialMediaFeedDampingEnabled = feedDampingEnabled;
                config.SocialMediaFeedDampingScrolls = NormalizeSocialMediaFeedDampingScrolls(feedDampingScrolls);
            }, localNow, devModeActive);
        }

        // Fixed platform-to-domain map for the per-platform full blocks; the
        // PowerShell side (Get-SocialMediaBlockedDomains) mirrors it and both
        // are pinned by tests.
        public static string[] GetSocialMediaBlockedDomains(string blockedCsv)
        {
            System.Collections.Generic.List<string> result = new System.Collections.Generic.List<string>();
            foreach (string part in (blockedCsv ?? string.Empty).Split(','))
            {
                string platform = part.Trim().ToLowerInvariant();
                string[] domains;
                switch (platform)
                {
                    case "x": domains = new[] { "x.com", "twitter.com" }; break;
                    case "instagram": domains = new[] { "instagram.com" }; break;
                    case "tiktok": domains = new[] { "tiktok.com" }; break;
                    // BAS-006: Der Vollblock kannte nur .com, waehrend die
                    // Fail-closed-Liste derselben Plattform dreizehn Domains
                    // sperrt. Wer Pinterest bewusst vollstaendig sperrte,
                    // erreichte pinterest.de weiterhin - und zwar in der
                    // Richtung, die er ausdruecklich angefordert hat.
                    case "pinterest": domains = new[] { "pinterest.com", "pinterest.de", "pinterest.at", "pinterest.ch", "pinterest.fr", "pinterest.it", "pinterest.es", "pinterest.co.uk", "pinterest.ca", "pinterest.com.au", "pinterest.com.mx", "pinterest.jp", "pinterest.se" }; break;
                    case "tumblr": domains = new[] { "tumblr.com" }; break;
                    case "bluesky": domains = new[] { "bsky.app" }; break;
                    case "reddit": domains = new[] { "reddit.com" }; break;
                    case "youtube": domains = new[] { "youtube.com", "m.youtube.com", "youtu.be" }; break;
                    // Streaming (Tester-Notiz 2026-10-06): nur im Browser, die Apps der
                    // Dienste bleiben frei. Prime Video auf amazon.de fehlt absichtlich -
                    // die Domain gehoert dem Shopping-Bereich.
                    case "streaming": domains = new[] { "netflix.com", "disneyplus.com", "primevideo.com", "max.com", "hbomax.com", "paramountplus.com", "tv.apple.com", "crunchyroll.com", "twitch.tv", "joyn.de", "plus.rtl.de", "dazn.com", "wowtv.de" }; break;
                    default: continue;
                }

                foreach (string domain in domains)
                {
                    if (!result.Contains(domain))
                    {
                        result.Add(domain);
                    }
                }
            }
            return result.ToArray();
        }

        // URL patterns of the selective feed block (distraction routes only,
        // rest of the platform stays usable). Route map is mirrored by the
        // PowerShell Get-SocialMediaFeedBlockedPatterns, the guard
        // fail-closed filters and the Companion route constant (pinned by
        // tests).
        public static string[] GetSocialMediaFeedBlockedPatterns(string feedCsv)
        {
            System.Collections.Generic.List<string> result = new System.Collections.Generic.List<string>();
            foreach (string part in (feedCsv ?? string.Empty).Split(','))
            {
                string platform = part.Trim().ToLowerInvariant();
                string[] hosts;
                string[] routes;
                switch (platform)
                {
                    case "instagram": hosts = new[] { "instagram.com" }; routes = new[] { "/reels", "/explore" }; break;
                    case "youtube": hosts = new[] { "youtube.com", "m.youtube.com" }; routes = new[] { "/shorts" }; break;
                    case "x": hosts = new[] { "x.com", "twitter.com" }; routes = new[] { "/explore" }; break;
                    case "reddit": hosts = new[] { "reddit.com" }; routes = new[] { "/r/popular", "/r/all" }; break;
                    case "tumblr": hosts = new[] { "tumblr.com" }; routes = new[] { "/explore" }; break;
                    default: continue;
                }

                foreach (string host in hosts)
                {
                    foreach (string route in routes)
                    {
                        foreach (string pattern in new[] { "*://" + host + route + "*", "*://*." + host + route + "*" })
                        {
                            if (!result.Contains(pattern))
                            {
                                result.Add(pattern);
                            }
                        }
                    }
                }
            }
            return result.ToArray();
        }


        // Total number of switchable site-protection modules. Must match the
        // Site*Enabled fields counted in EnabledSiteProtectionCount below;
        // asserted in PurestateLogicTests so UI denominators can never drift
        // from the real field count again (0.61.43 added TikTok/Pinterest but
        // the overview card kept showing "/9").
        public const int SiteProtectionTotal = 11;

        public static int EnabledSiteProtectionCount(AppConfig config)
        {
            if (config == null || !config.AdultContentProtectionEnabled)
            {
                return 0;
            }

            int count = 0;
            if (config.SiteRedditEnabled) count++;
            if (config.SiteXEnabled) count++;
            if (config.SiteBlueskyEnabled) count++;
            if (config.SiteTumblrEnabled) count++;
            if (config.SiteDeviantArtEnabled) count++;
            if (config.SitePixivEnabled) count++;
            if (config.SiteNewgroundsEnabled) count++;
            if (config.SiteImgurEnabled) count++;
            if (config.SiteInstagramEnabled) count++;
            if (config.SiteTikTokEnabled) count++;
            if (config.SitePinterestEnabled) count++;
            return count;
        }
    }

    // DESK-03: Der Start der Wartezeit ist kein Fehler, sondern das erwartete
    // Ergebnis. Bleibt eine InvalidOperationException, damit bestehende
    // Aufrufer unveraendert funktionieren; die Oberflaeche erkennt ihn am Typ.
    public sealed class PauseCooldownStartedException : InvalidOperationException
    {
        public readonly DateTime ReadyAtUtc;

        public PauseCooldownStartedException(DateTime readyAtUtc)
            : base("Abkuehlzeit gestartet. Pausieren ist ab " + readyAtUtc.ToLocalTime().ToString("g") + " moeglich.")
        {
            ReadyAtUtc = readyAtUtc;
        }
    }
}
