using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // Social media protection. The old 8x3 matrix (free-text minutes +
    // Vollsperre + Nur-Feed checkboxes) becomes one row per platform with a
    // single choice list plus an optional own time limit. Saved values map to
    // exactly the same CSV config fields as before.
    internal sealed partial class AdminForm
    {
        private sealed class PlatformControls
        {
            public string Id;
            public ComboBox Mode;
            public CheckBox OwnLimit;
            public ComboBox OwnLimitMinutes;
            public bool SupportsFeedBlock;
        }

        private Control CreatePlatformRow(Label nameLabel, ComboBox mode, int width)
        {
            TableLayoutPanel row = new TableLayoutPanel
            {
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 2,
                Margin = new Padding(0, 0, 0, Ui.GapSmall),
                MaximumSize = new Size(width, 0),
                MinimumSize = new Size(width, 40),
                Width = width
            };
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 128));
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            nameLabel.Anchor = AnchorStyles.Left;
            mode.Anchor = AnchorStyles.Left;
            row.Controls.Add(nameLabel, 0, 0);
            row.Controls.Add(mode, 1, 0);
            return row;
        }

        private void ShowSocialMediaSettings()
        {
            AppConfig config = Support.LoadConfig();
            using (DialogShell shell = new DialogShell(theme, "Social-Media-Schutz",
                "Purestate begrenzt die Zeit auf sozialen Netzwerken oder sperrt einzelne Plattformen. Gezählt wird die Zeit auf diesem PC.",
                "Stellt Zeitlimits und Plattform-Sperren für soziale Netzwerke ein.", true))
            {
                shell.Kicker = "Schutzbereich";
                CheckBox enabled = Ui.Check(theme, "Social-Media-Schutz einschalten", config.SocialMediaProtectionEnabled,
                    "Schaltet alle Social-Media-Hilfen an oder aus.");
                shell.Add(enabled);

                shell.AddSection("Gemeinsame Regeln");
                CheckBox budget = Ui.Check(theme, "Tägliches Zeitlimit für alle Plattformen zusammen", config.SocialMediaDailyBudgetEnabled,
                    "Begrenzt die gesamte Social-Media-Zeit pro Tag. Streaming zählt getrennt und hat unten sein eigenes Limit.");
                shell.Add(budget);
                ComboBox budgetMinutes = Ui.MinutesCombo(5, 480,
                    Support.NormalizeSocialMediaBudgetMinutes(config.SocialMediaDailyBudgetMinutes),
                    "Gemeinsames Zeitlimit in Minuten", "Wert zwischen 5 und 480 Minuten pro Tag.");
                FlowLayoutPanel budgetRow = shell.Row(budgetMinutes, Ui.WrapLabel(theme, "Minuten pro Tag", 200, true));
                budgetRow.Padding = new Padding(24, 0, 0, 0);
                shell.Add(budgetRow);
                Ui.BindVisibility(budget, budgetRow);

                CheckBox curfew = Ui.Check(theme, "Feste Social-Media-Pause (Sperrzeit)", config.SocialMediaCurfewEnabled,
                    "In diesem Zeitfenster sind alle Plattformen gesperrt - außer Streaming.");
                shell.Add(curfew);
                ComboBox curfewStart = Ui.TimeCombo(config.SocialMediaCurfewStart, "22:00", "Beginn der Social-Media-Pause");
                ComboBox curfewEnd = Ui.TimeCombo(config.SocialMediaCurfewEnd, "06:00", "Ende der Social-Media-Pause");
                FlowLayoutPanel curfewRow = shell.Row(Ui.WrapLabel(theme, "Von", 40, true), curfewStart, Ui.WrapLabel(theme, "bis", 40, true), curfewEnd, Ui.WrapLabel(theme, "Uhr (auch über Mitternacht möglich)", 260, true));
                curfewRow.Padding = new Padding(24, 0, 0, 0);
                shell.Add(curfewRow);
                Label curfewError = shell.AddErrorLine();
                Ui.BindVisibility(curfew, curfewRow);

                shell.AddSection("Einzelne Plattformen");
                shell.AddHint("Für jede Plattform kannst du wählen, wie stark Purestate eingreift. „Nur den Ablenkungs-Feed sperren“ sperrt zum Beispiel Reels und Entdecken bei Instagram oder Shorts bei YouTube - der Rest bleibt nutzbar.");

                string[] platformLabels = { "X (Twitter)", "Instagram", "TikTok", "Pinterest", "Tumblr", "Bluesky", "Reddit", "YouTube", "Streaming" };
                Dictionary<string, int> existingLimits = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                foreach (string part in (config.SocialMediaPlatformLimits ?? string.Empty).Split(','))
                {
                    string[] pair = part.Split('=');
                    int parsedLimit;
                    if (pair.Length == 2 && int.TryParse(pair[1].Trim(), out parsedLimit))
                    {
                        existingLimits[pair[0].Trim().ToLowerInvariant()] = parsedLimit;
                    }
                }
                HashSet<string> existingBlocked = new HashSet<string>(
                    (config.SocialMediaBlockedPlatforms ?? string.Empty).Split(','), StringComparer.OrdinalIgnoreCase);
                HashSet<string> existingFeedBlocked = new HashSet<string>(
                    (config.SocialMediaFeedBlockedPlatforms ?? string.Empty).Split(','), StringComparer.OrdinalIgnoreCase);

                List<PlatformControls> platforms = new List<PlatformControls>();
                for (int index = 0; index < Support.SocialMediaPlatformIds.Length; index++)
                {
                    string platformId = Support.SocialMediaPlatformIds[index];
                    string label = platformLabels[index];
                    bool supportsFeed = Support.IsSocialMediaFeedRoutePlatform(platformId);
                    // Streaming fuehrt ein eigenes Zeitbudget (Tester-Notiz 2026-10-06):
                    // es zaehlt nicht ins gemeinsame Limit, und die Social-Media-Pause
                    // gilt fuer die Plattform nicht.
                    bool ownBudget = Support.IsSocialMediaOwnBudgetPlatform(platformId);

                    PlatformControls controls = new PlatformControls { Id = platformId, SupportsFeedBlock = supportsFeed };

                    Label nameLabel = new Label
                    {
                        Text = label,
                        Font = Ui.FontBodyBold,
                        ForeColor = theme.TextPrimary,
                        AutoSize = true,
                        MinimumSize = new Size(120, 28),
                        TextAlign = ContentAlignment.MiddleLeft,
                        Margin = new Padding(0, 6, 8, 0)
                    };
                    Ui.SetAccessibility(nameLabel, label, "Plattform " + label + ".", AccessibleRole.StaticText);

                    ComboBox mode = new ComboBox
                    {
                        DropDownStyle = ComboBoxStyle.DropDownList,
                        Width = 280,
                        Font = Ui.FontBody,
                        Margin = new Padding(0, 2, 0, 2)
                    };
                    Ui.StyleInput(theme, mode);
                    mode.Items.Add("Keine Einschränkung");
                    if (supportsFeed)
                    {
                        mode.Items.Add("Nur den Ablenkungs-Feed sperren");
                    }
                    mode.Items.Add("Ganze Plattform sperren");
                    if (existingBlocked.Contains(platformId))
                    {
                        mode.SelectedIndex = mode.Items.Count - 1;
                    }
                    else if (supportsFeed && existingFeedBlocked.Contains(platformId))
                    {
                        mode.SelectedIndex = 1;
                    }
                    else
                    {
                        mode.SelectedIndex = 0;
                    }
                    Ui.SetAccessibility(mode, label + " Schutzart",
                        supportsFeed
                            ? "Keine Einschränkung, nur den Ablenkungs-Feed sperren oder die ganze Plattform sperren."
                            : "Keine Einschränkung oder die ganze Plattform sperren.",
                        AccessibleRole.ComboBox);
                    controls.Mode = mode;

                    shell.Add(CreatePlatformRow(nameLabel, mode, shell.InnerWidth));

                    int existingMinutes;
                    bool hasOwnLimit = existingLimits.TryGetValue(platformId, out existingMinutes);
                    CheckBox ownLimit = Ui.Check(theme,
                        ownBudget ? "Tägliches Zeitlimit für " + label : "Eigenes Zeitlimit nur für " + label,
                        hasOwnLimit,
                        ownBudget
                            ? "Streaming hat sein eigenes Tageslimit. Es zählt nicht ins gemeinsame Zeitlimit."
                            : "Zusätzlich zum gemeinsamen Zeitlimit gilt dann ein eigener Wert für " + label + ".");
                    ownLimit.Margin = new Padding(24, 0, 0, 0);
                    controls.OwnLimit = ownLimit;
                    shell.Add(ownLimit);

                    ComboBox ownMinutes = Ui.MinutesCombo(5, 480, hasOwnLimit ? existingMinutes : (ownBudget ? 120 : 30),
                        label + " Zeitlimit in Minuten", "Wert zwischen 5 und 480 Minuten pro Tag.");
                    FlowLayoutPanel ownRow = shell.Row(ownMinutes, Ui.WrapLabel(theme, "Minuten pro Tag", 200, true));
                    ownRow.Padding = new Padding(48, 0, 0, 0);
                    controls.OwnLimitMinutes = ownMinutes;
                    shell.Add(ownRow);
                    Ui.BindVisibility(ownLimit, ownRow);

                    if (ownBudget)
                    {
                        Label streamingHint = Ui.WrapLabel(theme, "Netflix, Disney+, Prime Video, Max, Paramount+, Apple TV+, Crunchyroll, Twitch, Joyn, RTL+, DAZN und WOW - im Browser. Streaming zählt getrennt: nicht ins gemeinsame Zeitlimit, und die Social-Media-Pause gilt hier nicht. Die Apps der Dienste bleiben frei.", shell.InnerWidth - 48, true);
                        streamingHint.Margin = new Padding(24, 0, 0, Ui.GapSmall);
                        shell.Add(streamingHint);
                    }
                    else if (!supportsFeed)
                    {
                        Label onlyFull = Ui.WrapLabel(theme, label + " besteht fast nur aus Feed - deshalb gibt es hier nur die vollständige Sperre.", shell.InnerWidth - 48, true);
                        onlyFull.Margin = new Padding(24, 0, 0, Ui.GapSmall);
                        shell.Add(onlyFull);
                    }
                    if (string.Equals(platformId, "youtube", StringComparison.OrdinalIgnoreCase))
                    {
                        Label youtubeHint = Ui.WrapLabel(theme, "Hinweis: „Ganze Plattform sperren“ sperrt YouTube komplett, auch Lernvideos und Musik.", shell.InnerWidth - 48, true);
                        youtubeHint.Margin = new Padding(24, 0, 0, Ui.GapSmall);
                        shell.Add(youtubeHint);
                    }

                    platforms.Add(controls);
                }

                shell.AddSection("Weitere Hilfen");
                CheckBox reflection = Ui.Check(theme, "Kurze Frage beim ersten Öffnen am Tag", config.SocialMediaReflectionEnabled,
                    "Zeigt einmal pro Plattform und Tag eine kurze Frage vor der Nutzung.");
                shell.Add(reflection);
                CheckBox feedDamping = Ui.Check(theme, "Bremse gegen endloses Weiterscrollen", config.SocialMediaFeedDampingEnabled,
                    "Nach längerem Scrollen erscheint ein sanfter Zwischenstopp mit Weiter-Knopf.");
                shell.Add(feedDamping);
                ComboBox feedDampingScrolls = Ui.StepsCombo(new[] { 10, 25, 50, 75, 100, 150, 200, 300, 500 }, 5, 500,
                    Support.NormalizeSocialMediaFeedDampingScrolls(config.SocialMediaFeedDampingScrolls),
                    "Scroll-Schwelle", "Anzahl der Scroll-Bewegungen bis zum Zwischenstopp, Wert zwischen 5 und 500.");
                FlowLayoutPanel dampingRow = shell.Row(feedDampingScrolls, Ui.WrapLabel(theme, "Scroll-Bewegungen bis zum Zwischenstopp", 320, true));
                dampingRow.Padding = new Padding(24, 0, 0, 0);
                shell.Add(dampingRow);
                Ui.BindVisibility(feedDamping, dampingRow);

                shell.SaveButton.Click += delegate
                {
                    if (curfew.Checked &&
                        (!Support.IsValidScheduleTimeText(curfewStart.Text) || !Support.IsValidScheduleTimeText(curfewEnd.Text)))
                    {
                        shell.ShowError(curfewError, "Bitte gib die Social-Media-Pause im Format 22:00 ein.",
                            Support.IsValidScheduleTimeText(curfewStart.Text) ? curfewEnd : curfewStart);
                        return;
                    }
                    shell.ClearError(curfewError);

                    bool enabledValue = enabled.Checked;
                    bool budgetValue = budget.Checked;
                    int budgetMinutesValue = int.Parse(budgetMinutes.Text);
                    StringBuilder limitsCsv = new StringBuilder();
                    StringBuilder blockedCsv = new StringBuilder();
                    StringBuilder feedBlockedCsv = new StringBuilder();
                    foreach (PlatformControls platform in platforms)
                    {
                        if (platform.OwnLimit.Checked)
                        {
                            if (limitsCsv.Length > 0) { limitsCsv.Append(','); }
                            limitsCsv.Append(platform.Id).Append('=').Append(int.Parse(platform.OwnLimitMinutes.Text));
                        }
                        int selected = platform.Mode.SelectedIndex;
                        bool fullBlock = selected == platform.Mode.Items.Count - 1 && selected > 0;
                        bool feedBlock = platform.SupportsFeedBlock && selected == 1;
                        if (fullBlock)
                        {
                            if (blockedCsv.Length > 0) { blockedCsv.Append(','); }
                            blockedCsv.Append(platform.Id);
                        }
                        if (feedBlock)
                        {
                            if (feedBlockedCsv.Length > 0) { feedBlockedCsv.Append(','); }
                            feedBlockedCsv.Append(platform.Id);
                        }
                    }
                    string limitsValue = limitsCsv.ToString();
                    string blockedValue = blockedCsv.ToString();
                    string feedBlockedValue = feedBlockedCsv.ToString();
                    bool curfewValue = curfew.Checked;
                    string curfewStartValue = curfewStart.Text;
                    string curfewEndValue = curfewEnd.Text;
                    bool reflectionValue = reflection.Checked;
                    bool feedDampingValue = feedDamping.Checked;
                    int feedDampingScrollsValue = int.Parse(feedDampingScrolls.Text);

                    if (!ConfirmPassword("Social-Media-Schutz speichern", shell))
                    {
                        return;
                    }

                    RunAction("Social-Media-Schutz speichern", shell, delegate
                    {
                        Support.SetSocialMediaSettingsGuarded(enabledValue, budgetValue, budgetMinutesValue, limitsValue, blockedValue, feedBlockedValue, curfewValue, curfewStartValue, curfewEndValue, reflectionValue, feedDampingValue, feedDampingScrollsValue, Support.TrustedLocalNow(), false);
                        Support.ReapplyProtection();
                    }, "Social-Media-Schutz: Änderungen gespeichert.");
                };

                shell.FinishLayout();
                shell.Shown += delegate { enabled.Focus(); };
                shell.ShowDialog(this);
            }
        }
    }
}
