# Purestate UI-Designsystem

Gilt für die Windows-App (`src/PurestateApp.cs` + `src/UI/`). Ziel: ruhig, seriös,
außerordentlich einfach. Zentrale Umsetzung in `src/UI/Theme.cs` (`Ui`-Klasse) —
Dialoge definieren Schriftgrößen, Abstände und Farben nicht selbst.

Farben, Formen und Register folgen der Website (`docs/WEB-DESIGN.md`); Schrift
bleibt Segoe UI.

## Typografie (Segoe UI, logische Punkt bei 96 dpi)

| Rolle | Größe | Konstante |
| --- | --- | --- |
| Seitentitel | 20 Semilight | `Ui.FontPageTitle` |
| Statuszeile (Startkarte) | 16 Semibold | `Ui.FontStatus` |
| Abschnittstitel | 12 Semibold | `Ui.FontSection` |
| Zeilen-/Kartentitel | 11 Semibold | `Ui.FontRowTitle` |
| Fließtext, Controls | 10 | `Ui.FontBody` |
| Hinweistexte | 10 (nie kleiner) | `Ui.FontHint` |
| Berichte | Cascadia Mono 10 (Rückfall Consolas) | `Ui.FontMono` |
| Mono-Label | 10, Großbuchstaben | `Ui.FontLabel` / `Ui.MonoLabel` |

Fehlt eine Familie, fällt `Ui.MakeFont` auf Segoe UI bzw. Consolas zurück.

Keine Schrift unter 10pt. Lange Texte immer mit fester Breite + AutoSize-Höhe
(`Ui.WrapLabel`), nie abgeschnitten.

## Abstände (8er-Raster)

- 8 px: kleinster Abstand (Label ↔ Feld)
- 16 px: innerhalb einer Gruppe
- 24 px: zwischen Gruppen/Abschnitten
- 32 px: Seitenränder (`Ui.PagePadding`)

## Bedienziele

- Buttons: Höhe ≥ 36 px, Breite ≥ 96 px, `AutoSize` + `Padding`, nie beschnittener Text.
- Primäraktion pro Ansicht: genau 1, gefüllt mit `PrimaryFill` (hell Navy, dunkel Teal), Pillenform (`RoundButton`).
- Sekundäraktionen: neutraler Rahmen, Pillenform.
- Gefährliche Aktionen: roter Text, Konsequenz im Button-Text („Purestate deinstallieren").
- Checkboxen/Radios: Zeilenhöhe ≥ 32 px; Listeneinträge ≥ 36 px.
- Links (`LinkLabel`) nur für Zusatzinfos, nie einziger Weg zu einer wichtigen Aktion.
- Tastaturfokus: 2-px-Ring in `Accent` außerhalb der Pille, nur bei Tastaturbedienung.

## Farben

Zwei Paletten (Hell/Dunkel) in `Ui.Theme`; Windows-Hochkontrast → Systemfarben
(`SystemColors`), keine eigenen Farben. Statusfarben werden nie allein verwendet:
immer Glyph (Form) + Text + Handlungsanweisung.

`Divider` ist nur für ruhige Flächentrennung. `ControlBorder` kennzeichnet
interaktive Sekundärbuttons und Eingabeflächen deutlich kontrastreicher. Diese
Rollen dürfen nicht wieder zu einer einzigen Rahmenfarbe zusammenfallen.

`Accent` (Teal) ist Fokus, Links, aktive Navigation und Auswahl. Die Füllung
des Hauptknopfs ist `PrimaryFill`. Werte: Tabelle in
`docs/superpowers/specs/2026-09-19-app-website-look-design.md`, Quelle
`website/src/styles/global.css`.

Auswahl muss sich von ihrer Fläche abheben, nicht nur ihr Text: der aktive
Seitenleisteneintrag liegt auf `AccentTint` (hell `#d1eeec` statt Website-`#e5f0ef`,
das auf der Seitenleiste unsichtbar war), der ausgewählte Eintrag einer
Auswahlliste auf voller `Accent`-Fläche mit `OnAccent`-Schrift.

Auswahlfelder zeichnen Rahmen und Pfeilbereich selbst (`Ui.PaintComboChrome`,
angehängt von `Ui.StyleInput`): Rahmen `ControlBorder`, mit Fokus `Accent`,
Pfeil als Winkel in `TextSecondary` auf `InputBackground`. Das geschlossene
Feld bekommt keine Akzentfläche. Windows malt den Pfeilknopf sonst in der
hellen Systemfarbe, auch im Dunkelmodus.

| Zustand | Bedeutung | Glyph |
| --- | --- | --- |
| Aktiv (Teal) | Alles funktioniert | Kreis + Haken |
| Eingeschränkt (orange) | Regeln unvollständig | Dreieck + ! |
| Reparatur (orange-rot) | Dienst läuft nicht | Kreis + ! |
| Pausiert (grau) | bewusst pausiert | Kreis + Pause |
| Noch nichts eingeschaltet (grau) | Kein Schutzbereich an | Kreis + i |

Kein Farbverlauf, keine Farbanimation, keine dekorativen Effekte.

## Formen

Rundungen sind Markenform, kein Effekt: Buttons als Pille (`RoundButton`), Karten mit 12 px
(`RoundCard`: `AddSection`, `CommandRow`, `EmptyState`, Schutzbereichszeilen), aktiver
Seitenleisteneintrag mit 8 px. Eingabefelder bleiben eckig (native Steuerelemente). Die
Statuskarte bleibt ein eckiges Band über die volle Breite. Im Hochkontrast ist alles eckig.

Mono-Label (`Ui.MonoLabel`) steht über jedem Seiten- und Dialogtitel: „PURESTATE", in den fünf
Bereichsdialogen „SCHUTZBEREICH". Screenreader lesen die normale Schreibweise.

## Fenster und Dialoge

- Hauptfenster: vergrößerbar, `MinimumSize` 900×640, Inhalt dock-/ankerbasiert,
  Seiten scrollen (`AutoScroll`).
- Dialoge: `DialogShell` (in `src/UI/DialogShell.cs`) = Titel + Erklärsatz +
  scrollbarer Inhalt + feste Aktionsleiste (Speichern primär, Abbrechen sekundär).
  Inhaltsbreite 640 px, Fensterbreite maximal 740 px; Höhe = min(Inhalt, 85 %
  Arbeitsbereich). Kein Dialog hängt von fester Pixelhöhe ab.
- `AutoScaleMode.Dpi` überall; Layout über `TableLayoutPanel`/`FlowLayoutPanel`/`Dock`.

## Interaktionsregeln

- GDI-Symbole aus `UiIcon` gibt es nur noch in der Sidebar-Navigation und für
  Statusmeldungen (Warnung/Erfolg/Info), immer zusammen mit Text. Bereichs- und
  Aktionszeilen tragen keine Symbole.
- Wiederkehrende Aktionen verwenden `Ui.CommandRow` mit einem spezifischen
  Button-Verb je Zeile (Ändern, Verwalten, Prüfen, ...); fehlende Inhalte
  `Ui.EmptyState`. Keine dekorativen Seitenstreifen für aktive Zustände.
- Eingabefelder: Uhrzeiten über `Ui.TimeCombo` (Auswahlliste in halben Stunden,
  Altwerte werden einsortiert), Minuten-Limits über `Ui.MinutesCombo`
  (Stufenliste), Stückzahlen/Budget über `Ui.StepsCombo` (Stufenliste mit
  Unter-/Obergrenze, Altwerte werden einsortiert). Kein
  `NumericUpDown`, kein Freitext für Uhrzeiten.
- Dialog-Abschnitte (`DialogShell.AddSection`) sind Karten mit
  `CardBackground`; der Haupt-Ein/Aus-Schalter steht davor direkt im Inhalt.
- Dunkelmodus: Scrollbalken laufen über `Ui.ApplyScrollbarTheme`
  (`DarkMode_Explorer`), Hover-Farben werden bei jedem Restyle neu berechnet,
  Checkboxen/Radios rendern flach.
- Progressive Offenlegung: Eingabefelder nur sichtbar/aktiv, wenn die zugehörige
  Option aktiviert ist; Abhängigkeiten stehen als Hinweis direkt am Control.
- Speichern-Regel: Änderungen wirken erst nach „Speichern"; Passwort wird beim
  Speichern (bzw. vor der geschützten Aktion) abgefragt, nicht beim bloßen Ansehen.
  Ungespeicherte Änderungen → Rückfrage beim Schließen.
- Erfolg: Inline-Meldung („Änderungen gespeichert.") auf der Statuskarte, keine MessageBox.
- Meldungen und Bestätigungen in der Admin-UI verwenden `Ui.Confirm`/`Ui.Inform`
  im Theme-Look; native MessageBox nur noch in Installer/Uninstaller und vor dem
  UI-Start. Buttons benennen die Konsequenz, nie nur „OK/Ja".
- Eingabefehler: rote Hinweiszeile direkt am Feld, Fokus springt zum Feld,
  Screenreader-Name enthält die Fehlermeldung.

## Sprache (verbindliche Begriffe)

| Konzept | Sichtbarer Begriff | Verboten im Alltag |
| --- | --- | --- |
| Ausnahmen von Sperren | Erlaubte Webseiten | Allowlist |
| Eigene Sperreinträge | Gesperrte Webseiten | Domains, Sperrliste (allein) |
| Companion/Härtung | Browser-Schutz | Companion, Browser-Härtung |
| Tagesbudget | Zeitlimit | Budget, Tageszeitlimit |
| Curfew | Sperrzeit | Curfew, Pause (für Zeitfenster) |
| DNS/Hosts | Zusätzlicher Internetfilter / Webseiten auf diesem PC blockieren | DNS, Hosts |

Echte Umlaute in allen sichtbaren Texten (Quellen UTF-8, Build mit `/codepage:65001`).
Buttons beginnen mit Verb („Backup erstellen", „Spiel hinzufügen"). Technische
Fachbegriffe nur im Bereich „Technische Werkzeuge" oder in Klammern.

## Einfach vs. technisch

- Einfache Oberfläche: Start, Schutzbereiche (+ 5 Dialoge), Einstellungen,
  Webseitenlisten, Sicherung, Hilfe.
- Technisch (unter „Mehr → Technische Werkzeuge", mit Erklärung „Diese Funktionen
  werden im normalen Alltag nicht benötigt"): Statusbericht, Protokolle,
  Installationsprüfung, Schutztest, Listenprüfung, Dateiprüfung, Umgehungsprüfung,
  Reparatur.
- Nur für Entwicklung: Dev-Modus (eigener, abgesetzter Block; Sidebar-Indikator
  „DEV-MODUS AKTIV" bleibt).

## Barrierefreiheit

- Jede Funktion per Tastatur; Enter = Hauptaktion, Esc = Abbrechen, sichtbarer Fokus
  (2px-Akzentrahmen), Tab-Reihenfolge = Lesereihenfolge.
- `AccessibleName`/`Description`/`Role` an jedem interaktiven Control; Gruppen als
  `Grouping`; Fehlertexte erhalten Fokus und werden dadurch vorgelesen.
- Status nie nur über Farbe; deaktivierte Controls bleiben lesbar (Hinweis erklärt warum).
- Reduzierte Animation: es gibt keine Animationen mehr.
