using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Pipes;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace Purestate.Native
{
    // Ausgang eines Durchlaufs des Boten. Off heisst nur "diesmal nichts zu tun": der
    // Waechter hat OFF gesagt oder gar nicht geantwortet, und das kann auch ein Lesefehler
    // von eben sein. Es beweist nicht, dass der Abgleich aus ist.
    internal enum DeviceSyncCycleResult
    {
        Off,
        Synced,
        Failed
    }

    // Der Aufruf des Servers als Delegat, damit sich der Durchlauf ohne Netz pruefen laesst.
    // error ist der Text von PostJson, leer bei Erfolg.
    internal delegate string PostDeviceSyncBody(string body, out string error);

    // Abgleich zwischen Geraeten (Spec 2026-10-30, Abschnitte 5 und 6), Seite der App. Der
    // Tray ist nur Bote: er reicht verschluesselte Zeilen zwischen der Pipe des Waechters und
    // dem Server weiter, ohne Schluessel und ohne eine Datei aus dem Datenordner zu lesen.
    // Ob und was gesendet wird und was mit der Antwort geschieht, entscheidet der Waechter.
    // Den Kopplungscode schreibt nur das Verwaltungsfenster. Der Server wird ueber PostJson
    // aus NativeSupportAuthority.cs gerufen; hier steht kein eigener Netzcode.
    internal static partial class Support
    {
        // ---- Kopplungscode (Spec 6)

        // Crockford-Base32 ohne I, L, O und U, damit sich beim Abtippen nichts verwechseln laesst.
        private const string DeviceSyncAlphabet = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";

        // 20 Zeichen aus dem Zufallsgenerator des Systems (100 Bit) plus Pruefzeichen, in
        // Vierergruppen: K7MQ-2XRT-9HPD-WN4C-G8VB-8.
        public static string GenerateDeviceSyncCode()
        {
            byte[] bytes = new byte[20];
            using (RNGCryptoServiceProvider random = new RNGCryptoServiceProvider())
            {
                random.GetBytes(bytes);
            }

            // 32 Zeichen im Alphabet: die unteren fuenf Bit eines Bytes sind gleichverteilt.
            char[] body = new char[bytes.Length];
            for (int i = 0; i < body.Length; i++)
            {
                body[i] = DeviceSyncAlphabet[bytes[i] & 31];
            }

            return FormatDeviceSyncCode(new string(body));
        }

        // Eingabe wie getippt oder eingefuegt: Gross- und Kleinschreibung, Leerzeichen und
        // Striche sind egal, O gilt als 0, I und L als 1. code ist die Anzeigeform mit
        // Strichen - genau der Text, aus dem der Waechter die Schluessel ableitet.
        public static bool TryNormalizeDeviceSyncCode(string input, out string code)
        {
            code = string.Empty;
            if (input == null)
            {
                return false;
            }

            StringBuilder body = new StringBuilder();
            foreach (char typed in input)
            {
                if (typed == '-' || char.IsWhiteSpace(typed))
                {
                    continue;
                }

                // Nur ASCII und ohne Kulturregeln: ToUpper machte aus Zeichen anderer Schriften
                // (das tuerkische i ohne Punkt) ein I und damit eine 1.
                char c = typed >= 'a' && typed <= 'z' ? (char)(typed - 32) : typed;
                if (c == 'O')
                {
                    c = '0';
                }
                else if (c == 'I' || c == 'L')
                {
                    c = '1';
                }

                if (DeviceSyncAlphabet.IndexOf(c) < 0)
                {
                    return false;
                }

                body.Append(c);
            }

            // 20 Zeichen Code und das Pruefzeichen.
            if (body.Length != 21 || DeviceSyncCheckChar(body.ToString(0, 20)) != body[20])
            {
                return false;
            }

            code = FormatDeviceSyncCode(body.ToString(0, 20));
            return true;
        }

        private static string FormatDeviceSyncCode(string body)
        {
            StringBuilder code = new StringBuilder();
            for (int i = 0; i < 20; i += 4)
            {
                code.Append(body, i, 4).Append('-');
            }

            return code.Append(DeviceSyncCheckChar(body)).ToString();
        }

        // Alphabetwert von (Summe aus Gewicht mal Zeichenwert) modulo 32, das Gewicht ist der
        // ungerade Wert 2 * Position - 1 (Position ab 1). Ein ungerades Gewicht hat mit 32 keinen
        // Teiler gemeinsam, also aendert jede einzelne Ersetzung die Summe und faellt auf. Mit dem
        // Gewicht "Position" blieben an geraden Stellen Ersetzungen unbemerkt (rund 6 %). Nur fuer
        // Zeichen aus dem Alphabet; die Aufrufer pruefen das vorher.
        private static char DeviceSyncCheckChar(string body)
        {
            int sum = 0;
            for (int i = 0; i < body.Length; i++)
            {
                sum += (2 * i + 1) * DeviceSyncAlphabet.IndexOf(body[i]);
            }

            return DeviceSyncAlphabet[sum % 32];
        }

        // ---- Code-Datei

        public static void EnableDeviceSyncGuarded(string code, DateTime localNow, bool devModeActive)
        {
            EnableDeviceSyncGuarded(code, localNow, devModeActive, ExchangeWithDeviceSyncGuard);
        }

        // Pruefen, Aufraeumen und Schreiben gehoeren in dieselbe Konfigurationssperre:
        // sonst ersetzt ein zweites Fenster den Code oder der Waechter verpasst Aus/An.
        internal static void EnableDeviceSyncGuarded(string code, DateTime localNow, bool devModeActive, Func<string, string> pipe)
        {
            UpdateConfigWithWeakeningGate(delegate(AppConfig config)
            {
                if (config.DeviceSyncEnabled)
                {
                    throw new InvalidOperationException("Der Abgleich ist schon eingeschaltet. Einen anderen Code gibt es nur über Aus und wieder An.");
                }

                if (pipe("prepare") != "OK")
                {
                    throw new InvalidOperationException("Der Wächter ist noch nicht bereit für den Abgleich. Versuche es gleich noch einmal.");
                }

                SaveDeviceSyncCode(code);
                config.DeviceSyncEnabled = true;
            }, localNow, devModeActive);
        }

        // Als Eigenschaft: Support ist auf viele Dateien verteilt, und die Reihenfolge ihrer
        // statischen Felder ist nicht festgelegt - DataDir muss beim Lesen schon stehen.
        private static string DeviceSyncKeyPath
        {
            get { return Path.Combine(DataDir, "device-sync.key"); }
        }

        // Wirft bei einem ungueltigen Code. Der Waechter leitet die Schluessel Zeichen fuer
        // Zeichen aus dem Text der Datei ab: eine andere Schreibweise ergaebe Schluessel, die
        // kein Partner teilt, und der Abgleich bliebe still ohne Wirkung.
        public static void SaveDeviceSyncCode(string code)
        {
            string normalized;
            if (!TryNormalizeDeviceSyncCode(code, out normalized))
            {
                throw new ArgumentException("Das ist kein gueltiger Kopplungscode.", "code");
            }

            EnsureDataDir();
            // Nie vorher loeschen: fehlt die Datei bei eingeschalteter Option, ist der Abgleich dem Waechter
            // unterbrochen (er behaelt den Stand der anderen, der Bote bekommt OFF; Spec 8).
            // WriteAllTextDurable ueberschreibt an Ort und Stelle; ein Leser bekommt dabei eine Sperre
            // (Zustand unbekannt), nie eine fehlende Datei.
            WriteAllTextDurable(DeviceSyncKeyPath, normalized);
        }

        // Fuer "Code anzeigen". Leer, wenn es keinen gibt oder die Datei gerade nicht lesbar ist.
        public static string ReadDeviceSyncCode()
        {
            try
            {
                return File.ReadAllText(DeviceSyncKeyPath, Encoding.UTF8).Trim();
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        // Der bewusste Weg nach "Abgleich ausschalten": erst danach darf die Datei fehlen.
        public static void DeleteDeviceSyncCode()
        {
            if (File.Exists(DeviceSyncKeyPath))
            {
                File.Delete(DeviceSyncKeyPath);
            }
        }

        // ---- Bote (Spec 5)

        private const int DeviceSyncMaxBlobs = 9;
        private const int DeviceSyncMaxBlobChars = 4096;

        // Die Fassung fuer den Tray: echte Pipe, echter Server.
        public static DeviceSyncCycleResult RunDeviceSyncCycle()
        {
            return RunDeviceSyncCycle(ExchangeWithDeviceSyncGuard);
        }

        // Mit der Pipe als Parameter, aber dem echten Server: so faehrt die Ende-zu-Ende-Pruefung
        // den Durchlauf gegen HandleDeviceSyncMessage des Waechters.
        internal static DeviceSyncCycleResult RunDeviceSyncCycle(Func<string, string> pipe)
        {
            return RunDeviceSyncCycle(pipe, PostDeviceSyncToServer);
        }

        private static string PostDeviceSyncToServer(string body, out string error)
        {
            return PostJson("/sync", body, out error);
        }

        // Ein Durchlauf. Die Zeilen der Pipe sind die des Waechters (HandleDeviceSyncMessage):
        //   export -> OFF oder OK|<pubKey>|<seq>|<blob>|<signature>
        //   import[|<blob>...] -> OK|accepted=<n>|rejected=<m>
        //   fail|<unreachable|expired|refused> -> OK
        // OFF heisst "hier laeuft kein Abgleich" oder "gerade nicht zu sagen" (auch ein Lesefehler
        // wird so beantwortet): der Bote tut dann nichts - kein Server, keine Meldung, und er
        // schliesst daraus nichts. Wirft nie; der Tray faengt zusaetzlich.
        internal static DeviceSyncCycleResult RunDeviceSyncCycle(Func<string, string> pipe, PostDeviceSyncBody post)
        {
            try
            {
                string[] export = (pipe("export") ?? string.Empty).Split('|');
                string body = export.Length == 5 && export[0] == "OK"
                    ? BuildDeviceSyncRequestJson(export[1], export[2], export[3], export[4])
                    : null;
                if (body == null)
                {
                    return DeviceSyncCycleResult.Off;
                }

                string error;
                string response = post(body, out error);
                if (!string.IsNullOrEmpty(error))
                {
                    pipe("fail|" + DeviceSyncFailureCode(error));
                    return DeviceSyncCycleResult.Failed;
                }

                // HTTP 200 allein beweist nichts: ein Captive Portal oder Proxy antwortet auch so.
                // Ohne das Feld "blobs" wird nichts importiert, damit eine Anmeldeseite keinen
                // Stand leert.
                List<string> blobs = ParseDeviceSyncBlobs(response);
                if (blobs == null)
                {
                    pipe("fail|refused");
                    return DeviceSyncCycleResult.Failed;
                }

                // Hat der Server nichts geliefert, lautet die Zeile "import" ohne Trennstrich:
                // "import|" waere ein leeres Paeckchen und zaehlt als abgelehnt.
                string imported = pipe(blobs.Count == 0 ? "import" : "import|" + string.Join("|", blobs.ToArray())) ?? string.Empty;
                if (imported == "OFF")
                {
                    return DeviceSyncCycleResult.Off;
                }

                // Abgelehnte Pakete sind kein Fehler des Boten; nur eine fehlende Antwort ist es.
                return imported.StartsWith("OK", StringComparison.Ordinal) ? DeviceSyncCycleResult.Synced : DeviceSyncCycleResult.Failed;
            }
            catch (Exception)
            {
                return DeviceSyncCycleResult.Failed;
            }
        }

        // Die Texte so, wie PostJson sie liefert: unreachable ist AuthorityUnreachableMessage,
        // expired die Uebersetzung von "license expired", alles andere ist refused.
        private static string DeviceSyncFailureCode(string error)
        {
            if (string.Equals(error, AuthorityUnreachableMessage, StringComparison.Ordinal))
            {
                return "unreachable";
            }

            return string.Equals(error, TranslateAuthorityError("license expired"), StringComparison.Ordinal) ? "expired" : "refused";
        }

        // Der Rumpf fuer POST /sync (Spec 7). null, wenn ein Feld fehlt oder die Nummer keine Zahl
        // ist: dann gibt es nichts zu senden. seq steht als Zahl im Text, wie der Server sie bindet
        // und signiert; geprueft wird sie, weil sie ohne Anfuehrungszeichen eingesetzt wird.
        internal static string BuildDeviceSyncRequestJson(string pubKey, string seq, string blob, string signature)
        {
            long number;
            if (string.IsNullOrEmpty(pubKey) || string.IsNullOrEmpty(blob) || string.IsNullOrEmpty(signature) ||
                !long.TryParse(seq, NumberStyles.None, CultureInfo.InvariantCulture, out number))
            {
                return null;
            }

            return "{\"pubKey\":" + JsonString(pubKey) + ",\"seq\":" + number.ToString(CultureInfo.InvariantCulture) +
                ",\"blob\":" + JsonString(blob) + ",\"signature\":" + JsonString(signature) + "}";
        }

        // Die Pakete der anderen Geraete aus {"blobs":[...]}. Die Antwort ist fremde Eingabe,
        // bevor irgendetwas davon in die Pipe kommt: jeder Wert wird aus seinen JSON-Escapes
        // geloest und gilt nur, wenn er danach Base64 bis 4096 Zeichen ist. Erst loesen, dann
        // pruefen: ein | oder Zeilenumbruch in Escape-Schreibweise kaeme sonst durch und koennte
        // ein Feld oder einen Befehl dazuerfinden, und ein Schreiber darf auch das + von Base64
        // als Escape schreiben. Hoechstens neun Stueck. null, wenn die Antwort nicht von der
        // Form ist (kein Feld "blobs", kein Text in der Liste, abgeschnitten); eine leere Liste
        // ist eine gueltige Antwort.
        internal static List<string> ParseDeviceSyncBlobs(string responseJson)
        {
            if (string.IsNullOrEmpty(responseJson))
            {
                return null;
            }

            Match start = Regex.Match(responseJson, "\"blobs\"\\s*:\\s*\\[");
            if (!start.Success)
            {
                return null;
            }

            List<string> blobs = new List<string>();
            int index = start.Index + start.Length;
            while (index < responseJson.Length)
            {
                char current = responseJson[index];
                if (current == ']')
                {
                    return blobs;
                }

                if (current == ',' || char.IsWhiteSpace(current))
                {
                    index++;
                    continue;
                }

                string value;
                int end;
                if (current != '"' || !TryReadJsonString(responseJson, index, out value, out end))
                {
                    return null;
                }

                if (blobs.Count < DeviceSyncMaxBlobs && IsDeviceSyncBlob(value))
                {
                    blobs.Add(value);
                }

                index = end + 1;
            }

            return null;
        }

        // \A und \z statt ^ und $: ein $ liesse einen Zeilenumbruch am Ende durch.
        private static bool IsDeviceSyncBlob(string value)
        {
            return value.Length > 0 && value.Length <= DeviceSyncMaxBlobChars && Regex.IsMatch(value, @"\A[A-Za-z0-9+/]+={0,2}\z");
        }

        // Abstand bis zum naechsten Durchlauf: 120 s +/- 15 s, nach Fehlern verdoppelnd (240,
        // 480) bis hoechstens 900 s. Die Streuung haelt die Geraete auseinander, im Fehlerfall
        // zaehlt der gleichmaessige Abstand.
        internal static int NextDeviceSyncDelaySeconds(int consecutiveFailures, Random random)
        {
            if (consecutiveFailures <= 0)
            {
                return 105 + random.Next(31);
            }

            // Ab drei Fehlern ist die Grenze erreicht; so kann beim Schieben nichts ueberlaufen.
            return consecutiveFailures >= 3 ? 900 : 120 << consecutiveFailures;
        }

        // ---- Pipe zum Waechter

        private const string DeviceSyncPipeName = "PurestateDeviceSync";
        private const int DeviceSyncPipeConnectMs = 3000;
        // Gesamtfrist fuer einen Austausch mit dem Waechter: verbinden, senden, lesen.
        internal const int DeviceSyncPipeDeadlineMs = 10000;

        private static string ExchangeWithDeviceSyncGuard(string message)
        {
            return ExchangeDeviceSyncLine(DeviceSyncPipeName, message);
        }

        // Eine Zeile hin, eine zurueck, wie ExchangeGuardUsage im Native Host, in hoechstens
        // DeviceSyncPipeDeadlineMs. Leer heisst: keine Pipe, keine Antwort oder keine rechtzeitig.
        // Wirft nie. Die Gegenstelle wird nicht geprueft: ueber diese Pipe laufen nur
        // Verschluesseltes und Anzeige, und der Waechter prueft seinerseits den Client.
        internal static string ExchangeDeviceSyncLine(string pipeName, string message)
        {
            return ExchangeDeviceSyncLine(pipeName, message, DeviceSyncPipeDeadlineMs);
        }

        // Dasselbe mit eigener Frist, damit ein Test nicht zehn Sekunden wartet. Nur das Verbinden
        // hat eine Grenze (3 s); ReadLine wartet, solange die Gegenstelle die Verbindung offen haelt
        // und schweigt. Deshalb laeuft der Austausch auf einem Hintergrundfaden, und nach deadlineMs
        // gibt es die leere Antwort: der Durchlauf versteht sie als "kein Abgleich", das Fenster als
        // "kein Stand".
        // ponytail: ein Faden bleibt je Stillstand geparkt, bis die Gegenstelle antwortet oder der Tray
        // endet; die Pipe des Waechters hat nur eine Instanz, spaetere Aufrufe scheitern deshalb schon
        // beim Verbinden, statt weitere Faeden zu parken. Wer das nicht will: BeginRead mit WaitOne
        // und eigener Zeilenschleife wie ReadPipeLine im Waechter, etwa 20 Zeilen.
        internal static string ExchangeDeviceSyncLine(string pipeName, string message, int deadlineMs)
        {
            try
            {
                string answer = string.Empty;
                Thread worker = new Thread(delegate () { answer = ExchangeDeviceSyncLineBlocking(pipeName, message); });
                worker.IsBackground = true;
                worker.Start();
                return worker.Join(deadlineMs) ? answer : string.Empty;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        private static string ExchangeDeviceSyncLineBlocking(string pipeName, string message)
        {
            try
            {
                using (NamedPipeClientStream pipe = new NamedPipeClientStream(".", pipeName, PipeDirection.InOut))
                {
                    pipe.Connect(DeviceSyncPipeConnectMs);
                    using (StreamWriter writer = new StreamWriter(pipe, new UTF8Encoding(false), 1024, true))
                    using (StreamReader reader = new StreamReader(pipe, Encoding.UTF8, false, 1024, true))
                    {
                        writer.AutoFlush = true;
                        writer.WriteLine(message);
                        return reader.ReadLine() ?? string.Empty;
                    }
                }
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        // ---- Status fuer die Anzeige

        // Fragt den Waechter ueber dieselbe Pipe. Wirft nie; ohne Antwort und bei OFF ist
        // Enabled false.
        public static DeviceSyncStatus QueryDeviceSyncStatus()
        {
            return ParseDeviceSyncStatus(ExchangeWithDeviceSyncGuard("status"));
        }

        // Die Summe der Zaehler der anderen Geraete fuer einen Schluessel im laufenden Zeitraum,
        // etwa "games" fuer die Videospiel-Anzeige. Ohne Stand (OFF, keine Antwort) ist sie 0: die
        // Anzeige zeigt dann nur den eigenen Stand.
        internal static int SumDeviceSyncForeignSeconds(DeviceSyncStatus status, string key)
        {
            long sum = 0;
            foreach (DeviceSyncPeerStatus peer in status.Peers)
            {
                int seconds;
                if (peer.Used.TryGetValue(key, out seconds))
                {
                    sum += seconds;
                }
            }

            return sum > int.MaxValue ? int.MaxValue : (int)sum;
        }

        // Die Zeile des Waechters auf status (StatusDeviceSync): OFF oder
        //   OK|last=<ISO>|failure=<code>|othercode=<0|1>|self=<name>;<used>;<off>
        //     |peer=<name>;<ISO>;<used>;<off>...|limit=<key>,<geltend>,<eigen>,<name>...
        // <used> ist schluessel=wert mit Kommas, <off> eine Liste von Bereichen. Was nicht passt,
        // wird uebergangen: eine Zeile ist nie Grund fuer eine Ausnahme. OFF, Muell und keine
        // Antwort ergeben dasselbe, Enabled false mit leeren Listen.
        internal static DeviceSyncStatus ParseDeviceSyncStatus(string line)
        {
            DeviceSyncStatus status = new DeviceSyncStatus();
            string[] fields = (line ?? string.Empty).Split('|');
            if (fields.Length < 2 || fields[0] != "OK")
            {
                return status;
            }

            status.Enabled = true;
            for (int i = 1; i < fields.Length; i++)
            {
                int separator = fields[i].IndexOf('=');
                if (separator <= 0)
                {
                    continue;
                }

                string value = fields[i].Substring(separator + 1);
                DateTime time;
                string[] parts;
                int effective;
                int own;
                switch (fields[i].Substring(0, separator))
                {
                    case "last":
                        if (TryParseDeviceSyncTime(value, out time))
                        {
                            status.LastContactUtc = time;
                        }
                        break;
                    case "failure":
                        status.Failure = value;
                        break;
                    case "othercode":
                        status.OtherCodeSeen = value == "1";
                        break;
                    case "self":
                        parts = value.Split(';');
                        if (parts.Length == 3)
                        {
                            status.SelfName = parts[0];
                            status.SelfUsed = ParseDeviceSyncUsed(parts[1]);
                            status.SelfOff = ParseDeviceSyncAreas(parts[2]);
                        }
                        break;
                    case "peer":
                        parts = value.Split(';');
                        if (parts.Length == 4 && TryParseDeviceSyncTime(parts[1], out time))
                        {
                            DeviceSyncPeerStatus peer = new DeviceSyncPeerStatus();
                            peer.Name = parts[0];
                            peer.LastSeenUtc = time;
                            peer.Used = ParseDeviceSyncUsed(parts[2]);
                            peer.Off = ParseDeviceSyncAreas(parts[3]);
                            status.Peers.Add(peer);
                        }
                        break;
                    case "limit":
                        parts = value.Split(',');
                        if (parts.Length == 4 &&
                            int.TryParse(parts[1], NumberStyles.None, CultureInfo.InvariantCulture, out effective) &&
                            int.TryParse(parts[2], NumberStyles.None, CultureInfo.InvariantCulture, out own))
                        {
                            DeviceSyncLimitStatus limit = new DeviceSyncLimitStatus();
                            limit.Key = parts[0];
                            limit.Effective = effective;
                            limit.Own = own;
                            limit.PeerName = parts[3];
                            status.Limits.Add(limit);
                        }
                        break;
                }
            }

            return status;
        }

        // Das Format des Waechters (DeviceSyncIso); strikt, damit Muell keine Zeit ergibt.
        private static bool TryParseDeviceSyncTime(string text, out DateTime utc)
        {
            return DateTime.TryParseExact(text, "yyyy-MM-dd'T'HH:mm:ss.fffffff'Z'", CultureInfo.InvariantCulture,
                DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out utc);
        }

        private static Dictionary<string, int> ParseDeviceSyncUsed(string text)
        {
            Dictionary<string, int> used = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (string item in text.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                int separator = item.IndexOf('=');
                int value;
                if (separator > 0 && int.TryParse(item.Substring(separator + 1), NumberStyles.None, CultureInfo.InvariantCulture, out value))
                {
                    used[item.Substring(0, separator)] = value;
                }
            }

            return used;
        }

        private static List<string> ParseDeviceSyncAreas(string text)
        {
            return new List<string>(text.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
        }

        // ---- Zeilen der Anzeige (Spec 3)

        // Die Bereiche, wie der Waechter sie im off-Feld nennt, mit ihren Anzeigenamen. Die Zaehler der
        // Geraeteliste gehoeren in derselben Reihenfolge dazu; Plattformen (social:<plattform>) und
        // Monatswerte (orders, spend) stehen nicht in der Liste.
        private static readonly string[] DeviceSyncAreaNames = { "social", "shopping", "gambling", "games" };
        private static readonly string[] DeviceSyncAreaLabels = { "Social Media", "Shopping", "Glücksspiel", "Videospiele" };
        private static readonly string[] DeviceSyncListKeys = { "social:global", "shopping", "gambling", "games" };

        // Die Geraeteliste und die Hinweise, die gerade zutreffen, als fertige Zeilen. Rein, damit sie ohne
        // Fenster testbar sind. Was die Konfiguration von status.Limits streicht, erledigt vorher
        // DropInapplicableDeviceSyncLimits. Der Fehlercode des Waechters (Failure) erscheint nicht: auf einem
        // PC mit zwei Nutzern steht dort refused, obwohl der Abgleich laeuft; die Unterbrechung zeigt "Kein
        // Abgleich seit". Nur wo es noch keinen Kontakt gab, zaehlt, dass ein Fehler gemeldet ist ("Noch kein
        // Abgleich gelungen"). Ohne Stand (OFF, keine Antwort) gibt es keine Zeilen.
        internal static List<string> DeviceSyncStatusLines(DeviceSyncStatus status, DateTime nowUtc)
        {
            List<string> lines = new List<string>();
            if (status == null || !status.Enabled)
            {
                return lines;
            }

            lines.Add(DeviceSyncDeviceLine(
                status.SelfName.Length == 0 ? "Dieser PC" : "Dieser PC (" + DeviceSyncDisplayName(status.SelfName) + ")",
                "gerade eben", status.SelfUsed));
            foreach (DeviceSyncPeerStatus peer in status.Peers)
            {
                lines.Add(DeviceSyncDeviceLine(DeviceSyncDisplayName(peer.Name), DeviceSyncAge(nowUtc - peer.LastSeenUtc), peer.Used));
            }

            // Ein fremdes Limit gilt hier nur, solange der Bereich hier an ist. Ist er aus, steht dort statt des
            // Limits, dass hier verbrachte Zeit nicht zaehlt - einmal je Bereich, auch bei mehreren Schluesseln.
            List<string> offShown = new List<string>();
            foreach (DeviceSyncLimitStatus limit in status.Limits)
            {
                string area = DeviceSyncAreaOfKey(limit.Key);
                string label = DeviceSyncKeyLabel(limit.Key);
                if (area == null || label == null || limit.Effective <= 0)
                {
                    continue;
                }

                if (status.SelfOff.Contains(area))
                {
                    if (!offShown.Contains(area))
                    {
                        offShown.Add(area);
                        lines.Add("Auf diesem Gerät " + DeviceSyncAreaIsOff(area) + " Hier verbrachte Zeit zählt nicht.");
                    }

                    continue;
                }

                lines.Add(label + ": " + DeviceSyncLimitAmount(limit.Key, limit.Effective) + " hier, weil " +
                    DeviceSyncDisplayName(limit.PeerName) + " das strengere Limit hat." +
                    (limit.Own > 0 ? " Hier eingestellt: " + limit.Own.ToString(CultureInfo.InvariantCulture) + "." : string.Empty));
            }

            // Bereiche, die auf einem anderen Geraet aus sind. Ist derselbe Bereich hier auch aus, entfaellt der
            // Hinweis: sonst stuende bei einer Standardeinrichtung dreimal dasselbe da.
            foreach (DeviceSyncPeerStatus peer in status.Peers)
            {
                List<string> peerShown = new List<string>();
                foreach (string area in peer.Off)
                {
                    if (Array.IndexOf(DeviceSyncAreaNames, area) < 0 || status.SelfOff.Contains(area) || peerShown.Contains(area))
                    {
                        continue;
                    }

                    peerShown.Add(area);
                    lines.Add("Auf " + DeviceSyncDisplayName(peer.Name) + " " + DeviceSyncAreaIsOff(area) + " Dort verbrachte Zeit zählt nicht.");
                }
            }

            // Erst ab 30 Minuten ohne Kontakt, in Minuten oder Stunden.
            if (status.LastContactUtc.HasValue)
            {
                TimeSpan silent = nowUtc - status.LastContactUtc.Value;
                if (silent >= TimeSpan.FromMinutes(30))
                {
                    lines.Add("Kein Abgleich seit " +
                        (silent < TimeSpan.FromHours(1) ? (int)silent.TotalMinutes + " Minuten" : DeviceSyncHours(silent)) +
                        ". Der Schutz läuft, gezählt wird, was bisher bekannt ist.");
                }
            }
            else if (!string.IsNullOrEmpty(status.Failure))
            {
                // Noch nie ein Abgleich gelungen, und ein Fehler ist gemeldet: ein Server, der von Anfang an nicht
                // zu erreichen ist, oder eine abgelaufene Lizenz sehen sonst aus wie "noch kein zweites Geraet".
                // Ohne Fehler bleibt die Zeile weg. Nur dass einer gemeldet ist, zaehlt; sein Wert erscheint nie.
                lines.Add("Noch kein Abgleich gelungen. Der Schutz läuft, gezählt wird, was bisher bekannt ist.");
            }

            if (status.OtherCodeSeen)
            {
                lines.Add("Ein weiteres Gerät gleicht mit einem anderen Code ab.");
            }

            return lines;
        }

        // Nimmt aus status.Limits, was hier nicht gilt, obwohl der Waechter es nennt: er meldet bei voll
        // gesperrtem Gluecksspiel und bei strengen Spielen "eigen 0", als gaebe es hier kein Limit - dort
        // greift aber kein fremdes (die Sperre ist voll, im strengen Modus laeuft kein Spiel). Das weiss nur
        // die Konfiguration. Bereiche, die hier aus sind, erledigt die Liste SelfOff in DeviceSyncStatusLines.
        internal static void DropInapplicableDeviceSyncLimits(DeviceSyncStatus status, AppConfig config)
        {
            if (status == null || config == null)
            {
                return;
            }

            bool gamblingBlocked = EffectiveGamblingProtectionEnabled(config);
            bool gamesStrict = NormalizeVideoGamesMode(config.VideoGamesProtectionMode, config.VideoGamesProtectionEnabled) == "strict";
            status.Limits.RemoveAll(delegate (DeviceSyncLimitStatus limit)
            {
                return (gamblingBlocked && limit.Key == "gambling") || (gamesStrict && limit.Key == "games");
            });
        }

        // Das Limit, das der Waechter bei Videospielen durchsetzt (ApplyDeviceSyncGameLimit): nur im sanften Modus,
        // dort das kleinere von eigenem und fremdem, und ohne eigenes das fremde. ownMinutes und das Ergebnis sind 0,
        // wenn kein Limit gilt. Der Waechter nennt ein fremdes Limit nur, wenn es strenger ist oder hier keins steht;
        // das Minimum steht trotzdem hier, weil die Anzeige ihr eigenes Limit aus der Konfiguration liest. status ist
        // schon durch DropInapplicableDeviceSyncLimits gelaufen; der Modus kommt trotzdem mit, denn bei ausgeschalteten
        // Spielen setzt der Waechter das fremde Limit nicht durch.
        internal static int EffectiveVideoGamesLimitMinutes(int ownMinutes, string mode, DeviceSyncStatus status)
        {
            if (status == null || mode != "gentle")
            {
                return ownMinutes;
            }

            foreach (DeviceSyncLimitStatus limit in status.Limits)
            {
                if (limit.Key == "games" && limit.Effective > 0)
                {
                    return ownMinutes > 0 ? Math.Min(ownMinutes, limit.Effective) : limit.Effective;
                }
            }

            return ownMinutes;
        }

        // Zwischen Zahl und "min" steht ein geschuetztes Leerzeichen (U+00A0): "5" und "min." brechen nie
        // auseinander. Nur in den Geraetezeilen; die Hinweise behalten ihre gewoehnlichen Leerzeichen.
        private static readonly string DeviceSyncMinutesUnit = (char)0xA0 + "min";

        // "Dieser PC (DESKTOP-ABC), gerade eben. Heute: Social Media 20 min, Videospiele 0 min." (mit dem
        // geschuetzten Leerzeichen vor min). Ohne Zaehler bleibt es bei der ersten Aussage.
        private static string DeviceSyncDeviceLine(string name, string age, Dictionary<string, int> used)
        {
            List<string> areas = new List<string>();
            for (int i = 0; i < DeviceSyncListKeys.Length; i++)
            {
                int seconds;
                if (used != null && used.TryGetValue(DeviceSyncListKeys[i], out seconds))
                {
                    areas.Add(DeviceSyncAreaLabels[i] + " " + (seconds / 60).ToString(CultureInfo.InvariantCulture) + DeviceSyncMinutesUnit);
                }
            }

            return name + ", " + age + "." + (areas.Count == 0 ? string.Empty : " Heute: " + string.Join(", ", areas.ToArray()) + ".");
        }

        // Namen anderer Geraete sind fremde Eingabe: die Pipe-Gegenstelle wird nicht geprueft. Der Waechter
        // laesst nur [A-Za-z0-9._-] bis 32 Zeichen durch; alles andere wird hier zu "?" und gekuerzt, damit
        // ein Name nie Zeichen mit Sonderbedeutung (&, {0}, Steuer- und Umschaltzeichen) traegt und das
        // Layout nicht sprengt.
        private static string DeviceSyncDisplayName(string name)
        {
            string safe = Regex.Replace(name ?? string.Empty, "[^A-Za-z0-9._-]", "?");
            return safe.Length == 0 ? "?" : (safe.Length > 32 ? safe.Substring(0, 32) : safe);
        }

        // Unter zwei Minuten "gerade eben" (auch bei einem Zeitpunkt in der Zukunft: zwei Uhren gehen nie
        // ganz gleich), dann Minuten, Stunden und Tage.
        private static string DeviceSyncAge(TimeSpan age)
        {
            if (age < TimeSpan.FromMinutes(2))
            {
                return "gerade eben";
            }

            if (age < TimeSpan.FromHours(1))
            {
                return "vor " + (int)age.TotalMinutes + " Minuten";
            }

            if (age < TimeSpan.FromHours(24))
            {
                return "vor " + DeviceSyncHours(age);
            }

            int days = (int)age.TotalDays;
            return "vor " + days + (days == 1 ? " Tag" : " Tagen");
        }

        private static string DeviceSyncHours(TimeSpan span)
        {
            int hours = (int)span.TotalHours;
            return hours + (hours == 1 ? " Stunde" : " Stunden");
        }

        // Zu welchem Bereich ein Schluessel von limit= gehoert (Namen wie im off-Feld); null, wenn die App
        // ihn nicht kennt.
        private static string DeviceSyncAreaOfKey(string key)
        {
            if (key == "shopping" || key == "orders" || key == "spend")
            {
                return "shopping";
            }

            if (key == "gambling" || key == "games")
            {
                return key;
            }

            return key != null && key.StartsWith("social:", StringComparison.Ordinal) ? "social" : null;
        }

        // Anzeigename zu einem Schluessel. Plattformen heissen wie im Dialog der Social-Media-Einstellungen;
        // null bei einer Plattform, die diese Fassung nicht kennt (der Host wendet ihr Limit hier auch nicht an).
        private static string DeviceSyncKeyLabel(string key)
        {
            string area = DeviceSyncAreaOfKey(key);
            if (area == null)
            {
                return null;
            }

            if (area == "social" && key != "social:global")
            {
                int platform = Array.IndexOf(SocialMediaPlatformIds, key.Substring("social:".Length));
                return platform < 0 ? null : SocialMediaPlatformLabels[platform];
            }

            return DeviceSyncAreaLabels[Array.IndexOf(DeviceSyncAreaNames, area)];
        }

        // "30 Minuten gelten", "3 Bestellungen im Monat gelten", "100 Euro im Monat gelten". Die Einheit gehoert
        // zum Schluessel (orders zaehlt Bestellungen, spend Euro, alles andere Minuten); bei 1 heisst es "gilt".
        private static string DeviceSyncLimitAmount(string key, int value)
        {
            bool one = value == 1;
            string unit = key == "orders" ? (one ? "Bestellung im Monat" : "Bestellungen im Monat")
                : key == "spend" ? "Euro im Monat"
                : (one ? "Minute" : "Minuten");
            return value.ToString(CultureInfo.InvariantCulture) + " " + unit + (one ? " gilt" : " gelten");
        }

        // "ist Social Media aus." / "sind Videospiele aus."
        private static string DeviceSyncAreaIsOff(string area)
        {
            return (area == "games" ? "sind " : "ist ") + DeviceSyncAreaLabels[Array.IndexOf(DeviceSyncAreaNames, area)] + " aus.";
        }
    }

    // Was die Oberflaeche aus der Statuszeile des Waechters braucht (Spec 3). Felder ohne
    // Wert sind leer statt null, damit niemand pruefen muss, bevor er eine Liste durchgeht.
    public sealed class DeviceSyncStatus
    {
        // false bei OFF, ohne Antwort und bei allem, was keine Statuszeile ist.
        public bool Enabled;
        // Letzter erfolgreicher Austausch; null, solange es keinen gab.
        public DateTime? LastContactUtc;
        // unreachable, expired oder refused nach dem letzten Fehlschlag; leer, wenn alles gut ging.
        public string Failure = string.Empty;
        // Ein weiteres Geraet gleicht mit einem anderen Code ab.
        public bool OtherCodeSeen;
        public string SelfName = string.Empty;
        // Eigene Zaehler des laufenden Zeitraums: Sekunden, bei orders die Anzahl, bei spend Euro.
        public Dictionary<string, int> SelfUsed = new Dictionary<string, int>();
        // Bereiche, die hier aus sind.
        public List<string> SelfOff = new List<string>();
        public List<DeviceSyncPeerStatus> Peers = new List<DeviceSyncPeerStatus>();
        // Schluessel, bei denen das Limit eines anderen Geraets hier gilt.
        public List<DeviceSyncLimitStatus> Limits = new List<DeviceSyncLimitStatus>();
    }

    public sealed class DeviceSyncPeerStatus
    {
        public string Name = string.Empty;
        public DateTime LastSeenUtc;
        public Dictionary<string, int> Used = new Dictionary<string, int>();
        public List<string> Off = new List<string>();
    }

    // Das strengste fremde Limit eines Schluessels in Minuten: Effective gilt hier, Own ist das
    // hier eingestellte (0, wenn keins), PeerName das Geraet mit dem strengsten.
    public sealed class DeviceSyncLimitStatus
    {
        public string Key = string.Empty;
        public int Effective;
        public int Own;
        public string PeerName = string.Empty;
    }
}
