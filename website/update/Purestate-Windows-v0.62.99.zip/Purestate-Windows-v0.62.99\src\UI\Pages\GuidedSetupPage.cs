using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    internal sealed partial class AdminForm
    {
        private readonly string[] guidedSetupAreas = { Support.AreaAdultContent, Support.AreaGambling, Support.AreaShopping, Support.AreaSocialMedia, Support.AreaVideoGames };
        private int guidedSetupStep;
        private Label guidedSetupTitle;
        private Label guidedSetupHint;
        private Label guidedSetupStatus;
        private Button guidedSetupBack;
        private Button guidedSetupNext;
        private Button guidedSetupConfigure;
        private Button guidedSetupDevices;

        private void BuildGuidedSetupPage()
        {
            TableLayoutPanel page = CreatePage("setup");
            AddPageTitle(page, "Geführte Einrichtung");
            AddPageHint(page, "Gehe die fünf Schutzbereiche in Ruhe durch. Weiter und Zurück ändern nichts. Bereits gespeicherte Änderungen bleiben bestehen, wenn du zur Startseite zurückkehrst.");
            RoundCard card = new RoundCard
            {
                AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 1,
                Padding = new Padding(Ui.GapGroup), Margin = new Padding(0, Ui.GapSmall, 0, Ui.GapGroup)
            };
            card.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            Ui.StyleCard(theme, card);
            Ui.FitToPageColumn(card, Dpi.Px(120));
            guidedSetupTitle = Ui.WrapLabel(theme, string.Empty, Ui.ContentMaxWidth, false);
            guidedSetupTitle.Font = Ui.FontRowTitle;
            guidedSetupHint = Ui.WrapLabel(theme, string.Empty, Ui.ContentMaxWidth, true);
            guidedSetupStatus = Ui.WrapLabel(theme, string.Empty, Ui.ContentMaxWidth, false);
            foreach (Label label in new Label[] { guidedSetupTitle, guidedSetupHint, guidedSetupStatus })
            {
                label.MaximumSize = Size.Empty;
                label.Anchor = AnchorStyles.Left | AnchorStyles.Right;
                card.Controls.Add(label);
            }
            guidedSetupConfigure = Ui.SecondaryButton(theme, "Einstellen", "Öffnet die Einstellungen dieses Schutzbereichs.");
            guidedSetupConfigure.Click += delegate { ConfigureGuidedSetupArea(); };
            card.Controls.Add(guidedSetupConfigure);
            guidedSetupDevices = Ui.SecondaryButton(theme, "Mehrere Geräte", "Öffnet den Geräteabgleich in den Einstellungen.");
            guidedSetupDevices.Click += delegate
            {
                NavigateTo("settings");
                pageHost.ScrollControlIntoView(deviceSyncOnRow.Visible ? deviceSyncOnRow : deviceSyncOffRow);
            };
            card.Controls.Add(guidedSetupDevices);
            page.Controls.Add(card);

            FlowLayoutPanel navigation = new FlowLayoutPanel { AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, WrapContents = true, Margin = Padding.Empty };
            Ui.FitToPageColumn(navigation, Dpi.Px(44));
            guidedSetupBack = Ui.SecondaryButton(theme, "Zurück", "Geht einen Schritt zurück, ohne Einstellungen zu ändern.");
            guidedSetupBack.Click += delegate { if (guidedSetupStep > 0) { guidedSetupStep--; UpdateGuidedSetupStep(); } };
            guidedSetupNext = Ui.PrimaryButton(theme, "Weiter", "Geht zum nächsten Schritt, ohne Einstellungen zu ändern.");
            guidedSetupNext.Click += delegate
            {
                if (guidedSetupStep < guidedSetupAreas.Length) { guidedSetupStep++; UpdateGuidedSetupStep(); }
                else { NavigateTo("start"); }
            };
            Button exit = Ui.SecondaryButton(theme, "Zur Startseite", "Verlässt die Einrichtung. Bereits gespeicherte Änderungen bleiben bestehen.");
            exit.Click += delegate { NavigateTo("start"); };
            navigation.Controls.AddRange(new Control[] { guidedSetupBack, guidedSetupNext, exit });
            page.Controls.Add(navigation);
            actionButtons.AddRange(new Button[] { guidedSetupConfigure, guidedSetupDevices, guidedSetupBack, guidedSetupNext, exit });
            themeAppliers.Add(delegate
            {
                Ui.StyleCard(theme, card);
                guidedSetupTitle.ForeColor = theme.TextPrimary;
                guidedSetupHint.ForeColor = theme.TextSecondary;
                guidedSetupStatus.ForeColor = theme.TextPrimary;
                foreach (Button button in new Button[] { guidedSetupConfigure, guidedSetupDevices, guidedSetupBack, exit }) { Ui.StyleSecondary(theme, button); }
                Ui.StylePrimary(theme, guidedSetupNext);
            });
            UpdateGuidedSetupStep();
        }

        private void StartGuidedSetup()
        {
            guidedSetupStep = 0;
            UpdateGuidedSetupStep();
            NavigateTo("setup");
        }

        private void UpdateGuidedSetupStep()
        {
            bool final = guidedSetupStep == guidedSetupAreas.Length;
            Ui.SetDynamicText(guidedSetupTitle, "Schritt " + (guidedSetupStep + 1) + " von 6: " + (final ? "Abschluss" : AreaDisplayName(guidedSetupAreas[guidedSetupStep])), "Einrichtung");
            string[] hints = {
                "Blockiert Erwachseneninhalte und filtert unterstützte Webseiten. Dieser Bereich wird auf jedem Gerät einzeln eingeschaltet.",
                "Wähle zwischen vollständiger Sperre und einem Tageszeitlimit für Glücksspiel. Dieser Bereich wird auf jedem Gerät einzeln eingeschaltet.",
                "Wartezeiten, Zeitlimits und Kaufbremsen helfen gegen Impulskäufe. Dieser Bereich wird auf jedem Gerät einzeln eingeschaltet.",
                "Wähle Tageszeitlimit, Plattformen und Pausen für Social Media. Dieser Bereich wird auf jedem Gerät einzeln eingeschaltet.",
                "Wähle Spiele und entscheide zwischen Zeitregeln und vollständiger Sperre. Dieser Bereich wird auf jedem Gerät einzeln eingeschaltet."
            };
            Ui.SetDynamicText(guidedSetupHint, final ? "Das ist der aktuelle Stand auf diesem Gerät. Beim Geräteabgleich zählt die gemeldete Nutzung zusammen; das strengere gemeinsame Limit gilt. Bereiche und Sperrzeiten stellst du auf jedem Gerät einzeln ein." : hints[guidedSetupStep], "Einrichtungshinweis");
            guidedSetupConfigure.Visible = !final;
            guidedSetupDevices.Visible = final && deviceSyncOnRow != null;
            guidedSetupBack.Enabled = actionButtonsEnabled && guidedSetupStep > 0;
            Ui.SetDynamicText(guidedSetupNext, final ? "Fertig" : "Weiter", final ? "Einrichtung abschließen" : "Nächster Schritt");
            guidedSetupNext.AccessibleDescription = final ? "Kehrt zur Startseite zurück. Bereits gespeicherte Änderungen bleiben bestehen." : "Geht zum nächsten Schritt, ohne Einstellungen zu ändern.";
            UpdateGuidedSetupStatus();
            if (currentPageKey == "setup") { pageHost.AutoScrollPosition = new Point(0, 0); }
        }

        private void ConfigureGuidedSetupArea()
        {
            if (guidedSetupStep == 0) { ShowSiteProtectionSettings(); }
            else if (guidedSetupStep == 1) { ShowGamblingProtectionSettings(); }
            else if (guidedSetupStep == 2) { ShowShoppingProtectionSettings(); }
            else if (guidedSetupStep == 3) { ShowSocialMediaSettings(); }
            else if (guidedSetupStep == 4) { ShowVideoGamesSettings(); }
        }

        private void UpdateGuidedSetupStatus()
        {
            if (guidedSetupStatus == null) { return; }
            List<string> lines = new List<string>();
            bool final = guidedSetupStep == guidedSetupAreas.Length;
            foreach (string area in guidedSetupAreas)
            {
                if (!final && area != guidedSetupAreas[guidedSetupStep]) { continue; }
                Label label;
                lines.Add(AreaDisplayName(area) + ": " + (startAreaStatusLabels.TryGetValue(area, out label) ? label.Text : "wird ermittelt ..."));
            }
            Ui.SetDynamicText(guidedSetupStatus, string.Join(Environment.NewLine, lines.ToArray()), "Aktueller Schutz");
        }
    }
}
