using System;
using System.Diagnostics;
using System.Globalization;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // Update-Suche im Verwaltungsfenster: Hinweis auf der Startseite, "Nach Updates
    // suchen" auf der Seite "Mehr", Dialog mit Aenderungstext, Installation und der
    // Weg von "Zur neuen Fassung". Netz und Ablage stehen in src\PurestateUpdate.cs;
    // hier ist nur die Oberflaeche. Geladen und entpackt wird ausschliesslich in
    // diesem erhoehten Fenster, nie im Tray.
    internal sealed partial class AdminForm
    {
        private TableLayoutPanel updateBannerRow;
        private Label updateBannerTitle;

        // Gesetzt von Program.Main, wenn der Tray das Fenster nach einem Klick auf die
        // Update-Sprechblase gestartet hat (Argument --update).
        internal bool OpenUpdateOnStart;

        // Hinweis oben auf der Startseite. Unsichtbar, bis ein Update bekannt ist.
        private void BuildUpdateBanner(TableLayoutPanel page)
        {
            updateBannerRow = AddActionRow(page, "Eine neue Version ist verfügbar",
                "Hier siehst du, was neu ist, und kannst sie installieren.",
                "Ansehen", delegate { CheckAndShowUpdate(); }, false);
            updateBannerRow.Visible = false;
            TableLayoutPanel copy = updateBannerRow.GetControlFromPosition(0, 0) as TableLayoutPanel;
            updateBannerTitle = copy == null ? null : copy.GetControlFromPosition(0, 0) as Label;
        }

        // Liest den Zustand und zeigt oder versteckt den Hinweis. Auf dem
        // Ablaufbildschirm gibt es keinen Hinweis, dort passiert nichts.
        private void ApplyUpdateBanner()
        {
            if (updateBannerRow == null)
            {
                return;
            }

            UpdateState state = UpdateClient.LoadState(UpdateClient.StatePath);
            bool known = Support.IsUpdateNewer(state.LastSeenVersion);
            if (known && updateBannerTitle != null)
            {
                Ui.SetDynamicText(updateBannerTitle, "Version " + state.LastSeenVersion + " ist verfügbar", "Update");
            }

            updateBannerRow.Visible = known;
        }

        // Beim Oeffnen des Fensters: alte Download-Ordner wegraeumen, den Hinweis
        // zeigen, einen Klick auf die Sprechblase einloesen und sonst hoechstens
        // einmal am Tag still nachsehen (deckt Nutzer ohne Tray ab).
        private void RunUpdateStartupTasks()
        {
            ApplyUpdateBanner();

            if (OpenUpdateOnStart)
            {
                // Der Klick auf die Sprechblase (Argument --update) wartet auf uns.
                OpenUpdateOnStart = false;
                CheckAndShowUpdate();
                return;
            }

            UpdateState state = UpdateClient.LoadState(UpdateClient.StatePath);
            bool dueCheck = Support.ShouldCheckForUpdate(DateTime.UtcNow, state);
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    UpdateClient.CleanupOldDownloads(UpdateClient.DownloadRoot, Support.AppVersion);
                    if (dueCheck)
                    {
                        UpdateClient.CheckNow(UpdateClient.StatePath, Support.UpdateBase(), null, DateTime.UtcNow, false);
                        if (IsHandleCreated && !IsDisposed)
                        {
                            BeginInvoke(new Action(ApplyUpdateBanner));
                        }
                    }
                }
                catch
                {
                }
            });
        }

        // Fragt den Server jetzt (Knopf, Hinweis, Sprechblase) - ohne den
        // 24-Stunden-Takt. Nur hier erscheinen Netzfehler und "kein Update" als
        // Meldung; der stille Takt im Hintergrund meldet nichts.
        private void CheckAndShowUpdate()
        {
            UpdateCheckResult result = null;
            RunAction("Update-Suche", delegate
            {
                result = UpdateClient.CheckNow(UpdateClient.StatePath, Support.UpdateBase(), null, DateTime.UtcNow, true);
            }, delegate (bool success)
            {
                if (!success || result == null)
                {
                    return;
                }

                ApplyUpdateBanner();
                if (result.Outcome == UpdateCheckOutcome.Available)
                {
                    ShowUpdateDialog(result.Manifest);
                }
                else if (result.Outcome == UpdateCheckOutcome.UpToDate)
                {
                    Ui.Inform(this, theme, "Updates", "Purestate " + Support.AppVersion + " ist aktuell.");
                }
                else
                {
                    Ui.Inform(this, theme, "Updates", result.Message);
                }
            });
        }

        // "Zur neuen Fassung" auf dem Bildschirm "Beta beendet": erst nach einem
        // Update fragen. Nur wenn keines bekannt ist (zum Beispiel ohne Netz), geht
        // es wie bisher auf die Website.
        private void CheckForNewVersionOrOpenWebsite()
        {
            UpdateCheckResult result = null;
            RunAction("Update-Suche", delegate
            {
                result = UpdateClient.CheckNow(UpdateClient.StatePath, Support.UpdateBase(), null, DateTime.UtcNow, true);
            }, delegate (bool success)
            {
                if (success && result != null && result.Outcome == UpdateCheckOutcome.Available)
                {
                    ShowUpdateDialog(result.Manifest);
                    return;
                }

                Process.Start(new ProcessStartInfo("https://purestate-app.com/") { UseShellExecute = true });
            });
        }

        private void ShowUpdateDialog(UpdateManifest manifest)
        {
            string message =
                "Version " + manifest.Version + " vom " + FormatUpdateDate(manifest.Date) +
                " ist verfügbar. Installiert ist " + Support.AppVersion + "." +
                Environment.NewLine + Environment.NewLine +
                manifest.Notes.Replace("\n", Environment.NewLine) +
                Environment.NewLine + Environment.NewLine +
                "Purestate lädt die Datei von purestate-app.com, prüft sie und startet den Installer. " +
                "Er fragt wie bei jedem Update nach deinem Purestate-Passwort.";

            if (Ui.Confirm(this, theme, "Neue Version " + manifest.Version, message, "Jetzt installieren", "Später"))
            {
                InstallUpdate(manifest);
                return;
            }

            // Später: die Sprechblase meldet sich in 24 Stunden wieder, der Hinweis
            // auf der Startseite bleibt.
            UpdateState state = UpdateClient.LoadState(UpdateClient.StatePath);
            Support.MarkUpdateLater(state, manifest.Version, DateTime.UtcNow);
            UpdateClient.SaveState(UpdateClient.StatePath, state);
        }

        private void InstallUpdate(UpdateManifest manifest)
        {
            string installerPath = null;
            RunAction("Update laden und prüfen", delegate
            {
                Support.EnsureDataDir();
                installerPath = UpdateClient.DownloadAndPrepare(manifest, UpdateClient.DownloadRoot, ShowUpdateProgress);
            }, delegate (bool success)
            {
                if (!success)
                {
                    return;
                }

                try
                {
                    UpdateClient.StartInstaller(installerPath);
                    ShowSaveFeedback("Der Installer wurde gestartet. Er fragt nach deinem Purestate-Passwort.");
                }
                catch (Exception ex)
                {
                    Ui.Inform(this, theme, "Update",
                        "Der Installer konnte nicht gestartet werden. Es wurde nichts installiert." +
                        Environment.NewLine + Environment.NewLine + ex.Message);
                }
            }, delegate (Exception failure)
            {
                Ui.Inform(this, theme, "Update", UpdateClient.DescribeFailure(failure));
            });
        }

        // Aus dem Arbeitsthread: Schritt (Laden, Pruefen, Entpacken) im Statushinweis.
        private void ShowUpdateProgress(string step)
        {
            try
            {
                BeginInvoke(new Action(delegate
                {
                    if (statusHintLabel != null)
                    {
                        Ui.SetDynamicText(statusHintLabel, step + " ...", "Statushinweis");
                    }
                }));
            }
            catch
            {
            }
        }

        private static string FormatUpdateDate(string isoDate)
        {
            DateTime date;
            return DateTime.TryParseExact(isoDate, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date)
                ? date.ToString("dd.MM.yyyy", CultureInfo.InvariantCulture)
                : isoDate;
        }
    }
}
