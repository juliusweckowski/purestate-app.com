using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.Installer
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            if (!Support.IsAdministrator())
            {
                try
                {
                    Support.RelaunchElevated(string.Empty);
                }
                catch
                {
                    MessageBox.Show("Bitte starte die Installation mit Administrator-Rechten.", "Purestate Installation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new InstallerForm());
        }
    }

    internal sealed class InstallerForm : Form
    {
        // Same light-theme palette as Purestate.exe's main window (navy/
        // enterprise, see PurestateApp.cs ThemeColors.Light) - duplicated here
        // rather than shared, because Installieren.exe/PurestateUninstaller.exe
        // are compiled as separate executables from PurestateApp.cs (see
        // tools\Build-Release.ps1) and never had shared UI code with it even
        // before this pass. Keeping the same concrete values is what matters for
        // a consistent look, not a shared class.
        private static readonly Color WindowBackground = Color.FromArgb(247, 248, 250);
        private static readonly Color TextPrimary = Color.FromArgb(15, 23, 42);
        private static readonly Color TextSecondary = Color.FromArgb(85, 96, 107);
        private static readonly Color Border = Color.FromArgb(226, 229, 234);
        private static readonly Color ButtonBackground = Color.White;
        private static readonly Color StatusActive = Color.FromArgb(21, 128, 61);
        private static readonly Color DangerRed = Color.FromArgb(185, 28, 28);

        // Rounds a control's corners via a clipping Region - same technique as
        // PurestateApp.cs's ApplyRoundedCorners, duplicated for the same reason
        // as the palette above.
        private static void ApplyRoundedCorners(Control control, int radius)
        {
            if (control.Width <= 0 || control.Height <= 0)
            {
                return;
            }
            var path = new System.Drawing.Drawing2D.GraphicsPath();
            Rectangle bounds = new Rectangle(0, 0, control.Width, control.Height);
            int d = radius * 2;
            path.AddArc(bounds.X, bounds.Y, d, d, 180, 90);
            path.AddArc(bounds.Right - d, bounds.Y, d, d, 270, 90);
            path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            control.Region = new Region(path);
        }

        private static Color MixColor(Color from, Color to, int percentTo)
        {
            int p = Math.Max(0, Math.Min(100, percentTo));
            return Color.FromArgb(
                from.R + ((to.R - from.R) * p / 100),
                from.G + ((to.G - from.G) * p / 100),
                from.B + ((to.B - from.B) * p / 100));
        }

        private static Color HoverBackground(Color normal)
        {
            if (!normal.Equals(ButtonBackground))
            {
                return MixColor(normal, Color.Black, 8);
            }
            return MixColor(normal, Color.FromArgb(231, 237, 243), 65);
        }

        private static Color PressedBackground(Color normal)
        {
            if (!normal.Equals(ButtonBackground))
            {
                return MixColor(normal, Color.Black, 16);
            }
            return MixColor(normal, Color.FromArgb(231, 237, 243), 90);
        }

        private static void WireButtonFeedback(Button button, int normalBorderSize, Color normalBack, Color normalFore, Color normalBorder)
        {
            button.FlatAppearance.MouseOverBackColor = HoverBackground(normalBack);
            button.FlatAppearance.MouseDownBackColor = PressedBackground(normalBack);
            button.MouseEnter += delegate
            {
                if (button.Enabled)
                {
                    button.BackColor = HoverBackground(normalBack);
                }
            };
            button.MouseLeave += delegate
            {
                if (!button.Focused)
                {
                    button.BackColor = normalBack;
                    button.ForeColor = normalFore;
                }
            };
            button.MouseDown += delegate
            {
                if (button.Enabled)
                {
                    button.BackColor = PressedBackground(normalBack);
                }
            };
            button.MouseUp += delegate
            {
                if (button.Enabled)
                {
                    button.BackColor = button.ClientRectangle.Contains(button.PointToClient(Cursor.Position))
                        ? HoverBackground(normalBack)
                        : normalBack;
                }
            };
            button.Enter += delegate
            {
                button.FlatAppearance.BorderSize = Math.Max(normalBorderSize, 2);
                button.FlatAppearance.BorderColor = Color.FromArgb(30, 58, 95);
                button.BackColor = HoverBackground(normalBack);
                button.ForeColor = normalFore;
            };
            button.Leave += delegate
            {
                button.FlatAppearance.BorderSize = normalBorderSize;
                button.FlatAppearance.BorderColor = normalBorder;
                button.BackColor = normalBack;
                button.ForeColor = normalFore;
            };
        }

        private static string CleanMnemonic(string text)
        {
            return (text ?? string.Empty).Replace("&", string.Empty).Trim();
        }

        private static void ConfigureFormAccessibility(Form form, string name, string description)
        {
            form.AutoScaleMode = AutoScaleMode.Dpi;
            form.AccessibleName = name;
            form.AccessibleDescription = description;
            form.AccessibleRole = AccessibleRole.Window;
        }

        private static void ConfigureControlAccessibility(Control control, string name, string description, AccessibleRole role)
        {
            control.AccessibleName = name;
            control.AccessibleDescription = description;
            control.AccessibleRole = role;
        }

        private static void ConfigureButtonAccessibility(Button button, string description)
        {
            ConfigureControlAccessibility(button, CleanMnemonic(button.Text), description, AccessibleRole.PushButton);
        }

        private static void StyleSecondaryButton(Button button)
        {
            button.FlatStyle = FlatStyle.Flat;
            button.BackColor = ButtonBackground;
            button.ForeColor = TextPrimary;
            button.FlatAppearance.BorderSize = 1;
            button.FlatAppearance.BorderColor = Border;
            ApplyRoundedCorners(button, 4);
            if (string.IsNullOrEmpty(button.AccessibleName))
            {
                ConfigureButtonAccessibility(button, CleanMnemonic(button.Text) + " ausführen.");
            }
            WireButtonFeedback(button, 1, ButtonBackground, TextPrimary, Border);
        }

        private readonly TextBox tokenBox;
        private readonly TextBox passwordBox;
        private readonly TextBox repeatBox;
        private readonly TextBox hintBox;
        private readonly Label statusLabel;
        private readonly Button preflightButton;
        private readonly Button installButton;
        private readonly Button closeButton;

        public InstallerForm()
        {
            AppConfig existingConfig = File.Exists(Support.ConfigPath) ? Support.LoadConfig() : null;
            bool hasExistingPassword = existingConfig != null && existingConfig.Password != null;
            string productName = "Purestate " + Support.AppVersion;

            Text = productName + " installieren";
            ConfigureFormAccessibility(this, productName + " installieren", "Installiert, aktualisiert oder repariert Purestate mit geschütztem Passwort.");
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = true;
            ClientSize = new Size(620, 464);
            Font = new Font("Segoe UI", 10);
            BackColor = WindowBackground;

            Label title = new Label();
            title.Text = productName + " installieren";
            // 17pt semibold instead of 21pt bold - a marketing-hero-sized title
            // reads as a consumer installer, not a Windows admin/security tool.
            title.Font = new Font("Segoe UI", 17, FontStyle.Bold);
            title.ForeColor = TextPrimary;
            title.Location = new Point(26, 22);
            title.Size = new Size(500, 38);
            Controls.Add(title);

            Label subtitle = new Label();
            subtitle.Text = hasExistingPassword
                ? "Purestate wird repariert oder aktualisiert. Dafür wird das bestehende Purestate-Passwort benötigt."
                : "Der Schutzdienst wird installiert und mit einem Passwort geschützt. Der Vorabcheck ändert nichts.";
            subtitle.ForeColor = TextSecondary;
            subtitle.Location = new Point(30, 72);
            // Zwei Zeilen Segoe UI 10 brauchen 38 px; bei 34 zeichnete das Label
            // die zweite Zeile gar nicht ("benötigt." fehlte, VM 2026-09-28).
            subtitle.Size = new Size(560, 40);
            Controls.Add(subtitle);

            Label tokenLabel = new Label();
            tokenLabel.Text = "Freischaltcode";
            tokenLabel.ForeColor = TextPrimary;
            // Die Unterzeile bricht in 560 px auf zwei Zeilen um und belegt
            // y 72-112; sie wird zuerst hinzugefuegt und zeichnet damit ueber
            // allem, was sich mit ihr ueberschneidet. Die Freischaltzeile
            // beginnt deshalb erst darunter, in derselben Spalte wie die
            // uebrigen Feldbeschriftungen (x = 32).
            tokenLabel.Location = new Point(32, 121);
            tokenLabel.Size = new Size(150, 24);
            Controls.Add(tokenLabel);

            tokenBox = new TextBox();
            tokenBox.Location = new Point(190, 118);
            tokenBox.Size = new Size(360, 25);
            tokenBox.TabIndex = 0;
            ConfigureControlAccessibility(tokenBox, "Freischaltcode",
                "Der Code aus deiner Beta-Einladung. Für die Freischaltung wird einmalig eine Internetverbindung gebraucht.", AccessibleRole.Text);
            Controls.Add(tokenBox);
            tokenBox.Visible = !hasExistingPassword;
            tokenLabel.Visible = !hasExistingPassword;

            Label passLabel = new Label();
            passLabel.Text = hasExistingPassword ? "Purestate-Passwort" : "Passwort";
            passLabel.ForeColor = TextPrimary;
            passLabel.Location = new Point(32, 160);
            passLabel.Size = new Size(150, 24);
            Controls.Add(passLabel);

            passwordBox = new TextBox();
            passwordBox.Location = new Point(190, 157);
            passwordBox.Size = new Size(360, 25);
            passwordBox.UseSystemPasswordChar = true;
            passwordBox.TabIndex = 1;
            ConfigureControlAccessibility(passwordBox, hasExistingPassword ? "Purestate-Passwort" : "Passwort", "Purestate Passwort eingeben.", AccessibleRole.Text);
            Controls.Add(passwordBox);

            Label repeatLabel = new Label();
            repeatLabel.Text = hasExistingPassword ? "Nur bei Neuinstallation" : "Wiederholen";
            repeatLabel.ForeColor = TextPrimary;
            repeatLabel.Location = new Point(32, 198);
            repeatLabel.Size = new Size(150, 24);
            Controls.Add(repeatLabel);

            repeatBox = new TextBox();
            repeatBox.Location = new Point(190, 195);
            repeatBox.Size = new Size(360, 25);
            repeatBox.UseSystemPasswordChar = true;
            repeatBox.Enabled = !hasExistingPassword;
            repeatBox.TabIndex = 2;
            ConfigureControlAccessibility(repeatBox, "Passwort wiederholen", "Neues Purestate Passwort erneut eingeben.", AccessibleRole.Text);
            Controls.Add(repeatBox);

            Label hintLabel = new Label();
            hintLabel.Text = "Hinweis";
            hintLabel.ForeColor = TextPrimary;
            hintLabel.Location = new Point(32, 236);
            hintLabel.Size = new Size(150, 24);
            Controls.Add(hintLabel);

            hintBox = new TextBox();
            hintBox.Location = new Point(190, 233);
            hintBox.Size = new Size(360, 25);
            hintBox.MaxLength = 120;
            hintBox.Text = hasExistingPassword ? existingConfig.PasswordHint : string.Empty;
            hintBox.TabIndex = 3;
            ConfigureControlAccessibility(hintBox, "Passworthinweis", "Optionaler lokaler Hinweis für das Purestate Passwort.", AccessibleRole.Text);
            Controls.Add(hintBox);

            statusLabel = new Label();
            statusLabel.Text = "Bereit.";
            statusLabel.Location = new Point(32, 286);
            statusLabel.Size = new Size(560, 58);
            statusLabel.ForeColor = TextSecondary;
            ConfigureControlAccessibility(statusLabel, "Installationsstatus", "Zeigt den aktuellen Installations- oder Vorabcheck-Status.", AccessibleRole.StatusBar);
            Controls.Add(statusLabel);

            preflightButton = new Button();
            preflightButton.Text = "Vorabcheck";
            preflightButton.Location = new Point(32, 396);
            preflightButton.Size = new Size(130, 40);
            preflightButton.TabIndex = 4;
            ConfigureButtonAccessibility(preflightButton, "Führt einen Vorabcheck des Installationspakets aus.");
            preflightButton.Click += PreflightButton_Click;
            StyleSecondaryButton(preflightButton);
            Controls.Add(preflightButton);

            installButton = new Button();
            installButton.Text = hasExistingPassword ? "Aktualisieren" : "Installieren";
            installButton.Location = new Point(174, 396);
            installButton.Size = new Size(130, 40);
            installButton.BackColor = StatusActive;
            installButton.ForeColor = Color.White;
            installButton.FlatStyle = FlatStyle.Flat;
            installButton.FlatAppearance.BorderSize = 0;
            installButton.TabIndex = 5;
            ConfigureButtonAccessibility(installButton, hasExistingPassword ? "Aktualisiert oder repariert Purestate." : "Installiert Purestate und aktiviert den Schutz.");
            installButton.Click += InstallButton_Click;
            ApplyRoundedCorners(installButton, 4);
            WireButtonFeedback(installButton, 0, StatusActive, Color.White, StatusActive);
            Controls.Add(installButton);

            Button openButton = new Button();
            openButton.Text = "App öffnen";
            openButton.Location = new Point(316, 396);
            openButton.Size = new Size(130, 40);
            openButton.TabIndex = 6;
            ConfigureButtonAccessibility(openButton, "Öffnet die installierte Purestate App.");
            openButton.Click += delegate { OpenInstalledApp(); };
            StyleSecondaryButton(openButton);
            Controls.Add(openButton);

            closeButton = new Button();
            closeButton.Text = "Schließen";
            closeButton.Location = new Point(458, 396);
            closeButton.Size = new Size(130, 40);
            closeButton.TabIndex = 7;
            ConfigureButtonAccessibility(closeButton, "Schließt den Installer.");
            closeButton.Click += delegate { Close(); };
            StyleSecondaryButton(closeButton);
            Controls.Add(closeButton);

            // Im Aktualisierungspfad ist tokenBox unsichtbar, und Focus() auf
            // einem unsichtbaren Feld ist wirkungslos - der Pfad hatte damit
            // gar keinen Anfangsfokus mehr.
            Shown += delegate { (hasExistingPassword ? (Control)passwordBox : tokenBox).Focus(); };
        }

        // PRC-002: Der Vorabcheck startet drei PowerShell-Selbsttests. Auf dem
        // UI-Thread hiess das im schlechtesten Fall ein eingefrorenes Fenster
        // ohne Rueckmeldung. Er laeuft deshalb im Hintergrund, das Ergebnis
        // kommt ueber BeginInvoke zurueck.
        private void PreflightButton_Click(object sender, EventArgs e)
        {
            preflightButton.Enabled = false;
            Cursor = Cursors.WaitCursor;
            statusLabel.ForeColor = TextSecondary;
            statusLabel.Text = "Vorabcheck läuft...";
            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                string report = null;
                string error = null;
                try
                {
                    report = Support.BuildPackagePreflightReport(baseDirectory);
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                }

                try
                {
                    if (IsHandleCreated && !IsDisposed)
                    {
                        BeginInvoke(new Action(delegate { ShowPreflightResult(report, error); }));
                    }
                }
                catch
                {
                }
            });
        }

        private void ShowPreflightResult(string report, string error)
        {
            preflightButton.Enabled = true;
            Cursor = Cursors.Default;

            if (report == null)
            {
                statusLabel.ForeColor = DangerRed;
                statusLabel.Text = "Vorabcheck fehlgeschlagen.";
                MessageBox.Show(error ?? "Der Vorabcheck konnte nicht ausgeführt werden.", "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            bool ok = report.IndexOf("Status: OK", StringComparison.OrdinalIgnoreCase) >= 0;
            statusLabel.ForeColor = ok ? StatusActive : DangerRed;
            statusLabel.Text = ok
                ? "Vorabcheck OK. Die Installation kann gestartet werden."
                : "Vorabcheck fertig. Bitte Bericht prüfen.";
            ShowReportDialog("Purestate Vorabcheck", report);
        }

        private void InstallButton_Click(object sender, EventArgs e)
        {
            string password = passwordBox.Text;
            string repeat = repeatBox.Text;
            string hint = hintBox.Text;
            AppConfig existingConfig = File.Exists(Support.ConfigPath) ? Support.LoadConfig() : null;

            // A compromised config refuses every password by design, so the
            // generic "wrong password" message would be misleading. Tell the
            // user the config is damaged/tampered and how to recover instead.
            if (existingConfig != null && existingConfig.IntegrityCompromised)
            {
                Support.WriteSecurityLog("Install refused: config integrity compromised.");
                MessageBox.Show(
                    "Die vorhandene Purestate-Konfiguration ist beschädigt oder wurde außerhalb der App verändert und ist gesperrt. " +
                    "Ein Aktualisieren ist deshalb nicht möglich (auch das Passwort wird abgelehnt)." + Environment.NewLine + Environment.NewLine +
                    "So richtest du Purestate neu ein: Starte zuerst" + Environment.NewLine +
                    Path.Combine(Support.InstallDir, "PurestateUninstaller.exe") + Environment.NewLine +
                    "und bestätige dort das vollständige Entfernen. Danach diese Installation erneut starten." + Environment.NewLine + Environment.NewLine +
                    "Lösche die Purestate-Ordner NICHT von Hand. Nur der Deinstaller nimmt die Systemänderungen zurück " +
                    "(hosts-Eintrag, erzwungenes DNS, Proxy, Firewall-Regeln, Browser-Richtlinien); von Hand gelöscht bleiben sie " +
                    "stehen, und die DNS-Sicherung im Datenordner wäre mit gelöscht." + Environment.NewLine + Environment.NewLine +
                    "Deine Domains/Einstellungen gehen dabei verloren; der Schutz wird neu aufgesetzt.",
                    "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool hasExistingPassword = existingConfig != null && existingConfig.Password != null;

            if (hasExistingPassword)
            {
                int lockoutRemaining;
                PasswordCheckResult check = Support.VerifyPasswordThrottled(password, out lockoutRemaining);
                if (check == PasswordCheckResult.LockedOut)
                {
                    Support.WriteSecurityLog("Password locked out: Aktualisieren");
                    MessageBox.Show("Zu viele Fehlversuche. Bitte warte etwa " + Math.Max(1, (lockoutRemaining + 59) / 60) + " Minute(n) und versuche es erneut.", "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (check != PasswordCheckResult.Success)
                {
                    Support.WriteSecurityLog("Password rejected: Aktualisieren");
                    MessageBox.Show("Das bestehende Purestate-Passwort ist falsch.", "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Support.WriteSecurityLog("Password accepted: Aktualisieren");
                password = string.Empty;
            }
            else
            {
                string passwordPolicyError = Support.GetPasswordPolicyError(password, hint);
                if (!string.IsNullOrEmpty(passwordPolicyError))
                {
                    MessageBox.Show(passwordPolicyError, "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!string.Equals(password, repeat, StringComparison.Ordinal))
                {
                    MessageBox.Show("Die Passwörter stimmen nicht überein.", "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            // Erst einloesen, dann einrichten. Schlaegt die Einloesung fehl,
            // bleibt der Rechner unangetastet: kein Dienst, keine Aufgabe,
            // keine Konfiguration, keine Erweiterung, keine Firewallregel.
            string entitledUntil = string.Empty;
            int entitlementMaxDevices = 0;
            string entitlementSignature = string.Empty;

            if (!hasExistingPassword)
            {
                // Dieselbe Grenze und derselbe Text wie in der Verwaltung
                // (SettingsPage.EnrollAuthorityDevice). Ohne sie loeste eine
                // Neuinstallation nach dem Schnitt den Code noch ein - und
                // verbrannte einen der zwei Geraeteplaetze, weil ein neuer
                // Rechner einen neuen Geraeteschluessel bedeutet - um danach
                // am Paket-Selbsttest mit "Schedule self-test failed" zu
                // scheitern, was dem Tester nichts sagt.
                if (Support.IsBuildExpired(existingConfig))
                {
                    MessageBox.Show(
                        "Diese Beta-Fassung ist beendet und lässt sich nicht mehr freischalten. " +
                        "Bitte lade die neue Fassung von purestate-app.com.",
                        "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string token = tokenBox.Text.Trim();
                if (token.Length == 0)
                {
                    MessageBox.Show("Bitte gib den Freischaltcode aus deiner Beta-Einladung ein.", "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string tokenError;
                if (!Support.TryRedeemToken(token, out entitledUntil, out entitlementMaxDevices, out entitlementSignature, out tokenError))
                {
                    MessageBox.Show(
                        "Der Freischaltcode konnte nicht eingelöst werden." + Environment.NewLine + Environment.NewLine +
                        tokenError + Environment.NewLine + Environment.NewLine +
                        "Für die Freischaltung wird einmalig eine Internetverbindung gebraucht. " +
                        "Es wurde nichts installiert.",
                        "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Der Server loest auch einen Code ein, dessen Termin schon
                // verstrichen ist. Eingerichtet gaebe der Ablauf den Rechner im
                // ersten Takt wieder frei.
                if (Support.IsRedeemedEntitlementExpiredAt(entitledUntil, Support.TrustedUtcNow(existingConfig)))
                {
                    MessageBox.Show(
                        "Dieser Freischaltcode ist abgelaufen. Melde dich, wenn du weitermachen möchtest." + Environment.NewLine + Environment.NewLine +
                        "Es wurde nichts installiert.",
                        "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            installButton.Enabled = false;
            Cursor = Cursors.WaitCursor;

            try
            {
                Support.WriteSecurityLog("Install or update started.");
                // Haelt den Watchdog fuer die Dauer des Laufs zurueck. Ohne das
                // liest er mitten im Kopieren eine schon migrierte
                // Konfiguration mit noch alten Skripten und schreibt einen
                // Integritaets-Fehlalarm ins security.log.
                Support.BeginInstallWindow();
                bool protectionApplied = Install(password, hint, entitledUntil, entitlementMaxDevices, entitlementSignature);
                Support.WriteSecurityLog(protectionApplied
                    ? "Install or update completed."
                    : "Install or update completed; protection is still applying.");
                statusLabel.ForeColor = StatusActive;
                statusLabel.Text = protectionApplied
                    ? "Fertig. Purestate ist installiert und aktiv."
                    : "Purestate ist installiert. Schutz wird im Hintergrund weiter angewendet.";

                // Der Installer hat den laufenden Tray beendet (CloseRunningInstalledUtilities);
                // ohne diesen Start fehlte das Symbol bis zur naechsten Anmeldung.
                Support.TryStartTrayTask();

                // Auto-launch the installed app and close the installer so a
                // successful install needs no further clicks. A pending
                // installer self-replacement still just closes here; the
                // replacement runs on exit as before.
                // Bei ausstehendem Aufbau bleibt die Rueckmeldung sichtbar.
                if (protectionApplied)
                {
                    LaunchInstalledApp();
                    Close();
                }
            }
            catch (Exception ex)
            {
                Support.WriteSecurityLog("Install or update failed: " + ex.GetType().Name);
                // A failure may have already stopped the previous protection.
                // Try to bring it back so the machine is not left unprotected.
                bool restored = Support.TryRestoreProtectionAfterFailedInstall();
                statusLabel.ForeColor = DangerRed;
                statusLabel.Text = restored
                    ? "Installation fehlgeschlagen. Vorheriger Schutz wurde reaktiviert."
                    : "Installation fehlgeschlagen.";
                string message = restored
                    ? ex.Message + Environment.NewLine + Environment.NewLine +
                      "Der zuvor installierte Schutz wurde wieder aktiviert."
                    : ex.Message;
                MessageBox.Show(message, "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Error);
                installButton.Enabled = true;
            }
            finally
            {
                // Auch im Fehlerfall: ein liegengebliebener Marker wuerde den
                // Watchdog bremsen. Er laeuft ohnehin nach
                // InstallWindowMinutes ab, aber erst gar nicht liegenbleiben
                // ist besser.
                Support.EndInstallWindow();
                Cursor = Cursors.Default;
            }
        }

        private bool Install(string password, string hint, string entitledUntilUtc,
            int entitlementMaxDevices, string entitlementSignature)
        {
            bool freshInstall = !File.Exists(Support.ConfigPath);
            string sourceDir = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
            string destinationDir = Support.InstallDir.TrimEnd(Path.DirectorySeparatorChar);

            // Verify the package is complete BEFORE tearing down the running
            // service. If the source is incomplete/corrupt we abort here and the
            // existing protection is left fully intact instead of being stopped
            // in favour of a broken half-install.
            statusLabel.Text = "Installationspaket wird geprüft...";
            Application.DoEvents();
            Support.VerifyInstallSource(sourceDir);

            // Refuse a downgrade BEFORE tearing down the running protection: an
            // older package must not replace a newer install, or a user could
            // roll back past a fixed bypass. The existing protection is left
            // fully intact. Legitimate rollback goes through Deinstall first
            // (password + cooldown), which clears the recorded floor.
            if (File.Exists(Support.ConfigPath))
            {
                AppConfig installedConfig = Support.LoadConfig();
                if (installedConfig != null && !installedConfig.IntegrityCompromised &&
                    Support.IsInstallDowngrade(Support.AppVersion, installedConfig.InstalledVersion))
                {
                    throw new InvalidOperationException(
                        "Es ist bereits eine neuere Purestate-Version (" + installedConfig.InstalledVersion +
                        ") installiert. Ein Herabstufen auf " + Support.AppVersion +
                        " ist nicht möglich. Zum Zurückstufen bitte Purestate zuerst deinstallieren.");
                }
            }

            statusLabel.Text = "Laufende Purestate-Komponenten werden beendet...";
            Application.DoEvents();

            Support.CancelPendingInstallerReplacements(sourceDir);
            Support.CloseRunningInstalledUtilities();
            Support.CloseRunningDesktopApp();
            Support.StopService();
            Support.DeleteServiceIfExists();

            if (!string.Equals(sourceDir, destinationDir, StringComparison.OrdinalIgnoreCase))
            {
                statusLabel.Text = "Dateien werden kopiert...";
                Application.DoEvents();
                Support.CopyDirectory(sourceDir, destinationDir);
            }

            if (!File.Exists(Path.Combine(Support.InstallDir, "PurestateGuard.exe")))
            {
                throw new InvalidOperationException("PurestateGuard.exe wurde nicht gefunden.");
            }

            statusLabel.Text = "Passwort und Schutzdaten werden vorbereitet...";
            Application.DoEvents();

            Support.EnsureDataDir();
            Support.TightenDataFolderAcl();
            Support.TightenInstallFolderAcl();
            Support.UpdateConfig(delegate (AppConfig config)
            {
                // Vor dem Ueberschreiben: die bisherige Version bleibt fuer die
                // Dauer der Store-Pruefung als Companion zugelassen.
                Support.StartCompanionGrace(config, Support.AppVersion, Support.TrustedUtcNow(config));
                Support.ApplyInstallerConfig(config, freshInstall);

                // Nur bei einer frischen Installation gesetzt (config.Password
                // ist hier noch null) - bei einer Aktualisierung bleiben die
                // Freischaltfelder unberuehrt, statt mit den fuer diesen Aufruf
                // leeren Parametern ueberschrieben zu werden.
                //
                // Bewusst OHNE config.AuthorityMode = Support.AuthorityModeServer:
                // der Servermodus ersetzt die lokale Siebentagefrist fuer
                // Abschwaechungen durch ein serverbestaetigtes 72-Stunden-Fenster
                // OHNE Offline-Rueckfall. Ein Serverausfall hiesse damit, dass
                // kein Tester mehr irgendetwas lockern kann, unbegrenzt lange -
                // und der Freischaltcode waere genau die zusaetzliche
                // Schutzschicht gegen den Nutzer im Rueckfallmoment, die
                // Abschnitt 1 der Spezifikation ausschliesst. Die Ablaufregel
                // braucht den Servermodus nicht: IsEntitlementExpiredAt prueft
                // AuthorityMode gar nicht, und die Freischaltzeilen erscheinen
                // schon, sobald AuthorityBaseUrl gefuellt ist.
                if (config.Password == null)
                {
                    Support.ApplyRedeemedEntitlement(config, entitledUntilUtc, entitlementMaxDevices, entitlementSignature);
                }

                if (!string.IsNullOrEmpty(password) || config.Password == null)
                {
                    Support.EnsurePasswordPolicy(password, hint);
                    config.Password = Support.NewPasswordRecord(password);
                }

                // INS-005: Frueher stand hier "nur schreiben, wenn ein Hinweis
                // eingegeben wurde oder es noch kein Passwort gab". Das
                // Eingabefeld ist aber mit dem bestehenden Hinweis vorbelegt -
                // wer ihn leerte und speicherte, bei dem blieb der alte stehen.
                // Ausgerechnet ein zu verraeterischer Hinweis liess sich damit
                // hier nicht mehr loswerden. Das Feld zeigt den aktuellen
                // Stand, also gilt auch, was darin steht: nichts.
                config.PasswordHint = Support.CleanPasswordHint(hint);
            });
            Support.RemoveObsoletePersonalSupportData();

            statusLabel.Text = "Windows-Dienst wird eingerichtet...";
            Application.DoEvents();

            Support.CreateService();
            Support.RegisterNativeMessagingHost();
            Support.RegisterWatchdogTask();

            statusLabel.Text = "Schutz wird aktiviert...";
            Application.DoEvents();

            bool protectionApplied = Support.ActivateInstalledProtection();
            Support.CreateShortcuts();
            Support.RegisterAppEntry();
            Support.RegisterUserStartupEntry();
            return protectionApplied;
        }

        private void OpenInstalledApp()
        {
            string app = Path.Combine(Support.InstallDir, "Purestate.exe");
            if (!File.Exists(app))
            {
                MessageBox.Show("Die App ist noch nicht installiert.", "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            System.Diagnostics.Process.Start(app);
        }

        // Silent post-install launch: never blocks the auto-close with a dialog.
        // A failed launch is non-fatal - the install already succeeded and the
        // Start-menu shortcut remains.
        private void LaunchInstalledApp()
        {
            try
            {
                string app = Path.Combine(Support.InstallDir, "Purestate.exe");
                if (File.Exists(app))
                {
                    // Nicht im Ordner des Installers: bei einem Update liegt er unter
                    // update\<Version>, und die App hielte ihn als Arbeitsverzeichnis fest.
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(app)
                    {
                        WorkingDirectory = Support.InstallDir
                    });
                }
            }
            catch
            {
            }
        }

        private void ShowReportDialog(string title, string report)
        {
            using (Form dialog = new Form())
            {
                dialog.Text = title;
                ConfigureFormAccessibility(dialog, title, "Zeigt einen kopierbaren Purestate Bericht.");
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.Size = new Size(760, 560);
                dialog.MinimizeBox = false;
                dialog.MaximizeBox = true;
                dialog.Font = new Font("Segoe UI", 10);
                dialog.BackColor = WindowBackground;

                TextBox reportBox = new TextBox();
                reportBox.Multiline = true;
                reportBox.ReadOnly = true;
                reportBox.ScrollBars = ScrollBars.Both;
                reportBox.WordWrap = false;
                reportBox.Font = new Font("Consolas", 9);
                reportBox.ForeColor = TextPrimary;
                reportBox.Dock = DockStyle.Fill;
                reportBox.Text = report;
                reportBox.TabIndex = 0;
                ConfigureControlAccessibility(reportBox, title + " Bericht", "Berichtstext zum Lesen und Kopieren.", AccessibleRole.Text);
                dialog.Controls.Add(reportBox);

                FlowLayoutPanel buttons = new FlowLayoutPanel();
                buttons.Dock = DockStyle.Bottom;
                buttons.Height = 52;
                buttons.FlowDirection = FlowDirection.RightToLeft;
                buttons.Padding = new Padding(10);
                buttons.BackColor = WindowBackground;
                dialog.Controls.Add(buttons);

                Button close = new Button();
                close.Text = "Schließen";
                close.Size = new Size(120, 32);
                close.TabIndex = 2;
                close.DialogResult = DialogResult.Cancel;
                ConfigureButtonAccessibility(close, "Schließt den Bericht.");
                close.Click += delegate { dialog.Close(); };
                dialog.CancelButton = close;
                StyleSecondaryButton(close);
                buttons.Controls.Add(close);

                Button copy = new Button();
                copy.Text = "Kopieren";
                copy.Size = new Size(120, 32);
                copy.TabIndex = 1;
                ConfigureButtonAccessibility(copy, "Kopiert den Bericht in die Zwischenablage.");
                copy.Click += delegate
                {
                    Clipboard.SetText(report);
                    // PRIV-009: Die Meldung sagte nur, DASS kopiert wurde, nicht
                    // WAS. Der Bericht traegt Programm- und Domainnamen aus dem
                    // Protokoll; das gehoert in den Moment vor dem Verschicken.
                    MessageBox.Show(
                        "Bericht wurde kopiert." + Environment.NewLine + Environment.NewLine +
                        "Er enthält den Zustand deines Geräts, Auszüge aus dem Protokoll sowie " +
                        "Programm- und Domainnamen. Bitte lies ihn durch, bevor du ihn weitergibst.",
                        "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                };
                StyleSecondaryButton(copy);
                buttons.Controls.Add(copy);

                dialog.Shown += delegate { reportBox.Focus(); };
                dialog.ShowDialog(this);
            }
        }
    }
}
