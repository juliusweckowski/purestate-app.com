using System;
using System.Drawing;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // Protection areas page: five rows, each with a plain-language effect
    // description, the current state, and one clear "Einstellen" action.
    internal sealed partial class AdminForm
    {
        private void BuildProtectionAreasPage()
        {
            TableLayoutPanel page = CreatePage("areas");
            AddPageTitle(page, "Schutzbereiche");
            AddPageHint(page, "Wähle einen Bereich und klicke auf „Einstellen“. Zum Ansehen brauchst du kein Passwort - erst beim Speichern von Änderungen.");

            AddAreaRow(page, Support.AreaAdultContent,
                "Blockiert Pornografie-Webseiten und erzwingt die sichere Suche.",
                delegate { ShowSiteProtectionSettings(); });
            AddAreaRow(page, Support.AreaGambling,
                "Sperrt Glücksspiel-Webseiten vollständig oder begrenzt die Zeit dort.",
                delegate { ShowGamblingProtectionSettings(); });
            AddAreaRow(page, Support.AreaShopping,
                "Hilft mit Wartezeiten und Zeitlimits gegen Impulskäufe.",
                delegate { ShowShoppingProtectionSettings(); });
            AddAreaRow(page, Support.AreaSocialMedia,
                "Begrenzt die Zeit auf sozialen Netzwerken oder sperrt einzelne Plattformen.",
                delegate { ShowSocialMediaSettings(); });
            AddAreaRow(page, Support.AreaVideoGames,
                "Begrenzt die Spielzeit oder sperrt ausgewählte Spiele.",
                delegate { ShowVideoGamesSettings(); });

            AddSectionTitle(page, "Hilfe");
            AddActionRow(page, "Informationen und Hilfe anzeigen",
                "Was Purestate technisch kann und wo es professionelle Unterstützung gibt.",
                "Anzeigen", delegate { ShowInformationAndHelp(); }, false);
        }

        private void AddAreaRow(TableLayoutPanel page, string areaId, string effectText, EventHandler onConfigure)
        {
            string displayName = AreaDisplayName(areaId);

            RoundCard row = new RoundCard
            {
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 2,
                Margin = new Padding(0, 0, 0, Ui.GapGroup),
                Padding = new Padding(Ui.GapGroup)
            };
            Ui.StyleCard(theme, row);
            Ui.FitToPageColumn(row, 112);
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            row.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            Ui.SetAccessibility(row, displayName, "Schutzbereich " + displayName + " mit Status und Einstellen-Aktion.", AccessibleRole.Grouping);

            Label title = new Label
            {
                Text = displayName,
                Font = Ui.FontRowTitle,
                ForeColor = theme.TextPrimary,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 2)
            };
            Ui.SetAccessibility(title, displayName, displayName, AccessibleRole.StaticText);
            row.Controls.Add(title, 0, 0);

            Label effect = new Label
            {
                Text = effectText,
                Font = Ui.FontHint,
                ForeColor = theme.TextSecondary,
                AutoSize = true,
                // Umbruch an der verfuegbaren Spaltenbreite (DESK-02).
                Anchor = AnchorStyles.Left | AnchorStyles.Right,
                Margin = new Padding(0, 0, 0, 4)
            };
            Ui.SetAccessibility(effect, effectText, effectText, AccessibleRole.StaticText);
            row.Controls.Add(effect, 0, 1);

            Label status = new Label
            {
                Text = "wird ermittelt ...",
                Font = Ui.FontBody,
                ForeColor = theme.TextPrimary,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 0)
            };
            Ui.SetAccessibility(status, displayName + " Status", "Aktueller Zustand: " + displayName + ".", AccessibleRole.StaticText);
            row.Controls.Add(status, 0, 2);
            areaPageStatusLabels[areaId] = status;

            Button configure = Ui.SecondaryButton(theme, "Einstellen", displayName + " ansehen und einstellen.");
            configure.Margin = new Padding(Ui.GapGroup, Ui.GapSmall, 0, 0);
            configure.Click += onConfigure;
            row.Controls.Add(configure, 1, 0);
            row.SetRowSpan(configure, 3);
            configure.Anchor = AnchorStyles.Right;
            actionButtons.Add(configure);

            page.Controls.Add(row);
            themeAppliers.Add(delegate
            {
                Ui.StyleCard(theme, row);
                title.ForeColor = theme.TextPrimary;
                effect.ForeColor = theme.TextSecondary;
                status.ForeColor = theme.TextPrimary;
                Ui.StyleSecondary(theme, configure);
            });
        }

        private void ShowInformationAndHelp()
        {
            ShowTextDialog("Informationen und Hilfe", Support.BuildInformationAndHelpText(), false);
        }
    }
}
