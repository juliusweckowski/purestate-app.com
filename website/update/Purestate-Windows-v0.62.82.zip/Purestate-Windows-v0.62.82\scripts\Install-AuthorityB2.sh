#!/usr/bin/env bash
# Credentials are read from /dev/tty, never command arguments or shell history.
set -euo pipefail
umask 077
[[ $EUID -eq 0 && ( $# -eq 1 || ( $# -eq 2 && $2 == --replace-key ) ) ]] || { echo 'Usage: sudo bash Install-AuthorityB2.sh Upload-AuthorityBackups.sh [--replace-key]' >&2; exit 1; }
source_script=$(realpath -- "$1")
bash -n "$source_script"
systemctl is-enabled --quiet purestate-backup.timer
if ! command -v rclone >/dev/null; then
    apt-get update
    apt-get install -y rclone
fi
install -d -o root -g root -m 0700 /etc/purestate-b2
python3 - "${2:-}" <<'PY'
import getpass, os, pathlib, re, sys, tempfile, warnings
warnings.simplefilter('error', getpass.GetPassWarning)
path = pathlib.Path('/etc/purestate-b2/rclone.conf')
if path.exists() or path.is_symlink():
    if path.is_symlink() or path.stat().st_uid != 0 or path.stat().st_mode & 0o077:
        raise SystemExit('Existing B2 config has unsafe permissions.')
if path.exists() and sys.argv[1] != '--replace-key':
    print('Using existing protected B2 configuration.')
else:
    key_id = getpass.getpass('B2 keyID (hidden): ').strip()
    key = getpass.getpass('B2 applicationKey (hidden): ').strip()
    if not re.fullmatch(r'[A-Za-z0-9]+', key_id) or not re.fullmatch(r'[A-Za-z0-9+/=_-]+', key):
        raise SystemExit('Invalid key format; configuration was not saved.')
    fd, temporary = tempfile.mkstemp(prefix='.config-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as f:
            f.write('[b2]\ntype = b2\naccount = ' + key_id + '\nkey = ' + key + '\n')
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    print('B2 configuration saved with root-only permissions.')
PY
install -o root -g root -m 0700 "$source_script" /usr/local/sbin/purestate-upload-backups
cat > /etc/systemd/system/purestate-b2.service <<'UNIT'
[Unit]
Description=Copy encrypted Purestate snapshots to Backblaze B2
Wants=network-online.target
After=network-online.target purestate-backup.service

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/purestate-upload-backups
TimeoutStartSec=20min
UMask=0077
Nice=10
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=strict
ReadWritePaths=/run
UNIT
cat > /etc/systemd/system/purestate-b2.timer <<'UNIT'
[Unit]
Description=Hourly retry of encrypted Purestate B2 backup transfer

[Timer]
OnCalendar=*-*-* *:40:00 Europe/Berlin
RandomizedDelaySec=5min
Persistent=true
Unit=purestate-b2.service

[Install]
WantedBy=timers.target
UNIT
chmod 0644 /etc/systemd/system/purestate-b2.service /etc/systemd/system/purestate-b2.timer
systemd-analyze verify /etc/systemd/system/purestate-b2.service /etc/systemd/system/purestate-b2.timer
systemctl daemon-reload
# Start the first transfer before enabling unattended operation.
if ! systemctl start purestate-b2.service; then
    echo 'First B2 upload failed. Inspect: sudo journalctl -u purestate-b2.service -n 25 --no-pager' >&2
    exit 1
fi
systemctl enable --now purestate-b2.timer
systemctl list-timers purestate-b2.timer --no-pager
echo 'B2 timer enabled. A downloaded archive must still be tested for recovery.'
