using System;
using System.ComponentModel;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace Purestate.Native
{
    internal enum UpdateCheckOutcome
    {
        Skipped,
        Failed,
        Invalid,
        UpToDate,
        Available
    }

    internal sealed class UpdateCheckResult
    {
        public UpdateCheckOutcome Outcome = UpdateCheckOutcome.Failed;
        public UpdateManifest Manifest;
        public string Message = string.Empty;
    }

    // Eine Meldung, die der Nutzer lesen darf (kein Typname, kein Stapel).
    internal sealed class UpdateException : Exception
    {
        public UpdateException(string message) : base(message)
        {
        }
    }

    // Netz und Ablage der Update-Suche. Nur die App: diese Datei steht in keiner
    // Compile-Liste des Guard oder des Native Host, ein Quelltext-Vertrag in
    // tests\Purestate.Tests.ps1 haelt das fest. Der Guard bleibt netzfrei.
    internal static class UpdateClient
    {
        private const int TimeoutMs = 15000;
        private const int SmallFileDeadlineSeconds = 30;
        private const int ZipDeadlineSeconds = 300;
        private const int SignatureMaxBytes = 2048;
        private const long DefaultMaxExtractedBytes = 200L * 1024 * 1024;

        // Eine Naht fuer die Tests: sie schreiben sonst in das echte security.log.
        internal static Action<string> SecurityLog = Support.WriteSecurityLog;

        public static string StatePath
        {
            get
            {
                return Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Purestate", "update-state.json");
            }
        }

        public static string DownloadRoot
        {
            get { return Path.Combine(Support.DataDir, "update"); }
        }

        // ---- Zustand ------------------------------------------------------------

        public static UpdateState LoadState(string path)
        {
            try
            {
                return File.Exists(path)
                    ? Support.ParseUpdateState(File.ReadAllText(path, Encoding.UTF8))
                    : new UpdateState();
            }
            catch
            {
                return new UpdateState();
            }
        }

        // Atomar: Temp-Datei im selben Ordner, dann umbenennen und dabei ersetzen. Ein
        // Abbruch mittendrin laesst die alte Datei stehen statt eine halbe. Nicht
        // File.Replace: bei gleichzeitigem Schreiben (Tray und Verwaltungsfenster)
        // liess es eigene ~RF*.TMP-Reste mit dem alten Zustand liegen.
        public static void SaveState(string path, UpdateState state)
        {
            string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                File.WriteAllText(temp, Support.FormatUpdateState(state), new UTF8Encoding(false));
                if (!MoveFileEx(temp, path, MoveFileReplaceExisting))
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error());
                }
            }
            catch
            {
                try { File.Delete(temp); } catch { }
            }
        }

        private const int MoveFileReplaceExisting = 1;

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern bool MoveFileEx(string existingFileName, string newFileName, int flags);

        // ---- Suche --------------------------------------------------------------

        // Ein Durchlauf: holen, pruefen, Zustand fortschreiben. force = der Nutzer
        // hat gefragt, dann gilt der 24-Stunden-Takt nicht. publicKeys = null
        // nimmt die eingebauten Schluessel (nur Tests geben eigene mit).
        public static UpdateCheckResult CheckNow(string statePath, string baseUrl, string[] publicKeys,
            DateTime nowUtc, bool force)
        {
            UpdateState state = LoadState(statePath);
            if (!force && !Support.ShouldCheckForUpdate(nowUtc, state))
            {
                UpdateCheckResult skipped = new UpdateCheckResult();
                skipped.Outcome = UpdateCheckOutcome.Skipped;
                return skipped;
            }

            UpdateCheckResult result = Fetch(baseUrl, publicKeys);
            if (result.Outcome == UpdateCheckOutcome.Failed)
            {
                // Zustand unveraendert: der naechste Takt versucht es wieder.
                return result;
            }

            state.LastCheckUtc = nowUtc;
            if (result.Outcome == UpdateCheckOutcome.Available)
            {
                state.LastSeenVersion = result.Manifest.Version;
            }
            else if (result.Outcome == UpdateCheckOutcome.UpToDate)
            {
                state.LastSeenVersion = string.Empty;
            }
            else
            {
                SecurityLog("Update information from the website did not verify and was ignored.");
            }

            SaveState(statePath, state);
            return result;
        }

        internal static UpdateCheckResult Fetch(string baseUrl, string[] publicKeys)
        {
            UpdateCheckResult result = new UpdateCheckResult();
            byte[] manifestBytes;
            byte[] signatureBytes;
            try
            {
                manifestBytes = HttpGet(baseUrl + Support.UpdateManifestFile, Support.UpdateManifestMaxBytes, SmallFileDeadlineSeconds);
                signatureBytes = HttpGet(baseUrl + Support.UpdateSignatureFile, SignatureMaxBytes, SmallFileDeadlineSeconds);
            }
            catch (Exception)
            {
                result.Outcome = UpdateCheckOutcome.Failed;
                result.Message = "Purestate konnte den Update-Server nicht erreichen. Prüfe die Internetverbindung.";
                return result;
            }

            // Eine Anmeldeseite im WLAN (Captive Portal) antwortet mit HTML statt JSON.
            // Das ist weder ein Angriff noch eine kaputte Veroeffentlichung, sondern
            // nur kein Netz: still wiederholen, nichts protokollieren.
            if (manifestBytes.Length == 0 || manifestBytes[0] != (byte)'{')
            {
                result.Outcome = UpdateCheckOutcome.Failed;
                result.Message = "Purestate konnte den Update-Server nicht erreichen. Prüfe die Internetverbindung.";
                return result;
            }

            // Reihenfolge: erst die Signatur ueber die rohen Bytes, dann Form und
            // Adresse. Eine Datei, die nicht vom Betreiber stammt, wird nie gelesen.
            string signature = Encoding.ASCII.GetString(signatureBytes);
            bool signed = publicKeys == null
                ? Support.VerifyUpdateSignature(manifestBytes, signature)
                : Support.VerifyUpdateSignature(manifestBytes, signature, publicKeys);

            UpdateManifest manifest = null;
            if (!signed || !Support.TryParseUpdateManifest(manifestBytes, baseUrl, out manifest))
            {
                result.Outcome = UpdateCheckOutcome.Invalid;
                result.Message = "Die Update-Information ist ungültig und wurde ignoriert.";
                return result;
            }

            result.Manifest = manifest;
            result.Outcome = Support.IsUpdateNewer(manifest.Version)
                ? UpdateCheckOutcome.Available
                : UpdateCheckOutcome.UpToDate;
            return result;
        }

        // Keine Weiterleitung, hoechstens maxBytes, harte Gesamtfrist. Der
        // User-Agent ist neutral und traegt keine Version.
        private static byte[] HttpGet(string url, int maxBytes, int deadlineSeconds)
        {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";
            request.Timeout = TimeoutMs;
            request.ReadWriteTimeout = TimeoutMs;
            request.AllowAutoRedirect = false;
            request.UserAgent = "Purestate";

            DateTime deadline = DateTime.UtcNow.AddSeconds(deadlineSeconds);
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    throw new InvalidDataException("Unerwarteter HTTP-Status " + (int)response.StatusCode + ".");
                }

                if (response.ContentLength > maxBytes)
                {
                    throw new InvalidDataException("Die Antwort ist groesser als erlaubt.");
                }

                using (Stream stream = response.GetResponseStream())
                using (MemoryStream buffer = new MemoryStream())
                {
                    byte[] chunk = new byte[16 * 1024];
                    int read;
                    while ((read = stream.Read(chunk, 0, chunk.Length)) > 0)
                    {
                        if (buffer.Length + read > maxBytes)
                        {
                            throw new InvalidDataException("Die Antwort ist groesser als erlaubt.");
                        }

                        if (DateTime.UtcNow > deadline)
                        {
                            throw new TimeoutException("Der Abruf dauert zu lange.");
                        }

                        buffer.Write(chunk, 0, read);
                    }

                    return buffer.ToArray();
                }
            }
        }

        // ---- Download und Vorbereitung ----------------------------------------------

        // Laedt das Paket, prueft Groesse und SHA-256 gegen die signierte Datei,
        // entpackt nach <updateRoot>\<Version> und liefert den Pfad zu
        // Installieren.exe. Nur im erhoehten Verwaltungsfenster aufrufen: der
        // Ordner gehoert den Administratoren, niemand kann die Dateien zwischen
        // Pruefung und Start austauschen. Bei jedem Fehler bleibt nichts liegen.
        public static string DownloadAndPrepare(UpdateManifest manifest, string updateRoot, Action<string> progress)
        {
            return DownloadAndPrepare(manifest, updateRoot, progress, DefaultMaxExtractedBytes);
        }

        internal static string DownloadAndPrepare(UpdateManifest manifest, string updateRoot, Action<string> progress,
            long maxExtractedBytes)
        {
            if (manifest == null)
            {
                throw new ArgumentNullException("manifest");
            }

            Report(progress, "Update wird geladen");
            byte[] zip = HttpGet(manifest.ZipUrl, (int)manifest.ZipSize, ZipDeadlineSeconds);

            Report(progress, "Update wird geprüft");
            if (zip.LongLength != manifest.ZipSize ||
                !string.Equals(Sha256Hex(zip), manifest.ZipSha256, StringComparison.OrdinalIgnoreCase))
            {
                throw new UpdateException("Die heruntergeladene Datei stimmt nicht mit der Prüfsumme überein. Es wurde nichts installiert.");
            }

            Report(progress, "Update wird entpackt");
            Directory.CreateDirectory(updateRoot);
            Support.EnsureDirectoryIsNotReparsePoint(updateRoot);
            string target = Path.Combine(updateRoot, manifest.Version);
            if (Directory.Exists(target))
            {
                Support.EnsureDirectoryIsNotReparsePoint(target);
                Directory.Delete(target, true);
            }

            Directory.CreateDirectory(target);
            try
            {
                ExtractZip(zip, target, maxExtractedBytes);
                string installer = FindInstaller(target);
                if (installer == null)
                {
                    throw new UpdateException("Das Paket enthält keinen Installer. Es wurde nichts installiert.");
                }

                return installer;
            }
            catch
            {
                try { Directory.Delete(target, true); } catch { }
                throw;
            }
        }

        // Build-Release.ps1 packt den Paketordner (Purestate-Windows-vX) mit
        // Compress-Archive: Installieren.exe liegt eine Ebene unter dem Versionsordner.
        // Ein flaches ZIP legt sie direkt hinein. Zwei Paketordner mit Installer sind
        // mehrdeutig - dann gilt das Paket als ohne Installer.
        private static string FindInstaller(string target)
        {
            string flat = Path.Combine(target, "Installieren.exe");
            if (File.Exists(flat))
            {
                return flat;
            }

            string found = null;
            foreach (string directory in Directory.GetDirectories(target))
            {
                string candidate = Path.Combine(directory, "Installieren.exe");
                if (!File.Exists(candidate))
                {
                    continue;
                }

                if (found != null)
                {
                    return null;
                }

                found = candidate;
            }

            return found;
        }

        // Eigene Schleife statt ExtractToDirectory: kein Eintrag darf ausserhalb des
        // Zielordners landen (".." oder absolute Pfade), nichts wird ueberschrieben
        // (doppelte Namen brechen ab), und die Gesamtgroesse ist gedeckelt. Nur
        // System.IO.Compression.dll, kein FileSystem-Zusatz.
        internal static void ExtractZip(byte[] zip, string targetDir, long maxExtractedBytes)
        {
            string root = Path.GetFullPath(targetDir).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            long total = 0;
            using (ZipArchive archive = new ZipArchive(new MemoryStream(zip), ZipArchiveMode.Read))
            {
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    string destination = Path.GetFullPath(Path.Combine(targetDir, entry.FullName));
                    if (!destination.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                    {
                        throw new UpdateException("Das Paket enthält einen ungültigen Pfad. Es wurde nichts installiert.");
                    }

                    if (entry.FullName.EndsWith("/", StringComparison.Ordinal) ||
                        entry.FullName.EndsWith("\\", StringComparison.Ordinal))
                    {
                        Directory.CreateDirectory(destination);
                        continue;
                    }

                    Directory.CreateDirectory(Path.GetDirectoryName(destination));
                    using (Stream input = entry.Open())
                    using (FileStream output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    {
                        byte[] chunk = new byte[64 * 1024];
                        int read;
                        while ((read = input.Read(chunk, 0, chunk.Length)) > 0)
                        {
                            total += read;
                            if (total > maxExtractedBytes)
                            {
                                throw new UpdateException("Das Paket ist entpackt unerwartet groß. Es wurde nichts installiert.");
                            }

                            output.Write(chunk, 0, read);
                        }
                    }
                }
            }
        }

        // Der Installer fragt wie bei jedem Update nach dem Purestate-Passwort.
        public static void StartInstaller(string installerPath)
        {
            System.Diagnostics.ProcessStartInfo info = new System.Diagnostics.ProcessStartInfo();
            info.FileName = installerPath;
            info.WorkingDirectory = Path.GetDirectoryName(installerPath);
            info.UseShellExecute = true;
            System.Diagnostics.Process.Start(info);
        }

        // Beim Start des Verwaltungsfensters: Ordner der installierten oder aelterer
        // Versionen entfernen. Ein noch ausstehendes (neueres) Update bleibt. Was
        // sich nicht loeschen laesst (laufender Installer), raeumt der naechste
        // Start auf.
        public static void CleanupOldDownloads(string updateRoot, string installedVersion)
        {
            try
            {
                if (!Directory.Exists(updateRoot))
                {
                    return;
                }

                // Eine Verknuepfung als Update-Ordner wird nie durchlaufen: der erhoehte
                // Prozess loeschte sonst im Ziel rekursiv alles, was nicht wie eine
                // neuere Version heisst (DownloadAndPrepare lehnt sie aus demselben
                // Grund ab).
                if ((File.GetAttributes(updateRoot) & FileAttributes.ReparsePoint) != 0)
                {
                    return;
                }

                foreach (string directory in Directory.GetDirectories(updateRoot))
                {
                    if (Support.IsUpdateNewer(Path.GetFileName(directory), installedVersion))
                    {
                        continue;
                    }

                    try
                    {
                        if ((File.GetAttributes(directory) & FileAttributes.ReparsePoint) == 0)
                        {
                            Directory.Delete(directory, true);
                        }
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }
        }

        public static string DescribeFailure(Exception failure)
        {
            UpdateException known = failure as UpdateException;
            if (known != null)
            {
                return known.Message;
            }

            if (failure is WebException || failure is TimeoutException)
            {
                return "Der Download ist fehlgeschlagen. Prüfe die Internetverbindung. Es wurde nichts installiert.";
            }

            if (failure is IOException || failure is UnauthorizedAccessException)
            {
                return "Der Update-Ordner ist nicht beschreibbar oder die Platte ist voll. Es wurde nichts installiert.";
            }

            return "Das Update konnte nicht vorbereitet werden. Es wurde nichts installiert.";
        }

        private static string Sha256Hex(byte[] data)
        {
            using (SHA256 sha = SHA256.Create())
            {
                return BitConverter.ToString(sha.ComputeHash(data)).Replace("-", string.Empty).ToLowerInvariant();
            }
        }

        private static void Report(Action<string> progress, string text)
        {
            if (progress != null)
            {
                progress(text);
            }
        }
    }
}
