using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // Adult-content / per-site browser protection: one clear list of supported
    // websites, each with an on/off switch. Technical notes live behind
    // "Technische Details anzeigen".
    internal sealed partial class AdminForm
    {
        private void ShowSiteProtectionSettings()
        {
            AppConfig config = Support.LoadConfig();
            using (DialogShell shell = new DialogShell(theme, "Erwachseneninhalte und Browser-Schutz",
                "Der Browser-Schutz entfernt nicht jugendfreie Inhalte auf unterstützten Webseiten und erzwingt die sichere Suche. Haken bedeutet: die Webseite ist geschützt.",
                "Schaltet den Browser-Schutz für einzelne Webseiten an oder aus.", true))
            {
                shell.Kicker = "Schutzbereich";
                CheckBox adultEnabled = Ui.Check(theme, "Erwachseneninhalte-Schutz einschalten", config.AdultContentProtectionEnabled,
                    "Schaltet den Schutz vor Erwachseneninhalten an oder aus. Die Webseiten-Filter unten wirken nur, wenn er an ist.");
                shell.Add(adultEnabled);
                shell.AddSection("Unterstützte Webseiten");

                List<CheckBox> boxes = new List<CheckBox>();
                TableLayoutPanel siteGrid = new TableLayoutPanel
                {
                    AutoSize = true,
                    AutoSizeMode = AutoSizeMode.GrowAndShrink,
                    ColumnCount = 2,
                    Dock = DockStyle.Top,
                    Margin = new Padding(0),
                    RowCount = 0
                };
                siteGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
                siteGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
                Action<string, bool> addSite = delegate (string label, bool isChecked)
                {
                    CheckBox box = Ui.Check(theme, label, isChecked, "Browser-Schutz für " + label + " an- oder ausschalten.");
                    box.Dock = DockStyle.Fill;
                    boxes.Add(box);
                    siteGrid.Controls.Add(box, (boxes.Count - 1) % 2, (boxes.Count - 1) / 2);
                };

                addSite("Reddit", config.SiteRedditEnabled);
                addSite("X / Twitter", config.SiteXEnabled);
                addSite("Bluesky", config.SiteBlueskyEnabled);
                addSite("Tumblr", config.SiteTumblrEnabled);
                addSite("DeviantArt", config.SiteDeviantArtEnabled);
                addSite("pixiv", config.SitePixivEnabled);
                addSite("Newgrounds", config.SiteNewgroundsEnabled);
                addSite("Imgur", config.SiteImgurEnabled);
                addSite("Instagram", config.SiteInstagramEnabled);
                addSite("TikTok", config.SiteTikTokEnabled);
                addSite("Pinterest", config.SitePinterestEnabled);
                shell.Add(siteGrid);

                LinkLabel techDetails = new LinkLabel
                {
                    Text = "Technische Details anzeigen",
                    AutoSize = true,
                    LinkColor = theme.Accent,
                    Font = Ui.FontHint,
                    Margin = new Padding(0, Ui.GapGroup, 0, 0)
                };
                Ui.SetAccessibility(techDetails, "Technische Details anzeigen", "Erklärt, wie der Browser-Schutz technisch funktioniert.", AccessibleRole.Link);
                techDetails.LinkClicked += delegate
                {
                    ShowTextDialog("Technische Details zum Browser-Schutz",
                        "So funktioniert der Browser-Schutz technisch:" + Environment.NewLine + Environment.NewLine +
                        "- Eine Browser-Erweiterung (Companion) filtert Inhalte direkt auf den unterstützten Webseiten." + Environment.NewLine +
                        "- Zusätzlich wirken unabhängig davon: lokale Sperrliste (Hosts), DNS-Inhaltsfilter und Umgehungsschutz." + Environment.NewLine +
                        "- Diese Schalter steuern nur die Feinfilterung pro Webseite; die Grundsperren bleiben unberührt." + Environment.NewLine +
                        "- Browser ohne erzwingbare Erweiterung können unter Einstellungen > Internetschutz gesperrt werden.", false);
                };
                shell.Add(techDetails);

                shell.AddSection("Selbst erkannte Seiten");
                shell.AddHint("Purestate erkennt manche Erwachsenenseiten automatisch am Inhalt. Wurde eine harmlose Seite gesperrt, kannst du sie hier freigeben. Die Freigabe wird in 15 Minuten wirksam. Eine Rücknahme wirkt sofort.");

                FlowLayoutPanel learnedList = new FlowLayoutPanel
                {
                    FlowDirection = FlowDirection.TopDown,
                    AutoSize = true,
                    AutoSizeMode = AutoSizeMode.GrowAndShrink,
                    WrapContents = false,
                    Width = shell.InnerWidth,
                    Margin = new Padding(0)
                };
                Label learnedEmpty = Ui.WrapLabel(theme, "Es wurden bisher keine Webseiten automatisch erkannt.", shell.InnerWidth, true);
                Label learnedError = shell.AddErrorLine();

                Action refreshLearned = null;
                refreshLearned = delegate
                {
                    learnedList.Controls.Clear();
                    DateTime nowUtc = Support.TrustedUtcNow();
                    List<AdultLearnedExemption> exemptions = Support.ReadAdultLearnedExemptions();
                    bool any = false;

                    foreach (string learnedHost in Support.ReadLearnedAdultDomains())
                    {
                        AdultLearnedExemption existing = null;
                        foreach (AdultLearnedExemption candidate in exemptions)
                        {
                            if (string.Equals(candidate.Host, learnedHost, StringComparison.OrdinalIgnoreCase) &&
                                (Support.IsAdultLearnedExemptionEffective(candidate, nowUtc) ||
                                candidate.ActivatesAtUtc.ToUniversalTime() > nowUtc))
                            {
                                existing = candidate;
                                break;
                            }
                        }

                        any = true;
                        string labelText = learnedHost;
                        if (existing != null)
                        {
                            // Eine bereits wirksame Freigabe steht noch in der gelernten
                            // Datei (die schreibt nur der Companion), sperrt aber
                            // nirgends mehr - Get-LearnedAdultDomains zieht sie ab.
                            // Trotzdem anzeigen: sonst gibt es fuer sie keinen
                            // Ruecknahme-Weg mehr, obwohl der Hinweistext genau das
                            // verspricht.
                            labelText += existing.ActivatesAtUtc <= nowUtc
                                ? " (freigegeben)"
                                : " (wirksam ab " + existing.ActivatesAtUtc.ToLocalTime().ToString("g") + ")";
                        }
                        Label hostLabel = Ui.WrapLabel(theme, labelText, 420, false);
                        string capturedHost = learnedHost;

                        if (existing == null)
                        {
                            Button freeButton = Ui.SecondaryButton(theme, "Freigeben",
                                "Nimmt " + learnedHost + " von der Erwachsenen-Erkennung aus. Braucht das Passwort, wirkt nach 15 Minuten. Danach gilt sie 30 Tage.");
                            freeButton.Click += delegate
                            {
                                if (!ConfirmPassword("Erwachsenen-Freigabe hinzufügen", shell))
                                {
                                    return;
                                }

                                string addError = string.Empty;
                                if (!TryListChange(shell, learnedError, freeButton, delegate { addError = Support.AddAdultLearnedExemption(capturedHost); }))
                                {
                                    return;
                                }
                                if (addError.Length != 0)
                                {
                                    shell.ShowError(learnedError, addError, freeButton);
                                    return;
                                }

                                shell.ClearError(learnedError);
                                refreshLearned();
                                ShowSaveFeedback("Die Webseite ist in 15 Minuten freigegeben. Danach gilt sie 30 Tage.");
                            };
                            learnedList.Controls.Add(shell.Row(hostLabel, freeButton));
                        }
                        else
                        {
                            // Zuruecknehmen ist eine Verstaerkung: kein Passwort, keine
                            // Frist, wirkt sofort - wie bei der Gluecksspiel-Freigabe.
                            Button withdrawButton = Ui.SecondaryButton(theme, "Freigabe entfernen",
                                "Nimmt die Freigabe fuer " + learnedHost + " zurueck. Wirkt sofort, kein Passwort noetig.");
                            withdrawButton.Click += delegate
                            {
                                if (!TryListChange(shell, learnedError, withdrawButton, delegate { Support.RemoveAdultLearnedExemption(capturedHost); }))
                                {
                                    return;
                                }
                                shell.ClearError(learnedError);
                                refreshLearned();
                                ShowSaveFeedback("Die Freigabe wurde entfernt.");
                            };
                            learnedList.Controls.Add(shell.Row(hostLabel, withdrawButton));
                        }
                    }

                    learnedList.Visible = any;
                    learnedEmpty.Visible = !any;
                };
                refreshLearned();

                shell.Add(learnedEmpty);
                shell.Add(learnedList);

                shell.SaveButton.Click += delegate
                {
                    bool adultChecked = adultEnabled.Checked;
                    bool redditChecked = boxes[0].Checked;
                    bool xChecked = boxes[1].Checked;
                    bool blueskyChecked = boxes[2].Checked;
                    bool tumblrChecked = boxes[3].Checked;
                    bool deviantArtChecked = boxes[4].Checked;
                    bool pixivChecked = boxes[5].Checked;
                    bool newgroundsChecked = boxes[6].Checked;
                    bool imgurChecked = boxes[7].Checked;
                    bool instagramChecked = boxes[8].Checked;
                    bool tikTokChecked = boxes[9].Checked;
                    bool pinterestChecked = boxes[10].Checked;

                    if (!ConfirmPassword("Webseiten-Schutz speichern", shell))
                    {
                        return;
                    }

                    RunAction("Webseiten-Schutz speichern", shell, delegate
                    {
                        Support.SetSiteProtectionSettingsGuarded(adultChecked, redditChecked, xChecked, blueskyChecked, tumblrChecked, deviantArtChecked, pixivChecked, newgroundsChecked, imgurChecked, instagramChecked, tikTokChecked, pinterestChecked, Support.TrustedLocalNow(), false);
                        Support.ReapplyProtection();
                    }, "Browser-Schutz: Änderungen gespeichert.");
                };

                shell.FinishLayout();
                shell.Shown += delegate { boxes[0].Focus(); };
                shell.ShowDialog(this);
            }
        }
    }
}
