"use strict";

// Purestate Imgur companion.
//
// Imgur is a mixed site (general meme/image hosting with a large NSFW-tagged
// subset), so we keep safe content usable and layer two protections. Built
// from live real-DOM inspection of a logged-in account (2026-07-01).
//
// Secondary protection — account setting: the account settings page
// (/account/settings) exposes a single native checkbox `#show_mature`
// ("Show mature posts and comments"), wrapped in a plain <form> with an
// `<input type="submit" value="Save">` - unlike Tumblr/pixiv there is NO
// auto-save, the change only persists after Save is clicked (mirrors the
// DeviantArt Safe-Mode model). We keep it unchecked and click Save whenever it
// is found checked.
//
// IMPORTANT (verified live 2026-07-01): unchecking this setting does NOT
// filter dedicated adult tag pages like /t/nsfw - a full page of unblurred
// NSFW art still rendered there with the setting off. It only affects the
// general/algorithmic feed. So this account setting is belt-and-suspenders
// here, not the primary defense.
//
// Primary protection — adult tag/search URL blocking: Imgur tag pages
// (/t/<tag>) are single-purpose galleries (a tag either IS the adult topic or
// isn't - there is no per-item filtering to preserve), and search results
// carry the query in `?q=`. Both are checked against the shared adult-term
// list and blocked with the shared full-page overlay, the same mechanism
// already used for Reddit/pixiv/Newgrounds.
//
// Scope note: Imgur exposes no per-thumbnail maturity marker in the DOM
// (verified live: no mature/nsfw data-* attributes anywhere in the gallery
// grid, no window.__NEXT_DATA__ or similar embedded state blob), so a
// per-item backstop is not possible - mirrors the DeviantArt/pixiv scope note.

const IMGUR_INSTANT_STYLE_ID = "purestate-imgur-instant-style";
const IMGUR_SEARCH_OVERLAY_ID = "purestate-imgur-search-overlay";

let imgurObserver = null;
let imgurScanTimer = 0;
let imgurInterval = 0;
let lastImgurLocation = "";
let imgurLastEnforceClick = 0;

purestateRunWhenSiteProtectionEnabled("imgur", () => {
  installImgurInstantHide();
  installImgurLockStyle();
  installImgurSettingsGuard();
  installImgurMonitoring();
});

// Make the "Show mature posts and comments" checkbox (and its label) literally
// un-clickable via CSS, so the user cannot even begin to toggle it on. The
// capture-phase guard stays as a backstop, and our enforcement uses a
// programmatic .click() which pointer-events:none does not block.
function installImgurLockStyle() {
  purestateInjectStyle(
    document,
    "purestate-imgur-lock-style",
    '#show_mature,label[for="show_mature"]{pointer-events:none !important;cursor:not-allowed !important;}'
  );
}

// At document_start: block an adult tag/search URL outright so nothing flashes
// before the overlay is built.
function installImgurInstantHide() {
  if (!document.documentElement) {
    return;
  }
  if (imgurAdultSearchTerm()) {
    purestateInstantHide(document, IMGUR_INSTANT_STYLE_ID);
  }
}

// Extracts the adult search/tag term from an Imgur URL: the ?q= search query
// or the /t/<tag> tag-page path segment. Returns "" when neither is adult.
function imgurAdultSearchTerm() {
  try {
    const url = new URL(location.href);
    if (!/(^|\.)imgur\.com$/i.test(url.hostname)) {
      return "";
    }
    const candidates = [url.searchParams.get("q") || ""];
    const tagMatch = url.pathname.match(/^\/t\/([^/?#]+)/i);
    if (tagMatch) {
      candidates.push(decodeURIComponent(tagMatch[1]).replace(/[-_+]/g, " "));
    }
    for (const value of candidates) {
      if (value && purestateIsAdultSearchText(value)) {
        return value;
      }
    }
  } catch {
  }
  return "";
}

// Block an adult tag/search term with the shared full-page overlay. Returns
// true when the current URL is a blocked adult tag/search.
function applyImgurSearchBlock() {
  if (imgurAdultSearchTerm()) {
    purestateInstantHide(document, IMGUR_INSTANT_STYLE_ID);
    purestateShowSearchOverlay(
      document,
      IMGUR_SEARCH_OVERLAY_ID,
      "Diese Imgur-Seite wurde durch Purestate blockiert."
    );
    return true;
  }
  purestateHideSearchOverlay(document, IMGUR_SEARCH_OVERLAY_ID, IMGUR_INSTANT_STYLE_ID);
  return false;
}

function installImgurMonitoring() {
  applyImgurSearchBlock();
  enforceImgurSettings(document);
  imgurObserver = new MutationObserver(() => scheduleImgurScan());
  imgurObserver.observe(document.documentElement, { childList: true, subtree: true });
  imgurInterval = setInterval(() => {
    // Imgur is a client-routed SPA: catch tag/search navigation that never
    // reloads the page.
    const current = location.href;
    if (current !== lastImgurLocation) {
      lastImgurLocation = current;
      applyImgurSearchBlock();
    }
    enforceImgurSettings(document);
    observeImgurCanary();
  }, 1000);
}

// Selector canary (diagnostics only, see purestateCanaryObserve): when this
// document IS the account-settings page, the #show_mature checkbox must
// exist. 15 consecutive 1s-tick misses report a selector break.
function observeImgurCanary() {
  purestateCanaryObserve(
    "imgur",
    "show-mature-checkbox",
    /^\/account\/settings/i.test(location.pathname || ""),
    !!(document.getElementById && document.getElementById("show_mature"))
  );
}

function scheduleImgurScan() {
  clearTimeout(imgurScanTimer);
  imgurScanTimer = setTimeout(() => {
    applyImgurSearchBlock();
    enforceImgurSettings(document);
  }, 80);
}

// --- Account setting enforcement (secondary layer) --------------------------

// Finds the Save submit button for the settings form containing the given
// checkbox. Imgur's Save button carries a per-page-load unique `name`
// attribute (a CSRF-style token), so it must be matched by type+value, not by
// name.
function imgurFindSaveButton(checkbox) {
  if (!checkbox || !checkbox.closest) {
    return null;
  }
  const container = checkbox.closest("form") || (checkbox.ownerDocument ? checkbox.ownerDocument.body : null);
  if (!container || !container.querySelector) {
    return null;
  }
  return container.querySelector('input[type="submit"][value="Save"]');
}

// Forces the "Show mature posts and comments" checkbox off and persists it via
// Save whenever it is found checked on the settings page. Throttled so we
// never fight our own click while Imgur's page JS settles.
function enforceImgurSettings(doc) {
  if (!doc || !doc.getElementById) {
    return;
  }
  const checkbox = doc.getElementById("show_mature");
  if (!checkbox || !checkbox.checked) {
    return;
  }
  const now = Date.now();
  if (now - imgurLastEnforceClick < 1000) {
    return;
  }
  imgurLastEnforceClick = now;
  const save = imgurFindSaveButton(checkbox);
  try {
    checkbox.click();
  } catch {
  }
  setTimeout(() => {
    try {
      if (save) {
        save.click();
      }
    } catch {
    }
  }, 200);
}

// --- Settings guard ----------------------------------------------------------
// Block the user from re-checking "Show mature posts and comments"; our own
// synthetic clicks (isTrusted === false) stay exempt so enforcement above is
// not self-blocked.

function installImgurSettingsGuard() {
  const guard = (event) => guardImgurSettingsClick(event);
  document.addEventListener("pointerdown", guard, true);
  document.addEventListener("click", guard, true);
  document.addEventListener("change", guard, true);
  document.addEventListener("keydown", (event) => {
    if (!event || (event.key !== " " && event.key !== "Enter")) {
      return;
    }
    guard(event);
  }, true);
}

// Returns the guarded checkbox a click/keydown is targeting, or null. Imgur's
// checkbox is not wrapped by its label (a separate `<label for="show_mature">`
// sits beside it in its own table cell), so a hit on either the checkbox
// itself or that label counts.
function imgurGuardedControl(target) {
  if (!target) {
    return null;
  }
  if (typeof target.matches === "function" && target.matches("#show_mature")) {
    return target;
  }
  if (target.tagName === "LABEL" && target.htmlFor === "show_mature") {
    return (target.ownerDocument || document).getElementById("show_mature");
  }
  return null;
}

function guardImgurSettingsClick(event) {
  if (event && event.isTrusted === false) {
    return;
  }
  const control = imgurGuardedControl(event && event.target);
  if (!control) {
    return;
  }
  // Block only the unsafe direction: turning the setting ON (it is currently
  // off, so the activation would enable it).
  if (control.checked) {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  if (event.stopImmediatePropagation) {
    event.stopImmediatePropagation();
  }
  setTimeout(() => enforceImgurSettings(document), 50);
}
