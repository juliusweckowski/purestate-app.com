using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace Purestate.Native
{
    internal static partial class Support
    {
        private static int CountBypassRiskIndicators()
        {
            int count = 0;
            if (FindRunningBypassProcesses().Length > 0) count++;
            if (FindBypassNetworkAdapters().Length > 0) count++;
            if (FindInstalledBypassTools().Length > 0) count++;
            if (FindPortableBrowserHints().Length > 0) count++;

            string proxyServer;
            if (WindowsProxyEnabled(out proxyServer)) count++;
            if (!BrowserHardeningActive()) count++;
            return count;
        }

        internal static int CountBypassToolIndicators()
        {
            int count = 0;
            if (FindRunningBypassProcesses().Length > 0) count++;
            if (FindInstalledBypassTools().Length > 0) count++;
            if (FindPortableBrowserHints().Length > 0) count++;
            return count;
        }

        private static string[] FindUnsupportedBrowserHints()
        {
            System.Collections.Generic.SortedSet<string> results = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (string value in FindRunningUnsupportedBrowsers())
            {
                results.Add(value);
            }

            foreach (string value in FindInstalledUnsupportedBrowsers())
            {
                results.Add(value);
            }

            return ToLimitedArray(results, 40);
        }

        private static string[] FindRunningUnsupportedBrowsers()
        {
            System.Collections.Generic.SortedSet<string> results = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            Process[] processes;

            try
            {
                processes = Process.GetProcesses();
            }
            catch
            {
                return new string[0];
            }

            try
            {
                foreach (Process process in processes)
                {
                    try
                    {
                        string name = process.ProcessName ?? string.Empty;
                        string path = SafeProcessPath(process);
                        if (ProcessNameLooksLikeUnsupportedBrowser(name) || PathLooksLikeUnsupportedBrowser(path))
                        {
                            string label = name;
                            if (!string.IsNullOrEmpty(path))
                            {
                                label += " (" + path + ")";
                            }

                            results.Add(label);
                        }
                    }
                    catch
                    {
                    }

                    if (results.Count >= 40)
                    {
                        break;
                    }
                }
            }
            finally
            {
                DisposeProcesses(processes);
            }

            return ToLimitedArray(results, 40);
        }

        // BYP-005: Process.GetProcesses() liefert je Prozess ein Objekt mit
        // einem offenen Handle. Die Schleifen unten entsorgten nur den GERADE
        // bearbeiteten und brachen bei Erreichen der Ergebnisgrenze ab - die
        // restlichen 150 bis 250 Handles eines normalen Systems blieben liegen
        // und verschwanden erst mit dem Finalizer. In einem Dienst, der Monate
        // laufen soll, ist der Finalizer keine Aufraeumstrategie.
        //
        // Dispose ist mehrfach aufrufbar, also genuegt ein Durchgang am Ende
        // fuer alle - ob schon entsorgt oder nicht.
        private static void DisposeProcesses(Process[] processes)
        {
            foreach (Process process in processes ?? new Process[0])
            {
                try
                {
                    process.Dispose();
                }
                catch
                {
                }
            }
        }

        private static string[] FindInstalledUnsupportedBrowsers()
        {
            System.Collections.Generic.SortedSet<string> results = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            string[] programRoots =
            {
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
            };

            string[] relativePaths =
            {
                @"BraveSoftware\Brave-Browser\Application\brave.exe",
                @"Opera\launcher.exe",
                @"Opera GX\launcher.exe",
                @"Vivaldi\Application\vivaldi.exe",
                @"LibreWolf\librewolf.exe",
                @"Waterfox\waterfox.exe",
                @"AVAST Software\Browser\Application\AvastBrowser.exe",
                @"AVG\Browser\Application\AVGBrowser.exe",
                @"CCleaner Browser\Application\CCleanerBrowser.exe",
                @"DuckDuckGo\DuckDuckGo.exe",
                @"Epic Privacy Browser\epic.exe",
                @"Maxthon\Bin\Maxthon.exe",
                @"SeaMonkey\seamonkey.exe",
                @"Yandex\YandexBrowser\Application\browser.exe",
                @"UCBrowser\Application\UCBrowser.exe",
                @"Pale Moon\palemoon.exe"
            };

            foreach (string root in programRoots)
            {
                if (string.IsNullOrEmpty(root))
                {
                    continue;
                }

                foreach (string relative in relativePaths)
                {
                    AddExistingPath(results, Path.Combine(root, relative));
                    if (results.Count >= 40)
                    {
                        return ToLimitedArray(results, 40);
                    }
                }
            }

            return ToLimitedArray(results, 40);
        }

        private static string[] FindRunningBypassProcesses()
        {
            System.Collections.Generic.SortedSet<string> results = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            Process[] processes;

            try
            {
                processes = Process.GetProcesses();
            }
            catch
            {
                return new string[0];
            }

            try
            {
                foreach (Process process in processes)
                {
                    try
                    {
                        string name = process.ProcessName ?? string.Empty;
                        string path = SafeProcessPath(process);
                        if (ProcessNameLooksLikeBypassTool(name) || PathLooksLikeBypassTool(path))
                        {
                            string label = name;
                            if (!string.IsNullOrEmpty(path))
                            {
                                label += " (" + path + ")";
                            }

                            results.Add(label);
                        }
                    }
                    catch
                    {
                    }

                    if (results.Count >= 30)
                    {
                        break;
                    }
                }
            }
            finally
            {
                DisposeProcesses(processes);
            }

            return ToLimitedArray(results, 30);
        }

        // BYP-003: Die Stichwoerter "tap" und "tun" wurden als Teilzeichenkette
        // geprueft und trafen damit zwei Adapter, die Windows selbst
        // mitbringt: "Microsoft ISATAP Adapter" (isaTAP) und "Teredo Tunneling
        // Pseudo-Interface" (TUNneling). Auf einem voellig sauberen Rechner
        // stand die Zahl der Umgehungshinweise damit dauerhaft bei mindestens
        // 1. Ein Mass, das den Ruhewert nie erreicht, ist als Mass wertlos -
        // schlimmer noch, es gewoehnt den Leser daran, den Hinweis zu
        // uebersehen. Statt einer Wortgrenze (ISATAP und Teredo waeren auch
        // dann Treffer) stehen hier die qualifizierten Produktformen.
        // wintun gehoert zu WireGuard, tap- zu OpenVPN und seinen Ablegern -
        // ohne die beiden faellt echte Erkennung weg.
        //
        // Der Bindestrich in "tap-" ist die eigentliche Arbeit: die
        // TAP-Treiber heissen samt und sonders "TAP-Windows Adapter V9",
        // "TAP-NordVPN Windows Adapter" und so fort, waehrend "ISATAP Adapter"
        // keinen hat. Ein Versuch mit "tap adapter" schlug im eigenen Test
        // fehl - "isaTAP Adapter" enthaelt genau das.
        internal static readonly string[] BypassAdapterKeywords =
        {
            "vpn", "tap-", "wintun", "tunsafe",
            "wireguard", "openvpn", "tailscale", "zerotier", "hamachi", "nord",
            "proton", "surfshark", "expressvpn", "windscribe", "mullvad"
        };

        internal static bool IsBypassAdapterLabel(string label)
        {
            return TextContainsAny(label ?? string.Empty, BypassAdapterKeywords);
        }

        private static string[] FindBypassNetworkAdapters()
        {
            System.Collections.Generic.SortedSet<string> results = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);

            try
            {
                foreach (System.Net.NetworkInformation.NetworkInterface adapter in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
                {
                    string label = (adapter.Name ?? string.Empty) + " - " + (adapter.Description ?? string.Empty);
                    if (IsBypassAdapterLabel(label))
                    {
                        results.Add(label + " (" + adapter.OperationalStatus + ")");
                    }

                    if (results.Count >= 30)
                    {
                        break;
                    }
                }
            }
            catch
            {
            }

            return ToLimitedArray(results, 30);
        }

        private static string[] FindInstalledBypassTools()
        {
            System.Collections.Generic.SortedSet<string> results = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            string[] programRoots =
            {
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
            };

            string[] names =
            {
                "Tor Browser",
                "Mullvad Browser",
                "OpenVPN",
                "WireGuard",
                "Tailscale",
                "ZeroTier",
                "Hamachi",
                "NordVPN",
                "Proton VPN",
                "ProtonVPN",
                "Surfshark",
                "ExpressVPN",
                "Windscribe",
                "Psiphon",
                "UltraSurf"
            };

            foreach (string root in programRoots)
            {
                if (string.IsNullOrEmpty(root))
                {
                    continue;
                }

                foreach (string name in names)
                {
                    AddExistingPath(results, Path.Combine(root, name));
                    if (results.Count >= 40)
                    {
                        return ToLimitedArray(results, 40);
                    }
                }
            }

            return ToLimitedArray(results, 40);
        }

        private static string[] FindPortableBrowserHints()
        {
            System.Collections.Generic.SortedSet<string> results = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            string userProfile = Environment.GetEnvironmentVariable("USERPROFILE") ?? string.Empty;
            string[] roots =
            {
                Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                string.IsNullOrEmpty(userProfile) ? string.Empty : Path.Combine(userProfile, "Downloads")
            };

            string[] hints =
            {
                "tor browser",
                "torbrowser",
                "mullvad browser",
                "firefoxportable",
                "chromeportable",
                "braveportable",
                "operaportable",
                "librewolf",
                "waterfoxportable",
                "portableapps"
            };

            foreach (string root in roots)
            {
                int visited = 0;
                SearchPathHints(root, hints, 2, ref visited, results, 40);
                if (results.Count >= 40)
                {
                    break;
                }
            }

            return ToLimitedArray(results, 40);
        }

        // BYP-006: MainModule wirft bei geschuetzten Prozessen, bei
        // Anti-Cheat-Treibern und ueber Bitness-Grenzen hinweg. Der Ruckfall
        // ueber QueryFullProcessImageName braucht nur
        // PROCESS_QUERY_LIMITED_INFORMATION. Dieselbe Loesung steht im Guard
        // (PurestateGuardVideoGameDetection.GetProcessImagePath) und im Native
        // Host - die drei werden in getrennte Assemblies kompiliert, deshalb
        // hier eine eigene Fassung.
        private const uint ProcessQueryLimitedInformation = 0x1000;

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr OpenProcess(uint desiredAccess, bool inheritHandle, int processId);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CloseHandle(IntPtr handle);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern bool QueryFullProcessImageName(IntPtr process, uint flags, StringBuilder exeName, ref uint size);

        private static string SafeProcessPath(Process process)
        {
            try
            {
                string path = process.MainModule == null ? string.Empty : process.MainModule.FileName;
                if (!string.IsNullOrEmpty(path))
                {
                    return path;
                }
            }
            catch
            {
                // Zugriff verweigert oder Prozess beendet - der eingeschraenkte
                // Weg kann trotzdem antworten.
            }

            try
            {
                IntPtr handle = OpenProcess(ProcessQueryLimitedInformation, false, process.Id);
                if (handle == IntPtr.Zero)
                {
                    return string.Empty;
                }

                try
                {
                    StringBuilder buffer = new StringBuilder(1024);
                    uint size = (uint)buffer.Capacity;
                    if (QueryFullProcessImageName(handle, 0, buffer, ref size))
                    {
                        return buffer.ToString();
                    }
                }
                finally
                {
                    CloseHandle(handle);
                }
            }
            catch
            {
            }

            return string.Empty;
        }

        private static bool ProcessNameLooksLikeBypassTool(string processName)
        {
            string value = (processName ?? string.Empty).ToLowerInvariant();
            if (value == "tor")
            {
                return true;
            }

            string[] keywords =
            {
                "openvpn",
                "wireguard",
                "tailscale",
                "zerotier",
                "hamachi",
                "nordvpn",
                "protonvpn",
                "surfshark",
                "expressvpn",
                "windscribe",
                "mullvad",
                "psiphon",
                "ultrasurf"
            };

            return TextContainsAny(value, keywords);
        }

        private static bool PathLooksLikeBypassTool(string path)
        {
            string value = (path ?? string.Empty).ToLowerInvariant();
            string[] keywords =
            {
                "tor browser",
                "mullvad browser",
                "openvpn",
                "wireguard",
                "tailscale",
                "zerotier",
                "nordvpn",
                "protonvpn",
                "surfshark",
                "expressvpn",
                "windscribe",
                "psiphon",
                "ultrasurf",
                "firefoxportable",
                "chromeportable",
                "braveportable",
                "operaportable"
            };

            return TextContainsAny(value, keywords);
        }

        internal static bool ProcessNameLooksLikeUnsupportedBrowser(string processName)
        {
            string value = (processName ?? string.Empty).ToLowerInvariant();
            string[] keywords =
            {
                "brave",
                "opera",
                "operagx",
                "vivaldi",
                "librewolf",
                "waterfox",
                "avastbrowser",
                "avgbrowser",
                "ccleanerbrowser",
                "duckduckgo",
                "epicbrowser",
                "maxthon",
                "seamonkey",
                "yandexbrowser",
                "ucbrowser",
                "palemoon",
                "chromium",
                "thorium"
            };

            return TextContainsAny(value, keywords);
        }

        internal static bool PathLooksLikeUnsupportedBrowser(string path)
        {
            string value = (path ?? string.Empty).ToLowerInvariant();
            string[] keywords =
            {
                "bravesoftware",
                "brave-browser",
                "opera gx",
                "opera\\launcher.exe",
                "vivaldi",
                "librewolf",
                "waterfox",
                "avast software\\browser",
                "avg\\browser",
                "ccleaner browser",
                "duckduckgo",
                "epic privacy browser",
                "maxthon",
                "seamonkey",
                "yandexbrowser",
                "ucbrowser",
                "pale moon",
                "chromium",
                "thorium",
                "chromiumportable",
                "firefoxportable",
                "chromeportable",
                "braveportable",
                "operaportable"
            };

            return TextContainsAny(value, keywords);
        }

        private static void AddExistingPath(System.Collections.Generic.SortedSet<string> results, string path)
        {
            try
            {
                if (File.Exists(path) || Directory.Exists(path))
                {
                    results.Add(path);
                }
            }
            catch
            {
            }
        }

        private static void SearchPathHints(string root, string[] hints, int depth, ref int visited, System.Collections.Generic.SortedSet<string> results, int maxResults)
        {
            if (string.IsNullOrEmpty(root) || depth < 0 || visited > 250 || results.Count >= maxResults || !Directory.Exists(root))
            {
                return;
            }

            visited++;

            try
            {
                foreach (string file in Directory.GetFiles(root))
                {
                    if (TextContainsAny(Path.GetFileName(file), hints))
                    {
                        results.Add(file);
                    }

                    if (results.Count >= maxResults)
                    {
                        return;
                    }
                }

                foreach (string directory in Directory.GetDirectories(root))
                {
                    if (TextContainsAny(Path.GetFileName(directory), hints))
                    {
                        results.Add(directory);
                    }

                    if (results.Count >= maxResults)
                    {
                        return;
                    }

                    SearchPathHints(directory, hints, depth - 1, ref visited, results, maxResults);
                    if (visited > 250 || results.Count >= maxResults)
                    {
                        return;
                    }
                }
            }
            catch
            {
            }
        }
    }
}
