"use strict";

const GAMBLING_RULES_GET = "purestate.getBrowserRules";
const GAMBLING_TIME_TICK = "purestate.timeTick";
const GAMBLING_TIME_STATE = "purestate.timeState";
const GAMBLING_TIME_OVERLAY_ID = "purestate-gambling-time-overlay";
const GAMBLING_TIME_BADGE_ID = "purestate-gambling-time-badge";

// The script now runs on every page (broad host permission). This baseline
// mirrors rules\gambling-domains.txt (pinned by tests) so the module keeps
// working on the core sites even without a rule pack; the pack adds
// offshore- and custom-list domains dynamically.
const GAMBLING_TIME_BASELINE_DOMAINS = [
  "bet365.com", "bet365.de", "bwin.de", "tipico.de", "tipico.com",
  "bet-at-home.com", "bet-at-home.de", "interwetten.com", "merkur-spiel.de",
  "merkur-sports.de", "merkurbets.de", "merkurslots.de", "xtip.de",
  "jackpotpiraten.de", "bingbong.de", "slotmagie.de", "novoline.de",
  "sunmaker.de", "stargames.de", "stargames.at", "stargames.com",
  "pokerstars.de", "ggpoker.de", "lotto.de", "lottoland.com", "jackpot.de",
  "winamax.de", "888casino.com", "888poker.com", "unibet.com", "betway.com",
  "betway.de", "williamhill.com", "ladbrokes.com", "coral.co.uk",
  "paddypower.com", "draftkings.com", "fanduel.com", "stake.com",
  "roobet.com", "bc.game", "rollbit.com"
];

// Exposed for the regression tests, which pin the baseline against
// rules\gambling-domains.txt.
function gamblingTimeBaselineDomains() {
  return GAMBLING_TIME_BASELINE_DOMAINS.slice();
}

let gamblingTimeRulePack = null;
let gamblingTimeReached = false;
let gamblingHostRemembered = false;
let gamblingHostRememberedAt = 0;
let gamblingDetection = { state: "", href: "", gambling: false, reason: "" };

// Ein Casino ist ein Ort, keine einzelne Seite: der Pflichthinweis steht im
// Fussbereich der Startseite, an den Spieltischen nicht unbedingt.
const GAMBLING_HOST_MEMORY_KEY = "purestateGamblingHosts";
const GAMBLING_HOST_MEMORY_MS = 30 * 24 * 60 * 60 * 1000;
const GAMBLING_HOST_MEMORY_MAX = 300;
const GAMBLING_HOST_REFRESH_MS = 60 * 60 * 1000;

function gamblingStrictActive(pack) {
  const rules = pack && typeof pack === "object" ? pack : {};
  const areas = rules.areas && typeof rules.areas === "object" ? rules.areas : {};
  const area = areas.gambling && typeof areas.gambling === "object" ? areas.gambling : {};
  return area.mode === "strict";
}

function gamblingTimeLimitActive(pack) {
  const rules = pack && typeof pack === "object" ? pack : {};
  const areas = rules.areas && typeof rules.areas === "object" ? rules.areas : {};
  const area = areas.gambling && typeof areas.gambling === "object" ? areas.gambling : {};
  const limits = rules.gamblingLimits && typeof rules.gamblingLimits === "object" ? rules.gamblingLimits : {};
  return area.mode !== "strict" && limits.dailyLimitEnabled === true;
}

// Pure host gate, unit-tested: baseline plus the dynamic pack list, suffix
// semantics (exact or subdomain), never a substring match.
function gamblingTimeHostMatches(pack, hostname) {
  const host = String(hostname || "").toLowerCase();
  if (!host) {
    return false;
  }
  const rules = pack && typeof pack === "object" ? pack : {};
  const gambling = rules.gambling && typeof rules.gambling === "object" ? rules.gambling : {};
  const dynamic = Array.isArray(gambling.hostDomains) ? gambling.hostDomains : [];
  for (const value of GAMBLING_TIME_BASELINE_DOMAINS.concat(dynamic)) {
    const domain = String(value || "").toLowerCase();
    if (domain && (host === domain || host.endsWith("." + domain))) {
      return true;
    }
  }
  return false;
}

// Freigegebene Fehltreffer. Wirkt NUR auf die Erkennungsschicht - der
// Aufrufer unten fragt sie erst, nachdem die gepflegten Listen verneint
// haben. Gleiche Suffix-Semantik wie gamblingTimeHostMatches, nie Teilstring.
function gamblingExemptHostMatches(pack, hostname) {
  const host = String(hostname || "").toLowerCase();
  if (!host) {
    return false;
  }
  const rules = pack && typeof pack === "object" ? pack : {};
  const gambling = rules.gambling && typeof rules.gambling === "object" ? rules.gambling : {};
  const exempt = Array.isArray(gambling.exemptHosts) ? gambling.exemptHosts : [];
  for (const value of exempt) {
    const domain = String(value || "").toLowerCase();
    if (domain && (host === domain || host.endsWith("." + domain))) {
      return true;
    }
  }
  return false;
}

// Gepflegte Liste ODER am Inhalt erkannt ODER frueher schon erkannt. BEIDE
// Aufrufstellen unten fragen DIESE Funktion - eine Stelle stehen zu lassen
// waere genau die Luecke, die im Shopping-Bereich die Kaufverzoegerung
// ausgehebelt hat.
//
// Die Reihenfolge traegt drei Entscheidungen:
//   1. gelistet steht vor freigegeben - sonst waere die Ausnahmedatei der
//      Generalschluessel fuer den ganzen Schutzbereich.
//   2. freigegeben steht vor gemerkt - ein einmal falsch gemerkter Host
//      waere sonst 30 Tage unerreichbar trotz eingetragener Freigabe.
//   3. eine Funktion, nicht zwei - der Rueckgabewert steuert Vorhang UND
//      Zeitzaehlung.
function gamblingHostActive() {
  if (gamblingTimeHostMatches(gamblingTimeRulePack, location.hostname)) {
    return true;
  }
  if (gamblingExemptHostMatches(gamblingTimeRulePack, location.hostname)) {
    return false;
  }
  if (gamblingHostRemembered) {
    return true;
  }
  if (detectedGamblingPage()) {
    rememberGamblingHost();
    return true;
  }
  return false;
}

// Ein einziges Urteil je Ladezustand reicht nicht: hinter einem
// Zustimmungsbanner liefert eine Seite gemessen 1.400 Zeichen statt einer
// halben Million, und nach dem Wegklicken aendert sich der Ladezustand nicht
// mehr. Deshalb wird bis zu GAMBLING_DETECT_TRIES mal nachgesehen - der Tick
// laeuft alle 15 Sekunden, das deckt die erste Minute ab. Danach ist Schluss,
// damit auf fremden Seiten kein Dauerscan entsteht.
const GAMBLING_DETECT_TRIES = 4;

function detectedGamblingPage() {
  if (typeof purestateDetectGamblingPage !== "function") {
    return false;
  }
  const state = document.readyState;
  // DET-004 (gleiche Familie wie im Erwachsenenmodul): Der Zaehler wurde NUR
  // bei einem Wechsel von document.readyState zurueckgesetzt, und der bleibt
  // nach dem Laden dauerhaft "complete". Eine Seite, die ihre Inhalte per
  // pushState wechselt, wurde nach den ersten Urteilen nie wieder beurteilt.
  const href = location.href;
  if (gamblingDetection.state !== state || gamblingDetection.href !== href) {
    gamblingDetection = { state: state, href: href, gambling: false, reason: "", tries: 0 };
  }
  if (!gamblingDetection.gambling && gamblingDetection.tries < GAMBLING_DETECT_TRIES) {
    gamblingDetection.tries += 1;
    const verdict = purestateDetectGamblingPage(document, location.hostname);
    gamblingDetection.gambling = verdict.gambling === true;
    gamblingDetection.reason = verdict.reason || "";
  }
  return gamblingDetection.gambling;
}

function readGamblingStore(callback) {
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local &&
        typeof chrome.storage.local.get === "function") {
      chrome.storage.local.get(null, (items) => {
        if (chrome.runtime && chrome.runtime.lastError) {
          callback(null);
          return;
        }
        callback(items && typeof items === "object" ? items : {});
      });
      return;
    }
  } catch {
  }
  if (!globalThis.__purestateGamblingFallback) {
    globalThis.__purestateGamblingFallback = {};
  }
  callback(globalThis.__purestateGamblingFallback);
}

function writeGamblingHostMemory(map) {
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local &&
        typeof chrome.storage.local.set === "function") {
      const values = {};
      values[GAMBLING_HOST_MEMORY_KEY] = map;
      chrome.storage.local.set(values, () => {});
      return;
    }
  } catch {
  }
  if (!globalThis.__purestateGamblingFallback) {
    globalThis.__purestateGamblingFallback = {};
  }
  globalThis.__purestateGamblingFallback[GAMBLING_HOST_MEMORY_KEY] = map;
}

function loadGamblingHostMemory(done) {
  readGamblingStore((items) => {
    const map = items && typeof items[GAMBLING_HOST_MEMORY_KEY] === "object" && items[GAMBLING_HOST_MEMORY_KEY]
      ? items[GAMBLING_HOST_MEMORY_KEY]
      : {};
    const seen = map[location.hostname];
    // Ein zukunftsdatierter Eintrag verfaellt bewusst NICHT sofort: eine
    // vorgestellte Uhr darf das Gedaechtnis nicht leeren.
    if (typeof seen === "number" && Date.now() - seen <= GAMBLING_HOST_MEMORY_MS) {
      gamblingHostRemembered = true;
      gamblingHostRememberedAt = seen;
    }
    done();
  });
}

function rememberGamblingHost() {
  const now = Date.now();
  if (gamblingHostRemembered && now - gamblingHostRememberedAt < GAMBLING_HOST_REFRESH_MS) {
    return;
  }
  gamblingHostRemembered = true;
  gamblingHostRememberedAt = now;
  readGamblingStore((items) => {
    const stored = items && typeof items[GAMBLING_HOST_MEMORY_KEY] === "object" && items[GAMBLING_HOST_MEMORY_KEY]
      ? items[GAMBLING_HOST_MEMORY_KEY]
      : {};
    stored[location.hostname] = now;
    const fresh = Object.keys(stored)
      .filter((host) => typeof stored[host] === "number" && now - stored[host] <= GAMBLING_HOST_MEMORY_MS)
      .sort((a, b) => stored[b] - stored[a])
      .slice(0, GAMBLING_HOST_MEMORY_MAX);
    const next = {};
    for (const host of fresh) {
      next[host] = stored[host];
    }
    writeGamblingHostMemory(next);
  });
}

function installGamblingTimeModule() {
  requestGamblingTimeRules();
  installGamblingTimePushListener();
  loadGamblingHostMemory(evaluateGamblingCurtain);
  document.addEventListener("DOMContentLoaded", evaluateGamblingCurtain);
  window.addEventListener("load", evaluateGamblingCurtain);
  window.addEventListener("load", requestGamblingTimeState);
  setInterval(sendGamblingTimeTick, 15000);
  setInterval(evaluateGamblingCurtain, 15000);
}

function requestGamblingTimeRules() {
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return;
    }
    const maybePromise = chrome.runtime.sendMessage({ type: GAMBLING_RULES_GET, site: "gambling" }, applyGamblingTimeRules);
    if (maybePromise && typeof maybePromise.then === "function") {
      maybePromise.then(applyGamblingTimeRules).catch(() => {});
    }
  } catch {
  }
}

function installGamblingTimePushListener() {
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.onMessage || typeof chrome.runtime.onMessage.addListener !== "function") {
      return;
    }
    chrome.runtime.onMessage.addListener((message) => {
      if (message && message.type === "purestate.rulesUpdated") {
        applyGamblingTimeRules(message);
      }
      return false;
    });
  } catch {
  }
}

function applyGamblingTimeRules(response) {
  gamblingTimeRulePack = response && response.rules && typeof response.rules === "object" ? response.rules : null;
  gamblingTimeReached = false;
  removeGamblingTimeBadge();
  gamblingTimeStateAsked = false;
  removeGamblingTimeOverlay();
  // EXT-A03: Der strikte Vorhang faellt nur hier, im Abgleich eines gueltigen
  // Regelpakets - und nur, wenn er fuer diesen Host nicht mehr verlangt ist
  // (Modus aus oder wirksame Freigabe eines nicht gelisteten Hosts). Ein
  // Ausfall des Dienstes (ok !== true) ist kein Regelwechsel.
  if (response && response.ok === true && gamblingTimeRulePack &&
      !(gamblingStrictActive(gamblingTimeRulePack) && gamblingHostActive())) {
    removeGamblingTimeOverlay(true);
  }
  // Der Modus kann sich mit jedem Pack aendern, und ein gemerkter Host
  // braucht keinen Textdurchlauf - fuer ihn geht der Vorhang sofort hoch.
  evaluateGamblingCurtain();
  // Kam das Regelpaket erst nach "load", wuerde das Kaestchen sonst bis zum
  // ersten Tick fehlen. Vor "load" holt das load-Ereignis die Anfrage nach.
  if (document.readyState === "complete") {
    requestGamblingTimeState();
  }
}

function sendGamblingTimeTick() {
  // Reihenfolge zaehlt: der Rule-Pack-Test ist ein Feldvergleich, der
  // Host-Begriff kann einen Textdurchlauf ausloesen. Laeuft kein Limit, wird
  // auf fremden Seiten gar nichts gelesen.
  if (!gamblingTimeLimitActive(gamblingTimeRulePack) ||
      !gamblingHostActive() ||
      document.visibilityState !== "visible" || typeof document.hasFocus !== "function" || !document.hasFocus() ||
      (document.getElementById && document.getElementById(GAMBLING_TIME_OVERLAY_ID))) {
    return;
  }
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return;
    }
    const maybePromise = chrome.runtime.sendMessage({ type: GAMBLING_TIME_TICK, area: "gambling" }, handleGamblingTimeTickResponse);
    if (maybePromise && typeof maybePromise.then === "function") {
      maybePromise.then(handleGamblingTimeTickResponse).catch(() => {});
    }
  } catch {
  }
}

// EXT-001: Schweigt der Dienst, kannte der Handler keinen Unterschied zwischen
// "Limit nicht erreicht" und "nicht ermittelbar" - er kehrte ohne Aktion
// zurueck, und der letzte Stand blieb stehen. Schwelle wie beim Shopping: bei
// 15 Sekunden Takt rund zwei Minuten, damit ein Dienstneustart niemanden
// aussperrt.
const GAMBLING_TIME_PROBE_FAILURE_LIMIT = 8;
let gamblingTimeProbeFailures = 0;
let gamblingTimeStateUnknown = false;

function purestateGamblingTimeStateUnknown() {
  return gamblingTimeStateUnknown;
}

function purestateGamblingTimeProbeLimit() {
  return GAMBLING_TIME_PROBE_FAILURE_LIMIT;
}

function handleGamblingTimeTickResponse(response) {
  if (!response || response.ok !== true || response.area !== "gambling") {
    gamblingTimeProbeFailures += 1;
    if (gamblingTimeProbeFailures >= GAMBLING_TIME_PROBE_FAILURE_LIMIT && !gamblingTimeStateUnknown) {
      gamblingTimeStateUnknown = true;
      if (gamblingTimeLimitActive(gamblingTimeRulePack) && gamblingHostActive()) {
        showGamblingTimeUnknownOverlay();
      }
    }
    return;
  }

  gamblingTimeProbeFailures = 0;
  gamblingTimeStateUnknown = false;
  gamblingTimeReached = response.limitReached === true;
  updateGamblingTimeBadge(response);
  if (gamblingTimeReached && gamblingTimeLimitActive(gamblingTimeRulePack) &&
      gamblingHostActive()) {
    showGamblingTimeOverlay();
  } else {
    removeGamblingTimeOverlay();
  }
}

// Restzeit-Kaestchen wie bei Social Media und Shopping (gemeinsamer Baustein).
// Die Antwort traegt usedSeconds und limitSeconds schon. Sichtbar nur auf einem
// Gluecksspiel-Host, solange das Zeitlimit gilt und noch nicht erreicht ist.
function gamblingRemainingSeconds(response) {
  if (!response || !Number.isInteger(response.limitSeconds) || response.limitSeconds <= 0 ||
      response.limitReached === true) {
    return -1;
  }
  const used = Number.isInteger(response.usedSeconds) && response.usedSeconds >= 0 ? response.usedSeconds : 0;
  return Math.max(0, response.limitSeconds - used);
}

function updateGamblingTimeBadge(response) {
  const remaining = gamblingRemainingSeconds(response);
  if (remaining < 0 || !gamblingTimeLimitActive(gamblingTimeRulePack) || !gamblingHostActive() ||
      typeof purestateShowTimeBadge !== "function") {
    removeGamblingTimeBadge();
    return;
  }
  purestateShowTimeBadge(document, GAMBLING_TIME_BADGE_ID, purestateFormatRemaining(remaining));
}

function removeGamblingTimeBadge() {
  if (typeof purestateRemoveTimeBadge === "function") {
    purestateRemoveTimeBadge(document, GAMBLING_TIME_BADGE_ID);
  }
}

// Reine Stand-Abfrage ohne Zaehlen (wie beim Shopping): das Kaestchen soll beim
// Laden der Seite stehen, nicht erst nach dem ersten Tick in bis zu 15 s - und
// der Tick laeuft ohnehin nur bei Fokus. Einmal je Regelpaket und Seite.
let gamblingTimeStateAsked = false;

function requestGamblingTimeState() {
  if (gamblingTimeStateAsked || !gamblingTimeLimitActive(gamblingTimeRulePack) || !gamblingHostActive()) {
    return;
  }
  gamblingTimeStateAsked = true;
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return;
    }
    const maybePromise = chrome.runtime.sendMessage({ type: GAMBLING_TIME_STATE, area: "gambling" }, handleGamblingTimeTickResponse);
    if (maybePromise && typeof maybePromise.then === "function") {
      maybePromise.then(handleGamblingTimeTickResponse).catch(() => {});
    }
  } catch {
  }
}

function showGamblingTimeOverlay() {
  showGamblingOverlay(
    "Tageszeit für Glücksspielseiten erreicht",
    "Morgen geht es weiter.",
    "time");
}

// EXT-001: Eigener Text - "Tageszeit erreicht" waere hier gelogen.
function showGamblingTimeUnknownOverlay() {
  showGamblingOverlay(
    "Zeitbudget nicht prüfbar",
    "Purestate kann das Zeitbudget gerade nicht prüfen und pausiert diese Seite so lange. Läuft der Schutzdienst wieder, geht es sofort weiter.",
    "time");
}

// Vollvorhang im strikten Modus. Gelistete Domains sind ueber hosts, DNS und
// URLBlocklist ohnehin tot - dort ist der Vorhang ein Rueckfallnetz und
// braucht keine Sonderbehandlung. Erkannte Hosts kennt nur der Browser, fuer
// sie ist er die einzige Durchsetzung.
function showGamblingCurtain() {
  showGamblingOverlay(
    "Glücksspielseite gesperrt",
    "Diese Seite wurde als Glücksspielangebot erkannt und ist gesperrt. " +
    "Ist das ein Irrtum? In der Purestate-App unter Glücksspiel-Schutz kannst " +
    "du „" + location.hostname + "“ freigeben. Die Freigabe wirkt nach 15 Minuten.",
    "strict");
}

// Reihenfolge zaehlt: erst der Feldvergleich auf den Modus, dann der
// Host-Begriff. Laeuft der Bereich nicht strikt, wird hier kein Zeichen Text
// gelesen.
function evaluateGamblingCurtain() {
  if (!gamblingStrictActive(gamblingTimeRulePack) || !gamblingHostActive()) {
    return;
  }
  showGamblingCurtain();
}

// LIM-003: Zeitlimit-Vorhang und strikter Vollvorhang benutzen DASSELBE
// Element. Die Tick-Antwort raeumte es ab, sobald das Zeitlimit nicht erreicht
// war - ohne zu pruefen, ob der Vorhang gerade aus dem strikten Grund steht.
// Gehalten hat das bisher nur, weil die beiden Wege sich ueber den Modus
// ausschliessen: im strikten Modus wird gar kein Tick gesendet. Der Schutz war
// also eine Bedingung in einer ANDEREN Funktion, unsichtbar an der Stelle, die
// abraeumt - und er bricht, sobald jemand die Modus-Trennung lockert, etwa um
// im strikten Modus zusaetzlich Zeit zu zaehlen.
//
// Der Grund steht jetzt am Element, und das Abraeumen liest ihn.
function showGamblingOverlay(titleText, detailText, reason) {
  const doc = document;
  if (!doc.documentElement || (doc.getElementById && doc.getElementById(GAMBLING_TIME_OVERLAY_ID))) {
    return;
  }
  if (typeof purestateInstantHide === "function") {
    purestateInstantHide(doc, GAMBLING_TIME_OVERLAY_ID + "-style");
  }
  const theme = purestateCurtainTheme(doc);

  doc.documentElement.style.setProperty("overflow", "hidden", "important");
  if (doc.body) {
    doc.body.style.setProperty("overflow", "hidden", "important");
  }

  const overlay = doc.createElement("div");
  overlay.id = GAMBLING_TIME_OVERLAY_ID;
  overlay.setAttribute("data-purestate-reason", reason || "time");
  overlay.setAttribute("role", "alertdialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-live", "assertive");
  overlay.setAttribute("aria-label", "Purestate " + titleText);
  overlay.setAttribute("aria-labelledby", GAMBLING_TIME_OVERLAY_ID + "-title");
  overlay.setAttribute("tabindex", "-1");
  // EXT-A05: eigener Scroll + margin:auto statt abschneidender Zentrierung.
  // purestateInstantHide blendet den body aus; das visibility:visible aus dem
  // Baukasten haelt Meldung und Zurueck-Knopf sichtbar.
  overlay.style.cssText = purestateCurtainOverlayCss(theme);

  const column = purestateCurtainColumn(doc);
  column.appendChild(purestateCurtainBars(doc, theme, "lg"));
  column.appendChild(purestateCurtainText(doc, theme, "Purestate", "label"));
  column.appendChild(purestateCurtainTitle(doc, theme, GAMBLING_TIME_OVERLAY_ID + "-title", titleText, "curtain"));
  column.appendChild(purestateCurtainText(doc, theme, detailText, "detail"));

  const back = purestateCurtainButton(doc, theme, "Zurück", "primary");
  back.setAttribute("aria-label", "Zurück zur vorherigen Seite");
  back.addEventListener("click", (event) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    navigateBackFromGamblingOverlay(doc);
  }, true);
  const actions = purestateCurtainActions(doc);
  actions.appendChild(back);
  column.appendChild(actions);

  overlay.appendChild(column);
  (doc.body || doc.documentElement).appendChild(overlay);
  if (typeof purestateHoldOverlayFocus === "function") {
    purestateHoldOverlayFocus(doc, overlay, back);
  } else if (typeof overlay.focus === "function") {
    overlay.focus();
  }
}

function navigateBackFromGamblingOverlay(doc) {
  try {
    const view = doc.defaultView || (typeof window !== "undefined" ? window : null);
    if (!view) {
      return;
    }
    const origin = view.location.origin;
    // Der Vorhang sperrt den ganzen Host: dessen Startseite zeigt denselben
    // Vorhang wieder (live 2026-09-18). Deshalb auf eine neutrale Seite.
    if (view.history && view.history.length > 1) {
      view.history.back();
      view.setTimeout(() => {
        try {
          if (view.location.origin === origin) {
            view.location.assign("about:blank");
          }
        } catch {
        }
      }, 250);
    } else {
      view.location.assign("about:blank");
    }
  } catch {
  }
}

function removeGamblingTimeOverlay(strictNoLongerRequired) {
  if (!document.getElementById) {
    return;
  }
  const overlay = document.getElementById(GAMBLING_TIME_OVERLAY_ID);
  if (!overlay) {
    return;
  }
  // LIM-003: Nur den eigenen Vorhang abraeumen. Ein Vollvorhang aus dem
  // strikten Modus geht die Zeitzaehlung nichts an. Nur der Regelabgleich
  // (EXT-A03) darf ihn mit strictNoLongerRequired === true nehmen.
  if (strictNoLongerRequired !== true && overlay.getAttribute &&
      overlay.getAttribute("data-purestate-reason") === "strict") {
    return;
  }
  if (overlay.parentElement) {
    overlay.parentElement.removeChild(overlay);
  }
  if (typeof purestateRemoveInstantHide === "function") {
    purestateRemoveInstantHide(document, GAMBLING_TIME_OVERLAY_ID + "-style");
  }
  // Erst nach dem Sichtbarmachen: ein unsichtbarer Knopf nimmt keinen Fokus.
  if (typeof purestateReleaseOverlayFocus === "function") {
    purestateReleaseOverlayFocus(overlay);
  }
  if (document.documentElement) {
    document.documentElement.style.removeProperty("overflow");
  }
  if (document.body) {
    document.body.style.removeProperty("overflow");
  }
}

installGamblingTimeModule();
