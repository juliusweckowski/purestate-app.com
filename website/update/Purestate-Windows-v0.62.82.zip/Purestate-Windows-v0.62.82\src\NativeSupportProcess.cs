using System;
using System.Diagnostics;
using System.IO;
using System.Security.Principal;
using System.Text;
using System.Windows.Forms;

namespace Purestate.Native
{
    internal static partial class Support
    {
        private const int DefaultProcessTimeoutMilliseconds = 90000;

        // PRC-002: Ein Skript-Selbsttest, der laenger als 20 Sekunden
        // braucht, ist fehlgeschlagen. Drei davon hintereinander mit dem
        // allgemeinen Zeitlimit haetten den Vorabcheck 4,5 Minuten haengen
        // lassen.
        internal const int SelfTestProcessTimeoutMilliseconds = 20000;
        private const int MaxCapturedProcessOutputChars = 65536;

        public static bool IsAdministrator()
        {
            WindowsIdentity identity = WindowsIdentity.GetCurrent();
            WindowsPrincipal principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }

        // Hat die Aufgabe "\Purestate\Open" uns gestartet? Dann darf dieser Prozess
        // sie nicht noch einmal anstossen: gehoert der Nutzer nicht zu den
        // Administratoren, ist seine "hoechste verfuegbare" Stufe nicht erhoeht,
        // und die Aufgabe finge sonst von vorn an.
        internal static bool IsOpenTaskLaunch(string[] args)
        {
            foreach (string arg in args ?? new string[0])
            {
                if (string.Equals(arg, OpenTaskLaunchArgument, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        // Kommt der Start vom Klick auf die Update-Sprechblase? Dann oeffnet das
        // Verwaltungsfenster den Update-Dialog von sich aus.
        internal static bool IsOpenUpdateLaunch(string[] args)
        {
            foreach (string arg in args ?? new string[0])
            {
                if (string.Equals(arg, OpenUpdateLaunchArgument, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool AllowSetForegroundWindow(int processId);

        // ASFW_ANY: jeder Prozess darf den Vordergrund nehmen, bis der Nutzer die
        // naechste Eingabe macht.
        private const int AllowForegroundForAnyProcess = -1;

        // Erhoehter Start der Verwaltung ohne UAC-Dialog (Tester-Notiz 2026-10-06):
        // die Aufgabe "\Purestate\Open" laeuft mit der hoechsten verfuegbaren
        // Berechtigung des Benutzers. Zaehlt als gelungen erst, wenn wirklich ein
        // neuer Purestate-Prozess auftaucht - "schtasks /Run" meldet schon Erfolg,
        // wenn die Aufgabe nur angenommen wurde, und ein stiller Fehlschlag liesse
        // den Nutzer vor nichts sitzen. Bei false faellt der Aufrufer auf den
        // gewohnten Weg (runas, mit Rueckfrage) zurueck.
        public static bool TryStartOpenTask()
        {
            try
            {
                // Nur die installierte Kopie nimmt den Aufgabenweg: die Aufgabe
                // startet immer das installierte Purestate.exe, eine Kopie aus einem
                // Entwicklungs- oder Paketordner soll sich selbst erhoeht starten.
                if (!string.Equals(
                        Path.GetFullPath(Application.ExecutablePath),
                        Path.GetFullPath(Path.Combine(InstallDir, "Purestate.exe")),
                        StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }

                int ownId = Process.GetCurrentProcess().Id;
                System.Collections.Generic.HashSet<int> before = new System.Collections.Generic.HashSet<int>();
                foreach (Process existing in Process.GetProcessesByName("Purestate"))
                {
                    before.Add(existing.Id);
                    existing.Dispose();
                }

                // Ein von der Aufgabe gestarteter Prozess darf nicht von sich aus in den
                // Vordergrund: in der VM gemessen (2026-10-06) landete das Fenster der
                // Verwaltung hinter dem aktiven Fenster. Wir kommen von einem Klick und
                // duerfen es erlauben; das neue Fenster holt sich den Vordergrund dann
                // selbst (siehe Program.Main).
                try
                {
                    AllowSetForegroundWindow(AllowForegroundForAnyProcess);
                }
                catch
                {
                }

                RunProcess(SystemToolPath("schtasks.exe"), "/Run /TN \"" + OpenTaskName + "\"", true, 15000);

                DateTime deadline = DateTime.UtcNow.AddSeconds(8);
                while (DateTime.UtcNow < deadline)
                {
                    foreach (Process candidate in Process.GetProcessesByName("Purestate"))
                    {
                        int id = candidate.Id;
                        candidate.Dispose();
                        if (id != ownId && !before.Contains(id))
                        {
                            return true;
                        }
                    }
                    System.Threading.Thread.Sleep(250);
                }
            }
            catch
            {
            }
            return false;
        }

        // Startet die Aufgabe "\Purestate\Tray" sofort, statt auf die naechste
        // Anmeldung zu warten: der Installer beendet beim Aktualisieren den
        // laufenden Tray. Best effort - die Installation ist auch ohne das
        // gelungen (die Aufgabe laeuft nur in einer Benutzersitzung).
        public static void TryStartTrayTask()
        {
            try
            {
                RunProcess(SystemToolPath("schtasks.exe"), "/Run /TN \"" + TrayTaskName + "\"", true, 15000);
            }
            catch
            {
            }
        }

        public static void RelaunchElevated(string argument)
        {
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = Application.ExecutablePath;
            info.Arguments = argument ?? string.Empty;
            info.UseShellExecute = true;
            info.Verb = "runas";
            Process.Start(info);
        }

        public static string RunProcess(string fileName, string arguments, bool hidden)
        {
            return RunProcess(fileName, arguments, hidden, DefaultProcessTimeoutMilliseconds);
        }

        public static string RunProcess(string fileName, string arguments, bool hidden, int timeoutMilliseconds)
        {
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = fileName;
            info.Arguments = arguments;
            info.UseShellExecute = false;
            info.CreateNoWindow = hidden;
            info.RedirectStandardOutput = true;
            info.RedirectStandardError = true;

            using (Process process = new Process())
            {
                StringBuilder output = new StringBuilder();
                StringBuilder error = new StringBuilder();
                process.StartInfo = info;
                process.OutputDataReceived += delegate (object sender, DataReceivedEventArgs e)
                {
                    AppendCapturedProcessLine(output, e.Data);
                };
                process.ErrorDataReceived += delegate (object sender, DataReceivedEventArgs e)
                {
                    AppendCapturedProcessLine(error, e.Data);
                };

                if (!process.Start())
                {
                    throw new InvalidOperationException("Prozess konnte nicht gestartet werden.");
                }

                process.BeginOutputReadLine();
                process.BeginErrorReadLine();
                if (!process.WaitForExit(timeoutMilliseconds))
                {
                    try
                    {
                        process.Kill();
                        process.WaitForExit(5000);
                    }
                    catch
                    {
                    }

                    WriteActivityLog("Process timed out: " + SafeProcessDisplayName(fileName));
                    throw new TimeoutException("Ein Windows-Hilfsprozess hat das Zeitlimit ueberschritten. Details stehen im Aktivitaetsprotokoll.");
                }

                process.WaitForExit();

                if (process.ExitCode != 0)
                {
                    string combined = (error.ToString() + Environment.NewLine + output.ToString()).Trim();
                    if (string.IsNullOrWhiteSpace(combined))
                    {
                        combined = "Prozess wurde mit Exitcode " + process.ExitCode + " beendet.";
                    }

                    WriteActivityLog("Process failed: " + SafeProcessDisplayName(fileName) + " exit " + process.ExitCode + ". " + combined);
                    throw new InvalidOperationException("Ein Windows-Hilfsprozess konnte nicht erfolgreich abgeschlossen werden. Details stehen im Aktivitaetsprotokoll.");
                }

                return output.ToString().Trim();
            }
        }

        private static void AppendCapturedProcessLine(StringBuilder builder, string line)
        {
            if (line == null || builder.Length >= MaxCapturedProcessOutputChars)
            {
                return;
            }

            if (builder.Length > 0)
            {
                builder.AppendLine();
            }

            int remaining = MaxCapturedProcessOutputChars - builder.Length;
            if (line.Length <= remaining)
            {
                builder.Append(line);
            }
            else
            {
                builder.Append(line.Substring(0, remaining));
            }
        }

        private static string SafeProcessDisplayName(string fileName)
        {
            try
            {
                return Path.GetFileName(fileName);
            }
            catch
            {
                return "unknown";
            }
        }

        // PRC-003: .NET 4.x kennt kein ProcessStartInfo.ArgumentList, die
        // Befehlszeile wird also zusammengesetzt. Ein Anfuehrungszeichen im
        // Wert wuerde sie zerlegen. Heute erreicht kein Aufrufer das - die
        // Pruefung haelt es so, statt sich darauf zu verlassen.
        internal static string RequireArgumentWithoutQuote(string value, string name)
        {
            if (value != null && value.IndexOf('"') >= 0)
            {
                throw new ArgumentException("Der Wert fuer " + name + " enthaelt ein Anfuehrungszeichen und kann keinem Hilfsprozess uebergeben werden.");
            }

            return value ?? string.Empty;
        }

        public static string RunPowerShellFile(string scriptPath, string arguments)
        {
            return RunPowerShellFile(scriptPath, arguments, DefaultProcessTimeoutMilliseconds);
        }

        public static string RunPowerShellFile(string scriptPath, string arguments, int timeoutMilliseconds)
        {
            string powershell = PowerShellExecutablePath();
            string args = "-NoProfile -ExecutionPolicy Bypass -File \"" + RequireArgumentWithoutQuote(scriptPath, "Skriptpfad") + "\" " + (arguments ?? string.Empty);
            return RunProcess(powershell, args, true, timeoutMilliseconds);
        }

        public static string RunPowerShellCommand(string command)
        {
            string powershell = PowerShellExecutablePath();
            return RunProcess(powershell, "-NoProfile -ExecutionPolicy Bypass -Command \"" + command.Replace("\"", "\\\"") + "\"", true);
        }

        // PRC-001: Directory.CreateDirectory folgt einem vorhandenen Junction
        // stillschweigend. Lag unter dem Zielordner vorher einer, landeten die
        // Skripte an dessen Ziel - in einem Ordner, den der Nutzer ohne
        // Adminrechte aendern kann, waehrend der Dienst sie als LocalSystem
        // ausfuehrt. Geprueft werden nur die Ordner, die hier angelegt werden;
        // ein Junction WEITER OBEN (manche legen "C:\Program Files" bewusst so
        // auf ein anderes Laufwerk) bleibt erlaubt.
        private static void CreateDirectoryWithoutFollowingReparsePoint(string path)
        {
            if (Directory.Exists(path))
            {
                FileAttributes attributes = File.GetAttributes(path);
                if ((attributes & FileAttributes.ReparsePoint) != 0)
                {
                    throw new InvalidOperationException(
                        "Der Zielordner \"" + path + "\" ist ein Verknuepfungs- oder Reparse-Punkt. " +
                        "Die Installation wurde abgebrochen, damit die Programmdateien nicht ausserhalb des Installationsordners landen.");
                }
                return;
            }

            Directory.CreateDirectory(path);
        }

        public static bool CopyDirectory(string sourceDir, string destinationDir)
        {
            CreateDirectoryWithoutFollowingReparsePoint(destinationDir);

            foreach (string directory in Directory.GetDirectories(sourceDir, "*", SearchOption.AllDirectories))
            {
                string relative = directory.Substring(sourceDir.Length).TrimStart(Path.DirectorySeparatorChar);
                CreateDirectoryWithoutFollowingReparsePoint(Path.Combine(destinationDir, relative));
            }

            string installerSource = string.Empty;
            string installerDestination = string.Empty;

            foreach (string file in Directory.GetFiles(sourceDir, "*", SearchOption.AllDirectories))
            {
                string relative = file.Substring(sourceDir.Length).TrimStart(Path.DirectorySeparatorChar);
                string destination = Path.Combine(destinationDir, relative);
                CreateDirectoryWithoutFollowingReparsePoint(Path.GetDirectoryName(destination));

                if (relative.Equals("Installieren.exe", StringComparison.OrdinalIgnoreCase))
                {
                    installerSource = file;
                    installerDestination = destination;
                    continue;
                }

                CopyFileWithRetry(file, destination, relative);
            }

            if (!string.IsNullOrEmpty(installerSource))
            {
                try
                {
                    CopyFileWithRetry(installerSource, installerDestination, "Installieren.exe");
                }
                catch (IOException)
                {
                    CancelPendingInstallerReplacements(destinationDir, destinationDir);
                    try
                    {
                        CopyFileWithRetry(installerSource, installerDestination, "Installieren.exe");
                        return false;
                    }
                    catch (IOException)
                    {
                    }

                    QueueInstallerReplacement(installerSource, installerDestination);
                    return true;
                }
            }

            return false;
        }

        public static void CloseRunningDesktopApp()
        {
            string expectedPath = Path.GetFullPath(Path.Combine(InstallDir, "Purestate.exe"));
            Process[] processes;

            try
            {
                processes = Process.GetProcessesByName("Purestate");
            }
            catch
            {
                return;
            }

            foreach (Process process in processes)
            {
                try
                {
                    string processPath = SafeProcessPath(process);
                    if (string.IsNullOrEmpty(processPath) ||
                        !string.Equals(Path.GetFullPath(processPath), expectedPath, StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    if (!process.HasExited && process.CloseMainWindow())
                    {
                        process.WaitForExit(2000);
                    }

                    if (!process.HasExited)
                    {
                        process.Kill();
                        process.WaitForExit(3000);
                    }
                }
                catch
                {
                }
                finally
                {
                    process.Dispose();
                }
            }

            System.Threading.Thread.Sleep(250);
        }

        public static void CloseRunningInstalledUtilities()
        {
            CloseProcessesAtPath("Installieren", Path.Combine(InstallDir, "Installieren.exe"));
            CloseProcessesAtPath("PurestateUninstaller", Path.Combine(InstallDir, "PurestateUninstaller.exe"));
            CloseProcessesAtPath("PurestateNativeHost", Path.Combine(InstallDir, "PurestateNativeHost.exe"));
        }

        public static void CancelPendingInstallerReplacements(string packageDir)
        {
            CancelPendingInstallerReplacements(packageDir, InstallDir);
        }

        private static void CancelPendingInstallerReplacements(string packageDir, string targetInstallDir)
        {
            string helper = Path.Combine(packageDir, "scripts", "Cancel-Installer-Updates.ps1");
            if (!File.Exists(helper))
            {
                return;
            }

            try
            {
                RunPowerShellFile(helper, "-InstallDir \"" + targetInstallDir + "\" -Quiet");
            }
            catch
            {
            }
        }

        private static void CloseProcessesAtPath(string processName, string expectedPath)
        {
            int currentProcessId = Process.GetCurrentProcess().Id;
            Process[] processes;

            try
            {
                processes = Process.GetProcessesByName(processName);
            }
            catch
            {
                return;
            }

            foreach (Process process in processes)
            {
                try
                {
                    if (process.Id == currentProcessId)
                    {
                        continue;
                    }

                    string processPath = SafeProcessPath(process);
                    if (string.IsNullOrEmpty(processPath) ||
                        !string.Equals(Path.GetFullPath(processPath), Path.GetFullPath(expectedPath), StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    if (!process.HasExited && process.CloseMainWindow())
                    {
                        process.WaitForExit(1500);
                    }

                    if (!process.HasExited)
                    {
                        process.Kill();
                        process.WaitForExit(2500);
                    }
                }
                catch
                {
                }
                finally
                {
                    process.Dispose();
                }
            }
        }

        private static void QueueInstallerReplacement(string source, string destination)
        {
            string installRoot = Path.GetDirectoryName(destination);
            string updateToken = Guid.NewGuid().ToString("N");
            string pendingName = "Installieren.pending." + AppVersion.Replace(".", "_") + "." +
                Process.GetCurrentProcess().Id + "." + updateToken + ".exe";
            string pending = Path.Combine(installRoot, pendingName);
            CopyFileWithRetry(source, pending, "Installieren.pending.exe");
            string expectedSha256 = ComputeSha256(pending);
            string helper = Path.Combine(installRoot, "scripts", "Finish-Installer-Update.ps1");
            string tokenFile = Path.Combine(installRoot, "InstallerUpdate.current");

            if (!File.Exists(helper) || string.IsNullOrEmpty(expectedSha256))
            {
                throw new IOException("Die verzögerte Aktualisierung von Installieren.exe konnte nicht vorbereitet werden.");
            }

            File.WriteAllText(tokenFile, updateToken, new UTF8Encoding(false));

            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = PowerShellExecutablePath();
            info.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + RequireArgumentWithoutQuote(helper, "Hilfsskript") +
                "\" -PendingFile \"" + RequireArgumentWithoutQuote(pending, "Zwischendatei") +
                "\" -DestinationFile \"" + RequireArgumentWithoutQuote(destination, "Zieldatei") +
                "\" -ExpectedSha256 \"" + RequireArgumentWithoutQuote(expectedSha256, "Pruefsumme") +
                "\" -TokenFile \"" + RequireArgumentWithoutQuote(tokenFile, "Tokendatei") +
                "\" -UpdateToken \"" + RequireArgumentWithoutQuote(updateToken, "Token") +
                "\" -WaitForProcessId " + Process.GetCurrentProcess().Id;
            info.UseShellExecute = false;
            info.CreateNoWindow = true;
            info.WindowStyle = ProcessWindowStyle.Hidden;

            using (Process helperProcess = Process.Start(info))
            {
                if (helperProcess == null)
                {
                    throw new IOException("Der Abschluss der Installer-Aktualisierung konnte nicht gestartet werden.");
                }
            }
        }

        private static void CopyFileWithRetry(string source, string destination, string relative)
        {
            Exception lastError = null;

            for (int attempt = 0; attempt < 16; attempt++)
            {
                try
                {
                    File.Copy(source, destination, true);
                    return;
                }
                catch (IOException ex)
                {
                    lastError = ex;
                }
                catch (UnauthorizedAccessException ex)
                {
                    lastError = ex;
                }

                // Der Installer beendet die laufenden Komponenten vor dem
                // Kopieren - Chrome startet den Native Host danach aber sofort
                // wieder, und dann haelt er die Datei erneut. Statt am Ende zu
                // bitten ("Bitte schliesse Purestate"), wird waehrend der
                // Wiederholungen noch einmal nachgefasst.
                if (attempt == 3 || attempt == 9)
                {
                    try
                    {
                        CloseRunningInstalledUtilities();
                        CloseRunningDesktopApp();
                    }
                    catch
                    {
                    }
                }

                System.Threading.Thread.Sleep(250);
            }

            throw new IOException(
                "Die Datei " + relative + " konnte nicht ersetzt werden - sie ist noch von einem laufenden Programm belegt. Bitte starte den Rechner neu und wiederhole die Aktualisierung.",
                lastError);
        }
    }
}
