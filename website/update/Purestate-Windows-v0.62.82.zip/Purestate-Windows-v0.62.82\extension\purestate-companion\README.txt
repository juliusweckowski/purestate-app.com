Purestate Companion Extension
==============================

Zweck:
- ergaenzt Purestate um Seitenerkennung im Browser
- erste Version fuer Chrome und Edge
- prueft Reddit-Communities lokal und ueber Reddit-Metadaten
- erkennt eindeutige Erwachsenenbegriffe im Community-Namen
- liest 18+-Kennzeichnungen bei Bedarf direkt aus der Reddit-Seite
- blockiert 18+-Communities mit einer neutralen Purestate-Seite
- ersetzt einzelne als 18+ markierte Reddit-Beitraege durch neutrale Platzhalter
- prueft auch dynamisch nachgeladene Beitraege beim Scrollen
- verdeckt Bilder, Videos, GIFs und eingebettete Medien bis zur Post-Pruefung
- blockiert NSFW-Medien in Listen, Suchtreffern, Profilen und Medienansichten
- erfasst in Reddit-Suchen die gesamte einzelne Ergebniszeile ueber das sichtbare NSFW-Kennzeichen
- verdeckt dabei auch Reddit-eigene Vorschaubild-Komponenten und erzeugt nur einen Platzhalter
- behaelt eine Vorschau vorsorglich verdeckt, wenn Reddit keine sichere Entscheidung liefert
- erkennt auf X und Twitter native Warnungen fuer sensible oder nicht jugendfreie Medien
- blockiert dort einzelne Medienflaechen und Vorschaukarten bekannter expliziter Anbieter
- blockiert pornografische X-Suchanfragen auch bei internen Seitenwechseln
- erzwingt in den X-Einstellungen das Ausblenden sensibler Inhalte
- ersetzt Warnkacheln in der X-Ansicht Media und entfernt deren Show-Aktion
- blockiert auch wiederholte Freigabeversuche auf derselben Medienkachel
- sperrt bei mehreren Warnkacheln vorsorglich das gesamte aktuelle Medienraster
- erfasst dadurch auch bereits enthuellte oder von X nicht mehr markierte Kacheln
- blockiert pornografische Bluesky-Suchen und Hashtags
- prueft oeffentliche Bluesky-Postlabels wie porn, sexual und nudity
- verdeckt Bluesky-Medien bis zu einer sicheren Label-Entscheidung
- behaelt unbekannte oder gemeinsam mit 18+-Posts dargestellte Medien vorsorglich verdeckt
- blockiert pornografische Suchanfragen und Tags direkt auf Google, Bing,
  DuckDuckGo, Brave Search, Yahoo, Yandex, YouTube und Giphy
- blockiert TikTok-Such-, Tag-, Discover- und Music-Routen mit pornografischen Begriffen
- blockiert Pinterest-Such- und Ideen-Routen mit pornografischen Begriffen auf pinterest.com und Laenderhosts
- verdeckt Instagram-Suchvorschlaege, sobald ein echtes Suchfeld einen pornografischen Begriff enthaelt
- kann lokale Zusatzregeln vom geschuetzten Purestate Native Host laden

Installation in Chrome:
1. Chrome oeffnen.
2. chrome://extensions oeffnen.
3. Entwicklermodus einschalten.
4. "Entpackte Erweiterung laden" waehlen.
5. Exakt diesen installierten Ordner auswaehlen:
   C:\Program Files\Purestate\extension\purestate-companion
6. Bei einem Update "Aktualisieren" anklicken und offene geschuetzte Tabs neu laden.

Installation in Edge:
1. Edge oeffnen.
2. edge://extensions oeffnen.
3. Entwicklermodus einschalten.
4. "Entpackte Erweiterung laden" waehlen.
5. Exakt diesen installierten Ordner auswaehlen:
   C:\Program Files\Purestate\extension\purestate-companion

Hinweise:
- Diese Erweiterung wird fuer produktive Tests ueber den Chrome Web Store verwaltet installiert.
- Sie ist lokal und sendet keine Daten an Purestate-Server.
- Ab Purestate 0.50 werden Reddit und X vollstaendig gesperrt, wenn diese Erweiterung in einem Chrome-/Edge-Profil fehlt oder deaktiviert ist.
- Ab Purestate 0.51 muss die aktive Erweiterung aus dem geschuetzten Purestate-Installationsordner stammen und exakt zur installierten Version passen.
- Ab Purestate 0.52 beobachtet der Schutzdienst Aenderungen an Chrome-/Edge-Profilen und startet danach einen schnellen Companion-Abgleich.
- Ab Purestate 0.53 umfasst der Companion-Modus auch Bluesky; ohne aktuelle Erweiterung wird Bluesky vollstaendig gesperrt.
- Ab Purestate 0.54 schliesst der Schutzdienst Chrome oder Edge einmal, wenn Companion aktiviert oder deaktiviert wird, damit die passende Richtlinie sofort beim Neustart geladen wird.
- Ab Purestate 0.55 werden Chromes getrennte geschuetzte und normale Einstellungsdateien gemeinsam ausgewertet; ein Off-Signal in einer davon gewinnt immer.
- Ab Purestate 0.56 verwendet die Vollsperre native Chrome-/Edge-Domainfilter statt WebExtension-Match-Patterns.
- Kopien aus Download- oder alten Paketordnern loesen deshalb absichtlich die Vollsperre aus.
- Bei mehreren Profilen muss Purestate Companion in jedem Profil aktiv sein.
- Fuer Reddit fragt sie die oeffentliche Reddit-about-Information der besuchten Community ab.
- Falls Reddit diese Abfrage ablehnt, verwendet Purestate lokale Regeln und Seitensignale.
- Bereits offene Reddit-Tabs werden nach einem Erweiterungsupdate automatisch einmal neu geladen.
- Bluesky-Labels werden ueber die oeffentliche Bluesky-API geprueft; es gibt keine Purestate-Cloud.
- Lokale Browser-Zusatzregeln kommen aus rules\browser-companion-rules.txt und sind nur additiv.
- Spaeter koennen KI-Detektoren in background.js ergaenzt werden.
