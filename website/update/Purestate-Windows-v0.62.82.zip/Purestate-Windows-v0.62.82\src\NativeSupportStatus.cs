using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Purestate.Native
{
    // STA-002: Der fuer die DNS-Statusfrage noetige Ausschnitt eines Adapters.
    // Eigener Typ, damit die Entscheidung ohne echte Netzwerkkarten pruefbar
    // ist - NetworkInterface laesst sich nicht erzeugen.
    internal sealed class DnsAdapterState
    {
        public DnsAdapterState(bool isUp, bool hasGateway, string[] dnsServers)
        {
            IsUp = isUp;
            HasGateway = hasGateway;
            DnsServers = dnsServers ?? new string[0];
        }

        public bool IsUp { get; private set; }
        public bool HasGateway { get; private set; }
        public string[] DnsServers { get; private set; }
    }

    internal static partial class Support
    {
        public static bool HostsActive()
        {
            try
            {
                return File.Exists(HostsPath) && HostsBlockActive(File.ReadAllText(HostsPath));
            }
            catch
            {
                return false;
            }
        }

        // PST-002: Frueher genuegte die Startmarke irgendwo im Text. Eine
        // Datei, die ein abgerissener Schreibvorgang auf die Marke und ein paar
        // Zeilen gekuerzt hat, meldete damit "lokale Sperrliste aktiv", und
        // daraus wurde der gruene Gesamtstatus (STA-003). Verlangt sind beide
        // Marken und dazwischen mindestens eine Sperrzeile. Dieselbe
        // Entscheidung steht als Test-HostsBlockActive in scripts\Common.ps1.
        internal static bool HostsBlockActive(string content)
        {
            string text = content ?? string.Empty;
            int begin = text.IndexOf(MarkerBegin, StringComparison.Ordinal);
            if (begin < 0)
            {
                return false;
            }

            int end = text.IndexOf(MarkerEnd, begin, StringComparison.Ordinal);
            if (end < 0)
            {
                return false;
            }

            return System.Text.RegularExpressions.Regex.IsMatch(
                text.Substring(begin, end - begin),
                @"(?m)^\s*\d{1,3}(\.\d{1,3}){3}\s+\S");
        }

        // Reads the configured DNS servers directly via .NET instead of
        // spawning powershell.exe for Get-DnsClientServerAddress (this runs on
        // the status/overview path, previously one process launch per refresh).
        public static bool FamilyDnsActive()
        {
            try
            {
                string[] servers = FamilyDnsServersForProfile(LoadConfig().DnsProfile);
                System.Collections.Generic.List<DnsAdapterState> adapters =
                    new System.Collections.Generic.List<DnsAdapterState>();

                foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
                {
                    try
                    {
                        IPInterfaceProperties properties = nic.GetIPProperties();
                        System.Collections.Generic.List<string> dnsServers =
                            new System.Collections.Generic.List<string>();
                        foreach (IPAddress dns in properties.DnsAddresses)
                        {
                            dnsServers.Add(dns.ToString());
                        }

                        adapters.Add(new DnsAdapterState(
                            nic.OperationalStatus == OperationalStatus.Up,
                            properties.GatewayAddresses.Count > 0,
                            dnsServers.ToArray()));
                    }
                    catch
                    {
                        // Some interface types throw on GetIPProperties; skip them.
                    }
                }

                return FamilyDnsActiveForAdapters(servers, adapters);
            }
            catch
            {
                return false;
            }
        }

        // STA-002: Die Pruefung meldete frueher true, sobald EIN EINZIGER
        // Adapter eine Familien-Adresse trug - ohne Ruecksicht auf
        // Betriebszustand, Gateway oder Adaptertyp. Falsch wurde das genau dann,
        // wenn es darauf ankommt: Laptop aus dem Dock (Ethernet traegt den
        // Familien-DNS, ist aber Down, WLAN ist aktiv und ungefiltert) oder ein
        // aufgebautes VPN. Beide Male stand da "Familien-DNS aktiv: Ja".
        //
        // Jetzt zaehlt "alle verkehrstragenden Adapter" statt "irgendeiner".
        // Damit deckt der Status NET-001 auf, statt ihn zu verbergen. Als reine
        // Entscheidung herausgezogen, weil sie sonst nur mit echten
        // Netzwerkkarten pruefbar waere.
        internal static bool FamilyDnsActiveForAdapters(
            string[] familyServers,
            System.Collections.Generic.IEnumerable<DnsAdapterState> adapters)
        {
            System.Collections.Generic.HashSet<string> family =
                new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string server in familyServers ?? new string[0])
            {
                if (!string.IsNullOrWhiteSpace(server))
                {
                    family.Add(server.Trim());
                }
            }

            if (family.Count == 0)
            {
                return false;
            }

            bool sawCarrier = false;
            foreach (DnsAdapterState adapter in adapters ?? new DnsAdapterState[0])
            {
                // Ein Adapter ohne Standardgateway traegt keinen Internetverkehr;
                // ein Adapter, der nicht Up ist, ebenfalls nicht.
                if (!adapter.IsUp || !adapter.HasGateway)
                {
                    continue;
                }

                sawCarrier = true;
                bool filtered = false;
                foreach (string dns in adapter.DnsServers ?? new string[0])
                {
                    if (family.Contains((dns ?? string.Empty).Trim()))
                    {
                        filtered = true;
                        break;
                    }
                }

                if (!filtered)
                {
                    return false;
                }
            }

            return sawCarrier;
        }

        public static bool BrowserPoliciesActive()
        {
            bool chrome = RegistryValueEquals(@"SOFTWARE\Policies\Google\Chrome", "DnsOverHttpsMode", "off");
            bool edge = RegistryValueEquals(@"SOFTWARE\Policies\Microsoft\Edge", "DnsOverHttpsMode", "off");
            bool firefox = RegistryValueEquals(@"SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS", "Enabled", 0);
            return chrome || edge || firefox || BrowserHardeningActive() || MixedSitePoliciesActive();
        }

        // BYS-002: "Wirksam" heisst nicht "es gibt Regeln", sondern "der
        // Regelsatz entspricht dem, was zu blockieren waere".
        // Enable-BypassBlocking legt Regeln nur fuer GEFUNDENE Programme an
        // (Common.ps1:6966-6969); auf einem Rechner ohne VPN, Tor oder Proxy
        // sind null Regeln der Sollzustand. Die Kachel las das frueher als
        // Ausfall und stand beim Normalnutzer ab dem ersten Start dauerhaft
        // gelb - genau das Wegsehtraining, das STA-003 verhindern sollte.
        // Der Gesundheitsbericht prueft laengst richtig
        // (NativeSupportReports.cs:904), diese Zeile zieht die Kachel nach.
        //
        // Offen bleibt die Gegenrichtung BYS-001: eine einzige Regel genuegt
        // hier weiterhin fuer "wirksam", auch wenn sie auf einen Fehltreffer
        // zeigt und das laufende Werkzeug ungesperrt ist.
        internal static bool BypassBlockingEffective(int firewallRules, int toolIndicators)
        {
            return firewallRules > 0 || toolIndicators == 0;
        }

        // STA-003: Nennt die eingeschalteten Schutzschichten, die nicht wirken.
        // Die Statuskachel entschied frueher allein an der hosts-Datei, ob sie
        // "Alle aktivierten Schutzbereiche funktionieren" meldet - DNS,
        // Browser-Richtlinien, Umgehungsschutz und Watchdog wurden zwar erhoben,
        // gingen aber nur in den Detailtext ein. Wer den DNS-Schutz verloren
        // hatte (NET-001), sah trotzdem gruen.
        //
        // Ausgeschaltete Schichten gehen NICHT ein: eine Kachel, die dauerhaft
        // gelb steht, weil der Nutzer einen Bereich bewusst nicht will, trainiert
        // ihn darauf, Warnungen zu ignorieren.
        internal static string[] FindFailedProtectionLayers(
            bool hostsEnabled, bool hostsActive,
            bool dnsEnabled, bool dnsActive,
            bool browserPoliciesEnabled, bool browserPoliciesActive,
            bool bypassEnabled, bool bypassActive,
            bool watchdogRegistered)
        {
            System.Collections.Generic.List<string> failed =
                new System.Collections.Generic.List<string>();

            if (hostsEnabled && !hostsActive) { failed.Add("Hosts-Sperre"); }
            if (dnsEnabled && !dnsActive) { failed.Add("Familien-DNS"); }
            if (browserPoliciesEnabled && !browserPoliciesActive) { failed.Add("Browser-Richtlinien"); }
            if (bypassEnabled && !bypassActive) { failed.Add("Umgehungsschutz"); }

            // Der Watchdog haengt an keinem Bereichsschalter - er stellt den
            // Schutz nach einem Ausfall wieder her und muss immer stehen.
            if (!watchdogRegistered) { failed.Add("Watchdog"); }

            return failed.ToArray();
        }

        // STA-001: Frueher genuegte, dass der Schluessel UEBERHAUPT Werte hat -
        // wessen, blieb ungefragt. Auf einem verwalteten Rechner (Firma, Schule,
        // Sicherheitssoftware) stehen dort Fremdeintraege, und wenn Purestates
        // eigene Regeln ueber den 1000er-Deckel gefallen sind (POL-001), meldete
        // die Oberflaeche trotzdem "geschuetzt".
        public static bool MixedSitePoliciesActive()
        {
            return
                PurestateUrlListActive(@"SOFTWARE\Policies\Google\Chrome\URLBlocklist") ||
                PurestateUrlListActive(@"SOFTWARE\Policies\Microsoft\Edge\URLBlocklist") ||
                PurestateUrlListActive(@"SOFTWARE\Policies\Mozilla\Firefox\WebsiteFilter\Block");
        }

        private static bool PurestateUrlListActive(string subKey)
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(subKey))
                {
                    if (key == null)
                    {
                        return false;
                    }

                    System.Collections.Generic.List<string> values =
                        new System.Collections.Generic.List<string>();
                    foreach (string name in key.GetValueNames())
                    {
                        object value = key.GetValue(name);
                        if (value != null)
                        {
                            values.Add(value.ToString());
                        }
                    }

                    return ContainsPurestateUrlPattern(values.ToArray());
                }
            }
            catch
            {
                return false;
            }
        }

        // Erkennt an einem eigenen Marker, ob in einer geteilten Sperrliste
        // wirklich Purestate-Regeln stehen. Als Marker dienen die
        // Kernabdeckungsrouten (Suchmaschinen) - sie haengen an keinem
        // abschaltbaren Bereich, anders als reddit- oder x-Muster, die nach
        // RGL-002 verschwinden, sobald der Nutzer den Bereich freigibt. Dazu die
        // Fail-closed-Vollsperre, die im Companion-Ausfall an ihre Stelle tritt.
        internal static bool ContainsPurestateUrlPattern(string[] values)
        {
            if (values == null || values.Length == 0)
            {
                return false;
            }

            // Eine Suchroute ALLEIN reicht nicht: ein Firmenfilter, der Bing
            // oder Reddit sperrt, wuerde sonst als Purestate-Schutz gelten. Erst
            // Route PLUS Erwachsenen-Stichwort ist eindeutig unsere Regel.
            string[] searchRoutes = new string[]
            {
                "bing.com/search", "bing.com/images/search", "bing.com/videos/search",
                "duckduckgo.com/", "search.brave.com/search", "yandex.com/search",
                "ecosia.org/search", "startpage.com/sp/search", "qwant.com/",
                "metager.org/meta/", "search.yahoo.com/search", "google."
            };

            bool sawReddit = false;
            bool sawX = false;
            bool sawBsky = false;

            foreach (string value in values)
            {
                string candidate = (value ?? string.Empty).Trim();
                if (candidate.Length == 0)
                {
                    continue;
                }

                foreach (string route in searchRoutes)
                {
                    if (candidate.IndexOf(route, StringComparison.OrdinalIgnoreCase) < 0)
                    {
                        continue;
                    }

                    foreach (string keyword in CoreAdultUrlKeywordsForStatus())
                    {
                        if (candidate.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            return true;
                        }
                    }
                }

                // Der Companion-Ausfall ersetzt die Musterliste durch die
                // Vollsperre. Sie zaehlt nur als Dreiergespann - einzeln waere
                // jede davon auch ein plausibler Fremdeintrag.
                if (candidate.IndexOf("reddit.com", StringComparison.OrdinalIgnoreCase) >= 0) { sawReddit = true; }
                if (candidate.IndexOf("x.com", StringComparison.OrdinalIgnoreCase) >= 0) { sawX = true; }
                if (candidate.IndexOf("bsky.app", StringComparison.OrdinalIgnoreCase) >= 0) { sawBsky = true; }
            }

            return sawReddit && sawX && sawBsky;
        }

        // Ein Ausschnitt aus Get-CoreAdultUrlKeywords (scripts\Common.ps1); fuer
        // die Statusfrage genuegen die Begriffe, die in jeder Kernabdeckung
        // vorkommen. Bewusst kurz gehalten - das hier ist ein Nachweis, keine
        // Sperrliste.
        private static string[] CoreAdultUrlKeywordsForStatus()
        {
            return new string[] { "porn", "hentai", "nsfw", "nude", "xxx" };
        }

        public static bool BrowserHardeningActive()
        {
            bool chrome = ChromiumHardeningActive(@"SOFTWARE\Policies\Google\Chrome", "IncognitoModeAvailability", "BrowserAddPersonEnabled");
            bool edge = ChromiumHardeningActive(@"SOFTWARE\Policies\Microsoft\Edge", "InPrivateModeAvailability", "BrowserAddProfileEnabled");
            bool firefox =
                RegistryValueEquals(@"SOFTWARE\Policies\Mozilla\Firefox", "DisablePrivateBrowsing", 1) &&
                RegistryValueEquals(@"SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS", "Enabled", 0) &&
                RegistryValueEquals(@"SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS", "Locked", 1) &&
                RegistryValueEquals(@"SOFTWARE\Policies\Mozilla\Firefox\Proxy", "Mode", "none") &&
                RegistryValueEquals(@"SOFTWARE\Policies\Mozilla\Firefox\Proxy", "Locked", 1);

            return chrome || edge || firefox;
        }

        public static bool BrowserProxyHardeningActive()
        {
            bool chrome = RegistryValueEquals(@"SOFTWARE\Policies\Google\Chrome", "ProxyMode", "direct");
            bool edge = RegistryValueEquals(@"SOFTWARE\Policies\Microsoft\Edge", "ProxyMode", "direct");
            bool firefox =
                RegistryValueEquals(@"SOFTWARE\Policies\Mozilla\Firefox\Proxy", "Mode", "none") &&
                RegistryValueEquals(@"SOFTWARE\Policies\Mozilla\Firefox\Proxy", "Locked", 1);

            return chrome || edge || firefox;
        }

        public static bool WindowsProxyActive()
        {
            string proxyServer;
            return WindowsProxyEnabled(out proxyServer);
        }

        public static string BrowserPolicySummary()
        {
            StringBuilder summary = new StringBuilder();
            summary.AppendLine("Chrome gehaertet: " + YesNo(ChromiumHardeningActive(@"SOFTWARE\Policies\Google\Chrome", "IncognitoModeAvailability", "BrowserAddPersonEnabled")));
            summary.AppendLine("Edge gehaertet: " + YesNo(ChromiumHardeningActive(@"SOFTWARE\Policies\Microsoft\Edge", "InPrivateModeAvailability", "BrowserAddProfileEnabled")));
            summary.AppendLine("Chrome: " + ChromeCompanionStatus());
            summary.AppendLine("Edge: " + EdgeCompanionStatus());
            summary.AppendLine("Firefox: " + FirefoxMixedSiteStatus());
            summary.AppendLine("Firefox gehaertet: " + YesNo(
                RegistryValueEquals(@"SOFTWARE\Policies\Mozilla\Firefox", "DisablePrivateBrowsing", 1) &&
                RegistryValueEquals(@"SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS", "Enabled", 0) &&
                RegistryValueEquals(@"SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS", "Locked", 1) &&
                RegistryValueEquals(@"SOFTWARE\Policies\Mozilla\Firefox\Proxy", "Mode", "none") &&
                RegistryValueEquals(@"SOFTWARE\Policies\Mozilla\Firefox\Proxy", "Locked", 1)
            ));
            summary.AppendLine("Browser-Proxy gehaertet: " + YesNo(BrowserProxyHardeningActive()));
            summary.AppendLine("Gemischte Webseiten geschuetzt: " + YesNo(MixedSitePoliciesActive()));
            summary.AppendLine("URL-Regeln fuer gemischte Webseiten: " + CountMixedSiteUrlPatterns());
            summary.AppendLine("Erwachsene URL-Begriffe: " + CountAdultUrlKeywords());
            return summary.ToString().TrimEnd();
        }

        public static string ChromeCompanionStatus()
        {
            return ChromiumCompanionStatus(@"SOFTWARE\Policies\Google\Chrome");
        }

        public static string EdgeCompanionStatus()
        {
            return ChromiumCompanionStatus(@"SOFTWARE\Policies\Microsoft\Edge");
        }

        public static string FirefoxMixedSiteStatus()
        {
            return ChromiumFailClosedActive(@"SOFTWARE\Policies\Mozilla\Firefox\WebsiteFilter")
                ? "X/Reddit/Bluesky-Vollsperre aktiv"
                : "nicht vollstaendig geschuetzt";
        }

        // These prefixes mirror $script:BypassFirewallPrefix /
        // $script:UnsupportedBrowserFirewallPrefix in scripts\Common.ps1, which
        // is where the rules are created (their DisplayName == INetFwRule.Name).
        private const string BypassFirewallRulePrefix = "Purestate Bypass Block - ";
        private const string UnsupportedBrowserFirewallRulePrefix = "Purestate Unsupported Browser Block - ";

        public static int CountBypassFirewallRules()
        {
            return CountFirewallRulesByNamePrefix(BypassFirewallRulePrefix);
        }

        public static bool BypassBlockingActive()
        {
            return CountBypassFirewallRules() > 0;
        }

        public static int CountUnsupportedBrowserFirewallRules()
        {
            return CountFirewallRulesByNamePrefix(UnsupportedBrowserFirewallRulePrefix);
        }

        // Counts Windows Firewall rules whose name starts with the given prefix
        // via the Windows Firewall COM API (INetFwPolicy2) instead of spawning
        // powershell.exe for Get-NetFirewallRule. Fully late-bound so no COM
        // reference assembly is needed; any failure degrades to 0 like before.
        private static int CountFirewallRulesByNamePrefix(string prefix)
        {
            object policy = null;
            try
            {
                Type policyType = Type.GetTypeFromProgID("HNetCfg.FwPolicy2");
                if (policyType == null)
                {
                    return 0;
                }

                policy = Activator.CreateInstance(policyType);
                object rules = policyType.InvokeMember("Rules", BindingFlags.GetProperty, null, policy, null);
                System.Collections.IEnumerable enumerable = rules as System.Collections.IEnumerable;
                if (enumerable == null)
                {
                    return 0;
                }

                int count = 0;
                foreach (object rule in enumerable)
                {
                    try
                    {
                        object name = rule.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, rule, null);
                        string ruleName = name as string;
                        if (!string.IsNullOrEmpty(ruleName) && ruleName.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                        {
                            count++;
                        }
                    }
                    catch
                    {
                    }
                    finally
                    {
                        if (rule != null && Marshal.IsComObject(rule))
                        {
                            Marshal.ReleaseComObject(rule);
                        }
                    }
                }

                return count;
            }
            catch
            {
                return 0;
            }
            finally
            {
                if (policy != null && Marshal.IsComObject(policy))
                {
                    Marshal.ReleaseComObject(policy);
                }
            }
        }

        public static bool UnsupportedBrowserBlockingActive()
        {
            return CountUnsupportedBrowserFirewallRules() > 0;
        }

        private static string ChromiumCompanionStatus(string policyPath)
        {
            if (ChromiumFailClosedActive(policyPath))
            {
                return "Vollsperre aktiv (Companion fehlt oder ist veraltet)";
            }

            // STA-001: Frueher genuegte die blosse Existenz von Werten. Auf einem
            // verwalteten Rechner stand hier "Companion aktiv", obwohl in der
            // Liste ausschliesslich Fremdeintraege standen.
            if (PurestateUrlListActive(policyPath + @"\URLBlocklist"))
            {
                return "Companion aktiv";
            }

            if (RegistrySubKeyHasValues(policyPath + @"\URLBlocklist"))
            {
                return "fremde Sperrliste vorhanden, eigene Regeln fehlen";
            }

            return "nicht eingerichtet";
        }

        private static bool RegistryValueEquals(string subKey, string name, object expected)
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(subKey))
                {
                    if (key == null)
                    {
                        return false;
                    }

                    object value = key.GetValue(name);
                    return value != null && string.Equals(value.ToString(), expected.ToString(), StringComparison.OrdinalIgnoreCase);
                }
            }
            catch
            {
                return false;
            }
        }

        private static bool RegistrySubKeyHasValues(string subKey)
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(subKey))
                {
                    return key != null && key.GetValueNames().Length > 0;
                }
            }
            catch
            {
                return false;
            }
        }

        private static bool ChromiumHardeningActive(string subKey, string privateModePolicyName, string profilePolicyName)
        {
            // Befund #5 / Spec 2.4: Enable-BrowserPolicies setzt
            // ForceGoogleSafeSearch nur noch, solange der Bereich
            // Erwachseneninhalte an ist (sonst WEG statt 0, wie
            // ForceYouTubeRestrict) - ohne den Bereich darf das Fehlen dieser
            // Richtlinie "gehaertet" nicht verneinen.
            bool adultOn = LoadConfig().AdultContentProtectionEnabled;
            return
                RegistryValueEquals(subKey, "DnsOverHttpsMode", "off") &&
                RegistryValueEquals(subKey, "ProxyMode", "direct") &&
                RegistryValueEquals(subKey, privateModePolicyName, 1) &&
                RegistryValueEquals(subKey, profilePolicyName, 0) &&
                RegistryValueEquals(subKey, "BrowserGuestModeEnabled", 0) &&
                (!adultOn || RegistryValueEquals(subKey, "ForceGoogleSafeSearch", 1)) &&
                RegistryValueEquals(subKey, "ForceYouTubeRestrict", 1);
        }

        private static bool ChromiumFailClosedActive(string subKey)
        {
            return
                (RegistryStringListContains(subKey + @"\URLBlocklist", "reddit.com") &&
                 RegistryStringListContains(subKey + @"\URLBlocklist", "x.com") &&
                 RegistryStringListContains(subKey + @"\URLBlocklist", "bsky.app")) ||
                (RegistryStringListContains(subKey + @"\Block", "*://*.reddit.com/*") &&
                 RegistryStringListContains(subKey + @"\Block", "*://*.x.com/*") &&
                 RegistryStringListContains(subKey + @"\Block", "*://*.bsky.app/*"));
        }

        private static bool RegistryStringListContains(string subKey, string expected)
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(subKey))
                {
                    if (key == null)
                    {
                        return false;
                    }
                    foreach (string name in key.GetValueNames())
                    {
                        object value = key.GetValue(name);
                        if (value != null && string.Equals(value.ToString(), expected, StringComparison.OrdinalIgnoreCase))
                        {
                            return true;
                        }
                    }
                }
            }
            catch
            {
            }
            return false;
        }

        private const string ProxyInternetSettingsSuffix =
            @"Software\Microsoft\Windows\CurrentVersion\Internet Settings";

        // STA-004: Spiegelt Get-ProxyInternetSettingsPath aus scripts\Common.ps1.
        // HKCU stimmt, solange der interaktive Nutzer laeuft - im Dienstkontext
        // ist HKCU aber die Hive von SYSTEM und nicht die des Menschen vor dem
        // Rechner. Purestate verlangt Administratorrechte; startet ein
        // Standardbenutzer die App per UAC mit einem separaten Administrator-
        // konto, zeigte die Oberflaeche ab da dessen Proxy an, waehrend
        // Disable-WindowsProxy die Einstellungen des Standardbenutzers aendert.
        // Laesst sich der Nutzer nicht aufloesen, gibt es KEINEN Pfad - lieber
        // "unbekannt" als die Antwort eines fremden Kontos.
        internal static string ResolveProxyInternetSettingsPath(string currentSid, string interactiveSid)
        {
            if (!string.Equals(currentSid, "S-1-5-18", StringComparison.Ordinal))
            {
                return @"HKCU\" + ProxyInternetSettingsSuffix;
            }

            if (string.IsNullOrWhiteSpace(interactiveSid))
            {
                return null;
            }

            return @"HKU\" + interactiveSid + @"\" + ProxyInternetSettingsSuffix;
        }

        // STA-004: Aus den geladenen Hives die des Menschen vor dem Rechner
        // waehlen. Echte Nutzerkonten tragen S-1-5-21-…; die Dienstkonten
        // (S-1-5-18/19/20) und die _Classes-Zwillinge fallen raus. Genau EIN
        // Treffer ist eine Antwort - bei mehreren angemeldeten Nutzern waere
        // jede Wahl geraten, und geraten wird hier nicht.
        //
        // Bewusst ohne WMI: System.Management.dll wird nur fuer den Guard
        // referenziert, und fuer eine Anzeige lohnt weder eine neue
        // Assembly-Referenz noch eine zweite Kopie der WTS-P/Invokes.
        internal static string SelectInteractiveUserSid(string[] loadedHives)
        {
            string found = null;
            foreach (string hive in loadedHives ?? new string[0])
            {
                string name = (hive ?? string.Empty).Trim();
                if (!name.StartsWith("S-1-5-21-", StringComparison.OrdinalIgnoreCase) ||
                    name.EndsWith("_Classes", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                if (found != null)
                {
                    return null;
                }

                found = name;
            }

            return found;
        }

        private static string InteractiveUserSid()
        {
            try
            {
                return SelectInteractiveUserSid(Registry.Users.GetSubKeyNames());
            }
            catch
            {
                return null;
            }
        }

        private static RegistryKey OpenProxyInternetSettingsKey()
        {
            string currentSid = string.Empty;
            try
            {
                currentSid = System.Security.Principal.WindowsIdentity.GetCurrent().User.Value;
            }
            catch
            {
            }

            if (!string.Equals(currentSid, "S-1-5-18", StringComparison.Ordinal))
            {
                return Registry.CurrentUser.OpenSubKey(ProxyInternetSettingsSuffix);
            }

            string interactiveSid = InteractiveUserSid();
            if (string.IsNullOrWhiteSpace(interactiveSid))
            {
                return null;
            }

            return Registry.Users.OpenSubKey(interactiveSid + @"\" + ProxyInternetSettingsSuffix);
        }

        private static bool WindowsProxyEnabled(out string proxyServer)
        {
            proxyServer = string.Empty;
            try
            {
                using (RegistryKey key = OpenProxyInternetSettingsKey())
                {
                    if (key == null)
                    {
                        return false;
                    }

                    object enabled = key.GetValue("ProxyEnable");
                    object server = key.GetValue("ProxyServer");
                    object autoConfig = key.GetValue("AutoConfigURL");
                    proxyServer = server == null ? string.Empty : server.ToString();
                    if (enabled != null && Convert.ToInt32(enabled) != 0)
                    {
                        return true;
                    }

                    if (autoConfig != null && !string.IsNullOrWhiteSpace(autoConfig.ToString()))
                    {
                        proxyServer = "PAC: " + autoConfig.ToString();
                        return true;
                    }

                    return false;
                }
            }
            catch
            {
                proxyServer = string.Empty;
                return false;
            }
        }
        // GRD-022: Eine Canary-Sperre entsteht, wenn ein Erkennungsskript auf
        // einer der sechs zugeordneten Seiten seinen Anker nicht mehr findet -
        // ein Umbau der Seite loest sie bei allen Nutzern gleichzeitig aus. Die
        // Sperre ist gewollt (fail-closed), aber sie stand ohne jede Erklaerung
        // in der Oberflaeche: "Instagram geht nicht mehr" ohne Grund und ohne
        // Frist. Diese Zeilen nennen beides.
        //
        // Bewusst ein eigener, kleiner Leser statt des Guard-Parsers: der Guard
        // ist nicht Teil des Programms, und diese Auskunft ist reine Anzeige.
        // Sie entscheidet nichts - die Sperre selbst setzt der Dienst.
        public static readonly string CanaryFailClosedPath =
            Path.Combine(DataDir, "canary-fail-closed.json");

        public static string[] ActiveCanaryFailClosedBlocks(string path, DateTime nowUtc)
        {
            List<string> lines = new List<string>();
            try
            {
                if (!File.Exists(path))
                {
                    return lines.ToArray();
                }

                FileInfo info = new FileInfo(path);
                if (info.Length > 16384)
                {
                    return lines.ToArray();
                }

                string json = File.ReadAllText(path, Encoding.UTF8);
                foreach (Match match in Regex.Matches(
                    json,
                    "\"domain\":\"(?<domain>[^\"\\\\]*)\"[^}]*?\"blockUntilUtc\":\"(?<until>[^\"\\\\]*)\"",
                    RegexOptions.Singleline))
                {
                    DateTime until;
                    if (!DateTime.TryParse(
                            match.Groups["until"].Value,
                            CultureInfo.InvariantCulture,
                            DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal,
                            out until) ||
                        until <= nowUtc)
                    {
                        continue;
                    }

                    string domain = match.Groups["domain"].Value;
                    if (domain.Length == 0)
                    {
                        continue;
                    }

                    lines.Add(domain + " — bis " + until.ToLocalTime().ToString("dd.MM.yyyy HH:mm"));
                }
            }
            catch
            {
            }

            return lines.ToArray();
        }
    }
}
