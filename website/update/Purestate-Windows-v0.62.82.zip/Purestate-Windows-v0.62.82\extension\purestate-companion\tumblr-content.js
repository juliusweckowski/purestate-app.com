"use strict";

const TUMBLR_BLOCKED_ATTRIBUTE = "data-purestate-tumblr-blocked";
const TUMBLR_PLACEHOLDER_ATTRIBUTE = "data-purestate-tumblr-placeholder";
const TUMBLR_STYLE_ID = "purestate-tumblr-shield-style";
const TUMBLR_INSTANT_STYLE_ID = "purestate-tumblr-instant-style";
const TUMBLR_SEARCH_OVERLAY_ID = "purestate-tumblr-search-overlay";
const TUMBLR_POST_SELECTOR = [
  "article[data-id]",
  ".post[data-id]",
  "div[data-id][data-type]",
  "[data-is-tumblr-post]"
].join(",");
// Legacy attribute markers. Modern Tumblr no longer emits these on rendered
// posts, but we keep them as a cheap defense-in-depth layer.
const TUMBLR_NSFW_ATTRIBUTE_SELECTOR = [
  "[data-is-nsfw='true']",
  "[data-content-rating='nsfw']",
  "[data-content-rating='explicit']",
  "[data-tumblelog-content-rating='nsfw']",
  "[data-tumblelog-content-rating='explicit']",
  ".is-nsfw[data-id]"
].join(",");
const TUMBLR_MEDIA_SELECTOR = [
  "img",
  "video",
  "figure",
  "picture",
  "iframe[src]",
  "[style*='background-image']"
].join(",");
// Centralized: the NSFW search-term list lives in adult-search-terms.js (loaded
// first in the manifest) so it is extended in one place across every site.
const TUMBLR_ADULT_SEARCH_PATTERN = purestateAdultSearchPattern();
// Tumblr renders a "community label" badge on flagged posts. The badge text is
// the only stable signal: the surrounding classes are build-hashed and there
// are no nsfw data-attributes on the rendered DOM. Confirmed German strings:
// "Inhalt für Erwachsene" and "Potenziell jugendgefährdende Inhalte".
const TUMBLR_LABEL_TEXT_PATTERN = /(?:inhalt(?:e)?\s+für\s+erwachsene|jugendgef[äa]hrdende?\s+inhalte|sexuelle\s+themen|adult\s+content|mature\s+content|sexual\s+themes)/i;

// Account settings (Einstellungen) toggles we keep locked.
const TUMBLR_SETTING_SHOW_ADULT_PATTERN = /(?:inhalt(?:e)?\s+für\s+erwachsene\s+anzeigen|show\s+adult\s+content|view\s+adult\s+content)/i;
const TUMBLR_SETTING_BLUR_ADULT_PATTERN = /(?:inhalt(?:e)?\s+für\s+erwachsene\s+unkenntlich|blur\s+adult\s+content)/i;

let tumblrObserver = null;
let tumblrScanTimer = 0;
let tumblrInterval = 0;
let lastTumblrLocation = "";
const tumblrControlLastClick = new WeakMap();

purestateRunWhenSiteProtectionEnabled("tumblr", () => {
  installTumblrInstantHide();
  installTumblrShieldStyle();
  installTumblrSettingsGuard();
  installTumblrMonitoring();
});

// Runs synchronously at document_start. If the current URL is an adult search/
// tag, hide page content from the very first paint so blocked posts never flash
// before the overlay is built.
function installTumblrInstantHide() {
  if (!document.documentElement) {
    return;
  }
  if (isTumblrAdultUrl()) {
    purestateInstantHide(document, TUMBLR_INSTANT_STYLE_ID);
  }
}

function installTumblrShieldStyle() {
  purestateInjectStyle(
    document,
    TUMBLR_STYLE_ID,
    "[" + TUMBLR_BLOCKED_ATTRIBUTE + "='true'] > :not([" + TUMBLR_PLACEHOLDER_ATTRIBUTE + "='true']) {\n" +
      "  display: none !important;\n" +
      "  visibility: hidden !important;\n" +
      "}"
  );
}

function installTumblrMonitoring() {
  if (tumblrObserver) {
    return;
  }
  scanTumblr(document);
  enforceTumblrSettings(document);
  tumblrObserver = new MutationObserver(() => {
    scheduleTumblrScan();
  });
  tumblrObserver.observe(document.documentElement, { childList: true, subtree: true });
  tumblrInterval = setInterval(() => {
    const current = location.href;
    if (current !== lastTumblrLocation) {
      lastTumblrLocation = current;
      // URL changed (SPA navigation): re-evaluate the instant hide so adult
      // searches reached without a full reload still blank instantly.
      if (isTumblrAdultUrl()) {
        purestateInstantHide(document, TUMBLR_INSTANT_STYLE_ID);
      } else {
        purestateRemoveInstantHide(document, TUMBLR_INSTANT_STYLE_ID);
      }
      scanTumblr(document);
    }
    enforceTumblrSettings(document);
    observeTumblrCanary();
  }, 1200);
}

// Selector canary (diagnostics only, see purestateCanaryObserve): when this
// document IS the account-settings page (/settings/account, verified live
// 2026-06-28), the two guarded adult-content toggles must be findable via
// their label captions. 15 consecutive 1.2s-tick misses report a break -
// either Tumblr moved the toggles or changed the caption wording this module
// matches on.
function observeTumblrCanary() {
  purestateCanaryObserve(
    "tumblr",
    "settings-toggles",
    /^\/settings\/account/i.test(location.pathname || ""),
    !!(tumblrSettingControl(TUMBLR_SETTING_SHOW_ADULT_PATTERN) ||
       tumblrSettingControl(TUMBLR_SETTING_BLUR_ADULT_PATTERN))
  );
}

function scheduleTumblrScan() {
  clearTimeout(tumblrScanTimer);
  tumblrScanTimer = setTimeout(() => {
    scanTumblr(document);
    enforceTumblrSettings(document);
  }, 80);
}

function scanTumblr(root) {
  if (!root || typeof root.querySelectorAll !== "function") {
    return;
  }
  if (isTumblrAdultUrl()) {
    purestateInstantHide(document, TUMBLR_INSTANT_STYLE_ID);
    showTumblrSearchOverlay(root);
  } else {
    hideTumblrSearchOverlay(root);
  }
  // Block NSFW posts regardless of URL, so adult results are removed from the
  // DOM even underneath the search overlay (defense in depth).
  for (const post of root.querySelectorAll(TUMBLR_NSFW_ATTRIBUTE_SELECTOR)) {
    if (post.getAttribute(TUMBLR_BLOCKED_ATTRIBUTE) === "true") {
      continue;
    }
    blockTumblrPost(post);
  }
  // Primary path: scan rendered posts for a community-label badge.
  for (const post of tumblrCandidatePosts(root)) {
    if (post.getAttribute(TUMBLR_BLOCKED_ATTRIBUTE) === "true") {
      continue;
    }
    if (tumblrPostHasAdultLabel(post) || tumblrPostHasNsfwTag(post)) {
      blockTumblrPost(post);
    }
  }
}

// Returns the post-level containers on the page. Modern Tumblr wraps each
// timeline entry in a div whose data-id is the numeric post id; older/embedded
// layouts use article[data-id] or [data-is-tumblr-post]. We accept any element
// with a numeric data-id plus the legacy selector set.
function tumblrCandidatePosts(root) {
  const seen = new Set();
  const posts = [];
  for (const el of root.querySelectorAll("[data-id]")) {
    const id = el.getAttribute("data-id") || "";
    if (/^\d{6,}$/.test(id) && !seen.has(el)) {
      seen.add(el);
      posts.push(el);
    }
  }
  for (const el of root.querySelectorAll(TUMBLR_POST_SELECTOR)) {
    if (!seen.has(el)) {
      seen.add(el);
      posts.push(el);
    }
  }
  return posts;
}

function tumblrOwnText(el) {
  let text = "";
  for (const node of el.childNodes) {
    if (node.nodeType === 3) {
      text += node.textContent;
    }
  }
  return text.trim();
}

// A flagged post carries a short community-label badge somewhere in its header.
// We confirm the badge by matching the OWN text of a small element, which avoids
// blocking safe posts that merely mention these words in their body.
function tumblrPostHasAdultLabel(post) {
  for (const el of post.querySelectorAll("span,p,h2,h3,div")) {
    const text = tumblrOwnText(el);
    if (text.length > 0 && text.length < 60 && TUMBLR_LABEL_TEXT_PATTERN.test(text)) {
      return true;
    }
  }
  return false;
}

function tumblrPostHasNsfwTag(post) {
  const tags = String(post.getAttribute("data-tags") || post.getAttribute("data-tag") || "");
  if (!tags) {
    return false;
  }
  const tagList = tags.toLowerCase().split(/[\s,]+/);
  return tagList.some((tag) => TUMBLR_ADULT_SEARCH_PATTERN.test(tag));
}

function isTumblrAdultUrl() {
  const path = (location.pathname || "").toLowerCase();
  const search = (location.search || "").toLowerCase();
  const tagMatch = path.match(/\/(?:search|tagged)\/([^/?#]+)/);
  if (tagMatch) {
    const term = decodeURIComponent(tagMatch[1]).replace(/[-_+]/g, " ").trim();
    if (TUMBLR_ADULT_SEARCH_PATTERN.test(term)) {
      return true;
    }
  }
  if (TUMBLR_ADULT_SEARCH_PATTERN.test(search)) {
    return true;
  }
  return false;
}

function blockTumblrPost(post) {
  post.setAttribute(TUMBLR_BLOCKED_ATTRIBUTE, "true");
  for (const media of post.querySelectorAll(TUMBLR_MEDIA_SELECTOR)) {
    if (media.getAttribute(TUMBLR_PLACEHOLDER_ATTRIBUTE) === "true") {
      continue;
    }
    media.style.setProperty("display", "none", "important");
    media.style.setProperty("visibility", "hidden", "important");
  }
  if (!post.querySelector("[" + TUMBLR_PLACEHOLDER_ATTRIBUTE + "='true']")) {
    const placeholder = purestateCurtainPlaceholder(
      document,
      purestateCurtainTheme(document),
      "18+ Beitrag blockiert",
      "",
      ["margin:4px 0"]
    );
    placeholder.setAttribute(TUMBLR_PLACEHOLDER_ATTRIBUTE, "true");
    post.insertBefore(placeholder, post.firstChild);
  }
}

function showTumblrSearchOverlay(root) {
  const doc = root && root.ownerDocument ? root.ownerDocument : root;
  if (!doc || !doc.documentElement) {
    return;
  }
  purestateShowSearchOverlay(
    doc,
    TUMBLR_SEARCH_OVERLAY_ID,
    "Diese Tumblr-Suche wurde durch Purestate blockiert."
  );
}

function hideTumblrSearchOverlay(root) {
  const doc = root && root.ownerDocument ? root.ownerDocument : root;
  if (!doc) {
    return;
  }
  purestateHideSearchOverlay(doc, TUMBLR_SEARCH_OVERLAY_ID, TUMBLR_INSTANT_STYLE_ID);
}

// --- Account settings enforcement -----------------------------------------
// Tumblr exposes two relevant toggles under Einstellungen as native
// <input type="checkbox"> elements wrapped in a <label> carrying the German
// caption. We keep "Inhalt für Erwachsene anzeigen" OFF and "... unkenntlich
// machen" ON, and block user attempts to flip them.

function installTumblrSettingsGuard() {
  document.addEventListener("pointerdown", guardTumblrSettingsClick, true);
  document.addEventListener("click", guardTumblrSettingsClick, true);
  document.addEventListener("change", guardTumblrSettingsClick, true);
  document.addEventListener("keydown", (event) => {
    if (!event || (event.key !== " " && event.key !== "Enter")) {
      return;
    }
    guardTumblrSettingsClick(event);
  }, true);
}

function tumblrSettingControl(pattern) {
  for (const label of document.querySelectorAll("label")) {
    const text = String(label.textContent || "");
    if (!pattern.test(text)) {
      continue;
    }
    const input = label.querySelector("input[type='checkbox']")
      || label.querySelector("[role='switch']");
    if (input) {
      return input;
    }
  }
  return null;
}

function tumblrControlChecked(control) {
  if (typeof control.checked === "boolean") {
    return control.checked;
  }
  const aria = String(control.getAttribute && control.getAttribute("aria-checked") || "").toLowerCase();
  return aria === "true";
}

function enforceTumblrSettings(root) {
  if (!root || !root.querySelectorAll) {
    return;
  }
  enforceTumblrControl(tumblrSettingControl(TUMBLR_SETTING_SHOW_ADULT_PATTERN), false);
  enforceTumblrControl(tumblrSettingControl(TUMBLR_SETTING_BLUR_ADULT_PATTERN), true);
}

// Flips a control toward the desired state, throttled per control so we give
// Tumblr's React onChange handler time to settle and never fight our own click.
function enforceTumblrControl(control, wantChecked) {
  if (!control) {
    return;
  }
  const last = tumblrControlLastClick.get(control) || 0;
  if (Date.now() - last < 1000) {
    return;
  }
  if (tumblrControlChecked(control) !== wantChecked) {
    tumblrControlLastClick.set(control, Date.now());
    clickTumblrControl(control);
  }
}

function clickTumblrControl(control) {
  try {
    control.click();
  } catch {
  }
}

function guardTumblrSettingsClick(event) {
  // Skip our own synthetic clicks so enforcement can flip controls back.
  if (event && event.isTrusted === false) {
    return;
  }
  const target = event && event.target;
  if (!target || !target.closest) {
    return;
  }
  const label = target.closest("label");
  if (!label) {
    return;
  }
  const text = String(label.textContent || "");
  const isShowAdult = TUMBLR_SETTING_SHOW_ADULT_PATTERN.test(text);
  const isBlurAdult = TUMBLR_SETTING_BLUR_ADULT_PATTERN.test(text);
  if (!isShowAdult && !isBlurAdult) {
    return;
  }
  const input = label.querySelector("input[type='checkbox']") || label.querySelector("[role='switch']");
  const checked = input ? tumblrControlChecked(input) : false;
  // Block only the change that moves a control into the unsafe direction:
  // turning "show adult" ON, or turning "blur adult" OFF.
  const unsafe = (isShowAdult && !checked) || (isBlurAdult && checked);
  if (!unsafe) {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  if (event.stopImmediatePropagation) {
    event.stopImmediatePropagation();
  }
  setTimeout(() => enforceTumblrSettings(document), 50);
}
