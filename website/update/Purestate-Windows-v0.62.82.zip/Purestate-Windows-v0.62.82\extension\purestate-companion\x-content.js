"use strict";

const X_POST_SELECTOR = "article[data-testid='tweet']";
const X_BLOCKED_ATTRIBUTE = "data-purestate-x-media-blocked";
const X_PLACEHOLDER_ATTRIBUTE = "data-purestate-x-placeholder";
const X_STANDALONE_BLOCKED_ATTRIBUTE = "data-purestate-x-tile-blocked";
const X_STANDALONE_PLACEHOLDER_ATTRIBUTE = "data-purestate-x-tile-placeholder";
const X_STYLE_ID = "purestate-x-shield-style";
const X_SEARCH_OVERLAY_ID = "purestate-x-search-overlay";
const X_APP_INERT_ATTRIBUTE = "data-purestate-x-inert";
const X_SENSITIVE_IDS_ATTRIBUTE = "data-purestate-x-sensitive-posts";
const X_SENSITIVE_IDS_EVENT = "purestate-x-sensitive-posts";
const X_SETTING_CONTROL_SELECTOR = "input[type='checkbox'], [role='checkbox'], [role='switch']";
const X_STANDALONE_MEDIA_SELECTOR = "img, video, [data-testid='tweetPhoto'], [data-testid='videoPlayer'], [style*='background-image']";
const X_MEDIA_SELECTOR = [
  "[data-testid='tweetPhoto']",
  "[data-testid='videoPlayer']",
  "[data-testid='card.wrapper']",
  "[data-testid='videoComponent']",
  "video"
].join(",");
const X_NATIVE_SIGNAL_SELECTOR = [
  "[data-testid*='sensitive' i]",
  "[data-testid*='warning' i]",
  "[aria-label*='sensitive' i]",
  "[aria-label*='sensib' i]",
  "[aria-label*='adult content' i]",
  "[aria-label*='18+' i]"
].join(",");
const X_WARNING_PATTERN = /(?:potentially sensitive|possibly sensitive|sensitive (?:content|media)|warning:\s*(?:sensitive content|nudity|adult content)|\bnudity\b|adult content|sexually explicit|sexual content|graphic nudity|contains nudity|the following media includes|sensible (?:inhalte|medien)|potenziell sensibel|m\u00f6glicherweise sensibel|erwachseneninhalt|sexuelle inhalte|nicht jugendfrei)/i;
const X_REVEAL_ACTION_PATTERN = /^(?:show|view|anzeigen|einblenden)$/i;
const X_RISKY_GRID_WARNING_THRESHOLD = 1;
const X_ADULT_LINK_PATTERN = /(?:2cams\.org|justfor\.fans|justforfans\.com|loyalfans\.com|manyvids\.com|redgifs\.com|onlyfans\.com|fansly\.com|pornhub\.com|xvideos\.com|xnxx\.com|rule34\.(?:xxx|paheal\.net)|chaturbate\.com|stripchat\.com|livejasmin\.com|cam4\.com)/i;
// Centralized: the NSFW search-term list lives in adult-search-terms.js (loaded
// first in the manifest) so it is extended in one place across every site.
const X_ADULT_SEARCH_PATTERN = purestateAdultSearchPattern();
const X_DISPLAY_SENSITIVE_SETTING_PATTERN = /(?:display media that may contain sensitive content|medien anzeigen[^.]{0,120}(?:sensible|sensitive) inhalte|medien[^.]{0,120}(?:sensible|sensitive) inhalte[^.]{0,80}anzeigen)/i;
const X_HIDE_SENSITIVE_SETTING_PATTERN = /(?:hide sensitive content|(?:sensible|sensitive) inhalte ausblenden)/i;

let xObserver = null;
let xScanTimer = 0;
let xInterval = 0;
let xReloadRequested = false;
let xNavigationHooksInstalled = false;
const xSettingChangeAttempts = new WeakMap();
const xRiskyMediaGrids = new Set();
const xSensitivePostIds = new Set();

purestateRunWhenSiteProtectionEnabled("x", () => {
  installXSensitiveMetadataListener();
  installXMonitoring();
});

function installXSensitiveMetadataListener() {
  refreshXSensitivePostIds();
  document.addEventListener(X_SENSITIVE_IDS_EVENT, () => {
    refreshXSensitivePostIds();
    scheduleXScan();
  });
}

function refreshXSensitivePostIds() {
  const value = document.documentElement
    ? String(document.documentElement.getAttribute(X_SENSITIVE_IDS_ATTRIBUTE) || "")
    : "";
  for (const id of value.split(",")) {
    if (/^\d{5,25}$/.test(id)) {
      xSensitivePostIds.add(id);
    }
  }
}

function installXMonitoring() {
  if (xObserver || !xExtensionContextAvailable()) {
    return;
  }

  if (!document.documentElement) {
    document.addEventListener("readystatechange", installXMonitoring, { once: true });
    return;
  }

  installXShieldStyle();
  installXNavigationHooks();
  xObserver = new MutationObserver(() => scheduleXScan());
  xObserver.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["aria-label", "data-testid"]
  });

  window.addEventListener("popstate", handleXNavigation);
  window.addEventListener("hashchange", handleXNavigation);
  document.addEventListener("readystatechange", scheduleXScan);
  document.addEventListener("pointerdown", guardXBlockedMediaClick, true);
  document.addEventListener("click", guardXBlockedMediaClick, true);
  document.addEventListener("click", guardXSettingsClick, true);
  xInterval = setInterval(scheduleXScan, 1200);
  scheduleXScan();
}

function installXNavigationHooks() {
  if (xNavigationHooksInstalled) {
    return;
  }
  xNavigationHooksInstalled = true;

  const originalPushState = history.pushState;
  const originalReplaceState = history.replaceState;
  history.pushState = function pushState() {
    const result = originalPushState.apply(this, arguments);
    handleXNavigation();
    return result;
  };
  history.replaceState = function replaceState() {
    const result = originalReplaceState.apply(this, arguments);
    handleXNavigation();
    return result;
  };
}

function handleXNavigation() {
  if (!blockXAdultNavigation()) {
    scheduleXScan();
  }
}

function scheduleXScan() {
  if (!xExtensionContextAvailable()) {
    reloadXAfterExtensionUpdate();
    return;
  }

  if (xScanTimer) {
    return;
  }

  xScanTimer = setTimeout(() => {
    xScanTimer = 0;
    if (blockXAdultNavigation()) {
      return;
    }
    enforceXSafeSettings(document);
    scanXStandaloneWarnings(document);
    scanXPosts(document);
  }, 60);
}

function blockXAdultNavigation() {
  if (!xAdultSearchFromLocation(window.location.href) && !xAdultSearchFromVisibleControls(document)) {
    removeXSearchOverlay();
    return false;
  }

  showXSearchOverlay();
  return true;
}

function xAdultSearchFromLocation(input) {
  try {
    const url = new URL(String(input || ""), "https://x.com/");
    const path = url.pathname.toLowerCase();
    let value = "";

    if (/\/search\/?$/.test(path)) {
      value = [url.searchParams.get("q"), url.searchParams.get("query")].filter(Boolean).join(" ");
    } else {
      const hashtag = path.match(/\/hashtag\/([^/?#]+)/i);
      if (hashtag) {
        value = hashtag[1];
      }
    }

    try {
      value = decodeURIComponent(value);
    } catch {
    }
    return X_ADULT_SEARCH_PATTERN.test(value.replace(/[+_%-]+/g, " "));
  } catch {
    return false;
  }
}

function xNormalizeSearchText(input) {
  return String(input || "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[+_%-]+/g, " ")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function xAdultSearchFromVisibleControls(root) {
  if (!root || !root.querySelectorAll) {
    return false;
  }
  const controls = root.querySelectorAll("input, textarea, [role='searchbox']");
  for (const control of controls) {
    const label = xNormalizeSearchText(
      String(control.getAttribute && control.getAttribute("aria-label") || "") + " " +
      String(control.getAttribute && control.getAttribute("placeholder") || "")
    );
    if (label && !/\b(search|suche|suchen)\b/.test(label)) {
      continue;
    }
    const value = xNormalizeSearchText(
      purestateSettledSearchText(control, String(control.value || "")) + " " +
      purestateSettledSearchText(control, String(control.textContent || ""))
    );
    if (value && X_ADULT_SEARCH_PATTERN.test(value)) {
      return true;
    }
  }
  return false;
}

function showXSearchOverlay() {
  if (!document.documentElement || document.getElementById(X_SEARCH_OVERLAY_ID)) {
    return;
  }

  // XCO-003: Hier fehlte purestateInstantHide - anders als bei den drei
  // anderen Suchsperren des Produkts (content.js, bluesky-content.js). Bis der
  // Vorhang steht, liegen der asynchrone Site-Schalter und die Entprellung
  // dazwischen. X rendert seine Trefferliste erst nach eigenen Netzabfragen,
  // der Vorhang gewinnt das Rennen also meistens - aber "meistens" ist keine
  // Zusicherung, und die anderen drei brauchen sie auch nicht.
  if (typeof purestateInstantHide === "function") {
    purestateInstantHide(document, X_SEARCH_OVERLAY_ID + "-style");
  }

  const appRoot = document.getElementById("react-root");
  if (appRoot) {
    appRoot.setAttribute(X_APP_INERT_ATTRIBUTE, "true");
    appRoot.inert = true;
  }

  // XCO-003, zweiter Punkt: "inert" sperrt Eingaben, haelt aber laufende
  // Videos und Ton NICHT an. pauseXMedia steht in derselben Datei und wurde
  // hier nicht gerufen - dieselbe Luecke wie bei RDT-001. Ein Vorhang, hinter
  // dem weiter Ton laeuft, ist kein Vorhang.
  if (document.body) {
    pauseXMedia(document.body);
  }

  purestateShowSearchOverlay(
    document,
    X_SEARCH_OVERLAY_ID,
    "Diese X-Suche wurde durch Purestate blockiert."
  );
}

function removeXSearchOverlay() {
  purestateHideSearchOverlay(document, X_SEARCH_OVERLAY_ID);

  // XCO-003: Aufdecken an derselben Stelle, an der der Vorhang faellt - sonst
  // bliebe die Seite unsichtbar, obwohl sie freigegeben ist.
  if (typeof purestateRemoveInstantHide === "function") {
    purestateRemoveInstantHide(document, X_SEARCH_OVERLAY_ID + "-style");
  }

  const appRoot = document.querySelector("[" + X_APP_INERT_ATTRIBUTE + "='true']");
  if (appRoot) {
    appRoot.inert = false;
    appRoot.removeAttribute(X_APP_INERT_ATTRIBUTE);
  }
}

// XCO-004: Die Einstellung "Sensible Inhalte anzeigen" existiert
// ausschliesslich unter /settings. Die Durchsetzung lief trotzdem bei JEDEM
// Takt ueber alle Kontrollelemente des Dokuments und rief je Treffer
// xSensitiveSetting, das bis zu sieben Vorfahren mit textContent verkettet.
// Das Schwesternmodul hat dieses Gate laengst
// (content.js, isRedditSafeSearchRelevantPage).
function isXSettingsRelevantPage() {
  return String(location.pathname || "").toLowerCase().indexOf("/settings") !== -1;
}

function enforceXSafeSettings(root) {
  if (!root || !root.querySelectorAll || !isXSettingsRelevantPage()) {
    return;
  }

  for (const control of root.querySelectorAll(X_SETTING_CONTROL_SELECTOR)) {
    const setting = xSensitiveSetting(control);
    if (!setting) {
      continue;
    }

    // Already safe: lock it so it cannot be clicked at all.
    if (xControlChecked(control) === setting.secureChecked) {
      lockXSensitiveControl(control, setting.row);
      continue;
    }

    const lastAttempt = xSettingChangeAttempts.get(control) || 0;
    if (Date.now() - lastAttempt < 1500) {
      continue;
    }

    xSettingChangeAttempts.set(control, Date.now());
    try {
      control.click();
    } catch {
    }
    // Re-lock once it settles into the safe state.
    setTimeout(() => lockXSensitiveControl(control, setting.row), 250);
  }
}

function guardXSettingsClick(event) {
  if (!event || event.isTrusted === false) {
    return;
  }

  const control = xSettingControlFromTarget(event.target);
  const setting = control ? xSensitiveSetting(control) : null;
  if (!setting || xControlChecked(control) !== setting.secureChecked) {
    return;
  }

  event.preventDefault();
  event.stopPropagation();
  if (event.stopImmediatePropagation) {
    event.stopImmediatePropagation();
  }
}

function xSettingControlFromTarget(target) {
  if (!target || !target.closest) {
    return null;
  }

  const direct = target.closest(X_SETTING_CONTROL_SELECTOR);
  if (direct) {
    return direct;
  }

  let node = target;
  for (let depth = 0; node && depth < 6; depth += 1, node = node.parentElement) {
    if (!node.querySelectorAll) {
      continue;
    }
    const controls = node.querySelectorAll(X_SETTING_CONTROL_SELECTOR);
    if (controls.length === 1 && xSensitiveSetting(controls[0])) {
      return controls[0];
    }
  }
  return null;
}

function xSensitiveSetting(control) {
  let node = control;
  for (let depth = 0; node && depth < 7; depth += 1, node = node.parentElement) {
    const text = [node.getAttribute && node.getAttribute("aria-label"), node.textContent].join(" ").replace(/\s+/g, " ").trim();
    const displaySetting = X_DISPLAY_SENSITIVE_SETTING_PATTERN.test(text);
    const hideSetting = X_HIDE_SENSITIVE_SETTING_PATTERN.test(text);
    if (displaySetting !== hideSetting) {
      return { secureChecked: hideSetting, row: node };
    }
    if (text.length > 1200) {
      break;
    }
  }
  return null;
}

// Makes the sensitive-content setting control literally un-clickable once it is
// in its safe state. X re-renders, so this is re-applied every enforcement tick.
// pointer-events:none does not block our programmatic control.click(), so
// enforcement can still flip it if X ever resets it.
function lockXSensitiveControl(control, row) {
  for (const node of [control, row]) {
    if (node && node.style && node.style.setProperty) {
      node.style.setProperty("pointer-events", "none", "important");
      node.style.setProperty("cursor", "not-allowed", "important");
    }
  }
}

function xControlChecked(control) {
  if (typeof control.checked === "boolean") {
    return control.checked;
  }

  const ariaChecked = String(control.getAttribute("aria-checked") || "").toLowerCase();
  if (ariaChecked === "true" || ariaChecked === "false") {
    return ariaChecked === "true";
  }

  const state = String(control.getAttribute("data-state") || "").toLowerCase();
  return state === "checked" || state === "on";
}

function scanXPosts(root) {
  if (!root || !root.querySelectorAll) {
    return;
  }

  const posts = [];
  if (root.nodeType === 1 && root.matches && root.matches(X_POST_SELECTOR)) {
    posts.push(root);
  }
  for (const post of root.querySelectorAll(X_POST_SELECTOR)) {
    posts.push(post);
  }

  for (const post of posts) {
    if (post.getAttribute(X_BLOCKED_ATTRIBUTE) === "true") {
      continue;
    }

    const decision = xPostDecision(post);
    if (decision) {
      blockXPostMedia(post, decision);
    }
  }
}

function scanXStandaloneWarnings(root) {
  if (!root || !root.querySelectorAll || !xStandaloneMediaPage()) {
    return;
  }

  const scope = root.querySelector("main") || root;
  refreshXSensitivePostIds();
  for (const link of scope.querySelectorAll("a[href*='/status/']")) {
    const statusId = xStatusIdFromHref(link.getAttribute("href"));
    if (statusId && xSensitivePostIds.has(statusId)) {
      const tile = xStatusMediaLink(link);
      if (tile) {
        blockXStandaloneTile(tile);
      }
    }
  }

  const signals = xWarningSignalsWithin(scope, 5000);
  for (const signal of signals.filter((item) => !item.closest || !item.closest(X_POST_SELECTOR))) {

    const tile = xStandaloneMediaRoot(signal);
    if (tile) {
      blockXStandaloneTile(tile);
    }
  }

  const gridKey = xMediaGridKey();
  if (gridKey && signals.length >= X_RISKY_GRID_WARNING_THRESHOLD) {
    xRiskyMediaGrids.add(gridKey);
  }
  if (gridKey && xRiskyMediaGrids.has(gridKey)) {
    blockXRiskyMediaGrid(scope);
  }
}

function xStandaloneMediaPage() {
  try {
    const url = new URL(window.location.href);
    return /\/search\/?$/i.test(url.pathname) || /\/media\/?$/i.test(url.pathname);
  } catch {
    return false;
  }
}

function xMediaGridKey() {
  try {
    const url = new URL(window.location.href);
    const path = url.pathname.toLowerCase();
    const isSearchMedia = /\/search\/?$/i.test(path) && String(url.searchParams.get("f") || "").toLowerCase() === "media";
    const isProfileMedia = /\/media\/?$/i.test(path);
    if (!isSearchMedia && !isProfileMedia) {
      return "";
    }
    return path + "|" + String(url.searchParams.get("q") || "").trim().toLowerCase();
  } catch {
    return "";
  }
}

function blockXRiskyMediaGrid(scope) {
  for (const link of scope.querySelectorAll("a[href*='/status/']")) {
    if (link.getAttribute(X_STANDALONE_BLOCKED_ATTRIBUTE) === "true") {
      continue;
    }

    const containsMedia = Boolean(
      (link.matches && link.matches(X_STANDALONE_MEDIA_SELECTOR)) ||
      (link.querySelector && link.querySelector(X_STANDALONE_MEDIA_SELECTOR))
    );
    if (containsMedia) {
      blockXStandaloneTile(link);
    }
  }
}

function xStatusIdFromHref(href) {
  try {
    const url = new URL(String(href || ""), window.location.href);
    const match = url.pathname.match(/\/status\/(\d{5,25})(?:\/|$)/i);
    return match ? match[1] : "";
  } catch {
    return "";
  }
}

function xStatusMediaLink(link) {
  if (!link || !link.querySelector) {
    return null;
  }
  const containsMedia = Boolean(
    (link.matches && link.matches(X_STANDALONE_MEDIA_SELECTOR)) ||
    link.querySelector(X_STANDALONE_MEDIA_SELECTOR)
  );
  return containsMedia ? link : null;
}

function xWarningSignalsWithin(root, limit) {
  const signals = [];
  const candidates = [];
  if (root.nodeType === 1 && root.matches && root.matches(X_NATIVE_SIGNAL_SELECTOR)) {
    candidates.push(root);
  }
  for (const element of root.querySelectorAll(X_NATIVE_SIGNAL_SELECTOR)) {
    candidates.push(element);
    if (candidates.length >= limit) {
      break;
    }
  }

  if (candidates.length < limit) {
    for (const element of root.querySelectorAll("span, button, [role='button']")) {
      if (X_WARNING_PATTERN.test(String(element.textContent || ""))) {
        candidates.push(element);
      }
      if (candidates.length >= limit) {
        break;
      }
    }
  }

  for (const candidate of candidates) {
    // XCO-002: Auf dem BEITRAGSpfad wird ausdruecklich ausgeschlossen, dass der
    // Text des Beitrags selbst als Warnhinweis zaehlt (isXAuthorText, :698).
    // Auf dem Kachelpfad fehlte genau diese Pruefung - X_WARNING_PATTERN
    // enthaelt "nudity", "adult content", "sexual content", und ein Beitrag,
    // der diese Woerter NENNT, sperrte damit das Gitter. Dasselbe Muster wie
    // RDT-004 bei Reddit: die Ausnahme sass auf dem Pfad, wo der Fehlalarm
    // auffiel, nicht an beiden.
    if (isXTileAuthorText(candidate)) {
      continue;
    }
    const value = [candidate.getAttribute && candidate.getAttribute("aria-label"), candidate.textContent].join(" ");
    if (!X_WARNING_PATTERN.test(value)) {
      continue;
    }
    if (signals.some((existing) => existing.contains(candidate) || candidate.contains(existing))) {
      continue;
    }
    signals.push(candidate);
  }
  return signals;
}

function xStandaloneMediaRoot(signal) {
  const directLink = signal.closest ? signal.closest("a[href*='/status/']") : null;
  if (directLink) {
    return directLink;
  }

  let best = null;
  let node = signal.parentElement;
  for (let depth = 0; node && depth < 9; depth += 1, node = node.parentElement) {
    if (node.matches && node.matches("main, body")) {
      break;
    }

    const warnings = xWarningSignalsWithin(node, 3);
    const statusLinks = new Set();
    for (const link of node.querySelectorAll ? node.querySelectorAll("a[href*='/status/']") : []) {
      statusLinks.add(String(link.getAttribute("href") || ""));
      if (statusLinks.size > 1) {
        break;
      }
    }
    if (warnings.length > 1 || statusLinks.size > 1) {
      break;
    }

    const containsMedia = Boolean(
      (node.matches && node.matches(X_STANDALONE_MEDIA_SELECTOR)) ||
      (node.querySelector && node.querySelector(X_STANDALONE_MEDIA_SELECTOR))
    );
    if (warnings.length === 1 && (containsMedia || statusLinks.size === 1)) {
      best = node;
    }
  }
  return best;
}

function blockXStandaloneTile(tile) {
  if (!tile || !tile.appendChild || tile.getAttribute(X_STANDALONE_BLOCKED_ATTRIBUTE) === "true") {
    return;
  }

  tile.setAttribute(X_STANDALONE_BLOCKED_ATTRIBUTE, "true");
  tile.removeAttribute("href");
  tile.setAttribute("aria-disabled", "true");
  tile.style.setProperty("background-image", "none", "important");
  tile.style.setProperty("overflow", "hidden", "important");
  tile.style.setProperty("min-height", "150px", "important");

  for (const link of tile.querySelectorAll("a[href]")) {
    link.removeAttribute("href");
    link.setAttribute("aria-disabled", "true");
    link.addEventListener("click", preventXReveal);
  }

  const media = [];
  if (tile.matches && tile.matches(X_STANDALONE_MEDIA_SELECTOR)) {
    media.push(tile);
  }
  for (const item of tile.querySelectorAll(X_STANDALONE_MEDIA_SELECTOR)) {
    media.push(item);
  }
  for (const item of media) {
    if (item !== tile) {
      item.style.setProperty("display", "none", "important");
      pauseXMedia(item);
    }
  }

  for (const child of Array.from(tile.children || [])) {
    child.style.setProperty("display", "none", "important");
  }

  if (!tile.querySelector("[" + X_STANDALONE_PLACEHOLDER_ATTRIBUTE + "='true']")) {
    tile.appendChild(createXStandalonePlaceholder());
  }
}

function createXStandalonePlaceholder() {
  const placeholder = purestateCurtainPlaceholder(
    document,
    purestateCurtainTheme(document),
    "Sensible Medien blockiert",
    "",
    ["width:100%", "height:100%", "min-height:150px"]
  );
  placeholder.setAttribute(X_STANDALONE_PLACEHOLDER_ATTRIBUTE, "true");
  placeholder.setAttribute("role", "note");
  return placeholder;
}

function guardXBlockedMediaClick(event) {
  const target = event && event.target;
  if (!target || !target.closest) {
    return;
  }

  const blocked = target.closest("[" + X_STANDALONE_BLOCKED_ATTRIBUTE + "='true'],[" + X_BLOCKED_ATTRIBUTE + "='true']");
  if (blocked || xSensitiveRevealAttempt(target)) {
    event.preventDefault();
    event.stopPropagation();
    if (event.stopImmediatePropagation) {
      event.stopImmediatePropagation();
    }
    scheduleXScan();
  }
}

function xSensitiveRevealAttempt(target) {
  const actionText = String(target.textContent || "").replace(/\s+/g, " ").trim();
  if (!X_REVEAL_ACTION_PATTERN.test(actionText)) {
    return false;
  }

  let node = target;
  for (let depth = 0; node && depth < 7; depth += 1, node = node.parentElement) {
    const text = String(node.textContent || "").replace(/\s+/g, " ").trim();
    if (X_WARNING_PATTERN.test(text)) {
      return true;
    }
    if (text.length > 900 || (node.matches && node.matches("main, body"))) {
      break;
    }
  }
  return false;
}

function xPostDecision(post) {
  for (const link of post.querySelectorAll("a[href*='/status/']")) {
    const statusId = xStatusIdFromHref(link.getAttribute("href"));
    if (statusId && xSensitivePostIds.has(statusId)) {
      return { source: "x-sensitive-metadata", signal: null, link: null };
    }
  }

  const signal = xNativeWarningSignal(post);
  if (signal) {
    return { source: "native-warning", signal, link: null };
  }

  const link = xAdultLink(post);
  if (link) {
    return { source: "adult-link", signal: null, link };
  }

  return null;
}

function xNativeWarningSignal(post) {
  for (const element of post.querySelectorAll(X_NATIVE_SIGNAL_SELECTOR)) {
    if (!belongsToXPost(element, post) || isXAuthorText(element, post)) {
      continue;
    }

    const testId = String(element.getAttribute("data-testid") || "");
    const ariaLabel = String(element.getAttribute("aria-label") || "");
    const text = String(element.textContent || "");
    if (/sensitive|warning/i.test(testId) || X_WARNING_PATTERN.test(ariaLabel + " " + text)) {
      return element;
    }
  }

  const labels = post.querySelectorAll("span, button, [role='button']");
  const limit = Math.min(labels.length, 350);
  for (let index = 0; index < limit; index += 1) {
    const element = labels[index];
    if (belongsToXPost(element, post) && !isXAuthorText(element, post) && X_WARNING_PATTERN.test(String(element.textContent || ""))) {
      return element;
    }
  }

  return null;
}

function xAdultLink(post) {
  const links = post.querySelectorAll("a[href]");
  const limit = Math.min(links.length, 150);
  for (let index = 0; index < limit; index += 1) {
    const link = links[index];
    if (!belongsToXPost(link, post)) {
      continue;
    }

    const value = [
      link.getAttribute("href"),
      link.getAttribute("title"),
      link.getAttribute("aria-label"),
      link.getAttribute("data-expanded-url"),
      link.textContent
    ].join(" ");
    if (X_ADULT_LINK_PATTERN.test(value)) {
      return link;
    }
  }
  return null;
}

function belongsToXPost(element, post) {
  return Boolean(element && element.closest && element.closest(X_POST_SELECTOR) === post);
}

// XCO-002: Auf dem Kachelpfad gibt es keinen Beitrag zum Vergleichen, also
// genuegt hier die Zugehoerigkeit zum Beitragstext selbst - der Nachweis, dass
// der Treffer aus dem geschriebenen Text stammt und nicht aus einer Warnung von
// X.
function isXTileAuthorText(element) {
  return Boolean(element && element.closest && element.closest("[data-testid='tweetText']"));
}

function isXAuthorText(element, post) {
  const textContainer = element && element.closest ? element.closest("[data-testid='tweetText']") : null;
  return Boolean(textContainer && belongsToXPost(textContainer, post));
}

function xMediaTargets(post) {
  const targets = [];
  for (const candidate of post.querySelectorAll(X_MEDIA_SELECTOR)) {
    if (!belongsToXPost(candidate, post)) {
      continue;
    }

    if (targets.some((existing) => existing.contains(candidate))) {
      continue;
    }
    targets.push(candidate);
  }
  return targets;
}

function blockXPostMedia(post, decision) {
  if (post.getAttribute(X_BLOCKED_ATTRIBUTE) === "true") {
    return;
  }

  let targets = xMediaTargets(post);
  if (!targets.length && decision.signal) {
    const warningContainer = xWarningContainer(decision.signal, post);
    if (warningContainer) {
      targets = [warningContainer];
    }
  }

  if (!targets.length && decision.link) {
    const card = decision.link.closest("[data-testid='card.wrapper']");
    if (card && belongsToXPost(card, post)) {
      targets = [card];
    }
  }

  if (!targets.length) {
    return;
  }

  post.setAttribute(X_BLOCKED_ATTRIBUTE, "true");
  for (const target of targets) {
    target.style.setProperty("display", "none", "important");
    pauseXMedia(target);
  }

  if (decision.link) {
    decision.link.removeAttribute("href");
    decision.link.setAttribute("aria-disabled", "true");
    decision.link.addEventListener("click", preventXReveal);
  }

  for (const button of post.querySelectorAll("button, [role='button']")) {
    if (belongsToXPost(button, post) && X_WARNING_PATTERN.test(String(button.parentElement && button.parentElement.textContent || button.textContent || ""))) {
      button.setAttribute("aria-disabled", "true");
      button.addEventListener("click", preventXReveal);
    }
  }

  if (post.querySelector("[" + X_PLACEHOLDER_ATTRIBUTE + "='true']")) {
    return;
  }

  const firstTarget = targets[0];
  const host = firstTarget.parentElement || post;
  const placeholder = createXPlaceholder(decision.source);
  host.insertBefore(placeholder, firstTarget.parentElement === host ? firstTarget : host.firstChild);
}

function xWarningContainer(signal, post) {
  let best = signal;
  let node = signal;
  for (let depth = 0; node && depth < 5; depth += 1, node = node.parentElement) {
    if (node === post) {
      break;
    }
    best = node;
    if (node.querySelector && node.querySelector("button, [role='button']")) {
      break;
    }
  }
  return best === post ? null : best;
}

function pauseXMedia(root) {
  const players = [];
  if (root.matches && root.matches("video, audio")) {
    players.push(root);
  }
  for (const player of root.querySelectorAll ? root.querySelectorAll("video, audio") : []) {
    players.push(player);
  }

  for (const player of players) {
    try {
      player.muted = true;
      player.removeAttribute("autoplay");
      player.pause();
    } catch {
    }
  }
}

function preventXReveal(event) {
  event.preventDefault();
  event.stopPropagation();
}

function createXPlaceholder(source) {
  const placeholder = purestateCurtainPlaceholder(
    document,
    purestateCurtainTheme(document),
    source === "adult-link" ? "18+ Medien blockiert" : "Sensible Medien blockiert",
    "Purestate hat die Medien dieses X-Beitrags ausgeblendet.",
    ["width:100%", "min-height:96px", "padding:16px"]
  );
  placeholder.setAttribute(X_PLACEHOLDER_ATTRIBUTE, "true");
  placeholder.setAttribute("role", "note");
  return placeholder;
}

function installXShieldStyle() {
  purestateInjectStyle(
    document,
    X_STYLE_ID,
    [
      "[" + X_BLOCKED_ATTRIBUTE + "='true'] [data-testid='tweetPhoto'],",
      "[" + X_BLOCKED_ATTRIBUTE + "='true'] [data-testid='videoPlayer'],",
      "[" + X_BLOCKED_ATTRIBUTE + "='true'] [data-testid='card.wrapper'],",
      "[" + X_BLOCKED_ATTRIBUTE + "='true'] [data-testid='videoComponent'] {",
      "  display: none !important;",
      "}",
      "[" + X_BLOCKED_ATTRIBUTE + "='true'] [" + X_PLACEHOLDER_ATTRIBUTE + "='true'] {",
      "  display: flex !important;",
      "}",
      "[" + X_STANDALONE_BLOCKED_ATTRIBUTE + "='true'] > :not([" + X_STANDALONE_PLACEHOLDER_ATTRIBUTE + "='true']) {",
      "  display: none !important;",
      "}",
      "[" + X_STANDALONE_BLOCKED_ATTRIBUTE + "='true'] > [" + X_STANDALONE_PLACEHOLDER_ATTRIBUTE + "='true'] {",
      "  display: flex !important;",
      "}"
    ].join("\n")
  );
}

function xExtensionContextAvailable() {
  try {
    return typeof chrome !== "undefined" && Boolean(chrome.runtime && chrome.runtime.id);
  } catch {
    return false;
  }
}

function reloadXAfterExtensionUpdate() {
  if (xReloadRequested) {
    return;
  }
  xReloadRequested = true;

  if (xScanTimer) {
    clearTimeout(xScanTimer);
    xScanTimer = 0;
  }
  if (xInterval) {
    clearInterval(xInterval);
    xInterval = 0;
  }
  if (xObserver) {
    xObserver.disconnect();
    xObserver = null;
  }

  try {
    window.location.reload();
  } catch {
  }
}
