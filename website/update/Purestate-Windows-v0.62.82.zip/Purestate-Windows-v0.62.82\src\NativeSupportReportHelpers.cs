using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Purestate.Native
{
    internal static partial class Support
    {
        private static void AddDomainsToSet(System.Collections.Generic.SortedSet<string> target, System.Collections.Generic.IEnumerable<string> domains)
        {
            foreach (string domain in domains)
            {
                target.Add(domain);
            }
        }

        private static void AddRuleAuditProblems(System.Collections.Generic.List<string> problems, RuleFileAudit audit)
        {
            if (!audit.Exists)
            {
                if (string.Equals(audit.Title, "Haupt-Sperrliste", StringComparison.OrdinalIgnoreCase))
                {
                    problems.Add(audit.Title + " fehlt.");
                }

                return;
            }

            if (audit.InvalidLines.Count > 0)
            {
                problems.Add(audit.Title + " enthaelt ungueltige Eintraege.");
            }

            if (audit.DuplicateEntries > 0)
            {
                problems.Add(audit.Title + " enthaelt doppelte Domains.");
            }

            if (audit.ValidEntries == 0 && string.Equals(audit.Title, "Haupt-Sperrliste", StringComparison.OrdinalIgnoreCase))
            {
                problems.Add("Haupt-Sperrliste enthaelt keine gueltigen Domains.");
            }
        }

        private static void AppendRuleAudit(StringBuilder report, RuleFileAudit audit)
        {
            report.AppendLine(audit.Title + ":");
            report.AppendLine("- Datei: " + audit.Path);
            report.AppendLine("- Vorhanden: " + YesNo(audit.Exists));

            if (!audit.Exists)
            {
                report.AppendLine();
                return;
            }

            report.AppendLine("- Eintraege gelesen: " + audit.RawEntries);
            report.AppendLine("- Gueltige Domains: " + audit.ValidEntries);
            report.AppendLine("- Ungueltige Zeilen: " + audit.InvalidLines.Count);
            AppendLimitedValues(report, audit.InvalidLines, 10);
            report.AppendLine("- Doppelte Eintraege: " + audit.DuplicateEntries);
            AppendLimitedValues(report, audit.DuplicateDomains, 10);
            report.AppendLine();
        }

        private sealed class IntegrityManifestEntry
        {
            public string Path;
            public long Size;
            public string Sha256;
        }

        private sealed class IntegrityManifest
        {
            public bool Exists;
            public string AppVersion = string.Empty;
            public System.Collections.Generic.Dictionary<string, IntegrityManifestEntry> Files =
                new System.Collections.Generic.Dictionary<string, IntegrityManifestEntry>(StringComparer.OrdinalIgnoreCase);
        }

        private static IntegrityManifest LoadIntegrityManifest()
        {
            IntegrityManifest manifest = new IntegrityManifest();
            string path = Path.Combine(InstallDir, "PurestateManifest.txt");
            manifest.Exists = SafeFileExists(path);

            if (!manifest.Exists)
            {
                return manifest;
            }

            bool inFiles = false;
            try
            {
                foreach (string raw in File.ReadAllLines(path))
                {
                    string line = (raw ?? string.Empty).Trim();
                    if (line.Length == 0 || line.StartsWith("#"))
                    {
                        continue;
                    }

                    if (string.Equals(line, "[Files]", StringComparison.OrdinalIgnoreCase))
                    {
                        inFiles = true;
                        continue;
                    }

                    int equals = line.IndexOf('=');
                    if (!inFiles && equals > 0)
                    {
                        string name = line.Substring(0, equals).Trim();
                        string value = line.Substring(equals + 1).Trim();
                        if (string.Equals(name, "AppVersion", StringComparison.OrdinalIgnoreCase))
                        {
                            manifest.AppVersion = value;
                        }

                        continue;
                    }

                    if (inFiles)
                    {
                        string[] parts = line.Split('|');
                        if (parts.Length != 3)
                        {
                            continue;
                        }

                        long size;
                        if (!long.TryParse(parts[1], out size))
                        {
                            continue;
                        }

                        string relative = NormalizeManifestPath(parts[0]);
                        if (relative.Length == 0)
                        {
                            continue;
                        }

                        manifest.Files[relative] = new IntegrityManifestEntry
                        {
                            Path = relative,
                            Size = size,
                            Sha256 = parts[2].Trim().ToLowerInvariant()
                        };
                    }
                }
            }
            catch
            {
            }

            return manifest;
        }

        private static void AppendIntegrityFile(StringBuilder report, System.Collections.Generic.List<string> problems, string path, IntegrityManifest manifest)
        {
            string relative = RelativeInstallPath(path);
            string manifestKey = NormalizeManifestPath(relative);
            report.AppendLine(relative + ":");

            if (!SafeFileExists(path))
            {
                report.AppendLine("- Vorhanden: Nein");
                if (!relative.Equals(@"rules\allow-domains.txt", StringComparison.OrdinalIgnoreCase))
                {
                    problems.Add(relative + " fehlt.");
                }

                report.AppendLine();
                return;
            }

            try
            {
                FileInfo info = new FileInfo(path);
                string actualSha = ComputeSha256(path);
                report.AppendLine("- Vorhanden: Ja");
                report.AppendLine("- Groesse: " + info.Length + " Bytes");
                report.AppendLine("- Geaendert: " + info.LastWriteTime.ToString("s"));
                report.AppendLine("- SHA256: " + actualSha);

                IntegrityManifestEntry expected;
                if (manifest.Files.TryGetValue(manifestKey, out expected))
                {
                    bool sizeMatches = expected.Size == info.Length;
                    bool hashMatches = string.Equals(expected.Sha256, actualSha, StringComparison.OrdinalIgnoreCase);
                    report.AppendLine("- Manifest-Groesse: " + expected.Size + " Bytes");
                    report.AppendLine("- Manifest-SHA256: " + expected.Sha256);
                    report.AppendLine("- Manifest-Vergleich: " + (sizeMatches && hashMatches ? "OK" : "Abweichung"));

                    if (!sizeMatches || !hashMatches)
                    {
                        problems.Add(relative + " weicht vom Manifest ab.");
                    }
                }
                else if (manifest.Exists && !relative.Equals("PurestateManifest.txt", StringComparison.OrdinalIgnoreCase))
                {
                    report.AppendLine("- Manifest-Vergleich: Nicht im Manifest");
                    if (!relative.Equals(@"rules\allow-domains.txt", StringComparison.OrdinalIgnoreCase))
                    {
                        problems.Add(relative + " fehlt im Manifest.");
                    }
                }

                if (info.Length == 0)
                {
                    problems.Add(relative + " ist leer.");
                }

                if (relative.Equals(@"rules\adult-domains.txt", StringComparison.OrdinalIgnoreCase) && CountDomainsInPackageFile(path) < 100)
                {
                    problems.Add(relative + " enthaelt zu wenige gueltige Domains.");
                }

                if (relative.Equals(@"rules\mixed-site-url-patterns.txt", StringComparison.OrdinalIgnoreCase) && CountUrlPatternsInPackageFile(path) < 50)
                {
                    problems.Add(relative + " enthaelt zu wenige URL-Regeln.");
                }

                if (relative.Equals(@"rules\adult-url-keywords.txt", StringComparison.OrdinalIgnoreCase) && CountAdultUrlKeywordsInPackageFile(path) < 30)
                {
                    problems.Add(relative + " enthaelt zu wenige URL-Begriffe.");
                }

                if (relative.Equals(@"rules\nsfw-subreddits.txt", StringComparison.OrdinalIgnoreCase) && CountNsfwSubredditsInPackageFile(path) < 60)
                {
                    problems.Add(relative + " enthaelt zu wenige Reddit-18+-Communities.");
                }

                if (relative.Equals(@"extension\purestate-companion\rules\nsfw-subreddits.txt", StringComparison.OrdinalIgnoreCase) && CountNsfwSubredditsInPackageFile(path) < 60)
                {
                    problems.Add(relative + " enthaelt zu wenige Reddit-18+-Communities.");
                }

                if (relative.Equals(@"rules\bypass-app-keywords.txt", StringComparison.OrdinalIgnoreCase) && CountKeywordLinesInPackageFile(path) < 10)
                {
                    problems.Add(relative + " enthaelt zu wenige Umgehungs-App-Begriffe.");
                }

                if (relative.Equals(@"rules\unsupported-browser-keywords.txt", StringComparison.OrdinalIgnoreCase) && CountKeywordLinesInPackageFile(path) < 10)
                {
                    problems.Add(relative + " enthaelt zu wenige Begriffe fuer nicht unterstuetzte Browser.");
                }
            }
            catch (Exception ex)
            {
                // RPT-004: Hier stand ex.Message. .NET-IO-Meldungen enthalten
                // regelmaessig den VOLLSTAENDIGEN Pfad - derselbe unmaskierte
                // Pfad wie in RPT-002, und ausgerechnet im Fehlerfall gibt der
                // Nutzer den Bericht besonders wahrscheinlich weiter. Die
                // verwertbare Information, WELCHE Datei betroffen ist, steht
                // ohnehin in problems.
                report.AppendLine("- Fehler: " + ex.GetType().Name);
                problems.Add(relative + " konnte nicht gelesen werden.");
            }

            report.AppendLine();
        }

        private static string NormalizeManifestPath(string path)
        {
            return (path ?? string.Empty).Replace('/', '\\').Trim().TrimStart('\\');
        }

        private static string RelativeInstallPath(string path)
        {
            try
            {
                string root = Path.GetFullPath(InstallDir).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
                string full = Path.GetFullPath(path);
                if (full.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                {
                    return full.Substring(root.Length);
                }
            }
            catch
            {
            }

            return path;
        }

        private static string ComputeSha256(string path)
        {
            using (SHA256 sha = SHA256.Create())
            using (FileStream stream = File.OpenRead(path))
            {
                byte[] hash = sha.ComputeHash(stream);
                StringBuilder builder = new StringBuilder();
                foreach (byte item in hash)
                {
                    builder.Append(item.ToString("x2"));
                }

                return builder.ToString();
            }
        }

        private static int CountAllowConflictingDomains()
        {
            int count = 0;
            try
            {
                foreach (string domain in ReadExistingAllowDomains())
                {
                    if (IsDomainInLists(domain))
                    {
                        count++;
                    }
                }
            }
            catch
            {
                return 0;
            }

            return count;
        }

        private static int CountExistingAllowDomains()
        {
            return ReadExistingAllowDomains().Length;
        }

        private static string[] ReadExistingAllowDomains()
        {
            System.Collections.Generic.SortedSet<string> domains = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            string path = AllowDomainsPath();

            try
            {
                if (!File.Exists(path))
                {
                    return new string[0];
                }

                foreach (string raw in File.ReadAllLines(path))
                {
                    string domain = NormalizeDomain(raw);
                    if (IsValidDomain(domain))
                    {
                        domains.Add(domain);
                    }
                }
            }
            catch
            {
                return new string[0];
            }

            string[] result = new string[domains.Count];
            domains.CopyTo(result);
            return result;
        }

        private static string[] ReadSampleBlockDomains(int maxCount)
        {
            System.Collections.Generic.List<string> samples = new System.Collections.Generic.List<string>();
            System.Collections.Generic.HashSet<string> seen = new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
            string[] files =
            {
                Path.Combine(InstallDir, "rules", "adult-domains.txt"),
                Path.Combine(InstallDir, "rules", "custom-domains.txt")
            };

            foreach (string file in files)
            {
                try
                {
                    if (!File.Exists(file))
                    {
                        continue;
                    }

                    foreach (string raw in File.ReadAllLines(file))
                    {
                        string domain = NormalizeDomain(raw);
                        if (!IsValidDomain(domain) || seen.Contains(domain))
                        {
                            continue;
                        }

                        seen.Add(domain);
                        samples.Add(domain);
                        if (samples.Count >= Math.Max(1, maxCount))
                        {
                            return samples.ToArray();
                        }
                    }
                }
                catch
                {
                }
            }

            return samples.ToArray();
        }
    }
}
