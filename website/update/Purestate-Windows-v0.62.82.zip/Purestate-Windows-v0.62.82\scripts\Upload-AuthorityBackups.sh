#!/usr/bin/env bash
# Only encrypted snapshots go to the dedicated private B2 bucket.
set -euo pipefail
umask 077
[[ $EUID -eq 0 ]] || { echo 'Run as root.' >&2; exit 1; }
# Share the snapshot lock so an archive cannot be uploaded while being written.
exec 9>/run/purestate-backup.lock
flock -w 300 9
manifest=$(mktemp /run/purestate-upload.XXXXXXXX)
trap 'rm -f -- "$manifest"' EXIT
python3 - "$manifest" <<'PY'
import datetime, pathlib, re, sys
root = pathlib.Path('/var/backups/purestate')
names = []
times = []
now = datetime.datetime.now(datetime.timezone.utc)
for p in sorted(root.iterdir()):
    match = re.fullmatch(r'authority-(\d{8}T\d{6}Z)-[A-Za-z0-9]{6}\.tar\.gz\.age', p.name)
    if not match:
        continue
    stamp = datetime.datetime.strptime(match[1], '%Y%m%dT%H%M%SZ').replace(tzinfo=datetime.timezone.utc)
    # B2 hides after 89 upload-days and deletes one day later. Stop selecting
    # snapshots after 88 days to allow for B2's daily lifecycle boundary.
    # Local/server archives remain untouched; expired B2 copies stay expired.
    if (now - stamp).total_seconds() >= 88 * 86400:
        continue
    if p.is_symlink() or not p.is_file():
        raise SystemExit('Snapshot must be a regular file.')
    with p.open('rb') as f:
        if f.read(22) != b'age-encryption.org/v1\n':
            # Header is 22 bytes including newline.
            raise SystemExit('Snapshot has no age encryption header.')
    names.append(p.name)
    times.append(stamp)
if not names:
    raise SystemExit('No encrypted snapshots found.')
age = (now - max(times)).total_seconds()
if not -600 <= age <= 36 * 3600:
    raise SystemExit('No current snapshot (36-hour limit), or server clock incorrect.')
pathlib.Path(sys.argv[1]).write_text('\n'.join(names) + '\n', encoding='ascii')
PY
/usr/bin/rclone copy /var/backups/purestate b2:purestate-backups-julius-2026 \
    --config /etc/purestate-b2/rclone.conf --files-from-raw "$manifest" \
    --checksum --immutable --transfers 1 --checkers 2 \
    --retries 3 --retries-sleep 20s --contimeout 30s --timeout 2m --stats 0
/usr/bin/rclone check /var/backups/purestate b2:purestate-backups-julius-2026 \
    --config /etc/purestate-b2/rclone.conf --files-from-raw "$manifest" \
    --one-way --checkers 2 --contimeout 30s --timeout 2m --stats 0
echo 'B2 upload and remote checksum comparison succeeded.'
