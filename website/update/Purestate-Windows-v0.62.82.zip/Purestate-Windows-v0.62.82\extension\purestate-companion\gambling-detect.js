"use strict";

// Purestate: Gluecksspiel-Erkennung am Inhalt.
//
// Eine gepflegte Domainliste deckt nur ab, woran jemand gedacht hat - und
// gerade die unlizenzierten Anbieter KOENNEN auf keiner amtlichen Liste
// stehen. Dieses Modul entscheidet am Inhalt der Seite.
//
// Bewusste Grenzen:
// - Ein Treffer verlangt ZWEI unabhaengige Signale. Der Warnhinweis allein
//   steht auf jeder Seite, die ueber Spielsucht schreibt; Betriebswoerter
//   allein stehen bei jeder Bank.
// - Gelesen wird ausschliesslich die bereits geladene Seite. Kein Netz, kein
//   Speichern von Seiteninhalten.
// - ponytail: der JSON-LD-Leser ist eine kleine Kopie aus shopping-detect.js.
//   Zusammenlegen hiesse, ausgeliefertem und live geprueftem Code plus zwei
//   Manifest-Pins anzufassen, fuer knapp zwanzig gesparte Zeilen.

(function () {
  // Signal 1: Auflage, nicht Designgeschmack. Deutsche Lizenznehmer muessen
  // den Suchthinweis fuehren, Offshore-Anbieter tragen das Gegenstueck.
  const REGULATORY = new RegExp(
    "gl(?:ue|ü)cksspiel kann s(?:ue|ü)chtig machen" +
    "|spielsucht" +
    "|spielerschutz" +
    "|spielersperrsystem" +
    "|0800\\s*1372\\s*700" +
    "|gamble responsibly" +
    // Dieselbe Auflage, andere Formel. unibet.com fuehrt den Hinweis als
    // "Gambling can be addictive. Play responsibly" - die enge Fassung auf
    // "gamble responsibly" hat ihn nicht gesehen.
    "|play responsibly" +
    "|gambling can be addictive" +
    "|responsible gam(?:bl)?ing" +
    // Und noch einmal dieselbe Auflage auf Deutsch. stake.com fuehrt weder
    // Warnsatz noch Lizenzgeber im Text, sondern "Stake setzt sich fuer
    // verantwortungsvolles Gluecksspiel ein" - live gemessen die einzige
    // Seite ohne Signal 1. Nicht aufgenommen ist "Selbstausschluss": das
    // Wort haette denselben Dienst getan, steht aber auf jeder Beratungs-
    // und Aufsichtsseite und waere dort ein Signal 1 zu viel.
    "|verantwortungsvolles gl(?:ue|ü)cksspiel" +
    "|begambleaware" +
    "|gamcare" +
    "|gamstop" +
    "|curacao egaming" +
    "|antillephone" +
    "|anjouan gaming" +
    "|malta gaming authority",
    "i"
  );

  // Signal 2: ohne diese Woerter laesst sich kein Gluecksspielbetrieb fuehren.
  //
  // Die Lotterie-Woerter stehen bewusst mit dabei: lotto.de fuehrt den
  // Pflichthinweis, verkauft aber weder Wettschein noch Freispiel, und fiel
  // deshalb durch. Nicht aufgenommen ist "Gewinnzahlen" - das meldet jede
  // Nachrichtenseite am Samstagabend.
  const OPERATIONAL = new RegExp(
    "einzahlung" +
    "|auszahlung" +
    "|mindesteinsatz" +
    "|h(?:oe|ö)chsteinsatz" +
    "|freispiel" +
    "|wettschein" +
    "|wettquote" +
    "|echtgeld" +
    "|willkommensbonus" +
    "|umsatzbedingungen" +
    "|bonusbedingungen" +
    "|jetzt spielen" +
    "|jetzt wetten" +
    "|jetzt tippen" +
    // Wortgrenze, sonst stecken diese beiden in "Gluecksspielteilnahme" und
    // "Gluecksspieleinsatz" - den Woertern, mit denen jeder Fachtext ueber
    // Spielsucht arbeitet. Live gemessen: der Wikipedia-Artikel trug so
    // beide Signale und haing allein an der redaktionellen Ausnahme.
    "|\\bspielteilnahme" +
    "|\\bspieleinsatz" +
    "|spielschein" +
    "|tippschein" +
    "|lottoschein" +
    "|live-?wetten" +
    "|free spins" +
    "|betslip" +
    // Englische Betriebswoerter fuer die internationalen Auftritte. Bewusst
    // nur die beiden, die ausserhalb der Branche kaum vorkommen: "slots"
    // oder "sports betting" stehen auch in jedem Bericht ueber Spielsucht.
    "|sportsbook" +
    "|live dealer" +
    "|wagering requirement" +
    "|real money",
    "i"
  );

  // Ersatz fuer Signal 2: der eingebettete Spielanbieter selbst.
  const PROVIDER_SRC = new RegExp(
    "pragmaticplay|evolution(?:gaming)?|netent|playngo|play-?n-?go" +
    "|relaxgaming|redtiger|quickspin|betsoft|yggdrasil",
    "i"
  );

  // Deckel gegen sehr grosse Seiten. Gelesen werden Anfang UND Ende, nie nur
  // der Anfang: eine Wettseite bringt es gemessen auf ueber eine halbe
  // Million Zeichen, und der Pflichthinweis steht ueblicherweise im
  // Fussbereich. Ein reiner Kopf-Ausschnitt haette ihn dort abgeschnitten.
  const TEXT_HEAD = 60000;
  const TEXT_TAIL = 60000;

  function pageText(doc) {
    const body = doc && doc.body;
    const raw = String((body && body.textContent) || "");
    if (raw.length <= TEXT_HEAD + TEXT_TAIL) {
      return raw;
    }
    return raw.slice(0, TEXT_HEAD) + " " + raw.slice(raw.length - TEXT_TAIL);
  }

  function hasProviderFrame(doc) {
    let frames;
    try {
      frames = doc.querySelectorAll("iframe");
    } catch {
      return false;
    }
    for (const frame of Array.from(frames || []).slice(0, 60)) {
      const src = String((frame.getAttribute && frame.getAttribute("src")) || "");
      if (src && PROVIDER_SRC.test(src)) {
        return true;
      }
    }
    return false;
  }

  // Redaktionelle Seiten nennen beide Signalgruppen, ohne ein Angebot zu
  // sein. Dieselbe Regel, die im Shopping-Bereich den heise-Fehltreffer
  // geloest hat.
  const EDITORIAL_TYPES = /^(article|newsarticle|blogposting|liveblogposting|opinionnewsarticle|reportagenewsarticle)$/i;

  // Hilfe-, Beratungs- und Aufsichtsangebote. FEST IM CODE und per Test
  // gepinnt: konfigurierbar hiesse leerbar, und eine leerbare Ausnahmeliste
  // fuer Suchtberatung ist genau der Schalter, den man im Impuls umlegt.
  // Eine gesperrte Beratungsstelle waere Schaden am Zweck des Bereichs.
  //
  // Die Gluecksspielbehoerde steht bewusst mit hier und nicht nur unter der
  // redaktionellen Ausnahme: live gemessen fuehrt sie ueberhaupt kein
  // JSON-LD, die Ausnahme greift dort also nicht. Geschuetzt war sie damit
  // nur davon, dass auf der Startseite zufaellig kein Betriebswort steht -
  // "Spielerschutz" als Signal 1 traegt sie auf jeder Seite.
  const HELP_HOSTS = [
    "bzga.de",
    "gluecksspiel-behoerde.de",
    "check-dein-spiel.de",
    "spielen-mit-verantwortung.de",
    "gluecksspielsucht.de",
    "caritas.de",
    "diakonie.de",
    "telefonseelsorge.de",
    "dhs.de",
    "sucht.de",
    "bas-muenchen.de",
    "begambleaware.org",
    "gamcare.org.uk",
    "gamstop.co.uk"
  ];

  function isHelpHost(hostname) {
    const host = String(hostname || "").toLowerCase().replace(/^www\./, "");
    if (!host) {
      return false;
    }
    for (const entry of HELP_HOSTS) {
      // Suffix-Semantik: exakt oder Unterdomain. Nie Teilzeichenkette, sonst
      // waere "caritas-casino.example" eine Beratungsstelle.
      if (host === entry || host.endsWith("." + entry)) {
        return true;
      }
    }
    return false;
  }

  function eachJsonLd(doc, visit) {
    let scripts;
    try {
      scripts = doc.querySelectorAll('script[type="application/ld+json"]');
    } catch {
      return;
    }
    for (const script of Array.from(scripts || [])) {
      let data;
      try {
        data = JSON.parse(String((script && script.textContent) || ""));
      } catch {
        continue;
      }
      walk(data, 0);
    }
    function walk(node, depth) {
      if (!node || typeof node !== "object" || depth > 6) {
        return;
      }
      if (Array.isArray(node)) {
        for (const entry of node) {
          walk(entry, depth + 1);
        }
        return;
      }
      visit(node);
      for (const key of Object.keys(node)) {
        walk(node[key], depth + 1);
      }
    }
  }

  function isEditorial(doc) {
    let found = false;
    eachJsonLd(doc, (node) => {
      if (found) {
        return;
      }
      const types = Array.isArray(node["@type"]) ? node["@type"] : [node["@type"]];
      for (const type of types) {
        if (typeof type === "string" && EDITORIAL_TYPES.test(type.trim())) {
          found = true;
          return;
        }
      }
    });
    return found;
  }

  function detectGamblingPage(doc, hostname) {
    if (!doc || typeof doc.querySelectorAll !== "function") {
      return { gambling: false, reason: "" };
    }
    // Beide Ausnahmen stehen VOR der Erkennung: sie schlagen jedes Signal.
    if (isHelpHost(hostname)) {
      return { gambling: false, reason: "help-host" };
    }
    if (isEditorial(doc)) {
      return { gambling: false, reason: "editorial" };
    }
    const text = pageText(doc);
    // Der Grund benennt bei einem Nein, WELCHES Signal gefehlt hat. Er
    // steuert nichts - entschieden wird allein ueber gambling -, aber ohne
    // ihn ist am Pruefstand nicht zu sehen, ob eine Seite den Pflichthinweis
    // nicht fuehrt oder ob das Angebot in einem Rahmen steckt.
    if (!REGULATORY.test(text)) {
      return { gambling: false, reason: "kein Pflichthinweis" };
    }
    if (OPERATIONAL.test(text)) {
      return { gambling: true, reason: "regulatory-and-operational" };
    }
    if (hasProviderFrame(doc)) {
      return { gambling: true, reason: "regulatory-and-provider" };
    }
    return { gambling: false, reason: "nur Pflichthinweis" };
  }

  globalThis.purestateDetectGamblingPage = detectGamblingPage;

  // Nur fuer den Test, der die Liste gegen Leerlaufen sichert.
  globalThis.purestateGamblingHelpHosts = function () {
    return HELP_HOSTS.slice();
  };
})();
