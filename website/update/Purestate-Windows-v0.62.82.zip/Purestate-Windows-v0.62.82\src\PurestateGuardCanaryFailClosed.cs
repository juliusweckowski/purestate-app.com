using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace Purestate
{
    internal sealed partial class GuardService
    {
        private const int CanaryFailClosedTtlHours = 24;
        private const string CanaryCheckPattern = @"^[a-z0-9][a-z0-9._-]{0,39}$";

        // GRD-009: Die Pruefnamen kommen vom Absender und dienen nur der
        // Diagnose - keine Entscheidung haengt an ihnen. Ohne Deckel wuchs die
        // Datei linear mit, und sie wird auf dem 30-s-Takt mit einer
        // Singleline-Regex komplett geparst. Deckel je Eintrag plus
        // Groessenschutz vor dem Parsen, wie bei usage.json.
        private const int MaxCanaryChecksPerEntry = 16;
        private const long MaxCanaryFileBytes = 16384;

        private static string CanaryFailClosedPath
        {
            get
            {
                string dataDir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                    "Purestate");
                return Path.Combine(dataDir, "canary-fail-closed.json");
            }
        }

        private static readonly string[][] CanaryFailClosedSiteDomains =
        {
            new[] { "pixiv", "pixiv.net", "SitePixivEnabled" },
            new[] { "deviantart", "deviantart.com", "SiteDeviantArtEnabled" },
            new[] { "instagram", "instagram.com", "SiteInstagramEnabled" },
            new[] { "imgur", "imgur.com", "SiteImgurEnabled" },
            new[] { "newgrounds", "newgrounds.com", "SiteNewgroundsEnabled" },
            new[] { "tumblr", "tumblr.com", "SiteTumblrEnabled" }
        };

        internal static bool TryMapCanarySiteToDomain(string site, out string domain, out string siteProtectionField)
        {
            domain = string.Empty;
            siteProtectionField = string.Empty;
            string token = (site ?? string.Empty).Trim().ToLowerInvariant();
            foreach (string[] row in CanaryFailClosedSiteDomains)
            {
                if (string.Equals(row[0], token, StringComparison.Ordinal))
                {
                    domain = row[1];
                    siteProtectionField = row[2];
                    return true;
                }
            }
            return false;
        }

        internal static bool IsCanaryMessage(string message)
        {
            string[] parts = (message ?? string.Empty).Split('|');
            return parts.Length == 5 && parts[0] == "CANARY";
        }

        private static string[] ReadActiveCanaryFailClosedDomains()
        {
            // Befund #2: alle Canary-Felder sind Feinfilter des Bereichs
            // Erwachseneninhalte (Spec 2.4) - ohne den Bereich selbst darf
            // auch der Kanarienvogel nichts sperren.
            return GetActiveCanaryFailClosedDomains(
                CanaryFailClosedPath,
                ReadClockAnchorUtc(),
                delegate(string field) { return ReadSiteProtectionConfigBool(field, true) && ReadSiteProtectionConfigBool("AdultContentProtectionEnabled", true); });
        }

        internal sealed class CanaryFailClosedEntry
        {
            public string Site = string.Empty;
            public string Domain = string.Empty;
            public string SiteProtectionField = string.Empty;
            public readonly List<string> Checks = new List<string>();
            public DateTime FirstSeenUtc;
            public DateTime LastSeenUtc;
            public DateTime BlockUntilUtc;
        }

        internal sealed class CanaryFailClosedState
        {
            public readonly Dictionary<string, CanaryFailClosedEntry> Entries =
                new Dictionary<string, CanaryFailClosedEntry>(StringComparer.Ordinal);
        }

        internal static bool HandleCanaryMessage(string message, string statePath, DateTime nowUtc, out string response)
        {
            return HandleCanaryMessage(message, statePath, nowUtc, null, out response);
        }

        internal static bool HandleCanaryMessage(string message, string statePath, DateTime nowUtc, Func<string, bool> siteEnabled, out string response)
        {
            response = "ERROR|invalid-canary";
            string[] parts = (message ?? string.Empty).Split('|');
            if (parts.Length != 5 || parts[0] != "CANARY" ||
                (parts[1] != "Chrome" && parts[1] != "Edge") ||
                !Regex.IsMatch(parts[2], @"^\d+\.\d+\.\d+$") ||
                !Regex.IsMatch(parts[4], CanaryCheckPattern))
            {
                return false;
            }

            string domain;
            string field;
            if (!TryMapCanarySiteToDomain(parts[3], out domain, out field))
            {
                response = "ERROR|unknown-site";
                return false;
            }

            if (siteEnabled != null && !siteEnabled(field))
            {
                response = "OK|canary";
                return false;
            }

            CanaryFailClosedState state = LoadCanaryFailClosedState(statePath, nowUtc);
            string[] activeBefore = ProjectActiveCanaryFailClosedDomains(state, nowUtc, siteEnabled);
            CanaryFailClosedEntry entry;
            string site = parts[3].Trim().ToLowerInvariant();
            if (!state.Entries.TryGetValue(site, out entry))
            {
                entry = new CanaryFailClosedEntry
                {
                    Site = site,
                    Domain = domain,
                    SiteProtectionField = field,
                    FirstSeenUtc = nowUtc
                };
                state.Entries[site] = entry;
            }

            entry.Domain = domain;
            entry.SiteProtectionField = field;
            entry.LastSeenUtc = nowUtc;
            entry.BlockUntilUtc = nowUtc.AddHours(CanaryFailClosedTtlHours);
            if (!entry.Checks.Contains(parts[4]))
            {
                entry.Checks.Add(parts[4]);
                while (entry.Checks.Count > MaxCanaryChecksPerEntry)
                {
                    entry.Checks.RemoveAt(0);
                }
            }

            SaveCanaryFailClosedState(statePath, state);
            response = "OK|canary";
            string[] activeAfter = ProjectActiveCanaryFailClosedDomains(state, nowUtc, siteEnabled);
            return !StringArraysEqual(activeBefore, activeAfter);
        }

        internal static string[] GetCanaryDirectFailClosedFilters(string statePath, DateTime nowUtc, Func<string, bool> siteEnabled)
        {
            return GetActiveCanaryFailClosedDomains(statePath, nowUtc, siteEnabled);
        }

        // Der zuletzt erfolgreich gelesene Stand, je Zustandsdatei. Er traegt
        // ueber einen Zugriffsfehler hinweg, damit ein Lesekonflikt keine
        // Sperre aufhebt (GRD-007).
        private static readonly Dictionary<string, string[]> lastCanaryDomains =
            new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);

        internal static string[] GetActiveCanaryFailClosedDomains(string statePath, DateTime nowUtc, Func<string, bool> siteEnabled)
        {
            bool unreadable;
            CanaryFailClosedState state = LoadCanaryFailClosedState(statePath, nowUtc, out unreadable);
            string key = statePath ?? string.Empty;

            if (unreadable)
            {
                lock (lastCanaryDomains)
                {
                    string[] previous;
                    if (lastCanaryDomains.TryGetValue(key, out previous))
                    {
                        return previous;
                    }
                }
                return new string[0];
            }

            string[] domains = ProjectActiveCanaryFailClosedDomains(state, nowUtc, siteEnabled);
            lock (lastCanaryDomains)
            {
                lastCanaryDomains[key] = domains;
            }
            return domains;
        }

        private static string[] ProjectActiveCanaryFailClosedDomains(CanaryFailClosedState state, DateTime nowUtc, Func<string, bool> siteEnabled)
        {
            List<string> domains = new List<string>();
            foreach (CanaryFailClosedEntry entry in state.Entries.Values)
            {
                if (entry.BlockUntilUtc <= nowUtc)
                {
                    continue;
                }

                if (siteEnabled != null && !siteEnabled(entry.SiteProtectionField))
                {
                    continue;
                }

                if (!domains.Contains(entry.Domain))
                {
                    domains.Add(entry.Domain);
                }
            }

            domains.Sort(StringComparer.Ordinal);
            return domains.ToArray();
        }

        private static bool StringArraysEqual(string[] left, string[] right)
        {
            if (left.Length != right.Length)
            {
                return false;
            }

            for (int index = 0; index < left.Length; index++)
            {
                if (!string.Equals(left[index], right[index], StringComparison.Ordinal))
                {
                    return false;
                }
            }

            return true;
        }

        internal static CanaryFailClosedState LoadCanaryFailClosedState(string path, DateTime nowUtc)
        {
            bool unreadable;
            return LoadCanaryFailClosedState(path, nowUtc, out unreadable);
        }

        // GRD-007: "Datei nicht lesbar" wurde wie "keine Sperren" behandelt.
        // Fuer einen PARSE-Fehler ist das richtig - der Inhalt ist dann
        // wertlos. Fuer einen ZUGRIFFS-Fehler ist es fail-open: ein
        // Virenscanner, der die Datei eine Sekunde offen haelt, hob genau die
        // Sperren auf, die der Canary hart durchsetzen soll. Die beiden Faelle
        // sind jetzt getrennt; der Aufrufer haelt bei einem Zugriffsfehler den
        // zuletzt bekannten Stand.
        internal static CanaryFailClosedState LoadCanaryFailClosedState(string path, DateTime nowUtc, out bool unreadable)
        {
            unreadable = false;
            CanaryFailClosedState state = new CanaryFailClosedState();
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                return state;
            }

            // Eine aufgeblaehte Datei gilt wie ein Zugriffsfehler, NICHT wie
            // "keine Sperren": sonst hebt angehaengter Muell genau die Sperre
            // auf, die der Canary durchsetzen soll. Der naechste Canary-Bericht
            // schreibt die Datei ohnehin wieder klein.
            try
            {
                if (new FileInfo(path).Length > MaxCanaryFileBytes)
                {
                    unreadable = true;
                    return state;
                }
            }
            catch
            {
                unreadable = true;
                return state;
            }

            string json = null;
            for (int attempt = 0; attempt < 3 && json == null; attempt++)
            {
                try
                {
                    using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                    {
                        json = reader.ReadToEnd();
                    }
                }
                catch (IOException)
                {
                    System.Threading.Thread.Sleep(20);
                }
                catch (UnauthorizedAccessException)
                {
                    System.Threading.Thread.Sleep(20);
                }
                catch
                {
                    // Alles andere ist kein Zugriffsproblem und gilt wie ein
                    // unlesbarer Inhalt.
                    return state;
                }
            }

            if (json == null)
            {
                unreadable = true;
                return state;
            }

            Match root = Regex.Match(json, @"^\{""entries"":\[(?<entries>.*)\]\}$", RegexOptions.Singleline);
            if (!root.Success)
            {
                return state;
            }

            string entriesJson = root.Groups["entries"].Value;
            if (entriesJson.Length == 0)
            {
                return state;
            }

            Regex entryRegex = new Regex(
                @"\{""site"":""(?<site>[^""\\]*)"",""domain"":""(?<domain>[^""\\]*)"",""siteProtectionField"":""(?<field>[^""\\]*)"",""checks"":\[(?<checks>[^\]]*)\],""firstSeenUtc"":""(?<first>[^""\\]*)"",""lastSeenUtc"":""(?<last>[^""\\]*)"",""blockUntilUtc"":""(?<block>[^""\\]*)""\}",
                RegexOptions.Singleline);

            int offset = 0;
            foreach (Match match in entryRegex.Matches(entriesJson))
            {
                if (match.Index != offset)
                {
                    if (offset < entriesJson.Length && entriesJson[offset] == ',')
                    {
                        offset++;
                    }

                    if (match.Index != offset)
                    {
                        return new CanaryFailClosedState();
                    }
                }

                offset = match.Index + match.Length;

                string site = match.Groups["site"].Value;
                string expectedDomain;
                string expectedField;
                if (!TryMapCanarySiteToDomain(site, out expectedDomain, out expectedField))
                {
                    continue;
                }

                if (!string.Equals(match.Groups["domain"].Value, expectedDomain, StringComparison.Ordinal) ||
                    !string.Equals(match.Groups["field"].Value, expectedField, StringComparison.Ordinal))
                {
                    continue;
                }

                DateTime firstSeen = ParseCanaryUtc(match.Groups["first"].Value);
                DateTime lastSeen = ParseCanaryUtc(match.Groups["last"].Value);
                DateTime blockUntil = ParseCanaryUtc(match.Groups["block"].Value);
                if (firstSeen == DateTime.MinValue || lastSeen == DateTime.MinValue ||
                    blockUntil == DateTime.MinValue || blockUntil <= nowUtc)
                {
                    continue;
                }

                List<string> checks = ParseCanaryChecks(match.Groups["checks"].Value);
                if (checks == null || checks.Count == 0)
                {
                    continue;
                }

                CanaryFailClosedEntry entry = new CanaryFailClosedEntry
                {
                    Site = site.Trim().ToLowerInvariant(),
                    Domain = expectedDomain,
                    SiteProtectionField = expectedField,
                    FirstSeenUtc = firstSeen,
                    LastSeenUtc = lastSeen,
                    BlockUntilUtc = blockUntil
                };
                entry.Checks.AddRange(checks);
                state.Entries[entry.Site] = entry;
            }

            if (offset != entriesJson.Length)
            {
                return new CanaryFailClosedState();
            }

            return state;
        }

        private static List<string> ParseCanaryChecks(string checksJson)
        {
            List<string> checks = new List<string>();
            if (checksJson.Length == 0)
            {
                return checks;
            }

            Regex checkRegex = new Regex(@"""(?<check>[^""\\]*)""");
            int offset = 0;
            foreach (Match match in checkRegex.Matches(checksJson))
            {
                if (match.Index != offset)
                {
                    if (offset < checksJson.Length && checksJson[offset] == ',')
                    {
                        offset++;
                    }

                    if (match.Index != offset)
                    {
                        return null;
                    }
                }

                offset = match.Index + match.Length;
                string check = match.Groups["check"].Value;
                if (!Regex.IsMatch(check, CanaryCheckPattern))
                {
                    return null;
                }

                if (!checks.Contains(check))
                {
                    checks.Add(check);
                }
            }

            if (offset != checksJson.Length)
            {
                return null;
            }

            return checks;
        }

        private static void SaveCanaryFailClosedState(string path, CanaryFailClosedState state)
        {
            string parent = Path.GetDirectoryName(path);
            if (string.IsNullOrWhiteSpace(parent))
            {
                throw new InvalidOperationException("Canary fail-closed state path has no parent directory.");
            }

            Directory.CreateDirectory(parent);
            EnsureDataDirectoryIsNotReparsePoint(parent);

            string json = BuildCanaryFailClosedJson(state);
            ReplaceFileAtomically(path, delegate(string temp)
            {
                File.WriteAllText(temp, json, new UTF8Encoding(false));
            });
        }

        internal static string BuildCanaryFailClosedJson(CanaryFailClosedState state)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(@"{""entries"":[");
            List<CanaryFailClosedEntry> entries = new List<CanaryFailClosedEntry>((state ?? new CanaryFailClosedState()).Entries.Values);
            entries.Sort(delegate(CanaryFailClosedEntry left, CanaryFailClosedEntry right)
            {
                return string.CompareOrdinal(left.Site, right.Site);
            });

            for (int entryIndex = 0; entryIndex < entries.Count; entryIndex++)
            {
                CanaryFailClosedEntry entry = entries[entryIndex];
                if (entryIndex > 0)
                {
                    builder.Append(',');
                }

                builder.Append(@"{""site"":""").Append(EscapeCanaryJson(entry.Site));
                builder.Append(@""",""domain"":""").Append(EscapeCanaryJson(entry.Domain));
                builder.Append(@""",""siteProtectionField"":""").Append(EscapeCanaryJson(entry.SiteProtectionField));
                builder.Append(@""",""checks"":[");
                for (int checkIndex = 0; checkIndex < entry.Checks.Count; checkIndex++)
                {
                    if (checkIndex > 0)
                    {
                        builder.Append(',');
                    }

                    builder.Append('"').Append(EscapeCanaryJson(entry.Checks[checkIndex])).Append('"');
                }

                builder.Append(@"],""firstSeenUtc"":""").Append(entry.FirstSeenUtc.ToUniversalTime().ToString("O", CultureInfo.InvariantCulture));
                builder.Append(@""",""lastSeenUtc"":""").Append(entry.LastSeenUtc.ToUniversalTime().ToString("O", CultureInfo.InvariantCulture));
                builder.Append(@""",""blockUntilUtc"":""").Append(entry.BlockUntilUtc.ToUniversalTime().ToString("O", CultureInfo.InvariantCulture));
                builder.Append(@"""}");
            }

            builder.Append("]}");
            return builder.ToString();
        }

        private static string EscapeCanaryJson(string value)
        {
            return (value ?? string.Empty).Replace("\\", "\\\\").Replace("\"", "\\\"");
        }

        private static DateTime ParseCanaryUtc(string value)
        {
            DateTime parsed;
            if (!DateTime.TryParseExact(
                value,
                "O",
                CultureInfo.InvariantCulture,
                DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal,
                out parsed))
            {
                return DateTime.MinValue;
            }

            return DateTime.SpecifyKind(parsed.ToUniversalTime(), DateTimeKind.Utc);
        }
    }
}
