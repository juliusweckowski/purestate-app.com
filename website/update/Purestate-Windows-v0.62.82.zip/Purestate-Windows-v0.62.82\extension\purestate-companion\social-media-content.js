"use strict";

// Purestate social media companion (per-platform block, curfew, daily
// budget/override limits, first-open reflection, feed damping).
//
// Priority per page - the first matching mechanism wins:
//   full block > feed-route block > curfew > time limit > reflection > feed damping.
// Everything is gated on areas["social-media"].mode === "gentle" from the
// rule pack; without a pack the module is off (fail-open by design, like
// shopping - a gentle area must not guess).

const SOCIAL_RULES_GET = "purestate.getBrowserRules";
const SOCIAL_TIME_TICK = "purestate.socialTimeTick";
const SOCIAL_TIME_STATE = "purestate.socialTimeState";
const SOCIAL_BLOCK_OVERLAY_ID = "purestate-social-block-overlay";
const SOCIAL_FEED_OVERLAY_ID = "purestate-social-feed-overlay";
const SOCIAL_CURFEW_OVERLAY_ID = "purestate-social-curfew-overlay";
const SOCIAL_TIME_OVERLAY_ID = "purestate-social-time-overlay";
const SOCIAL_REFLECT_OVERLAY_ID = "purestate-social-reflect-overlay";
const SOCIAL_DAMPING_OVERLAY_ID = "purestate-social-damping-overlay";
const SOCIAL_FULL_OVERLAY_IDS = [
  SOCIAL_BLOCK_OVERLAY_ID, SOCIAL_FEED_OVERLAY_ID, SOCIAL_CURFEW_OVERLAY_ID,
  SOCIAL_TIME_OVERLAY_ID, SOCIAL_REFLECT_OVERLAY_ID, SOCIAL_DAMPING_OVERLAY_ID
];
const SOCIAL_MEDIA_PAUSE_OVERLAY_IDS = [
  SOCIAL_BLOCK_OVERLAY_ID, SOCIAL_FEED_OVERLAY_ID, SOCIAL_CURFEW_OVERLAY_ID,
  SOCIAL_TIME_OVERLAY_ID, SOCIAL_DAMPING_OVERLAY_ID
];

// Distraction routes of the selective feed block (path prefixes). Mirrors
// SOCIAL_MEDIA_FEED_ROUTE_PLATFORM_IDS in background.js and the route maps in
// Support/guard/PowerShell (pinned by tests).
const SOCIAL_FEED_BLOCK_ROUTES = {
  instagram: ["/reels", "/explore"],
  youtube: ["/shorts"],
  x: ["/explore"],
  reddit: ["/r/popular", "/r/all"],
  tumblr: ["/explore"]
};

// Suffix-matched host map; www./m./de. etc. are ordinary subdomains.
const SOCIAL_PLATFORM_DOMAINS = {
  x: ["x.com", "twitter.com"],
  instagram: ["instagram.com"],
  tiktok: ["tiktok.com"],
  pinterest: [
    "pinterest.com", "pinterest.de", "pinterest.at", "pinterest.ch", "pinterest.fr",
    "pinterest.it", "pinterest.es", "pinterest.co.uk", "pinterest.ca",
    "pinterest.com.au", "pinterest.com.mx", "pinterest.jp", "pinterest.se"
  ],
  tumblr: ["tumblr.com"],
  bluesky: ["bsky.app"],
  reddit: ["reddit.com"],
  youtube: ["youtube.com", "youtu.be"],
  // Streaming (Tester-Notiz 2026-10-06): Netflix & Co. Nur im Browser - die
  // Apps der Dienste sieht der Companion nicht. Prime Video auf amazon.de
  // fehlt absichtlich: die Domain gehoert dem Shopping-Bereich.
  streaming: [
    "netflix.com", "disneyplus.com", "primevideo.com", "max.com", "hbomax.com",
    "paramountplus.com", "tv.apple.com", "crunchyroll.com", "twitch.tv", "joyn.de",
    "plus.rtl.de", "dazn.com", "wowtv.de"
  ]
};

// Plattformen mit eigenem Zeitbudget: ihre Zeit zaehlt nicht ins gemeinsame
// Social-Media-Limit, und dieses (samt Social-Media-Pause, Reflexionsfrage und
// Scroll-Bremse) gilt nicht fuer sie. Sonst frisst ein einziger Film das
// Limit fuer alles andere - oder die Pause sperrt abends den Film. Spiegel:
// SOCIAL_MEDIA_OWN_BUDGET_PLATFORM_IDS in background.js und
// SocialMediaOwnBudgetPlatformIds in src\NativeSupportConfig.cs (durch Tests
// gepinnt).
const SOCIAL_OWN_BUDGET_PLATFORMS = ["streaming"];

function socialPlatformHasOwnBudget(platform) {
  return SOCIAL_OWN_BUDGET_PLATFORMS.includes(platform);
}

const SOCIAL_REFLECTION_QUESTIONS = [
  "Was möchtest du hier gerade finden?",
  "Wie fühlst du dich in diesem Moment?",
  "Was würdest du sonst mit den nächsten Minuten machen?",
  "Suchst du etwas Bestimmtes oder nur Ablenkung?",
  "Wie oft warst du heute schon hier?",
  "Was hat dir das letzte Scrollen gegeben?",
  "Gibt es etwas, das du gerade aufschiebst?",
  "Wie lange möchtest du jetzt wirklich bleiben?",
  "Würdest du diese Zeit später vermissen?",
  "Was wäre jetzt gut für dich?"
];

// Feed damping counts discrete scroll actions (bursts). One burst = scroll
// movement with a >=400ms gap to the previous one - on short-form feeds
// (TikTok, Shorts, Reels) that is one item swipe. After the threshold a
// full pause overlay shows how much time the scrolling took.
const SOCIAL_FEED_DAMPING_DEFAULT_SCROLLS = 50;
const SOCIAL_FEED_DAMPING_MIN_SCROLLS = 5;
const SOCIAL_FEED_DAMPING_MAX_SCROLLS = 500;
const SOCIAL_FEED_DAMPING_BURST_GAP_MS = 400;

const SOCIAL_TIME_BADGE_ID = "purestate-social-time-badge";

let socialRulePack = null;
let socialTimeLimitReached = false;
let socialReflectionPending = false;
let socialReflectionDone = false;
let socialScrollCount = 0;
let socialScrollCountStartMs = 0;
let socialLastScrollEventMs = 0;
let socialLastScrollY = 0;
let socialWasRestricted = false;

function socialPlatformFromHostname(hostname) {
  const host = String(hostname || "").trim().toLowerCase().replace(/\.$/, "");
  if (host.length === 0) {
    return null;
  }
  for (const platform of Object.keys(SOCIAL_PLATFORM_DOMAINS)) {
    for (const domain of SOCIAL_PLATFORM_DOMAINS[platform]) {
      if (host === domain || host.endsWith("." + domain)) {
        return platform;
      }
    }
  }
  return null;
}

function socialLimitsFromPack(pack) {
  const rules = pack && typeof pack === "object" ? pack : {};
  const limits = rules.socialMediaLimits && typeof rules.socialMediaLimits === "object" ? rules.socialMediaLimits : {};
  return limits;
}

function socialAreaActive(pack) {
  const rules = pack && typeof pack === "object" ? pack : {};
  const areas = rules.areas && typeof rules.areas === "object" ? rules.areas : {};
  const area = areas["social-media"] && typeof areas["social-media"] === "object" ? areas["social-media"] : {};
  return area.mode === "gentle";
}

function socialParseCurfewMinutes(text, fallback) {
  const match = /^(\d{1,2}):(\d{2})$/.exec(String(text || "").trim());
  if (!match) {
    return fallback;
  }
  const hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);
  if (hours > 23 || minutes > 59) {
    return fallback;
  }
  return hours * 60 + minutes;
}

// Same wrap semantics as the Windows schedule: start==end is "off"; a window
// across midnight wraps.
function socialCurfewActive(nowMinutes, startText, endText) {
  const start = socialParseCurfewMinutes(startText, 22 * 60);
  const end = socialParseCurfewMinutes(endText, 6 * 60);
  if (start === end) {
    return false;
  }
  if (start < end) {
    return nowMinutes >= start && nowMinutes < end;
  }
  return nowMinutes >= start || nowMinutes < end;
}

// Pure prefix matcher of the selective feed block, unit-tested: true when the
// pathname sits on a blocked distraction route of the platform.
function socialFeedRouteBlocked(platform, pathname) {
  const routes = SOCIAL_FEED_BLOCK_ROUTES[platform];
  if (!Array.isArray(routes)) {
    return false;
  }
  // Same prefix semantics as the policy patterns (*://host/route*).
  const path = String(pathname || "");
  for (const route of routes) {
    if (path.startsWith(route)) {
      return true;
    }
  }
  return false;
}

// Pure priority decision, unit-tested. state:
//   nowMinutes            local minute of day
//   pathname              location.pathname (selective feed block)
//   usedTotalSeconds      accumulated seconds across all platforms today
//   usedPlatformSeconds   accumulated seconds on this platform today
//   reflectedToday        platform already reflected on today
function socialMediaDecision(pack, platform, state) {
  if (!socialAreaActive(pack) || !platform) {
    return { action: "none" };
  }
  const limits = socialLimitsFromPack(pack);
  const safeState = state && typeof state === "object" ? state : {};

  const blocked = Array.isArray(limits.blockedPlatforms) && limits.blockedPlatforms.includes(platform);
  if (blocked) {
    return { action: "block" };
  }

  if (Array.isArray(limits.feedBlockedPlatforms) && limits.feedBlockedPlatforms.includes(platform) &&
      socialFeedRouteBlocked(platform, safeState.pathname)) {
    return { action: "feed" };
  }

  const ownBudget = socialPlatformHasOwnBudget(platform);
  const nowMinutes = Number.isInteger(safeState.nowMinutes) ? safeState.nowMinutes : 0;
  if (!ownBudget && limits.curfewEnabled === true && socialCurfewActive(nowMinutes, limits.curfewStart, limits.curfewEnd)) {
    return { action: "curfew" };
  }

  const usedTotal = Number.isInteger(safeState.usedTotalSeconds) && safeState.usedTotalSeconds >= 0 ? safeState.usedTotalSeconds : 0;
  const usedPlatform = Number.isInteger(safeState.usedPlatformSeconds) && safeState.usedPlatformSeconds >= 0 ? safeState.usedPlatformSeconds : 0;
  const budgetSeconds = !ownBudget && limits.budgetEnabled === true && Number.isInteger(limits.budgetMinutes) ? limits.budgetMinutes * 60 : 0;
  const overrides = limits.platformLimits && typeof limits.platformLimits === "object" ? limits.platformLimits : {};
  const platformSeconds = Number.isInteger(overrides[platform]) ? overrides[platform] * 60 : 0;
  if (budgetSeconds > 0 && usedTotal >= budgetSeconds) {
    return { action: "limit", scope: "budget" };
  }
  if (platformSeconds > 0 && usedPlatform >= platformSeconds) {
    return { action: "limit", scope: "platform" };
  }

  if (!ownBudget && limits.reflectionEnabled === true && safeState.reflectedToday !== true) {
    return { action: "reflect" };
  }

  return { action: "none" };
}

// Pure burst counter, unit-tested: a scroll event starts a new burst when
// the gap to the previous event is at least SOCIAL_FEED_DAMPING_BURST_GAP_MS.
// Returns the new burst count.
function countScrollBurst(currentCount, lastEventMs, nowMs) {
  const count = Number.isInteger(currentCount) && currentCount >= 0 ? currentCount : 0;
  const last = Number.isFinite(lastEventMs) && lastEventMs > 0 ? lastEventMs : 0;
  const now = Number.isFinite(nowMs) ? nowMs : 0;
  if (last === 0 || now - last >= SOCIAL_FEED_DAMPING_BURST_GAP_MS) {
    return count + 1;
  }
  return count;
}

function feedDampingScrollThreshold(value) {
  return Number.isInteger(value) &&
    value >= SOCIAL_FEED_DAMPING_MIN_SCROLLS &&
    value <= SOCIAL_FEED_DAMPING_MAX_SCROLLS
    ? value
    : SOCIAL_FEED_DAMPING_DEFAULT_SCROLLS;
}

function feedDampingShouldPause(scrollCount, threshold) {
  return Number.isInteger(scrollCount) && scrollCount >= feedDampingScrollThreshold(threshold);
}

// Pure copy builder for the pause overlay, unit-tested: turns the elapsed
// time since the counter started into the calm stocktaking line.
function feedDampingSummary(scrollCount, elapsedMs) {
  const count = Number.isInteger(scrollCount) && scrollCount >= 0 ? scrollCount : 0;
  const minutes = Math.max(1, Math.round((Number.isFinite(elapsedMs) && elapsedMs > 0 ? elapsedMs : 0) / 60000));
  return "Du hast gerade " + count + "-mal weitergescrollt – das waren etwa " + minutes +
    (minutes === 1 ? " Minute." : " Minuten.");
}

const SOCIAL_DAMPING_ALTERNATIVES = [
  "Zehn ruhige Atemzüge",
  "Kurz aufstehen und strecken",
  "Ein Glas Wasser holen",
  "Ein paar Seiten lesen",
  "Kurz nach draußen schauen"
];

function socialLocalDateKey(nowMs) {
  const date = new Date(nowMs === undefined ? Date.now() : nowMs);
  const year = String(date.getFullYear()).padStart(4, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return year + "-" + month + "-" + day;
}

function socialReflectStorageKey(nowMs) {
  return "purestateReflect:social:" + socialLocalDateKey(nowMs);
}

// ---- Module wiring ---------------------------------------------------------

function installSocialMediaModule() {
  requestSocialRules();
  installSocialPushListener();
  setInterval(() => {
    // Re-evaluate overlays every interval so a curfew window starts and ends
    // on time even without a rule-pack push, then count the tick.
    applySocialState();
    sendSocialTimeTick();
    refreshSocialTimeStateUnderCurtain();
  }, 15000);
  if (typeof document.addEventListener === "function") {
    document.addEventListener("visibilitychange", refreshSocialTimeStateUnderCurtain);
  }
  if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
    window.addEventListener("focus", refreshSocialTimeStateUnderCurtain);
  }
  installSocialLocationWatcher();
  installSocialFeedDamping();
  installSocialMediaPause();
}

// SPA navigations change routes without a page load; the selective feed block
// must cover /reels & co. right away, not on the next 15s tick.
function installSocialLocationWatcher() {
  let lastHref = "";
  try {
    lastHref = String(location.href || "");
  } catch {
  }
  setInterval(() => {
    let currentHref = "";
    try {
      currentHref = String(location.href || "");
    } catch {
      return;
    }
    if (currentHref === lastHref) {
      return;
    }
    lastHref = currentHref;
    applySocialState();
  }, 1000);
}

// Hard overlays silence the page: the visual cover alone left e.g. a YouTube
// video playing underneath (live finding). The first-open reflection gate only
// mutes: pausing a reactivated YouTube player from that path can freeze the
// tab, muting never touches the playback state (live finding L-13 - the gate
// covered the picture while sound kept running).
// Runs as a slow interval so SPA-injected players stay covered.
function installSocialMediaPause() {
  setInterval(() => {
    if (socialHasMediaPauseOverlay()) {
      pauseSocialMedia();
      return;
    }
    if (document.getElementById && document.getElementById(SOCIAL_REFLECT_OVERLAY_ID)) {
      muteSocialMedia();
    }
  }, 1000);
}

function muteSocialMedia() {
  try {
    if (!document.querySelectorAll) {
      return;
    }
    for (const media of document.querySelectorAll("video, audio")) {
      try {
        media.muted = true;
      } catch {
      }
    }
  } catch {
  }
}

function pauseSocialMedia() {
  try {
    if (!document.querySelectorAll) {
      return;
    }
    for (const media of document.querySelectorAll("video, audio")) {
      try {
        if (!media.paused) {
          media.pause();
        }
        media.muted = true;
      } catch {
      }
    }
  } catch {
  }
}

function requestSocialRules() {
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return;
    }
    const maybePromise = chrome.runtime.sendMessage({ type: SOCIAL_RULES_GET, site: "social-media" }, applySocialRules);
    if (maybePromise && typeof maybePromise.then === "function") {
      maybePromise.then(applySocialRules).catch(() => {});
    }
  } catch {
  }
}

function installSocialPushListener() {
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.onMessage || typeof chrome.runtime.onMessage.addListener !== "function") {
      return;
    }
    chrome.runtime.onMessage.addListener((message) => {
      if (message && message.type === "purestate.rulesUpdated") {
        applySocialRules(message);
      }
      return false;
    });
  } catch {
  }
}

function applySocialRules(response) {
  socialRulePack = response && response.rules && typeof response.rules === "object" ? response.rules : null;
  // EXT-A02: Der erreichte Stand faellt nur, wenn fuer diese Plattform gar
  // kein Zeitlimit mehr gilt. Jedes Paket loeschte ihn frueher, und weil Ticks
  // unter dem Vorhang pausieren, stand die Seite danach offen (im
  // Hintergrundtab dauerhaft). Gilt noch ein Limit, bestimmt die reine
  // Statusabfrage unten den Stand in beide Richtungen neu.
  const platform = currentSocialPlatform();
  if (!platform || !socialAreaActive(socialRulePack) ||
      !socialTimeLimitStillConfigured(socialLimitsFromPack(socialRulePack), platform)) {
    socialTimeLimitReached = false;
  }
  applySocialState();
  requestSocialTimeState();
  // Do not wait for the next 15s interval: the remaining-time badge should
  // appear fast.
  sendSocialTimeTick();
}

function currentSocialPlatform() {
  try {
    return socialPlatformFromHostname(location.hostname);
  } catch {
    return null;
  }
}

function applySocialState() {
  const platform = currentSocialPlatform();
  if (!socialAreaActive(socialRulePack) || !platform) {
    for (const overlayId of SOCIAL_FULL_OVERLAY_IDS) {
      removeSocialOverlay(overlayId);
    }
    removeSocialOverlay(SOCIAL_DAMPING_OVERLAY_ID);
    removeSocialTimeBadge();
    reloadIfSocialRestrictionLifted("none");
    return;
  }

  const limits = socialLimitsFromPack(socialRulePack);
  const decision = socialMediaDecision(socialRulePack, platform, {
    nowMinutes: socialCurrentMinuteOfDay(),
    pathname: socialCurrentPathname(),
    usedTotalSeconds: socialTimeLimitReached ? Number.MAX_SAFE_INTEGER : 0,
    usedPlatformSeconds: 0,
    reflectedToday: true
  });

  if (decision.action === "block") {
    removeSocialOverlay(SOCIAL_FEED_OVERLAY_ID);
    removeSocialOverlay(SOCIAL_CURFEW_OVERLAY_ID);
    removeSocialOverlay(SOCIAL_TIME_OVERLAY_ID);
    removeSocialOverlay(SOCIAL_REFLECT_OVERLAY_ID);
    showSocialBlockOverlay();
    pauseSocialMedia();
    socialWasRestricted = "block";
    return;
  }
  removeSocialOverlay(SOCIAL_BLOCK_OVERLAY_ID);

  if (decision.action === "feed") {
    removeSocialOverlay(SOCIAL_CURFEW_OVERLAY_ID);
    removeSocialOverlay(SOCIAL_TIME_OVERLAY_ID);
    removeSocialOverlay(SOCIAL_REFLECT_OVERLAY_ID);
    showSocialFeedOverlay();
    pauseSocialMedia();
    socialWasRestricted = "feed";
    return;
  }
  removeSocialOverlay(SOCIAL_FEED_OVERLAY_ID);

  if (decision.action === "curfew") {
    removeSocialOverlay(SOCIAL_TIME_OVERLAY_ID);
    removeSocialOverlay(SOCIAL_REFLECT_OVERLAY_ID);
    showSocialCurfewOverlay(limits);
    pauseSocialMedia();
    socialWasRestricted = "curfew";
    return;
  }
  removeSocialOverlay(SOCIAL_CURFEW_OVERLAY_ID);

  if (socialTimeLimitReached || socialTimeStateUnknown) {
    removeSocialOverlay(SOCIAL_REFLECT_OVERLAY_ID);
    showSocialTimeOverlay();
    pauseSocialMedia();
    socialWasRestricted = "limit";
    return;
  }
  removeSocialOverlay(SOCIAL_TIME_OVERLAY_ID);

  reloadIfSocialRestrictionLifted(socialTimeLimitStillConfigured(limits, platform) ? "limit-pending" : "none");

  if (limits.reflectionEnabled === true && !socialReflectionDone && !socialReflectionPending &&
      !socialPlatformHasOwnBudget(platform)) {
    checkSocialReflection(platform);
  }
}

// Ein Zeitlimit gilt fuer die Plattform, wenn das gemeinsame Budget laeuft oder
// sie ein eigenes Limit hat. Eine Plattform mit eigenem Budget (Streaming)
// kennt das gemeinsame nicht - fuer sie zaehlt nur ihr eigenes Limit.
function socialTimeLimitStillConfigured(limits, platform) {
  const overrides = limits.platformLimits && typeof limits.platformLimits === "object" ? limits.platformLimits : {};
  return (limits.budgetEnabled === true && !socialPlatformHasOwnBudget(platform)) ||
    Number.isInteger(overrides[platform]);
}

// After a push update lifts a block/curfew the covered page is often stuck
// (paused players, hidden scroll) - reload once so the tab is usable without
// the user hunting for the refresh button (live finding). A previously
// reached time limit reloads only when its configuration is gone: a recovered
// limit (next day, raised budget) may clear the curtain while the limit is
// still configured, and reloading then would loop (reload -> state re-covers).
function reloadIfSocialRestrictionLifted(currentState) {
  const previous = socialWasRestricted;
  if (!previous) {
    return;
  }
  if (previous === "limit" && currentState === "limit-pending") {
    return;
  }
  // Leaving a blocked feed route is normal SPA navigation - the overlay just
  // disappears, a reload would tear the page the user navigated to.
  if (previous === "feed") {
    socialWasRestricted = false;
    return;
  }
  socialWasRestricted = false;
  try {
    location.reload();
  } catch {
  }
}

function socialCurrentMinuteOfDay() {
  const now = new Date();
  return now.getHours() * 60 + now.getMinutes();
}

function socialCurrentPathname() {
  try {
    return String(location.pathname || "");
  } catch {
    return "";
  }
}

// ---- Time ticks -------------------------------------------------------------

function socialHasFullOverlay() {
  if (!document.getElementById) {
    return false;
  }
  for (const overlayId of SOCIAL_FULL_OVERLAY_IDS) {
    if (document.getElementById(overlayId)) {
      return true;
    }
  }
  return false;
}

function socialHasMediaPauseOverlay() {
  if (!document.getElementById) {
    return false;
  }
  for (const overlayId of SOCIAL_MEDIA_PAUSE_OVERLAY_IDS) {
    if (document.getElementById(overlayId)) {
      return true;
    }
  }
  return false;
}

function sendSocialTimeTick() {
  const platform = currentSocialPlatform();
  if (!socialAreaActive(socialRulePack) || !platform ||
      document.visibilityState !== "visible" || typeof document.hasFocus !== "function" || !document.hasFocus() ||
      socialHasFullOverlay()) {
    return;
  }
  const limits = socialLimitsFromPack(socialRulePack);
  if (!socialTimeLimitStillConfigured(limits, platform)) {
    return;
  }
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return;
    }
    const maybePromise = chrome.runtime.sendMessage({ type: SOCIAL_TIME_TICK, platform }, handleSocialTickResponse);
    if (maybePromise && typeof maybePromise.then === "function") {
      maybePromise.then(handleSocialTickResponse).catch(() => {});
    }
  } catch {
  }
}

// EXT-A02: Reine Statusabfrage ohne Fokusgate und ohne Zaehlen. Sie laeuft
// unter dem Zeitvorhang, wo die Ticks pausieren, damit ein neuer Tag oder ein
// wieder gesunder Dienst den offenen Tab erreicht.
function requestSocialTimeState() {
  const platform = currentSocialPlatform();
  if (!socialAreaActive(socialRulePack) || !platform ||
      !socialTimeLimitStillConfigured(socialLimitsFromPack(socialRulePack), platform)) {
    return;
  }
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return;
    }
    const maybePromise = chrome.runtime.sendMessage({ type: SOCIAL_TIME_STATE, platform }, handleSocialTickResponse);
    if (maybePromise && typeof maybePromise.then === "function") {
      maybePromise.then(handleSocialTickResponse).catch(() => {});
    }
  } catch {
  }
}

function refreshSocialTimeStateUnderCurtain() {
  if (document.getElementById && document.getElementById(SOCIAL_TIME_OVERLAY_ID)) {
    requestSocialTimeState();
  }
}

// EXT-001: Schweigt der Dienst, kannte der Handler keinen Unterschied zwischen
// "Limit nicht erreicht" und "nicht ermittelbar" - er kehrte ohne Aktion
// zurueck, und der letzte Stand blieb stehen. Schwelle wie in den beiden
// Schwestermodulen: bei 15 Sekunden Takt rund zwei Minuten, damit ein
// Dienstneustart niemanden aussperrt.
const SOCIAL_TIME_PROBE_FAILURE_LIMIT = 8;
let socialTimeProbeFailures = 0;
let socialTimeStateUnknown = false;

function purestateSocialTimeStateUnknown() {
  return socialTimeStateUnknown;
}

function purestateSocialTimeProbeLimit() {
  return SOCIAL_TIME_PROBE_FAILURE_LIMIT;
}

function handleSocialTickResponse(response) {
  if (!response || response.ok !== true) {
    socialTimeProbeFailures += 1;
    if (socialTimeProbeFailures >= SOCIAL_TIME_PROBE_FAILURE_LIMIT && !socialTimeStateUnknown) {
      socialTimeStateUnknown = true;
      removeSocialTimeBadge();
      applySocialState();
    }
    return;
  }

  socialTimeProbeFailures = 0;
  // EXT-A02: Eine gueltige Antwort setzt beide Merker in BEIDE Richtungen.
  // Frueher blieb "erreicht" nach einer Antwort "unter dem Limit" stehen, und
  // ein aufgehobenes "unbekannt" nahm den Vorhang nicht ab.
  const wasCurtained = socialTimeLimitReached || socialTimeStateUnknown;
  socialTimeStateUnknown = false;
  if (response.limitReached === true) {
    socialTimeLimitReached = true;
    removeSocialTimeBadge();
    applySocialState();
    return;
  }
  socialTimeLimitReached = false;
  if (wasCurtained) {
    applySocialState();
  }
  updateSocialTimeBadge(response);
}

// Pure remaining-seconds computation for the live badge, unit-tested: the
// tighter of budget rest and platform-override rest; -1 when no limit binds.
function socialRemainingSeconds(response) {
  if (!response || typeof response !== "object") {
    return -1;
  }
  const rests = [];
  if (Number.isInteger(response.budgetSeconds) && response.budgetSeconds > 0) {
    rests.push(Math.max(0, response.budgetSeconds - (Number.isInteger(response.usedSecondsTotal) ? response.usedSecondsTotal : 0)));
  }
  if (Number.isInteger(response.platformLimitSeconds) && response.platformLimitSeconds > 0) {
    rests.push(Math.max(0, response.platformLimitSeconds - (Number.isInteger(response.usedSecondsPlatform) ? response.usedSecondsPlatform : 0)));
  }
  return rests.length === 0 ? -1 : Math.min.apply(null, rests);
}

// Aussehen und Text kommen aus dem gemeinsamen Baustein (adult-search-terms.js),
// den seit 2026-10-06 auch Shopping und Gluecksspiel nutzen.
function formatSocialRemaining(seconds) {
  return typeof purestateFormatRemaining === "function" ? purestateFormatRemaining(seconds) : "";
}

function updateSocialTimeBadge(response) {
  const remaining = socialRemainingSeconds(response);
  if (remaining < 0 || typeof purestateShowTimeBadge !== "function") {
    removeSocialTimeBadge();
    return;
  }
  purestateShowTimeBadge(document, SOCIAL_TIME_BADGE_ID, formatSocialRemaining(remaining));
}

function removeSocialTimeBadge() {
  if (typeof purestateRemoveTimeBadge === "function") {
    purestateRemoveTimeBadge(document, SOCIAL_TIME_BADGE_ID);
  }
}

// ---- Reflection --------------------------------------------------------------

function checkSocialReflection(platform) {
  socialReflectionPending = true;
  try {
    if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local || typeof chrome.storage.local.get !== "function") {
      socialReflectionPending = false;
      return;
    }
    const key = socialReflectStorageKey();
    chrome.storage.local.get(null, (items) => {
      void (chrome.runtime && chrome.runtime.lastError);
      try {
        const store = items && typeof items === "object" ? items : {};
        const rawList = store[key];
        // A broken stored value resets for the day - never a permanent gate.
        const reflected = Array.isArray(rawList) ? rawList.filter((entry) => typeof entry === "string") : [];
        if (reflected.includes(platform)) {
          socialReflectionDone = true;
          socialReflectionPending = false;
          return;
        }
        scheduleSocialReflectionOverlay(platform, reflected, key, store);
      } catch {
        socialReflectionPending = false;
      }
    });
  } catch {
    socialReflectionPending = false;
  }
}

function markSocialReflected(platform, reflected, key, store) {
  try {
    if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local || typeof chrome.storage.local.set !== "function") {
      return;
    }
    const staleKeys = [];
    for (const existing of Object.keys(store || {})) {
      if (existing.startsWith("purestateReflect:social:") && existing !== key) {
        staleKeys.push(existing);
      }
    }
    if (staleKeys.length > 0 && typeof chrome.storage.local.remove === "function") {
      chrome.storage.local.remove(staleKeys, () => {
        void (chrome.runtime && chrome.runtime.lastError);
      });
    }
    const update = {};
    update[key] = reflected.concat([platform]);
    chrome.storage.local.set(update, () => {
      void (chrome.runtime && chrome.runtime.lastError);
    });
  } catch {
  }
}

function pickSocialReflectionQuestion(rng) {
  const random = typeof rng === "function" ? rng : Math.random;
  const sample = Number(random());
  const normalized = Number.isFinite(sample) && sample >= 0 && sample < 1 ? sample : 0;
  return SOCIAL_REFLECTION_QUESTIONS[Math.min(SOCIAL_REFLECTION_QUESTIONS.length - 1, Math.floor(normalized * SOCIAL_REFLECTION_QUESTIONS.length))];
}

function socialReflectionCountdownSeconds(unlockAtMs, nowMs) {
  const unlockAt = Number.isFinite(unlockAtMs) ? unlockAtMs : 0;
  const now = Number.isFinite(nowMs) ? nowMs : Date.now();
  return Math.max(0, Math.ceil((unlockAt - now) / 1000));
}

function scheduleSocialReflectionOverlay(platform, reflected, key, store) {
  runWhenSocialTabCanShowOverlay(() => {
    try {
      if (!socialReflectionPending) {
        return;
      }
      if (socialReflectionDone || socialHasFullOverlay()) {
        socialReflectionPending = false;
        return;
      }
      if (!socialAreaActive(socialRulePack) || currentSocialPlatform() !== platform) {
        socialReflectionPending = false;
        return;
      }
      showSocialReflectionOverlay(platform, reflected, key, store);
    } catch {
      socialReflectionPending = false;
    }
  });
}

function runWhenSocialTabCanShowOverlay(callback) {
  if (typeof callback !== "function") {
    return;
  }
  const waitForDomReady = () => {
    try {
      if (document.readyState === "loading" && typeof document.addEventListener === "function") {
        document.addEventListener("DOMContentLoaded", () => runAfterSocialIdle(callback), { once: true });
        return;
      }
    } catch {
    }
    runAfterSocialIdle(callback);
  };
  try {
    if (document.visibilityState === "hidden" && typeof document.addEventListener === "function") {
      const onVisible = () => {
        try {
          if (document.visibilityState === "hidden") {
            return;
          }
          if (typeof document.removeEventListener === "function") {
            document.removeEventListener("visibilitychange", onVisible, true);
          }
        } catch {
        }
        waitForDomReady();
      };
      document.addEventListener("visibilitychange", onVisible, true);
      return;
    }
  } catch {
  }
  waitForDomReady();
}

function runAfterSocialIdle(callback) {
  const run = () => {
    try {
      callback();
    } catch {
    }
  };
  try {
    if (typeof requestIdleCallback === "function") {
      requestIdleCallback(run, { timeout: 3000 });
      return;
    }
  } catch {
  }
  try {
    if (typeof requestAnimationFrame === "function") {
      requestAnimationFrame(() => {
        try {
          setTimeout(run, 0);
        } catch {
          run();
        }
      });
      return;
    }
  } catch {
  }
  try {
    setTimeout(run, 0);
  } catch {
    run();
  }
}

function showSocialReflectionOverlay(platform, reflected, key, store) {
  const overlay = buildSocialOverlay(
    SOCIAL_REFLECT_OVERLAY_ID,
    "Kurz innehalten",
    pickSocialReflectionQuestion(),
    { preservePageStyles: true, modalDialog: true, size: "dialog" }
  );
  if (!overlay) {
    socialReflectionPending = false;
    return;
  }

  const continueButton = purestateCurtainButton(document, overlay.purestateTheme, "Weiter (5)", "waiting");
  continueButton.setAttribute("aria-disabled", "true");
  continueButton.setAttribute("aria-label", "Weiter zur Seite");
  overlay.purestateActions.appendChild(continueButton);
  overlay.purestatePrimary = continueButton;
  activateSocialModalOverlay(overlay);

  const unlockAtMs = Date.now() + 5000;
  const renderRemaining = () => {
    const remaining = socialReflectionCountdownSeconds(unlockAtMs, Date.now());
    if (remaining <= 0) {
      clearInterval(timer);
      continueButton.setAttribute("aria-disabled", "false");
      continueButton.textContent = "Weiter";
      try {
        continueButton.style.setProperty("opacity", "1", "important");
      } catch {
        continueButton.style.opacity = "1";
      }
      return true;
    }
    continueButton.textContent = "Weiter (" + remaining + ")";
    return false;
  };
  const timer = setInterval(renderRemaining, 1000);

  continueButton.addEventListener("click", (event) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    if (continueButton.getAttribute("aria-disabled") === "true") {
      if (!renderRemaining()) {
        return;
      }
    }
    clearInterval(timer);
    markSocialReflected(platform, reflected, key, store);
    socialReflectionDone = true;
    socialReflectionPending = false;
    removeSocialOverlay(SOCIAL_REFLECT_OVERLAY_ID);
  }, true);
}

// ---- Feed damping -------------------------------------------------------------

function installSocialFeedDamping() {
  try {
    if (typeof window === "undefined" || typeof window.addEventListener !== "function") {
      return;
    }
    socialLastScrollY = Number.isFinite(window.scrollY) ? window.scrollY : 0;
    // Short-form feeds (TikTok, Shorts, Reels) often swipe whole items via
    // wheel/touch without moving window.scrollY, so both signals count.
    window.addEventListener("scroll", () => {
      const currentY = Number.isFinite(window.scrollY) ? window.scrollY : 0;
      const delta = currentY - socialLastScrollY;
      socialLastScrollY = currentY;
      if (delta > 0) {
        registerSocialScroll(Date.now());
      }
    }, { passive: true });
    window.addEventListener("wheel", (event) => {
      if (event && Number.isFinite(event.deltaY) && event.deltaY > 0) {
        registerSocialScroll(Date.now());
      }
    }, { passive: true });
    window.addEventListener("touchmove", () => {
      registerSocialScroll(Date.now());
    }, { passive: true });
  } catch {
  }
}

function registerSocialScroll(nowMs) {
  const platform = currentSocialPlatform();
  if (!socialAreaActive(socialRulePack) || !platform || socialHasFullOverlay()) {
    return;
  }
  const limits = socialLimitsFromPack(socialRulePack);
  if (limits.feedDampingEnabled !== true || socialPlatformHasOwnBudget(platform)) {
    return;
  }
  if (document.getElementById && document.getElementById(SOCIAL_DAMPING_OVERLAY_ID)) {
    return;
  }
  const nextCount = countScrollBurst(socialScrollCount, socialLastScrollEventMs, nowMs);
  if (nextCount !== socialScrollCount && socialScrollCount === 0) {
    socialScrollCountStartMs = nowMs;
  }
  socialScrollCount = nextCount;
  socialLastScrollEventMs = nowMs;
  if (feedDampingShouldPause(socialScrollCount, limits.feedDampingScrolls)) {
    showSocialDampingOverlay(nowMs);
  }
}

function showSocialDampingOverlay(nowMs) {
  const overlay = buildSocialOverlay(
    SOCIAL_DAMPING_OVERLAY_ID,
    "Kurzer Scroll-Stopp",
    feedDampingSummary(socialScrollCount, nowMs - socialScrollCountStartMs),
    { size: "dialog" }
  );
  if (!overlay) {
    return;
  }
  pauseSocialMedia();

  const theme = overlay.purestateTheme;
  const actions = overlay.purestateActions;
  overlay.purestateBox.insertBefore(purestateCurtainText(document, theme, "In der Zeit wäre auch drin gewesen:", "sub"), actions);
  overlay.purestateBox.insertBefore(purestateCurtainText(document, theme, SOCIAL_DAMPING_ALTERNATIVES, "list"), actions);

  const continueButton = purestateCurtainButton(document, theme, "Weiterscrollen", "secondary");
  continueButton.setAttribute("aria-label", "Weiterscrollen");
  continueButton.addEventListener("click", (event) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    socialScrollCount = 0;
    socialScrollCountStartMs = 0;
    socialLastScrollEventMs = 0;
    removeSocialOverlay(SOCIAL_DAMPING_OVERLAY_ID);
    applySocialState();
  }, true);
  actions.appendChild(continueButton);
}

// ---- Overlays (visual language of the shopping overlays) ---------------------

function activateSocialModalOverlay(overlay) {
  if (!overlay || overlay.purestateModalDialog !== true) {
    return;
  }
  if (overlay.purestateModalActive === true) {
    return;
  }
  overlay.purestateModalActive = true;
  overlay.setAttribute("aria-modal", "true");
  overlay.purestatePreviousFocus = document.activeElement || null;
  let nativeModal = false;
  try {
    if (typeof overlay.showModal === "function") {
      overlay.showModal();
      nativeModal = true;
    }
  } catch {
  }
  overlay.purestateUsesNativeModal = nativeModal;
  if (!nativeModal) {
    const states = [];
    const parent = overlay.parentElement;
    for (const sibling of Array.from(parent && parent.children ? parent.children : [])) {
      if (sibling === overlay) {
        continue;
      }
      states.push({
        element: sibling,
        inert: sibling.getAttribute("inert"),
        ariaHidden: sibling.getAttribute("aria-hidden")
      });
      sibling.setAttribute("inert", "");
      sibling.setAttribute("aria-hidden", "true");
    }
    overlay.purestateBackgroundStates = states;
  }
  overlay.addEventListener("keydown", (event) => {
    if (!event || overlay.purestateUsesNativeModal) {
      return;
    }
    if (event.key === "Escape") {
      event.preventDefault();
      if (overlay.purestateBack && typeof overlay.purestateBack.click === "function") {
        overlay.purestateBack.click();
      }
      return;
    }
    if (event.key !== "Tab") {
      return;
    }
    const focusable = [overlay.purestateBack, overlay.purestatePrimary]
      .filter((element) => element && typeof element.focus === "function");
    if (focusable.length === 0) {
      return;
    }
    event.preventDefault();
    const current = focusable.indexOf(document.activeElement);
    const next = event.shiftKey
      ? (current <= 0 ? focusable.length - 1 : current - 1)
      : (current < 0 || current === focusable.length - 1 ? 0 : current + 1);
    focusable[next].focus();
  }, true);
  overlay.addEventListener("cancel", (event) => {
    if (event) {
      event.preventDefault();
    }
    if (overlay.purestateBack && typeof overlay.purestateBack.click === "function") {
      overlay.purestateBack.click();
    }
  }, true);
  if (overlay.purestateBack && typeof overlay.purestateBack.focus === "function") {
    overlay.purestateBack.focus();
  }
}

function restoreSocialModalAttribute(element, name, previousValue) {
  if (!element) {
    return;
  }
  if (previousValue === null) {
    element.removeAttribute(name);
  } else {
    element.setAttribute(name, previousValue);
  }
}

function deactivateSocialModalOverlay(overlay) {
  if (!overlay || overlay.purestateModalDialog !== true) {
    return null;
  }
  const previousFocus = overlay.purestatePreviousFocus || null;
  try {
    if (overlay.open === true && typeof overlay.close === "function") {
      overlay.close();
    }
  } catch {
  }
  for (const state of Array.isArray(overlay.purestateBackgroundStates)
    ? overlay.purestateBackgroundStates : []) {
    restoreSocialModalAttribute(state.element, "inert", state.inert);
    restoreSocialModalAttribute(state.element, "aria-hidden", state.ariaHidden);
  }
  overlay.purestateBackgroundStates = [];
  overlay.purestatePreviousFocus = null;
  overlay.purestateModalActive = false;
  return previousFocus;
}

function showSocialBlockOverlay() {
  if (document.getElementById && document.getElementById(SOCIAL_BLOCK_OVERLAY_ID)) {
    return;
  }
  buildSocialOverlay(
    SOCIAL_BLOCK_OVERLAY_ID,
    "Diese Plattform ist durch Purestate pausiert",
    "Deine Einstellung: Vollsperre für diese Plattform. Änderbar in der Purestate-App."
  );
}

function showSocialFeedOverlay() {
  if (document.getElementById && document.getElementById(SOCIAL_FEED_OVERLAY_ID)) {
    return;
  }
  buildSocialOverlay(
    SOCIAL_FEED_OVERLAY_ID,
    "Diese Ablenkungsfläche ist durch Purestate gesperrt",
    "Deine Einstellung: Feed/Entdecken dieser Plattform ist gesperrt, der Rest bleibt nutzbar. Änderbar in der Purestate-App."
  );
}

function showSocialCurfewOverlay(limits) {
  if (document.getElementById && document.getElementById(SOCIAL_CURFEW_OVERLAY_ID)) {
    return;
  }
  const endText = limits && typeof limits.curfewEnd === "string" ? limits.curfewEnd : "06:00";
  buildSocialOverlay(
    SOCIAL_CURFEW_OVERLAY_ID,
    "Social Media pausiert",
    "Deine Einstellung: Social-Media-Pause bis " + endText + " Uhr."
  );
}

function showSocialTimeOverlay() {
  if (document.getElementById && document.getElementById(SOCIAL_TIME_OVERLAY_ID)) {
    return;
  }
  // EXT-001: Eigener Text - "Tageszeit erreicht" waere hier gelogen.
  if (socialTimeStateUnknown) {
    buildSocialOverlay(
      SOCIAL_TIME_OVERLAY_ID,
      "Zeitbudget nicht prüfbar",
      "Purestate kann das Zeitbudget gerade nicht prüfen und pausiert Social Media so lange. Läuft der Schutzdienst wieder, geht es sofort weiter."
    );
    return;
  }
  buildSocialOverlay(
    SOCIAL_TIME_OVERLAY_ID,
    "Tageszeit für Social Media erreicht",
    "Morgen geht es weiter."
  );
}

function buildSocialOverlay(overlayId, titleText, messageText, options) {
  const doc = document;
  if (!doc.documentElement || (doc.getElementById && doc.getElementById(overlayId))) {
    return null;
  }
  const preservePageStyles = !!(options && options.preservePageStyles === true);
  const modalDialog = !!(options && options.modalDialog === true);
  const dialogSize = !!(options && options.size === "dialog");
  if (!preservePageStyles && typeof purestateInstantHide === "function") {
    purestateInstantHide(doc, overlayId + "-style");
  }
  const theme = purestateCurtainTheme(doc);

  if (!preservePageStyles) {
    doc.documentElement.style.setProperty("overflow", "hidden", "important");
    if (doc.body) {
      doc.body.style.setProperty("overflow", "hidden", "important");
    }
  }

  const overlay = doc.createElement(modalDialog ? "dialog" : "div");
  overlay.id = overlayId;
  overlay.setAttribute("role", "alertdialog");
  overlay.setAttribute("aria-live", "assertive");
  overlay.setAttribute("aria-label", "Purestate " + titleText);
  overlay.setAttribute("aria-labelledby", overlayId + "-title");
  overlay.setAttribute("aria-describedby", overlayId + "-detail");
  overlay.setAttribute("tabindex", "-1");
  // EXT-A05: eigener Scroll + margin:auto statt abschneidender Zentrierung.
  // Der native <dialog> bringt eigene Raender und Groessen mit.
  overlay.style.cssText = purestateCurtainOverlayCss(theme, modalDialog
    ? ["border:0", "margin:0", "width:auto", "max-width:none", "height:auto", "max-height:none"]
    : []);

  const box = purestateCurtainColumn(doc);
  box.appendChild(purestateCurtainBars(doc, theme, dialogSize ? "sm" : "lg"));
  box.appendChild(purestateCurtainText(doc, theme, "Purestate", "label"));
  box.appendChild(purestateCurtainTitle(doc, theme, overlayId + "-title", titleText, dialogSize ? "dialog" : "curtain"));
  const detail = purestateCurtainText(doc, theme, messageText, "detail");
  detail.id = overlayId + "-detail";
  box.appendChild(detail);

  const back = purestateCurtainButton(doc, theme, "Zurück", "primary");
  back.setAttribute("aria-label", "Zurück zur vorherigen Seite");
  back.addEventListener("click", (event) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    try {
      const view = doc.defaultView || (typeof window !== "undefined" ? window : null);
      if (!view) {
        return;
      }
      const origin = view.location.origin;
      if (view.history && view.history.length > 1) {
        view.history.back();
        // Going "back" within the same covered platform would just re-show
        // the overlay (live finding on full blocks: the button felt dead) -
        // leave to a neutral page instead.
        view.setTimeout(() => {
          try {
            if (view.location.origin === origin) {
              view.location.assign("about:blank");
            }
          } catch {
          }
        }, 250);
      } else {
        view.location.assign("about:blank");
      }
    } catch {
    }
  }, true);
  const actions = purestateCurtainActions(doc);
  actions.appendChild(back);
  box.appendChild(actions);

  overlay.appendChild(box);
  (doc.body || doc.documentElement).appendChild(overlay);
  overlay.purestateBox = box;
  overlay.purestateBack = back;
  overlay.purestateActions = actions;
  overlay.purestateTheme = theme;
  overlay.purestateLocksPage = !preservePageStyles;
  overlay.purestateModalDialog = modalDialog;
  // EXT-A04: Die Vollvorhaenge nehmen den Fokus wie die Reflexion (die ihren
  // eigenen nativen Modalpfad hat, activateSocialModalOverlay).
  if (!modalDialog && typeof purestateHoldOverlayFocus === "function") {
    purestateHoldOverlayFocus(doc, overlay, back);
  }
  return overlay;
}

function removeSocialOverlay(overlayId) {
  if (!document.getElementById) {
    return;
  }
  const overlay = document.getElementById(overlayId);
  if (!overlay) {
    return;
  }
  const previousFocus = deactivateSocialModalOverlay(overlay);
  const unlockPage = overlay.purestateLocksPage === true;
  if (overlay.parentElement) {
    overlay.parentElement.removeChild(overlay);
  }
  if (typeof purestateRemoveInstantHide === "function") {
    purestateRemoveInstantHide(document, overlayId + "-style");
  }
  // Erst nach dem Sichtbarmachen: ein unsichtbarer Knopf nimmt keinen Fokus.
  if (typeof purestateReleaseOverlayFocus === "function") {
    purestateReleaseOverlayFocus(overlay);
  }
  if (unlockPage && document.documentElement && !socialHasFullOverlay()) {
    document.documentElement.style.removeProperty("overflow");
    if (document.body) {
      document.body.style.removeProperty("overflow");
    }
  }
  if (previousFocus && typeof previousFocus.focus === "function") {
    previousFocus.focus();
  }
}

installSocialMediaModule();
