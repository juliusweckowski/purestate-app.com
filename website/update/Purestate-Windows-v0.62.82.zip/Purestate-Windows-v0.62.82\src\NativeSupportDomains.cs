using System;
using System.IO;
using System.Text;

namespace Purestate.Native
{
    internal static partial class Support
    {
        public static string CustomDomainsPath()
        {
            return Path.Combine(InstallDir, "rules", "custom-domains.txt");
        }

        public static string AllowDomainsPath()
        {
            return Path.Combine(InstallDir, "rules", "allow-domains.txt");
        }

        public static string CustomGamblingDomainsPath()
        {
            return Path.Combine(InstallDir, "rules", "custom-gambling-domains.txt");
        }

        public static string CustomShoppingDomainsPath()
        {
            return Path.Combine(InstallDir, "rules", "custom-shopping-domains.txt");
        }

        public static string MixedSiteUrlPatternsPath()
        {
            return Path.Combine(InstallDir, "rules", "mixed-site-url-patterns.txt");
        }

        public static string AdultUrlKeywordsPath()
        {
            return Path.Combine(InstallDir, "rules", "adult-url-keywords.txt");
        }

        public static string NsfwSubredditsPath()
        {
            return Path.Combine(InstallDir, "rules", "nsfw-subreddits.txt");
        }

        public static string[] ReadCustomDomains()
        {
            EnsureCustomDomainsFile();
            return ReadCustomDomains(CustomDomainsPath());
        }

        internal static string[] ReadCustomDomains(string path)
        {
            System.Collections.Generic.SortedSet<string> domains = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            if (!File.Exists(path))
            {
                return new string[0];
            }

            foreach (string raw in File.ReadAllLines(path))
            {
                string domain = NormalizeDomain(raw);
                if (IsValidDomain(domain))
                {
                    domains.Add(domain);
                }
            }

            string[] result = new string[domains.Count];
            domains.CopyTo(result);
            return result;
        }

        // ---- Eigene Sperrliste: Eintragen sofort, Zuruecknehmen mit Frist -------
        //
        // RC-001: Eine selbst gesetzte Sperre liess sich in Sekunden wieder
        // aufheben - genau der Ablauf, fuer den es das Zeitfenster ueberhaupt
        // gibt: im klaren Moment eintragen, im Impuls entfernen. Das Muster
        // dafuer steht in derselben Datei (AddAdultLearnedExemption): Wirkung
        // erst nach einer Frist, Ruecknahme der Frist sofort.
        //
        // Die Ausnahme ist der eigentliche Entwurf: eine Eingabe, die noch keine
        // Stunde alt ist, ist eine Korrektur - Tippfehler, falsche Domain - und
        // wird sofort geloescht. Ohne sie bliebe ein versehentlich gesperrtes
        // bank.de eine Viertelstunde bestehen, und das Werkzeug haette einen
        // Fehler gemacht, den der Nutzer nicht rueckgaengig machen kann.
        public const int CustomDomainRemovalDelayMinutes = 15;
        public const int CustomDomainCorrectionWindowMinutes = 60;

        public static string CustomDomainsAddedPath()
        {
            return Path.Combine(InstallDir, "rules", "custom-domains-added.txt");
        }

        public static string CustomDomainRemovalsPath()
        {
            return Path.Combine(InstallDir, "rules", "custom-domain-removals.txt");
        }

        public static bool AddCustomDomain(string input)
        {
            EnsureCustomDomainsFile();
            return AddCustomDomainGuarded(
                input, CustomDomainsPath(), CustomDomainsAddedPath(), CustomDomainRemovalsPath(), TrustedUtcNow()).Length == 0;
        }

        // Leerer Rueckgabewert = eingetragen. Sonst der deutsche Hinweis.
        internal static string AddCustomDomainGuarded(string input, string listPath, string addedPath, string removalPath, DateTime nowUtc)
        {
            string domain = ToAsciiDomain(NormalizeDomain(input));
            // DMN-001: NormalizeDomain entfernt "www." nicht von sich aus. Die
            // Schwesterfunktionen fuer Gluecksspiel- und Shoppinglisten
            // schneiden es ab, diese hier tat es nicht - wer "www.beispiel.de"
            // eintrug, sperrte damit nicht "beispiel.de", ohne Hinweis. Die
            // Sperre gilt ohnehin fuer die Domain samt Unterdomains.
            if (domain.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
            {
                domain = domain.Substring(4);
            }

            if (!IsValidDomain(domain))
            {
                throw new InvalidOperationException("Das ist keine gueltige Domain.");
            }

            System.Collections.Generic.SortedSet<string> domains =
                new System.Collections.Generic.SortedSet<string>(ReadCustomDomains(listPath), StringComparer.OrdinalIgnoreCase);
            bool added = domains.Add(domain);
            WriteDomainFile(listPath, domains);

            // Eintragen ist eine Verstaerkung und wirkt sofort - auch auf eine
            // laufende Karenz: wer die Sperre zurueckholt, hebt seine eigene
            // Ruecknahme auf.
            WriteTimestampedDomainFile(removalPath, RemoveTimestampedDomain(ReadTimestampedDomains(removalPath), domain));

            System.Collections.Generic.List<TimestampedDomain> addedEntries = ReadTimestampedDomains(addedPath);
            if (added || FindTimestampedDomain(addedEntries, domain) == null)
            {
                addedEntries = RemoveTimestampedDomain(addedEntries, domain);
                addedEntries.Add(new TimestampedDomain(nowUtc, domain));
                WriteTimestampedDomainFile(addedPath, addedEntries);
            }

            return added ? string.Empty : "Diese Webseite steht bereits auf der Liste.";
        }

        public static bool RemoveCustomDomain(string input)
        {
            return RemoveCustomDomainGuarded(
                input, CustomDomainsPath(), CustomDomainsAddedPath(), CustomDomainRemovalsPath(), TrustedUtcNow()).Length == 0;
        }

        // Leerer Rueckgabewert = sofort entfernt (Korrektur). Sonst der
        // deutsche Hinweis auf die laufende Frist.
        internal static string RemoveCustomDomainGuarded(string input, string listPath, string addedPath, string removalPath, DateTime nowUtc)
        {
            string domain = ToAsciiDomain(NormalizeDomain(input));
            System.Collections.Generic.SortedSet<string> domains =
                new System.Collections.Generic.SortedSet<string>(ReadCustomDomains(listPath), StringComparer.OrdinalIgnoreCase);
            if (!domains.Contains(domain))
            {
                return string.Empty;
            }

            TimestampedDomain addedEntry = FindTimestampedDomain(ReadTimestampedDomains(addedPath), domain);
            bool isCorrection = addedEntry != null &&
                addedEntry.AtUtc > nowUtc.AddMinutes(-CustomDomainCorrectionWindowMinutes);

            if (isCorrection)
            {
                domains.Remove(domain);
                WriteDomainFile(listPath, domains);
                WriteTimestampedDomainFile(addedPath, RemoveTimestampedDomain(ReadTimestampedDomains(addedPath), domain));
                WriteActivityLog("Custom block domain removed within the correction window.");
                return string.Empty;
            }

            System.Collections.Generic.List<TimestampedDomain> removals = ReadTimestampedDomains(removalPath);
            TimestampedDomain pending = FindTimestampedDomain(removals, domain);
            if (pending == null)
            {
                removals.Add(new TimestampedDomain(nowUtc.AddMinutes(CustomDomainRemovalDelayMinutes), domain));
                WriteTimestampedDomainFile(removalPath, removals);
                WriteActivityLog("Custom block domain removal requested (effective in " +
                    CustomDomainRemovalDelayMinutes + " minutes).");
            }

            return "Diese Webseite wird in " + CustomDomainRemovalDelayMinutes +
                " Minuten freigegeben. Bis dahin bleibt sie gesperrt - du kannst die Freigabe jederzeit zuruecknehmen, indem du sie erneut eintraegst.";
        }

        public static void ClearCustomDomainRemovals()
        {
            WriteTimestampedDomainFile(CustomDomainRemovalsPath(), new System.Collections.Generic.List<TimestampedDomain>());
        }

        // Wird vom Durchsetzungslauf aufgerufen: faellige Ruecknahmen ausfuehren.
        // Rueckgabewert = Anzahl der entfernten Domains.
        public static int ApplyDueCustomDomainRemovals()
        {
            EnsureCustomDomainsFile();
            return ApplyDueCustomDomainRemovals(CustomDomainsPath(), CustomDomainRemovalsPath(), TrustedUtcNow());
        }

        internal static int ApplyDueCustomDomainRemovals(string listPath, string removalPath, DateTime nowUtc)
        {
            System.Collections.Generic.List<TimestampedDomain> removals = ReadTimestampedDomains(removalPath);
            if (removals.Count == 0)
            {
                return 0;
            }

            System.Collections.Generic.SortedSet<string> domains =
                new System.Collections.Generic.SortedSet<string>(ReadCustomDomains(listPath), StringComparer.OrdinalIgnoreCase);
            System.Collections.Generic.List<TimestampedDomain> pending =
                new System.Collections.Generic.List<TimestampedDomain>();
            int removed = 0;

            foreach (TimestampedDomain entry in removals)
            {
                if (entry.AtUtc > nowUtc)
                {
                    pending.Add(entry);
                    continue;
                }
                if (domains.Remove(entry.Host))
                {
                    removed++;
                }
            }

            if (removed > 0)
            {
                WriteDomainFile(listPath, domains);
                WriteActivityLog("Custom block domains released after the waiting period: " + removed + ".");
            }
            if (pending.Count != removals.Count)
            {
                WriteTimestampedDomainFile(removalPath, pending);
            }
            return removed;
        }

        internal sealed class TimestampedDomain
        {
            public TimestampedDomain(DateTime atUtc, string host)
            {
                AtUtc = atUtc.ToUniversalTime();
                Host = host;
            }

            public DateTime AtUtc;
            public string Host;
        }

        internal static System.Collections.Generic.List<TimestampedDomain> ReadTimestampedDomains(string path)
        {
            System.Collections.Generic.List<TimestampedDomain> entries =
                new System.Collections.Generic.List<TimestampedDomain>();
            if (!File.Exists(path))
            {
                return entries;
            }

            foreach (string raw in File.ReadAllLines(path))
            {
                string trimmed = (raw ?? string.Empty).Trim();
                if (trimmed.Length == 0 || trimmed.StartsWith("#", StringComparison.Ordinal))
                {
                    continue;
                }
                string[] parts = trimmed.Split(new[] { '|' }, 2);
                if (parts.Length != 2)
                {
                    continue;
                }
                DateTime atUtc;
                if (!DateTime.TryParse(parts[0].Trim(), System.Globalization.CultureInfo.InvariantCulture,
                        System.Globalization.DateTimeStyles.RoundtripKind, out atUtc))
                {
                    continue;
                }
                string host = NormalizeDomain(parts[1]);
                if (!IsValidDomain(host))
                {
                    continue;
                }
                entries.Add(new TimestampedDomain(atUtc, host));
            }
            return entries;
        }

        private static TimestampedDomain FindTimestampedDomain(
            System.Collections.Generic.List<TimestampedDomain> entries, string host)
        {
            foreach (TimestampedDomain entry in entries)
            {
                if (string.Equals(entry.Host, host, StringComparison.OrdinalIgnoreCase))
                {
                    return entry;
                }
            }
            return null;
        }

        private static System.Collections.Generic.List<TimestampedDomain> RemoveTimestampedDomain(
            System.Collections.Generic.List<TimestampedDomain> entries, string host)
        {
            System.Collections.Generic.List<TimestampedDomain> kept =
                new System.Collections.Generic.List<TimestampedDomain>();
            foreach (TimestampedDomain entry in entries)
            {
                if (!string.Equals(entry.Host, host, StringComparison.OrdinalIgnoreCase))
                {
                    kept.Add(entry);
                }
            }
            return kept;
        }

        private static void WriteTimestampedDomainFile(
            string path, System.Collections.Generic.List<TimestampedDomain> entries)
        {
            System.Text.StringBuilder builder = new System.Text.StringBuilder();
            foreach (TimestampedDomain entry in entries)
            {
                builder.AppendLine(entry.AtUtc.ToString("o") + "|" + entry.Host);
            }
            string directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }
            WriteAllTextDurable(path, builder.ToString());
        }

        private static void WriteDomainFile(string path, System.Collections.Generic.IEnumerable<string> domains)
        {
            System.Text.StringBuilder builder = new System.Text.StringBuilder();
            foreach (string domain in domains)
            {
                builder.AppendLine(domain);
            }
            string directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }
            WriteAllTextDurable(path, builder.ToString());
        }

        // DESK-13: Der Import zaehlte Eingabezeilen, las die ganze Datei in den
        // Speicher und begrenzte nur den einzelnen Aufruf. Jetzt: gestreamt,
        // derselbe Normalisierer wie bei der Einzeleingabe (www, Punycode),
        // Bestand und Duplikate zaehlen nicht als neu, und die Obergrenze gilt
        // fuer die ganze Liste. Nur der Importweg ist begrenzt - Leser der
        // Liste und die Einzeleingabe bleiben unveraendert.
        // Wie AddCustomDomainGuarded: Eintragen ist eine Verstaerkung und hebt
        // eine laufende eigene Ruecknahme auf; neu eingetragene Domains bekommen
        // den Zeitstempel fuer das Korrekturfenster. Bewusst strenger als die
        // Einzeleingabe: bereits vorhandene Domains ohne Zeitstempel bekommen
        // keinen neuen - sonst wuerde ein Import alte Sperren sofort entfernbar
        // machen. Jede Datei wird hoechstens einmal geschrieben.
        internal static CustomDomainImportResult ImportCustomDomains(string sourcePath, string listPath, string addedPath, string removalPath, DateTime nowUtc, int maxTotal)
        {
            System.Collections.Generic.SortedSet<string> domains =
                new System.Collections.Generic.SortedSet<string>(ReadCustomDomains(listPath), StringComparer.OrdinalIgnoreCase);
            System.Collections.Generic.List<string> inList = new System.Collections.Generic.List<string>();
            System.Collections.Generic.List<string> newlyAdded = new System.Collections.Generic.List<string>();
            CustomDomainImportResult result = new CustomDomainImportResult();
            foreach (string raw in File.ReadLines(sourcePath))
            {
                string trimmed = raw.Trim();
                if (trimmed.Length == 0 || trimmed.StartsWith("#", StringComparison.Ordinal))
                {
                    continue;
                }

                string domain = ToAsciiDomain(NormalizeDomain(trimmed));
                if (domain.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
                {
                    domain = domain.Substring(4);
                }
                if (domain.Length > 253 || !IsValidDomain(domain))
                {
                    result.Invalid++;
                    continue;
                }
                if (domains.Contains(domain))
                {
                    result.Duplicates++;
                    inList.Add(domain);
                    continue;
                }
                if (domains.Count >= maxTotal)
                {
                    result.Truncated = true;
                    break;
                }

                domains.Add(domain);
                inList.Add(domain);
                newlyAdded.Add(domain);
                result.Added++;
            }

            if (result.Added > 0)
            {
                WriteDomainFile(listPath, domains);
            }

            System.Collections.Generic.List<TimestampedDomain> removals = ReadTimestampedDomains(removalPath);
            int pendingBefore = removals.Count;
            foreach (string domain in inList)
            {
                removals = RemoveTimestampedDomain(removals, domain);
            }
            if (removals.Count != pendingBefore)
            {
                WriteTimestampedDomainFile(removalPath, removals);
            }

            if (newlyAdded.Count > 0)
            {
                System.Collections.Generic.List<TimestampedDomain> addedEntries = ReadTimestampedDomains(addedPath);
                foreach (string domain in newlyAdded)
                {
                    addedEntries = RemoveTimestampedDomain(addedEntries, domain);
                    addedEntries.Add(new TimestampedDomain(nowUtc, domain));
                }
                WriteTimestampedDomainFile(addedPath, addedEntries);
            }

            result.Total = domains.Count;
            return result;
        }

        public static int CleanCustomDomains()
        {
            System.Collections.Generic.SortedSet<string> domains = new System.Collections.Generic.SortedSet<string>(ReadCustomDomains(), StringComparer.OrdinalIgnoreCase);
            WriteCustomDomains(domains);
            return domains.Count;
        }

        public static string[] ReadAllowDomains()
        {
            string path = AllowDomainsPath();
            EnsureAllowDomainsFile();

            System.Collections.Generic.SortedSet<string> domains = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string raw in File.ReadAllLines(path))
            {
                string domain = NormalizeDomain(raw);
                if (IsValidDomain(domain))
                {
                    domains.Add(domain);
                }
            }

            string[] result = new string[domains.Count];
            domains.CopyTo(result);
            return result;
        }

        public static string[] ReadCustomGamblingDomains()
        {
            return ReadCustomGamblingDomains(CustomGamblingDomainsPath());
        }

        public static string[] ReadCustomGamblingDomains(string path)
        {
            EnsureCustomGamblingDomainsFile(path);

            System.Collections.Generic.SortedSet<string> domains = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string raw in File.ReadAllLines(path))
            {
                string domain = NormalizeDomain(raw);
                if (IsValidDomain(domain))
                {
                    domains.Add(domain);
                }
            }

            string[] result = new string[domains.Count];
            domains.CopyTo(result);
            return result;
        }

        public static bool AddCustomGamblingDomain(string input)
        {
            return AddCustomGamblingDomain(input, CustomGamblingDomainsPath());
        }

        internal static bool AddCustomGamblingDomain(string input, string path)
        {
            string domain = ToAsciiDomain(NormalizeDomain(input));
            if (domain.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
            {
                domain = domain.Substring(4);
            }
            if (!IsValidDomain(domain))
            {
                throw new InvalidOperationException("Das ist keine gueltige Domain.");
            }

            System.Collections.Generic.SortedSet<string> domains = new System.Collections.Generic.SortedSet<string>(ReadCustomGamblingDomains(path), StringComparer.OrdinalIgnoreCase);
            bool added = domains.Add(domain);
            WriteCustomGamblingDomains(domains, path);
            return added;
        }

        public static int CleanCustomGamblingDomains()
        {
            return CleanCustomGamblingDomains(CustomGamblingDomainsPath());
        }

        internal static int CleanCustomGamblingDomains(string path)
        {
            System.Collections.Generic.SortedSet<string> domains = new System.Collections.Generic.SortedSet<string>(ReadCustomGamblingDomains(path), StringComparer.OrdinalIgnoreCase);
            WriteCustomGamblingDomains(domains, path);
            return domains.Count;
        }

        public static string[] ReadCustomShoppingDomains()
        {
            return ReadCustomShoppingDomains(CustomShoppingDomainsPath());
        }

        public static string[] ReadCustomShoppingDomains(string path)
        {
            EnsureCustomShoppingDomainsFile(path);

            System.Collections.Generic.SortedSet<string> domains = new System.Collections.Generic.SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string raw in File.ReadAllLines(path))
            {
                string domain = NormalizeDomain(raw);
                if (IsValidDomain(domain))
                {
                    domains.Add(domain);
                }
            }

            string[] result = new string[domains.Count];
            domains.CopyTo(result);
            return result;
        }

        public static bool AddCustomShoppingDomain(string input)
        {
            return AddCustomShoppingDomain(input, CustomShoppingDomainsPath());
        }

        internal static bool AddCustomShoppingDomain(string input, string path)
        {
            string domain = ToAsciiDomain(NormalizeDomain(input));
            if (domain.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
            {
                domain = domain.Substring(4);
            }
            if (!IsValidDomain(domain))
            {
                throw new InvalidOperationException("Das ist keine gueltige Domain.");
            }

            System.Collections.Generic.SortedSet<string> domains = new System.Collections.Generic.SortedSet<string>(ReadCustomShoppingDomains(path), StringComparer.OrdinalIgnoreCase);
            bool added = domains.Add(domain);
            WriteCustomShoppingDomains(domains, path);
            return added;
        }

        public static int CleanCustomShoppingDomains()
        {
            return CleanCustomShoppingDomains(CustomShoppingDomainsPath());
        }

        internal static int CleanCustomShoppingDomains(string path)
        {
            System.Collections.Generic.SortedSet<string> domains = new System.Collections.Generic.SortedSet<string>(ReadCustomShoppingDomains(path), StringComparer.OrdinalIgnoreCase);
            WriteCustomShoppingDomains(domains, path);
            return domains.Count;
        }

        // Steht die Domain in einer MITGELIEFERTEN Sperrliste? Die selbst
        // gepflegten Listen (custom-*.txt) zaehlen bewusst nicht mit: eine
        // eigene Sperre muss der Nutzer selbst wieder aufheben koennen.
        // Grundlage fuer DOM-003 - die Allowlist darf kuratierte Domains weder
        // aus der hosts-Sperre nehmen (siehe Get-EffectiveHostsBlockDomains in
        // scripts\Common.ps1) noch ueberhaupt annehmen.
        internal static bool IsCuratedBlockDomain(string input, string rulesDirectory)
        {
            string domain = ToAsciiDomain(NormalizeDomain(input));
            // Wie IsListedGamblingDomain: fuehrendes "www." abschneiden, sonst
            // waere "www.kuratiert.example" eine andere Domain als der
            // Listeneintrag.
            if (domain.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
            {
                domain = domain.Substring(4);
            }
            if (!IsValidDomain(domain) || string.IsNullOrEmpty(rulesDirectory))
            {
                return false;
            }

            string[] files =
            {
                "adult-domains.txt",
                "gambling-domains.txt",
                "offshore-gambling-domains.txt",
                "gambling-affiliate-domains.txt",
                "gaming-domains.txt"
            };
            foreach (string file in files)
            {
                string path = Path.Combine(rulesDirectory, file);
                if (!File.Exists(path))
                {
                    continue;
                }

                foreach (string raw in File.ReadAllLines(path))
                {
                    if (string.Equals(NormalizeDomain(raw), domain, StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public static bool IsCuratedBlockDomain(string input)
        {
            return IsCuratedBlockDomain(input, Path.Combine(InstallDir, "rules"));
        }

        public static bool AddAllowDomain(string input)
        {
            string domain = ToAsciiDomain(NormalizeDomain(input));
            if (!IsValidDomain(domain))
            {
                throw new InvalidOperationException("Das ist keine gueltige Domain.");
            }

            // Lieber hier ablehnen als spaeter still wirkungslos bleiben: die
            // Durchsetzung nimmt kuratierte Domains ohnehin nicht mehr aus der
            // Sperre, und ein Eintrag, der nichts tut, ist die schlechtere
            // Antwort (DOM-003).
            if (IsCuratedBlockDomain(domain))
            {
                throw new InvalidOperationException(
                    "Diese Domain steht in einer mitgelieferten Sperrliste und kann nicht freigegeben werden.");
            }

            System.Collections.Generic.SortedSet<string> domains = new System.Collections.Generic.SortedSet<string>(ReadAllowDomains(), StringComparer.OrdinalIgnoreCase);
            bool added = domains.Add(domain);
            WriteAllowDomains(domains);
            return added;
        }

        public static bool RemoveAllowDomain(string input)
        {
            string domain = ToAsciiDomain(NormalizeDomain(input));
            System.Collections.Generic.SortedSet<string> domains = new System.Collections.Generic.SortedSet<string>(ReadAllowDomains(), StringComparer.OrdinalIgnoreCase);
            bool removed = domains.Remove(domain);
            WriteAllowDomains(domains);
            return removed;
        }

        public static int CleanAllowDomains()
        {
            System.Collections.Generic.SortedSet<string> domains = new System.Collections.Generic.SortedSet<string>(ReadAllowDomains(), StringComparer.OrdinalIgnoreCase);
            WriteAllowDomains(domains);
            return domains.Count;
        }

        private static void EnsureCustomDomainsFile()
        {
            string path = CustomDomainsPath();
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            if (!File.Exists(path))
            {
                File.WriteAllText(path, "# Optional custom block list." + Environment.NewLine + "# Add one domain per line." + Environment.NewLine, Encoding.ASCII);
            }
        }

        private static void WriteCustomDomains(System.Collections.Generic.IEnumerable<string> domains)
        {
            string path = CustomDomainsPath();
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("# Optional custom block list.");
            builder.AppendLine("# Managed by Purestate.");
            foreach (string domain in domains)
            {
                if (IsValidDomain(domain))
                {
                    builder.AppendLine(domain.ToLowerInvariant());
                }
            }

            File.WriteAllText(path, builder.ToString(), Encoding.ASCII);
        }

        private static void EnsureCustomGamblingDomainsFile()
        {
            EnsureCustomGamblingDomainsFile(CustomGamblingDomainsPath());
        }

        private static void EnsureCustomGamblingDomainsFile(string path)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            if (!File.Exists(path))
            {
                File.WriteAllText(path, "# Optional custom gambling block list." + Environment.NewLine + "# Add one domain per line." + Environment.NewLine, Encoding.ASCII);
            }
        }

        private static void WriteCustomGamblingDomains(System.Collections.Generic.IEnumerable<string> domains)
        {
            WriteCustomGamblingDomains(domains, CustomGamblingDomainsPath());
        }

        private static void WriteCustomGamblingDomains(System.Collections.Generic.IEnumerable<string> domains, string path)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("# Optional custom gambling block list.");
            builder.AppendLine("# Managed by Purestate.");
            foreach (string domain in domains)
            {
                if (IsValidDomain(domain))
                {
                    builder.AppendLine(domain.ToLowerInvariant());
                }
            }

            File.WriteAllText(path, builder.ToString(), Encoding.ASCII);
        }

        private static void EnsureCustomShoppingDomainsFile(string path)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            if (!File.Exists(path))
            {
                File.WriteAllText(path, "# Optional custom shopping block list." + Environment.NewLine + "# Add one domain per line." + Environment.NewLine, Encoding.ASCII);
            }
        }

        private static void WriteCustomShoppingDomains(System.Collections.Generic.IEnumerable<string> domains)
        {
            WriteCustomShoppingDomains(domains, CustomShoppingDomainsPath());
        }

        private static void WriteCustomShoppingDomains(System.Collections.Generic.IEnumerable<string> domains, string path)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("# Optional custom shopping block list.");
            builder.AppendLine("# Managed by Purestate.");
            foreach (string domain in domains)
            {
                if (IsValidDomain(domain))
                {
                    builder.AppendLine(domain.ToLowerInvariant());
                }
            }

            File.WriteAllText(path, builder.ToString(), Encoding.ASCII);
        }

        private static void EnsureAllowDomainsFile()
        {
            string path = AllowDomainsPath();
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            if (!File.Exists(path))
            {
                File.WriteAllText(path, "# Optional allow list." + Environment.NewLine + "# Domains listed here are not written into the local hosts block." + Environment.NewLine, Encoding.ASCII);
            }
        }

        private static void WriteAllowDomains(System.Collections.Generic.IEnumerable<string> domains)
        {
            string path = AllowDomainsPath();
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("# Optional allow list.");
            builder.AppendLine("# Managed by Purestate.");
            foreach (string domain in domains)
            {
                if (IsValidDomain(domain))
                {
                    builder.AppendLine(domain.ToLowerInvariant());
                }
            }

            File.WriteAllText(path, builder.ToString(), Encoding.ASCII);
        }

        // ---- Gluecksspiel-Freigaben (Heuristikschicht) -----------------------------

        public const int GamblingHeuristicExemptionDelayMinutes = 15;
        // GHX-001: Der Erwachsenen-Zwilling hat Vorlauf, Ablauf UND Deckel;
        // hier gab es nur den Vorlauf. Eine im Impuls erteilte Freigabe galt
        // damit fuer immer, und die Liste konnte unbegrenzt wachsen. Ob das
        // Absicht war, stand nirgends - das war der eigentliche Befund. Es ist
        // jetzt angeglichen: dieselben Zahlen wie bei Erwachseneninhalten.
        public const int GamblingHeuristicExemptionLifetimeDays = 30;
        public const int GamblingHeuristicExemptionCapacity = 500;

        internal static bool IsGamblingHeuristicExemptionEffective(
            GamblingHeuristicExemption exemption, DateTime nowUtc)
        {
            DateTime activatesAtUtc = exemption == null
                ? DateTime.MinValue
                : exemption.ActivatesAtUtc.ToUniversalTime();
            return exemption != null &&
                activatesAtUtc <= nowUtc &&
                activatesAtUtc > nowUtc.AddDays(-GamblingHeuristicExemptionLifetimeDays);
        }

        public static string GamblingHeuristicExemptionsPath()
        {
            return Path.Combine(InstallDir, "rules", "gambling-heuristic-exemptions.txt");
        }

        public static string FormatGamblingHeuristicExemptionLine(GamblingHeuristicExemption exemption)
        {
            if (exemption == null)
            {
                throw new ArgumentNullException("exemption");
            }

            return exemption.ActivatesAtUtc.ToUniversalTime().ToString("o") + "|" + exemption.Host;
        }

        public static GamblingHeuristicExemption ParseGamblingHeuristicExemptionLine(string line)
        {
            string trimmed = (line ?? string.Empty).Trim();
            if (trimmed.Length == 0 || trimmed.StartsWith("#", StringComparison.Ordinal))
            {
                return null;
            }

            string[] parts = trimmed.Split(new[] { '|' }, 2);
            if (parts.Length != 2)
            {
                return null;
            }

            DateTime activatesAt;
            if (!DateTime.TryParse(parts[0].Trim(), null,
                System.Globalization.DateTimeStyles.RoundtripKind, out activatesAt))
            {
                return null;
            }

            string host = NormalizeDomain(parts[1]);
            if (!IsValidDomain(host))
            {
                return null;
            }

            return new GamblingHeuristicExemption
            {
                ActivatesAtUtc = activatesAt.ToUniversalTime(),
                Host = host
            };
        }

        public static System.Collections.Generic.List<GamblingHeuristicExemption> ReadGamblingHeuristicExemptions()
        {
            return ReadGamblingHeuristicExemptions(GamblingHeuristicExemptionsPath());
        }

        internal static System.Collections.Generic.List<GamblingHeuristicExemption> ReadGamblingHeuristicExemptions(string path)
        {
            System.Collections.Generic.List<GamblingHeuristicExemption> exemptions =
                new System.Collections.Generic.List<GamblingHeuristicExemption>();
            if (!File.Exists(path))
            {
                return exemptions;
            }

            System.Collections.Generic.HashSet<string> seen =
                new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string raw in File.ReadAllLines(path))
            {
                GamblingHeuristicExemption exemption = ParseGamblingHeuristicExemptionLine(raw);
                if (exemption == null || !seen.Add(exemption.Host))
                {
                    continue;
                }
                exemptions.Add(exemption);
            }

            // GHX-001, wie beim Erwachsenen-Zwilling: Altdateien koennen
            // groesser sein als der heutige Schreiber. Erst die juengsten
            // Eintraege bestimmen, dann deckeln - sonst verdecken 500
            // abgelaufene Zeilen am Dateianfang eine noch gueltige Freigabe
            // weiter unten und entfernen sie beim naechsten Schreiben
            // unwiederbringlich.
            exemptions.Sort((left, right) =>
                right.ActivatesAtUtc.CompareTo(left.ActivatesAtUtc));
            if (exemptions.Count > GamblingHeuristicExemptionCapacity)
            {
                exemptions.RemoveRange(
                    GamblingHeuristicExemptionCapacity,
                    exemptions.Count - GamblingHeuristicExemptionCapacity);
            }
            return exemptions;
        }

        public static void WriteGamblingHeuristicExemptions(
            System.Collections.Generic.IEnumerable<GamblingHeuristicExemption> exemptions)
        {
            WriteGamblingHeuristicExemptions(exemptions, GamblingHeuristicExemptionsPath());
        }

        internal static void WriteGamblingHeuristicExemptions(
            System.Collections.Generic.IEnumerable<GamblingHeuristicExemption> exemptions, string path)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("# Purestate Gluecksspiel-Freigaben (kein Gluecksspiel)");
            builder.AppendLine("# Format: aktivAbUtc|hostname");
            builder.AppendLine("# Wirkt nur auf die Inhaltserkennung. Gelistete Domains bleiben gesperrt.");
            System.Collections.Generic.HashSet<string> seen =
                new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (GamblingHeuristicExemption exemption in exemptions ?? new GamblingHeuristicExemption[0])
            {
                if (exemption == null || !IsValidDomain(exemption.Host) || !seen.Add(exemption.Host))
                {
                    continue;
                }
                builder.AppendLine(FormatGamblingHeuristicExemptionLine(exemption));
            }

            string directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }
            File.WriteAllText(path, builder.ToString(), new UTF8Encoding(false));
        }

        // Leerer Rueckgabewert = angelegt. Sonst der deutsche Ablehnungsgrund.
        // Die Passwortabfrage liegt im UI-Aufrufer, hier nur die Verzoegerung:
        // eine frische Freigabe darf die laufende Sitzung nicht mehr retten.
        public static string AddGamblingHeuristicExemption(string host)
        {
            return AddGamblingHeuristicExemption(host, GamblingHeuristicExemptionsPath(), TrustedUtcNow());
        }

        internal static string AddGamblingHeuristicExemption(string host, string path, DateTime nowUtc)
        {
            // GHX-003: Der Erwachsenen-Zwilling beginnt mit genau dieser Zeile,
            // hier fehlte sie. Heute folgenlos - der Produktivaufrufer uebergibt
            // TrustedUtcNow(), und die liefert immer Kind=Utc, ein zweites
            // ToUniversalTime() ist dann die Identitaet. Bei einer Local- oder
            // Unspecified-Zeit haette der Schreibweg dagegen um den lokalen
            // Versatz verschoben, waehrend die Frist mit der Rohzeit rechnet.
            nowUtc = nowUtc.ToUniversalTime();
            string domain = NormalizeDomain(host);
            if (domain.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
            {
                domain = domain.Substring(4);
            }
            if (!IsValidDomain(domain))
            {
                return "Das ist keine gueltige Webadresse.";
            }

            System.Collections.Generic.List<GamblingHeuristicExemption> exemptions =
                ReadGamblingHeuristicExemptions(path);
            exemptions.RemoveAll(existing => existing.ActivatesAtUtc.ToUniversalTime() <=
                nowUtc.AddDays(-GamblingHeuristicExemptionLifetimeDays));
            foreach (GamblingHeuristicExemption existing in exemptions)
            {
                if (string.Equals(existing.Host, domain, StringComparison.OrdinalIgnoreCase))
                {
                    return "Diese Webseite ist bereits freigegeben.";
                }
            }
            if (exemptions.Count >= GamblingHeuristicExemptionCapacity)
            {
                return "Es koennen hoechstens 500 Gluecksspiel-Freigaben gleichzeitig aktiv oder vorgemerkt sein.";
            }

            exemptions.Add(new GamblingHeuristicExemption
            {
                ActivatesAtUtc = nowUtc.AddMinutes(GamblingHeuristicExemptionDelayMinutes),
                Host = domain
            });
            WriteGamblingHeuristicExemptions(exemptions, path);
            WriteActivityLog("Gambling heuristic exemption added (effective in " +
                GamblingHeuristicExemptionDelayMinutes + " minutes).");
            return string.Empty;
        }

        // Zuruecknehmen ist eine Verstaerkung: sofort wirksam, ohne Frist.
        public static void RemoveGamblingHeuristicExemption(string host)
        {
            RemoveGamblingHeuristicExemption(host, GamblingHeuristicExemptionsPath());
        }

        internal static void RemoveGamblingHeuristicExemption(string host, string path)
        {
            string domain = NormalizeDomain(host);
            System.Collections.Generic.List<GamblingHeuristicExemption> kept =
                new System.Collections.Generic.List<GamblingHeuristicExemption>();
            foreach (GamblingHeuristicExemption exemption in ReadGamblingHeuristicExemptions(path))
            {
                if (!string.Equals(exemption.Host, domain, StringComparison.OrdinalIgnoreCase))
                {
                    kept.Add(exemption);
                }
            }
            WriteGamblingHeuristicExemptions(kept, path);
            WriteActivityLog("Gambling heuristic exemption removed.");
        }

        // Steht der Host auf einer der drei Sperrlisten? Eine Freigabe haette
        // fuer ihn keine Wirkung, weil der Companion die Listen zuerst fragt.
        // ReadCustomGamblingDomains allein reicht NICHT: die gepflegte
        // Grundliste und die Offshore-Liste liegen in eigenen Dateien.
        public static bool IsListedGamblingDomain(string host)
        {
            return IsListedGamblingDomain(host, Path.Combine(InstallDir, "rules"));
        }

        internal static bool IsListedGamblingDomain(string host, string rulesDirectory)
        {
            string domain = NormalizeDomain(host);
            if (domain.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
            {
                domain = domain.Substring(4);
            }
            if (!IsValidDomain(domain))
            {
                return false;
            }

            string[] files = { "gambling-domains.txt", "offshore-gambling-domains.txt", "custom-gambling-domains.txt" };
            foreach (string file in files)
            {
                string path = Path.Combine(rulesDirectory, file);
                if (!File.Exists(path))
                {
                    continue;
                }
                foreach (string raw in File.ReadAllLines(path))
                {
                    // GHX-002: Suffix wie im Companion
                    // (gambling-time-content.js:70). Verglich diese Pruefung
                    // exakt, nahm die Oberflaeche eine Freigabe fuer eine
                    // Unterdomain an und meldete Erfolg - gesperrt blieb sie
                    // trotzdem, weil die Durchsetzung ueber das Suffix trifft.
                    string entry = NormalizeDomain(raw);
                    if (entry.Length == 0)
                    {
                        continue;
                    }
                    if (string.Equals(entry, domain, StringComparison.OrdinalIgnoreCase) ||
                        domain.EndsWith("." + entry, StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        // ---- Erwachsenen-Freigaben (gelernte Hosts) --------------------------------

        public const int AdultLearnedExemptionDelayMinutes = 15;
        public const int AdultLearnedExemptionLifetimeDays = 30;
        public const int AdultLearnedExemptionCapacity = 500;

        internal static bool IsAdultLearnedExemptionEffective(
            AdultLearnedExemption exemption, DateTime nowUtc)
        {
            DateTime activatesAtUtc = exemption == null
                ? DateTime.MinValue
                : exemption.ActivatesAtUtc.ToUniversalTime();
            return exemption != null &&
                activatesAtUtc <= nowUtc &&
                activatesAtUtc > nowUtc.AddDays(-AdultLearnedExemptionLifetimeDays);
        }

        public static string AdultLearnedExemptionsPath()
        {
            return Path.Combine(InstallDir, "rules", "adult-learned-exemptions.txt");
        }

        public static string FormatAdultLearnedExemptionLine(AdultLearnedExemption exemption)
        {
            if (exemption == null)
            {
                throw new ArgumentNullException("exemption");
            }

            return exemption.ActivatesAtUtc.ToUniversalTime().ToString("o") + "|" + exemption.Host;
        }

        public static AdultLearnedExemption ParseAdultLearnedExemptionLine(string line)
        {
            string trimmed = (line ?? string.Empty).Trim();
            if (trimmed.Length == 0 || trimmed.StartsWith("#", StringComparison.Ordinal))
            {
                return null;
            }

            string[] parts = trimmed.Split(new[] { '|' }, 2);
            if (parts.Length != 2)
            {
                return null;
            }

            DateTime activatesAt;
            if (!DateTime.TryParse(parts[0].Trim(), null,
                System.Globalization.DateTimeStyles.RoundtripKind, out activatesAt))
            {
                return null;
            }

            string host = NormalizeDomain(parts[1]);
            if (!IsValidDomain(host))
            {
                return null;
            }

            return new AdultLearnedExemption
            {
                ActivatesAtUtc = activatesAt.ToUniversalTime(),
                Host = host
            };
        }

        public static System.Collections.Generic.List<AdultLearnedExemption> ReadAdultLearnedExemptions()
        {
            return ReadAdultLearnedExemptions(AdultLearnedExemptionsPath());
        }

        internal static System.Collections.Generic.List<AdultLearnedExemption> ReadAdultLearnedExemptions(string path)
        {
            System.Collections.Generic.List<AdultLearnedExemption> exemptions =
                new System.Collections.Generic.List<AdultLearnedExemption>();
            if (!File.Exists(path))
            {
                return exemptions;
            }

            System.Collections.Generic.HashSet<string> seen =
                new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string raw in File.ReadAllLines(path))
            {
                AdultLearnedExemption exemption = ParseAdultLearnedExemptionLine(raw);
                if (exemption == null || !seen.Add(exemption.Host))
                {
                    continue;
                }
                exemptions.Add(exemption);
            }

            // Altdateien koennen groesser als der heutige Writer sein. Erst
            // die juengsten Eintraege bestimmen, dann deckeln: sonst koennen
            // 500 abgelaufene Zeilen am Dateianfang eine noch gueltige
            // Freigabe weiter unten verdecken und beim naechsten Schreiben
            // unwiederbringlich entfernen.
            exemptions.Sort((left, right) =>
                right.ActivatesAtUtc.CompareTo(left.ActivatesAtUtc));
            if (exemptions.Count > AdultLearnedExemptionCapacity)
            {
                exemptions.RemoveRange(
                    AdultLearnedExemptionCapacity,
                    exemptions.Count - AdultLearnedExemptionCapacity);
            }
            return exemptions;
        }

        internal static void WriteAdultLearnedExemptions(
            System.Collections.Generic.IEnumerable<AdultLearnedExemption> exemptions, string path)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("# Purestate Erwachsenen-Freigaben (gelernte Hosts)");
            builder.AppendLine("# Format: aktivAbUtc|hostname");
            builder.AppendLine("# Die Freigabe trifft NUR gelernte Hosts. Kuratierte Domains stehen in");
            builder.AppendLine("# eigenen Dateien und werden hier nie angefasst - sonst waere diese Datei");
            builder.AppendLine("# der Generalschluessel fuer den ganzen Schutzbereich.");
            System.Collections.Generic.HashSet<string> seen =
                new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (AdultLearnedExemption exemption in exemptions ?? new AdultLearnedExemption[0])
            {
                if (exemption == null || !IsValidDomain(exemption.Host) || !seen.Add(exemption.Host))
                {
                    continue;
                }
                builder.AppendLine(FormatAdultLearnedExemptionLine(exemption));
                if (seen.Count >= AdultLearnedExemptionCapacity)
                {
                    break;
                }
            }

            string directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }
            File.WriteAllText(path, builder.ToString(), new UTF8Encoding(false));
        }

        // Passwortabfrage liegt im UI-Aufrufer, hier nur die Verzoegerung: eine
        // frische Freigabe darf die laufende Sitzung nicht mehr retten.
        public static string AddAdultLearnedExemption(string host)
        {
            return AddAdultLearnedExemption(host, AdultLearnedExemptionsPath(), TrustedUtcNow());
        }

        internal static string AddAdultLearnedExemption(string host, string path, DateTime nowUtc)
        {
            nowUtc = nowUtc.ToUniversalTime();
            string domain = NormalizeDomain(host);
            if (domain.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
            {
                domain = domain.Substring(4);
            }
            if (!IsValidDomain(domain))
            {
                return "Das ist keine gueltige Webadresse.";
            }

            System.Collections.Generic.List<AdultLearnedExemption> exemptions =
                ReadAdultLearnedExemptions(path);
            exemptions.RemoveAll(existing => existing.ActivatesAtUtc.ToUniversalTime() <=
                nowUtc.AddDays(-AdultLearnedExemptionLifetimeDays));
            foreach (AdultLearnedExemption existing in exemptions)
            {
                if (string.Equals(existing.Host, domain, StringComparison.OrdinalIgnoreCase))
                {
                    return "Diese Webseite ist bereits freigegeben.";
                }
            }
            if (exemptions.Count >= AdultLearnedExemptionCapacity)
            {
                return "Es koennen hoechstens 500 Erwachsenen-Freigaben gleichzeitig aktiv oder vorgemerkt sein.";
            }

            exemptions.Add(new AdultLearnedExemption
            {
                ActivatesAtUtc = nowUtc.AddMinutes(AdultLearnedExemptionDelayMinutes),
                Host = domain
            });
            WriteAdultLearnedExemptions(exemptions, path);
            WriteActivityLog("Adult learned-host exemption added (effective in " +
                AdultLearnedExemptionDelayMinutes + " minutes).");
            return string.Empty;
        }

        // Zuruecknehmen ist eine Verstaerkung: sofort wirksam, ohne Frist.
        public static void RemoveAdultLearnedExemption(string host)
        {
            RemoveAdultLearnedExemption(host, AdultLearnedExemptionsPath());
        }

        internal static void RemoveAdultLearnedExemption(string host, string path)
        {
            string domain = NormalizeDomain(host);
            System.Collections.Generic.List<AdultLearnedExemption> kept =
                new System.Collections.Generic.List<AdultLearnedExemption>();
            foreach (AdultLearnedExemption exemption in ReadAdultLearnedExemptions(path))
            {
                if (!string.Equals(exemption.Host, domain, StringComparison.OrdinalIgnoreCase))
                {
                    kept.Add(exemption);
                }
            }
            WriteAdultLearnedExemptions(kept, path);
            WriteActivityLog("Adult learned-host exemption removed.");
        }

        public static string LearnedAdultDomainsPath()
        {
            return Path.Combine(DataDir, "learned-adult-domains.txt");
        }

        // Fuer die Anzeige im UI: die vom Companion gelernten Hosts aus ProgramData.
        // Kaputte Zeilen fallen einzeln heraus, die restlichen tragen weiter.
        public static System.Collections.Generic.List<string> ReadLearnedAdultDomains()
        {
            return ReadLearnedAdultDomains(LearnedAdultDomainsPath());
        }

        internal static System.Collections.Generic.List<string> ReadLearnedAdultDomains(string path)
        {
            System.Collections.Generic.List<string> hosts = new System.Collections.Generic.List<string>();
            if (!File.Exists(path))
            {
                return hosts;
            }

            foreach (string raw in File.ReadAllLines(path))
            {
                string host = NormalizeDomain(raw);
                if (IsValidDomain(host))
                {
                    hosts.Add(host);
                }
            }
            return hosts;
        }
    }

    // Eine Freigabe fuer die Gluecksspiel-Inhaltserkennung. Nur ueber die App
    // anlegbar (Passwort im UI-Aufrufer), wirksam 15 Minuten spaeter, damit sie
    // die laufende Sitzung nicht mehr retten kann. Wirkt ausschliesslich auf die
    // Heuristikschicht - gelistete Domains bleiben gesperrt, weil der Companion
    // die Listen zuerst fragt.
    internal sealed class GamblingHeuristicExemption
    {
        public DateTime ActivatesAtUtc;
        public string Host = string.Empty;
    }

    // Eine Freigabe fuer einen automatisch gelernten Erwachsenen-Host. Nur ueber
    // die App anlegbar (Passwort im UI-Aufrufer), wirksam 15 Minuten spaeter, damit
    // sie die laufende Sitzung nicht mehr retten kann. Wirkt ausschliesslich auf
    // gelernte Hosts - kuratierte Domains stehen in eigenen Dateien und werden
    // hier nie angefasst.
    internal sealed class AdultLearnedExemption
    {
        public DateTime ActivatesAtUtc;
        public string Host = string.Empty;
    }

    internal sealed class CustomDomainImportResult
    {
        public int Added;
        public int Duplicates;
        public int Invalid;
        public bool Truncated;
        public int Total;
    }
}
