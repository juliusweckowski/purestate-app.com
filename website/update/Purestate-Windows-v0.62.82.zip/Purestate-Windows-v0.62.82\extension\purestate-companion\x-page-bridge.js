"use strict";

const PURESTATE_X_SENSITIVE_IDS_ATTRIBUTE = "data-purestate-x-sensitive-posts";
const PURESTATE_X_SENSITIVE_IDS_EVENT = "purestate-x-sensitive-posts";
const purestateXSensitivePostIds = new Set();

function purestateXBooleanWarning(value) {
  if (!value || typeof value !== "object") {
    return false;
  }
  return Object.values(value).some((item) => item === true);
}

function purestateXNodeIsSensitive(value) {
  return Boolean(value && typeof value === "object" && (
    value.possibly_sensitive === true ||
    value.possiblySensitive === true ||
    purestateXBooleanWarning(value.sensitive_media_warning) ||
    purestateXBooleanWarning(value.sensitiveMediaWarning)
  ));
}

function purestateXNodePostId(value) {
  if (!value || typeof value !== "object") {
    return "";
  }
  const candidates = [
    value.rest_id,
    value.id_str,
    value.legacy && value.legacy.id_str,
    value.tweet && value.tweet.rest_id
  ];
  return String(candidates.find((candidate) => /^\d{5,25}$/.test(String(candidate || ""))) || "");
}

function purestateCollectXSensitiveIds(payload) {
  const result = new Set();
  const seen = new WeakSet();
  const stack = [{ value: payload, parentId: "", depth: 0 }];
  let visited = 0;

  while (stack.length && visited < 50000) {
    const current = stack.pop();
    const value = current.value;
    if (!value || typeof value !== "object" || seen.has(value) || current.depth > 18) {
      continue;
    }
    seen.add(value);
    visited += 1;

    const nodeId = purestateXNodePostId(value) || current.parentId;
    if (nodeId && purestateXNodeIsSensitive(value)) {
      result.add(nodeId);
    }

    for (const child of Array.isArray(value) ? value : Object.values(value)) {
      if (child && typeof child === "object") {
        stack.push({ value: child, parentId: nodeId, depth: current.depth + 1 });
      }
    }
  }
  return Array.from(result);
}

function purestatePublishXSensitiveIds(ids) {
  for (const id of ids) {
    if (/^\d{5,25}$/.test(String(id || ""))) {
      purestateXSensitivePostIds.add(String(id));
    }
  }
  while (purestateXSensitivePostIds.size > 1000) {
    purestateXSensitivePostIds.delete(purestateXSensitivePostIds.values().next().value);
  }
  if (!document.documentElement || !purestateXSensitivePostIds.size) {
    return;
  }
  document.documentElement.setAttribute(
    PURESTATE_X_SENSITIVE_IDS_ATTRIBUTE,
    Array.from(purestateXSensitivePostIds).join(",")
  );
  document.dispatchEvent(new CustomEvent(PURESTATE_X_SENSITIVE_IDS_EVENT));
}

function purestateInspectXPayload(payload) {
  purestatePublishXSensitiveIds(purestateCollectXSensitiveIds(payload));
}

function purestateIsXApiUrl(input) {
  try {
    const url = new URL(String(input || ""), location.href);
    // XBR-001: Das Manifest speist diese Bruecke auf x.com, *.x.com,
    // twitter.com UND *.twitter.com ein - geprueft wurde nur x.com. Auf einem
    // Aufruf, der auf twitter.com bleibt, lieferte sie nie Kennungen:
    // xSensitivePostIds blieb leer und der staerkste Erkennungspfad fiel
    // ersatzlos aus, ohne Fehlermeldung. In der Praxis leitet X twitter.com
    // meist auf x.com um - belegt ist das hier aber nicht, und im Manifest
    // steht die Domain als unterstuetzt.
    return /(^|\.)(?:x|twitter)\.com$/i.test(url.hostname) &&
      /\/i\/api\/(?:graphql\/|2\/search\/adaptive\.json)/i.test(url.pathname);
  } catch {
    return false;
  }
}

function purestateInstallXFetchBridge() {
  if (typeof window.fetch !== "function") {
    return;
  }
  const originalFetch = window.fetch;
  window.fetch = function purestateXFetch() {
    const requestUrl = arguments[0] && arguments[0].url ? arguments[0].url : arguments[0];
    const request = originalFetch.apply(this, arguments);
    if (purestateIsXApiUrl(requestUrl)) {
      request.then((response) => response.clone().json())
        .then(purestateInspectXPayload)
        .catch(() => {});
    }
    return request;
  };
}

function purestateInstallXXhrBridge() {
  if (typeof window.XMLHttpRequest !== "function") {
    return;
  }
  const originalOpen = window.XMLHttpRequest.prototype.open;
  const originalSend = window.XMLHttpRequest.prototype.send;
  window.XMLHttpRequest.prototype.open = function purestateXOpen(method, url) {
    this.__purestateXUrl = String(url || "");
    return originalOpen.apply(this, arguments);
  };
  window.XMLHttpRequest.prototype.send = function purestateXSend() {
    if (purestateIsXApiUrl(this.__purestateXUrl)) {
      this.addEventListener("load", () => {
        try {
          const payload = this.responseType === "json"
            ? this.response
            : JSON.parse(String(this.responseText || ""));
          purestateInspectXPayload(payload);
        } catch {
        }
      }, { once: true });
    }
    return originalSend.apply(this, arguments);
  };
}

purestateInstallXFetchBridge();
purestateInstallXXhrBridge();
