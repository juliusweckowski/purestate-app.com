"use strict";

// Purestate Pinterest companion.
//
// Pinterest prohibits explicit pornography under its own Terms of Service
// (like Instagram/TikTok), so there is no adult-content account toggle to
// enforce. The deterministic protection surface is URL-based.
//
// IMPORTANT host finding (verified live 2026-07-04): pinterest.com REDIRECTS
// to a locale SUBDOMAIN - de.pinterest.com in Germany - and the generic
// search module's old host check (`^pinterest\.[a-z.]+$` after stripping only
// "www.") did NOT match those subdomains, so the search block never ran on
// the German Pinterest. This module matches pinterest.com plus ALL of its
// subdomains, plus the pinterest.<cc> ccTLD domains listed in the manifest.
//
// Covered routes (moved here from the generic search module in 0.61.43 so
// Pinterest participates in the per-site protection switch and fail-closed
// like every other site module):
// - /search/pins, /search/videos, /search/boards, ... with ?q=<term>
// - /ideas/<topic-slug>/<id> topic pages
//
// Scope note: pin detail pages (/pin/<id>) expose no maturity marker in the
// DOM, so a per-item backstop is not possible - mirrors the DeviantArt/
// pixiv/Imgur scope note.

const PINTEREST_INSTANT_STYLE_ID = "purestate-pinterest-instant-style";
const PINTEREST_SEARCH_OVERLAY_ID = "purestate-pinterest-search-overlay";

let pinterestObserver = null;
let pinterestScanTimer = 0;
let lastPinterestLocation = "";

purestateRunWhenSiteProtectionEnabled("pinterest", () => {
  installPinterestInstantHide();
  installPinterestMonitoring();
});

// At document_start: block an adult search/topic URL outright so nothing
// flashes before the overlay is built.
function installPinterestInstantHide() {
  if (!document.documentElement) {
    return;
  }
  if (pinterestAdultSearchTerm()) {
    purestateInstantHide(document, PINTEREST_INSTANT_STYLE_ID);
  }
}

// pinterest.com + all subdomains (www., de., br., ...), and pinterest.<cc>
// ccTLDs (pinterest.de, pinterest.co.uk, ...) + their subdomains.
function isPinterestHost(hostname) {
  const host = String(hostname || "").toLowerCase();
  return /(^|\.)pinterest\.[a-z]{2,3}(\.[a-z]{2})?$/i.test(host);
}

// Extracts the adult term from a Pinterest URL: the ?q= search query (all
// /search verticals) or the /ideas/<topic> path segment. Returns "" when
// none is adult.
function pinterestAdultSearchTerm() {
  return pinterestAdultSearchTermFromUrl(location.href);
}

function pinterestAdultSearchTermFromUrl(urlString) {
  try {
    const url = new URL(urlString);
    if (!isPinterestHost(url.hostname)) {
      return "";
    }
    const path = url.pathname || "/";
    if (/^\/search(?:\/|$)/i.test(path)) {
      const adult = globalThis.purestateAdultSearchParam(url.href, ["q"]);
      if (adult) {
        return adult;
      }
    }
    const topic = path.match(/^\/ideas\/([^/?#]+)/i);
    if (topic) {
      const term = pinterestDecodeTerm(topic[1]);
      if (term && purestateIsAdultSearchText(term)) {
        return term;
      }
    }
  } catch {
  }
  return "";
}

function pinterestDecodeTerm(value) {
  try {
    return decodeURIComponent(String(value || "")).replace(/[-_+]+/g, " ").trim();
  } catch {
    return String(value || "").replace(/[-_+]+/g, " ").trim();
  }
}

// Block an adult route with the shared full-page overlay. Returns true when
// the current URL is blocked.
function applyPinterestSearchBlock() {
  if (pinterestAdultSearchTerm()) {
    purestateInstantHide(document, PINTEREST_INSTANT_STYLE_ID);
    purestateShowSearchOverlay(
      document,
      PINTEREST_SEARCH_OVERLAY_ID,
      "Diese Pinterest-Seite wurde durch Purestate blockiert."
    );
    return true;
  }
  purestateHideSearchOverlay(document, PINTEREST_SEARCH_OVERLAY_ID, PINTEREST_INSTANT_STYLE_ID);
  return false;
}

function installPinterestMonitoring() {
  applyPinterestSearchBlock();
  pinterestObserver = new MutationObserver(() => schedulePinterestScan());
  pinterestObserver.observe(document.documentElement, { childList: true, subtree: true });
  setInterval(() => {
    // Pinterest is a client-routed SPA: catch search/topic navigation that
    // never reloads the page.
    const current = location.href;
    if (current !== lastPinterestLocation) {
      lastPinterestLocation = current;
      applyPinterestSearchBlock();
    }
  }, 500);
}

function schedulePinterestScan() {
  clearTimeout(pinterestScanTimer);
  pinterestScanTimer = setTimeout(() => applyPinterestSearchBlock(), 80);
}
