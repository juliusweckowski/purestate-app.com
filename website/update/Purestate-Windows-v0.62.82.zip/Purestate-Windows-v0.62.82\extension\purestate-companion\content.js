"use strict";

const REDDIT_CHECK = "purestate.checkRedditSubreddit";
const REDDIT_POSTS_CHECK = "purestate.checkRedditPosts";
const OVERLAY_ID = "purestate-companion-overlay";
const POST_BLOCKED_ATTRIBUTE = "data-purestate-post-blocked";
const POST_PLACEHOLDER_ATTRIBUTE = "data-purestate-post-placeholder";
const MEDIA_PENDING_ATTRIBUTE = "data-purestate-media-pending";
const MEDIA_BLOCKED_ATTRIBUTE = "data-purestate-media-blocked";
const MEDIA_PLACEHOLDER_ATTRIBUTE = "data-purestate-media-placeholder";
const MEDIA_STYLE_ID = "purestate-media-shield-style";
const MEDIA_SELECTOR = [
  "img",
  "picture",
  "video",
  "audio",
  "iframe",
  "canvas",
  "object",
  "embed",
  "faceplate-img",
  "shreddit-player",
  "shreddit-embed",
  "shreddit-media-lightbox",
  "shreddit-blurred-container",
  "[data-testid*='thumbnail' i]",
  "[style*='background-image']"
].join(",");
const POST_SELECTOR = [
  "shreddit-post",
  "[data-testid='post-container']",
  ".thing[data-fullname]",
  "article[id^='t3_']",
  "div[id^='t3_']"
].join(",");
const POST_FLAG_SELECTOR = [
  "[is-nsfw]",
  "[nsfw='true']",
  "[data-nsfw='true']",
  "[over18='true']",
  "[over-18='true']",
  "[data-over18='true']",
  "[data-over-18='true']",
  "[data-testid*='nsfw' i]",
  "[aria-label='NSFW' i]",
  "[aria-label='18+']",
  "[slot*='nsfw' i]",
  "faceplate-tracker[noun*='nsfw' i]"
].join(",");
const NSFW_BADGE_SELECTOR = [
  "span",
  "strong",
  "em",
  "a",
  "button",
  "div",
  "faceplate-tooltip",
  "faceplate-partial",
  "faceplate-tracker",
  "shreddit-content-tag",
  "[role='img']",
  "[data-testid*='nsfw' i]",
  "[aria-label*='NSFW' i]",
  "[aria-label*='18+' i]",
  "[aria-label*='nicht jugendfrei' i]",
  "[title*='NSFW' i]",
  "[title*='18+' i]",
  "[class*='nsfw' i]",
  "[class*='over18' i]",
  "[slot*='nsfw' i]",
  "[noun*='nsfw' i]"
].join(",");
const REDDIT_SAFE_SEARCH_CONTROL_SELECTOR = [
  "input[type='radio']",
  "button",
  "[role='radio']",
  "[role='menuitemradio']"
].join(",");
const REDDIT_SAFE_SEARCH_TRIGGER_SELECTOR = [
  "button[aria-haspopup]",
  "[role='button'][aria-haspopup]",
  "button[aria-expanded]",
  "[role='button'][aria-expanded]"
].join(",");
// Modern Reddit renders the Safe Search options as always-present custom
// elements (in the DOM even while the dropdown is closed). value is ON / AUTO /
// OFF; the selected option's <a> contains svg[icon-name="radio-button-fill"].
const REDDIT_SAFE_SEARCH_OPTION_SELECTOR = "safe-search-option-click-handler";
const REDDIT_SAFE_SEARCH_ON_SELECTOR = "safe-search-option-click-handler[value='ON']";
const REDDIT_SAFE_SEARCH_SELECTED_ICON_SELECTOR = "svg[icon-name='radio-button-fill']";
const REDDIT_SAFE_SEARCH_ENABLED_PATTERN = /(?:\baktiviert\b|\benabled\b|\bon\b|alle nicht jugendfreien suchergebnisse[^.]{0,80}ausblenden|hide[^.]{0,120}(?:nsfw|18\+|adult|mature)[^.]{0,120}search)/i;
const REDDIT_SAFE_SEARCH_UNSAFE_PATTERN = /(?:(?:\bautomatisch\b|\bautomatic\b|\bdeaktiviert\b|\bdisabled\b|\boff\b)[\s\S]{0,220}(?:nicht jugendfrei|18\+|nsfw|adult|mature|suchergebnisse|search)|(?:nicht jugendfrei|18\+|nsfw|adult|mature|suchergebnisse|search)[\s\S]{0,220}(?:\bautomatisch\b|\bautomatic\b|\bdeaktiviert\b|\bdisabled\b|\boff\b))/i;
const REDDIT_SAFE_SEARCH_CONTEXT_PATTERN = /(?:sichere suche|safe search|nicht jugendfrei|18\+|nsfw|adult|mature)/i;
const REDDIT_SAFE_SEARCH_TRIGGER_PATTERN = /(?:sichere suche|safe search)/i;
const REDDIT_NSFW_CONTEXT_PATTERN = /(?:^|[^a-z0-9])(?:nsfw|18\+|adult content|mature content|nicht jugendfrei)(?:[^a-z0-9]|$)/i;
const REDDIT_MATURE_MEDIA_BLUR_CONTROL_SELECTOR = [
  "input[type='checkbox']",
  "[role='switch']",
  "button[role='switch']"
].join(",");
const REDDIT_MATURE_MEDIA_BLUR_PATTERN = /(?:(?:18\+|nsfw|adult|mature|nicht jugendfrei)[\s\S]{0,140}(?:verwisch|unkenntlich|unscharf|weichzeichn|blur)|(?:verwisch|unkenntlich|unscharf|weichzeichn|blur)[\s\S]{0,140}(?:18\+|nsfw|adult|mature|nicht jugendfrei))/i;
// Matches the Reddit feed-settings toggle that ENABLES adult/NSFW content in feeds -> keep OFF/unchecked
const REDDIT_ADULT_CONTENT_SHOW_PATTERN = /(?:(?:nsfw|adult content|nicht jugendfrei|18\+|inhalte für erwachsene|erwachseneninhalt)[\s\S]{0,200}(?:aktivier|enabl|anzeig|sehen|view|show|einblend|zulassen|allow|feed|stream)|(?:aktivier|enabl|anzeig|sehen|view|show|einblend|zulassen|allow)[\s\S]{0,200}(?:nsfw|adult content|nicht jugendfrei|18\+|inhalte für erwachsene|erwachseneninhalt))/i;
// Reddit's RPL "18+ Inhalte anzeigen" control is now a faceplate-switch-input.
// Match the tag explicitly too, so a Reddit role/aria reshuffle does not make
// the account-wide adult toggle disappear from enforcement.
const REDDIT_ADULT_TOGGLE_SELECTOR = [
  "faceplate-switch-input",
  "input[type='checkbox']",
  "[role='switch']",
  "button[role='switch']",
  "[aria-checked]"
].join(",");
const REDDIT_SEARCH_OVERLAY_ID = "purestate-reddit-search-overlay";
const REDDIT_INSTANT_STYLE_ID = "purestate-reddit-instant-style";
const REDDIT_BROWSER_RULES_GET = "purestate.getBrowserRules";

let lastCheckedKey = "";
let checkTimer = 0;
let navigationInterval = 0;
let reloadRequested = false;
let postObserver = null;
let postScanTimer = 0;
let redditSafeSearchTimer = 0;
let redditSafeSearchLastClickAt = 0;
let redditAdultToggleLastClickAt = 0;
let redditSafeSearchConfirmedUrl = "";
const processedDataScripts = new WeakSet();
const embeddedNsfwPostIds = new Set();
const embeddedSafePostIds = new Set();
const mediaRootsByPostId = new Map();
const postMetadataStates = new Map();
let redditGamblingEnabled = false;
// RDT-006: Der Wert wurde GENAU EINMAL beim Start geholt. Schlug die Abfrage
// fehl - schlafender Service Worker, lastError, Ausnahme -, blieb er auf false,
// und es gab keinen zweiten Versuch: Gluecksspiel-Suche auf Reddit war fuer die
// Lebensdauer des Tabs offen. Derselbe Zustand entsteht, wenn der Nutzer den
// strikten Gluecksspielschutz NACHTRAEGLICH einschaltet - offene Tabs erfuhren
// es nie. Deshalb wird er nachgeholt, hoechstens einmal je Minute.
let redditGamblingLastQueryAt = 0;
const REDDIT_GAMBLING_REFRESH_MS = 60000;

purestateRunWhenSiteProtectionEnabled("reddit", () => {
  installNavigationHooks();
  installPostMonitoring();
  installRedditSafeSearchGuard();
  requestRedditGamblingArea();
  applyRedditSearchBlock();
  scheduleCheck();
});

// --- Adult search-query block ----------------------------------------------
// Reddit's own Safe Search is forced ON elsewhere; this is an additional hard
// block: an adult search query is replaced with a full-page overlay so no NSFW
// results render at all. Gambling search queries are blocked only while the
// native rule pack reports strict gambling protection as active.

function redditAdultSearchTerm() {
  try {
    const url = new URL(location.href);
    if (!/(^|\.)reddit\.com$/i.test(url.hostname) || !/\/search/i.test(url.pathname)) {
      return "";
    }
    const query = url.searchParams.get("q") || "";
    return query && purestateIsAdultSearchText(query) ? query : "";
  } catch {
    return "";
  }
}

function redditGamblingSearchTerm() {
  if (!redditGamblingEnabled || typeof purestateIsGamblingSearchText !== "function") {
    return "";
  }
  try {
    const url = new URL(location.href);
    if (!/(^|\.)reddit\.com$/i.test(url.hostname) || !/\/search/i.test(url.pathname)) {
      return "";
    }
    const query = url.searchParams.get("q") || "";
    return query && purestateIsGamblingSearchText(query) ? query : "";
  } catch {
    return "";
  }
}

function requestRedditGamblingArea() {
  try {
    redditGamblingLastQueryAt = Date.now();
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return;
    }
    chrome.runtime.sendMessage({ type: REDDIT_BROWSER_RULES_GET, site: "reddit" }, (response) => {
      try {
        if (chrome.runtime.lastError) {
          return;
        }
        const area = response && response.rules && response.rules.areas && response.rules.areas.gambling;
        redditGamblingEnabled = !!(area && area.enabled === true && area.mode === "strict");
        applyRedditSearchBlock();
      } catch {
      }
    });
  } catch {
  }
}

function applyRedditSearchBlock() {
  if (redditAdultSearchTerm()) {
    purestateInstantHide(document, REDDIT_INSTANT_STYLE_ID);
    purestateShowSearchOverlay(
      document,
      REDDIT_SEARCH_OVERLAY_ID,
      "Diese Reddit-Suche wurde durch Purestate blockiert."
    );
    return true;
  }
  if (redditGamblingSearchTerm()) {
    purestateInstantHide(document, REDDIT_INSTANT_STYLE_ID);
    purestateShowSearchOverlay(
      document,
      REDDIT_SEARCH_OVERLAY_ID,
      "Diese Glücksspiel-Suche wurde durch Purestate blockiert."
    );
    return true;
  }
  purestateHideSearchOverlay(document, REDDIT_SEARCH_OVERLAY_ID, REDDIT_INSTANT_STYLE_ID);
  return false;
}

function installNavigationHooks() {
  const originalPushState = history.pushState;
  const originalReplaceState = history.replaceState;

  history.pushState = function pushState() {
    const result = originalPushState.apply(this, arguments);
    scheduleCheck();
    return result;
  };

  history.replaceState = function replaceState() {
    const result = originalReplaceState.apply(this, arguments);
    scheduleCheck();
    return result;
  };

  window.addEventListener("popstate", scheduleCheck);
  window.addEventListener("hashchange", scheduleCheck);
  document.addEventListener("readystatechange", scheduleCheck);
  navigationInterval = setInterval(scheduleCheck, 1200);
}

function scheduleCheck() {
  if (!extensionContextAvailable()) {
    reloadAfterExtensionUpdate();
    return;
  }

  // RDT-006: Nachholen, falls die erste Abfrage scheiterte oder der Schutz
  // seither eingeschaltet wurde. scheduleCheck laeuft ohnehin bei jeder
  // Navigation und jeder Mutation; die Minutenpause haelt daraus eine
  // gelegentliche Frage statt einer Flut.
  if (!redditGamblingEnabled &&
      Date.now() - redditGamblingLastQueryAt >= REDDIT_GAMBLING_REFRESH_MS) {
    requestRedditGamblingArea();
  }

  applyRedditSearchBlock();
  schedulePostScan();

  if (checkTimer) {
    clearTimeout(checkTimer);
  }

  checkTimer = setTimeout(checkCurrentPage, 60);
}

function checkCurrentPage() {
  if (!extensionContextAvailable()) {
    reloadAfterExtensionUpdate();
    return;
  }

  const subreddit = subredditFromLocation(window.location.href);
  if (!subreddit) {
    removeOverlay();
    lastCheckedKey = "";
    return;
  }

  const key = window.location.pathname + "|" + subreddit;
  if (key === lastCheckedKey && document.getElementById(OVERLAY_ID)) {
    return;
  }

  lastCheckedKey = key;
  const pageDecision = detectPageNsfwSignal(subreddit);
  if (pageDecision.blocked) {
    showOverlay(subreddit, pageDecision);
    return;
  }

  try {
    chrome.runtime.sendMessage(
      { type: REDDIT_CHECK, subreddit },
      (decision) => {
        try {
          if (!extensionContextAvailable()) {
            reloadAfterExtensionUpdate();
            return;
          }

          if (chrome.runtime.lastError) {
            return;
          }

          if (decision && decision.blocked) {
            showOverlay(subreddit, decision);
          } else {
            const latestPageDecision = detectPageNsfwSignal(subreddit);
            if (latestPageDecision.blocked) {
              showOverlay(subreddit, latestPageDecision);
            } else {
              removeOverlay();
            }
          }
        } catch {
          reloadAfterExtensionUpdate();
        }
      }
    );
  } catch {
    reloadAfterExtensionUpdate();
  }
}

function extensionContextAvailable() {
  try {
    return typeof chrome !== "undefined" && Boolean(chrome.runtime && chrome.runtime.id);
  } catch {
    return false;
  }
}

function reloadAfterExtensionUpdate() {
  if (reloadRequested) {
    return;
  }

  reloadRequested = true;

  if (checkTimer) {
    clearTimeout(checkTimer);
    checkTimer = 0;
  }

  if (navigationInterval) {
    clearInterval(navigationInterval);
    navigationInterval = 0;
  }

  if (postScanTimer) {
    clearTimeout(postScanTimer);
    postScanTimer = 0;
  }

  if (postObserver) {
    postObserver.disconnect();
    postObserver = null;
  }

  try {
    window.location.reload();
  } catch {
    try {
      window.location.href = window.location.href;
    } catch {
      // The tab can still be reloaded manually if Chrome is already closing it.
    }
  }
}

function installRedditSafeSearchGuard() {
  document.addEventListener("pointerdown", guardRedditSafeSearchClick, true);
  document.addEventListener("click", guardRedditSafeSearchClick, true);
  document.addEventListener("change", guardRedditSafeSearchClick, true);
  document.addEventListener("keydown", (event) => {
    if (!event || (event.key !== " " && event.key !== "Enter")) {
      return;
    }
    guardRedditSafeSearchClick(event);
  }, true);
  scheduleRedditSafeSearchEnforcement();
  setInterval(scheduleRedditSafeSearchEnforcement, 1500);
}

function scheduleRedditSafeSearchEnforcement() {
  if (redditSafeSearchTimer) {
    return;
  }
  redditSafeSearchTimer = setTimeout(() => {
    redditSafeSearchTimer = 0;
    enforceRedditSafeSearch(document);
  }, 120);
}

// Reddit's Safe-Search and mature-content toggles only exist on the search
// results and settings/preferences pages. The media blur/scan still runs
// everywhere else; this just keeps the extra safe-search DOM queries (fired on
// every scan and on a 1.5s interval) off the busy feed and post pages, which is
// where the constant per-scan cost was showing up.
function isRedditSafeSearchRelevantPage() {
  const path = String(location.pathname || "").toLowerCase();
  return path.indexOf("/search") !== -1 ||
    path.indexOf("/settings") !== -1 ||
    path.indexOf("/prefs") !== -1;
}

function enforceRedditSafeSearch(root) {
  if (!root || !root.querySelectorAll) {
    return;
  }

  if (!isRedditSafeSearchRelevantPage()) {
    return;
  }

  const pageUrl = String(location.href || "");

  // Modern Reddit: re-select the always-present "Aktiviert" (value=ON) option
  // directly. No need to open the dropdown, which previously caused the trigger
  // to flap because the enabled control was never found.
  const modernOptions = root.querySelectorAll(REDDIT_SAFE_SEARCH_OPTION_SELECTOR);
  if (modernOptions.length) {
    if (redditSafeSearchSelectedValue(root) === "ON") {
      redditSafeSearchConfirmedUrl = pageUrl;
    } else if (Date.now() - redditSafeSearchLastClickAt >= 900) {
      const onOption = root.querySelector(REDDIT_SAFE_SEARCH_ON_SELECTOR);
      const link = onOption && (onOption.querySelector("a") || onOption);
      if (link) {
        redditSafeSearchLastClickAt = Date.now();
        redditSafeSearchConfirmedUrl = pageUrl;
        try {
          link.click();
        } catch {
        }
      }
    }
  } else {
    enforceLegacyRedditSafeSearch(root, pageUrl);
  }

  // Keep "18+ Inhalte verwischen" / mature-media blur ON (settings page).
  const blurControl = redditMatureMediaBlurControl(root);
  if (blurControl && !redditControlChecked(blurControl) && Date.now() - redditSafeSearchLastClickAt >= 900) {
    redditSafeSearchLastClickAt = Date.now();
    setRedditControlChecked(blurControl);
    try {
      blurControl.click();
    } catch {
    }
  }

  // Adult content "show in feed / ich bin über 18" toggle should stay OFF.
  const adultContentShowControl = redditAdultContentShowControl(root);
  if (adultContentShowControl) {
    if (redditControlChecked(adultContentShowControl) && Date.now() - redditAdultToggleLastClickAt >= 900) {
      redditAdultToggleLastClickAt = Date.now();
      forceRedditSwitchOff(adultContentShowControl);
    } else if (!redditControlChecked(adultContentShowControl)) {
      // Already OFF/safe: make it un-clickable so it cannot be turned back on.
      // Only locked in the safe state, so a failed flip never traps it ON.
      lockRedditToggle(adultContentShowControl);
    }
  }
}

// Turns a Reddit ON switch OFF, honoring the control's real activation model.
// A plain .click() does not flip Reddit's newer <faceplate-switch-input>
// (the "Nicht jugendfreie Inhalte anzeigen (ich bin über 18)" account toggle),
// which toggles on a pointer gesture rather than a synthetic click event. We
// therefore branch by control type and emit exactly ONE logical activation, so
// a control that honors more than one of these never double-toggles back ON.
function forceRedditSwitchOff(control) {
  if (!control) {
    return;
  }
  // Native checkbox: set the property and fire input/change so React/controlled
  // components observe the new state. A single deterministic write, no toggle.
  if (control.tagName === "INPUT" && typeof control.checked === "boolean") {
    if (control.checked) {
      control.checked = false;
      try { control.dispatchEvent(new Event("input", { bubbles: true })); } catch {}
      try { control.dispatchEvent(new Event("change", { bubbles: true })); } catch {}
    }
    return;
  }

  // faceplate-switch-input (live-confirmed: a lit web component with an inner
  // shadow <span class="outer"><span class="knob"> and NO .checked property) and
  // every other role=switch / button toggle its state on a real `click`, not on
  // raw pointer events. A single .click() is the canonical, single activation -
  // it flips exactly once. (The earlier pointer-only attempt did nothing because
  // the component ignores pointerup.)
  try {
    control.click();
  } catch {
  }
}

// Locks a Reddit toggle (and its wrapping <label>, e.g. the RPL
// data-testid="is-nsfw-shown" switch) un-clickable. pointer-events:none does
// not block our own programmatic .click(), so enforcement still works.
function lockRedditToggle(control) {
  const label = control && control.closest ? control.closest("label") : null;
  for (const node of [control, label]) {
    if (node && node.style && node.style.setProperty) {
      node.style.setProperty("pointer-events", "none", "important");
      node.style.setProperty("cursor", "not-allowed", "important");
    }
  }
}

// Reads the currently selected Safe Search value (ON/AUTO/OFF) from the modern
// custom-element options by locating the filled radio icon.
function redditSafeSearchSelectedValue(root) {
  for (const handler of root.querySelectorAll(REDDIT_SAFE_SEARCH_OPTION_SELECTOR)) {
    if (handler.querySelector(REDDIT_SAFE_SEARCH_SELECTED_ICON_SELECTOR)) {
      return String(handler.getAttribute("value") || "").toUpperCase();
    }
  }
  return "";
}

// Legacy Reddit builds: Safe Search as radio/menuitemradio behind a dropdown
// that must be opened first.
function enforceLegacyRedditSafeSearch(root, pageUrl) {
  const safeSearchEnabled = redditSafeSearchEnabledControl(root);
  if (safeSearchEnabled && redditControlChecked(safeSearchEnabled)) {
    redditSafeSearchConfirmedUrl = pageUrl;
  }
  if (safeSearchEnabled && !redditControlChecked(safeSearchEnabled) && Date.now() - redditSafeSearchLastClickAt >= 900) {
    redditSafeSearchLastClickAt = Date.now();
    setRedditControlChecked(safeSearchEnabled);
    redditSafeSearchConfirmedUrl = pageUrl;
    try {
      safeSearchEnabled.click();
    } catch {
    }
    return;
  }
  if (!safeSearchEnabled && redditSafeSearchConfirmedUrl !== pageUrl) {
    const trigger = redditSafeSearchMenuTrigger(root);
    if (trigger && Date.now() - redditSafeSearchLastClickAt >= 1200) {
      redditSafeSearchLastClickAt = Date.now();
      try {
        trigger.click();
      } catch {
      }
      scheduleRedditSafeSearchEnforcement();
    }
  }
}

function redditSafeSearchEnabledControl(root) {
  for (const control of root.querySelectorAll(REDDIT_SAFE_SEARCH_CONTROL_SELECTOR)) {
    const text = redditSafeSearchOptionText(control);
    if (REDDIT_SAFE_SEARCH_ENABLED_PATTERN.test(text) && REDDIT_SAFE_SEARCH_CONTEXT_PATTERN.test(text)) {
      return control;
    }
  }
  return null;
}

function redditSafeSearchMenuTrigger(root) {
  for (const trigger of root.querySelectorAll(REDDIT_SAFE_SEARCH_TRIGGER_SELECTOR)) {
    const text = redditSafeSearchOptionText(trigger);
    if (REDDIT_SAFE_SEARCH_TRIGGER_PATTERN.test(text)) {
      return trigger;
    }
  }
  return null;
}

function redditMatureMediaBlurControl(root) {
  for (const control of root.querySelectorAll(REDDIT_MATURE_MEDIA_BLUR_CONTROL_SELECTOR)) {
    const text = redditSafeSearchOptionText(control);
    if (REDDIT_MATURE_MEDIA_BLUR_PATTERN.test(text)) {
      return control;
    }
  }
  return null;
}

// Collects elements matching `selector` across the light DOM AND any OPEN
// shadow roots. Reddit's account settings render their toggles (including the
// "Nicht jugendfreie Inhalte anzeigen (ich bin über 18)" faceplate-switch-input)
// inside shadow roots, which a plain document.querySelectorAll cannot reach -
// live-confirmed 2026-07: querySelectorAll('[role=switch]') returned 0 on the
// settings page while the switch was visibly present. Same recursion the
// DeviantArt/pixiv reveal-guards use. The full-tree "*" walk is only cheap
// enough for the settings surface, so callers gate it by path.
function redditQueryAllDeep(selector, root, out, seenRoots) {
  root = root || document;
  out = out || [];
  seenRoots = seenRoots || new Set();
  try {
    for (const el of root.querySelectorAll(selector)) {
      out.push(el);
    }
  } catch {
  }
  let all;
  try {
    all = root.querySelectorAll("*");
  } catch {
    all = [];
  }
  for (const el of all) {
    const shadow = el.shadowRoot;
    if (shadow && !seenRoots.has(shadow)) {
      seenRoots.add(shadow);
      redditQueryAllDeep(selector, shadow, out, seenRoots);
    }
  }
  return out;
}

function redditOnSettingsPage() {
  return /\/settings(?:\/|$)/i.test(String(location.pathname || ""));
}

function redditAdultToggleControls(root) {
  const base = root || document;
  const shallow = Array.from(base.querySelectorAll(REDDIT_ADULT_TOGGLE_SELECTOR));
  // The account toggle lives inside a shadow root on the settings surface;
  // only there do we pay for the deep walk.
  if (redditOnSettingsPage()) {
    return shallow.concat(redditQueryAllDeep(REDDIT_ADULT_TOGGLE_SELECTOR, base));
  }
  return shallow;
}

function redditAdultContentShowControl(root) {
  for (const control of redditAdultToggleControls(root)) {
    const text = redditSafeSearchOptionText(control);
    if (REDDIT_ADULT_CONTENT_SHOW_PATTERN.test(text) && !REDDIT_MATURE_MEDIA_BLUR_PATTERN.test(text)) {
      return control;
    }
  }
  return null;
}

function guardRedditSafeSearchClick(event) {
  // Only block genuine user gestures. Our own enforcement dispatches synthetic
  // clicks (isTrusted === false); guarding those would cancel our own attempts
  // to flip a control back to the safe state.
  if (event && event.isTrusted === false) {
    return;
  }

  const target = event && event.target;
  if (!target || !target.closest) {
    return;
  }

  const unsafeControl = redditUnsafeSafeSearchControl(target) || redditMatureMediaBlurDisableControl(target) || redditAdultContentShowAttempt(target);
  if (!unsafeControl) {
    return;
  }

  event.preventDefault();
  event.stopPropagation();
  if (event.stopImmediatePropagation) {
    event.stopImmediatePropagation();
  }
  scheduleRedditSafeSearchEnforcement();
}

function redditUnsafeSafeSearchControl(target) {
  // Modern Reddit safe-search options: block selecting Automatisch/Deaktiviert,
  // allow Aktiviert. The enforcement loop re-selects ON afterwards.
  const handler = target.closest && target.closest(REDDIT_SAFE_SEARCH_OPTION_SELECTOR);
  if (handler) {
    const value = String(handler.getAttribute("value") || "").toUpperCase();
    return (value === "AUTO" || value === "OFF") ? handler : null;
  }

  const candidates = [];
  const control = target.closest(REDDIT_SAFE_SEARCH_CONTROL_SELECTOR);
  if (control) {
    candidates.push(control);
  }

  const row = target.closest("label,[role='radio'],[role='menuitemradio']");
  if (row && row !== control) {
    candidates.push(row);
  }

  for (const candidate of candidates) {
    const text = redditSafeSearchOptionText(candidate);
    if (REDDIT_SAFE_SEARCH_UNSAFE_PATTERN.test(text) && REDDIT_SAFE_SEARCH_CONTEXT_PATTERN.test(text)) {
      return candidate;
    }
  }
  return null;
}

function redditMatureMediaBlurDisableControl(target) {
  const candidates = [];
  const control = target.closest(REDDIT_MATURE_MEDIA_BLUR_CONTROL_SELECTOR);
  if (control) {
    candidates.push(control);
  }

  const row = target.closest("label,[role='switch']");
  if (row && row !== control) {
    candidates.push(row);
  }

  for (const candidate of candidates) {
    const text = redditSafeSearchOptionText(candidate);
    if (REDDIT_MATURE_MEDIA_BLUR_PATTERN.test(text)) {
      const toggle = candidate.matches && candidate.matches(REDDIT_MATURE_MEDIA_BLUR_CONTROL_SELECTOR)
        ? candidate
        : (candidate.querySelector ? candidate.querySelector(REDDIT_MATURE_MEDIA_BLUR_CONTROL_SELECTOR) : null);
      if (toggle) {
        setRedditControlChecked(toggle);
      }
      return candidate;
    }
  }
  return null;
}

function redditAdultContentShowAttempt(target) {
  const candidates = [];
  const control = target.closest(REDDIT_ADULT_TOGGLE_SELECTOR);
  if (control) {
    candidates.push(control);
  }

  const row = target.closest("label,[role='switch'],[role='menuitem'],[role='menuitemcheckbox'],li");
  if (row && row !== control) {
    candidates.push(row);
  }

  for (const candidate of candidates) {
    const text = redditSafeSearchOptionText(candidate);
    if (REDDIT_ADULT_CONTENT_SHOW_PATTERN.test(text) && !REDDIT_MATURE_MEDIA_BLUR_PATTERN.test(text)) {
      return candidate;
    }
  }
  return null;
}

function redditSafeSearchOptionText(control) {
  const values = [];
  let node = control;
  for (let depth = 0; node && depth < 5; depth += 1, node = node.parentElement) {
    values.push(
      String(node.getAttribute && node.getAttribute("aria-label") || ""),
      String(node.getAttribute && node.getAttribute("title") || ""),
      String(node.textContent || "")
    );
    const text = values.join(" ").replace(/\s+/g, " ").trim();
    if (text.length > 420 || REDDIT_SAFE_SEARCH_CONTEXT_PATTERN.test(text)) {
      break;
    }
  }
  return values.join(" ").replace(/\s+/g, " ").trim();
}

function redditControlChecked(control) {
  if (typeof control.checked === "boolean") {
    return control.checked;
  }
  const ariaChecked = String(control.getAttribute && control.getAttribute("aria-checked") || "").toLowerCase();
  if (ariaChecked === "true" || ariaChecked === "false") {
    return ariaChecked === "true";
  }
  const checkedAttr = control.getAttribute && control.getAttribute("checked");
  if (checkedAttr != null && (checkedAttr === "" || String(checkedAttr).toLowerCase() === "true" || String(checkedAttr).toLowerCase() === "checked")) {
    return true;
  }
  // RPL switch fallback: the knob renders a checkmark icon only when the toggle is on.
  if (control.querySelector && control.querySelector(".knob svg[icon-name='checkmark-12'], svg[icon-name='checkmark-12']")) {
    return true;
  }
  if (control.shadowRoot && control.shadowRoot.querySelector
    && control.shadowRoot.querySelector(".knob svg[icon-name='checkmark-12'], svg[icon-name='checkmark-12']")) {
    return true;
  }
  return false;
}

function setRedditControlChecked(control) {
  if (typeof control.checked === "boolean") {
    control.checked = true;
  }
  control.setAttribute("aria-checked", "true");
}

function installPostMonitoring() {
  if (postObserver || !extensionContextAvailable()) {
    return;
  }

  if (!document.documentElement) {
    document.addEventListener("readystatechange", installPostMonitoring, { once: true });
    return;
  }

  installMediaShieldStyle();

  postObserver = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type === "attributes" && mutation.target && mutation.target.nodeType === 1) {
        scanNsfwPosts(mutation.target);
      }

      for (const node of mutation.addedNodes || []) {
        if (node && node.nodeType === 1) {
          scanNsfwPosts(node);
        }
      }
    }

    schedulePostScan();
  });
  postObserver.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: [
      "class",
      "is-nsfw",
      "nsfw",
      "data-nsfw",
      "over18",
      "over-18",
      "data-over18",
      "data-over-18",
      "src",
      "data-src",
      "style",
      "aria-label",
      "title",
      "data-testid"
    ]
  });

  schedulePostScan();
}

function schedulePostScan() {
  if (!extensionContextAvailable() || postScanTimer) {
    return;
  }

  postScanTimer = setTimeout(() => {
    postScanTimer = 0;
    scanNsfwPosts(document);
    scheduleRedditSafeSearchEnforcement();
  }, 80);
}

function scanNsfwPosts(root) {
  updateEmbeddedNsfwPostIds();
  scanNsfwBadgeCards(root);
  scanNsfwMediaCards(root);

  const candidates = [];
  if (root && root.nodeType === 1 && root.matches && root.matches(POST_SELECTOR)) {
    candidates.push(root);
  }

  if (root && root.querySelectorAll) {
    for (const post of root.querySelectorAll(POST_SELECTOR)) {
      candidates.push(post);
    }
  }

  for (const post of candidates) {
    if (post.closest && post.closest("[" + MEDIA_BLOCKED_ATTRIBUTE + "='true']")) {
      continue;
    }

    if (post.parentElement && post.parentElement.closest("[" + POST_BLOCKED_ATTRIBUTE + "='true']")) {
      continue;
    }

    if (postLooksNsfw(post)) {
      blockNsfwPost(post);
    }
  }

  scanMediaPreviews(root);
}

function scanNsfwBadgeCards(root) {
  if (!root || !root.querySelectorAll) {
    return;
  }

  const badges = exactNsfwBadgesWithin(root);

  for (const badge of badges) {
    if (badge.closest && badge.closest("[" + POST_BLOCKED_ATTRIBUTE + "='true'],[" + MEDIA_BLOCKED_ATTRIBUTE + "='true']")) {
      continue;
    }

    const standardPost = badge.closest ? badge.closest(POST_SELECTOR) : null;
    if (standardPost) {
      blockNsfwPost(standardPost);
      continue;
    }

    const card = nsfwCardForBadge(badge);
    if (card) {
      blockNsfwMediaItems(card, true);
    }
  }
}

function isExactNsfwBadge(element) {
  const markerAttributes = ["aria-label", "title", "class", "slot", "noun", "data-testid"];
  for (const name of markerAttributes) {
    const value = String(element.getAttribute && element.getAttribute(name) || "");
    if (value.length <= 120 && REDDIT_NSFW_CONTEXT_PATTERN.test(value)) {
      return true;
    }
  }

  const text = (
    String(element.getAttribute && element.getAttribute("aria-label") || "") + " " +
    String(element.getAttribute && element.getAttribute("title") || "") + " " +
    String(element.textContent || "")
  ).replace(/\s+/g, " ").trim();
  const compact = text.toLowerCase().replace(/[^a-z0-9+]+/g, "");
  // RDT-004: Hier folgte frueher noch
  //   return text.length <= 120 && REDDIT_NSFW_CONTEXT_PATTERN.test(text);
  // - also "irgendwo in hoechstens 120 Zeichen steht nsfw/18+/adult". Ein
  // Treffer sperrte ueber scanNsfwBadgeCards den GANZEN Beitrag. Damit
  // verschwand ein Titel wie "30 Tage NSFW-frei" oder "Wie sage ich meiner
  // Partnerin, dass ich NSFW-Inhalte meide" hinter "18+ Beitrag blockiert" -
  // in einem Forum, das der Nutzer zur Unterstuetzung besucht. Ueber-Sperrung,
  // keine Luecke, aber sie zerstoert genau das Vertrauen, das die Erweiterung
  // braucht.
  //
  // Im Medienpfad war derselbe Fehlalarm laengst behoben (nsfwCardForBadge
  // verlangt badgeCount === 1). Die Korrektur sass dort, wo er auffiel, nicht
  // an der gemeinsamen Pruefung. Jetzt hier: nur noch die STRENGE Form -
  // exakter Text oder Markerattribut. Die lockere Textpruefung bleibt in
  // redditNodeHasNsfwContext, wo sie als ZWEITsignal dient und nicht allein
  // sperrt. Die harten Signale (is-nsfw, over18, shreddit-content-tag,
  // eingebettete Bewertung, Metadatenabfrage) sind unberuehrt.
  return /^(?:nsfw|18\+|adultcontent|maturecontent)$/.test(compact);
}

// RDT-005: Sechs Deckel im Scan brachen still ab - kein Log, kein Merker, kein
// Canary. Wer die Grenze ueberschreitet, bekommt eine unvollstaendige Pruefung,
// die von aussen wie eine vollstaendige aussieht. Ein Reddit-Feed mit
// unendlichem Scrollen ueberschreitet 15.000 Elemente nach wenigen
// Bildschirmseiten; ab dort findet der Abzeichenpfad nichts mehr. Die Deckel
// selbst sind fachlich richtig - falsch war nur, dass niemand davon erfaehrt.
//
// Der Befund schlaegt purestateCanaryReport("reddit", "scan-truncated") vor.
// Das waere FALSCH, aus zwei Gruenden: der Canary ist kein Diagnosekanal,
// sondern ein Sperrmechanismus (ein angenommener Bericht sperrt die zugehoerige
// Domain 24 Stunden lang), und "reddit" steht gar nicht in seiner
// Zuordnungstabelle - der Guard wiese die Meldung als unknown-site ab. Eine
// abgewiesene Meldung waere schlimmer als keine, eine ANGENOMMENE waere ein
// Totalausfall von reddit.com wegen eines gedeckelten Scans.
//
// Eine gekappte Pruefung ist eine Beobachtung, kein Erkennungsausfall. Sie
// gehoert in die Konsole des Tabs, einmal je Seitenaufruf und Deckel.
const redditReportedCaps = new Set();

function redditScanTruncated(welcherDeckel, grenze) {
  if (redditReportedCaps.has(welcherDeckel)) {
    return;
  }
  redditReportedCaps.add(welcherDeckel);
  try {
    console.warn("[purestate] Reddit-Scan gekappt: " + welcherDeckel +
      " hat die Grenze von " + grenze + " erreicht. Beitraege darueber hinaus sind nur noch " +
      "ueber ihre Attribute und die Metadatenabfrage gedeckt.");
  } catch {
  }
}

function nsfwCardForBadge(badge) {
  let node = badge.parentElement;

  for (let depth = 0; node && depth < 40; depth += 1, node = node.parentElement) {
    if (node.matches && node.matches("main, body")) {
      break;
    }

    const postIds = postIdsWithin(node, 2);
    const badgeCount = exactNsfwBadgeCount(node, 2);
    if (postIds.size > 1 || badgeCount > 1) {
      break;
    }

    if ((badgeCount === 1 || redditNodeHasNsfwContext(node)) && node.querySelector && node.querySelector(MEDIA_SELECTOR)) {
      return node;
    }
  }

  return null;
}

function exactNsfwBadgeCount(root, stopAfter) {
  return Math.min(exactNsfwBadgesWithin(root).length, stopAfter);
}

function exactNsfwBadgesWithin(root) {
  const badges = [];
  const candidates = [];
  if (root.matches && root.matches(NSFW_BADGE_SELECTOR) && isExactNsfwBadge(root)) {
    candidates.push(root);
  }
  let inspected = 0;
  for (const element of root.querySelectorAll(NSFW_BADGE_SELECTOR)) {
    inspected += 1;
    if (inspected > 15000) {
      redditScanTruncated("Abzeichen-Suche im Feed", 15000);
      break;
    }
    if (isExactNsfwBadge(element)) {
      candidates.push(element);
    }
  }

  for (const candidate of candidates) {
    if (badges.some((existing) => existing.contains(candidate) || candidate.contains(existing))) {
      continue;
    }
    badges.push(candidate);
  }
  return badges;
}

function scanNsfwMediaCards(root) {
  if (!root || !root.querySelectorAll) {
    return;
  }

  const media = [];
  if (root.matches && root.matches(MEDIA_SELECTOR)) {
    media.push(root);
  }
  for (const item of root.querySelectorAll(MEDIA_SELECTOR)) {
    media.push(item);
    if (media.length >= 600) {
      redditScanTruncated("Medien je Beitrag", 600);
      break;
    }
  }

  for (const item of media) {
    if (item.closest && item.closest("[" + POST_BLOCKED_ATTRIBUTE + "='true'],[" + MEDIA_BLOCKED_ATTRIBUTE + "='true']")) {
      continue;
    }

    const card = nsfwCardForMedia(item);
    if (card) {
      blockNsfwMedia(item, true, false);
    }
  }
}

function nsfwCardForMedia(media) {
  let node = media.parentElement;

  for (let depth = 0; node && depth < 40; depth += 1, node = node.parentElement) {
    if (node.matches && node.matches("main, body")) {
      break;
    }

    const badgeCount = exactNsfwBadgeCount(node, 2);
    if (badgeCount > 1) {
      break;
    }

    const postIds = postIdsWithin(node, 2);
    if (postIds.size > 1) {
      break;
    }

    // Media is auto-blocked only when the card carries an exact NSFW badge, not
    // on a free-text mention of "nsfw"/"18+"/"adult" anywhere in the ancestor
    // chain: a safe post whose title or comments merely name those words was
    // getting its images blocked. Real NSFW posts are still caught by their
    // nsfw/over18 attributes, an exact badge, and the post-metadata lookup.
    if (badgeCount === 1) {
      return node;
    }
  }

  return null;
}

function redditNodeHasNsfwContext(node) {
  if (!node || !node.textContent) {
    return false;
  }

  const text = String(node.textContent || "").replace(/\s+/g, " ").trim();
  return text.length > 0 && text.length <= 4500 && REDDIT_NSFW_CONTEXT_PATTERN.test(text);
}

function blockNsfwMediaItems(root, confirmedNsfw) {
  if (!root) {
    return;
  }

  const media = [];
  if (root.matches && root.matches(MEDIA_SELECTOR)) {
    media.push(root);
  }
  if (root.querySelectorAll) {
    for (const item of root.querySelectorAll(MEDIA_SELECTOR)) {
      media.push(item);
    }
  }

  for (const item of media) {
    if (item.closest && item.closest("[" + MEDIA_BLOCKED_ATTRIBUTE + "='true']")) {
      continue;
    }
    blockNsfwMedia(item, confirmedNsfw, false);
  }
}

function postIdsWithin(root, stopAfter) {
  const postIds = new Set();
  if (!root || !root.querySelectorAll) {
    return postIds;
  }

  for (const link of root.querySelectorAll("a[href*='/comments/']")) {
    const postId = postIdFromLink(link);
    if (postId) {
      postIds.add(postId);
      if (postIds.size >= stopAfter) {
        break;
      }
    }
  }
  return postIds;
}

function postLooksNsfw(post) {
  if (!post || !post.getAttribute || post.getAttribute(POST_BLOCKED_ATTRIBUTE) === "true") {
    return false;
  }

  if (elementHasTrueFlag(post, [
    "is-nsfw",
    "nsfw",
    "data-nsfw",
    "over18",
    "over-18",
    "data-over18",
    "data-over-18"
  ])) {
    return true;
  }

  const classes = post.classList;
  if (classes && (classes.contains("over18") || classes.contains("nsfw"))) {
    return true;
  }

  const postId = postIdentity(post);
  if (postId && embeddedNsfwPostIds.has(postId)) {
    return true;
  }

  if (post.querySelector && post.querySelector(POST_FLAG_SELECTOR)) {
    return true;
  }

  if (post.querySelectorAll) {
    const labels = post.querySelectorAll("span, strong, faceplate-tooltip");
    const limit = Math.min(labels.length, 250);
    if (labels.length > 250) { redditScanTruncated("Beschriftungen im Beitrag", 250); }
    for (let index = 0; index < limit; index += 1) {
      const text = String(labels[index].textContent || "").trim();
      if (/^(?:nsfw|18\+|adult content|mature content)$/i.test(text)) {
        return true;
      }
    }
  }

  return false;
}

function elementHasTrueFlag(element, names) {
  for (const name of names) {
    if (!element.hasAttribute(name)) {
      continue;
    }

    const value = String(element.getAttribute(name) || "").trim().toLowerCase();
    if (value === "" || value === "true" || value === "1" || value === "yes") {
      return true;
    }
  }

  return false;
}

function postIdentity(post) {
  const attributes = ["id", "post-id", "postid", "data-post-id", "thing-id", "data-fullname"];
  for (const name of attributes) {
    const normalized = normalizePostId(post.getAttribute(name));
    if (normalized) {
      return normalized;
    }
  }

  if (post.querySelector) {
    const link = post.querySelector("a[href*='/comments/']");
    if (link) {
      const match = String(link.getAttribute("href") || "").match(/\/comments\/([a-z0-9]+)(?:[/?#]|$)/i);
      if (match) {
        return normalizePostId(match[1]);
      }
    }
  }

  return "";
}

function normalizePostId(input) {
  let value = String(input || "").trim().toLowerCase();
  value = value.replace(/^t3_/, "");
  return /^[a-z0-9]{3,16}$/.test(value) ? value : "";
}

function updateEmbeddedNsfwPostIds() {
  const scripts = document.querySelectorAll("script[type='application/json'], script#data");
  for (const script of scripts) {
    if (processedDataScripts.has(script)) {
      continue;
    }

    const text = script.textContent || "";
    if (!text || text.length > 5000000) {
      continue;
    }

    processedDataScripts.add(script);
    try {
      collectEmbeddedPostIds(JSON.parse(text), embeddedNsfwPostIds, embeddedSafePostIds);
    } catch {
      // Some Reddit data scripts are not plain JSON.
    }
  }
}

// RDT-007: Hier stand collectNsfwPostIds - eine Huelle um
// collectEmbeddedPostIds, im ganzen Repository ohne einen einzigen Aufrufer.
// Zur Laufzeit kostete sie nichts; die Gefahr ist, dass jemand sie fuer einen
// zweiten Erkennungspfad haelt.

// RDT-008: Die Reddit-Einblendungen holen Farben und Schrift aus dem
// Vorhang-Baukasten (adult-search-terms.js) und folgen damit dem Dunkelmodus
// wie alle Vorhaenge: die Sperre soll beruhigen, nicht blenden.

function collectEmbeddedPostIds(root, blockedResult, safeResult) {
  const pending = [root];
  let inspected = 0;

  while (pending.length && inspected < 200000) {
    if (inspected + 1 >= 200000) { redditScanTruncated("JSON-Knoten (Beitragsdaten)", 200000); }
    const value = pending.pop();
    inspected += 1;

    if (!value || typeof value !== "object") {
      continue;
    }

    const flagNames = ["over_18", "over18", "isNsfw", "nsfw"];
    const hasFlag = flagNames.some((name) => Object.prototype.hasOwnProperty.call(value, name));
    const flagged = isTrue(value.over_18) || isTrue(value.over18) || isTrue(value.isNsfw) || isTrue(value.nsfw);
    if (hasFlag) {
      const identifiers = [value.id, value.name, value.postId, value.post_id];
      for (const identifier of identifiers) {
        const postId = normalizePostId(identifier);
        if (postId) {
          if (flagged) {
            blockedResult.add(postId);
            safeResult.delete(postId);
          } else if (!blockedResult.has(postId)) {
            safeResult.add(postId);
          }
        }
      }
    }

    for (const child of Object.values(value)) {
      if (child && typeof child === "object") {
        pending.push(child);
      }
    }
  }
}

function installMediaShieldStyle() {
  purestateInjectStyle(
    document,
    MEDIA_STYLE_ID,
    [
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] img,",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] picture,",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] video,",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] audio,",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] iframe,",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] canvas,",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] object,",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] embed,",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] faceplate-img,",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] shreddit-player,",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] shreddit-embed,",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] shreddit-media-lightbox,",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] shreddit-blurred-container,",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] [data-testid*='thumbnail' i],",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'] [style*='background-image'] {",
      "  visibility: hidden !important;",
      "  opacity: 0 !important;",
      "}",
      "[" + MEDIA_PENDING_ATTRIBUTE + "='true'][style*='background-image'] {",
      "  background-image: none !important;",
      "}"
    ].join("\n")
  );
}

function scanMediaPreviews(root) {
  if (!root || !root.querySelectorAll) {
    return;
  }

  const newPostIds = new Set();
  const links = root.querySelectorAll("a[href*='/comments/']");

  for (const link of links) {
    if (link.closest && link.closest("[" + POST_BLOCKED_ATTRIBUTE + "='true'],[" + MEDIA_BLOCKED_ATTRIBUTE + "='true']")) {
      continue;
    }

    // Comment permalinks (/comments/POSTID/slug/COMMENTID) sit inside a comment
    // whose surrounding container holds the commenter's avatar. Covering media
    // for those roots blocked unrelated profile pictures, so only the post's own
    // permalink is allowed to gate media.
    if (isRedditCommentPermalink(link.getAttribute && link.getAttribute("href"))) {
      continue;
    }

    const postId = postIdFromLink(link);
    const discoveredRoot = postId ? mediaRootForLink(link, postId) : null;
    const mediaRoot = postId && discoveredRoot ? registerMediaRoot(postId, discoveredRoot) : null;
    if (!postId || !mediaRoot) {
      continue;
    }

    if (mediaRootLooksNsfw(mediaRoot) || embeddedNsfwPostIds.has(postId)) {
      applyPostMetadataState(postId, "blocked");
      continue;
    }

    if (embeddedSafePostIds.has(postId)) {
      applyPostMetadataState(postId, "safe");
      continue;
    }

    const state = postMetadataStates.get(postId);
    if (state === "blocked") {
      blockNsfwMedia(mediaRoot, true, true);
    } else if (state === "unknown") {
      // Fail open when Reddit will not confirm the post's rating (its by-id
      // endpoint rate-limits large feed batches, which was covering harmless
      // images). Real NSFW is still caught by the post's own nsfw/over18
      // attributes, an exact badge, a known-blocked rating, and Reddit's own
      // forced safe-search + mature-media blur.
      releaseMediaRoot(mediaRoot);
    } else if (state === "safe") {
      releaseMediaRoot(mediaRoot);
    } else {
      markMediaPending(mediaRoot);
      if (state !== "checking") {
        postMetadataStates.set(postId, "checking");
        newPostIds.add(postId);
      }
    }
  }

  requestPostMetadata(Array.from(newPostIds));
}

function postIdFromLink(link) {
  const match = String(link.getAttribute("href") || "").match(/\/comments\/([a-z0-9]+)(?:[/?#]|$)/i);
  return match ? normalizePostId(match[1]) : "";
}

// A comment permalink has a comment id after the post id and slug
// (/comments/POSTID/slug/COMMENTID); a post permalink stops at the slug. Used to
// keep comment-section avatars from being treated as post media.
function isRedditCommentPermalink(href) {
  return /\/comments\/[a-z0-9]+\/[^/]+\/[a-z0-9]+/i.test(String(href || ""));
}

function mediaRootForLink(link, postId) {
  const standardPost = link.closest ? link.closest(POST_SELECTOR) : null;
  if (standardPost) {
    return standardPost;
  }

  let best = (link.matches && link.matches(MEDIA_SELECTOR)) || (link.querySelector && link.querySelector(MEDIA_SELECTOR))
    ? link
    : null;
  let node = link.parentElement;
  for (let depth = 0; node && depth < 10; depth += 1, node = node.parentElement) {
    if (node.matches && node.matches("main, body")) {
      break;
    }

    if (!node.querySelector || !node.querySelector(MEDIA_SELECTOR)) {
      continue;
    }

    const postIds = postIdsWithin(node, 2);

    if (postIds.size === 1 && postIds.has(postId)) {
      best = node;
      continue;
    }

    if (postIds.size > 1) {
      break;
    }
  }

  return best;
}

function mediaRootLooksNsfw(root) {
  if (elementHasTrueFlag(root, [
    "is-nsfw",
    "nsfw",
    "data-nsfw",
    "over18",
    "over-18",
    "data-over18",
    "data-over-18"
  ])) {
    return true;
  }

  if (root.querySelector && root.querySelector(POST_FLAG_SELECTOR)) {
    return true;
  }

  if (root.querySelectorAll) {
    const labels = root.querySelectorAll("span, strong, faceplate-tooltip");
    const limit = Math.min(labels.length, 200);
    if (labels.length > 200) { redditScanTruncated("Beschriftungen im Medienknoten", 200); }
    for (let index = 0; index < limit; index += 1) {
      if (/^(?:nsfw|18\+|adult content|mature content)$/i.test(String(labels[index].textContent || "").trim())) {
        return true;
      }
    }
  }

  return false;
}

function registerMediaRoot(postId, root) {
  let roots = mediaRootsByPostId.get(postId);
  if (!roots) {
    roots = new Set();
    mediaRootsByPostId.set(postId, roots);
  }

  for (const existing of roots) {
    if (existing === root || (existing.contains && existing.contains(root))) {
      return existing;
    }

    if (root.contains && root.contains(existing)) {
      roots.delete(existing);
    }
  }

  roots.add(root);
  return root;
}

function markMediaPending(root) {
  if (root.getAttribute(MEDIA_BLOCKED_ATTRIBUTE) === "true") {
    return;
  }

  root.setAttribute(MEDIA_PENDING_ATTRIBUTE, "true");
  pauseMedia(root);
}

function pauseMedia(root) {
  const players = [];
  if (root.matches && root.matches("video, audio")) {
    players.push(root);
  }
  if (root.querySelectorAll) {
    for (const player of root.querySelectorAll("video, audio")) {
      players.push(player);
    }
  }

  for (const player of players) {
    try {
      player.muted = true;
      player.removeAttribute("autoplay");
      player.pause();
    } catch {
    }
  }
}

function requestPostMetadata(postIds) {
  for (let offset = 0; offset < postIds.length; offset += 50) {
    requestPostMetadataBatch(postIds.slice(offset, offset + 50));
  }
}

function requestPostMetadataBatch(postIds) {
  if (!postIds.length) {
    return;
  }

  try {
    chrome.runtime.sendMessage(
      { type: REDDIT_POSTS_CHECK, postIds },
      (response) => {
        try {
          if (!extensionContextAvailable()) {
            reloadAfterExtensionUpdate();
            return;
          }

          if (chrome.runtime.lastError) {
            applyUnknownPostMetadata(postIds);
            return;
          }

          const decisions = new Map();
          for (const decision of response && Array.isArray(response.decisions) ? response.decisions : []) {
            const postId = normalizePostId(decision && decision.postId);
            if (postId) {
              decisions.set(postId, decision);
            }
          }

          for (const postId of postIds) {
            const decision = decisions.get(postId);
            if (decision && decision.known && decision.blocked) {
              applyPostMetadataState(postId, "blocked");
            } else if (decision && decision.known) {
              applyPostMetadataState(postId, "safe");
            } else {
              applyPostMetadataState(postId, "unknown");
            }
          }
        } catch {
          applyUnknownPostMetadata(postIds);
        }
      }
    );
  } catch {
    applyUnknownPostMetadata(postIds);
  }
}

function applyUnknownPostMetadata(postIds) {
  for (const postId of postIds) {
    applyPostMetadataState(postId, "unknown");
  }
}

function applyPostMetadataState(postId, state) {
  postMetadataStates.set(postId, state);
  const roots = mediaRootsByPostId.get(postId);
  if (!roots) {
    return;
  }

  for (const root of Array.from(roots)) {
    if (root.isConnected === false) {
      roots.delete(root);
      continue;
    }

    if (state === "blocked") {
      blockNsfwMedia(root, true, true);
    } else if (state === "safe") {
      releaseMediaRoot(root);
    } else if (state === "unknown") {
      // See scanMediaPreviews: unknown ratings fail open (Reddit's own forced
      // safe-search + mature blur and the local nsfw signals remain).
      releaseMediaRoot(root);
    }
  }
}

function releaseMediaRoot(root) {
  if (root.getAttribute(MEDIA_BLOCKED_ATTRIBUTE) !== "true") {
    root.removeAttribute(MEDIA_PENDING_ATTRIBUTE);
  }
}

function blockNsfwMedia(root, confirmedNsfw, blockWholePost) {
  const standardPost = root.matches && root.matches(POST_SELECTOR)
    ? root
    : (root.closest ? root.closest(POST_SELECTOR) : null);

  if (blockWholePost && standardPost) {
    blockNsfwPost(standardPost);
    return;
  }

  const media = [];
  if (root.matches && root.matches(MEDIA_SELECTOR)) {
    media.push(root);
  }
  if (root.querySelectorAll) {
    for (const item of root.querySelectorAll(MEDIA_SELECTOR)) {
      media.push(item);
    }
  }

  if (!standardPost && !(root.matches && root.matches(MEDIA_SELECTOR))) {
    blockNsfwMediaItems(root, confirmedNsfw);
    return;
  }

  if (root.getAttribute(MEDIA_BLOCKED_ATTRIBUTE) === "true") {
    return;
  }

  root.removeAttribute(MEDIA_PENDING_ATTRIBUTE);
  root.setAttribute(MEDIA_BLOCKED_ATTRIBUTE, "true");
  pauseMedia(root);

  const primaryMedia = selectPrimaryMedia(media);
  const placeholderHost = mediaPlaceholderHost(primaryMedia, root);

  // Measure the rendered media height BEFORE hiding it. Once display:none is set
  // getBoundingClientRect() returns 0, so the placeholder would collapse to its
  // minimum height and leave the container's (often black) background exposed
  // below it. Fall back to the host's height for wrapped players.
  let measuredMediaHeight = 0;
  for (const candidate of [primaryMedia, placeholderHost, root]) {
    if (candidate && candidate.getBoundingClientRect) {
      try {
        const h = Math.round(candidate.getBoundingClientRect().height || 0);
        if (h > measuredMediaHeight) {
          measuredMediaHeight = h;
        }
      } catch {
      }
    }
  }

  for (const item of media) {
    item.style.setProperty("display", "none", "important");
  }

  const mediaLink = primaryMedia && primaryMedia.closest ? primaryMedia.closest("a") : null;
  const disabledLink = mediaLink && (!root.contains || root.contains(mediaLink))
    ? mediaLink
    : (root.matches && root.matches("a") ? root : null);
  if (disabledLink) {
    disabledLink.removeAttribute("href");
    disabledLink.setAttribute("aria-disabled", "true");
    disabledLink.addEventListener("click", (event) => event.preventDefault());
  }

  if (!root.querySelector("[" + MEDIA_PLACEHOLDER_ATTRIBUTE + "='true']")) {
    const placeholder = createMediaPlaceholder(confirmedNsfw, primaryMedia, measuredMediaHeight);
    if (placeholderHost && placeholderHost.insertBefore) {
      placeholderHost.insertBefore(placeholder, primaryMedia && primaryMedia.parentElement === placeholderHost ? primaryMedia : placeholderHost.firstChild);
    } else {
      root.insertBefore(placeholder, root.firstChild);
    }
  }
}

function selectPrimaryMedia(media) {
  let selected = null;
  let selectedScore = -1;

  for (const item of media) {
    const tag = String(item.tagName || "").toLowerCase();
    const source = String(
      item.currentSrc ||
      (item.getAttribute && (item.getAttribute("src") || item.getAttribute("data-src"))) ||
      ""
    ).toLowerCase();
    let score = 0;

    if (/^(?:video|iframe|picture|canvas|object|embed|faceplate-img|shreddit-player|shreddit-embed|shreddit-media-lightbox|shreddit-blurred-container)$/.test(tag)) {
      score += 100;
    }
    if (/(?:preview\.redd\.it|i\.redd\.it|v\.redd\.it|external-preview|redgifs)/.test(source)) {
      score += 90;
    }

    const width = Number(item.naturalWidth || item.videoWidth || (item.getAttribute && item.getAttribute("width")) || 0);
    const height = Number(item.naturalHeight || item.videoHeight || (item.getAttribute && item.getAttribute("height")) || 0);
    if (width >= 80 || height >= 80) {
      score += 70;
    }
    if (item.closest && item.closest("a[href*='/comments/']")) {
      score += 50;
    }

    if (score > selectedScore) {
      selected = item;
      selectedScore = score;
    }
  }

  return selected;
}

function mediaPlaceholderHost(media, fallbackRoot) {
  if (!media || !media.parentElement) {
    return fallbackRoot;
  }

  let host = media.parentElement;
  if (host.matches && host.matches("picture") && host.parentElement) {
    host = host.parentElement;
  }
  return host;
}

function createMediaPlaceholder(confirmedNsfw, replacedMedia, measuredHeight) {
  const placeholder = purestateCurtainPlaceholder(
    document,
    purestateCurtainTheme(document),
    confirmedNsfw ? "18+ Vorschau blockiert" : "Vorschau blockiert",
    "",
    ["width:100%", "min-width:88px", "min-height:72px", "padding:8px"]
  );
  placeholder.setAttribute(MEDIA_PLACEHOLDER_ATTRIBUTE, "true");
  placeholder.setAttribute("role", "note");

  // Size the placeholder to the media it replaces so no black container
  // background shows below it. The height is measured before the media is
  // hidden (see blockNsfwMedia); a rendered element passed here is a fallback.
  let height = Math.round(Number(measuredHeight) || 0);
  if (height < 72 && replacedMedia && replacedMedia.getBoundingClientRect) {
    try {
      height = Math.round(replacedMedia.getBoundingClientRect().height || 0);
    } catch {
    }
  }
  if (height >= 72) {
    placeholder.style.setProperty("min-height", Math.min(height, 640) + "px", "important");
  }
  return placeholder;
}

function blockNsfwPost(post) {
  if (!post.parentNode || post.getAttribute(POST_BLOCKED_ATTRIBUTE) === "true") {
    return;
  }

  const placeholder = purestateCurtainPlaceholder(
    document,
    purestateCurtainTheme(document),
    "18+ Beitrag blockiert",
    "",
    ["min-height:112px", "padding:20px"]
  );
  placeholder.setAttribute(POST_PLACEHOLDER_ATTRIBUTE, "true");
  placeholder.setAttribute("role", "note");

  post.setAttribute(POST_BLOCKED_ATTRIBUTE, "true");
  post.parentNode.insertBefore(placeholder, post);
  post.style.setProperty("display", "none", "important");
}

function detectPageNsfwSignal(subreddit) {
  const flaggedHeader = document.querySelector([
    "shreddit-subreddit-header[is-nsfw]",
    "shreddit-subreddit-header[nsfw]",
    "shreddit-app[is-nsfw]",
    "[data-testid='subreddit-header'][data-nsfw='true']",
    "[data-testid='subreddit-header'][data-over18='true']"
  ].join(","));

  if (flaggedHeader) {
    return pageBlockDecision("Reddit kennzeichnet diese Community als 18+.", "reddit-page-attribute");
  }

  const adultMeta = document.querySelector([
    "meta[name='rating'][content*='adult' i]",
    "meta[property='og:restrictions:age'][content='18+']",
    "meta[property='og:restrictions:age'][content='18']"
  ].join(","));

  if (adultMeta) {
    return pageBlockDecision("Die Seitenangaben kennzeichnen diese Community als Erwachseneninhalt.", "reddit-page-meta");
  }

  const gate = document.querySelector([
    "shreddit-content-gate",
    "[data-testid='content-gate']",
    "[data-testid='age-gate']",
    "[slot='nsfw-landing-page']"
  ].join(","));

  if (gate && /(?:18\+|adult content|mature content|not safe for work|nsfw|erwachseneninhalt)/i.test(gate.textContent || "")) {
    return pageBlockDecision("Reddit zeigt für diese Community einen 18+-Hinweis an.", "reddit-page-gate");
  }

  if (embeddedSubredditIsNsfw(subreddit)) {
    return pageBlockDecision("Reddit kennzeichnet diese Community in den Seitendaten als 18+.", "reddit-page-data");
  }

  return { blocked: false, reason: "", source: "reddit-page" };
}

function embeddedSubredditIsNsfw(subreddit) {
  const target = String(subreddit || "").toLowerCase();
  const scripts = document.querySelectorAll("script[type='application/json'], script#data");

  for (const script of scripts) {
    const text = script.textContent || "";
    if (!text || text.length > 5000000 || text.toLowerCase().indexOf(target) < 0) {
      continue;
    }

    try {
      if (jsonContainsNsfwSubreddit(JSON.parse(text), target)) {
        return true;
      }
    } catch {
      // Some Reddit data scripts are not plain JSON.
    }
  }

  return false;
}

function jsonContainsNsfwSubreddit(root, target) {
  const pending = [root];
  let inspected = 0;

  while (pending.length && inspected < 150000) {
    if (inspected + 1 >= 150000) { redditScanTruncated("JSON-Knoten (Medien)", 150000); }
    const value = pending.pop();
    inspected += 1;

    if (!value || typeof value !== "object") {
      continue;
    }

    const displayName = String(value.display_name || value.displayName || "").toLowerCase();
    const subredditName = String(value.subredditName || "").toLowerCase();
    const flagged = isTrue(value.over18) || isTrue(value.over_18) || isTrue(value.isNsfw);

    if (flagged && (displayName === target || subredditName === target)) {
      return true;
    }

    for (const child of Object.values(value)) {
      if (child && typeof child === "object") {
        pending.push(child);
      }
    }
  }

  return false;
}

function pageBlockDecision(reason, source) {
  return { blocked: true, reason, source };
}

function isTrue(value) {
  return value === true || value === "true" || value === 1 || value === "1";
}

function subredditFromLocation(urlText) {
  let url;
  try {
    url = new URL(urlText);
  } catch {
    return "";
  }

  if (!/(^|\.)reddit\.com$/i.test(url.hostname)) {
    return "";
  }

  const match = url.pathname.match(/^\/r\/([a-z0-9_]{2,32})(?:[/?#]|$)/i);
  return match ? match[1].toLowerCase() : "";
}

function showOverlay(subreddit, decision) {
  const root = document.documentElement;
  if (!root) {
    return;
  }

  let overlay = document.getElementById(OVERLAY_ID);
  if (!overlay) {
    overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;
    root.appendChild(overlay);
  }

  overlay.innerHTML = "";
  const view = buildBlockView(subreddit, decision);
  overlay.appendChild(view);
  document.documentElement.style.overflow = "hidden";
  if (document.body) {
    document.body.style.overflow = "hidden";
  }
  // EXT-A04: Der Dialog behauptete aria-modal, liess den Fokus aber im
  // Hintergrund. Beim Neuaufbau (anderer Subreddit) ist der fokussierte Knopf
  // weg - dann gehoert der Fokus wieder in die erste Aktion.
  if (typeof purestateHoldOverlayFocus === "function") {
    if (overlay.purestateFocusHeld === true) {
      try { view.purestateFirstAction.focus({ preventScroll: true }); } catch {}
    } else {
      purestateHoldOverlayFocus(document, overlay, view.purestateFirstAction);
    }
  }
}

function buildBlockView(subreddit, decision) {
  const theme = purestateCurtainTheme(document);
  const wrapper = document.createElement("div");
  wrapper.setAttribute("role", "dialog");
  wrapper.setAttribute("aria-modal", "true");
  wrapper.setAttribute("aria-labelledby", OVERLAY_ID + "-title");
  // EXT-A05: eigener Scroll + margin:auto statt abschneidender Zentrierung.
  wrapper.style.cssText = purestateCurtainOverlayCss(theme);

  const panel = purestateCurtainColumn(document);
  panel.appendChild(purestateCurtainBars(document, theme, "lg"));
  panel.appendChild(purestateCurtainText(document, theme, "Purestate", "label"));
  const title = purestateCurtainTitle(document, theme, OVERLAY_ID + "-title", "Inhalt blockiert", "curtain");
  title.setAttribute("role", "heading");
  title.setAttribute("aria-level", "1");
  panel.appendChild(title);
  panel.appendChild(purestateCurtainText(document, theme, "r/" + subreddit + " wurde durch den Inhalts-Schutz blockiert.", "detail"));
  panel.appendChild(purestateCurtainText(document, theme, decision.reason || "Diese Seite passt zu einer aktiven Purestate-Regel.", "small"));

  // Die Knopfregeln aus dem Baukasten halten Reddits globales Button-CSS fern
  // (frueher live bestaetigt: Layout und Klick kaputt).
  const buttons = purestateCurtainActions(document);
  panel.appendChild(buttons);

  const home = purestateCurtainButton(document, theme, "Reddit Startseite", "primary");
  home.addEventListener("click", (event) => {
    if (event) { event.preventDefault(); event.stopPropagation(); }
    window.location.assign("https://www.reddit.com/");
  }, true);
  buttons.appendChild(home);

  const back = purestateCurtainButton(document, theme, "Zurück", "secondary");
  back.addEventListener("click", (event) => {
    if (event) { event.preventDefault(); event.stopPropagation(); }
    // Reddit is an SPA: history.back() is sometimes swallowed (popstate handled
    // client-side with no real navigation), which looks like a dead button. If
    // the URL has not changed shortly after, or if it lands back on a blocked
    // adult search route, fall back to the Reddit home page.
    const before = location.href;
    if (history.length > 1) {
      history.back();
      setTimeout(() => {
        if (location.href === before || redditAdultSearchTerm()) {
          window.location.assign("https://www.reddit.com/");
        }
      }, 400);
    } else {
      window.location.assign("https://www.reddit.com/");
    }
  }, true);
  buttons.appendChild(back);

  wrapper.purestateFirstAction = home;
  wrapper.appendChild(panel);
  return wrapper;
}

function removeOverlay() {
  const overlay = document.getElementById(OVERLAY_ID);
  if (overlay) {
    overlay.remove();
    if (typeof purestateReleaseOverlayFocus === "function") {
      purestateReleaseOverlayFocus(overlay);
    }
  }

  document.documentElement.style.overflow = "";
  if (document.body) {
    document.body.style.overflow = "";
  }
}
