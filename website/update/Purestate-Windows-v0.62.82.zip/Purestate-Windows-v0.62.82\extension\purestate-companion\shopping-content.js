"use strict";

// Purestate shopping companion (checkout delay, stimulus damping, curfew).
//
// Gentle friction, never a hard block outside the configured curfew window:
// - Checkout delay: checkout/cart routes open behind a full-page overlay with
//   a mandatory wait timer and calm reflection questions. "Weiter zum Kauf"
//   only appears after the timer ran out. The release timestamp lives in
//   chrome.storage.local, so reloads or a browser restart do NOT reset the
//   wait; after release a short grace window lets multi-step checkouts pass.
// - Stimulus damping: countdown/scarcity/sale-shouting elements are hidden.
//   Fail-open heuristic - only small text elements, never product lists.
// - Curfew: inside the configured window the WHOLE shop page is covered with
//   a calm overlay (back button only).
//
// Everything is driven by the native rule pack. If the rule pack is missing
// or the shopping area is off, this module does nothing (fail-open by design;
// shopping friction is not a safety failure like NSFW).

const SHOPPING_RULES_GET = "purestate.getBrowserRules";
const SHOPPING_TIME_TICK = "purestate.timeTick";
const SHOPPING_TIME_STATE = "purestate.timeState";
const SHOPPING_DELAY_OVERLAY_ID = "purestate-shopping-delay-overlay";
const SHOPPING_CURFEW_OVERLAY_ID = "purestate-shopping-curfew-overlay";
const SHOPPING_TIME_OVERLAY_ID = "purestate-shopping-time-overlay";
const SHOPPING_MONTHLY_OVERLAY_ID = "purestate-shopping-monthly-overlay";
const SHOPPING_TIME_BADGE_ID = "purestate-shopping-time-badge";
const SHOPPING_DELAY_GRACE_MS = 15 * 60 * 1000;
// Merker fuer einen Kauf, der ohne lesbaren Betrag gezaehlt wurde. Er lebt
// genau so lange wie das Kulanzfenster: danach gehoert eine Summe auf dem
// Bildschirm zu einem anderen Vorgang.
const SHOPPING_PENDING_SPEND_KEY = "purestatePendingSpend";
// Live gefunden (2026-10-06, Amazon): "Betrag nicht lesbar" las sich wie ein
// Fehler. Gemeint ist der Normalfall der ersten Kassenseite (Prime-Zwischen-
// seite ohne Summe): gebucht wird sofort, der Betrag folgt auf einer spaeteren
// Seite (usage-spend). Der Text sagt das, statt einen Defekt zu melden.
const SHOPPING_AMOUNT_PENDING_TEXT =
  "Der Betrag steht auf dieser Seite noch nicht fest. Purestate zählt den Kauf und trägt den Betrag nach, sobald eine spätere Kassenseite ihn zeigt.";
const SHOPPING_DAMPED_ATTR = "data-purestate-damped";
const SHOPPING_REFLECTION_QUESTIONS = [
  "Brauche ich das wirklich?",
  "Welches Bedürfnis möchte ich gerade erfüllen?",
  "Würde ich es auch ohne Rabatt kaufen?",
  "Passt der Kauf zu meinen Zielen?",
  "Besitze ich schon etwas Vergleichbares?",
  "Kann ich die Ausgabe ohne Folgen tragen?",
  "Wie fühle ich mich morgen damit?",
  "Was könnte ich jetzt stattdessen tun?",
  "Würde ich den Kauf einer vertrauten Person offen zeigen?",
  "Möchte ich den Gegenstand oder das Gefühl des Kaufens?"
];

let shoppingRules = emptyShoppingRules();
let shoppingDelayCountdownTimer = null;
let shoppingTimeLimitReached = false;
let shoppingDelayOverlayPending = false;
let shoppingSpendSettling = false;
let lastShoppingLocation = "";
let shoppingHostDomains = [];
let shoppingModuleStarted = false;
let shoppingDetection = { state: "", href: "", shop: false, reason: "", tries: 0 };
let shoppingHostRemembered = false;
let shoppingHostRememberedAt = 0;
let shoppingHeadObserver = null;
let shoppingHeadMarkupCount = -1;

// Ein Shop ist ein Ort, keine einzelne Seite. Erkannt wird zuverlaessig nur,
// wo ein Produkt ausgezeichnet ist - Startseite, Kategorien und Suchergebnisse
// tragen dieselben Merkmale nicht. Genau dort passiert aber das Bummeln, das
// Zeit kostet, und ohne diese Erinnerung liefe auch das Tagesbudget dort nicht
// mit. Gemerkt wird nur der Hostname mit einem Zeitstempel, im Browserprofil.
const SHOPPING_HOST_MEMORY_KEY = "purestateShopHosts";
const SHOPPING_HOST_MEMORY_MS = 30 * 24 * 60 * 60 * 1000;
const SHOPPING_HOST_MEMORY_MAX = 300;
const SHOPPING_HOST_REFRESH_MS = 60 * 60 * 1000;

installShoppingModule();

function emptyShoppingRules() {
  return {
    enabled: false,
    checkoutDelayEnabled: false,
    stimulusDampingEnabled: false,
    curfewEnabled: false,
    curfewStart: "22:00",
    curfewEnd: "06:00",
    delayMinutes: 10,
    dailyLimitEnabled: false,
    dailyLimitMinutes: 30,
    monthlyOrderLimitEnabled: false,
    monthlyOrderLimit: 10,
    monthlyBudgetEnabled: false,
    monthlyBudgetEuro: 200
  };
}

// The script now runs on every page (broad host permission). Fixed shops
// start immediately as before; every other page asks for the rule pack and
// only starts the shopping module once its hostname turns out to be a shop.
//
// LEAD-005, am 2026-08-22 gemessen: "inert" ist das NICHT, und der Kommentar
// behauptete es frueher. Auf einer fremden Seite bleiben ein Beobachter ueber
// den ganzen Teilbaum (bis DOMContentLoaded, siehe watchHeadForShopMarkup) und
// nach "load" ein begrenztes Sekundenintervall. Zusammen mit den beiden
// anderen Modulen des breiten Blocks sind es drei Dauerintervalle, ein
// Beobachter und dreizehn DOM-Abfragen, bevor die Seite Inhalt hat. Der
// Regressionstest in tests\Extension.Regression.Tests.js haelt diese Zahlen
// als Obergrenze fest.
function installShoppingModule() {
  requestShoppingRules();
  installShoppingPushListener();
  if (typeof purestateFindShoppingSite === "function" && purestateFindShoppingSite(location.hostname)) {
    startShoppingModule();
    return;
  }
  watchForDetectedShopPage();
  watchHeadForShopMarkup();
  loadShoppingHostMemory(recheckDetectedShopPage);
}

// Beim ERSTEN Kontakt mit einem unbekannten Shop ist die Seite so lange
// benutzbar, bis Inhalt da ist - und wer in dieser Zeit weiterklickt, faengt
// auf der naechsten Seite von vorn an. Produktauszeichnung steht aber im
// <head> und ist fertig, lange bevor die Seite sichtbar wird. Der Beobachter
// laeuft deshalb nur bis zum ersten Treffer oder bis "DOMContentLoaded".
// Ab dem zweiten Kontakt greift ohnehin das Host-Gedaechtnis.
function watchHeadForShopMarkup() {
  if (typeof MutationObserver !== "function" || !document || !document.documentElement ||
      typeof purestateDetectShopMarkup !== "function") {
    return;
  }
  const stop = () => {
    if (shoppingHeadObserver) {
      shoppingHeadObserver.disconnect();
      shoppingHeadObserver = null;
    }
  };
  const probe = () => {
    if (shoppingModuleStarted || !shoppingHeadObserver) {
      stop();
      return;
    }
    // ponytail: Zaehler statt Neuauswertung bei jeder Mutation - waehrend des
    // Parsens feuert der Beobachter sonst hunderte Male und parst jedes Mal
    // dasselbe JSON.
    let count;
    try {
      count = document.querySelectorAll('script[type="application/ld+json"], meta[property="og:type"], meta[name="og:type"]').length;
    } catch {
      return;
    }
    if (count === shoppingHeadMarkupCount) {
      return;
    }
    shoppingHeadMarkupCount = count;
    if (!purestateDetectShopMarkup(document)) {
      return;
    }
    stop();
    shoppingDetection = { state: document.readyState, href: location.href, shop: true,
      reason: "head-markup", tries: 0 };
    rememberShoppingHost();
    recheckDetectedShopPage();
  };
  shoppingHeadObserver = new MutationObserver(probe);
  shoppingHeadObserver.observe(document.documentElement, { childList: true, subtree: true });
  if (typeof document.addEventListener === "function") {
    document.addEventListener("DOMContentLoaded", stop);
  }
  probe();
}

// Bei document_start ist die Seite leer - dort erkennt der Erkenner nie einen
// Shop. Ohne diese zweite Frage bliebe jeder nicht gelistete Shop dauerhaft
// unbehandelt, weil das Regelpaket lange vor dem Seiteninhalt eintrifft.
function watchForDetectedShopPage() {
  if (!document || typeof document.addEventListener !== "function") {
    return;
  }
  // ponytail: zwei Ereignisse plus ein begrenztes Nachfassen statt
  // Dauerbeobachtung. Live gefunden (2026-08-07, bergfreunde.de): Warenkorb
  // und Preise standen erst nach "load" auf der Seite, und danach fragte
  // niemand mehr - die Seite blieb dauerhaft unbehandelt. Ein Beobachter auf
  // jeder Webseite waere aber eine Bremse fuer den ganzen Browser, deshalb
  // hoert das Nachfassen nach SHOPPING_DETECT_MAX_RETRIES Versuchen auf.
  document.addEventListener("DOMContentLoaded", recheckDetectedShopPage);
  if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
    window.addEventListener("load", pollForDetectedShopPage);
  }
}

function pollForDetectedShopPage() {
  recheckDetectedShopPage();
  if (shoppingModuleStarted || typeof setInterval !== "function") {
    return;
  }
  let left = SHOPPING_DETECT_MAX_RETRIES;
  const timer = setInterval(() => {
    left -= 1;
    recheckDetectedShopPage();
    if (shoppingModuleStarted || left <= 0) {
      clearInterval(timer);
    }
  }, 1000);
}

function recheckDetectedShopPage() {
  if (shoppingModuleStarted || !shoppingRules.enabled || !shoppingHostActive()) {
    return;
  }
  startShoppingModule();
  applyShoppingState();
}

// ---- Host-Gedaechtnis -----------------------------------------------------

function loadShoppingHostMemory(done) {
  readShoppingStore((items) => {
    const map = items && typeof items[SHOPPING_HOST_MEMORY_KEY] === "object" && items[SHOPPING_HOST_MEMORY_KEY]
      ? items[SHOPPING_HOST_MEMORY_KEY]
      : {};
    const seen = map[location.hostname];
    // Ein zukunftsdatierter Eintrag laeuft bewusst NICHT sofort ab: eine
    // vorgestellte Uhr darf das Gedaechtnis nicht leeren.
    if (typeof seen === "number" && Date.now() - seen <= SHOPPING_HOST_MEMORY_MS) {
      shoppingHostRemembered = true;
      shoppingHostRememberedAt = seen;
    }
    done();
  });
}

function rememberShoppingHost() {
  if (shoppingHostIsPlatform()) {
    return;
  }
  const now = Date.now();
  if (shoppingHostRemembered && now - shoppingHostRememberedAt < SHOPPING_HOST_REFRESH_MS) {
    return;
  }
  shoppingHostRemembered = true;
  shoppingHostRememberedAt = now;
  readShoppingStore((items) => {
    const stored = items && typeof items[SHOPPING_HOST_MEMORY_KEY] === "object" && items[SHOPPING_HOST_MEMORY_KEY]
      ? items[SHOPPING_HOST_MEMORY_KEY]
      : {};
    stored[location.hostname] = now;
    // Abgelaufenes faellt beim Schreiben weg, und die juengsten Eintraege
    // gewinnen - so waechst die Liste nicht unbegrenzt.
    const fresh = Object.keys(stored)
      .filter((host) => typeof stored[host] === "number" && now - stored[host] <= SHOPPING_HOST_MEMORY_MS)
      .sort((a, b) => stored[b] - stored[a])
      .slice(0, SHOPPING_HOST_MEMORY_MAX);
    const next = {};
    for (const host of fresh) {
      next[host] = stored[host];
    }
    writeShoppingHostMemory(next);
  });
}

function writeShoppingHostMemory(map) {
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local && typeof chrome.storage.local.set === "function") {
      const values = {};
      values[SHOPPING_HOST_MEMORY_KEY] = map;
      chrome.storage.local.set(values, () => {});
      return;
    }
  } catch {
  }
  if (!globalThis.__purestateShoppingMonthFallback) {
    globalThis.__purestateShoppingMonthFallback = {};
  }
  globalThis.__purestateShoppingMonthFallback[SHOPPING_HOST_MEMORY_KEY] = map;
}

function startShoppingModule() {
  if (shoppingModuleStarted) {
    return;
  }
  shoppingModuleStarted = true;
  requestShoppingTimeState();
  setInterval(() => {
    sendShoppingTimeTick();
    refreshShoppingTimeStateUnderCurtain();
  }, 15000);
  if (typeof document.addEventListener === "function") {
    document.addEventListener("visibilitychange", refreshShoppingTimeStateUnderCurtain);
  }
  if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
    window.addEventListener("focus", refreshShoppingTimeStateUnderCurtain);
  }
  setInterval(() => {
    applyShoppingState();
    const current = location.href;
    if (current !== lastShoppingLocation) {
      lastShoppingLocation = current;
      applyShoppingState();
    }
  }, 1000);
  if (document.documentElement && typeof MutationObserver === "function") {
    const observer = new MutationObserver(() => {
      applyShoppingDamping();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
}

// Plattformen des Social-Media-Bereichs (YouTube, Reddit, ...) sind keine Shops.
// Die Inhaltserkennung darf sie weder als Shop werten noch merken - und ein
// bereits gemerkter Eintrag aus dem Browserprofil zaehlt nicht mehr (Live-Fund
// 2026-10-06: YouTube lag unter dem Shopping-Zeitvorhang).
function shoppingHostIsPlatform() {
  return typeof purestateShoppingNotShopHost === "function" &&
    purestateShoppingNotShopHost(location.hostname);
}

// Gepflegte Hostliste ODER am Inhalt erkannter Shop. Ohne den zweiten Teil
// waere "nimm einen anderen Shop" die billigste Umgehung des ganzen
// Schutzbereichs - eine Liste deckt immer nur ab, woran jemand gedacht hat.
function shoppingHostActive() {
  if (typeof purestateShoppingHostMatches === "function" &&
      purestateShoppingHostMatches(location.hostname, shoppingHostDomains)) {
    return true;
  }
  if (shoppingHostIsPlatform()) {
    return false;
  }
  if (shoppingHostRemembered) {
    return true;
  }
  if (detectedShopPage()) {
    // Nur Produktauszeichnung macht den ganzen Host zum Shop. Die weiche Regel
    // "cart-and-price" gilt dagegen nur fuer diese Seite: ein einzelner
    // Fehltreffer (Live-Fund 2026-10-06, YouTube) soll nicht 30 Tage lang jede
    // Seite des Hosts treffen. Echte Shops zeigen auf ihren Produktseiten
    // Auszeichnung, und ihre Kassen- und Kategorieseiten tragen Warenkorb und
    // Preis, werden also auch einzeln erkannt.
    if (shoppingDetection.reason !== "cart-and-price") {
      rememberShoppingHost();
    }
    return true;
  }
  return false;
}

// Nur die Hostliste, ohne Inhaltserkennung. Alles, was ueber die sanften
// Mechanismen hinausgeht, haengt an dieser Fassung.
function shoppingHostListed() {
  return typeof purestateShoppingHostMatches === "function" &&
    purestateShoppingHostMatches(location.hostname, shoppingHostDomains);
}

// Das Ergebnis wird gemerkt, solange sich der Ladezustand nicht aendert: bei
// document_start ist der Seiteninhalt noch leer, und ein Erkenner, der jede
// Sekunde ueber alle Knoten laeuft, waere eine Bremse auf jeder Webseite.
//
// Der Ladezustand allein reicht aber nicht. Live gefunden (2026-08-07,
// hornbach.de): readyState kennt nach "complete" keinen weiteren Wert, und was
// eine Seite danach nachrendert - bei jeder SPA der halbe Inhalt - sah der
// Erkenner nie. Ein einmal gefaelltes "kein Shop" blieb fuer die ganze
// Lebensdauer der Seite kleben. Ein "Shop" dagegen kann so bleiben: mehr als
// erkannt wird daraus nicht.
const SHOPPING_DETECT_MAX_RETRIES = 10;

function detectedShopPage() {
  if (typeof purestateDetectShopPage !== "function") {
    return false;
  }
  const state = document.readyState;
  // DET-004 (gleiche Familie wie im Erwachsenen- und Gluecksspielmodul): der
  // Ladezustand bleibt nach dem Laden dauerhaft "complete", also war eine
  // Navigation INNERHALB der Seite kein Ausloeser. Gerade Shops wechseln von
  // der Kategorie- auf die Produktseite per pushState.
  const href = location.href;
  const stateChanged = shoppingDetection.state !== state || shoppingDetection.href !== href;
  // Nachgereicht wird nur, solange das Urteil "kein Shop" lautet, und nur
  // begrenzt oft - sonst liefe der Durchlauf auf jeder harmlosen Seite
  // endlos weiter.
  const retry = !stateChanged && !shoppingDetection.shop &&
    shoppingDetection.tries < SHOPPING_DETECT_MAX_RETRIES;
  if (stateChanged || retry) {
    const verdict = purestateDetectShopPage(document);
    shoppingDetection = {
      state: state,
      href: href,
      shop: verdict.shop === true,
      reason: verdict.reason || "",
      tries: stateChanged ? 0 : shoppingDetection.tries + 1
    };
  }
  return shoppingDetection.shop;
}

function applyShoppingRules(response) {
  const rules = response && response.rules && typeof response.rules === "object" ? response.rules : {};
  const areas = rules.areas && typeof rules.areas === "object" ? rules.areas : {};
  const area = areas.shopping && typeof areas.shopping === "object" ? areas.shopping : null;
  const shopping = rules.shopping && typeof rules.shopping === "object" ? rules.shopping : {};
  const next = emptyShoppingRules();
  next.enabled = !!(area && area.enabled === true && area.mode === "gentle");
  next.checkoutDelayEnabled = shopping.checkoutDelayEnabled === true;
  next.stimulusDampingEnabled = shopping.stimulusDampingEnabled === true;
  next.curfewEnabled = shopping.curfewEnabled === true;
  next.curfewStart = typeof shopping.curfewStart === "string" && /^\d{1,2}:\d{2}$/.test(shopping.curfewStart) ? shopping.curfewStart : "22:00";
  next.curfewEnd = typeof shopping.curfewEnd === "string" && /^\d{1,2}:\d{2}$/.test(shopping.curfewEnd) ? shopping.curfewEnd : "06:00";
  next.delayMinutes = [2, 5, 10, 15].includes(shopping.delayMinutes) ? shopping.delayMinutes : 10;
  next.dailyLimitEnabled = shopping.dailyLimitEnabled === true;
  next.dailyLimitMinutes = Number.isInteger(shopping.dailyLimitMinutes) && shopping.dailyLimitMinutes >= 5 && shopping.dailyLimitMinutes <= 240
    ? shopping.dailyLimitMinutes
    : 30;
  next.monthlyOrderLimitEnabled = shopping.monthlyOrderLimitEnabled === true;
  next.monthlyOrderLimit = Number.isInteger(shopping.monthlyOrderLimit) && shopping.monthlyOrderLimit >= 1 && shopping.monthlyOrderLimit <= 99
    ? shopping.monthlyOrderLimit
    : 10;
  next.monthlyBudgetEnabled = shopping.monthlyBudgetEnabled === true;
  next.monthlyBudgetEuro = Number.isInteger(shopping.monthlyBudgetEuro) && shopping.monthlyBudgetEuro >= 1 && shopping.monthlyBudgetEuro <= 99999
    ? shopping.monthlyBudgetEuro
    : 200;
  shoppingHostDomains = [];
  for (const value of Array.isArray(shopping.hostDomains) ? shopping.hostDomains : []) {
    if (typeof value === "string" && value.length > 0) {
      shoppingHostDomains.push(value);
    }
  }
  // Live gefunden (2026-08-09): der Vorhang "Tageszeit erreicht" flackerte.
  // Jedes eintreffende Regelpaket loeschte den Merker, und weil die Ticks
  // unter dem Vorhang pausieren (sendShoppingTimeTick), kam er erst beim
  // naechsten Tick zurueck - bis zu 15 s, in denen der Shop offen stand.
  // Der Merker faellt deshalb nur noch, wenn sich am Limit wirklich etwas
  // geaendert hat. Bliebe er auch dann stehen, haenge der Vorhang fuer immer:
  // die Ticks, die ihn aufheben, kommen ja nicht mehr durch.
  const limitUnchanged = next.dailyLimitEnabled === true &&
    shoppingRules.dailyLimitEnabled === true &&
    next.dailyLimitMinutes === shoppingRules.dailyLimitMinutes;
  shoppingRules = next;
  if (!limitUnchanged) {
    shoppingTimeLimitReached = false;
    removeShoppingOverlay(SHOPPING_TIME_OVERLAY_ID);
    // Sofort neu bestimmen statt bis zum naechsten Tick offen zu stehen.
    // Beim ersten Paket uebernimmt das startShoppingModule weiter unten.
    if (shoppingModuleStarted) {
      requestShoppingTimeState();
    }
  }
  removeShoppingOverlay(SHOPPING_MONTHLY_OVERLAY_ID);
  if (shoppingHostActive()) {
    startShoppingModule();
  }
  if (shoppingModuleStarted) {
    applyShoppingState();
  }
}

// Live updates: the background pushes "purestate.rulesUpdated" the moment
// the Windows app saves a change; overlays flip without a tab reload.
function installShoppingPushListener() {
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.onMessage || typeof chrome.runtime.onMessage.addListener !== "function") {
      return;
    }
    chrome.runtime.onMessage.addListener((message) => {
      if (message && message.type === "purestate.rulesUpdated") {
        applyShoppingRules(message);
      }
      return false;
    });
  } catch {
  }
}

function requestShoppingRules() {
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return;
    }
    const maybePromise = chrome.runtime.sendMessage({ type: SHOPPING_RULES_GET, site: "shopping" }, (response) => {
      applyShoppingRules(response);
    });
    if (maybePromise && typeof maybePromise.then === "function") {
      maybePromise.then((response) => applyShoppingRules(response)).catch(() => {});
    }
  } catch {
  }
}

function applyShoppingState() {
  if (!shoppingRules.enabled || !shoppingHostActive()) {
    shoppingTimeLimitReached = false;
    removeShoppingTimeBadge();
    removeShoppingOverlay(SHOPPING_TIME_OVERLAY_ID);
    removeShoppingOverlay(SHOPPING_MONTHLY_OVERLAY_ID);
    removeShoppingOverlay(SHOPPING_CURFEW_OVERLAY_ID);
    removeShoppingOverlay(SHOPPING_DELAY_OVERLAY_ID);
    return;
  }

  if ((shoppingTimeLimitReached || shoppingTimeStateUnknown) && shoppingRules.dailyLimitEnabled) {
    removeShoppingTimeBadge();
    removeShoppingOverlay(SHOPPING_CURFEW_OVERLAY_ID);
    removeShoppingOverlay(SHOPPING_DELAY_OVERLAY_ID);
    removeShoppingOverlay(SHOPPING_MONTHLY_OVERLAY_ID);
    showShoppingTimeOverlay();
    return;
  }
  if (!shoppingRules.dailyLimitEnabled) {
    shoppingTimeLimitReached = false;
    removeShoppingTimeBadge();
    removeShoppingOverlay(SHOPPING_TIME_OVERLAY_ID);
  }

  if (shoppingRules.curfewEnabled && purestateShoppingIsInCurfew(currentMinuteOfDay(), shoppingRules.curfewStart, shoppingRules.curfewEnd)) {
    removeShoppingOverlay(SHOPPING_DELAY_OVERLAY_ID);
    removeShoppingOverlay(SHOPPING_MONTHLY_OVERLAY_ID);
    showShoppingCurfewOverlay();
    return;
  }
  removeShoppingOverlay(SHOPPING_CURFEW_OVERLAY_ID);

  const checkoutLimitEnabled = shoppingRules.checkoutDelayEnabled ||
    shoppingRules.monthlyOrderLimitEnabled || shoppingRules.monthlyBudgetEnabled;
  if (checkoutLimitEnabled && shoppingCheckoutHere()) {
    ensureShoppingDelayOverlay();
  } else {
    removeShoppingOverlay(SHOPPING_DELAY_OVERLAY_ID);
    removeShoppingOverlay(SHOPPING_MONTHLY_OVERLAY_ID);
  }

  if (shoppingRules.stimulusDampingEnabled) {
    applyShoppingDamping();
  }
}

// Kuratierte Shops haben gepflegte Kassenrouten. Ein erkannter Shop hat die
// nicht, dort entscheidet das allgemeine Muster - dieselbe Regel wie fuer die
// selbst eingetragenen Domains.
function shoppingCheckoutHere() {
  if (typeof purestateShoppingCheckoutMatches !== "function") {
    return false;
  }
  if (purestateShoppingCheckoutMatches(location.href, shoppingHostDomains)) {
    return true;
  }
  // Gefragt wird der Host, nicht die einzelne Seite: eine Kassenseite traegt
  // fast nie Produktauszeichnung, und ein gemerkter Shop bleibt einer, auch
  // wenn gerade nichts zu erkennen ist.
  if (typeof purestateShoppingGenericCheckout === "undefined" || !shoppingHostActive()) {
    return false;
  }
  return purestateShoppingGenericCheckout.test((location.pathname || "/") + (location.search || ""));
}

// Fragt den Tagesstand einmal ab, statt auf den ersten Tick zu warten. Live
// gefunden (2026-08-09): ein neu geladener Tab startet mit
// shoppingTimeLimitReached = false, und der Tick, der das korrigieren wuerde,
// kommt nur bei Fokus - im Hintergrundtab also nie. Bewusst OHNE Fokusgate:
// Lesen ist kein Zaehlen, und der Vorhang muss auch dann stehen, wenn der Tab
// gerade nicht vorne ist.
function requestShoppingTimeState() {
  if (!shoppingRules.enabled || !shoppingRules.dailyLimitEnabled) {
    return;
  }
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return;
    }
    const maybePromise = chrome.runtime.sendMessage({ type: SHOPPING_TIME_STATE, area: "shopping" }, handleShoppingTimeTickResponse);
    if (maybePromise && typeof maybePromise.then === "function") {
      maybePromise.then(handleShoppingTimeTickResponse).catch(() => {});
    }
  } catch {
  }
}

// EXT-A02: Unter dem Zeitvorhang pausieren die Ticks - und sie waren die
// einzige spaetere Statusabfrage. Ein neuer Tag oder ein wieder gesunder
// Dienst erreichten den offenen Tab so nie. Diese Abfrage liest nur (kein
// Zaehlen); erst eine gueltige Antwort "unter dem Limit" nimmt den Vorhang.
function refreshShoppingTimeStateUnderCurtain() {
  if (document.getElementById && document.getElementById(SHOPPING_TIME_OVERLAY_ID)) {
    requestShoppingTimeState();
  }
}

function sendShoppingTimeTick() {
  if (!shoppingRules.enabled || !shoppingRules.dailyLimitEnabled || !shoppingHostActive() ||
      document.visibilityState !== "visible" || typeof document.hasFocus !== "function" || !document.hasFocus() ||
      (document.getElementById && document.getElementById(SHOPPING_TIME_OVERLAY_ID))) {
    return;
  }
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return;
    }
    const maybePromise = chrome.runtime.sendMessage({ type: SHOPPING_TIME_TICK, area: "shopping" }, handleShoppingTimeTickResponse);
    if (maybePromise && typeof maybePromise.then === "function") {
      maybePromise.then(handleShoppingTimeTickResponse).catch(() => {});
    }
  } catch {
  }
}

// EXT-001: Der Rueckgabewert kannte nur "Limit erreicht" und "Limit nicht
// erreicht". Blieb die Antwort aus, kehrte der Handler ohne jede Aktion
// zurueck - der zuletzt bekannte Zustand blieb stehen, und beim Laden eines
// Tabs ist das "kein Limit". Fuer kuratierte Seiten faengt die Windows-Seite
// das nach dem Heartbeat-Timeout mit der Vollsperre ab; ein am Inhalt
// erkannter Shop steht auf keiner Liste, dort wirkte der Ausfall unbegrenzt.
//
// Die Schwelle liegt bewusst hoch: bei 15 Sekunden Takt sind das rund zwei
// Minuten. Ein Dienstneustart darf niemanden aussperren - zu aggressiv
// gesetzt waere der Fix schlimmer als der Befund.
const SHOPPING_TIME_PROBE_FAILURE_LIMIT = 8;
let shoppingTimeProbeFailures = 0;
let shoppingTimeStateUnknown = false;

function purestateShoppingTimeStateUnknown() {
  return shoppingTimeStateUnknown;
}

// Als Funktion, nicht als Konstante: eine mit const deklarierte Bindung ist im
// Test-Kontext (vm.runInContext) nicht erreichbar, eine Funktionsdeklaration
// schon.
function purestateShoppingTimeProbeLimit() {
  return SHOPPING_TIME_PROBE_FAILURE_LIMIT;
}

function handleShoppingTimeTickResponse(response) {
  if (!response || response.ok !== true || response.area !== "shopping") {
    shoppingTimeProbeFailures += 1;
    if (shoppingTimeProbeFailures >= SHOPPING_TIME_PROBE_FAILURE_LIMIT && !shoppingTimeStateUnknown) {
      shoppingTimeStateUnknown = true;
      applyShoppingState();
    }
    return;
  }

  shoppingTimeProbeFailures = 0;
  shoppingTimeStateUnknown = false;
  shoppingTimeLimitReached = response.limitReached === true;
  updateShoppingTimeBadge(response);
  if (shoppingTimeLimitReached) {
    applyShoppingState();
  } else {
    // Im selben Takt neu bestimmen: eine faellige Sperrzeit, Wartezeit oder
    // Monatsgrenze uebernimmt ohne offene Luecke bis zum Sekundentakt.
    removeShoppingOverlay(SHOPPING_TIME_OVERLAY_ID);
    applyShoppingState();
  }
}

// Restzeit-Kaestchen wie bei Social Media (gemeinsamer Baustein). Die Tick- und
// Stand-Antwort traegt usedSeconds und limitSeconds schon; bisher zeigte sie
// niemand an. Sichtbar nur, solange ein Tageslimit gesetzt und noch nicht
// erreicht ist - danach steht der Zeitvorhang.
function shoppingRemainingSeconds(response) {
  if (!response || !Number.isInteger(response.limitSeconds) || response.limitSeconds <= 0 ||
      response.limitReached === true) {
    return -1;
  }
  const used = Number.isInteger(response.usedSeconds) && response.usedSeconds >= 0 ? response.usedSeconds : 0;
  return Math.max(0, response.limitSeconds - used);
}

function updateShoppingTimeBadge(response) {
  const remaining = shoppingRemainingSeconds(response);
  if (remaining < 0 || !shoppingRules.dailyLimitEnabled || typeof purestateShowTimeBadge !== "function") {
    removeShoppingTimeBadge();
    return;
  }
  purestateShowTimeBadge(document, SHOPPING_TIME_BADGE_ID, purestateFormatRemaining(remaining));
}

function removeShoppingTimeBadge() {
  if (typeof purestateRemoveTimeBadge === "function") {
    purestateRemoveTimeBadge(document, SHOPPING_TIME_BADGE_ID);
  }
}

function currentMinuteOfDay() {
  const now = new Date();
  return now.getHours() * 60 + now.getMinutes();
}

function parseCurfewMinutes(text, fallback) {
  const match = /^(\d{1,2}):(\d{2})$/.exec(String(text || "").trim());
  if (!match) {
    return fallback;
  }
  const hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);
  if (hours > 23 || minutes > 59) {
    return fallback;
  }
  return hours * 60 + minutes;
}

// Read-only snapshot for the regression tests (script-level "let" is not
// reachable from outside the vm script scope).
globalThis.purestateShoppingRulesSnapshot = function () {
  return shoppingRules;
};

// Same wrap semantics as the Windows schedule (IsScheduleActiveAt): start==end
// means "off"; a window across midnight wraps.
globalThis.purestateShoppingIsInCurfew = function (nowMinutes, startText, endText) {
  const start = parseCurfewMinutes(startText, 22 * 60);
  const end = parseCurfewMinutes(endText, 6 * 60);
  if (start === end) {
    return false;
  }
  if (start < end) {
    return nowMinutes >= start && nowMinutes < end;
  }
  return nowMinutes >= start || nowMinutes < end;
};

function applyOrderToMonth(storeObj, yyyyMm, amountEuroOrNull) {
  if (!storeObj || typeof storeObj !== "object" || !/^\d{4}-\d{2}$/.test(String(yyyyMm || ""))) {
    return { orders: 0, spend: 0 };
  }
  const ordersKey = "purestateOrders:" + yyyyMm;
  const spendKey = "purestateSpend:" + yyyyMm;
  for (const key of Object.keys(storeObj)) {
    if ((key.startsWith("purestateOrders:") && key !== ordersKey) ||
        (key.startsWith("purestateSpend:") && key !== spendKey)) {
      delete storeObj[key];
    }
  }
  const currentOrders = Number.isInteger(storeObj[ordersKey]) && storeObj[ordersKey] >= 0 ? storeObj[ordersKey] : 0;
  const hasStoredSpend = Number.isInteger(storeObj[spendKey]) && storeObj[spendKey] >= 0;
  const currentSpend = hasStoredSpend ? storeObj[spendKey] : 0;
  const hasAmount = Number.isInteger(amountEuroOrNull) && amountEuroOrNull >= 0 && amountEuroOrNull <= 99999;
  const amount = hasAmount
    ? amountEuroOrNull
    : 0;
  const result = {
    orders: Math.min(Number.MAX_SAFE_INTEGER, currentOrders + 1),
    spend: Math.min(Number.MAX_SAFE_INTEGER, currentSpend + amount)
  };
  storeObj[ordersKey] = result.orders;
  if (hasStoredSpend || hasAmount) {
    storeObj[spendKey] = result.spend;
  } else {
    delete storeObj[spendKey];
  }
  return result;
}

function monthlyLimitReached(pack, orders, spend) {
  const source = pack && typeof pack === "object" && pack.shopping && typeof pack.shopping === "object"
    ? pack.shopping
    : (pack || {});
  const orderLimit = Number.isInteger(source.monthlyOrderLimit) && source.monthlyOrderLimit >= 1 && source.monthlyOrderLimit <= 99
    ? source.monthlyOrderLimit
    : 10;
  const budgetEuro = Number.isInteger(source.monthlyBudgetEuro) && source.monthlyBudgetEuro >= 1 && source.monthlyBudgetEuro <= 99999
    ? source.monthlyBudgetEuro
    : 200;
  return (source.monthlyOrderLimitEnabled === true && orders >= orderLimit) ||
    (source.monthlyBudgetEnabled === true && spend >= budgetEuro);
}

function pickReflectionQuestions(rng) {
  const random = typeof rng === "function" ? rng : Math.random;
  const available = SHOPPING_REFLECTION_QUESTIONS.slice();
  const selected = [];
  while (selected.length < 3 && available.length > 0) {
    const sample = Number(random());
    const normalized = Number.isFinite(sample) && sample >= 0 && sample < 1 ? sample : 0;
    const index = Math.min(available.length - 1, Math.floor(normalized * available.length));
    selected.push(available.splice(index, 1)[0]);
  }
  return selected;
}

// ---- Checkout delay -------------------------------------------------------

function localMonthKey(nowMs) {
  const date = new Date(nowMs === undefined ? Date.now() : nowMs);
  return String(date.getFullYear()).padStart(4, "0") + "-" + String(date.getMonth() + 1).padStart(2, "0");
}

function monthStateFromStore(storeObj, yyyyMm) {
  const orders = storeObj && storeObj["purestateOrders:" + yyyyMm];
  const spend = storeObj && storeObj["purestateSpend:" + yyyyMm];
  return {
    orders: Number.isInteger(orders) && orders >= 0 ? orders : 0,
    spend: Number.isInteger(spend) && spend >= 0 ? spend : 0
  };
}

function readShoppingStore(callback) {
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local && typeof chrome.storage.local.get === "function") {
      chrome.storage.local.get(null, (items) => {
        if (chrome.runtime && chrome.runtime.lastError) {
          callback(null);
          return;
        }
        callback(items && typeof items === "object" ? items : {});
      });
      return;
    }
  } catch {
  }
  if (!globalThis.__purestateShoppingMonthFallback) {
    globalThis.__purestateShoppingMonthFallback = {};
  }
  callback(globalThis.__purestateShoppingMonthFallback);
}

// Guard-authoritative month counters: the local chrome.storage values are a
// cache; the guard's persistent store (via the background relay) wins so
// clearing browser data no longer resets the monthly order/budget limits.
function sendShoppingRuntimeMessage(payload, callback) {
  try {
    if (typeof chrome !== "undefined" && chrome.runtime && typeof chrome.runtime.sendMessage === "function") {
      chrome.runtime.sendMessage(payload, (response) => {
        if (chrome.runtime && chrome.runtime.lastError) {
          callback(null);
          return;
        }
        callback(response || null);
      });
      return;
    }
  } catch {
  }
  callback(null);
}

function guardMonthStateFromResponse(response) {
  if (response && response.ok === true &&
      Number.isInteger(response.orders) && response.orders >= 0 &&
      Number.isInteger(response.spend) && response.spend >= 0) {
    return { orders: response.orders, spend: response.spend };
  }
  return null;
}

function reseedShoppingMonth(month, totals, done) {
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local && typeof chrome.storage.local.set === "function") {
      const values = {};
      values["purestateOrders:" + month] = totals.orders;
      values["purestateSpend:" + month] = totals.spend;
      chrome.storage.local.set(values, () => done());
      return;
    }
  } catch {
  }
  done();
}

function readShoppingMonthState(callback) {
  readShoppingStore((storeObj) => {
    const local = storeObj ? monthStateFromStore(storeObj, localMonthKey()) : null;
    sendShoppingRuntimeMessage({ type: "purestate.shoppingMonth" }, (response) => {
      const guard = guardMonthStateFromResponse(response);
      if (!guard) {
        // Der lokale Stand taugt zum Rechnen (fail-closed weiter unten), aber
        // nicht als Auskunft: er kann NIEDRIGER sein als der echte. Live
        // gesehen (2026-08-09): lokal 0 Bestellungen, im Guard 2 - die
        // Einblendung sagte "Bestellung 1 von 10" und beruhigte damit falsch.
        callback(local ? { orders: local.orders, spend: local.spend, stale: true } : null);
        return;
      }
      const base = local || { orders: 0, spend: 0 };
      const merged = {
        orders: Math.max(base.orders, guard.orders),
        spend: Math.max(base.spend, guard.spend)
      };
      reseedShoppingMonth(localMonthKey(), merged, () => callback(merged));
    });
  });
}

function shoppingDelayStorageKey() {
  return "purestateShoppingDelayUntil:" + String(location.hostname || "").toLowerCase().replace(/^www\./, "");
}

function readShoppingDelayUntil(callback) {
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local && typeof chrome.storage.local.get === "function") {
      const key = shoppingDelayStorageKey();
      chrome.storage.local.get([key], (items) => {
        const value = items && typeof items[key] === "number" ? items[key] : 0;
        callback(value);
      });
      return;
    }
  } catch {
  }
  callback(globalThis.__purestateShoppingDelayFallback || 0);
}

function writeShoppingDelayUntil(untilMs) {
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local && typeof chrome.storage.local.set === "function") {
      const entry = {};
      entry[shoppingDelayStorageKey()] = untilMs;
      chrome.storage.local.set(entry);
      return;
    }
  } catch {
  }
  globalThis.__purestateShoppingDelayFallback = untilMs;
}

function ensureShoppingDelayOverlay() {
  if (shoppingDelayOverlayPending || (document.getElementById &&
      (document.getElementById(SHOPPING_DELAY_OVERLAY_ID) || document.getElementById(SHOPPING_MONTHLY_OVERLAY_ID)))) {
    return;
  }
  shoppingDelayOverlayPending = true;
  readShoppingMonthState((monthState) => {
    if (!monthState && (shoppingRules.monthlyOrderLimitEnabled || shoppingRules.monthlyBudgetEnabled)) {
      shoppingDelayOverlayPending = false;
      showShoppingMonthlyLimitOverlay();
      return;
    }
    if (monthState && monthlyLimitReached(shoppingRules, monthState.orders, monthState.spend)) {
      shoppingDelayOverlayPending = false;
      showShoppingMonthlyLimitOverlay();
      return;
    }
    if (!shoppingRules.checkoutDelayEnabled) {
      shoppingDelayOverlayPending = false;
      showShoppingDelayOverlay(Date.now(), monthState || { orders: 0, spend: 0 });
      return;
    }
    readShoppingDelayUntil((until) => {
      shoppingDelayOverlayPending = false;
      const now = Date.now();
      if (until > 0 && until <= now && now - until <= SHOPPING_DELAY_GRACE_MS) {
        // Freigegeben, keine neue Einblendung - aber genau hier laufen die
        // spaeteren Schritte der Kasse durch, und einer davon traegt die
        // Summe, die auf der ersten Seite noch fehlte.
        settlePendingShoppingSpend();
        return; // released recently; let the multi-step checkout finish calmly
      }
      let target = until;
      if (!(target > now)) {
        target = now + shoppingRules.delayMinutes * 60 * 1000;
        writeShoppingDelayUntil(target);
      }
      showShoppingDelayOverlay(target, monthState || { orders: 0, spend: 0 });
    });
  });
}

function showShoppingDelayOverlay(untilMs, monthState) {
  const overlay = buildShoppingOverlay(
    SHOPPING_DELAY_OVERLAY_ID,
    "Kurz warten, dann entscheiden",
    "Dein Kauf bleibt möglich. Nimm dir die Wartezeit, die du dir selbst eingerichtet hast.",
    "dialog"
  );
  if (!overlay) {
    return;
  }
  const doc = overlay.purestateBox.ownerDocument;
  const theme = overlay.purestateTheme;
  const box = overlay.purestateBox;
  const actions = overlay.purestateActions;

  box.insertBefore(purestateCurtainText(doc, theme, pickReflectionQuestions(), "list"), actions);

  const state = monthState || { orders: 0, spend: 0 };
  let amountLine = null;
  let amountSettled = true;
  // Ohne Auskunft des Dienstes lieber keine Zahl als eine zu niedrige.
  const monthStateUnknown = state.stale === true &&
    (shoppingRules.monthlyOrderLimitEnabled || shoppingRules.monthlyBudgetEnabled);
  if (monthStateUnknown) {
    box.insertBefore(purestateCurtainText(doc, theme, "Monatsstand gerade nicht abrufbar", "meta"), actions);
  }
  if (!monthStateUnknown && shoppingRules.monthlyOrderLimitEnabled) {
    box.insertBefore(purestateCurtainText(doc, theme,
      "Bestellung " + (state.orders + 1) + " von " + shoppingRules.monthlyOrderLimit + " in diesem Monat", "meta"), actions);
  }
  if (shoppingRules.monthlyBudgetEnabled) {
    if (!monthStateUnknown) {
      box.insertBefore(purestateCurtainText(doc, theme,
        state.spend + " EUR von " + shoppingRules.monthlyBudgetEuro + " EUR in diesem Monat", "meta"), actions);
    }

    // Der Betrag kommt von der Seite, nicht mehr aus einem Eingabefeld. Eine
    // Zahl, die der Nutzer im Kaufmoment selbst eintraegt, kann jede
    // beliebige sein - und ein Budget, das man beim Ueberschreiten selbst
    // kleinrechnen kann, ist keines.
    const readAmount = readCheckoutAmount();
    amountSettled = readAmount !== null;
    amountLine = purestateCurtainText(doc, theme, readAmount === null
      ? SHOPPING_AMOUNT_PENDING_TEXT
      : "Dieser Kauf: " + readAmount + " EUR", "meta");
    box.insertBefore(amountLine, actions);
  }

  const countdown = purestateCurtainText(doc, theme, "", "count");
  countdown.setAttribute("role", "timer");
  box.insertBefore(countdown, actions);

  // Live gefunden (2026-08-09, obi.de): die Kasse rendert ihre Summe erst
  // Sekunden nach dem Aufbau der Einblendung. Gebucht wurde beim Klick
  // korrekt - "Weiter zum Kauf" liest neu -, angezeigt blieb aber "nicht
  // lesbar". Der Nutzer entscheidet dann gegen die Buchung, die gleich folgt.
  // ponytail: haengt am Countdown-Takt statt an einem eigenen Beobachter, und
  // liest nur jeden vierten Takt (alle 2 s). Die Lesung geht ueber bis zu
  // 20000 Elemente; jeder Takt waere auf grossen Kassen eine Bremse. Dieselbe
  // Obergrenze wie bei der Shop-Erkennung, damit es nur eine Zahl gibt.
  let amountTicks = 0;
  let amountRetriesLeft = SHOPPING_DETECT_MAX_RETRIES;

  const renderRemaining = () => {
    if (!amountSettled && amountLine && amountRetriesLeft > 0) {
      amountTicks += 1;
      if (amountTicks % 4 === 0) {
        amountRetriesLeft -= 1;
        const lateAmount = readCheckoutAmount();
        if (lateAmount !== null) {
          amountLine.textContent = "Dieser Kauf: " + lateAmount + " EUR";
          amountSettled = true;
        }
      }
    }
    const remaining = Math.max(0, Math.ceil((untilMs - Date.now()) / 1000));
    const minutes = String(Math.floor(remaining / 60)).padStart(2, "0");
    const seconds = String(remaining % 60).padStart(2, "0");
    countdown.textContent = minutes + ":" + seconds;
    if (remaining <= 0) {
      stopShoppingCountdown();
      addShoppingContinueButton(overlay);
    }
  };
  stopShoppingCountdown();
  renderRemaining();
  if (!overlay.purestateContinue) {
    shoppingDelayCountdownTimer = setInterval(renderRemaining, 500);
  }
}

function stopShoppingCountdown() {
  if (shoppingDelayCountdownTimer) {
    clearInterval(shoppingDelayCountdownTimer);
    shoppingDelayCountdownTimer = null;
  }
}

function addShoppingContinueButton(overlay) {
  if (overlay.purestateContinue || !overlay.purestateBox) {
    return;
  }
  const doc = overlay.purestateBox.ownerDocument;
  const proceed = purestateCurtainButton(doc, overlay.purestateTheme, "Weiter zum Kauf", "secondary");
  proceed.setAttribute("aria-label", "Wartezeit abgelaufen, weiter zum Kauf");
  proceed.addEventListener("click", (event) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    if (overlay.purestateOrderRecording) {
      return;
    }
    overlay.purestateOrderRecording = true;
    proceed.disabled = true;
    stopShoppingCountdown();
    // Erst hier lesen, nicht beim Aufbau der Einblendung: mehrstufige Kassen
    // aendern die Summe noch waehrend der Wartezeit.
    const amount = readCheckoutAmount();
    // War hier keine Summe zu holen, ist die Kasse mehrstufig: der Betrag
    // steht erst einen Schritt spaeter. Den Merker fuer den Nachtrag legt die
    // Hintergrundseite an, sobald die Bestellung ohne Betrag gemeldet wird -
    // also nur, wenn eine Monatsgrenze aktiv ist (EXT-A06).
    recordShoppingOrder(amount, (result) => {
      removeShoppingOverlay(SHOPPING_DELAY_OVERLAY_ID);
      if (!result || monthlyLimitReached(shoppingRules, result.orders, result.spend)) {
        showShoppingMonthlyLimitOverlay();
      }
    });
  }, true);
  overlay.purestateActions.appendChild(proceed);
  overlay.purestateContinue = proceed;
}

// Liefert den Gesamtbetrag der Seite in ganzen Euro, oder null. Gelesen wird
// nur die bereits geladene Seite; der Wert bleibt im Browserprofil und geht
// weder in config.json noch in Backups, Protokolle oder ans Netz.
function readCheckoutAmount() {
  if (typeof purestateReadCheckoutTotal !== "function") {
    return null;
  }
  try {
    return purestateReadCheckoutTotal(document);
  } catch {
    return null;
  }
}

// Traegt den Betrag einer schon gezaehlten Bestellung nach, sobald ihn eine
// spaetere Kassenseite hergibt. Zaehlt bewusst KEINE zweite Bestellung - der
// Guard bekommt dafuer usage-spend statt usage-order.
//
// EXT-A06: Pruefen, Buchen und Verbrauchen des Merkers macht die
// Hintergrundseite, nacheinander fuer alle Tabs. Der Tab liest nur die Summe
// und fragt vorher billig nach, ob ueberhaupt ein Merker fuer diese Kasse
// liegt. Ohne aktive Monatsgrenze wird nichts gemeldet (Vertrag V-2).
function settlePendingShoppingSpend() {
  if (shoppingSpendSettling ||
      !(shoppingRules.monthlyOrderLimitEnabled || shoppingRules.monthlyBudgetEnabled)) {
    return;
  }
  shoppingSpendSettling = true;
  readShoppingStore((storeObj) => {
    const marker = storeObj ? storeObj[SHOPPING_PENDING_SPEND_KEY] : null;
    const host = String(location.hostname || "").toLowerCase().replace(/^www\./, "");
    // Gleiche Kasse auch ueber Subdomains (www.shop.de -> checkout.shop.de);
    // die verbindliche Pruefung macht die Hintergrundseite.
    const related = typeof marker === "object" && marker !== null && typeof marker.host === "string" &&
      (marker.host === host ||
        (marker.host.includes(".") && host.endsWith("." + marker.host)) ||
        (host.includes(".") && marker.host.endsWith("." + host)));
    if (!marker || typeof marker !== "object" ||
        (typeof marker.host === "string" && !related)) {
      shoppingSpendSettling = false;
      return;
    }
    const amount = readCheckoutAmount();
    if (amount === null && marker.localBooked !== true) {
      shoppingSpendSettling = false;
      return; // diese Seite gibt noch nichts her, der naechste Takt fragt erneut
    }
    sendShoppingRuntimeMessage(
      { type: "purestate.shoppingSpend", amountEuro: amount, host: location.hostname },
      () => { shoppingSpendSettling = false; });
  });
}

function recordShoppingOrder(amountEuroOrNull, callback) {
  if (!shoppingRules.monthlyOrderLimitEnabled && !shoppingRules.monthlyBudgetEnabled) {
    callback({ orders: 0, spend: 0 });
    return;
  }
  readShoppingStore((storeObj) => {
    if (!storeObj) {
      callback(null);
      return;
    }
    const beforeKeys = new Set(Object.keys(storeObj));
    const month = localMonthKey();
    const result = applyOrderToMonth(storeObj, month, amountEuroOrNull);
    const removedKeys = [];
    for (const key of beforeKeys) {
      if (!Object.prototype.hasOwnProperty.call(storeObj, key)) {
        removedKeys.push(key);
      }
    }
    persistShoppingMonthState(storeObj, month, removedKeys, (ok) => {
      if (!ok) {
        callback(null);
        return;
      }
      const payload = { type: "purestate.shoppingOrder", host: location.hostname };
      if (Number.isInteger(amountEuroOrNull) && amountEuroOrNull >= 0 && amountEuroOrNull <= 99999) {
        payload.amountEuro = amountEuroOrNull;
      }
      sendShoppingRuntimeMessage(payload, (response) => {
        const guard = guardMonthStateFromResponse(response);
        if (!guard) {
          callback(result);
          return;
        }
        const merged = {
          orders: Math.max(result.orders, guard.orders),
          spend: Math.max(result.spend, guard.spend)
        };
        reseedShoppingMonth(month, merged, () => callback(merged));
      });
    });
  });
}

function persistShoppingMonthState(storeObj, month, removedKeys, callback) {
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local && typeof chrome.storage.local.set === "function") {
      const writeCurrent = () => {
        const values = {};
        values["purestateOrders:" + month] = storeObj["purestateOrders:" + month];
        if (Object.prototype.hasOwnProperty.call(storeObj, "purestateSpend:" + month)) {
          values["purestateSpend:" + month] = storeObj["purestateSpend:" + month];
        }
        chrome.storage.local.set(values, () => {
          callback(!(chrome.runtime && chrome.runtime.lastError));
        });
      };
      if (removedKeys.length > 0 && typeof chrome.storage.local.remove === "function") {
        chrome.storage.local.remove(removedKeys, () => {
          if (chrome.runtime && chrome.runtime.lastError) {
            callback(false);
            return;
          }
          writeCurrent();
        });
      } else {
        writeCurrent();
      }
      return;
    }
  } catch {
    callback(false);
    return;
  }
  globalThis.__purestateShoppingMonthFallback = storeObj;
  callback(true);
}

// ---- Curfew ---------------------------------------------------------------

function showShoppingCurfewOverlay() {
  if (document.getElementById && document.getElementById(SHOPPING_CURFEW_OVERLAY_ID)) {
    return;
  }
  buildShoppingOverlay(
    SHOPPING_CURFEW_OVERLAY_ID,
    "Shopping pausiert",
    "Deine Einstellung: Shopping-Pause bis " + shoppingRules.curfewEnd + " Uhr. Stöbern und Kaufen sind in diesem Fenster pausiert."
  );
}

function showShoppingTimeOverlay() {
  if (document.getElementById && document.getElementById(SHOPPING_TIME_OVERLAY_ID)) {
    return;
  }
  // EXT-001: Eigener Text fuer den unbekannten Zustand. "Tageszeit erreicht"
  // waere hier gelogen - der Nutzer soll wissen, dass Purestate gerade nicht
  // messen kann, und nicht glauben, sein Budget sei aufgebraucht.
  if (shoppingTimeStateUnknown) {
    buildShoppingOverlay(
      SHOPPING_TIME_OVERLAY_ID,
      "Zeitbudget nicht prüfbar",
      "Purestate kann das Zeitbudget gerade nicht prüfen und pausiert Shopping so lange. Läuft der Schutzdienst wieder, geht es sofort weiter."
    );
    return;
  }
  buildShoppingOverlay(
    SHOPPING_TIME_OVERLAY_ID,
    "Tageszeit für Shopping erreicht",
    "Morgen geht es weiter."
  );
}

function showShoppingMonthlyLimitOverlay() {
  if (document.getElementById && document.getElementById(SHOPPING_MONTHLY_OVERLAY_ID)) {
    return;
  }
  buildShoppingOverlay(
    SHOPPING_MONTHLY_OVERLAY_ID,
    "Monatslimit erreicht",
    "Dein Monatslimit ist erreicht. Änderbar in der Purestate-App."
  );
}

// ---- Overlay building (Vorhang-Baukasten aus adult-search-terms.js) -------

function buildShoppingOverlay(overlayId, titleText, messageText, titleSize) {
  const doc = document;
  if (!doc.documentElement || (doc.getElementById && doc.getElementById(overlayId))) {
    return null;
  }
  if (typeof purestateInstantHide === "function") {
    purestateInstantHide(doc, overlayId + "-style");
  }
  const theme = purestateCurtainTheme(doc);

  doc.documentElement.style.setProperty("overflow", "hidden", "important");
  if (doc.body) {
    doc.body.style.setProperty("overflow", "hidden", "important");
  }

  const overlay = doc.createElement("div");
  overlay.id = overlayId;
  overlay.setAttribute("role", "alertdialog");
  overlay.setAttribute("aria-live", "assertive");
  overlay.setAttribute("aria-label", "Purestate " + titleText);
  overlay.setAttribute("aria-labelledby", overlayId + "-title");
  overlay.setAttribute("tabindex", "-1");
  // EXT-A05: eigener Scroll + margin:auto statt abschneidender Zentrierung.
  overlay.style.cssText = purestateCurtainOverlayCss(theme);

  const dialog = titleSize === "dialog";
  const box = purestateCurtainColumn(doc);
  box.appendChild(purestateCurtainBars(doc, theme, dialog ? "sm" : "lg"));
  box.appendChild(purestateCurtainText(doc, theme, "Purestate", "label"));
  box.appendChild(purestateCurtainTitle(doc, theme, overlayId + "-title", titleText, dialog ? "dialog" : "curtain"));
  box.appendChild(purestateCurtainText(doc, theme, messageText, "detail"));

  const back = purestateCurtainButton(doc, theme, "Zurück", "primary");
  back.setAttribute("aria-label", "Zurück zur vorherigen Seite");
  back.addEventListener("click", (event) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    try {
      const view = doc.defaultView || (typeof window !== "undefined" ? window : null);
      if (!view) {
        return;
      }
      const origin = view.location.origin;
      // Sperrzeit und Tageslimit decken den ganzen Shop ab: dessen Startseite
      // zeigt denselben Vorhang wieder (live 2026-09-18). Deshalb neutral.
      if (view.history && view.history.length > 1) {
        view.history.back();
        view.setTimeout(() => {
          try {
            if (view.location.origin === origin) {
              view.location.assign("about:blank");
            }
          } catch {
          }
        }, 250);
      } else {
        view.location.assign("about:blank");
      }
    } catch {
    }
  }, true);
  const actions = purestateCurtainActions(doc);
  actions.appendChild(back);
  box.appendChild(actions);

  overlay.appendChild(box);
  (doc.body || doc.documentElement).appendChild(overlay);
  overlay.purestateBox = box;
  overlay.purestateBack = back;
  overlay.purestateActions = actions;
  overlay.purestateTheme = theme;
  if (typeof purestateHoldOverlayFocus === "function") {
    purestateHoldOverlayFocus(doc, overlay, back);
  }
  return overlay;
}

function removeShoppingOverlay(overlayId) {
  if (!document.getElementById) {
    return;
  }
  const overlay = document.getElementById(overlayId);
  if (!overlay) {
    return;
  }
  if (overlayId === SHOPPING_DELAY_OVERLAY_ID) {
    stopShoppingCountdown();
  }
  if (overlay.parentElement) {
    overlay.parentElement.removeChild(overlay);
  }
  if (typeof purestateRemoveInstantHide === "function") {
    purestateRemoveInstantHide(document, overlayId + "-style");
  }
  // Erst nach dem Sichtbarmachen: ein unsichtbarer Knopf nimmt keinen Fokus.
  if (typeof purestateReleaseOverlayFocus === "function") {
    purestateReleaseOverlayFocus(overlay);
  }
  if (document.documentElement) {
    document.documentElement.style.removeProperty("overflow");
  }
  if (document.body) {
    document.body.style.removeProperty("overflow");
  }
}

// ---- Stimulus damping -----------------------------------------------------

function applyShoppingDamping() {
  if (!shoppingRules.enabled || !shoppingRules.stimulusDampingEnabled || !document.body || typeof document.querySelectorAll !== "function") {
    return;
  }
  const candidates = document.querySelectorAll("span,div,p,b,strong,em,li");
  for (const element of candidates) {
    try {
      if (element.getAttribute(SHOPPING_DAMPED_ATTR) === "1") {
        continue;
      }
      const text = element.textContent || "";
      if (text.length === 0 || text.length > 240) {
        continue;
      }
      if (element.children && element.children.length > 3) {
        continue;
      }
      if (!purestateShoppingDampingText.test(text)) {
        continue;
      }
      // Nur den Treffer verstecken, nicht seinen Container. Live gefunden
      // (2026-08-09, bergfreunde.de/sale): ein 355x112 grosser
      // Navigationsblock war unsichtbar, weil einer von sechs Menuepunkten
      // "Black Friday" hiess - fuenf harmlose Links gingen mit. Traegt ein
      // Nachfahre denselben Treffer, versteckt ihn dieser Durchlauf selbst.
      if (dampingHitInside(element)) {
        continue;
      }
      element.setAttribute(SHOPPING_DAMPED_ATTR, "1");
      element.style.setProperty("visibility", "hidden", "important");
    } catch {
    }
  }
}

// Laeuft nur fuer Elemente, deren Text schon getroffen hat - also selten, und
// deshalb ohne eigenen Deckel.
function dampingHitInside(element) {
  if (!element || typeof element.querySelectorAll !== "function") {
    return false;
  }
  for (const child of element.querySelectorAll("span,div,p,b,strong,em,li")) {
    const text = child.textContent || "";
    if (text.length > 0 && text.length <= 240 && purestateShoppingDampingText.test(text)) {
      return true;
    }
  }
  return false;
}
