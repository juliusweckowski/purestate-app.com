using System;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // The former kitchen-sink "Einstellungen" dialog, split into two focused
    // dialogs: Internetschutz (blocklist, DNS filter, bypass protection) and
    // Zeitplan/Pausenregeln. Both save through the existing
    // Support.SetFeatureSettings call; fields the respective dialog does not
    // show are passed through unchanged from the current config.
    internal sealed partial class AdminForm
    {
        private void ShowInternetProtectionSettings()
        {
            AppConfig config = Support.LoadConfig();
            using (DialogShell shell = new DialogShell(theme, "Internetschutz",
                "Diese Grundschutz-Bausteine wirken zusammen. Für den Alltag ist es am sichersten, alle eingeschaltet zu lassen.",
                "Stellt Sperrliste, Internetfilter und Umgehungsschutz ein.", true))
            {
                shell.AddSection("Webseiten blockieren");
                CheckBox hosts = Ui.Check(theme, "Webseiten auf diesem PC blockieren", config.HostsEnabled,
                    "Sperrt bekannte Webseiten direkt auf diesem Gerät (lokale Sperrliste).");
                shell.Add(hosts);
                CheckBox dns = Ui.Check(theme, "Zusätzlichen Internetfilter verwenden", config.FamilyDnsEnabled,
                    "Leitet Internet-Anfragen über einen Filterdienst, der unerwünschte Webseiten aussortiert (DNS-Filter).");
                shell.Add(dns);
                ComboBox dnsProfile = new ComboBox
                {
                    DropDownStyle = ComboBoxStyle.DropDownList,
                    Width = 300,
                    Font = Ui.FontBody
                };
                Ui.StyleInput(theme, dnsProfile);
                dnsProfile.Items.AddRange(Support.DnsProfileLabels());
                dnsProfile.SelectedItem = Support.DnsProfileLabel(config.DnsProfile);
                if (dnsProfile.SelectedIndex < 0)
                {
                    dnsProfile.SelectedIndex = 0;
                }
                Ui.SetAccessibility(dnsProfile, "Filterstärke", "Wählt, wie streng der zusätzliche Internetfilter arbeitet.", AccessibleRole.ComboBox);
                FlowLayoutPanel dnsRow = shell.Row(Ui.WrapLabel(theme, "Filterstärke:", 100, true), dnsProfile);
                dnsRow.Padding = new Padding(24, 0, 0, 0);
                shell.Add(dnsRow);
                Ui.BindVisibility(dns, dnsRow);

                // Der Filteranbieter kann den eingeschraenkten YouTube-Modus selbst
                // erzwingen (Befund 2026-10-06) - dann ist er an, obwohl der Schalter
                // weiter unten aus ist. Der Hinweis steht nur beim betroffenen Profil.
                Label dnsYouTubeHint = Ui.WrapLabel(theme,
                    "Hinweis: CleanBrowsing Family erzwingt zusätzlich den eingeschränkten Modus auf YouTube - unabhängig vom Schalter weiter unten. Cloudflare Family und OpenDNS FamilyShield tun das nicht.",
                    shell.InnerWidth - 48, true);
                dnsYouTubeHint.Margin = new Padding(24, 0, 0, Ui.GapSmall);
                shell.Add(dnsYouTubeHint);
                Action applyDnsYouTubeHint = delegate
                {
                    dnsYouTubeHint.Visible = dns.Checked &&
                        Support.DnsProfileForcesYouTubeRestrict(dnsProfile.SelectedItem as string);
                };
                dns.CheckedChanged += delegate { applyDnsYouTubeHint(); };
                dnsProfile.SelectedIndexChanged += delegate { applyDnsYouTubeHint(); };
                applyDnsYouTubeHint();

                shell.AddSection("Browser und Umgehung");
                CheckBox browser = Ui.Check(theme, "Browser-Schutz auf unterstützten Webseiten (immer aktiv)", true,
                    "Pflichtbestandteil des Schutzes; kann nicht ausgeschaltet werden.");
                browser.Enabled = false;
                shell.Add(browser);
                shell.AddHint("Der Browser-Schutz ist Pflicht, damit gemischte Webseiten wie Reddit oder X gefiltert werden können.");
                CheckBox bypass = Ui.Check(theme, "Umgehung über VPN, Tor oder Proxy blockieren", config.BypassBlockingEnabled,
                    "Blockiert bekannte Programme und Wege, mit denen Sperren umgangen werden.");
                shell.Add(bypass);
                CheckBox unsupportedBrowsers = Ui.Check(theme, "Nicht unterstützte Browser sperren", config.UnsupportedBrowserBlockingEnabled,
                    "Sperrt Browser, in denen Purestate keinen Schutz erzwingen kann.");
                shell.Add(unsupportedBrowsers);
                CheckBox tamper = Ui.Check(theme, "Schutz-Einstellungen gegen Änderungen absichern", config.TamperProtectionEnabled,
                    "Stellt Browser- und Proxy-Einstellungen automatisch wieder her, wenn sie verändert werden.");
                shell.Add(tamper);
                CheckBox youTubeRestrict = Ui.Check(theme, "YouTube im eingeschränkten Modus", config.YouTubeRestrictEnabled,
                    "Blendet Videos aus, die YouTube als nicht jugendfrei einstuft. Trifft auch Harmloses - abschaltbar, ohne dass der übrige Schutz wegfällt.");
                shell.Add(youTubeRestrict);

                shell.SaveButton.Click += delegate
                {
                    bool hostsChecked = hosts.Checked;
                    bool dnsChecked = dns.Checked;
                    string dnsProfileValue = Support.DnsProfileFromLabel(dnsProfile.SelectedItem as string);
                    bool bypassChecked = bypass.Checked;
                    bool unsupportedBrowsersChecked = unsupportedBrowsers.Checked;
                    bool tamperChecked = tamper.Checked;
                    bool youTubeRestrictChecked = youTubeRestrict.Checked;

                    if (!ConfirmPassword("Internetschutz speichern", shell))
                    {
                        return;
                    }

                    RunAction("Internetschutz speichern", shell, delegate
                    {
                        AppConfig current = Support.LoadConfig();
                        Support.SetFeatureSettingsGuarded(
                            hostsChecked, dnsChecked, dnsProfileValue,
                            bypassChecked, unsupportedBrowsersChecked, tamperChecked,
                            youTubeRestrictChecked,
                            current.LockdownModeEnabled, current.PauseCooldownEnabled,
                            current.ScheduleEnabled, current.StrictModeEnabled,
                            current.ScheduleStart, current.ScheduleEnd,
                            Support.TrustedLocalNow(), false);
                        Support.ReapplyProtection();
                    }, "Internetschutz: Änderungen gespeichert.");
                };

                shell.FinishLayout();
                shell.Shown += delegate { hosts.Focus(); };
                shell.ShowDialog(this);
            }
        }

        private void ShowScheduleSettings()
        {
            AppConfig config = Support.LoadConfig();
            using (DialogShell shell = new DialogShell(theme, "Zeitplan und Pausenregeln",
                "Hier legst du fest, wann der Schutz automatisch aktiv ist und ob Pausieren erlaubt bleibt.",
                "Stellt Zeitplan, Sperrmodus und Pausenregeln ein.", true))
            {
                // DESK-03: Zwei unabhaengige Checkboxen versprachen etwas anderes,
                // als die gespeicherten Flags tun (Wartezeit wirkt nur im
                // Sperrmodus; "komplett verbieten" + Wartezeit erlaubte Pausen).
                // Drei Modi, abgebildet auf dieselben Flags - die Durchsetzung in
                // Support.SetProtectionPaused bleibt unveraendert.
                shell.AddSection("Pausenregeln");
                shell.AddHint("Legt fest, wie schnell du den Schutz selbst pausieren kannst. Während eines Zeitplans mit strengeren Regeln ist Pausieren immer gesperrt.");
                int storedPauseMode = Support.PauseModeFromFlags(config.LockdownModeEnabled, config.PauseCooldownEnabled);
                RadioButton pauseImmediate = Ui.Radio(theme, "Pausieren sofort möglich", storedPauseMode == Support.PauseModeImmediate,
                    "Nach der Passworteingabe pausiert der Schutz sofort.");
                RadioButton pauseAfterCooldown = Ui.Radio(theme, "Pausieren nach 10 Minuten Wartezeit", storedPauseMode == Support.PauseModeAfterCooldown,
                    "Die erste Anfrage startet eine Wartezeit von 10 Minuten. Danach kannst du pausieren.");
                RadioButton pauseForbidden = Ui.Radio(theme, "Pausieren nicht möglich (Sperrmodus)", storedPauseMode == Support.PauseModeForbidden,
                    "Solange der Schutz aktiv sein soll, lässt er sich nicht pausieren. Diese Regel zu lockern braucht die Frist für Lockerungen.");
                shell.Add(pauseImmediate);
                shell.Add(pauseAfterCooldown);
                shell.Add(pauseForbidden);

                shell.AddSection("Täglicher Zeitplan");
                CheckBox schedule = Ui.Check(theme, "Schutz jeden Tag automatisch aktivieren", config.ScheduleEnabled,
                    "Der Schutz schaltet sich im gewählten Zeitfenster von selbst ein.");
                shell.Add(schedule);
                ComboBox scheduleStart = Ui.TimeCombo(config.ScheduleStart, "22:00", "Beginn des Zeitplans");
                ComboBox scheduleEnd = Ui.TimeCombo(config.ScheduleEnd, "06:00", "Ende des Zeitplans");
                FlowLayoutPanel scheduleRow = shell.Row(Ui.WrapLabel(theme, "Von", 40, true), scheduleStart, Ui.WrapLabel(theme, "bis", 40, true), scheduleEnd, Ui.WrapLabel(theme, "Uhr (auch über Mitternacht möglich)", 260, true));
                scheduleRow.Padding = new Padding(24, 0, 0, 0);
                shell.Add(scheduleRow);
                Label scheduleError = shell.AddErrorLine();
                CheckBox strict = Ui.Check(theme, "Während des Zeitplans strengere Regeln verwenden", config.StrictModeEnabled,
                    "Im Zeitplan-Fenster gelten zusätzlich strengere Schutzregeln.");
                strict.Margin = new Padding(24, 0, 0, 4);
                shell.Add(strict);
                Ui.BindVisibility(schedule, scheduleRow, strict);

                shell.SaveButton.Click += delegate
                {
                    if (schedule.Checked)
                    {
                        bool startValid = Support.IsValidScheduleTimeText(scheduleStart.Text);
                        bool endValid = Support.IsValidScheduleTimeText(scheduleEnd.Text);
                        if (!startValid || !endValid)
                        {
                            shell.ShowError(scheduleError, "Bitte gib die Zeiten im Format 22:00 ein.", startValid ? scheduleEnd : scheduleStart);
                            return;
                        }
                        if (string.Equals(scheduleStart.Text.Trim(), scheduleEnd.Text.Trim(), StringComparison.Ordinal))
                        {
                            shell.ShowError(scheduleError, "Start und Ende dürfen nicht gleich sein.", scheduleEnd);
                            return;
                        }
                    }
                    shell.ClearError(scheduleError);

                    int pauseModeValue = pauseForbidden.Checked
                        ? Support.PauseModeForbidden
                        : (pauseAfterCooldown.Checked ? Support.PauseModeAfterCooldown : Support.PauseModeImmediate);
                    bool scheduleChecked = schedule.Checked;
                    bool strictChecked = strict.Checked;
                    string scheduleStartText = scheduleStart.Text;
                    string scheduleEndText = scheduleEnd.Text;

                    if (!ConfirmPassword("Zeitplan speichern", shell))
                    {
                        return;
                    }

                    RunAction("Zeitplan speichern", shell, delegate
                    {
                        AppConfig current = Support.LoadConfig();
                        // Gleicher Modus wie gespeichert = beide Flags unveraendert,
                        // damit das Gate keine Aenderung sieht, die niemand gemacht hat.
                        bool lockdownValue;
                        bool cooldownValue;
                        Support.PauseFlagsForMode(pauseModeValue, current.LockdownModeEnabled, current.PauseCooldownEnabled,
                            out lockdownValue, out cooldownValue);
                        Support.SetFeatureSettingsGuarded(
                            current.HostsEnabled, current.FamilyDnsEnabled, current.DnsProfile,
                            current.BypassBlockingEnabled, current.UnsupportedBrowserBlockingEnabled, current.TamperProtectionEnabled,
                            current.YouTubeRestrictEnabled,
                            lockdownValue, cooldownValue,
                            scheduleChecked, strictChecked,
                            scheduleStartText, scheduleEndText,
                            Support.TrustedLocalNow(), false);
                        Support.ReapplyProtection();
                    }, "Zeitplan und Pausenregeln: Änderungen gespeichert.");
                };

                shell.FinishLayout();
                shell.Shown += delegate { (pauseForbidden.Checked ? pauseForbidden : (pauseAfterCooldown.Checked ? pauseAfterCooldown : pauseImmediate)).Focus(); };
                shell.ShowDialog(this);
            }
        }
    }
}
