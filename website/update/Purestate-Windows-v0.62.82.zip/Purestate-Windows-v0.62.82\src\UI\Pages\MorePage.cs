using System;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // "Mehr" page: everything that is needed rarely. Website lists, backup,
    // clearly separated technical tools, the dev-only block and - at the very
    // bottom - the one destructive action.
    internal sealed partial class AdminForm
    {
        private void BuildMorePage()
        {
            TableLayoutPanel page = CreatePage("more");
            AddPageTitle(page, "Mehr");
            AddPageHint(page, "Webseitenlisten, Sicherung und technische Werkzeuge.");

            AddSectionTitle(page, "Eigene Webseitenlisten");
            AddActionRow(page, "Gesperrte Webseiten verwalten",
                "Eigene Webseiten ansehen, hinzufügen oder entfernen, die Purestate zusätzlich sperrt.",
                "Verwalten", delegate { ShowDomainManager(); }, false);
            AddActionRow(page, "Erlaubte Webseiten verwalten",
                "Ausnahmen ansehen, hinzufügen oder entfernen, die trotz Sperren erreichbar bleiben.",
                "Verwalten", delegate { ShowAllowListManager(); }, false);
            AddActionRow(page, "Sperrliste aus Datei übernehmen",
                "Liest gesperrte Webseiten aus einer Textdatei ein und fügt sie hinzu.",
                "Übernehmen", delegate { ImportBlockList(); }, false);
            AddActionRow(page, "Webseite testen",
                "Prüft, ob eine bestimmte Webseite gerade gesperrt oder erlaubt ist.",
                "Testen", delegate { TestDomain(); }, false);

            AddSectionTitle(page, "Sicherung");
            AddActionRow(page, "Backup erstellen",
                "Speichert deine Einstellungen und Webseitenlisten in einer Datei.",
                "Erstellen", delegate { ExportBackup(); }, false);
            AddActionRow(page, "Backup wiederherstellen",
                "Ersetzt die aktuellen Einstellungen durch ein früher erstelltes Backup.",
                "Wiederherstellen", delegate { ImportBackup(); }, false);

            AddSectionTitle(page, "Version und Updates");
            AddActionRow(page, "Installierte Version " + Support.AppVersion,
                "Fragt purestate-app.com, ob es eine neuere Version gibt. Einmal am Tag tut Purestate das auch von selbst.",
                "Nach Updates suchen", delegate { CheckAndShowUpdate(); }, false);

            AddSectionTitle(page, "Technische Werkzeuge");
            AddPageHint(page, "Diese Funktionen werden im normalen Alltag nicht benötigt. Sie helfen bei der Fehlersuche, wenn etwas nicht funktioniert.");
            AddActionRow(page, "Technischen Statusbericht erstellen",
                "Erstellt einen kopierbaren Bericht mit Status und Richtlinien.",
                "Erstellen", delegate { ShowDiagnostics(); }, false);
            AddActionRow(page, "Protokolle anzeigen",
                "Zeigt die letzten Aktivitäts-, Sicherheits- und Dienstmeldungen.",
                "Anzeigen", delegate { ShowLogs(); }, false);
            AddActionRow(page, "Installation prüfen",
                "Prüft, ob Dienst, Regeln und Dateien korrekt eingerichtet sind.",
                "Prüfen", delegate { ShowHealth(); }, false);
            AddActionRow(page, "Schutz automatisch testen",
                "Prüft, ob die aktivierten Schutzarten wirklich greifen.",
                "Testen", delegate { ShowProtectionTest(); }, false);
            AddActionRow(page, "Webseitenlisten auf Fehler prüfen",
                "Prüft gesperrte und erlaubte Webseiten auf Fehler und Duplikate.",
                "Prüfen", delegate { ShowRuleAudit(); }, false);
            AddActionRow(page, "Programmdateien überprüfen",
                "Verifiziert die installierten Purestate-Dateien per Prüfsumme.",
                "Prüfen", delegate { ShowIntegrityCheck(); }, false);
            AddActionRow(page, "Mögliche Umgehungsprogramme prüfen",
                "Sucht nach Hinweisen auf VPN, Tor, Proxy und Browser-Umgehung.",
                "Prüfen", delegate { ShowBypassCheck(); }, false);
            AddActionRow(page, "Purestate reparieren",
                "Stellt Dienst, Watchdog und Schutzregeln wieder her.",
                "Reparieren", delegate { RepairApp(); }, false);

            // ENS-001: Der Dev-Modus uebergibt die Companion-Vertrauensrolle.
            // Im ausgelieferten Bau gibt es ihn nicht - der Eintrag waere sonst
            // eine Einladung, die nur das Passwort kostet.
            if (Support.DevBuild)
            {
                AddSectionTitle(page, "Nur für Entwicklung");
                AddActionRow(page, "Dev-Modus öffnen",
                    "Vertraut testweise einer nicht-offiziellen Browser-Erweiterung. Nur für Entwickler.",
                    "Öffnen", delegate { ShowDevCompanionMode(); }, false);
            }

            AddSectionTitle(page, "Gefahrenzone");
            AddActionRow(page, "Purestate deinstallieren",
                "Entfernt Purestate von diesem Gerät. Passwortgeschützt, mit Wartezeit.",
                "Deinstallieren", delegate { LaunchUninstaller(); }, true);
        }

        // DESK-09: Berichte starten Prozesse und lesen Dateien - das lief
        // synchron und fror das Fenster ein. Jetzt im Hintergrund ueber
        // RunAction, der Bericht erscheint danach.
        private void ShowReport(string title, Func<string> build)
        {
            string report = null;
            RunAction(title, delegate { report = build(); }, delegate (bool success)
            {
                if (success)
                {
                    ShowTextDialog(title, report, true);
                }
            });
        }

        private void ShowDiagnostics()
        {
            ShowReport("Technischer Statusbericht", delegate
            {
                try
                {
                    return Support.BuildDiagnosticReport();
                }
                catch (Exception ex)
                {
                    // UI-002: Hier stand nur ex.Message - englischer Systemtext
                    // ohne Zusammenhang. Der Bericht ist ohnehin das Fenster fuer
                    // technische Angaben, also bleiben sie drin; davor steht jetzt
                    // ein Satz, der sagt, was das fuer den Nutzer bedeutet.
                    return "Der Statusbericht konnte nicht erstellt werden." + Environment.NewLine +
                        "Das heisst nicht, dass der Schutz nicht laeuft - nur der Bericht ist " +
                        "fehlgeschlagen. Unter \"Mehr\" kannst du es erneut versuchen." + Environment.NewLine +
                        Environment.NewLine +
                        "Technische Angaben:" + Environment.NewLine + ex;
                }
            });
        }

        private void ShowLogs()
        {
            ShowReport("Protokolle", delegate { return Support.ReadRecentLogs(80); });
        }

        private void ShowHealth()
        {
            ShowReport("Installationsprüfung", Support.BuildHealthReport);
        }

        private void ShowBypassCheck()
        {
            ShowReport("Prüfung auf Umgehungsprogramme", Support.BuildBypassReport);
        }

        private void ShowProtectionTest()
        {
            ShowReport("Automatischer Schutztest", Support.BuildProtectionTestReport);
        }

        private void ShowRuleAudit()
        {
            ShowReport("Prüfung der Webseitenlisten", Support.BuildRuleAuditReport);
        }

        private void ShowIntegrityCheck()
        {
            ShowReport("Prüfung der Programmdateien", Support.BuildIntegrityReport);
        }
    }
}
