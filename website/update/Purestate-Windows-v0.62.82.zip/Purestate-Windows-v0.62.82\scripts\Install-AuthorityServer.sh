#!/usr/bin/env bash
# First installation of the self-contained Linux x64 Authority build.
# Usage: sudo bash Install-AuthorityServer.sh /absolute/path/to/published-build
# This does not expose the service publicly or modify SSH authentication.
set -euo pipefail
umask 077

[[ $EUID -eq 0 ]] || { echo 'Run this installer with sudo.' >&2; exit 1; }
[[ $# -eq 1 ]] || { echo 'Supply the published build directory.' >&2; exit 1; }
source_dir=$(realpath -- "$1")
[[ $(uname -m) == x86_64 ]] || { echo 'An x86_64 server is required.' >&2; exit 1; }
for item in Purestate.Authority Purestate.Authority.dll libhostfxr.so libcoreclr.so; do
    [[ -f "$source_dir/$item" ]] || { echo "Missing build file: $item" >&2; exit 1; }
done
for target in /opt/purestate-authority /var/lib/purestate-authority /etc/systemd/system/purestate-authority.service; do
    [[ ! -e $target ]] || { echo "Already exists; refusing to overwrite: $target" >&2; exit 1; }
done
if getent passwd purestate-authority >/dev/null; then
    echo 'The service account already exists; inspect the previous installation.' >&2
    exit 1
fi

useradd --system --user-group --home-dir /var/lib/purestate-authority --no-create-home --shell /usr/sbin/nologin purestate-authority
install -d -m 0755 /opt/purestate-authority
cp -a -- "$source_dir/." /opt/purestate-authority/
chown -R root:root /opt/purestate-authority
find /opt/purestate-authority -type d -exec chmod 0755 {} +
find /opt/purestate-authority -type f -exec chmod 0644 {} +
chmod 0755 /opt/purestate-authority/Purestate.Authority
install -d -m 0700 -o purestate-authority -g purestate-authority /var/lib/purestate-authority

cat > /etc/systemd/system/purestate-authority.service <<'UNIT'
[Unit]
Description=Purestate Authority
After=network.target

[Service]
Type=simple
User=purestate-authority
Group=purestate-authority
WorkingDirectory=/opt/purestate-authority
ExecStart=/opt/purestate-authority/Purestate.Authority --urls=http://127.0.0.1:5199 --Authority:DataDirectory=/var/lib/purestate-authority
Environment=ASPNETCORE_ENVIRONMENT=Production
Environment=Logging__LogLevel__Default=Warning
Environment=Logging__LogLevel__Microsoft=Warning
UMask=0077
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
PrivateDevices=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/purestate-authority
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
RestrictAddressFamilies=AF_UNIX AF_INET AF_INET6
CapabilityBoundingSet=

[Install]
WantedBy=multi-user.target
UNIT
chmod 0644 /etc/systemd/system/purestate-authority.service
systemd-analyze verify /etc/systemd/system/purestate-authority.service
systemctl daemon-reload
systemctl enable --now purestate-authority.service

# Invalid public key: exercises the route and initializes the real database
# without enrolling a device or creating a license.
for attempt in {1..20}; do
    status=$(curl --silent --output /dev/null --write-out '%{http_code}' --max-time 2 \
        -H 'Content-Type: application/json' -d '{"token":"installation-check","pubKey":"invalid"}' \
        http://127.0.0.1:5199/enroll) || status=000
    if [[ $status == 400 ]]; then
        systemctl is-active --quiet purestate-authority.service
        stat -c '%a %U %n' /var/lib/purestate-authority /var/lib/purestate-authority/authority.key /var/lib/purestate-authority/authority.db
        echo 'Purestate Authority installed and checked on 127.0.0.1:5199.'
        exit 0
    fi
    sleep 1
done
echo 'Service check failed. Inspect: sudo journalctl -u purestate-authority -n 40' >&2
exit 1
