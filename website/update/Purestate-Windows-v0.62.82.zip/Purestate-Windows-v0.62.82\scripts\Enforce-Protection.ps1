param(
    [switch]$Quiet,
    [switch]$BrowserOnly,
    [switch]$Reconcile,
    [switch]$SelfTest
)

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\Common.ps1"

if ($SelfTest) {
    $selfTestDataDir = Join-Path ([System.IO.Path]::GetTempPath()) ("Purestate-EnforceSelfTest-" + [guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Path $selfTestDataDir -Force | Out-Null
    $script:DataDir = $selfTestDataDir
    $script:ConfigPath = Join-Path $script:DataDir "config.json"
    $script:IntegrityKeyPath = Join-Path $script:DataDir "integrity.key"
    $script:DnsBackupPath = Join-Path $script:DataDir "dns-backup.json"
    $script:ProxyBackupPath = Join-Path $script:DataDir "proxy-backup.json"
    $script:BrowserCompanionStatePath = Join-Path $script:DataDir "browser-companion-state.json"
    $script:ManagedListRecordPath = Join-Path $script:DataDir "managed-url-lists.json"
    $script:LogPath = Join-Path $script:DataDir "activity.log"
    $script:SecurityLogPath = Join-Path $script:DataDir "security.log"

    $domains = Get-DomainList
    if ($domains.Count -lt 250) {
        throw "Domain list is unexpectedly short."
    }

    $mixedSitePatterns = Get-MixedSiteUrlPatterns
    if ($mixedSitePatterns.Count -lt 700) {
        throw "Mixed-site URL rule list is unexpectedly short."
    }

    if ($mixedSitePatterns -notcontains "*://*.reddit.com/r/*porn*") {
        throw "Mixed-site URL rule list is missing the Reddit path check."
    }

    if ($mixedSitePatterns -notcontains "*://reddit.com/r/*gonewild*" -or
        $mixedSitePatterns -notcontains "*://*.reddit.com/r/*gonewild*") {
        throw "Mixed-site URL rule list is missing the Reddit NSFW community wildcard checks."
    }

    if ($mixedSitePatterns -notcontains "*://www.google.*/search*porn*") {
        throw "Mixed-site URL rule list is missing the search query check."
    }

    if ($mixedSitePatterns -notcontains "*://www.tiktok.com/search*porn*") {
        throw "Mixed-site URL rule list is missing the TikTok search check."
    }

    if ($mixedSitePatterns -notcontains "*://www.instagram.com/explore/tags/*nsfw*") {
        throw "Mixed-site URL rule list is missing the Instagram tag check."
    }

    if (Test-ProtectionAreaEnabled -Area "gambling") {
        if ((Get-ChromiumFailClosedFilters) -notcontains "google.com") {
            throw "Gambling fail-closed search coverage is missing."
        }
    }

    $failClosedPatterns = @(Merge-BrowserUrlPatterns -BasePatterns $mixedSitePatterns -FailClosed $true)
    if ($failClosedPatterns.Count -ne 1000 -or
        $failClosedPatterns -notcontains "*://*.reddit.com/*" -or
        $failClosedPatterns -notcontains "*://*.x.com/*" -or
        $failClosedPatterns -notcontains "*://*.bsky.app/*") {
        throw "Browser fail-closed rules are missing or exceed the policy limit."
    }

    # Chromium verwirft jeden Eintrag, der nicht "[schema://][.]host[:port][/pfad]"
    # ist - ein einziges Sternchen macht die Zeile wirkungslos (Befund L-5).
    # Die Liste ist deshalb kuerzer als die Firefox-Liste und darf nirgends ein
    # Sternchen enthalten.
    $chromiumFailClosed = @(Merge-ChromiumUrlFilters -BasePatterns $mixedSitePatterns -FailClosed $true)
    if ($chromiumFailClosed.Count -gt 1000 -or
        $chromiumFailClosed.Count -lt 24 -or
        $chromiumFailClosed[0] -ne "reddit.com" -or
        $chromiumFailClosed -notcontains "x.com" -or
        $chromiumFailClosed -notcontains "bsky.app" -or
        @($chromiumFailClosed | Where-Object { $_.Contains("*") }).Count -gt 0) {
        throw "Chromium fail-closed filters do not use the native URLBlocklist domain format."
    }

    if ((Test-BrowserCompanionPolicySyncNeeded -ChromeActive $true -EdgeActive $true -ChromeFailClosed $false -EdgeFailClosed $false) -or
        -not (Test-BrowserCompanionPolicySyncNeeded -ChromeActive $false -EdgeActive $true -ChromeFailClosed $false -EdgeFailClosed $false) -or
        -not (Test-BrowserCompanionPolicySyncNeeded -ChromeActive $true -EdgeActive $true -ChromeFailClosed $true -EdgeFailClosed $false)) {
        throw "Browser companion policy transition check failed."
    }

    $safeState = [pscustomobject]@{ ChromeActive = $true; EdgeActive = $true; Version = "0.60.0" }
    $chromeOff = @(Get-BrowserCompanionStateChanges -PreviousState $safeState -ChromeActive $false -EdgeActive $true -ExpectedVersion "0.60.0")
    $unchanged = @(Get-BrowserCompanionStateChanges -PreviousState $safeState -ChromeActive $true -EdgeActive $true -ExpectedVersion "0.60.0")
    $versionChange = @(Get-BrowserCompanionStateChanges -PreviousState $safeState -ChromeActive $true -EdgeActive $true -ExpectedVersion "0.61.28")
    $firstState = @(Get-BrowserCompanionStateChanges -PreviousState $null -ChromeActive $true -EdgeActive $true -ExpectedVersion "0.60.0")
    if ($chromeOff.Count -ne 1 -or $chromeOff[0] -ne "Chrome" -or $unchanged.Count -ne 0 -or $versionChange.Count -ne 2 -or $firstState.Count -ne 2) {
        throw "Browser companion persisted state transition check failed."
    }

    $unsafe = @(Get-BrowserCompanionUnsafeStateChanges -PreviousState $safeState -ChromeActive $false -EdgeActive $true)
    $recovered = @(Get-BrowserCompanionUnsafeStateChanges -PreviousState ([pscustomobject]@{ ChromeActive = $false; EdgeActive = $false }) -ChromeActive $true -EdgeActive $true)
    if ($unsafe.Count -ne 1 -or $unsafe[0] -ne "Chrome" -or $recovered.Count -ne 0) {
        throw "Browser companion unsafe transition check failed."
    }

    $missingFailClosed = @(Get-BrowserFailClosedPolicyRefreshTargets -ChromeActive $false -EdgeActive $true -ChromeFailClosed $false -EdgeFailClosed $false)
    $alreadyFailClosed = @(Get-BrowserFailClosedPolicyRefreshTargets -ChromeActive $false -EdgeActive $true -ChromeFailClosed $true -EdgeFailClosed $false)
    $clearStaleFailClosed = @(Get-BrowserFailClosedPolicyRefreshTargets -ChromeActive $true -EdgeActive $true -ChromeFailClosed $true -EdgeFailClosed $false)
    if ($missingFailClosed.Count -ne 1 -or $missingFailClosed[0] -ne "Chrome" -or
        $alreadyFailClosed.Count -ne 0 -or
        $clearStaleFailClosed.Count -ne 0) {
        throw "Browser fail-closed refresh check failed."
    }

    # Nicht der Wert der Konstanten, sondern was sie entscheidet (CMP-002): der
    # Rueckfall auf die verwaltete Richtlinie traegt den frisch gestarteten
    # Browser und einen eben abgelaufenen Herzschlag - und danach nichts mehr.
    if (-not (Test-CompanionPolicyFallbackValid -BrowserProcessAgeSeconds 60 -HeartbeatAgeSeconds -1) -or
        -not (Test-CompanionPolicyFallbackValid -BrowserProcessAgeSeconds -1 -HeartbeatAgeSeconds -1) -or
        -not (Test-CompanionPolicyFallbackValid -BrowserProcessAgeSeconds 7200 -HeartbeatAgeSeconds 400) -or
        (Test-CompanionPolicyFallbackValid -BrowserProcessAgeSeconds 7200 -HeartbeatAgeSeconds -1) -or
        (Test-CompanionPolicyFallbackValid -BrowserProcessAgeSeconds 7200 -HeartbeatAgeSeconds 900)) {
        throw "Browser startup grace contract failed."
    }

    # CMP-003: Ein Browser, den Purestate soeben selbst neu gestartet hat, ist
    # zwar jung, hat seine Gnadenfrist aber verbraucht. Ohne diese Regel erneuert
    # der Eingriff die Bedingung, unter der er nicht sperren muss - live gemessen
    # als Kreislauf aus Sperre, Schliessen und Neustart alle fuenfeinhalb Minuten.
    # Ein geschlossener Browser bleibt davon unberuehrt, sonst wuerde jeder Lauf
    # ohne Browser unnoetig verschaerfen.
    if ((Test-CompanionPolicyFallbackValid -BrowserProcessAgeSeconds 60 -HeartbeatAgeSeconds -1 -StartupGraceSpent $true) -or
        -not (Test-CompanionPolicyFallbackValid -BrowserProcessAgeSeconds 60 -HeartbeatAgeSeconds -1 -StartupGraceSpent $false) -or
        -not (Test-CompanionPolicyFallbackValid -BrowserProcessAgeSeconds -1 -HeartbeatAgeSeconds -1 -StartupGraceSpent $true) -or
        -not (Test-CompanionPolicyFallbackValid -BrowserProcessAgeSeconds 60 -HeartbeatAgeSeconds 100 -StartupGraceSpent $true)) {
        throw "Browser startup grace reuse contract failed (CMP-003)."
    }

    $bypassKeywords = Get-BypassAppKeywords
    if ($bypassKeywords.Count -lt 10) {
        throw "Bypass app keyword list is unexpectedly short."
    }

    if ($bypassKeywords -notcontains "tor" -or $bypassKeywords -notcontains "openvpn") {
        throw "Bypass app keyword list is missing core tools."
    }

    $adultUrlKeywords = Get-AdultUrlKeywords
    if ($adultUrlKeywords.Count -lt 30) {
        throw "Adult URL keyword list is unexpectedly short."
    }

    if ($adultUrlKeywords -notcontains "rule34" -or $adultUrlKeywords -notcontains "redgifs" -or
        $adultUrlKeywords -notcontains "breasts" -or $adultUrlKeywords -notcontains "goonsky") {
        throw "Adult URL keyword list is missing expanded platform terms."
    }

    $nsfwSubreddits = Get-NsfwSubreddits
    if ($nsfwSubreddits.Count -lt 60) {
        throw "Reddit NSFW subreddit list is unexpectedly short."
    }

    if ($nsfwSubreddits -notcontains "gonewild" -or $nsfwSubreddits -notcontains "onlyfans") {
        throw "Reddit NSFW subreddit list is missing core entries."
    }

    if ((Get-FamilyDnsServers -Profile "CloudflareFamily").Count -lt 2) {
        throw "Cloudflare DNS profile is missing."
    }

    if ((Get-FamilyDnsServers -Profile "CleanBrowsingFamily").Count -lt 2) {
        throw "CleanBrowsing DNS profile is missing."
    }

    if ((Get-FamilyDnsServers -Profile "OpenDnsFamilyShield").Count -lt 2) {
        throw "OpenDNS DNS profile is missing."
    }

    $unsupportedBrowserKeywords = Get-UnsupportedBrowserKeywords
    if ($unsupportedBrowserKeywords.Count -lt 10) {
        throw "Unsupported browser keyword list is unexpectedly short."
    }

    if ($unsupportedBrowserKeywords -notcontains "brave" -or $unsupportedBrowserKeywords -notcontains "opera") {
        throw "Unsupported browser keyword list is missing core browsers."
    }

    # Fester Uhr-Anker statt der Wanduhr. Ohne ihn misst der Selbsttest die
    # Systemuhr - und ab der Fassungsgrenze (31.03.2027) faellt er mit
    # "Schedule self-test failed", obwohl der Zeitplan in Ordnung ist: dann
    # sagt Test-ProtectionShouldRun "abgelaufen". Der Selbsttest laeuft aus der
    # Paketpruefung des Installers (NativeSupportPackage.cs) und ist damit
    # datumsabhaengig gewesen. Anker wie bei den Cooldown-Tests.
    $selfTestAnchorUtc = [datetime]::new(2026, 10, 1, 12, 0, 0, [System.DateTimeKind]::Utc)
    $selfTestLocal = $selfTestAnchorUtc.ToLocalTime()
    $scheduleStart = $selfTestLocal.AddMinutes(-1).ToString("HH:mm")
    $scheduleEnd = $selfTestLocal.AddMinutes(1).ToString("HH:mm")
    $scheduleConfig = [pscustomobject]@{
        ClockAnchorUtc = $selfTestAnchorUtc.ToString("o")
        ProtectionEnabled = $false
        HostsEnabled = $true
        FamilyDnsEnabled = $true
        DnsProfile = "CleanBrowsingFamily"
        BrowserPoliciesEnabled = $true
        BypassBlockingEnabled = $true
        UnsupportedBrowserBlockingEnabled = $true
        TamperProtectionEnabled = $true
        LockdownModeEnabled = $true
        PauseCooldownEnabled = $true
        PendingPauseUntilUtc = ""
        ScheduleEnabled = $true
        StrictModeEnabled = $true
        ScheduleStart = $scheduleStart
        ScheduleEnd = $scheduleEnd
        PauseUntilUtc = ""
        PasswordHint = ""
        Password = $null
    }

    if (-not (Test-ProtectionShouldRun -Config $scheduleConfig)) {
        throw "Schedule self-test failed."
    }

    $sample = "$script:MarkerBegin`r`n0.0.0.0 example.com`r`n$script:MarkerEnd`r`nkeep"
    $clean = Remove-ManagedHostsBlock -Content $sample
    if ($clean -ne "keep") {
        throw "Hosts cleanup self-test failed."
    }

    $junctionTarget = Join-Path ([System.IO.Path]::GetTempPath()) ("Purestate-EnforceTarget-" + [guid]::NewGuid().ToString("N"))
    $junctionPath = Join-Path ([System.IO.Path]::GetTempPath()) ("Purestate-EnforceJunction-" + [guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Path $junctionTarget -Force | Out-Null
    '{}' | Set-Content -LiteralPath (Join-Path $junctionTarget "config.json") -Encoding UTF8
    try {
        $junctionCommand = "mklink /J `"$junctionPath`" `"$junctionTarget`""
        $junctionProcess = Start-Process -FilePath (Join-Path $env:SystemRoot "System32\cmd.exe") `
            -ArgumentList @("/d", "/c", $junctionCommand) `
            -WindowStyle Hidden `
            -Wait `
            -PassThru
        if ($junctionProcess.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $junctionPath -PathType Container)) {
            throw "Data-directory Junction self-test fixture could not be created."
        }

        $script:DataDir = $junctionPath
        $script:ConfigPath = Join-Path $script:DataDir "config.json"
        $script:IntegrityKeyPath = Join-Path $script:DataDir "integrity.key"
        $script:DnsBackupPath = Join-Path $script:DataDir "dns-backup.json"
        $script:ProxyBackupPath = Join-Path $script:DataDir "proxy-backup.json"
        $script:BrowserCompanionStatePath = Join-Path $script:DataDir "browser-companion-state.json"
        $script:ManagedListRecordPath = Join-Path $script:DataDir "managed-url-lists.json"
        $script:LogPath = Join-Path $script:DataDir "activity.log"
        $script:SecurityLogPath = Join-Path $script:DataDir "security.log"

        $junctionRejected = $false
        try {
            Get-Config | Out-Null
        } catch {
            $junctionRejected = $_.Exception.Message -match "Reparse"
        }
        Save-ManagedListRecord -Record @{ Chrome = @("blocked.example") }
        Add-AppLog "Junction self-test must not reach the target."
        $junctionWriteReachedTarget =
            (Test-Path -LiteralPath (Join-Path $junctionTarget "managed-url-lists.json")) -or
            (Test-Path -LiteralPath (Join-Path $junctionTarget "activity.log"))
        if (-not $junctionRejected -or $junctionWriteReachedTarget) {
            throw "PowerShell enforcement did not reject the data-directory Junction before config/state access."
        }
    } finally {
        $script:DataDir = $selfTestDataDir
        $script:ConfigPath = Join-Path $script:DataDir "config.json"
        $script:IntegrityKeyPath = Join-Path $script:DataDir "integrity.key"
        $script:DnsBackupPath = Join-Path $script:DataDir "dns-backup.json"
        $script:ProxyBackupPath = Join-Path $script:DataDir "proxy-backup.json"
        $script:BrowserCompanionStatePath = Join-Path $script:DataDir "browser-companion-state.json"
        $script:ManagedListRecordPath = Join-Path $script:DataDir "managed-url-lists.json"
        $script:LogPath = Join-Path $script:DataDir "activity.log"
        $script:SecurityLogPath = Join-Path $script:DataDir "security.log"
        if ([System.IO.Directory]::Exists($junctionPath)) {
            [System.IO.Directory]::Delete($junctionPath)
        }
        if ([System.IO.Directory]::Exists($junctionTarget)) {
            [System.IO.Directory]::Delete($junctionTarget, $true)
        }
    }

    "Self-test OK. $($domains.Count) domains and $($mixedSitePatterns.Count) URL rules loaded; browser fail-closed ready."
    Remove-Item -LiteralPath $selfTestDataDir -Recurse -Force -ErrorAction SilentlyContinue
    exit 0
}

if ($BrowserOnly) {
    $config = Get-Config
    if (Test-ProtectionShouldRun -Config $config) {
        $changed = Sync-BrowserCompanionPolicies -RestartChangedBrowsers $true
        if (-not $Quiet) {
            "Browser companion policies synchronized=$changed"
        }
    }
    exit 0
}

Enable-Protection -Reconcile:$Reconcile

if (-not $Quiet) {
    $status = Get-ProtectionStatus
    "Protection enforced. Hosts=$($status.HostsActive) DNS=$($status.DnsActive) Service=$($status.ServiceRunning)"
}

