"use strict";

// DeviantArt companion. Two layers of protection:
//   1. Force the account "Browsing mode" to Safe Mode (server-side filter) and
//      keep it locked. Safe Mode is the strong defense: DeviantArt itself filters
//      mature deviations out of every feed/search once it is on.
//   2. Block known adult search/tag URLs with a full-page overlay (backup), and
//      hide content from the first paint so nothing flashes before the overlay.
//
// DeviantArt exposes NO per-thumbnail maturity marker in the DOM (verified live
// 2026-06-29: no data-* flag, no client-side state, blur/badge come from
// build-hashed classes), so reliable per-image detection is not possible. The
// Safe Mode enforcement plus URL blocking is the robust approach.

const DA_INSTANT_STYLE_ID = "purestate-da-instant-style";
const DA_SEARCH_OVERLAY_ID = "purestate-da-search-overlay";
const DA_ENFORCE_FRAME_ID = "purestate-da-enforce-frame";
const DA_SETTINGS_URL = "https://www.deviantart.com/account/browsing";
const DA_ENFORCE_INTERVAL_MS = 60000;

// DeviantArt exposes the browsing-mode radios under TWO different names:
//   - `contentFilter` on the standalone settings page (/account/browsing).
//   - `content_filter` (underscore) inside the inline "Browsing Mode" modal that
//     opens from the top-right account dropdown and from a gated deviation's
//     "Update Browsing Mode" button. The inline modal lets the user switch to
//     Standard/Mature from ANY page, which is the primary Safe-Mode bypass.
// Verified live 2026-06-29. Both must be locked to Safe.
const DA_FILTER_RADIOS =
  'input[name="contentFilter"], input[name="content_filter"]';
const DA_SAFE_RADIO =
  'input[name="contentFilter"][value="safe"], input[name="content_filter"][value="safe"]';

// A gated deviation in Safe Mode renders a reveal control (real label observed
// live: "Show Deviation Anyway") that displays the mature content client-side
// WITHOUT changing the browsing mode, so locking the mode alone does not stop
// it. Matched on the control's accessible text (DeviantArt's class names are
// build-hashed and unstable). The first branch matches any "Show ... Anyway"
// wording; plus content/view variants and German fallbacks. Deliberately
// specific so it never matches the account dropdown's "Browsing Mode" /
// "Update Browsing Mode" entries.
const DA_REVEAL_PATTERN =
  /\bshow\b[\w\s]*\banyway\b|\bshow (?:this )?(?:deviation|mature|adult|sensitive)[\w\s]*\bcontent\b|\bview (?:mature|adult|sensitive) content\b|\btrotzdem (?:anzeigen|ansehen)\b|\binhalt anzeigen\b/i;

// Centralized: the NSFW search-term list lives in adult-search-terms.js (loaded
// first in the manifest) so it is extended in one place across every site.
const DA_ADULT_SEARCH_PATTERN = purestateAdultSearchPattern();

let daObserver = null;
let daScanTimer = 0;
// PLT-004: Was der Beobachter gemeldet hat, und ob ein Vollbaumlauf faellig ist.
const daPendingRoots = [];
let daFullScanPending = false;
let daInterval = 0;
let lastDaLocation = "";
let daEnforceInFlight = false;
let daLastEnforce = 0;

purestateRunWhenSiteProtectionEnabled("deviantart", () => {
  installDaInstantHide();
  installDaSettingsGuard();
  installDaMonitoring();
});

function daIsTopLevel() {
  try {
    return window.top === window.self;
  } catch {
    return false;
  }
}

function daOnDeviantArtHost() {
  return /(?:^|\.)deviantart\.com$/i.test(location.hostname || "");
}

// Runs synchronously at document_start. On an adult search/tag URL, hide page
// content from the first paint so blocked deviations never flash before the
// overlay is built.
function installDaInstantHide() {
  if (!document.documentElement || !daIsTopLevel()) {
    return;
  }
  if (isDeviantArtAdultUrl()) {
    purestateInstantHide(document, DA_INSTANT_STYLE_ID);
  }
}

function installDaMonitoring() {
  if (daObserver) {
    return;
  }
  scanDa(document);
  enforceDaSettings();
  enforceDaAccountWide();
  daObserver = new MutationObserver((records) => scheduleDaScan(records));
  daObserver.observe(document.documentElement, { childList: true, subtree: true });
  daInterval = setInterval(() => {
    const current = location.href;
    if (current !== lastDaLocation) {
      lastDaLocation = current;
      if (daIsTopLevel()) {
        if (isDeviantArtAdultUrl()) {
          purestateInstantHide(document, DA_INSTANT_STYLE_ID);
        } else {
          purestateRemoveInstantHide(document, DA_INSTANT_STYLE_ID);
        }
      }
      scanDa(document);
    }
    enforceDaSettings();
    enforceDaAccountWide();
    observeDaCanary();
  }, 1500);
}

// Selector canary (diagnostics only, see purestateCanaryObserve): when this
// document IS the browsing-settings page, the contentFilter radios must exist.
// 15 consecutive 1.5s-tick misses report a selector break.
function observeDaCanary() {
  purestateCanaryObserve(
    "deviantart",
    "browsing-radios",
    /^\/account\/browsing/i.test(location.pathname || ""),
    !!document.querySelector(DA_FILTER_RADIOS)
  );
}

// Self-heal frame canary: the hidden iframe loaded DA_SETTINGS_URL, so the
// browsing-mode radios must exist inside it by the end of the cycle. Three
// consecutive 60s cycles without them report a selector break.
function observeDaFrameCanary(frame) {
  try {
    const doc = purestateSettingsFrameDocument(frame, "/account/browsing");
    const found = !!(doc && doc.querySelector && doc.querySelector(DA_FILTER_RADIOS));
    purestateCanaryObserve("deviantart", "selfheal-frame", !!doc, found, 3);
  } catch {
  }
}

// PLT-004: Der Beobachter loeste einen Lauf ueber JEDES Element des Dokuments
// aus, 80 ms entprellt. Was er meldet, ist aber genau der Teilbaum, in dem der
// neue Aufdeck-Knopf steht - der reicht. Meldet er nichts Brauchbares, bleibt
// es beim Vollbaumlauf: lieber einmal zu viel als ein uebersehener Knopf.
function scheduleDaScan(records) {
  if (records && records.length) {
    for (const record of records) {
      const added = (record && record.addedNodes) || [];
      for (const node of added) {
        if (node && node.nodeType === 1) {
          daPendingRoots.push(node);
        }
      }
    }
  } else {
    daFullScanPending = true;
  }

  clearTimeout(daScanTimer);
  daScanTimer = setTimeout(() => {
    const roots = daPendingRoots.splice(0, daPendingRoots.length);
    const voll = daFullScanPending || roots.length === 0;
    daFullScanPending = false;
    scanDa(document, voll ? null : roots);
    enforceDaSettings();
  }, 80);
}

function scanDa(root, revealRoots) {
  if (!root || typeof root.querySelectorAll !== "function") {
    return;
  }
  // Overlays are a top-window concern; never paint one inside the hidden
  // enforcement iframe.
  if (!daIsTopLevel()) {
    return;
  }
  // Reveal controls can appear on any deviation page, not just adult URLs.
  if (revealRoots && revealRoots.length) {
    for (const node of revealRoots) {
      neutralizeDaRevealIn(node);
    }
  } else {
    neutralizeDaReveal(root.ownerDocument ? root.ownerDocument : root);
  }
  if (isDeviantArtAdultUrl()) {
    purestateInstantHide(document, DA_INSTANT_STYLE_ID);
    showDaSearchOverlay(root);
  } else {
    hideDaSearchOverlay(root);
  }
}

// --- Safe Mode enforcement -------------------------------------------------

// Returns the currently selected browsing-mode value ("safe"|"standard"|
// "mature") or "" if the radios are not present in the given document.
function daCurrentContentFilter(doc) {
  if (!doc || !doc.querySelectorAll) {
    return "";
  }
  for (const radio of doc.querySelectorAll(DA_FILTER_RADIOS)) {
    if (radio.checked) {
      return radio.value;
    }
  }
  return "";
}

// Locate the Save/submit button for a browsing-mode form. The settings page wraps
// the radios in a <form> with a submit button; the inline modal has no form, so
// fall back to a nearby button whose accessible text is Save/Speichern.
function daFindSaveButton(radio) {
  if (!radio || !radio.closest) {
    return null;
  }
  const form = radio.closest("form");
  if (form && form.querySelector) {
    const submit = form.querySelector('button[type="submit"]');
    if (submit) {
      return submit;
    }
  }
  const container =
    radio.closest('[role="dialog"], .ReactModalPortal, form') ||
    (radio.ownerDocument ? radio.ownerDocument.body : null);
  if (!container || !container.querySelectorAll) {
    return null;
  }
  for (const button of container.querySelectorAll('button, [role="button"]')) {
    const text = (button.textContent || "").trim();
    if (/^(save|speichern)$/i.test(text)) {
      return button;
    }
  }
  return null;
}

// Forces Safe Mode in the given document if the browsing-mode radios are present
// and not already on "safe". A native radio.click() makes DeviantArt's React
// form enable the (otherwise disabled) Save button; we then click Save so the
// change persists server-side. Verified live 2026-06-29.
function applyDaSafeModeInDoc(doc) {
  if (!doc || !doc.querySelector) {
    return false;
  }
  const safe = doc.querySelector(DA_SAFE_RADIO);
  if (!safe) {
    return false;
  }
  if (daCurrentContentFilter(doc) === "safe") {
    return true;
  }
  const save = daFindSaveButton(safe);
  try {
    safe.click();
  } catch {
  }
  setTimeout(() => {
    try {
      if (save) {
        save.click();
      }
    } catch {
    }
  }, 200);
  return true;
}

// Direct enforcement: whenever the browsing-mode radios are present in THIS
// document (the real settings page, or the hidden enforcement iframe), force
// Safe Mode. Keyed on the radios rather than the URL so it keeps working if
// DeviantArt moves the settings page.
function enforceDaSettings() {
  const names = new Set();
  for (const radio of document.querySelectorAll(DA_FILTER_RADIOS)) {
    if (radio.name) {
      names.add(radio.name);
    }
  }
  for (const name of names) {
    applyDaSafeModeForName(document, name);
  }
}

// Current selected value within a single radio group ("safe"|"standard"|
// "mature") or "" if none present.
function daGroupCurrentValue(doc, name) {
  for (const radio of doc.querySelectorAll('input[name="' + name + '"]')) {
    if (radio.checked) {
      return radio.value;
    }
  }
  return "";
}

// Force one specific browsing-mode group (by radio name) to Safe. Both the
// settings page (`contentFilter`) and the inline modal (`content_filter`) are
// handled the same way: native click on Safe, then click Save to persist.
function applyDaSafeModeForName(doc, name) {
  if (!doc || !doc.querySelector) {
    return;
  }
  const safe = doc.querySelector('input[name="' + name + '"][value="safe"]');
  if (!safe || daGroupCurrentValue(doc, name) === "safe") {
    return;
  }
  const save = daFindSaveButton(safe);
  try {
    safe.click();
  } catch {
  }
  setTimeout(() => {
    try {
      if (save) {
        save.click();
      }
    } catch {
    }
  }, 200);
}

// Account-wide enforcement: from any DeviantArt page that is NOT itself the
// settings page, load the browsing settings in a hidden same-origin iframe and
// force Safe Mode inside it. This reuses DeviantArt's own page JS so its CSRF
// protection is satisfied (a hand-rolled fetch is rejected with csrf:missing).
function enforceDaAccountWide() {
  if (!daIsTopLevel() || !daOnDeviantArtHost()) {
    return;
  }
  // If the radios are already in this document (settings page, or the inline
  // Browsing Mode modal) direct enforcement handles it, no iframe needed.
  if (document.querySelector(DA_SAFE_RADIO)) {
    return;
  }
  const now = Date.now();
  if (daEnforceInFlight || now - daLastEnforce < DA_ENFORCE_INTERVAL_MS) {
    return;
  }
  daEnforceInFlight = true;
  daLastEnforce = now;
  const existing = document.getElementById(DA_ENFORCE_FRAME_ID);
  if (existing) {
    existing.remove();
  }
  const frame = document.createElement("iframe");
  frame.id = DA_ENFORCE_FRAME_ID;
  frame.setAttribute("aria-hidden", "true");
  frame.style.cssText = "position:absolute!important;width:1px;height:1px;left:-9999px;top:-9999px;border:0;opacity:0;pointer-events:none;";
  frame.src = DA_SETTINGS_URL;
  const finish = () => {
    daEnforceInFlight = false;
    try {
      frame.remove();
    } catch {
    }
  };
  frame.addEventListener("load", () => {
    setTimeout(() => {
      try {
        applyDaSafeModeInDoc(frame.contentDocument);
      } catch {
      }
      // Leave the frame alive briefly so the Save round-trip can complete.
      setTimeout(() => {
        observeDaFrameCanary(frame);
        finish();
      }, 1800);
    }, 600);
  });
  // Safety net in case the frame never loads.
  setTimeout(() => {
    if (daEnforceInFlight) {
      finish();
    }
  }, 9000);
  (document.body || document.documentElement).appendChild(frame);
}

// --- Settings guard --------------------------------------------------------
// Block the user from selecting Standard/Mature mode; allow Safe. Our own
// synthetic clicks (isTrusted === false) are exempt so enforcement is not
// self-blocked.

function installDaSettingsGuard() {
  const guard = (event) => {
    guardDaSettingsClick(event);
    guardDaRevealClick(event);
  };
  document.addEventListener("pointerdown", guard, true);
  document.addEventListener("click", guard, true);
  document.addEventListener("keydown", (event) => {
    if (!event || (event.key !== " " && event.key !== "Enter")) {
      return;
    }
    guard(event);
  }, true);
}

// --- "Show Anyway" reveal guard --------------------------------------------
// Blocks the per-deviation reveal button that would show a single mature
// deviation client-side without changing the (locked) browsing mode.

function daControlMatchesReveal(node) {
  if (!node || !node.getAttribute) {
    return false;
  }
  const tag = (node.tagName || "").toLowerCase();
  const role = node.getAttribute("role");
  if (tag !== "button" && tag !== "a" && role !== "button") {
    return false;
  }
  const text = (
    node.getAttribute("aria-label") ||
    node.textContent ||
    ""
  ).trim();
  return Boolean(text && text.length < 60 && DA_REVEAL_PATTERN.test(text));
}

function daRevealControlFromEvent(target) {
  if (!target || !target.closest) {
    return null;
  }
  for (
    let node = target.closest('button, a, [role="button"]');
    node;
    node = node.parentElement && node.parentElement.closest
      ? node.parentElement.closest('button, a, [role="button"]')
      : null
  ) {
    if (daControlMatchesReveal(node)) {
      return node;
    }
  }
  return null;
}

// composedPath() exposes the real innermost target even when the deviation
// viewer renders the reveal control inside a shadow root (where event.target
// is retargeted to the shadow host and closest() cannot reach the button).
function daRevealControlFromPath(path) {
  if (!path || typeof path.length !== "number") {
    return null;
  }
  for (let i = 0; i < path.length; i += 1) {
    if (daControlMatchesReveal(path[i])) {
      return path[i];
    }
  }
  return null;
}

function guardDaRevealClick(event) {
  if (event && event.isTrusted === false) {
    return;
  }
  const path = event && typeof event.composedPath === "function"
    ? event.composedPath()
    : null;
  const control = daRevealControlFromPath(path)
    || daRevealControlFromEvent(event && event.target);
  if (!control) {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  if (event.stopImmediatePropagation) {
    event.stopImmediatePropagation();
  }
}

// Proactively remove reveal controls so a gated deviation cannot be un-gated
// even if the click guard is bypassed (e.g. programmatic activation).
function neutralizeDaReveal(doc) {
  if (!doc || !doc.querySelectorAll || !daIsTopLevel()) {
    return;
  }
  // Walk the light DOM plus any shadow roots: the deviation viewer can render
  // the reveal control inside a shadow tree, which querySelectorAll on the
  // document cannot reach.
  const all = doc.querySelectorAll("*");
  for (const el of all) {
    if (daControlMatchesReveal(el)) {
      disableDaRevealControl(el);
    }
    if (el.shadowRoot) {
      neutralizeDaReveal(el.shadowRoot);
    }
  }
}

function disableDaRevealControl(el) {
  if (el.setAttribute) {
    el.setAttribute("disabled", "true");
  }
  if (el.style && el.style.setProperty) {
    el.style.setProperty("pointer-events", "none", "important");
    el.style.setProperty("display", "none", "important");
  }
}

// PLT-004: Wie neutralizeDaReveal, aber auf einem gemeldeten Teilbaum - und der
// Knoten selbst zaehlt mit, denn querySelectorAll findet nur seine Nachfahren.
function neutralizeDaRevealIn(node) {
  if (!node || !daIsTopLevel()) {
    return;
  }
  if (node.nodeType === 1 && daControlMatchesReveal(node)) {
    disableDaRevealControl(node);
  }
  neutralizeDaReveal(node);
}

function daContentFilterFromEvent(target) {
  if (!target || !target.closest) {
    return null;
  }
  if (target.matches && target.matches(DA_FILTER_RADIOS)) {
    return target;
  }
  const label = target.closest("label");
  if (label) {
    return label.querySelector(DA_FILTER_RADIOS);
  }
  return null;
}

function guardDaSettingsClick(event) {
  if (event && event.isTrusted === false) {
    return;
  }
  const radio = daContentFilterFromEvent(event && event.target);
  if (!radio) {
    return;
  }
  if (radio.value === "safe") {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  if (event.stopImmediatePropagation) {
    event.stopImmediatePropagation();
  }
  setTimeout(() => enforceDaSettings(), 50);
}

// --- Adult URL blocking ----------------------------------------------------

function isDeviantArtAdultUrl() {
  const path = (location.pathname || "").toLowerCase();
  const search = (location.search || "").toLowerCase();
  const tagMatch = path.match(/\/tag\/([^/?#]+)/);
  if (tagMatch) {
    const term = decodeURIComponent(tagMatch[1]).replace(/[-_+]/g, " ").trim();
    if (DA_ADULT_SEARCH_PATTERN.test(term)) {
      return true;
    }
  }
  const qMatch = search.match(/[?&]q=([^&]*)/);
  if (qMatch) {
    let term = qMatch[1].replace(/\+/g, " ");
    try {
      term = decodeURIComponent(term);
    } catch {
    }
    if (DA_ADULT_SEARCH_PATTERN.test(term)) {
      return true;
    }
  }
  return false;
}

function showDaSearchOverlay(root) {
  const doc = root && root.ownerDocument ? root.ownerDocument : root;
  if (!doc || !doc.documentElement || doc.getElementById(DA_SEARCH_OVERLAY_ID)) {
    return;
  }
  purestateShowSearchOverlay(
    doc,
    DA_SEARCH_OVERLAY_ID,
    "Diese DeviantArt-Suche wurde durch Purestate blockiert."
  );
}

function hideDaSearchOverlay(root) {
  const doc = root && root.ownerDocument ? root.ownerDocument : root;
  if (!doc) {
    return;
  }
  purestateHideSearchOverlay(doc, DA_SEARCH_OVERLAY_ID, DA_INSTANT_STYLE_ID);
}
