"use strict";

// Purestate: Wirkung des Erwachsenen-Erkenners auf der Seite.
//
// adult-detect.js faellt das Urteil (rein, ohne Seiteneffekt). Dieses Modul
// setzt es um: Vollvorhang bei "hard", Warnleiste bei "soft", und merkt sich
// einen einmal hart erkannten Host, damit er nicht bei jedem Aufruf neu
// beurteilt werden muss.

const ADULT_RULES_GET = "purestate.getBrowserRules";
const ADULT_LEARN_HOST_MESSAGE = "purestate.adultLearnHost";
const ADULT_CURTAIN_ID = "purestate-adult-curtain";
const ADULT_BANNER_ID = "purestate-adult-banner";

// Ein Host bleibt gemerkt, keine Seite ist dauerhaft "sicher" nach 30 Tagen -
// derselbe Zeitraum wie beim Gluecksspiel-Gedaechtnis.
const ADULT_HOST_MEMORY_KEY = "purestateAdultHosts";
const ADULT_HOST_MEMORY_MS = 30 * 24 * 60 * 60 * 1000;

// __purestateAdultRulePack ist ausschliesslich ein Testeinstiegspunkt (siehe
// Extension.Regression.Tests.js): er erlaubt es Tests, einen Rule Pack ohne
// die volle Nachrichten-Laufzeit zu setzen. In echten Seiten ist die
// Kennung nie definiert, und requestAdultRules() liefert den echten Pack
// asynchron nach.
let adultRulePack = (typeof __purestateAdultRulePack !== "undefined") ? __purestateAdultRulePack : null;
let adultHostRemembered = false;
let adultDetection = { state: "", href: "", level: "none", reason: "", tries: 0 };

// Bereichsschalter aus dem Rule Pack. Fehlt der Pack oder das Feld, gilt der
// Bereich als an - fail-closed.
function adultAreaActive(pack) {
  const rules = pack && typeof pack === "object" ? pack : {};
  const areas = rules.areas && typeof rules.areas === "object" ? rules.areas : {};
  const area = areas["adult-content"];
  if (!area || typeof area !== "object") {
    return true;
  }
  return area.enabled !== false;
}

// adult.hostDomains traegt NICHT die 186 kuratierten Domains, sondern genau
// die vom Guard gelernte Datei (PurestateNativeHost.cs, learned-adult-
// domains.txt). Der Name sagt das, damit die Reihenfolge unten nachvollziehbar
// bleibt: eine Freigabe muss VOR dieser Liste greifen, nicht danach.
// Suffix-Semantik wie ueberall sonst im Companion: exakt oder Unterdomain,
// nie Teilzeichenkette.
function adultLearnedHostMatches(pack, hostname) {
  return adultHostListMatches(adultSection(pack).hostDomains, hostname);
}

// Freigegebene Fehltreffer (adult-learned-exemptions.txt, ueber den Native
// Host). Nur bereits wirksame Eintraege stehen hier - die 15-Minuten-Frist
// filtert der Native Host.
function adultExemptHostMatches(pack, hostname) {
  return adultHostListMatches(adultSection(pack).exemptHosts, hostname);
}

function adultSection(pack) {
  const rules = pack && typeof pack === "object" ? pack : {};
  return rules.adult && typeof rules.adult === "object" ? rules.adult : {};
}

function adultHostListMatches(values, hostname) {
  const host = String(hostname || "").toLowerCase();
  if (!host) {
    return false;
  }
  for (const value of Array.isArray(values) ? values : []) {
    const domain = String(value || "").toLowerCase();
    if (domain && (host === domain || host.endsWith("." + domain))) {
      return true;
    }
  }
  return false;
}

// Ein einziges Urteil je Ladezustand reicht nicht: hinter einem
// Zustimmungsbanner traegt eine Seite nur einen Bruchteil ihres Textes.
// Deshalb wird bis zu ADULT_DETECT_TRIES mal nachgesehen, genau wie beim
// Gluecksspiel-Modul (gambling-time-content.js:132).
const ADULT_DETECT_TRIES = 4;

function detectedAdultPage() {
  if (typeof purestateDetectAdultPage !== "function") {
    return "none";
  }
  const state = document.readyState;
  // DET-004: Der Zaehler wurde NUR bei einem Wechsel von document.readyState
  // zurueckgesetzt. Nach dem Laden bleibt der dauerhaft "complete" - eine
  // Anwendung, die ihre Inhalte per pushState wechselt, ohne die Seite neu zu
  // laden, wurde also nach den ersten vier Urteilen nie wieder beurteilt,
  // obwohl der 15-Sekunden-Takt weiterlief. Der Vier-Versuche-Deckel ist gegen
  // Zustimmungsbanner gedacht und dafuer richtig; fuer die Navigation INNERHALB
  // der Seite fehlte der Ausloeser. Die Adresse ist er.
  const href = location.href;
  if (adultDetection.state !== state || adultDetection.href !== href) {
    adultDetection = { state: state, href: href, level: "none", reason: "", tries: 0 };
  }
  if (adultDetection.level !== "hard" && adultDetection.tries < ADULT_DETECT_TRIES) {
    adultDetection.tries += 1;
    const verdict = purestateDetectAdultPage(document, location.hostname);
    adultDetection.level = verdict.level || "none";
    adultDetection.reason = verdict.reason || "";
  }
  return adultDetection.level;
}

// Die Reihenfolge traegt vier Entscheidungen:
//   1. nie-sperren steht ganz oben - eine gesperrte Beratungsstelle waere
//      Schaden am Zweck des Bereichs. Die Pruefung steckt zwar auch in
//      purestateDetectAdultPage, aber die Erkennung kommt hier zuletzt: ein
//      einmal faelschlich gelernter oder gemerkter Beratungshost bliebe sonst
//      gesperrt, ohne dass die Erkennung je wieder gefragt wird.
//   2. kuratiert steht vor freigegeben - sonst waere die Freigabedatei der
//      Generalschluessel fuer den ganzen Schutzbereich. Die kuratierten
//      Domains reisen gar nicht im Rule Pack; sie sperren ueber hosts-Datei
//      und Chromium-Sperrliste, und die Freigabedatei fasst beide nie an.
//   3. freigegeben steht vor gelernt UND vor gemerkt - ein falsch gelernter
//      Host waere sonst trotz eingetragener Freigabe dauerhaft unerreichbar,
//      denn adult.hostDomains IST die gelernte Liste und das 30-Tage-
//      Gedaechtnis wuerde direkt danach denselben Vorhang setzen.
//   4. gelernt/gemerkt steht vor erkannt - ein bekannter Host wird nicht neu
//      beurteilt. Die Freigabe schlaegt deshalb auch die Erkennung selbst,
//      sonst wuerde derselbe Host sofort wieder gelernt.
function adultPageLevel() {
  if (!adultAreaActive(adultRulePack)) {
    return "none";
  }
  if (typeof purestateAdultIsNeverBlockHost === "function" &&
      purestateAdultIsNeverBlockHost(location.hostname)) {
    return "none";
  }
  if (adultExemptHostMatches(adultRulePack, location.hostname)) {
    return "none";
  }
  if (adultLearnedHostMatches(adultRulePack, location.hostname)) {
    return "hard";
  }
  if (adultHostRemembered) {
    return "hard";
  }
  const verdict = detectedAdultPage();
  if (verdict === "hard") {
    reportLearnedHost(location.hostname);
  }
  return verdict;
}

function readAdultStore(callback) {
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local &&
        typeof chrome.storage.local.get === "function") {
      chrome.storage.local.get(null, (items) => {
        if (chrome.runtime && chrome.runtime.lastError) {
          callback(null);
          return;
        }
        callback(items && typeof items === "object" ? items : {});
      });
      return;
    }
  } catch {
  }
  if (!globalThis.__purestateAdultFallback) {
    globalThis.__purestateAdultFallback = {};
  }
  callback(globalThis.__purestateAdultFallback);
}

function writeAdultHostMemory(map) {
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local &&
        typeof chrome.storage.local.set === "function") {
      const values = {};
      values[ADULT_HOST_MEMORY_KEY] = map;
      chrome.storage.local.set(values, () => {});
      return;
    }
  } catch {
  }
  if (!globalThis.__purestateAdultFallback) {
    globalThis.__purestateAdultFallback = {};
  }
  globalThis.__purestateAdultFallback[ADULT_HOST_MEMORY_KEY] = map;
}

function loadAdultHostMemory(done) {
  readAdultStore((items) => {
    const map = items && typeof items[ADULT_HOST_MEMORY_KEY] === "object" && items[ADULT_HOST_MEMORY_KEY]
      ? items[ADULT_HOST_MEMORY_KEY]
      : {};
    const seen = map[location.hostname];
    if (typeof seen === "number" && Date.now() - seen <= ADULT_HOST_MEMORY_MS) {
      adultHostRemembered = true;
    }
    done();
  });
}

function rememberAdultHost(host) {
  adultHostRemembered = true;
  readAdultStore((items) => {
    const stored = items && typeof items[ADULT_HOST_MEMORY_KEY] === "object" && items[ADULT_HOST_MEMORY_KEY]
      ? items[ADULT_HOST_MEMORY_KEY]
      : {};
    const now = Date.now();
    stored[host] = now;
    // Abgelaufene Eintraege beim Schreiben mitraeumen, statt den Speicher
    // unbegrenzt wachsen zu lassen.
    const fresh = {};
    for (const key of Object.keys(stored)) {
      if (typeof stored[key] === "number" && now - stored[key] <= ADULT_HOST_MEMORY_MS) {
        fresh[key] = stored[key];
      }
    }
    writeAdultHostMemory(fresh);
  });
}

// Der Background bestaetigt erst, nachdem der Host in seiner persistenten,
// gedrosselten Retry-Queue liegt. Native-Host-/Guard-Ausfaelle duerfen hier
// trotzdem weder synchron noch als unbehandelte Promise-Ablehnung auftauchen.
function reportLearnedHost(host) {
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return;
    }
    let admitted = false;
    const handleResponse = (response) => {
      if (admitted || (chrome.runtime && chrome.runtime.lastError)) {
        return;
      }
      if (response && (response.ok === true || response.pending === true)) {
        admitted = true;
        rememberAdultHost(host);
      }
    };
    const maybePromise = chrome.runtime.sendMessage(
      { type: ADULT_LEARN_HOST_MESSAGE, host: host },
      handleResponse
    );
    if (maybePromise && typeof maybePromise.then === "function") {
      maybePromise.then(handleResponse).catch(() => {});
    }
  } catch {
  }
}

function requestAdultRules() {
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return;
    }
    const maybePromise = chrome.runtime.sendMessage({ type: ADULT_RULES_GET, site: "adult" }, applyAdultRules);
    if (maybePromise && typeof maybePromise.then === "function") {
      maybePromise.then(applyAdultRules).catch(() => {});
    }
  } catch {
  }
}

function installAdultPushListener() {
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.onMessage || typeof chrome.runtime.onMessage.addListener !== "function") {
      return;
    }
    chrome.runtime.onMessage.addListener((message) => {
      if (message && message.type === "purestate.rulesUpdated") {
        applyAdultRules(message);
      }
      return false;
    });
  } catch {
  }
}

function applyAdultRules(response) {
  adultRulePack = response && response.rules && typeof response.rules === "object" ? response.rules : null;
  evaluateAdultPage();
}

function evaluateAdultPage() {
  const level = adultPageLevel();
  if (level === "hard") {
    removeAdultBanner();
    showAdultCurtain();
    return;
  }
  removeAdultCurtain();
  if (level === "soft") {
    showAdultBanner();
  } else {
    removeAdultBanner();
  }
}

// Vollvorhang mit dem Vorhang-Baukasten aus adult-search-terms.js. Verhalten
// (Sofort-Ausblenden, Fokus-Halt, Zurueck-Ziel) bleibt hier.
function showAdultCurtain() {
  const doc = document;
  if (!doc.documentElement || (doc.getElementById && doc.getElementById(ADULT_CURTAIN_ID))) {
    return;
  }
  if (typeof purestateInstantHide === "function") {
    purestateInstantHide(doc, ADULT_CURTAIN_ID + "-style");
  }
  const theme = purestateCurtainTheme(doc);

  doc.documentElement.style.setProperty("overflow", "hidden", "important");
  if (doc.body) {
    doc.body.style.setProperty("overflow", "hidden", "important");
  }

  const overlay = doc.createElement("div");
  overlay.id = ADULT_CURTAIN_ID;
  overlay.setAttribute("role", "alertdialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-live", "assertive");
  overlay.setAttribute("aria-label", "Purestate Erwachseneninhalt gesperrt");
  overlay.setAttribute("aria-labelledby", ADULT_CURTAIN_ID + "-title");
  overlay.setAttribute("tabindex", "-1");
  // EXT-A05: eigener Scroll + margin:auto statt abschneidender Zentrierung.
  overlay.style.cssText = purestateCurtainOverlayCss(theme);

  const column = purestateCurtainColumn(doc);
  column.appendChild(purestateCurtainBars(doc, theme, "lg"));
  column.appendChild(purestateCurtainText(doc, theme, "Purestate", "label"));
  column.appendChild(purestateCurtainTitle(doc, theme, ADULT_CURTAIN_ID + "-title", "Erwachseneninhalt gesperrt", "curtain"));
  column.appendChild(purestateCurtainText(doc, theme, "Diese Seite wurde als Erwachsenenangebot erkannt und ist gesperrt.", "detail"));

  const back = purestateCurtainButton(doc, theme, "Zurück", "primary");
  back.setAttribute("aria-label", "Zurück zur vorherigen Seite");
  back.addEventListener("click", (event) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    navigateBackFromAdultCurtain(doc);
  }, true);
  const actions = purestateCurtainActions(doc);
  actions.appendChild(back);
  column.appendChild(actions);

  overlay.appendChild(column);
  (doc.body || doc.documentElement).appendChild(overlay);
  if (typeof purestateHoldOverlayFocus === "function") {
    purestateHoldOverlayFocus(doc, overlay, back);
  } else if (typeof overlay.focus === "function") {
    overlay.focus();
  }
}

function navigateBackFromAdultCurtain(doc) {
  try {
    const view = doc.defaultView || (typeof window !== "undefined" ? window : null);
    if (!view) {
      return;
    }
    const origin = view.location.origin;
    // Der Vorhang sperrt den ganzen Host: dessen Startseite zeigt denselben
    // Vorhang wieder (live 2026-09-18). Deshalb auf eine neutrale Seite.
    if (view.history && view.history.length > 1) {
      view.history.back();
      view.setTimeout(() => {
        try {
          if (view.location.origin === origin) {
            view.location.assign("about:blank");
          }
        } catch {
        }
      }, 250);
    } else {
      view.location.assign("about:blank");
    }
  } catch {
  }
}

function removeAdultCurtain() {
  if (!document.getElementById) {
    return;
  }
  const overlay = document.getElementById(ADULT_CURTAIN_ID);
  if (!overlay) {
    return;
  }
  if (overlay.parentElement) {
    overlay.parentElement.removeChild(overlay);
  }
  if (typeof purestateRemoveInstantHide === "function") {
    purestateRemoveInstantHide(document, ADULT_CURTAIN_ID + "-style");
  }
  // Erst nach dem Sichtbarmachen: ein unsichtbarer Knopf nimmt keinen Fokus.
  if (typeof purestateReleaseOverlayFocus === "function") {
    purestateReleaseOverlayFocus(overlay);
  }
  if (document.documentElement) {
    document.documentElement.style.removeProperty("overflow");
  }
  if (document.body) {
    document.body.style.removeProperty("overflow");
  }
}

// Warnleiste: ein schmaler position:fixed-Streifen oben, der die Seite nicht
// verdeckt. Anders als der Vollvorhang braucht sie keinen MutationObserver -
// sie blockiert nichts, sie warnt nur.
function showAdultBanner() {
  const doc = document;
  if (!doc.documentElement || (doc.getElementById && doc.getElementById(ADULT_BANNER_ID))) {
    return;
  }
  const theme = purestateCurtainTheme(doc);
  const banner = doc.createElement("div");
  banner.id = ADULT_BANNER_ID;
  banner.setAttribute("role", "status");
  banner.setAttribute("aria-label", "Purestate Warnung");
  banner.style.cssText = purestateCurtainCss([
    "position:fixed", "top:0", "left:0", "right:0", "z-index:2147483647",
    "padding:8px 16px", "box-sizing:border-box", "background:" + theme.warnBg,
    "color:" + theme.ink, "border-bottom:1px solid " + theme.line,
    "font:14px " + theme.fontText, "text-align:center",
    "pointer-events:none", "visibility:visible"
  ]);
  const label = doc.createElement("span");
  label.textContent = "Purestate";
  label.style.cssText = purestateCurtainCss([
    "font-family:" + theme.fontMono, "font-size:12px", "letter-spacing:.16em",
    "text-transform:uppercase", "color:" + theme.warn, "margin-right:8px"
  ]);
  const text = doc.createElement("span");
  // Das fuehrende Leerzeichen haelt textContent der Leiste lesbar.
  text.textContent = " Diese Seite könnte Erwachseneninhalte zeigen.";
  banner.appendChild(label);
  banner.appendChild(text);
  (doc.body || doc.documentElement).appendChild(banner);
}

function removeAdultBanner() {
  if (!document.getElementById) {
    return;
  }
  const banner = document.getElementById(ADULT_BANNER_ID);
  if (banner && banner.parentElement) {
    banner.parentElement.removeChild(banner);
  }
}

function installAdultPageModule() {
  requestAdultRules();
  installAdultPushListener();
  loadAdultHostMemory(evaluateAdultPage);
  if (typeof document.addEventListener === "function") {
    document.addEventListener("DOMContentLoaded", evaluateAdultPage);
  }
  if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
    window.addEventListener("load", evaluateAdultPage);
  }
  setInterval(evaluateAdultPage, 15000);
}

installAdultPageModule();
