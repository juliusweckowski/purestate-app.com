using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;

namespace Purestate.App
{
    internal static class PurestateVisualIdentity
    {
        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool DestroyIcon(IntPtr handle);

        // Abgerundete Kachel als Untergrund. Sie bleibt in jeder Groesse: ohne
        // sie stuende das helle Zeichen auf einem hellen Hintergrund im Nichts.
        private static System.Drawing.Drawing2D.GraphicsPath RoundedTile(float size, float radius)
        {
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            float diameter = radius * 2;
            path.AddArc(0, 0, diameter, diameter, 180, 90);
            path.AddArc(size - diameter, 0, diameter, diameter, 270, 90);
            path.AddArc(size - diameter, size - diameter, diameter, diameter, 0, 90);
            path.AddArc(0, size - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();
            return path;
        }

        // Saeule mit abgerundeten Ecken, wie rx="3.5" im SVG der Webseite. Als
        // spitzes Rechteck wich das Zeichen in grossen Groessen (Startmenue,
        // Alt-Tab) sichtbar vom Zeichen der Webseite ab.
        private static System.Drawing.Drawing2D.GraphicsPath RoundedBar(float x, float y, float width, float height, float radius)
        {
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            float diameter = radius * 2;
            path.AddArc(x, y, diameter, diameter, 180, 90);
            path.AddArc(x + width - diameter, y, diameter, diameter, 270, 90);
            path.AddArc(x + width - diameter, y + height - diameter, diameter, diameter, 0, 90);
            path.AddArc(x, y + height - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();
            return path;
        }

        // Die beiden Boegen des Schildes, Koordinaten wie in
        // website/public/favicon.svg (viewBox 0 0 128 128).
        private static System.Drawing.Drawing2D.GraphicsPath ShieldHalf(bool left, float s)
        {
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            if (left)
            {
                path.AddLine(56 * s, 18 * s, 22 * s, 34 * s);
                path.AddLine(22 * s, 34 * s, 22 * s, 61 * s);
                path.AddBezier(22 * s, 61 * s, 22 * s, 86 * s, 35.5f * s, 106 * s, 56 * s, 117 * s);
            }
            else
            {
                path.AddLine(72 * s, 18 * s, 106 * s, 34 * s);
                path.AddLine(106 * s, 34 * s, 106 * s, 61 * s);
                path.AddBezier(106 * s, 61 * s, 106 * s, 86 * s, 92.5f * s, 106 * s, 72 * s, 117 * s);
            }
            return path;
        }

        // Das Zeichen der Webseite, in GDI+ nachgezogen: zwei Boegen, die ein
        // Schild bilden, dazu die zwei Saeulen. Vorher stand hier ein blosses
        // "P" - App, Taskleiste und Infobereich zeigen jetzt dieselbe Marke
        // wie purestate-app.com.
        //
        // Gezeichnet wird die dunkle Fassung auf einer Navy-Kachel: der dunkle
        // Bogen des hellen Entwurfs waere auf einer dunklen Taskleiste kaum zu
        // sehen.
        public static void DrawMark(Graphics graphics, float size)
        {
            float s = size / 128f;
            graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            using (System.Drawing.Drawing2D.GraphicsPath tile = RoundedTile(size, size * 0.22f))
            using (SolidBrush navy = new SolidBrush(Color.FromArgb(10, 26, 49)))
            {
                graphics.FillPath(navy, tile);
            }

            Color silver = Color.FromArgb(233, 238, 247);
            float stroke = 11.5f * s;

            using (System.Drawing.Drawing2D.GraphicsPath left = ShieldHalf(true, s))
            using (Pen pen = new Pen(silver, stroke))
            {
                pen.LineJoin = System.Drawing.Drawing2D.LineJoin.Miter;
                graphics.DrawPath(pen, left);
            }

            using (System.Drawing.Drawing2D.GraphicsPath right = ShieldHalf(false, s))
            using (System.Drawing.Drawing2D.LinearGradientBrush teal = new System.Drawing.Drawing2D.LinearGradientBrush(
                new PointF(72 * s, 16 * s), new PointF(111 * s, 112 * s),
                Color.FromArgb(73, 195, 189), Color.FromArgb(42, 168, 166)))
            using (Pen pen = new Pen(teal, stroke))
            {
                pen.LineJoin = System.Drawing.Drawing2D.LineJoin.Miter;
                graphics.DrawPath(pen, right);
            }

            using (SolidBrush pillar = new SolidBrush(silver))
            using (System.Drawing.Drawing2D.GraphicsPath leftBar = RoundedBar(48 * s, 51 * s, 12 * s, 34 * s, 3.5f * s))
            using (System.Drawing.Drawing2D.GraphicsPath rightBar = RoundedBar(68 * s, 51 * s, 12 * s, 34 * s, 3.5f * s))
            {
                graphics.FillPath(pillar, leftBar);
                graphics.FillPath(pillar, rightBar);
            }
        }

        public static Icon CreateIcon(int size)
        {
            int dimension = Math.Max(16, size);
            using (Bitmap bitmap = new Bitmap(dimension, dimension))
            using (Graphics graphics = Graphics.FromImage(bitmap))
            {
                graphics.Clear(Color.Transparent);
                DrawMark(graphics, dimension);

                IntPtr handle = bitmap.GetHicon();
                try
                {
                    return (Icon)Icon.FromHandle(handle).Clone();
                }
                finally
                {
                    DestroyIcon(handle);
                }
            }
        }
    }
}
