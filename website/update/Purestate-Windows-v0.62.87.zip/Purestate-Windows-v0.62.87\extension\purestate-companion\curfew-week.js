"use strict";

// Purestate weekly curfew plan (0.62.87).
//
// A curfew area (shopping, social media) keeps its standard window, for
// example 22:00-06:00, and may treat single evenings differently. The plan is
// seven comma-separated entries, Monday to Sunday: "std" (standard window),
// "off" (no curfew that evening) or "HH:MM-HH:MM" (own window). An entry
// belongs to the evening the curfew starts: a window that starts before 04:00
// starts on the next calendar day, because before 04:00 it is still the night
// of the evening before - the same 04:00 budget day the daily budgets use.
// Loaded before shopping-content.js and social-media-content.js. The guard
// (VideoGamesGuard) and the app implement the same rules;
// tests/fixtures/curfew-week-cases.json is the contract for all of them.
(function () {
  const DAY_START = 4 * 60;
  const DAY = 24 * 60;

  function parseClock(text) {
    const match = /^(\d{1,2}):(\d{2})$/.exec(String(text == null ? "" : text).trim());
    if (!match) {
      return -1;
    }
    const hours = parseInt(match[1], 10);
    const minutes = parseInt(match[2], 10);
    if (hours > 23 || minutes > 59) {
      return -1;
    }
    return hours * 60 + minutes;
  }

  function clockText(minutes) {
    const hours = Math.floor(minutes / 60);
    const rest = minutes % 60;
    return (hours < 10 ? "0" : "") + hours + ":" + (rest < 10 ? "0" : "") + rest;
  }

  // "" means "every evening standard". A wrong count or an unreadable entry
  // makes the whole plan "" - never something looser than the standard.
  function normalize(text) {
    const parts = String(text == null ? "" : text).split(",");
    if (parts.length !== 7) {
      return "";
    }
    const tokens = [];
    for (const part of parts) {
      const token = part.trim().toLowerCase();
      if (token === "std" || token === "off") {
        tokens.push(token);
        continue;
      }
      const times = token.split("-");
      if (times.length !== 2) {
        return "";
      }
      const start = parseClock(times[0]);
      const end = parseClock(times[1]);
      if (start < 0 || end < 0) {
        return "";
      }
      tokens.push(start === end ? "off" : clockText(start) + "-" + clockText(end));
    }
    return tokens.every((token) => token === "std") ? "" : tokens.join(",");
  }

  // weekdayMon0: calendar day of the clock, Monday = 0. minuteOfDay: wall
  // clock. Only the evening of the current budget day and the one before can
  // cover the moment; until is the end of the window that lasts longest.
  function evaluate(enabled, start, end, week, weekdayMon0, minuteOfDay) {
    if (enabled !== true) {
      return { active: false, until: "" };
    }
    const tokens = normalize(week).split(",");
    const budgetDay = minuteOfDay < DAY_START ? (weekdayMon0 + 6) % 7 : weekdayMon0;
    const offset = (minuteOfDay - DAY_START + DAY) % DAY;
    let latest = -1;
    let until = "";
    for (const [row, position] of [[budgetDay, offset], [(budgetDay + 6) % 7, offset + DAY]]) {
      const token = tokens.length === 7 ? tokens[row] : "std";
      if (token === "off") {
        continue;
      }
      const times = token === "std" ? [start, end] : token.split("-");
      const from = parseClock(times[0]);
      const to = parseClock(times[1]);
      if (from < 0 || to < 0) {
        continue;
      }
      const length = (to - from + DAY) % DAY;
      const begin = (from - DAY_START + DAY) % DAY;
      if (length > 0 && position >= begin && position < begin + length) {
        const finish = begin + length - (position - offset);
        if (finish > latest) {
          latest = finish;
          until = clockText(to);
        }
      }
    }
    return latest < 0 ? { active: false, until: "" } : { active: true, until: until };
  }

  function evaluateAt(enabled, start, end, week, date) {
    return evaluate(enabled, start, end, week, (date.getDay() + 6) % 7, date.getHours() * 60 + date.getMinutes());
  }

  globalThis.purestateCurfewWeek = Object.freeze({ normalize: normalize, evaluate: evaluate, evaluateAt: evaluateAt });
})();
