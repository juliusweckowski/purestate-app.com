using System;
using System.Drawing;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // Shared small dialogs: password prompts, pause duration, free-text
    // prompt, report viewer, dev mode and the two website-list managers.
    internal sealed partial class AdminForm
    {
        private static string FormatLockoutDuration(int seconds)
        {
            if (seconds < 60)
            {
                return Math.Max(1, seconds) + " Sekunden";
            }

            int minutes = (int)Math.Ceiling(seconds / 60.0);
            return minutes + (minutes == 1 ? " Minute" : " Minuten");
        }

        private bool ConfirmPassword(string action)
        {
            return ConfirmPassword(action, this);
        }

        // Verifies the password inside the dialog: a typo shows an inline error
        // and keeps the dialog open (up to 3 attempts). Every rejected attempt
        // is security-logged; the throttle in Support stays authoritative.
        private bool ConfirmPassword(string action, IWin32Window owner)
        {
            AppConfig config = Support.LoadConfig();
            string prompt = "Bitte gib das Purestate-Passwort ein:";
            if (!string.IsNullOrEmpty(config.PasswordHint))
            {
                prompt = "Hinweis: " + config.PasswordHint;
            }

            using (Form dialog = new Form())
            {
                dialog.Text = "Passwort";
                Ui.PrepareForm(dialog, "Passwort", "Passwortabfrage für eine geschützte Purestate-Aktion.");
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.MaximizeBox = false;
                dialog.MinimizeBox = false;
                dialog.ClientSize = new Size(440, 196);
                dialog.BackColor = theme.WindowBackground;
                dialog.HandleCreated += delegate { Ui.ApplyDarkTitleBar(dialog.Handle, theme.IsDark); };

                Label label = Ui.WrapLabel(theme, prompt, 400, false);
                label.Location = new Point(20, 18);
                dialog.Controls.Add(label);

                TextBox box = new TextBox();
                box.Location = new Point(20, 66);
                box.Size = new Size(400, 26);
                box.Font = Ui.FontBody;
                box.UseSystemPasswordChar = true;
                box.TabIndex = 0;
                Ui.SetAccessibility(box, "Passwort", "Purestate-Passwort eingeben.", AccessibleRole.Text);
                dialog.Controls.Add(box);

                Label errorLabel = new Label();
                errorLabel.Text = string.Empty;
                errorLabel.Location = new Point(20, 98);
                errorLabel.Size = new Size(400, 36);
                errorLabel.Font = Ui.FontHint;
                errorLabel.ForeColor = theme.DangerRed;
                errorLabel.Visible = false;
                Ui.SetAccessibility(errorLabel, "Passwortfehler", "Hinweis, dass das eingegebene Passwort falsch war.", AccessibleRole.StaticText);
                dialog.Controls.Add(errorLabel);

                Button ok = Ui.PrimaryButton(theme, "OK", "Bestätigt das eingegebene Passwort.");
                ok.Location = new Point(212, 142);
                ok.TabIndex = 1;
                dialog.AcceptButton = ok;
                dialog.Controls.Add(ok);

                Button cancel = Ui.SecondaryButton(theme, "Abbrechen", "Bricht die Aktion ohne Passwort ab.");
                cancel.Location = new Point(318, 142);
                cancel.DialogResult = DialogResult.Cancel;
                cancel.TabIndex = 2;
                dialog.CancelButton = cancel;
                dialog.Controls.Add(cancel);

                const int maxAttempts = 3;
                int failedAttempts = 0;
                bool verified = false;
                bool lockedOut = false;

                ok.Click += delegate
                {
                    int lockoutRemaining;
                    PasswordCheckResult check = Support.VerifyPasswordThrottled(box.Text, out lockoutRemaining);
                    if (check == PasswordCheckResult.Success)
                    {
                        verified = true;
                        Support.WriteSecurityLog("Password accepted: " + action);
                        dialog.DialogResult = DialogResult.OK;
                        return;
                    }

                    if (check == PasswordCheckResult.LockedOut || lockoutRemaining > 0)
                    {
                        lockedOut = true;
                        Support.WriteSecurityLog("Password locked out: " + action);
                        errorLabel.Text = "Zu viele Fehlversuche. Bitte " + FormatLockoutDuration(lockoutRemaining) + " warten.";
                        errorLabel.Visible = true;
                        box.Text = string.Empty;
                        dialog.DialogResult = DialogResult.Cancel;
                        return;
                    }

                    failedAttempts++;
                    Support.WriteSecurityLog("Password rejected: " + action);
                    if (failedAttempts >= maxAttempts)
                    {
                        dialog.DialogResult = DialogResult.Cancel;
                        return;
                    }

                    errorLabel.Text = "Das Passwort ist falsch (Versuch " + failedAttempts + " von " + maxAttempts + ").";
                    errorLabel.AccessibleName = "Passwortfehler: " + errorLabel.Text;
                    errorLabel.Visible = true;
                    box.Text = string.Empty;
                    box.Focus();
                };

                dialog.Shown += delegate { box.Focus(); };
                DialogResult result = dialog.ShowDialog(owner);

                if (verified && result == DialogResult.OK)
                {
                    return true;
                }

                if (lockedOut)
                {
                    Ui.Inform(owner, theme, "Passwort", "Zu viele Fehlversuche. Die Passworteingabe ist vorübergehend gesperrt.");
                }
                else if (failedAttempts >= maxAttempts)
                {
                    Ui.Inform(owner, theme, "Passwort", "Das Passwort wurde " + maxAttempts + "-mal falsch eingegeben.");
                }
                else
                {
                    Support.WriteSecurityLog("Password prompt cancelled: " + action);
                }

                return false;
            }
        }

        private void ChangePassword()
        {
            if (!ConfirmPassword("Passwort ändern"))
            {
                return;
            }

            string newPassword;
            string newHint;
            if (!PromptNewPassword(out newPassword, out newHint))
            {
                return;
            }

            RunAction("Passwort ändern", delegate
            {
                Support.SetPassword(newPassword, newHint);
            }, delegate (bool success)
            {
                if (success)
                {
                    ShowSaveFeedback("Das Passwort wurde geändert.");
                }
            });
        }

        private bool PromptNewPassword(out string password, out string hint)
        {
            password = string.Empty;
            hint = string.Empty;
            using (Form dialog = new Form())
            {
                dialog.Text = "Neues Passwort";
                Ui.PrepareForm(dialog, "Neues Passwort", "Legt ein neues Purestate-Passwort und einen optionalen Hinweis fest.");
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.MaximizeBox = false;
                dialog.MinimizeBox = false;
                dialog.ClientSize = new Size(460, 260);
                dialog.BackColor = theme.WindowBackground;
                dialog.HandleCreated += delegate { Ui.ApplyDarkTitleBar(dialog.Handle, theme.IsDark); };

                Label firstLabel = Ui.WrapLabel(theme, "Neues Passwort", 160, false);
                firstLabel.Location = new Point(20, 22);
                dialog.Controls.Add(firstLabel);

                TextBox first = new TextBox();
                first.Location = new Point(190, 18);
                first.Size = new Size(240, 26);
                first.Font = Ui.FontBody;
                first.UseSystemPasswordChar = true;
                first.TabIndex = 0;
                Ui.SetAccessibility(first, "Neues Passwort", "Neues Purestate-Passwort mit mindestens zwölf Zeichen.", AccessibleRole.Text);
                dialog.Controls.Add(first);

                Label secondLabel = Ui.WrapLabel(theme, "Wiederholen", 160, false);
                secondLabel.Location = new Point(20, 64);
                dialog.Controls.Add(secondLabel);

                TextBox second = new TextBox();
                second.Location = new Point(190, 60);
                second.Size = new Size(240, 26);
                second.Font = Ui.FontBody;
                second.UseSystemPasswordChar = true;
                second.TabIndex = 1;
                Ui.SetAccessibility(second, "Passwort wiederholen", "Neues Purestate-Passwort erneut eingeben.", AccessibleRole.Text);
                dialog.Controls.Add(second);

                Label hintLabel = Ui.WrapLabel(theme, "Hinweis (optional)", 160, false);
                hintLabel.Location = new Point(20, 106);
                dialog.Controls.Add(hintLabel);

                TextBox hintBox = new TextBox();
                hintBox.Location = new Point(190, 102);
                hintBox.Size = new Size(240, 26);
                hintBox.Font = Ui.FontBody;
                hintBox.MaxLength = 120;
                hintBox.Text = Support.LoadConfig().PasswordHint;
                hintBox.TabIndex = 2;
                Ui.SetAccessibility(hintBox, "Passworthinweis", "Optionaler Hinweis, der bei der Passwortabfrage angezeigt wird.", AccessibleRole.Text);
                dialog.Controls.Add(hintBox);

                Label errorLabel = new Label();
                errorLabel.Text = string.Empty;
                errorLabel.Location = new Point(20, 140);
                errorLabel.Size = new Size(410, 48);
                errorLabel.Font = Ui.FontHint;
                errorLabel.ForeColor = theme.DangerRed;
                errorLabel.Visible = false;
                Ui.SetAccessibility(errorLabel, "Passwortfehler", "Erklärt, warum das neue Passwort noch nicht übernommen werden kann.", AccessibleRole.StaticText);
                dialog.Controls.Add(errorLabel);

                Button ok = Ui.PrimaryButton(theme, "Passwort speichern", "Übernimmt das neue Passwort.");
                ok.Location = new Point(158, 200);
                ok.TabIndex = 3;
                dialog.AcceptButton = ok;
                dialog.Controls.Add(ok);

                Button cancel = Ui.SecondaryButton(theme, "Abbrechen", "Behält das bisherige Passwort.");
                cancel.Location = new Point(330, 200);
                cancel.DialogResult = DialogResult.Cancel;
                cancel.TabIndex = 4;
                dialog.CancelButton = cancel;
                dialog.Controls.Add(cancel);

                Action<string, TextBox> showError = delegate (string message, TextBox focusTarget)
                {
                    errorLabel.Text = message;
                    errorLabel.AccessibleName = "Passwortfehler: " + message;
                    errorLabel.Visible = true;
                    focusTarget.SelectAll();
                    focusTarget.Focus();
                };

                ok.Click += delegate
                {
                    string passwordPolicyError = Support.GetPasswordPolicyError(first.Text, hintBox.Text);
                    if (!string.IsNullOrEmpty(passwordPolicyError))
                    {
                        showError(passwordPolicyError, first);
                        return;
                    }

                    if (!string.Equals(first.Text, second.Text, StringComparison.Ordinal))
                    {
                        showError("Die Passwörter stimmen nicht überein.", second);
                        return;
                    }

                    dialog.DialogResult = DialogResult.OK;
                };

                dialog.Shown += delegate { first.Focus(); };
                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return false;
                }

                password = first.Text;
                hint = Support.CleanPasswordHint(hintBox.Text);
                return true;
            }
        }

        private bool PromptPauseDuration(out int minutes)
        {
            minutes = 0;
            using (Form dialog = new Form())
            {
                dialog.Text = "Schutz pausieren";
                Ui.PrepareForm(dialog, "Schutz pausieren", "Wählt, wie lange der Purestate-Schutz pausiert werden soll.");
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.MaximizeBox = false;
                dialog.MinimizeBox = false;
                dialog.ClientSize = new Size(440, 200);
                dialog.BackColor = theme.WindowBackground;
                dialog.HandleCreated += delegate { Ui.ApplyDarkTitleBar(dialog.Handle, theme.IsDark); };

                Label label = Ui.WrapLabel(theme, "Wie lange soll der Schutz pausiert werden? Danach schaltet er sich von selbst wieder ein.", 400, false);
                label.Location = new Point(20, 18);
                dialog.Controls.Add(label);

                ComboBox choices = new ComboBox();
                choices.DropDownStyle = ComboBoxStyle.DropDownList;
                choices.Location = new Point(20, 74);
                choices.Size = new Size(400, 28);
                choices.Font = Ui.FontBody;
                choices.Items.Add("15 Minuten");
                choices.Items.Add("30 Minuten");
                choices.Items.Add("60 Minuten");
                choices.Items.Add("Bis morgen");
                choices.Items.Add("Bis ich ihn selbst wieder aktiviere");
                choices.SelectedIndex = 1;
                choices.TabIndex = 0;
                Ui.StyleInput(theme, choices);
                Ui.SetAccessibility(choices, "Pausendauer", "Auswahl, wie lange Purestate pausiert werden soll.", AccessibleRole.ComboBox);
                dialog.Controls.Add(choices);

                Button ok = Ui.PrimaryButton(theme, "Schutz pausieren", "Pausiert den Schutz für die gewählte Dauer.");
                ok.DialogResult = DialogResult.OK;
                ok.TabIndex = 1;
                dialog.AcceptButton = ok;

                Button cancel = Ui.SecondaryButton(theme, "Abbrechen", "Lässt den Schutz aktiv.");
                cancel.DialogResult = DialogResult.Cancel;
                cancel.TabIndex = 2;
                dialog.CancelButton = cancel;
                cancel.Margin = new Padding(Ui.GapSmall, 0, 0, 0);

                FlowLayoutPanel actions = new FlowLayoutPanel
                {
                    Dock = DockStyle.Bottom,
                    FlowDirection = FlowDirection.RightToLeft,
                    AutoSize = true,
                    Padding = new Padding(Ui.GapGroup, Ui.GapSmall, Ui.GapGroup, Ui.GapSmall)
                };
                actions.Controls.Add(cancel);
                actions.Controls.Add(ok);
                dialog.Controls.Add(actions);

                dialog.Shown += delegate { choices.Focus(); };
                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return false;
                }

                int[] values = { 15, 30, 60, 24 * 60, 0 };
                minutes = values[Math.Max(0, choices.SelectedIndex)];
                return true;
            }
        }

        private bool PromptText(string title, string prompt, out string value)
        {
            value = string.Empty;
            using (Form dialog = new Form())
            {
                dialog.Text = title;
                Ui.PrepareForm(dialog, title, prompt);
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.MaximizeBox = false;
                dialog.MinimizeBox = false;
                dialog.ClientSize = new Size(440, 160);
                dialog.BackColor = theme.WindowBackground;
                dialog.HandleCreated += delegate { Ui.ApplyDarkTitleBar(dialog.Handle, theme.IsDark); };

                Label label = Ui.WrapLabel(theme, prompt, 400, false);
                label.Location = new Point(20, 16);
                dialog.Controls.Add(label);

                TextBox box = new TextBox();
                box.Location = new Point(20, 52);
                box.Size = new Size(400, 26);
                box.Font = Ui.FontBody;
                box.TabIndex = 0;
                Ui.SetAccessibility(box, Ui.CleanMnemonic(prompt), prompt, AccessibleRole.Text);
                dialog.Controls.Add(box);

                Button ok = Ui.PrimaryButton(theme, "Übernehmen", "Übernimmt die Eingabe.");
                ok.DialogResult = DialogResult.OK;
                ok.TabIndex = 1;
                dialog.AcceptButton = ok;

                Button cancel = Ui.SecondaryButton(theme, "Abbrechen", "Verwirft die Eingabe.");
                cancel.DialogResult = DialogResult.Cancel;
                cancel.TabIndex = 2;
                dialog.CancelButton = cancel;
                cancel.Margin = new Padding(Ui.GapSmall, 0, 0, 0);

                FlowLayoutPanel actions = new FlowLayoutPanel
                {
                    Dock = DockStyle.Bottom,
                    FlowDirection = FlowDirection.RightToLeft,
                    AutoSize = true,
                    Padding = new Padding(Ui.GapGroup, Ui.GapSmall, Ui.GapGroup, Ui.GapSmall)
                };
                actions.Controls.Add(cancel);
                actions.Controls.Add(ok);
                dialog.Controls.Add(actions);

                dialog.Shown += delegate { box.Focus(); };
                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return false;
                }

                value = box.Text;
                return true;
            }
        }

        // UIX-003: Der Befund liest "allowSave: false" als "dieser Bericht soll
        // das Geraet nicht verlassen" und haelt es fuer einen Widerspruch, dass
        // der Kopierknopf trotzdem kopiert. Nachgesehen: die beiden Aufrufer mit
        // false zeigen reinen Hilfetext (Anlaufstellen, Erklaerung des
        // Browser-Schutzes) - keine Geraetedaten. Der Schalter sagt also "das
        // ist Fliesstext, keine Datei wert", nicht "vertraulich".
        //
        // Der Fehler war der NAME. Kopieren zu verbieten waere die falsche
        // Antwort gewesen: es haette einem Nutzer, der eine Telefonnummer aus
        // der Hilfe braucht, grundlos im Weg gestanden. Wer echte Geraetedaten
        // zeigt, ruft mit offerSave: true auf und bekommt den Hinweis darueber,
        // was im Bericht steht (PRIV-009).
        // Aufbau, Kopieren (PRIV-009) und Speichern leben in Ui.BuildTextDialog,
        // damit die Aktionsleiste ohne AdminForm testbar ist (DESK-02/DESK-10).
        private void ShowTextDialog(string title, string text, bool offerSave)
        {
            using (Form dialog = Ui.BuildTextDialog(theme, title, text, offerSave))
            {
                dialog.ShowDialog(this);
            }
        }

        // Dev-only: trusts one developer-supplied Companion extension ID and
        // releases the official Store force-install policy while active.
        // Password-gated like every protection-affecting setting.
        private void ShowDevCompanionMode()
        {
            // ENS-001: zweiter Riegel neben dem fehlenden Eintrag in MorePage -
            // im ausgelieferten Bau fuehrt kein Weg hierher.
            if (!Support.DevBuild)
            {
                return;
            }

            if (!ConfirmPassword("Dev-Modus öffnen"))
            {
                return;
            }

            using (DialogShell shell = new DialogShell(theme, "Dev-Modus",
                "Nur für Entwicklung auf einem Gerät, das du selbst vollständig kontrollierst.",
                "Vertraut testweise einer zusätzlichen, nicht-offiziellen Companion-Erweiterung.", false))
            {
                shell.AddHint("Purestate vertraut der hier eingetragenen Erweiterungs-ID und gibt die erzwungene " +
                    "Chrome-Web-Store-Erweiterung frei. Fehlt die Test-Erweiterung, blockiert Purestate weiterhin fail-closed.");

                string currentId = Support.GetDevCompanionId();
                shell.AddHint(currentId == null ? "Aktuell: nicht aktiv." : "Aktuell aktiv für ID: " + currentId);

                shell.AddHint("Erweiterungs-ID (aus chrome://extensions, Entwicklermodus):");
                TextBox idBox = new TextBox { Width = 400, Font = Ui.FontBody, MaxLength = 32, Text = currentId ?? string.Empty };
                Ui.SetAccessibility(idBox, "Erweiterungs-ID", "32 Kleinbuchstaben a bis p, wie in chrome://extensions angezeigt.", AccessibleRole.Text);
                shell.Add(idBox);

                Label errorLine = shell.AddErrorLine();

                Button apply = Ui.PrimaryButton(theme, "Dev-Modus aktivieren", "Vertraut der eingetragenen Erweiterungs-ID.");
                Button remove = Ui.SecondaryButton(theme, "Dev-Modus entfernen", "Entfernt die Test-Erweiterung wieder.");
                remove.Enabled = currentId != null;
                shell.Add(shell.Row(apply, remove));

                apply.Click += delegate
                {
                    string candidate = idBox.Text.Trim();
                    if (!Support.IsValidDevCompanionId(candidate))
                    {
                        shell.ShowError(errorLine, "Ungültige ID: genau 32 Kleinbuchstaben von a bis p erwartet.", idBox);
                        return;
                    }
                    shell.MarkSaved();
                    shell.Close();
                    RunAction("Dev-Modus aktivieren",
                        delegate { Support.SetDevCompanionId(candidate); },
                        delegate (bool success)
                        {
                            UpdateDevModeIndicator();
                            if (success) { ShowSaveFeedback("Der Dev-Modus ist aktiv."); }
                        });
                };
                remove.Click += delegate
                {
                    shell.MarkSaved();
                    shell.Close();
                    RunAction("Dev-Modus entfernen",
                        delegate { Support.ClearDevCompanionId(); },
                        delegate (bool success)
                        {
                            UpdateDevModeIndicator();
                            if (success) { ShowSaveFeedback("Der Dev-Modus wurde entfernt."); }
                        });
                };

                shell.FinishLayout();
                shell.Shown += delegate { idBox.Focus(); idBox.SelectAll(); };
                shell.ShowDialog(this);
            }
        }

        private void ShowDomainManager()
        {
            ShowListManager(
                "Gesperrte Webseiten",
                "Diese Webseiten sperrt Purestate zusätzlich zu den eingebauten Listen.",
                "Webseite, die gesperrt werden soll",
                delegate { Support.ApplyDueCustomDomainRemovals(); return Support.ReadCustomDomains(); },
                delegate (string domain) { return Support.AddCustomDomain(domain); },
                delegate (string domain)
                {
                    return Support.RemoveCustomDomainGuarded(
                        domain,
                        Support.CustomDomainsPath(),
                        Support.CustomDomainsAddedPath(),
                        Support.CustomDomainRemovalsPath(),
                        Support.TrustedUtcNow());
                },
                delegate { return Support.CleanCustomDomains(); },
                "Custom block domain",
                true);
        }

        private void ShowAllowListManager()
        {
            ShowListManager(
                "Erlaubte Webseiten",
                "Diese Webseiten bleiben erreichbar, auch wenn eine Sperrliste sie enthält.",
                "Webseite, die erlaubt bleiben soll",
                delegate { return Support.ReadAllowDomains(); },
                delegate (string domain) { return Support.AddAllowDomain(domain); },
                // Eine Freigabe zurueckzunehmen ist eine Verstaerkung und wirkt
                // sofort - hier gibt es nichts zu warten.
                delegate (string domain) { Support.RemoveAllowDomain(domain); return string.Empty; },
                delegate { return Support.CleanAllowDomains(); },
                "Allowlist domain",
                false);
        }

        // One implementation for both website lists - same layout, same
        // behavior, only wording and backing store differ. Changing lists is
        // protection-relevant, so it stays password-gated up front (each add/
        // remove writes immediately; a save-time gate would not work here).
        private void ShowListManager(
            string title,
            string intro,
            string addPrompt,
            Func<System.Collections.Generic.IEnumerable<string>> read,
            Func<string, bool> add,
            // Leerer Rueckgabewert = entfernt. Sonst der Hinweis, der dem
            // Nutzer angezeigt wird - seit RC-001 laeuft das Entfernen aus der
            // eigenen Sperrliste ueber eine Frist, und das muss man sehen.
            Func<string, string> remove,
            Func<int> clean,
            string logPrefix,
            bool isBlockList)
        {
            if (!ConfirmPassword(title + " verwalten"))
            {
                return;
            }

            using (Form dialog = new Form())
            {
                dialog.Text = "Purestate - " + title;
                Ui.PrepareForm(dialog, title, intro);
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.Size = new Size(680, 560);
                // DESK-02: gemessen - bei 600 px rutschte der rechts verankerte
                // "Schließen" (99 px) auf "Als Text anzeigen" (endet bei 506 px).
                dialog.MinimumSize = new Size(680, 460);
                dialog.BackColor = theme.WindowBackground;
                dialog.HandleCreated += delegate { Ui.ApplyDarkTitleBar(dialog.Handle, theme.IsDark); };

                Label introLabel = Ui.WrapLabel(theme, intro, 620, true);
                introLabel.Location = new Point(20, 14);
                dialog.Controls.Add(introLabel);

                Label searchLabel = new Label
                {
                    Text = "Suchen",
                    Font = Ui.FontBody,
                    ForeColor = theme.TextPrimary,
                    Location = new Point(20, 52),
                    AutoSize = true
                };
                dialog.Controls.Add(searchLabel);

                TextBox searchBox = new TextBox();
                searchBox.Location = new Point(96, 48);
                searchBox.Size = new Size(320, 26);
                searchBox.Font = Ui.FontBody;
                searchBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
                searchBox.TabIndex = 0;
                Ui.SetAccessibility(searchBox, title + " durchsuchen", "Filtert die angezeigten Webseiten.", AccessibleRole.Text);
                dialog.Controls.Add(searchBox);

                ListBox listBox = new ListBox();
                listBox.Location = new Point(20, 86);
                listBox.Size = new Size(624, 280);
                listBox.Font = Ui.FontBody;
                listBox.ItemHeight = 22;
                listBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
                listBox.TabIndex = 1;
                Ui.SetAccessibility(listBox, title, "Liste der Webseiten. Mit Pfeiltasten auswählen.", AccessibleRole.List);
                dialog.Controls.Add(listBox);

                Label addLabel = new Label
                {
                    Text = "Neue Webseite",
                    Font = Ui.FontBody,
                    ForeColor = theme.TextPrimary,
                    Location = new Point(20, 384),
                    AutoSize = true,
                    Anchor = AnchorStyles.Bottom | AnchorStyles.Left
                };
                dialog.Controls.Add(addLabel);

                TextBox addBox = new TextBox();
                addBox.Location = new Point(140, 380);
                addBox.Size = new Size(320, 26);
                addBox.Font = Ui.FontBody;
                addBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
                addBox.TabIndex = 2;
                Ui.SetAccessibility(addBox, addPrompt, "Adresse eingeben, zum Beispiel beispiel.de.", AccessibleRole.Text);
                dialog.Controls.Add(addBox);

                Button addButton = Ui.PrimaryButton(theme, "Webseite hinzufügen", "Fügt die eingegebene Webseite zur Liste hinzu.");
                addButton.Location = new Point(478, 376);
                addButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
                addButton.TabIndex = 3;
                dialog.Controls.Add(addButton);

                Label feedback = new Label
                {
                    Text = string.Empty,
                    Font = Ui.FontHint,
                    ForeColor = theme.TextSecondary,
                    Location = new Point(20, 412),
                    // Zwei Zeilen: der Hinweis auf die 15-Minuten-Frist ist lang
                    // und darf nicht abgeschnitten werden.
                    Size = new Size(620, 38),
                    Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
                };
                Ui.SetAccessibility(feedback, "Listen-Rückmeldung", "Bestätigt Änderungen an der Liste.", AccessibleRole.StaticText);
                dialog.Controls.Add(feedback);

                Button removeButton = Ui.SecondaryButton(theme, "Webseite entfernen", "Entfernt die ausgewählte Webseite aus der Liste.");
                removeButton.Location = new Point(20, 452);
                removeButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
                removeButton.TabIndex = 4;
                dialog.Controls.Add(removeButton);

                Button cleanButton = Ui.SecondaryButton(theme, "Liste aufräumen", "Entfernt Duplikate und ungültige Einträge.");
                cleanButton.Location = new Point(196, 452);
                cleanButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
                cleanButton.TabIndex = 5;
                dialog.Controls.Add(cleanButton);

                // DESK-04: Nur Ansicht. Vorher oeffnete dieser Knopf die AKTIVE
                // Listendatei beschreibbar im Editor - mit den Rechten der
                // erhoehten App. Eine dort geloeschte Zeile umging die
                // 15-Minuten-Frist von RemoveCustomDomainGuarded vollstaendig.
                Button viewButton = Ui.SecondaryButton(theme, "Als Text anzeigen", "Zeigt die Liste als reinen Text zum Lesen und Kopieren. Ändern geht nur über diese Verwaltung.");
                viewButton.Location = new Point(360, 452);
                viewButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
                viewButton.TabIndex = 6;
                dialog.Controls.Add(viewButton);

                Button closeButton = Ui.SecondaryButton(theme, "Schließen", "Schließt die Listenverwaltung.");
                closeButton.Location = new Point(544, 452);
                closeButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
                closeButton.TabIndex = 7;
                closeButton.DialogResult = DialogResult.Cancel;
                closeButton.Click += delegate { dialog.Close(); };
                dialog.CancelButton = closeButton;
                dialog.Controls.Add(closeButton);

                // DESK-09: Die Suche filtert eine Momentaufnahme im Speicher statt
                // bei jedem Zeichen die Datei zu lesen.
                string[] snapshot = new System.Collections.Generic.List<string>(read()).ToArray();
                bool busy = false;

                Action renderList = delegate
                {
                    string filter = searchBox.Text.Trim();
                    listBox.BeginUpdate();
                    listBox.Items.Clear();
                    foreach (string domain in snapshot)
                    {
                        if (filter.Length == 0 || domain.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            listBox.Items.Add(domain);
                        }
                    }
                    listBox.EndUpdate();
                };

                Action<string> showFeedback = delegate (string message)
                {
                    Ui.SetDynamicText(feedback, message, "Listen-Rückmeldung");
                };

                Control[] busyControls = { searchBox, listBox, addBox, addButton, removeButton, cleanButton, viewButton, closeButton };
                Action<bool> setBusy = delegate (bool value)
                {
                    busy = value;
                    foreach (Control control in busyControls)
                    {
                        control.Enabled = !value;
                    }
                    dialog.UseWaitCursor = value;
                };
                dialog.FormClosing += delegate (object sender, FormClosingEventArgs e)
                {
                    if (busy)
                    {
                        e.Cancel = true;
                    }
                };

                // DESK-09: Aendern, Liste neu lesen und Schutz neu anwenden laufen im
                // Hintergrund - in derselben Reihenfolge wie vorher im Klickhandler.
                // DESK-10: Jeder Fehler (auch bei Entfernen/Aufraeumen) landet in
                // der Rueckmeldezeile; der Dialog bleibt bedienbar.
                Action<Func<string>, Action> runListChange = delegate (Func<string> change, Action onSuccess)
                {
                    setBusy(true);
                    showFeedback("Wird gespeichert ...");
                    System.Threading.ThreadPool.QueueUserWorkItem(delegate
                    {
                        string message = null;
                        Exception failure = null;
                        string[] fresh = null;
                        try
                        {
                            message = change();
                        }
                        catch (Exception ex)
                        {
                            failure = ex;
                        }
                        try
                        {
                            fresh = new System.Collections.Generic.List<string>(read()).ToArray();
                            if (failure == null && Support.ProtectionShouldBeActive(Support.LoadConfig()))
                            {
                                if (isBlockList)
                                {
                                    Support.EnforceProtection();
                                }
                                else
                                {
                                    Support.ReapplyProtection();
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            if (failure == null)
                            {
                                failure = ex;
                            }
                        }
                        if (failure != null && !(failure is InvalidOperationException))
                        {
                            TryWriteLogs(logPrefix + " action failed (" + failure.GetType().Name + ")",
                                "Domain list action failed: " + failure.GetType().Name + ": " + failure.Message);
                        }

                        dialog.BeginInvoke(new Action(delegate
                        {
                            setBusy(false);
                            if (fresh != null)
                            {
                                snapshot = fresh;
                                renderList();
                            }
                            if (failure == null)
                            {
                                showFeedback(message);
                                if (onSuccess != null)
                                {
                                    onSuccess();
                                }
                            }
                            else if (failure is InvalidOperationException)
                            {
                                // UI-002: Diese Ausnahmen kommen aus Purestate und
                                // tragen Texte fuer den Nutzer ("Das ist keine
                                // gueltige Domain.") - sie zu verstecken hiesse,
                                // der Nutzer wuesste nicht, WARUM.
                                showFeedback(failure.Message);
                            }
                            else
                            {
                                showFeedback("Das hat nicht geklappt. Bitte versuche es erneut; " +
                                    "unter \"Mehr\" findest du die Protokolle mit den technischen Details.");
                            }
                            RefreshStatus();
                        }));
                    });
                };

                searchBox.TextChanged += delegate { renderList(); };
                addButton.Click += delegate
                {
                    string entered = addBox.Text.Trim();
                    runListChange(delegate
                    {
                        bool added = add(entered);
                        if (added)
                        {
                            Support.WriteSecurityLog(logPrefix + " added.");
                        }
                        return added
                            ? entered + " wurde hinzugefügt."
                            : "Diese Webseite ist bereits in der Liste.";
                    }, delegate { addBox.Text = string.Empty; });
                };

                removeButton.Click += delegate
                {
                    if (listBox.SelectedItem == null)
                    {
                        showFeedback("Bitte zuerst eine Webseite in der Liste auswählen.");
                        return;
                    }

                    string selected = listBox.SelectedItem.ToString();
                    if (!Ui.Confirm(dialog, theme, "Eintrag entfernen", "Soll " + selected + " wirklich aus der Liste entfernt werden?", "Entfernen", "Behalten"))
                    {
                        return;
                    }

                    // Entfernen laeuft ueber den geschuetzten Weg (RC-001: Frist
                    // ausserhalb des Korrekturfensters).
                    runListChange(delegate
                    {
                        string removeNotice = remove(selected);
                        Support.WriteSecurityLog(logPrefix + (removeNotice.Length == 0 ? " removed." : " removal requested."));
                        return removeNotice.Length == 0
                            ? selected + " wurde entfernt."
                            : removeNotice;
                    }, null);
                };

                cleanButton.Click += delegate
                {
                    runListChange(delegate
                    {
                        int count = clean();
                        Support.WriteSecurityLog(logPrefix + " list cleaned. Domains: " + count);
                        return "Die Liste wurde aufgeräumt. Einträge: " + count;
                    }, null);
                };

                viewButton.Click += delegate
                {
                    ShowTextDialog(title + " (nur Ansicht)",
                        "Nur zum Lesen und Kopieren. Hinzufügen und Entfernen geht über die Verwaltung - dort gelten die Fristen." +
                        Environment.NewLine + Environment.NewLine + string.Join(Environment.NewLine, snapshot), false);
                };

                renderList();
                dialog.Shown += delegate { searchBox.Focus(); };
                dialog.ShowDialog(this);
            }
        }

        private void ImportBlockList()
        {
            if (!ConfirmPassword("Sperrliste aus Datei übernehmen"))
            {
                return;
            }

            string sourcePath;
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Sperrliste aus Datei übernehmen";
                dialog.Filter = "Textdateien|*.txt;*.list;*.csv|Alle Dateien|*.*";
                if (dialog.ShowDialog() != DialogResult.OK)
                {
                    return;
                }
                sourcePath = dialog.FileName;
            }

            // DESK-13: Netto-Zaehlung, gemeinsamer Normalisierer und Obergrenze
            // fuer die ganze Liste (Support.ImportCustomDomains). DESK-09: im
            // Hintergrund, Reihenfolge Import -> Durchsetzen wie vorher.
            CustomDomainImportResult result = null;
            RunAction("Sperrliste übernehmen", delegate
            {
                result = Support.ImportCustomDomains(sourcePath, Support.CustomDomainsPath(),
                    Support.CustomDomainsAddedPath(), Support.CustomDomainRemovalsPath(), Support.TrustedUtcNow(), MaxImportedDomains);
                if (Support.ProtectionShouldBeActive(Support.LoadConfig()))
                {
                    Support.EnforceProtection();
                }
                Support.WriteSecurityLog("Block list imported. Added: " + result.Added + ", duplicates: " + result.Duplicates +
                    ", invalid: " + result.Invalid + ", truncated: " + (result.Truncated ? "yes" : "no"));
            }, delegate (bool success)
            {
                if (!success)
                {
                    return;
                }

                // UIX-002: alle Zahlen nennen - und zwar die echten. Vorher
                // meldete der Import Eingabezeilen als "übernommen".
                string meldung = result.Added + (result.Added == 1 ? " Webseite wurde" : " Webseiten wurden") + " neu übernommen.";
                if (result.Duplicates > 0)
                {
                    meldung += " " + result.Duplicates + " standen schon in der Liste oder mehrfach in der Datei.";
                }
                if (result.Invalid > 0)
                {
                    meldung += " " + result.Invalid + " Zeilen waren keine gültigen Adressen und wurden übersprungen.";
                }
                if (result.Truncated)
                {
                    meldung += " Die Liste hat die Obergrenze von " + MaxImportedDomains +
                        " Einträgen für Importe erreicht; der Rest der Datei wurde nicht übernommen.";
                }
                ShowSaveFeedback(result.Added + " neue Webseiten übernommen.");
                Ui.Inform(this, theme, "Sperrliste übernommen", meldung);
            });
        }

        private void TestDomain()
        {
            string domain;
            if (!PromptText("Webseite testen", "Adresse der Webseite eingeben (zum Beispiel beispiel.de):", out domain))
            {
                return;
            }

            ShowReport("Webseiten-Test", delegate { return Support.BuildDomainReport(domain); });
        }

        // UIX-002: Der Import hatte KEINE Obergrenze, und was der Filter
        // verwarf, erfuhr niemand. Eine oeffentliche Sperrliste hat leicht
        // 100.000 Eintraege; sie landeten vollstaendig in custom-domains.txt und
        // damit in der hosts-Datei und in der Musterableitung. DESK-13: Die
        // Grenze gilt fuer den Gesamtbestand nach dem Import, nicht je Aufruf.
        internal const int MaxImportedDomains = 20000;

        private void ExportBackup()
        {
            if (!ConfirmPassword("Backup erstellen"))
            {
                return;
            }

            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Title = "Backup speichern";
                dialog.Filter = "Purestate Backup|*.pbbackup.txt|Textdatei|*.txt|Alle Dateien|*.*";
                dialog.FileName = "Purestate-Backup.pbbackup.txt";
                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }

                try
                {
                    Support.ExportBackup(dialog.FileName);
                    Support.WriteSecurityLog("Backup exported.");
                    ShowSaveFeedback("Das Backup wurde erstellt.");
                }
                catch (Exception ex)
                {
                    ShowErrorDialog("Backup erstellen", ex);
                }
            }
        }

        private void ImportBackup()
        {
            if (!ConfirmPassword("Backup wiederherstellen"))
            {
                return;
            }

            string backupPath;
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Backup wiederherstellen";
                dialog.Filter = "Purestate Backup|*.pbbackup.txt;*.txt|Alle Dateien|*.*";
                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }
                backupPath = dialog.FileName;
            }

            if (!Ui.Confirm(this, theme, "Backup wiederherstellen",
                "Das Backup ersetzt die aktuellen Einstellungen und Webseitenlisten." + Environment.NewLine +
                "Soll das Backup jetzt wiederhergestellt werden?", "Wiederherstellen", "Abbrechen"))
            {
                return;
            }

            // DESK-09: Wiederherstellen und Durchsetzen im Hintergrund, in der
            // bisherigen Reihenfolge.
            int domains = 0;
            int allowCount = 0;
            RunAction("Backup wiederherstellen", delegate
            {
                domains = Support.ImportBackup(backupPath);
                if (Support.ProtectionShouldBeActive(Support.LoadConfig()))
                {
                    Support.EnforceProtection();
                }
                else
                {
                    Support.ClearProtection();
                }
                allowCount = Support.CountAllowDomains();
                Support.WriteSecurityLog("Backup restored. Domains: " + domains + ", Allowlist: " + allowCount);
            }, delegate (bool success)
            {
                if (success)
                {
                    ShowSaveFeedback("Das Backup wurde wiederhergestellt (" + domains + " gesperrte, " + allowCount + " erlaubte Webseiten).");
                }
            }, delegate (Exception failure)
            {
                // Eine abschwaechende Sicherung lehnt das Gate ab - das ist
                // eine Meldung, kein technischer Fehler.
                if (failure is InvalidOperationException)
                {
                    Ui.Inform(this, theme, "Backup nicht wiederhergestellt", failure.Message + WeakeningReleaseHint(failure.Message));
                    return;
                }
                ShowErrorDialog("Backup wiederherstellen", failure);
            });
        }
    }
}
