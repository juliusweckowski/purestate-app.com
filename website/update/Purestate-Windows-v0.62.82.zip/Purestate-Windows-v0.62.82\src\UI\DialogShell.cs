using System;
using System.Drawing;
using System.Windows.Forms;

namespace Purestate.App
{
    // Shared scaffold for every settings dialog: title + one-sentence intro +
    // scrollable content column + fixed action bar (Speichern/Abbrechen).
    // Tracks unsaved changes and asks before discarding them. Height adapts to
    // content but never exceeds 85% of the working area, so no dialog can grow
    // past the screen at 150/200% scaling.
    internal sealed class DialogShell : Form
    {
        private readonly UiTheme theme;
        private readonly Panel scrollHost;
        private readonly TableLayoutPanel content;
        private readonly FlowLayoutPanel actionBar;
        private readonly Label kickerLabel;
        public readonly Button SaveButton;
        public readonly Button CloseButtonControl;
        private bool dirty;
        private bool suspendDirty = true;
        private bool saved;

        public DialogShell(UiTheme theme, string title, string intro, string accessibleDescription, bool withSave)
        {
            this.theme = theme;
            Text = "Purestate - " + title;
            Ui.PrepareForm(this, title, accessibleDescription);
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.Sizable;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            BackColor = theme.WindowBackground;
            MinimumSize = new Size(600, 360);
            HandleCreated += delegate { Ui.ApplyDarkTitleBar(Handle, theme.IsDark); };

            scrollHost = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = theme.WindowBackground };
            Ui.ApplyScrollbarTheme(scrollHost, theme.IsDark);

            // DESK-02: nicht angedockt. Angedockt folgte die Breite dem Host,
            // die 672-px-Karten liefen bei schmalem Fenster rechts hinaus, und
            // der Host bot keinen horizontalen Scrollbalken an. So misst er
            // den Inhalt und scrollt, statt still abzuschneiden.
            content = new TableLayoutPanel
            {
                Location = Point.Empty,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 1,
                Padding = new Padding(Ui.GapSection, Ui.GapGroup, Ui.GapSection, Ui.GapSection),
                BackColor = theme.WindowBackground
            };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            scrollHost.Controls.Add(content);

            actionBar = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                FlowDirection = FlowDirection.RightToLeft,
                AutoSize = true,
                Padding = new Padding(Ui.GapGroup, Ui.GapSmall, Ui.GapGroup, Ui.GapSmall),
                BackColor = theme.SidebarBackground
            };

            CloseButtonControl = Ui.SecondaryButton(theme, withSave ? "Abbrechen" : "Schließen",
                withSave ? "Schließt den Dialog und verwirft nicht gespeicherte Änderungen." : "Schließt den Dialog.");
            CloseButtonControl.DialogResult = DialogResult.Cancel;
            CloseButtonControl.Margin = new Padding(Ui.GapSmall, 0, 0, 0);
            actionBar.Controls.Add(CloseButtonControl);
            CancelButton = CloseButtonControl;

            if (withSave)
            {
                SaveButton = Ui.PrimaryButton(theme, "Änderungen speichern", "Prüft die Eingaben, fragt das Passwort ab und speichert.");
                SaveButton.Margin = new Padding(Ui.GapSmall, 0, 0, 0);
                actionBar.Controls.Add(SaveButton);
                AcceptButton = SaveButton;
            }

            Panel separator = new Panel { Dock = DockStyle.Bottom, Height = 1, BackColor = theme.Divider };

            // DESK-08: Ablehnung beim Speichern steht hier, direkt ueber den
            // Knoepfen - unabhaengig davon, wohin der Inhalt gescrollt ist.
            saveErrorLabel = new Label
            {
                Dock = DockStyle.Bottom,
                AutoSize = false,
                Visible = false,
                Font = Ui.FontHint,
                ForeColor = theme.DangerRed,
                BackColor = theme.SidebarBackground,
                Padding = new Padding(Ui.GapGroup, Ui.GapSmall, Ui.GapGroup, 0)
            };
            Ui.SetAccessibility(saveErrorLabel, "Speichern nicht möglich", "Erklärt, warum die Änderungen noch nicht gespeichert wurden.", AccessibleRole.StaticText);
            Resize += delegate { FitSaveError(); };

            // Andockreihenfolge: zuletzt hinzugefuegt = ganz unten.
            Controls.Add(scrollHost);
            Controls.Add(separator);
            Controls.Add(saveErrorLabel);
            Controls.Add(actionBar);

            kickerLabel = Ui.MonoLabel(theme, "Purestate");
            content.Controls.Add(kickerLabel);

            Label titleLabel = new Label
            {
                Text = title,
                Font = Ui.FontPageTitle,
                ForeColor = theme.TextPrimary,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 4)
            };
            Ui.SetAccessibility(titleLabel, title, title, AccessibleRole.StaticText);
            content.Controls.Add(titleLabel);

            if (!string.IsNullOrEmpty(intro))
            {
                content.Controls.Add(Ui.WrapLabel(theme, intro, InnerWidth, true));
            }

            FormClosing += OnClosingCheckDirty;
        }

        public int InnerWidth
        {
            get { return 640; }
        }

        // Mono-Label ueber dem Titel (Website-Look). Standard "Purestate",
        // Bereichsdialoge setzen "Schutzbereich".
        public string Kicker
        {
            set
            {
                kickerLabel.Text = (value ?? string.Empty).ToUpper(new System.Globalization.CultureInfo("de-DE"));
                kickerLabel.AccessibleName = value;
                kickerLabel.AccessibleDescription = value;
            }
        }

        public void MarkSaved()
        {
            saved = true;
        }

        private readonly Label saveErrorLabel;
        private bool busy;

        // DESK-08: Speichern im Hintergrund, Dialog bleibt bis zum Ergebnis
        // offen. Vorher schloss er vor dem Ergebnis; lehnte das Gate ab, war
        // der ganze Entwurf weg. Die autoritative Pruefung bleibt in work
        // (Support) - hier wird nur gewartet und angezeigt.
        public void SaveInBackground(Action work, Action onSuccess, Func<Exception, string> describeFailure)
        {
            if (busy || SaveButton == null)
            {
                return;
            }
            SetBusy(true);
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                Exception failure = null;
                try
                {
                    work();
                }
                catch (Exception ex)
                {
                    failure = ex;
                }

                try
                {
                    BeginInvoke(new Action(delegate
                    {
                        SetBusy(false);
                        if (failure == null)
                        {
                            MarkSaved();
                            DialogResult = DialogResult.OK;
                            Close();
                            if (onSuccess != null)
                            {
                                onSuccess();
                            }
                            return;
                        }
                        ShowSaveError(describeFailure(failure));
                        SaveButton.Focus();
                    }));
                }
                catch (InvalidOperationException)
                {
                    // Fenster ohne Handle - kann nur nach Dispose passieren.
                }
            });
        }

        private void SetBusy(bool value)
        {
            busy = value;
            SaveButton.Enabled = !value;
            CloseButtonControl.Enabled = !value;
            scrollHost.Enabled = !value;
            UseWaitCursor = value;
            if (value)
            {
                saveErrorLabel.Visible = false;
            }
        }

        public void ShowSaveError(string message)
        {
            Ui.SetDynamicText(saveErrorLabel, message, "Speichern nicht möglich");
            saveErrorLabel.Visible = true;
            FitSaveError();
        }

        private void FitSaveError()
        {
            if (!saveErrorLabel.Visible)
            {
                return;
            }
            int width = Math.Max(80, ClientSize.Width - saveErrorLabel.Padding.Horizontal);
            saveErrorLabel.Height = TextRenderer.MeasureText(saveErrorLabel.Text, saveErrorLabel.Font,
                new Size(width, 0), TextFormatFlags.WordBreak).Height + saveErrorLabel.Padding.Vertical + 4;
        }

        private void OnClosingCheckDirty(object sender, FormClosingEventArgs e)
        {
            if (busy)
            {
                e.Cancel = true;
                return;
            }
            if (saved || !dirty || SaveButton == null)
            {
                return;
            }
            if (!Ui.Confirm(this, theme, "Ungespeicherte Änderungen",
                "Es gibt nicht gespeicherte Änderungen." + Environment.NewLine +
                "Sollen die Änderungen verworfen werden?", "Verwerfen", "Zurück"))
            {
                e.Cancel = true;
            }
        }

        private TableLayoutPanel currentCard;

        // Jede Section ist eine Karte: gruppiert zusammengehoerige Optionen
        // sichtbar statt flacher Liste (wie die Karten der Hauptseiten).
        // Controls vor der ersten Section (Master-Schalter, Intro) bleiben
        // direkt im Inhalt.
        public void AddSection(string title)
        {
            RoundCard card = new RoundCard
            {
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 1,
                Padding = new Padding(Ui.GapGroup),
                Margin = new Padding(0, Ui.GapGroup, 0, 0),
                // Innenbreite bleibt exakt InnerWidth, damit 640er-Inhalte
                // (Listen, Plattform-Zeilen) nicht am Kartenrand clippen.
                MinimumSize = new Size(InnerWidth + 2 * Ui.GapGroup, 0),
                MaximumSize = new Size(InnerWidth + 2 * Ui.GapGroup, 0)
            };
            Ui.StyleCard(theme, card);
            card.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            Label label = new Label
            {
                Text = title,
                Font = Ui.FontSection,
                ForeColor = theme.TextPrimary,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, Ui.GapSmall)
            };
            Ui.SetAccessibility(label, title, "Abschnitt " + title + ".", AccessibleRole.StaticText);
            card.Controls.Add(label);
            content.Controls.Add(card);
            currentCard = card;
        }

        private TableLayoutPanel Target
        {
            get { return currentCard != null ? currentCard : content; }
        }

        public void Add(Control control)
        {
            StyleInputs(control);
            WatchDirty(control);
            Target.Controls.Add(control);
        }

        private void StyleInputs(Control control)
        {
            TextBox text = control as TextBox;
            if (text != null) { Ui.StyleInput(theme, text); }
            ComboBox combo = control as ComboBox;
            if (combo != null) { Ui.StyleInput(theme, combo); }
            ListBox list = control as ListBox;
            if (list != null) { Ui.StyleInput(theme, list); }
            ListView listView = control as ListView;
            if (listView != null) { Ui.StyleListView(theme, listView); }
            foreach (Control child in control.Controls)
            {
                StyleInputs(child);
            }
        }

        public Label AddHint(string text)
        {
            Label hint = Ui.WrapLabel(theme, text, InnerWidth, true);
            Target.Controls.Add(hint);
            return hint;
        }

        // Inline validation line: hidden until an error is shown; focusing it
        // makes Narrator announce the message.
        public Label AddErrorLine()
        {
            Label error = new Label
            {
                Text = string.Empty,
                AutoSize = true,
                MaximumSize = new Size(InnerWidth, 0),
                Font = Ui.FontHint,
                ForeColor = theme.DangerRed,
                Visible = false,
                Margin = new Padding(0, 0, 0, Ui.GapSmall)
            };
            Ui.SetAccessibility(error, "Eingabefehler", "Beschreibt, welche Eingabe korrigiert werden muss.", AccessibleRole.StaticText);
            Target.Controls.Add(error);
            return error;
        }

        // DESK-05: Fokus springt ins Feld - der Fehler muss dort vorgelesen
        // werden, nicht nur am (nicht fokussierten) Fehlerlabel.
        private readonly System.Collections.Generic.Dictionary<Label, System.Collections.Generic.KeyValuePair<Control, string>> boundErrors =
            new System.Collections.Generic.Dictionary<Label, System.Collections.Generic.KeyValuePair<Control, string>>();

        public void ShowError(Label errorLine, string message, Control focusTarget)
        {
            RestoreErrorTarget(errorLine);
            Ui.SetDynamicText(errorLine, message, "Eingabefehler");
            errorLine.Visible = true;
            if (focusTarget != null)
            {
                string original = focusTarget.AccessibleDescription;
                boundErrors[errorLine] = new System.Collections.Generic.KeyValuePair<Control, string>(focusTarget, original);
                focusTarget.AccessibleDescription = "Fehler: " + message + (string.IsNullOrEmpty(original) ? string.Empty : " " + original);
            }
            if (focusTarget != null && focusTarget.CanFocus)
            {
                TextBox box = focusTarget as TextBox;
                if (box != null)
                {
                    box.SelectAll();
                }
                focusTarget.Focus();
            }
        }

        public void ClearError(Label errorLine)
        {
            errorLine.Text = string.Empty;
            errorLine.Visible = false;
            RestoreErrorTarget(errorLine);
        }

        private void RestoreErrorTarget(Label errorLine)
        {
            System.Collections.Generic.KeyValuePair<Control, string> bound;
            if (boundErrors.TryGetValue(errorLine, out bound))
            {
                bound.Key.AccessibleDescription = bound.Value;
                boundErrors.Remove(errorLine);
            }
        }

        // A horizontal row (e.g. checkbox + numeric + unit label).
        public FlowLayoutPanel Row(params Control[] controls)
        {
            FlowLayoutPanel row = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                WrapContents = true,
                MaximumSize = new Size(InnerWidth, 0),
                Margin = new Padding(0, 0, 0, 4),
                BackColor = Color.Transparent
            };
            foreach (Control control in controls)
            {
                if (control is Label)
                {
                    control.Margin = new Padding(4, 8, 4, 0);
                }
                row.Controls.Add(control);
            }
            return row;
        }

        private void WatchDirty(Control control)
        {
            CheckBox check = control as CheckBox;
            if (check != null) { check.CheckedChanged += SetDirty; }
            RadioButton radio = control as RadioButton;
            if (radio != null) { radio.CheckedChanged += SetDirty; }
            TextBox text = control as TextBox;
            if (text != null) { text.TextChanged += SetDirty; }
            ComboBox combo = control as ComboBox;
            if (combo != null) { combo.SelectedIndexChanged += SetDirty; }
            // APP-002: StyleInputs kennt beide Listen, WatchDirty kannte sie
            // nicht - abgehakte Spiele in der Videospielauswahl gingen deshalb
            // ohne die versprochene Nachfrage verloren.
            ListView listView = control as ListView;
            if (listView != null) { listView.ItemChecked += SetDirty; listView.SelectedIndexChanged += SetDirty; }
            ListBox list = control as ListBox;
            if (list != null) { list.SelectedIndexChanged += SetDirty; }
            foreach (Control child in control.Controls)
            {
                WatchDirty(child);
            }
        }

        private void SetDirty(object sender, EventArgs e)
        {
            if (!suspendDirty)
            {
                dirty = true;
            }
        }

        // Call after all controls are added: sizes the dialog to its content,
        // capped to 85% of the working area, and arms dirty tracking.
        public void FinishLayout()
        {
            content.PerformLayout();
            Size preferred = content.PreferredSize;
            int desiredHeight = preferred.Height + actionBar.PreferredSize.Height + 60;
            Rectangle work = Screen.FromPoint(Cursor.Position).WorkingArea;
            // DESK-02: Breite und Mindestbreite aus dem breitesten Inhalt plus
            // Scrollbalken - vorher waren 600 px erlaubt, obwohl die Karten
            // 672 px brauchen. Ist der Bildschirm schmaler, scrollt der Host.
            int width = Math.Min(preferred.Width + SystemInformation.VerticalScrollBarWidth, work.Width);
            int height = Math.Min(desiredHeight, (int)(work.Height * 0.85));
            ClientSize = new Size(width, height);
            MinimumSize = new Size(Width, Math.Min(360, Height));
            Shown += delegate { suspendDirty = false; };
        }
    }
}
