param(
    [string]$InstallDir = "",
    [switch]$Quiet,
    [switch]$SelfTest
)

$ErrorActionPreference = "Stop"

if ($SelfTest) {
    Write-Output "Self-test OK."
    exit 0
}

if ([string]::IsNullOrWhiteSpace($InstallDir)) {
    exit 2
}

try {
    $normalizedInstallDir = [System.IO.Path]::GetFullPath($InstallDir)
}
catch {
    exit 3
}

try {
    $helpers = Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction Stop
    foreach ($helper in $helpers) {
        $commandLine = [string]$helper.CommandLine
        if ($helper.ProcessId -ne $PID -and
            $commandLine.IndexOf("Finish-Installer-Update.ps1", [System.StringComparison]::OrdinalIgnoreCase) -ge 0 -and
            $commandLine.IndexOf($normalizedInstallDir, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
            Stop-Process -Id $helper.ProcessId -Force -ErrorAction SilentlyContinue
        }
    }
}
catch {
    if (-not $Quiet) {
        Write-Output "Laufende Abschlussprozesse konnten nicht vollstaendig geprueft werden."
    }
}

Start-Sleep -Milliseconds 150

$tokenFile = Join-Path $normalizedInstallDir "InstallerUpdate.current"
try {
    if (Test-Path -LiteralPath $tokenFile -PathType Leaf) {
        Remove-Item -LiteralPath $tokenFile -Force
    }
}
catch {
}

try {
    Get-ChildItem -LiteralPath $normalizedInstallDir -Filter "Installieren.pending*.exe" -File -ErrorAction SilentlyContinue |
        ForEach-Object {
            try {
                Remove-Item -LiteralPath $_.FullName -Force
            }
            catch {
            }
        }
}
catch {
}

if (-not $Quiet) {
    Write-Output "Purestate Installer-Abschlussprozesse wurden bereinigt."
}

exit 0
