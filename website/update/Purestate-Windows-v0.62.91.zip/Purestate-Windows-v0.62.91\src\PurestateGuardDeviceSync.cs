using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Pipes;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace Purestate
{
    // Stand eines Geraets im Abgleich: der Inhalt eines Paeckchens (Spec
    // 2026-10-30, Abschnitt 6). LastSeenUtc steht nicht im Text, sondern wird
    // beim Empfang gesetzt (MergeDeviceSyncPeer).
    internal sealed class DeviceSyncSnapshot
    {
        public string DeviceId = string.Empty;
        public string Name = string.Empty;
        public string Day = string.Empty;
        public string Month = string.Empty;
        public long Seq;
        public DateTime LastSeenUtc;
        public Dictionary<string, int> Used = new Dictionary<string, int>(StringComparer.Ordinal);
        public Dictionary<string, int> Limits = new Dictionary<string, int>(StringComparer.Ordinal);
        public List<string> AreasOff = new List<string>();
    }

    // Abgleich zwischen Geraeten (Spec 2026-10-30, Abschnitte 4, 5, 6 und 8).
    // Kommt nur in PurestateGuard.exe und wird eigenstaendig uebersetzt wie die
    // anderen Waechterdateien (keine Support-Verweise).
    //
    // Der erste Teil ist der Rechenkern: nur rechnen und Text bauen, keine
    // Dateien, keine Pipe, keine Uhr. Der zweite Teil (ab "Zustand, Export,
    // Import, Pipe") hat Dateien und die Pipe; die Zeit kommt auch dort immer
    // als Parameter. Das Netz gehoert dem Tray, der Waechter setzt vollstaendig
    // offline durch; was er von dort bekommt, ist ohne den Kopplungscode
    // wertlos.
    internal sealed partial class GuardService
    {
        internal const int DeviceSyncPayloadBytes = 2048;
        internal const int DeviceSyncLimitGraceDays = 7;

        // Lesedeckel je Tabelle, nur zum Schutz des Parsers. Gebaut wird nach
        // Platz (BuildDeviceSyncPayload), 64 lange Plattformnamen passen ohnehin
        // nicht in 2048 Bytes.
        private const int DeviceSyncMaxEntries = 64;

        // Umschlag: 0x01 | Geraete-ID (16 ASCII) | Nummer (8, big endian) | IV (16)
        // | Chiffretext | MAC (32), als Base64.
        private const int DeviceSyncIdBytes = 16;
        private const int DeviceSyncIvBytes = 16;
        private const int DeviceSyncMacBytes = 32;
        private const int DeviceSyncHeaderBytes = 1 + DeviceSyncIdBytes + 8 + DeviceSyncIvBytes;
        // CBC mit PKCS7 haengt an einen vollen Block einen ganzen an: 2048 -> 2064.
        private const int DeviceSyncCipherBytes = DeviceSyncPayloadBytes + 16;
        private const int DeviceSyncEnvelopeBytes = DeviceSyncHeaderBytes + DeviceSyncCipherBytes + DeviceSyncMacBytes;
        private const int DeviceSyncEnvelopeChars = (DeviceSyncEnvelopeBytes + 2) / 3 * 4;

        // \z statt $: ein angehaengter Zeilenumbruch darf nicht durchgehen.
        private const string DeviceSyncIdPattern = @"^[0-9a-fA-F]{16}\z";
        private const string DeviceSyncNamePattern = @"^[A-Za-z0-9._-]{1,32}\z";
        private const string DeviceSyncDayPattern = @"^[0-9]{4}-[0-9]{2}-[0-9]{2}\z";
        private const string DeviceSyncMonthPattern = @"^[0-9]{4}-[0-9]{2}\z";
        private const string DeviceSyncKeyPattern = @"^(social:[a-z0-9-]{1,32}|shopping|gambling|games|orders|spend)\z";
        private const string DeviceSyncPlatformPattern = @"^social:[a-z0-9-]{1,32}\z";

        // Die Bereichsschluessel stehen im Text vor den Plattformen: bei Platzmangel
        // faellt nur social:<plattform> weg, und auch ein Lesedeckel traefe nie einen
        // von ihnen.
        private static readonly string[] DeviceSyncAreaKeys =
            { "social:global", "shopping", "gambling", "games", "orders", "spend" };
        private static readonly string[] DeviceSyncOffNames =
            { "social", "shopping", "gambling", "games" };

        private static bool DeviceSyncMatches(string value, string pattern)
        {
            return value != null && Regex.IsMatch(value, pattern, RegexOptions.CultureInvariant);
        }

        // ---------------------------------------------------------------- Kanonisat

        // Zeichengleich mit Grants.SyncCanonical auf dem Server (Test-Vektor in
        // CrossLanguageFixtureTests). Der Blob geht als Hash ein, damit die
        // Signatur nur fuer genau dieses Paeckchen gilt.
        internal static string DeviceSyncCanonical(string pubKey, long seq, string blob)
        {
            byte[] hash;
            using (SHA256 sha = SHA256.Create())
            {
                hash = sha.ComputeHash(Encoding.UTF8.GetBytes(blob ?? string.Empty));
            }

            StringBuilder hex = new StringBuilder(hash.Length * 2);
            foreach (byte b in hash)
            {
                hex.Append(b.ToString("x2", CultureInfo.InvariantCulture));
            }

            return "op=sync\npubkey=" + pubKey + "\nseq=" + seq.ToString(CultureInfo.InvariantCulture) +
                "\nblob-sha256=" + hex;
        }

        // ---------------------------------------------------------------- Paeckchen

        // Gibt null zurueck, wenn eine Pflichtangabe nicht stimmt; der Aufrufer
        // sendet dann nichts.
        internal static string BuildDeviceSyncPayload(DeviceSyncSnapshot s)
        {
            if (s == null ||
                !DeviceSyncMatches(s.DeviceId, DeviceSyncIdPattern) ||
                !DeviceSyncMatches(s.Day, DeviceSyncDayPattern) ||
                !DeviceSyncMatches(s.Month, DeviceSyncMonthPattern) ||
                s.Seq < 0)
            {
                return null;
            }

            // Die Groesse steht fest (Spec 6: Groesse und Takt verraten dem Server
            // nichts), also gibt der Inhalt nach. Bei Platzmangel faellt
            // social:<plattform> weg, alphabetisch zuletzt zuerst. Die Bereichsschluessel
            // bleiben immer; ohne sie bewirkte der Abgleich nichts.
            List<string> platforms = new List<string>();
            CollectDeviceSyncPlatforms(platforms, s.Used);
            CollectDeviceSyncPlatforms(platforms, s.Limits);
            platforms.Sort(StringComparer.Ordinal);

            while (true)
            {
                string text = ComposeDeviceSyncPayload(s, platforms);
                int bytes = Encoding.UTF8.GetByteCount(text);
                if (bytes <= DeviceSyncPayloadBytes)
                {
                    return text + new string(' ', DeviceSyncPayloadBytes - bytes);
                }

                if (platforms.Count == 0)
                {
                    return null;
                }

                platforms.RemoveAt(platforms.Count - 1);
            }
        }

        private static void CollectDeviceSyncPlatforms(List<string> platforms, Dictionary<string, int> map)
        {
            if (map == null)
            {
                return;
            }

            foreach (string key in map.Keys)
            {
                if (key != "social:global" &&
                    DeviceSyncMatches(key, DeviceSyncPlatformPattern) &&
                    !platforms.Contains(key))
                {
                    platforms.Add(key);
                }
            }
        }

        private static string ComposeDeviceSyncPayload(DeviceSyncSnapshot s, List<string> platforms)
        {
            StringBuilder text = new StringBuilder();
            text.Append("v=1\n");
            text.Append("device=").Append(s.DeviceId).Append('\n');
            text.Append("name=").Append(DeviceSyncSafeName(s.Name)).Append('\n');
            text.Append("seq=").Append(s.Seq.ToString(CultureInfo.InvariantCulture)).Append('\n');
            text.Append("day=").Append(s.Day).Append('\n');
            text.Append("month=").Append(s.Month).Append('\n');
            AppendDeviceSyncTable(text, "used.", s.Used, platforms);
            AppendDeviceSyncTable(text, "limit.", s.Limits, platforms);

            List<string> off = new List<string>();
            foreach (string area in DeviceSyncOffNames)
            {
                if (s.AreasOff != null && s.AreasOff.Contains(area))
                {
                    off.Add(area);
                }
            }

            text.Append("off=").Append(string.Join(",", off)).Append('\n');
            return text.ToString();
        }

        private static void AppendDeviceSyncTable(StringBuilder text, string prefix, Dictionary<string, int> map, List<string> platforms)
        {
            if (map == null)
            {
                return;
            }

            foreach (string key in DeviceSyncAreaKeys)
            {
                AppendDeviceSyncEntry(text, prefix, key, map);
            }

            foreach (string key in platforms)
            {
                AppendDeviceSyncEntry(text, prefix, key, map);
            }
        }

        private static void AppendDeviceSyncEntry(StringBuilder text, string prefix, string key, Dictionary<string, int> map)
        {
            int value;
            if (map.TryGetValue(key, out value) && value >= 0)
            {
                text.Append(prefix).Append(key).Append('=')
                    .Append(value.ToString(CultureInfo.InvariantCulture)).Append('\n');
            }
        }

        // MachineName ist meist harmlos, darf aber Zeichen tragen, die das Muster
        // nicht kennt. Ein Name, der das Paeckchen unlesbar machte, legte den
        // Abgleich dieses Geraets still; er ist nur fuer die Anzeige da.
        private static string DeviceSyncSafeName(string name)
        {
            StringBuilder safe = new StringBuilder();
            foreach (char c in name ?? string.Empty)
            {
                if (safe.Length == 32)
                {
                    break;
                }

                bool allowed = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
                    c == '.' || c == '_' || c == '-';
                safe.Append(allowed ? c : '-');
            }

            return safe.Length == 0 ? "device" : safe.ToString();
        }

        // Prueft Laenge und Muster, wirft nie. Zeilen, die nicht zum Format
        // gehoeren, fallen weg; eine kaputte Pflichtzeile macht das ganze
        // Paeckchen ungueltig.
        internal static bool TryParseDeviceSyncPayload(string text, out DeviceSyncSnapshot s)
        {
            s = null;
            if (text == null || text.Length > DeviceSyncPayloadBytes)
            {
                return false;
            }

            DeviceSyncSnapshot parsed = new DeviceSyncSnapshot();
            bool hasVersion = false;
            bool hasDevice = false;
            bool hasName = false;
            bool hasSeq = false;
            bool hasDay = false;
            bool hasMonth = false;
            foreach (string line in text.Split('\n'))
            {
                int equals = line.IndexOf('=');
                if (equals <= 0)
                {
                    continue;
                }

                string key = line.Substring(0, equals);
                string value = line.Substring(equals + 1);
                if (key == "v")
                {
                    if (value != "1")
                    {
                        return false;
                    }

                    hasVersion = true;
                }
                else if (key == "device")
                {
                    if (!DeviceSyncMatches(value, DeviceSyncIdPattern))
                    {
                        return false;
                    }

                    parsed.DeviceId = value;
                    hasDevice = true;
                }
                else if (key == "name")
                {
                    if (!DeviceSyncMatches(value, DeviceSyncNamePattern))
                    {
                        return false;
                    }

                    parsed.Name = value;
                    hasName = true;
                }
                else if (key == "seq")
                {
                    // NumberStyles.None: kein Vorzeichen, keine Leerzeichen.
                    if (!long.TryParse(value, NumberStyles.None, CultureInfo.InvariantCulture, out parsed.Seq))
                    {
                        return false;
                    }

                    hasSeq = true;
                }
                else if (key == "day")
                {
                    if (!DeviceSyncMatches(value, DeviceSyncDayPattern))
                    {
                        return false;
                    }

                    parsed.Day = value;
                    hasDay = true;
                }
                else if (key == "month")
                {
                    if (!DeviceSyncMatches(value, DeviceSyncMonthPattern))
                    {
                        return false;
                    }

                    parsed.Month = value;
                    hasMonth = true;
                }
                else if (key == "off")
                {
                    foreach (string area in value.Split(','))
                    {
                        if (Array.IndexOf(DeviceSyncOffNames, area) >= 0 && !parsed.AreasOff.Contains(area))
                        {
                            parsed.AreasOff.Add(area);
                        }
                    }
                }
                else if (key.StartsWith("used.", StringComparison.Ordinal))
                {
                    AddDeviceSyncEntry(parsed.Used, key.Substring("used.".Length), value, false);
                }
                else if (key.StartsWith("limit.", StringComparison.Ordinal))
                {
                    AddDeviceSyncEntry(parsed.Limits, key.Substring("limit.".Length), value, true);
                }
            }

            if (!(hasVersion && hasDevice && hasName && hasSeq && hasDay && hasMonth))
            {
                return false;
            }

            s = parsed;
            return true;
        }

        // Ein Schluessel ausserhalb des Musters und eine Zahl, die keine
        // nichtnegative int ist, fallen weg. Bei Limits auch eine Zahl ausserhalb des
        // Bereichs ihres Schluessels (DeviceSyncLimitInRange); Zaehler bleiben, wie sie
        // sind: ein riesiger Zaehler verschaerft nur.
        private static void AddDeviceSyncEntry(Dictionary<string, int> map, string key, string value, bool limit)
        {
            int number;
            if (!DeviceSyncMatches(key, DeviceSyncKeyPattern) ||
                !int.TryParse(value, NumberStyles.None, CultureInfo.InvariantCulture, out number) ||
                (limit && !DeviceSyncLimitInRange(key, number)))
            {
                return;
            }

            if (!map.ContainsKey(key) && map.Count >= DeviceSyncMaxEntries)
            {
                return;
            }

            map[key] = number;
        }

        // Die Bereiche, die ein Geraet fuer sein eigenes Limit nie verlaesst: dieselben wie in
        // AddOwnDeviceSyncLimits, im Native Host (ReadForeignLimit und die Leser der Konfiguration) und bei den Spielen
        // (NormalizeVideoGamesDailyLimitMinutes, ParseRules). Ein Wert daneben kommt von keinem echten Geraet. Er verdeckte
        // sonst das gueltige Limit eines anderen (der Host verwirft das Minimum ausserhalb seines Bereichs und nimmt
        // gar keins), und ein Spiele-Limit ueber 35 791 394 liesse rules.DailyLimitMinutes * 60 ueberlaufen, so dass die
        // Spiele den ganzen Tag gesperrt blieben. Darum faellt er schon beim Lesen weg, und Summe, strengstes Limit,
        // Status und Limit-Datei sehen nur gueltige Werte.
        private static bool DeviceSyncLimitInRange(string key, int value)
        {
            switch (key)
            {
                case "shopping":
                case "gambling":
                    return value >= 5 && value <= 240;
                case "games":
                    return value >= 5 && value <= 600;
                case "orders":
                    return value >= 1 && value <= 99;
                case "spend":
                    return value >= 1 && value <= 99999;
                default:
                    // social:global und social:<plattform>
                    return value >= 5 && value <= 480;
            }
        }

        // ---------------------------------------------------------------- Verschluesselung

        // Der Code hat 100 Bit aus dem Zufallsgenerator; eine Dehnung wie bei einem
        // Passwort braeuchte es nicht. Zwei Schluessel, damit Verschluesselung und
        // MAC nie denselben benutzen. code ist die angezeigte Form mit Strichen,
        // Zeichen fuer Zeichen so, wie sie in device-sync.key steht.
        private static byte[] DeviceSyncDeriveKey(string code, string label)
        {
            using (HMACSHA256 hmac = new HMACSHA256(Encoding.UTF8.GetBytes(code)))
            {
                return hmac.ComputeHash(Encoding.UTF8.GetBytes(label));
            }
        }

        // Der Vergleich bricht nicht beim ersten Unterschied ab: aus der Laufzeit
        // soll sich nicht ablesen lassen, wie weit ein gefaelschter MAC stimmt.
        private static bool DeviceSyncFixedTimeEquals(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != b.Length)
            {
                return false;
            }

            int difference = 0;
            for (int i = 0; i < a.Length; i++)
            {
                difference |= a[i] ^ b[i];
            }

            return difference == 0;
        }

        // Verschluesseln, dann MAC (Encrypt-then-MAC). Gibt null zurueck, wenn die
        // Eingaben keinen Umschlag von genau 2852 Zeichen ergaeben: ein Umschlag
        // anderer Groesse verriete dem Server etwas ueber den Inhalt.
        internal static string SealDeviceSyncPayload(string code, string deviceId, long seq, string payload)
        {
            if (string.IsNullOrEmpty(code) || !DeviceSyncMatches(deviceId, DeviceSyncIdPattern) || seq < 0 || payload == null)
            {
                return null;
            }

            byte[] plain = Encoding.UTF8.GetBytes(payload);
            if (plain.Length != DeviceSyncPayloadBytes)
            {
                return null;
            }

            byte[] iv = new byte[DeviceSyncIvBytes];
            using (RNGCryptoServiceProvider random = new RNGCryptoServiceProvider())
            {
                random.GetBytes(iv);
            }

            byte[] body = new byte[DeviceSyncEnvelopeBytes];
            body[0] = 0x01;
            Encoding.ASCII.GetBytes(deviceId, 0, DeviceSyncIdBytes, body, 1);
            for (int i = 0; i < 8; i++)
            {
                body[1 + DeviceSyncIdBytes + i] = (byte)(seq >> (56 - 8 * i));
            }

            Array.Copy(iv, 0, body, 1 + DeviceSyncIdBytes + 8, DeviceSyncIvBytes);

            using (Aes aes = Aes.Create())
            {
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                aes.Key = DeviceSyncDeriveKey(code, "purestate-sync-enc-v1");
                aes.IV = iv;
                using (ICryptoTransform encryptor = aes.CreateEncryptor())
                {
                    byte[] cipher = encryptor.TransformFinalBlock(plain, 0, plain.Length);
                    Array.Copy(cipher, 0, body, DeviceSyncHeaderBytes, cipher.Length);
                }
            }

            int macStart = DeviceSyncEnvelopeBytes - DeviceSyncMacBytes;
            using (HMACSHA256 hmac = new HMACSHA256(DeviceSyncDeriveKey(code, "purestate-sync-mac-v1")))
            {
                Array.Copy(hmac.ComputeHash(body, 0, macStart), 0, body, macStart, DeviceSyncMacBytes);
            }

            return Convert.ToBase64String(body);
        }

        // Reihenfolge wie in der Spec (Abschnitt 5): erst Laenge und Form, dann der
        // MAC, und erst danach wird entschluesselt und gelesen. Bei jedem Fehler
        // false, nie eine Ausnahme.
        internal static bool TryOpenDeviceSyncPayload(string code, string envelope, out string deviceId, out long seq, out string payload)
        {
            deviceId = string.Empty;
            seq = 0;
            payload = string.Empty;
            if (string.IsNullOrEmpty(code) || envelope == null || envelope.Length != DeviceSyncEnvelopeChars)
            {
                return false;
            }

            try
            {
                byte[] body = Convert.FromBase64String(envelope);
                if (body.Length != DeviceSyncEnvelopeBytes || body[0] != 0x01)
                {
                    return false;
                }

                int macStart = DeviceSyncEnvelopeBytes - DeviceSyncMacBytes;
                byte[] expected;
                using (HMACSHA256 hmac = new HMACSHA256(DeviceSyncDeriveKey(code, "purestate-sync-mac-v1")))
                {
                    expected = hmac.ComputeHash(body, 0, macStart);
                }

                byte[] actual = new byte[DeviceSyncMacBytes];
                Array.Copy(body, macStart, actual, 0, DeviceSyncMacBytes);
                if (!DeviceSyncFixedTimeEquals(expected, actual))
                {
                    return false;
                }

                string id = Encoding.ASCII.GetString(body, 1, DeviceSyncIdBytes);
                long number = 0;
                for (int i = 0; i < 8; i++)
                {
                    number = (number << 8) | body[1 + DeviceSyncIdBytes + i];
                }

                if (!DeviceSyncMatches(id, DeviceSyncIdPattern) || number < 0)
                {
                    return false;
                }

                byte[] iv = new byte[DeviceSyncIvBytes];
                Array.Copy(body, 1 + DeviceSyncIdBytes + 8, iv, 0, DeviceSyncIvBytes);
                byte[] plain;
                using (Aes aes = Aes.Create())
                {
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;
                    aes.Key = DeviceSyncDeriveKey(code, "purestate-sync-enc-v1");
                    aes.IV = iv;
                    using (ICryptoTransform decryptor = aes.CreateDecryptor())
                    {
                        plain = decryptor.TransformFinalBlock(body, DeviceSyncHeaderBytes, DeviceSyncCipherBytes);
                    }
                }

                if (plain.Length != DeviceSyncPayloadBytes)
                {
                    return false;
                }

                deviceId = id;
                seq = number;
                payload = Encoding.UTF8.GetString(plain);
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
            catch (CryptographicException)
            {
                return false;
            }
        }

        // ---------------------------------------------------------------- Regeln

        // Nimmt den Stand eines anderen Geraets auf, wenn seine Nummer groesser ist
        // als die bekannte. Die eigene ID wird nie aufgenommen und eine unbekannte
        // eigene ID auch nicht: das eigene Paeckchen darf nie als fremdes zaehlen,
        // sonst stuende die eigene Zeit doppelt in der Summe. Die ID gilt in beiden
        // Schreibweisen als dieselbe.
        internal static bool MergeDeviceSyncPeer(List<DeviceSyncSnapshot> peers, DeviceSyncSnapshot incoming, string ownDeviceId, DateTime nowUtc)
        {
            if (peers == null || incoming == null ||
                string.IsNullOrEmpty(incoming.DeviceId) || string.IsNullOrEmpty(ownDeviceId) ||
                string.Equals(incoming.DeviceId, ownDeviceId, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            for (int i = 0; i < peers.Count; i++)
            {
                if (string.Equals(peers[i].DeviceId, incoming.DeviceId, StringComparison.OrdinalIgnoreCase))
                {
                    if (incoming.Seq <= peers[i].Seq)
                    {
                        return false;
                    }

                    incoming.LastSeenUtc = nowUtc;
                    peers[i] = incoming;
                    return true;
                }
            }

            incoming.LastSeenUtc = nowUtc;
            peers.Add(incoming);
            return true;
        }

        // Summe der Werte der anderen fuer denselben Zeitraum. Orders und spend
        // gelten fuer den Kalendermonat, alles andere fuer den Budget-Tag; Werte
        // eines anderen Zeitraums zaehlen nicht.
        internal static int DeviceSyncForeignUsed(IEnumerable<DeviceSyncSnapshot> peers, string key, string day, string month)
        {
            if (peers == null || key == null)
            {
                return 0;
            }

            bool monthly = key == "orders" || key == "spend";
            string period = monthly ? month : day;
            if (string.IsNullOrEmpty(period))
            {
                return 0;
            }

            long sum = 0;
            foreach (DeviceSyncSnapshot peer in peers)
            {
                int value;
                if (peer != null && peer.Used != null &&
                    string.Equals(monthly ? peer.Month : peer.Day, period, StringComparison.Ordinal) &&
                    peer.Used.TryGetValue(key, out value) && value > 0)
                {
                    sum += value;
                }
            }

            return sum > int.MaxValue ? int.MaxValue : (int)sum;
        }

        // Kleinstes eingestelltes Limit der anderen Geraete; 0 heisst keines. Ein
        // Geraet zaehlt, solange sein letzter Kontakt hoechstens
        // DeviceSyncLimitGraceDays her ist - sonst bliebe man nach dem Verkauf eines
        // Laptops fuer immer an dessen Limit gebunden. Genau 7 Tage zaehlen noch.
        internal static int DeviceSyncStrictestForeignLimit(IEnumerable<DeviceSyncSnapshot> peers, string key, DateTime nowUtc, out string peerName)
        {
            peerName = string.Empty;
            if (peers == null || key == null)
            {
                return 0;
            }

            TimeSpan grace = TimeSpan.FromDays(DeviceSyncLimitGraceDays);
            int strictest = 0;
            foreach (DeviceSyncSnapshot peer in peers)
            {
                int value;
                if (peer == null || peer.Limits == null || nowUtc - peer.LastSeenUtc > grace ||
                    !peer.Limits.TryGetValue(key, out value) || value <= 0)
                {
                    continue;
                }

                if (strictest == 0 || value < strictest)
                {
                    strictest = value;
                    peerName = peer.Name ?? string.Empty;
                }
            }

            return strictest;
        }

        // Ein Geraet verschwindet aus der Liste, sobald es nichts mehr bewirkt: sein
        // Limit gilt nicht mehr (mehr als 7 Tage still) und seine Werte gehoeren
        // nicht mehr zum laufenden Monat. currentMonth ist yyyy-MM.
        internal static bool DeviceSyncPeerIsObsolete(DeviceSyncSnapshot peer, DateTime nowUtc, string currentMonth)
        {
            if (peer == null)
            {
                return true;
            }

            return nowUtc - peer.LastSeenUtc > TimeSpan.FromDays(DeviceSyncLimitGraceDays) &&
                !string.Equals(peer.Month, currentMonth, StringComparison.Ordinal);
        }

        // Der Text der Datei fuer den Native Host: je Schluessel das kleinste eingestellte Limit der
        // anderen Geraete (mit derselben Sieben-Tage-Regel wie DeviceSyncStrictestForeignLimit), unter den
        // Namen der Konfiguration. Ein fehlender Schluessel heisst: kein fremdes Limit. Hier stehen nur
        // fremde Limits, nie das eigene und nie das, was nach dem Minimum mit dem eigenen gilt - das
        // Minimum mit seinem Wert nimmt der Host selbst. Das Spiele-Limit steht nicht darin, es gilt
        // direkt in den Regeln (ApplyDeviceSyncGameLimit). Kompakt und ohne Leerraum: die Leser des
        // Hosts sind Regex-Leser.
        internal static string BuildDeviceSyncLimitsJson(IEnumerable<DeviceSyncSnapshot> peers, DateTime nowUtc)
        {
            List<DeviceSyncSnapshot> all = peers == null ? new List<DeviceSyncSnapshot>() : new List<DeviceSyncSnapshot>(peers);
            List<string> items = new List<string>();
            AddDeviceSyncLimitItem(items, "ShoppingDailyLimitMinutes", all, "shopping", nowUtc);
            AddDeviceSyncLimitItem(items, "GamblingDailyLimitMinutes", all, "gambling", nowUtc);
            AddDeviceSyncLimitItem(items, "SocialMediaDailyBudgetMinutes", all, "social:global", nowUtc);

            // "plattform=minuten,...", nach Name geordnet, damit derselbe Stand immer denselben Text ergibt.
            List<string> platforms = new List<string>();
            foreach (DeviceSyncSnapshot peer in all)
            {
                if (peer != null)
                {
                    CollectDeviceSyncPlatforms(platforms, peer.Limits);
                }
            }
            platforms.Sort(StringComparer.Ordinal);

            List<string> pairs = new List<string>();
            foreach (string key in platforms)
            {
                string peerName;
                int minutes = DeviceSyncStrictestForeignLimit(all, key, nowUtc, out peerName);
                if (minutes > 0)
                {
                    pairs.Add(key.Substring("social:".Length) + "=" + minutes.ToString(CultureInfo.InvariantCulture));
                }
            }

            if (pairs.Count > 0)
            {
                items.Add("\"SocialMediaPlatformLimits\":\"" + string.Join(",", pairs.ToArray()) + "\"");
            }

            AddDeviceSyncLimitItem(items, "ShoppingMonthlyOrderLimit", all, "orders", nowUtc);
            AddDeviceSyncLimitItem(items, "ShoppingMonthlyBudgetEuro", all, "spend", nowUtc);
            return "{" + string.Join(",", items.ToArray()) + "}";
        }

        private static void AddDeviceSyncLimitItem(List<string> items, string name, List<DeviceSyncSnapshot> peers, string key, DateTime nowUtc)
        {
            string peerName;
            int value = DeviceSyncStrictestForeignLimit(peers, key, nowUtc, out peerName);
            if (value > 0)
            {
                items.Add("\"" + name + "\":" + value.ToString(CultureInfo.InvariantCulture));
            }
        }

        // ---------------------------------------------------------------- Zustand, Export, Import, Pipe

        internal const string DeviceSyncPipeName = "PurestateDeviceSync";
        internal const int MaxDeviceSyncMessageBytes = 32768;
        // Bei hoechstens ein paar Geraeten je ~2 KiB bleibt die Datei weit darunter.
        private const long MaxDeviceSyncStateBytes = 65536;

        // Reihenfolge der Sperren: webUsageSync vor deviceSyncSync, nie umgekehrt
        // (die Durchsetzung ruft DeviceSyncForeignUsedNow unter webUsageSync). Der
        // Export liest die eigenen Zaehler deshalb, bevor er deviceSyncSync nimmt.
        // Die Spiele (VideoGamesGuard.Run) nehmen deviceSyncSync nur kurz und zuletzt. Unter
        // deviceSyncSync kommt nur noch das Protokoll (logSync); webUsageSync und die Sperre
        // der Spiele werden dort nie genommen.
        private static readonly object deviceSyncSync = new object();
        // Lebenszyklus und Befehle serialisieren, ohne beim Lesen eigener Zaehler
        // deviceSyncSync zu halten (Sperrreihenfolge oben).
        private static readonly object deviceSyncCommandSync = new object();
        private static readonly List<DeviceSyncSnapshot> deviceSyncPeers = new List<DeviceSyncSnapshot>();
        private static bool deviceSyncLoaded;
        private static bool deviceSyncOffConfirmed;
        // Die Nummer gehoert zum Geraet, nicht zur Kopplung: ein sofortiges
        // Aus/An darf fuer den Server keine alte Anfrage wiederholen.
        private static long deviceSyncLastSeq;
        // Die folgenden drei gelten nur fuer die Anzeige und liegen nur im
        // Speicher: nach einem Neustart sind sie leer, bis der Bote sich meldet.
        private static DateTime deviceSyncLastContactUtc = DateTime.MinValue;
        private static string deviceSyncFailure = string.Empty;
        private static bool deviceSyncOtherCode;

        // Der Datenordner steht in jeder Waechterdatei als dieselbe Zeile, weil die
        // Tests sie umschreiben; die Abzweigungspruefung gilt wie fuer jede andere
        // Datei, die der Dienst als SYSTEM dort liest oder schreibt.
        private static string DeviceSyncDataDirectory()
        {
            string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Purestate");
            EnsureDataDirectoryIsNotReparsePoint(dataDir);
            return dataDir;
        }

        private static string DeviceSyncStatePath(string dataDir)
        {
            return Path.Combine(dataDir, "device-sync-state.txt");
        }

        private static string DeviceSyncLimitsPath(string dataDir)
        {
            return Path.Combine(dataDir, "public", "device-sync-limits.json");
        }

        // Ausgang eines Leseversuchs. Nur Content ist ein Befund ueber die Datei: eine
        // gesperrte Datei sagt nicht, dass sie leer ist oder die Option aus. config.json
        // wird bei jedem Durchsetzungslauf ersetzt, und Freigabeverletzungen sind an
        // Waechterdateien gemessen.
        private enum DeviceSyncRead
        {
            Content,
            Absent,
            Unreadable
        }

        private static DeviceSyncRead TryReadDeviceSyncFile(string path, out string text)
        {
            text = string.Empty;
            try
            {
                text = File.ReadAllText(path, Encoding.UTF8);
                return DeviceSyncRead.Content;
            }
            catch (FileNotFoundException)
            {
                return DeviceSyncRead.Absent;
            }
            catch (DirectoryNotFoundException)
            {
                return DeviceSyncRead.Absent;
            }
            catch (Exception)
            {
                return DeviceSyncRead.Unreadable;
            }
        }

        // Meldungen, die sich Takt fuer Takt wiederholen wuerden (Lese-, Schreib- und
        // Loeschfehler), kommen einmal ins Protokoll, bis die Lage sich geloest hat.
        // true, wenn sie neu ist; mit present = false wird sie als geloest vermerkt.
        private static readonly HashSet<string> deviceSyncReported = new HashSet<string>(StringComparer.Ordinal);

        private static bool DeviceSyncReportOnce(string situation, bool present)
        {
            lock (deviceSyncSync)
            {
                if (present)
                {
                    return deviceSyncReported.Add(situation);
                }

                deviceSyncReported.Remove(situation);
                return false;
            }
        }

        private enum DeviceSyncGate
        {
            On,
            Off,
            Unknown,
            Interrupted
        }

        // Laeuft der Abgleich hier? Die Option steht in config.json und wird wie jede
        // andere Regel des Waechters roh gelesen (er prueft die Signatur der Konfiguration
        // nicht; das tut der HMAC-Weg der App). Aus ist nur, was gelesen wurde: eine
        // Konfiguration, in der die Option nicht an ist, oder die Beta zu Ende. Nur das
        // raeumt auf. Alles, was sich nicht lesen laesst - gesperrt, leer, fehlende
        // Konfiguration, gesperrter Code -, ist Unknown: dann loescht und antwortet der
        // Aufrufer nichts, und der naechste Takt entscheidet. Interrupted ist die Option an
        // bei fehlendem oder leerem Code (Ruling 33): der Abgleich ist unterbrochen wie bei
        // beendetem Tray, nicht aus. Die Datei zu loeschen darf nicht billiger sein als
        // "Tray beenden", und niemand hat dafuer die Wartefrist abgewartet; der Stand der
        // anderen bleibt, die Sieben-Tage-Regel laeuft weiter. configJson ist der gelesene
        // Text, damit der Aufrufer nicht ein zweites Mal liest und anders entscheidet.
        private static DeviceSyncGate GetDeviceSyncGate(string dataDir, out string code, out string configJson)
        {
            DeviceSyncGate gate = ReadDeviceSyncGate(dataDir, out code, out configJson);

            // Auf einem Geraet, auf dem der Abgleich nie an war, steht dazu nichts im Protokoll: "Abgleich
            // aus heisst null Aenderung" gilt fuers Protokoll mit, und die Konfiguration ist wegen des Ersetzens bei
            // jedem Durchsetzungslauf oefter kurz unlesbar. Eine Spur ist der Code oder die Zustandsdatei.
            if (gate != DeviceSyncGate.Unknown)
            {
                DeviceSyncReportOnce("gate", false);
            }
            else if (DeviceSyncHasTrace(dataDir) && DeviceSyncReportOnce("gate", true))
            {
                Log("Geraete-Abgleich: config.json (gesperrt, leer oder fehlt) oder device-sync.key (gesperrt) ist gerade nicht lesbar; es wird nichts geloescht, der naechste Takt entscheidet.");
            }

            if (gate != DeviceSyncGate.Interrupted)
            {
                DeviceSyncReportOnce("interrupted", false);
            }
            else if (DeviceSyncReportOnce("interrupted", true))
            {
                Log("Geraete-Abgleich: device-sync.key fehlt oder ist leer, obwohl die Option an ist; der Abgleich ist unterbrochen. Der Stand der anderen Geraete bleibt, geloescht wird nur beim Ausschalten.");
            }

            return gate;
        }

        private static bool DeviceSyncHasTrace(string dataDir)
        {
            return File.Exists(Path.Combine(dataDir, "device-sync.key")) || File.Exists(DeviceSyncStatePath(dataDir));
        }

        private static DeviceSyncGate ReadDeviceSyncGate(string dataDir, out string code, out string configJson)
        {
            code = string.Empty;
            if (TryReadDeviceSyncFile(Path.Combine(dataDir, "config.json"), out configJson) != DeviceSyncRead.Content ||
                configJson.Trim().Length == 0)
            {
                return DeviceSyncGate.Unknown;
            }

            if (!VideoGamesGuard.ReadJsonBool(configJson, "DeviceSyncEnabled", false))
            {
                return DeviceSyncGate.Off;
            }

            // Ein Lesefehler am Code (gesperrt, Zugriff verweigert) ist kein Befund: Unknown, nie ein Aufraeumen.
            string keyText;
            if (TryReadDeviceSyncFile(Path.Combine(dataDir, "device-sync.key"), out keyText) == DeviceSyncRead.Unreadable)
            {
                return DeviceSyncGate.Unknown;
            }

            if (IsBetaExpired())
            {
                return DeviceSyncGate.Off;
            }

            // Fehlt der Code, ist keyText leer. Eine Datei mit null Bytes (ein Absturz mitten im Schreiben) gilt gleich.
            code = keyText.Trim();
            return code.Length == 0 ? DeviceSyncGate.Interrupted : DeviceSyncGate.On;
        }

        // Der Geraeteschluessel der App (device.key, RSA als XML). Der Waechter legt
        // keinen an: fehlt er, ist unlesbar oder hat keinen privaten Teil, ist das
        // Geraet nicht eingeloest, und es gibt nichts zu signieren. Der Aufrufer
        // gibt den Schluessel frei.
        private static RSACryptoServiceProvider LoadDeviceSyncKey(string dataDir)
        {
            string xml;
            if (TryReadDeviceSyncFile(Path.Combine(dataDir, "device.key"), out xml) != DeviceSyncRead.Content || xml.Length == 0)
            {
                return null;
            }

            RSACryptoServiceProvider key = new RSACryptoServiceProvider(2048);
            try
            {
                key.PersistKeyInCsp = false;
                key.FromXmlString(xml);
                if (!key.PublicOnly)
                {
                    return key;
                }
            }
            catch (Exception)
            {
            }

            key.Clear();
            return null;
        }

        // Modulus und Exponent in Base64, getrennt durch einen Punkt - zeichengleich
        // mit der Formatierung der App. Die Waechterdatei darf die App nicht
        // ansprechen, deshalb steht sie hier ein zweites Mal.
        private static string DeviceSyncPublicKey(RSACryptoServiceProvider key)
        {
            RSAParameters parameters = key.ExportParameters(false);
            return Convert.ToBase64String(parameters.Modulus) + "." + Convert.ToBase64String(parameters.Exponent);
        }

        // Die ersten 16 Hex (klein) von SHA-256 ueber den Text des oeffentlichen Schluessels.
        private static string DeviceSyncDeviceId(string pubKey)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(pubKey));
                StringBuilder hex = new StringBuilder(16);
                for (int i = 0; i < 8; i++)
                {
                    hex.Append(hash[i].ToString("x2", CultureInfo.InvariantCulture));
                }
                return hex.ToString();
            }
        }

        private static string DeviceSyncIso(DateTime utc)
        {
            return utc.ToString("yyyy-MM-dd'T'HH:mm:ss.fffffff'Z'", CultureInfo.InvariantCulture);
        }

        private static long DeviceSyncUnixSeconds(DateTime nowUtc)
        {
            long seconds = (long)(nowUtc - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
            return seconds < 0 ? 0 : seconds;
        }

        // ---- Eigener Stand

        // Die eigenen Zaehler und eingestellten Limits dieses Geraets (Spec
        // Abschnitt 4). Nur Eigenes: die Zaehler kommen aus usage.json und
        // video-games-usage.json, die nie Fremdes enthalten, und die Limits aus der
        // Konfiguration - nie die geltenden, sonst bliebe ein einmal strengerer Wert
        // fuer immer stehen.
        private static DeviceSyncSnapshot BuildOwnDeviceSyncSnapshot(DateTime nowUtc, string configJson)
        {
            string day = BudgetDayKey(nowUtc.ToLocalTime());
            DeviceSyncSnapshot own = new DeviceSyncSnapshot();
            own.Name = DeviceSyncSafeName(Environment.MachineName);
            own.Day = day;
            own.Month = MonthOfDay(day);

            WebUsageState web;
            lock (webUsageSync)
            {
                web = LoadWebUsageState(WebUsagePath, day);
            }

            foreach (KeyValuePair<string, int> area in web.Areas)
            {
                own.Used[area.Key] = area.Value;
            }
            own.Used["orders"] = web.MonthOrders;
            own.Used["spend"] = web.MonthSpendEuro;
            own.Used["games"] = VideoGamesGuard.LoadUsageState(
                VideoGamesGuard.UsagePath, day, VideoGamesGuard.TryLoadUsageIntegrityKey()).UsedSeconds;

            AddOwnDeviceSyncLimits(own, configJson);
            return own;
        }

        // Bereich an und Limit an: dann steht das Limit im Paeckchen, sonst nicht.
        // Vorgaben fehlender Felder und Wertebereiche wie im Native Host
        // (LoadShoppingSettings und Nachbarn): ein Wert ausserhalb gilt als
        // Vorgabe. Ein Bereich, der aus ist, steht in AreasOff.
        private static void AddOwnDeviceSyncLimits(DeviceSyncSnapshot own, string json)
        {
            if (VideoGamesGuard.ReadJsonBool(json, "SocialMediaProtectionEnabled", false))
            {
                if (VideoGamesGuard.ReadJsonBool(json, "SocialMediaDailyBudgetEnabled", false))
                {
                    own.Limits["social:global"] = DeviceSyncConfigNumber(json, "SocialMediaDailyBudgetMinutes", 60, 5, 480);
                }

                // "plattform=minuten,..."; die App schreibt es gedeckelt und
                // geordnet, hier zaehlt nur, was gueltig aussieht. Der erste Eintrag
                // einer Plattform gewinnt.
                foreach (string part in VideoGamesGuard.ReadJsonString(json, "SocialMediaPlatformLimits", string.Empty).Split(','))
                {
                    string[] pair = part.Split('=');
                    int minutes;
                    if (pair.Length != 2 ||
                        !int.TryParse(pair[1].Trim(), NumberStyles.None, CultureInfo.InvariantCulture, out minutes) ||
                        minutes < 5 || minutes > 480)
                    {
                        continue;
                    }

                    string key = "social:" + pair[0].Trim().ToLowerInvariant();
                    if (!own.Limits.ContainsKey(key))
                    {
                        own.Limits[key] = minutes;
                    }
                }
            }
            else
            {
                own.AreasOff.Add("social");
            }

            if (VideoGamesGuard.ReadJsonBool(json, "ShoppingProtectionEnabled", false))
            {
                if (VideoGamesGuard.ReadJsonBool(json, "ShoppingDailyLimitEnabled", true))
                {
                    own.Limits["shopping"] = DeviceSyncConfigNumber(json, "ShoppingDailyLimitMinutes", 30, 5, 240);
                }
                if (VideoGamesGuard.ReadJsonBool(json, "ShoppingMonthlyOrderLimitEnabled", true))
                {
                    own.Limits["orders"] = DeviceSyncConfigNumber(json, "ShoppingMonthlyOrderLimit", 10, 1, 99);
                }
                if (VideoGamesGuard.ReadJsonBool(json, "ShoppingMonthlyBudgetEnabled", false))
                {
                    own.Limits["spend"] = DeviceSyncConfigNumber(json, "ShoppingMonthlyBudgetEuro", 200, 1, 99999);
                }
            }
            else
            {
                own.AreasOff.Add("shopping");
            }

            // Gluecksspiel hat drei Zustaende, keinen Ein-Aus-Schalter (Dialog, IsAreaActive): Vollsperre
            // (wie ReadEffectiveGamblingProtectionConfigBool zaehlt das alte Feld mit) ist an und
            // veroeffentlicht kein Limit, nur Zeitlimit ist an und veroeffentlicht es, sonst ist der
            // Bereich aus.
            if (!(VideoGamesGuard.ReadJsonBool(json, "GamblingSupportEnabled", false) ||
                VideoGamesGuard.ReadJsonBool(json, "GamblingProtectionEnabled", false)))
            {
                if (VideoGamesGuard.ReadJsonBool(json, "GamblingDailyLimitEnabled", true))
                {
                    own.Limits["gambling"] = DeviceSyncConfigNumber(json, "GamblingDailyLimitMinutes", 15, 5, 240);
                }
                else
                {
                    own.AreasOff.Add("gambling");
                }
            }

            // Zeit zaehlt der Waechter nur im sanften Modus; im strengen laeuft kein Spiel.
            VideoGamesGuardRules games = VideoGamesGuard.ParseRules(json);
            if (games.Enabled)
            {
                if (games.Mode == "gentle" && games.DailyLimitEnabled)
                {
                    own.Limits["games"] = games.DailyLimitMinutes;
                }
            }
            else
            {
                own.AreasOff.Add("games");
            }
        }

        private static int DeviceSyncConfigNumber(string json, string name, int fallback, int min, int max)
        {
            int value = VideoGamesGuard.ReadJsonInt(json, name, fallback);
            return value >= min && value <= max ? value : fallback;
        }

        // ---- Stand der anderen: im Speicher und in device-sync-state.txt

        // Unter deviceSyncSync aufrufen. Ohne Integritaetsschluessel laesst sich
        // nichts pruefen und nichts schreiben. Es gibt drei Ausgaenge:
        //   - geladen;
        //   - fehlt oder ungueltig: dann zaehlt nur dieses Geraet, bis der naechste
        //     Abgleich die Datei neu schreibt, mit einer Zeile im Protokoll (Spec 8);
        //   - gerade nicht lesbar (gesperrt, Zugriff verweigert): dann bleibt es
        //     ungeladen, SaveDeviceSyncState schreibt nichts, und der naechste Aufruf
        //     versucht es noch einmal. Ein Lesefehler ist kein ungueltiger Inhalt -
        //     sonst ersetzte der naechste Abgleich eine gueltige Datei durch eine
        //     leere Liste.
        private static void EnsureDeviceSyncStateLoaded(string dataDir, byte[] integrityKey)
        {
            if (deviceSyncLoaded || integrityKey == null)
            {
                return;
            }

            long ownSeq = 0;
            DateTime lastContact = DateTime.MinValue;
            List<DeviceSyncSnapshot> peers = new List<DeviceSyncSnapshot>();
            string verdict = null;
            try
            {
                string path = DeviceSyncStatePath(dataDir);
                if (!File.Exists(path))
                {
                    verdict = "fehlt";
                }
                else if (!TryReadDeviceSyncState(path, integrityKey, out ownSeq, out lastContact, out peers))
                {
                    verdict = "ist ungueltig";
                }
            }
            catch (IOException ex)
            {
                NoteUnreadableDeviceSyncState(ex);
                return;
            }
            catch (UnauthorizedAccessException ex)
            {
                NoteUnreadableDeviceSyncState(ex);
                return;
            }
            catch (Exception)
            {
                verdict = "ist ungueltig";
            }

            deviceSyncLoaded = true;
            deviceSyncOffConfirmed = false;
            DeviceSyncReportOnce("state-read", false);
            deviceSyncPeers.Clear();
            if (verdict == null)
            {
                // Max statt Zuweisen: ein Export in einer Runde, in der die Datei nicht
                // lesbar war, hat die Nummer schon hochgezaehlt.
                deviceSyncLastSeq = Math.Max(deviceSyncLastSeq, ownSeq);
                if (lastContact > deviceSyncLastContactUtc)
                {
                    deviceSyncLastContactUtc = lastContact;
                }

                deviceSyncPeers.AddRange(peers);
                return;
            }

            Log("Geraete-Abgleich: device-sync-state.txt " + verdict + "; es zaehlt nur dieses Geraet, bis der naechste Abgleich sie neu schreibt.");
        }

        private static void NoteUnreadableDeviceSyncState(Exception ex)
        {
            if (DeviceSyncReportOnce("state-read", true))
            {
                Log("Geraete-Abgleich: device-sync-state.txt ist gerade nicht lesbar (" + ex.GetType().Name + "); der Stand bleibt unveraendert, der naechste Aufruf versucht es noch einmal.");
            }
        }

        // Aufbau: "v=1", "ownseq=<letzte eigene Nummer>", "last=<letzter Kontakt oder
        // leer>", dann je Geraet "peer=<Zeit seines letzten Kontakts>" und darunter
        // sein Paeckchen im Klartextformat, am Ende "integrity=<HMAC ueber alles davor>"
        // wie bei video-games-usage.json. Das Paeckchen wird mit denselben Funktionen
        // gelesen und geschrieben wie ein empfangenes, es gibt kein zweites Format.
        // Gibt false fuer jeden Inhalt zurueck, der nicht stimmt; Lesefehler der Datei
        // kommen als Ausnahme heraus und sind nicht dasselbe.
        private static bool TryReadDeviceSyncState(string path, byte[] integrityKey, out long ownSeq, out DateTime lastContact, out List<DeviceSyncSnapshot> peers)
        {
            ownSeq = 0;
            lastContact = DateTime.MinValue;
            peers = null;
            if (new FileInfo(path).Length > MaxDeviceSyncStateBytes)
            {
                return false;
            }

            string text = File.ReadAllText(path, Encoding.UTF8);
            const string marker = "\nintegrity=";
            int split = text.LastIndexOf(marker, StringComparison.Ordinal);
            if (split < 0)
            {
                return false;
            }

            string body = text.Substring(0, split + 1);
            string stored = text.Substring(split + marker.Length).Trim();
            if (!DeviceSyncFixedTimeEquals(
                Encoding.UTF8.GetBytes(stored),
                Encoding.UTF8.GetBytes(VideoGamesGuard.ComputeUsageIntegrity(body, integrityKey))))
            {
                return false;
            }

            string[] blocks = Regex.Split(body, "(?m)^peer=");
            Match head = Regex.Match(blocks[0], @"^v=1\nownseq=([0-9]{1,18})\nlast=([^\n]*)\n\z");
            if (!head.Success)
            {
                return false;
            }

            ownSeq = long.Parse(head.Groups[1].Value, CultureInfo.InvariantCulture);
            string last = head.Groups[2].Value;
            if (last.Length > 0 && !TryReadGuardUtc(last, out lastContact))
            {
                return false;
            }

            List<DeviceSyncSnapshot> read = new List<DeviceSyncSnapshot>();
            for (int i = 1; i < blocks.Length; i++)
            {
                int lineEnd = blocks[i].IndexOf('\n');
                DateTime seen;
                DeviceSyncSnapshot peer;
                if (lineEnd < 0 ||
                    !TryReadGuardUtc(blocks[i].Substring(0, lineEnd), out seen) ||
                    !TryParseDeviceSyncPayload(blocks[i].Substring(lineEnd + 1), out peer))
                {
                    return false;
                }

                peer.LastSeenUtc = seen;
                read.Add(peer);
            }

            peers = read;
            return true;
        }

        // Unter deviceSyncSync aufrufen. Geschrieben wird nur, was geladen wurde: eine
        // Datei, die gerade nicht lesbar war, ueberschriebe sonst der Anfang. Ein
        // einzelner Fehlschlag kostet nichts (der Stand liegt im Speicher, der naechste
        // Abgleich schreibt wieder), ein dauernder - Platte voll, Zugriffsrechte - liesse
        // Stand, Limits und Nummer beim naechsten Neustart verschwinden. Deshalb steht
        // er im Protokoll, einmal je Lage.
        private static void SaveDeviceSyncState(string dataDir, byte[] integrityKey)
        {
            if (integrityKey == null || !deviceSyncLoaded)
            {
                return;
            }

            try
            {
                StringBuilder body = new StringBuilder();
                body.Append("v=1\n");
                body.Append("ownseq=").Append(deviceSyncLastSeq.ToString(CultureInfo.InvariantCulture)).Append('\n');
                body.Append("last=").Append(deviceSyncLastContactUtc == DateTime.MinValue ? string.Empty : DeviceSyncIso(deviceSyncLastContactUtc)).Append('\n');
                foreach (DeviceSyncSnapshot peer in deviceSyncPeers)
                {
                    string payload = BuildDeviceSyncPayload(peer);
                    if (payload != null)
                    {
                        body.Append("peer=").Append(DeviceSyncIso(peer.LastSeenUtc)).Append('\n');
                        body.Append(payload.TrimEnd(' '));
                    }
                }

                string text = body.ToString();
                text += "integrity=" + VideoGamesGuard.ComputeUsageIntegrity(text, integrityKey);
                ReplaceFileAtomically(DeviceSyncStatePath(dataDir), delegate(string temp)
                {
                    File.WriteAllText(temp, text, new UTF8Encoding(false));
                });
                DeviceSyncReportOnce("save", false);
            }
            catch (Exception ex)
            {
                if (DeviceSyncReportOnce("save", true))
                {
                    Log("Geraete-Abgleich: device-sync-state.txt konnte nicht geschrieben werden (" + ex.GetType().Name + "); der Stand liegt nur im Speicher, bis es wieder klappt.");
                }
            }
        }

        // Nur aus dem Speicher und ohne Datei, damit die Durchsetzung es unter ihrer
        // eigenen Sperre rufen kann. Der Stand kommt mit dem ersten Takt oder
        // Aufruf aus der Datei in den Speicher. Die Option liest sie nicht: nach dem
        // Ausschalten leert erst der naechste Takt (RefreshDeviceSyncState) den
        // Speicher. Ein Fehler laesst das eigene Geraet allein zaehlen, steht aber
        // einmal je Lage im Protokoll: die Durchsetzung haengt daran
        // (DeviceSyncWithForeign), und still bliebe der Verlust fremder Zeit unsichtbar.
        internal static int DeviceSyncForeignUsedNow(string key, string day, string month)
        {
            try
            {
                lock (deviceSyncSync)
                {
                    int sum = DeviceSyncForeignUsed(deviceSyncPeers, key, day, month);
                    DeviceSyncReportOnce("foreign-used", false);
                    return sum;
                }
            }
            catch (Exception ex)
            {
                if (DeviceSyncReportOnce("foreign-used", true))
                {
                    Log("Geraete-Abgleich: Summe der anderen Geraete nicht gerechnet (" + ex.GetType().Name + "); es zaehlt nur dieses Geraet.");
                }
                return 0;
            }
        }

        // Ein ungeladener Stand ist kein bestaetigter leerer Stand. Beide Werte gehoeren zu derselben Liste.
        internal static bool TryDeviceSyncForeignUsage(string key, string platformKey, string day, string month, out int total, out int platform)
        {
            total = 0;
            platform = 0;
            try
            {
                lock (deviceSyncSync)
                {
                    if (!deviceSyncLoaded && !deviceSyncOffConfirmed) { return false; }
                    total = DeviceSyncForeignUsed(deviceSyncPeers, key, day, month);
                    platform = platformKey.Length > 0 ? DeviceSyncForeignUsed(deviceSyncPeers, platformKey, day, month) : 0;
                    DeviceSyncReportOnce("foreign-state", false);
                    return true;
                }
            }
            catch (Exception ex)
            {
                if (DeviceSyncReportOnce("foreign-state", true))
                {
                    Log("Geraete-Abgleich: Nutzungsstand der anderen Geraete nicht gerechnet (" + ex.GetType().Name + "); bekannte Browserwerte bleiben erhalten.");
                }
                return false;
            }
        }

        // Eigener Wert plus der der anderen fuer denselben Zeitraum - nur fuer Antworten und
        // Grenzen. Gespeichert wird immer allein der eigene Wert, sonst zaehlten sich die Geraete
        // bei jedem Austausch gegenseitig hoch. Als long gerechnet und bei int.MaxValue gedeckelt:
        // eine umgelaufene Summe hobe ein Limit auf. Nimmt deviceSyncSync (ueber
        // DeviceSyncForeignUsedNow); die Reihenfolge der Sperren steht an deren Deklaration.
        internal static int DeviceSyncWithForeign(int own, string key, string day, string month)
        {
            return (int)Math.Min((long)own + DeviceSyncForeignUsedNow(key, day, month), int.MaxValue);
        }

        // Das strengste Limit der anderen Geraete gilt fuer die Spiele direkt in den Regeln: nur
        // im sanften Modus (im strengen laeuft kein Spiel), das Limit geht an, und ein eigenes
        // "aus" weicht dem fremden Wert. Es aendern sich nur die Regeln im Speicher, nie config.json.
        // Wirft nie: ein Fehler im Abgleich darf die Durchsetzung nicht aufhalten (ohne das
        // try bliebe der ganze Takt der Spiele liegen). Dann gilt das eigene Limit allein,
        // und der Fehler steht einmal je Lage im Protokoll.
        internal static void ApplyDeviceSyncGameLimit(VideoGamesGuardRules rules, DateTime nowUtc)
        {
            try
            {
                if (rules == null || rules.Mode != "gentle")
                {
                    return;
                }

                int foreign;
                string peerName;
                lock (deviceSyncSync)
                {
                    foreign = DeviceSyncStrictestForeignLimit(deviceSyncPeers, "games", nowUtc, out peerName);
                }

                if (foreign > 0)
                {
                    rules.DailyLimitMinutes = rules.DailyLimitEnabled ? Math.Min(rules.DailyLimitMinutes, foreign) : foreign;
                    rules.DailyLimitEnabled = true;
                }

                DeviceSyncReportOnce("game-limit", false);
            }
            catch (Exception ex)
            {
                if (DeviceSyncReportOnce("game-limit", true))
                {
                    Log("Geraete-Abgleich: Spiele-Limit nicht angewendet (" + ex.GetType().Name + ").");
                }
            }
        }

        private static void ClearDeviceSyncMemory(bool confirmedOff = false)
        {
            lock (deviceSyncSync)
            {
                deviceSyncPeers.Clear();
                deviceSyncLoaded = false;
                deviceSyncOffConfirmed = confirmedOff;
                deviceSyncLastContactUtc = DateTime.MinValue;
                deviceSyncFailure = string.Empty;
                deviceSyncOtherCode = false;
            }
        }

        // Leert den Speicher; die Datei wird beim naechsten Zugriff neu gelesen,
        // wie nach einem Neustart des Dienstes. Auch die schon gemeldeten Lagen sind
        // dann wieder neu.
        internal static void ResetDeviceSyncStateForTests()
        {
            ClearDeviceSyncMemory();
            lock (deviceSyncSync)
            {
                deviceSyncLastSeq = 0;
                deviceSyncReported.Clear();
            }
        }

        // Gesperrt oder verweigert: der naechste Takt versucht es wieder. Eine
        // Limit-Datei, die stehen bleibt, verschaerft aber weiter - das steht im
        // Protokoll, einmal je Lage.
        private static void DeleteDeviceSyncFile(string path)
        {
            try
            {
                if (File.Exists(path))
                {
                    File.Delete(path);
                }

                DeviceSyncReportOnce("delete:" + path, false);
            }
            catch (Exception ex)
            {
                if (DeviceSyncReportOnce("delete:" + path, true))
                {
                    Log("Geraete-Abgleich: " + Path.GetFileName(path) + " liess sich nicht loeschen (" + ex.GetType().Name + "); der naechste Takt versucht es noch einmal.");
                }
            }
        }

        // Die fremden Limits fuer den Native Host. Unter deviceSyncSync aufrufen. Geschrieben wird
        // nur bei geaendertem Text, und gemessen wird an der Datei, nicht an dem, was zuletzt
        // geschrieben wurde: der Dateiwaechter des Hosts schickt jede Schreibung als neues Regelpaket,
        // und wer die Datei loescht oder leert, hat sie im naechsten Takt wieder. Den Ordner public
        // legt die App mit ihren Zugriffsrechten an; fehlt er, bleibt alles, wie es ist. Ohne
        // fremde Limits ("{}") verschwindet die Datei. Ein Fehler steht einmal je Lage im Protokoll.
        private static void WriteDeviceSyncLimits(string dataDir, string json)
        {
            string path = DeviceSyncLimitsPath(dataDir);
            if (json == "{}")
            {
                DeleteDeviceSyncFile(path);
                return;
            }

            try
            {
                string current;
                if (!Directory.Exists(Path.GetDirectoryName(path)) ||
                    (TryReadDeviceSyncFile(path, out current) == DeviceSyncRead.Content && current == json))
                {
                    return;
                }

                ReplaceFileAtomically(path, delegate(string temp)
                {
                    File.WriteAllText(temp, json, new UTF8Encoding(false));
                });
                DeviceSyncReportOnce("limits-write", false);
            }
            catch (Exception ex)
            {
                if (DeviceSyncReportOnce("limits-write", true))
                {
                    Log("Geraete-Abgleich: device-sync-limits.json konnte nicht geschrieben werden (" + ex.GetType().Name + "); der naechste Takt versucht es noch einmal.");
                }
            }
        }

        // Im Takt des Waechters und einmal beim Start: haelt den Speicher, die Zustandsdatei und die
        // Limit-Datei fuer den Host auf dem Stand der Option und der anderen Geraete. Wirft nie.
        internal static void RefreshDeviceSyncState(DateTime nowUtc)
        {
            lock (deviceSyncCommandSync)
            {
                RefreshDeviceSyncStateCore(nowUtc);
            }
        }

        private static void RefreshDeviceSyncStateCore(DateTime nowUtc)
        {
            try
            {
                string dataDir = DeviceSyncDataDirectory();
                string code;
                string configJson;
                DeviceSyncGate gate = GetDeviceSyncGate(dataDir, out code, out configJson);
                if (gate == DeviceSyncGate.Unknown)
                {
                    // Ein Lesefehler ist kein Befund: weder Speicher noch Dateien
                    // anfassen, der naechste Takt entscheidet.
                    return;
                }

                if (gate == DeviceSyncGate.Off)
                {
                    // Aus (oder Beta zu Ende): der Stand der anderen
                    // wird ignoriert und seine Spuren verschwinden. Bliebe die
                    // Limit-Datei liegen, verschaerfte sie weiter.
                    ClearDeviceSyncMemory(true);
                    DeleteDeviceSyncFile(DeviceSyncStatePath(dataDir));
                    DeleteDeviceSyncFile(DeviceSyncLimitsPath(dataDir));
                    return;
                }

                // On und Interrupted (Option an, Code weg) gehen denselben Weg: er braucht den Code nie, und die
                // Sieben-Tage-Regel samt Limit-Datei muss auch ohne ihn weiterlaufen. Sonst blieben alte Limits
                // stehen, solange der Code fehlt (Unknown kehrt vor der Sieben-Tage-Regel zurueck), oder das
                // Loeschen der Datei raeumte ohne Frist auf.

                byte[] integrityKey = VideoGamesGuard.TryLoadUsageIntegrityKey();
                string month = MonthOfDay(BudgetDayKey(nowUtc.ToLocalTime()));
                lock (deviceSyncSync)
                {
                    EnsureDeviceSyncStateLoaded(dataDir, integrityKey);
                    if (deviceSyncPeers.RemoveAll(delegate(DeviceSyncSnapshot peer) { return DeviceSyncPeerIsObsolete(peer, nowUtc, month); }) > 0)
                    {
                        SaveDeviceSyncState(dataDir, integrityKey);
                    }

                    // Ein Stand, der nicht geladen ist (Datei gerade nicht lesbar, kein Schluessel),
                    // sagt nichts ueber die Limits: dann bleibt die Datei, wie sie ist.
                    if (deviceSyncLoaded)
                    {
                        WriteDeviceSyncLimits(dataDir, BuildDeviceSyncLimitsJson(deviceSyncPeers, nowUtc));
                    }
                }
            }
            catch (Exception ex)
            {
                Log("Geraete-Abgleich: Takt fehlgeschlagen (" + ex.GetType().Name + ").");
            }
        }

        // ---- Befehle der Pipe

        // Eine Zeile je Verbindung, Felder mit | getrennt:
        //   export                 OFF oder OK|<pubKey>|<seq>|<blob>|<signature>
        //   import[|<blob>]...     OK|accepted=<n>|rejected=<m>
        //   fail|<code>            OK            (unreachable, expired oder refused)
        //   status                 OFF oder OK|last=..|failure=..|othercode=..|self=..|peer=..|limit=..
        //   prepare                OK nur nach Aufraeumen bei ausgeschalteter Option
        // OFF heisst: hier laeuft kein Abgleich, der Bote tut dann nichts. Nur status
        // antwortet auch bei unterbrochenem Abgleich (Option an, Code weg). Hat der
        // Server nichts geliefert, lautet die Zeile "import" ohne Trennstrich; "import|"
        // waere ein leeres Paeckchen und wird abgelehnt. Wirft nie.
        internal static string HandleDeviceSyncMessage(string message, DateTime nowUtc)
        {
            lock (deviceSyncCommandSync)
            {
                return HandleDeviceSyncMessageCore(message, nowUtc);
            }
        }

        private static string HandleDeviceSyncMessageCore(string message, DateTime nowUtc)
        {
            try
            {
                if (string.IsNullOrEmpty(message))
                {
                    return "ERROR|bad-message";
                }

                if (message.Length > MaxDeviceSyncMessageBytes)
                {
                    return "ERROR|too-long";
                }

                string[] parts = message.Split('|');
                string command = parts[0];
                if (command != "export" && command != "import" && command != "fail" && command != "status" && command != "prepare")
                {
                    return "ERROR|unknown-command";
                }

                string dataDir = DeviceSyncDataDirectory();
                string code;
                string configJson;
                DeviceSyncGate gate = GetDeviceSyncGate(dataDir, out code, out configJson);

                if (command == "prepare")
                {
                    if (parts.Length != 1) { return "ERROR|bad-message"; }
                    if (gate != DeviceSyncGate.Off) { return "ERROR|not-off"; }

                    // Ein bestaetigtes Aus vor der neuen Kopplung darf nicht zwischen zwei
                    // Takten verschwinden. Ein fehlender Code allein ist weiter kein Aus.
                    ClearDeviceSyncMemory(true);
                    DeleteDeviceSyncFile(DeviceSyncStatePath(dataDir));
                    DeleteDeviceSyncFile(DeviceSyncLimitsPath(dataDir));
                    string ignored;
                    return TryReadDeviceSyncFile(DeviceSyncStatePath(dataDir), out ignored) == DeviceSyncRead.Absent &&
                        TryReadDeviceSyncFile(DeviceSyncLimitsPath(dataDir), out ignored) == DeviceSyncRead.Absent
                        ? "OK" : "ERROR|cleanup";
                }

                // Bei unterbrochenem Abgleich (Option an, Code weg) bekommt der Bote OFF und tut nichts; nur status
                // antwortet weiter, damit die Liste die bekannten Geraete und "Kein Abgleich seit ..." zeigen kann.
                if (gate != DeviceSyncGate.On && !(gate == DeviceSyncGate.Interrupted && command == "status"))
                {
                    return "OFF";
                }

                if (command == "import")
                {
                    return ImportDeviceSync(dataDir, code, parts, nowUtc);
                }

                if (parts.Length != (command == "fail" ? 2 : 1))
                {
                    return "ERROR|bad-message";
                }

                if (command == "export")
                {
                    return ExportDeviceSync(dataDir, code, configJson, nowUtc);
                }

                return command == "fail" ? RecordDeviceSyncFailure(parts[1]) : StatusDeviceSync(dataDir, configJson, nowUtc);
            }
            catch (Exception ex)
            {
                Log("Geraete-Abgleich: Nachricht fehlgeschlagen (" + ex.GetType().Name + ").");
                return "ERROR|failed";
            }
        }

        private static string ExportDeviceSync(string dataDir, string code, string configJson, DateTime nowUtc)
        {
            byte[] integrityKey = VideoGamesGuard.TryLoadUsageIntegrityKey();
            if (integrityKey == null)
            {
                return "OFF";
            }

            using (RSACryptoServiceProvider key = LoadDeviceSyncKey(dataDir))
            {
                if (key == null)
                {
                    return "OFF";
                }

                string pubKey = DeviceSyncPublicKey(key);
                DeviceSyncSnapshot own = BuildOwnDeviceSyncSnapshot(nowUtc, configJson);
                own.DeviceId = DeviceSyncDeviceId(pubKey);

                // Groesserer Wert aus "letzte + 1" und der Uhr: jede Nummer ist neu,
                // auch bei zwei Aufrufen in einer Sekunde, nach einem Neustart und
                // nach einer zurueckgesprungenen Uhr.
                lock (deviceSyncSync)
                {
                    EnsureDeviceSyncStateLoaded(dataDir, integrityKey);
                    deviceSyncLastSeq = Math.Max(deviceSyncLastSeq + 1, DeviceSyncUnixSeconds(nowUtc));
                    own.Seq = deviceSyncLastSeq;
                }

                string payload = BuildDeviceSyncPayload(own);
                string blob = payload == null ? null : SealDeviceSyncPayload(code, own.DeviceId, own.Seq, payload);
                if (blob == null)
                {
                    return "OFF";
                }

                string signature = Convert.ToBase64String(key.SignData(
                    Encoding.UTF8.GetBytes(DeviceSyncCanonical(pubKey, own.Seq, blob)),
                    HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1));

                // Erst jetzt die Nummer festhalten: ein Export, der nichts ergibt,
                // soll auch keine Datei anlegen.
                lock (deviceSyncSync)
                {
                    SaveDeviceSyncState(dataDir, integrityKey);
                }

                return "OK|" + pubKey + "|" + own.Seq.ToString(CultureInfo.InvariantCulture) + "|" + blob + "|" + signature;
            }
        }

        // accepted zaehlt neu zusammengefuehrte Paeckchen, rejected nur solche, die
        // in Form oder MAC scheitern. Eine alte Nummer und das eigene Paeckchen
        // zaehlen als keins von beiden: bei jedem Durchlauf kommen die unveraenderten
        // Paeckchen eines stillen Geraets wieder.
        private static string ImportDeviceSync(string dataDir, string code, string[] parts, DateTime nowUtc)
        {
            byte[] integrityKey = VideoGamesGuard.TryLoadUsageIntegrityKey();
            string ownId;
            using (RSACryptoServiceProvider key = LoadDeviceSyncKey(dataDir))
            {
                if (key == null || integrityKey == null)
                {
                    return "OFF";
                }

                ownId = DeviceSyncDeviceId(DeviceSyncPublicKey(key));
            }

            // Erst alles pruefen, was keinen Zustand braucht (Form, MAC, Entschluesseln,
            // Lesen), dann unter der Sperre zusammenfuehren.
            List<DeviceSyncSnapshot> opened = new List<DeviceSyncSnapshot>();
            int rejected = 0;
            bool otherCode = false;
            for (int i = 1; i < parts.Length; i++)
            {
                string id;
                long number;
                string payload;
                DeviceSyncSnapshot peer;
                if (!TryOpenDeviceSyncPayload(code, parts[i], out id, out number, out payload))
                {
                    rejected++;
                    // Ein Umschlag in richtiger Form, der nicht aufgeht, kommt von
                    // einem anderen Code. Muell sagt darueber nichts.
                    otherCode = otherCode || DeviceSyncLooksSealed(parts[i]);
                }
                else if (!TryParseDeviceSyncPayload(payload, out peer) ||
                    !string.Equals(peer.DeviceId, id, StringComparison.OrdinalIgnoreCase) || peer.Seq != number)
                {
                    rejected++;
                }
                else
                {
                    // ID und Nummer gelten aus dem Umschlagkopf, den der MAC schuetzt;
                    // der Text muss mit ihnen uebereinstimmen.
                    peer.DeviceId = id.ToLowerInvariant();
                    opened.Add(peer);
                }
            }

            int accepted = 0;
            lock (deviceSyncSync)
            {
                EnsureDeviceSyncStateLoaded(dataDir, integrityKey);
                foreach (DeviceSyncSnapshot incoming in opened)
                {
                    if (MergeDeviceSyncPeer(deviceSyncPeers, incoming, ownId, nowUtc))
                    {
                        accepted++;
                    }
                }

                deviceSyncLastContactUtc = nowUtc;
                deviceSyncFailure = string.Empty;
                deviceSyncOtherCode = otherCode;

                // Auch ohne neues Paeckchen: der letzte Kontakt steht in der Datei, damit
                // "Kein Abgleich seit ..." einen Neustart ueberlebt.
                SaveDeviceSyncState(dataDir, integrityKey);
            }

            return "OK|accepted=" + accepted + "|rejected=" + rejected;
        }

        // Ein Umschlag in richtiger Form (Laenge, Base64, Version). Geht er beim
        // Oeffnen nicht auf, dann am MAC.
        private static bool DeviceSyncLooksSealed(string envelope)
        {
            if (envelope == null || envelope.Length != DeviceSyncEnvelopeChars)
            {
                return false;
            }

            try
            {
                byte[] body = Convert.FromBase64String(envelope);
                return body.Length == DeviceSyncEnvelopeBytes && body[0] == 0x01;
            }
            catch (FormatException)
            {
                return false;
            }
        }

        private static string RecordDeviceSyncFailure(string code)
        {
            if (code != "unreachable" && code != "expired" && code != "refused")
            {
                return "ERROR|bad-failure-code";
            }

            lock (deviceSyncSync)
            {
                deviceSyncFailure = code;
            }
            return "OK";
        }

        // Fuer die Anzeige der App. Zeitzaehler stehen in Sekunden (orders als
        // Anzahl, spend in Euro), Limits in Minuten. Werte eines anderen Zeitraums
        // fehlen, sonst stuende der Tag von gestern unter "Heute".
        private static string StatusDeviceSync(string dataDir, string configJson, DateTime nowUtc)
        {
            byte[] integrityKey = VideoGamesGuard.TryLoadUsageIntegrityKey();
            DeviceSyncSnapshot own = BuildOwnDeviceSyncSnapshot(nowUtc, configJson);
            StringBuilder line = new StringBuilder("OK");
            lock (deviceSyncSync)
            {
                EnsureDeviceSyncStateLoaded(dataDir, integrityKey);
                line.Append("|last=").Append(deviceSyncLastContactUtc == DateTime.MinValue ? string.Empty : DeviceSyncIso(deviceSyncLastContactUtc));
                line.Append("|failure=").Append(deviceSyncFailure);
                line.Append("|othercode=").Append(deviceSyncOtherCode ? "1" : "0");
                line.Append("|self=").Append(own.Name).Append(';')
                    .Append(DeviceSyncUsedText(own, own.Day, own.Month)).Append(';')
                    .Append(string.Join(",", own.AreasOff.ToArray()));
                foreach (DeviceSyncSnapshot peer in deviceSyncPeers)
                {
                    line.Append("|peer=").Append(peer.Name).Append(';')
                        .Append(DeviceSyncIso(peer.LastSeenUtc)).Append(';')
                        .Append(DeviceSyncUsedText(peer, own.Day, own.Month)).Append(';')
                        .Append(string.Join(",", peer.AreasOff.ToArray()));
                }

                AppendDeviceSyncLimitFields(line, own, nowUtc);
            }

            return line.ToString();
        }

        // schluessel=wert, mit Kommas, nur aus dem laufenden Zeitraum: Tageswerte
        // gelten fuer den Budget-Tag, orders und spend fuer den Monat.
        private static string DeviceSyncUsedText(DeviceSyncSnapshot s, string day, string month)
        {
            List<string> keys = new List<string>(s.Used.Keys);
            keys.Sort(StringComparer.Ordinal);
            List<string> items = new List<string>();
            foreach (string key in keys)
            {
                bool monthly = key == "orders" || key == "spend";
                if (string.Equals(monthly ? s.Month : s.Day, monthly ? month : day, StringComparison.Ordinal))
                {
                    items.Add(key + "=" + s.Used[key].ToString(CultureInfo.InvariantCulture));
                }
            }

            return string.Join(",", items.ToArray());
        }

        // limit=<schluessel>,<geltend>,<eingestellt oder 0>,<name> fuer jeden
        // Schluessel, bei dem das Limit eines anderen Geraets hier gilt: es ist
        // strenger als das eigene, oder hier ist keins eingestellt. Der Name ist der
        // des Geraets mit dem strengsten.
        private static void AppendDeviceSyncLimitFields(StringBuilder line, DeviceSyncSnapshot own, DateTime nowUtc)
        {
            List<string> keys = new List<string>();
            foreach (DeviceSyncSnapshot peer in deviceSyncPeers)
            {
                foreach (string key in peer.Limits.Keys)
                {
                    if (!keys.Contains(key))
                    {
                        keys.Add(key);
                    }
                }
            }

            keys.Sort(StringComparer.Ordinal);
            foreach (string key in keys)
            {
                string peerName;
                int foreign = DeviceSyncStrictestForeignLimit(deviceSyncPeers, key, nowUtc, out peerName);
                int mine;
                own.Limits.TryGetValue(key, out mine);
                if (foreign > 0 && (mine <= 0 || foreign < mine))
                {
                    line.Append("|limit=").Append(key).Append(',')
                        .Append(foreign.ToString(CultureInfo.InvariantCulture)).Append(',')
                        .Append((mine > 0 ? mine : 0).ToString(CultureInfo.InvariantCulture)).Append(',')
                        .Append(peerName);
                }
            }
        }

        // ---- Pipe

        // Ein eigener Faden, gestartet in OnStart; er endet mit "stopping" wie die
        // Herzschlag-Faeden.
        private void DeviceSyncServerLoop()
        {
            while (!stopping)
            {
                try
                {
                    ServeDeviceSyncConnection(DeviceSyncPipeName);
                }
                catch (Exception ex)
                {
                    if (!stopping)
                    {
                        Log("Geraete-Abgleich: Pipe-Fehler: " + ex.Message);
                        Thread.Sleep(1000);
                    }
                }
            }
        }

        // Eine Verbindung: warten, eine Zeile lesen, den Client pruefen, antworten.
        // Geantwortet wird nur dem Client aus dem Installationsordner - jede andere
        // Antwort, auch ein Fehler, bekommt nur ERROR|untrusted-client. Eine eigene
        // Methode, damit ein Test sie mit eigenem Pipe-Namen fahren kann.
        internal void ServeDeviceSyncConnection(string pipeName)
        {
            using (NamedPipeServerStream pipe = CreateDeviceSyncPipe(pipeName))
            {
                if (!WaitForHeartbeatConnection(pipe))
                {
                    return;
                }

                uint clientProcessId = GetHeartbeatClientProcessId(pipe);
                string message = null;
                string tooLong = null;
                try
                {
                    message = ReadPipeLine(pipe, MaxDeviceSyncMessageBytes);
                }
                catch (System.TimeoutException)
                {
                    Log("Geraete-Abgleich: Nachricht nicht rechtzeitig gelesen.");
                    return;
                }
                catch (InvalidDataException)
                {
                    tooLong = "ERROR|too-long";
                }

                string rejectionReason;
                if (!IsTrustedDeviceSyncClient(clientProcessId, out rejectionReason))
                {
                    Log("Geraete-Abgleich: Client abgewiesen: " + rejectionReason);
                    WriteDeviceSyncResponse(pipe, "ERROR|untrusted-client");
                    return;
                }

                WriteDeviceSyncResponse(pipe, tooLong != null ? tooLong : HandleDeviceSyncMessage(message, ReadClockAnchorUtc()));
            }
        }

        // Dieselbe Zugriffsliste wie die Herzschlag-Pipe, aus derselben Stelle
        // (CreateGuardPipeSecurity); eine Instanz genuegt, und die Puffer fassen eine
        // ganze Zeile.
        internal static NamedPipeServerStream CreateDeviceSyncPipe(string pipeName)
        {
            return new NamedPipeServerStream(
                pipeName,
                PipeDirection.InOut,
                1,
                PipeTransmissionMode.Byte,
                PipeOptions.Asynchronous,
                MaxDeviceSyncMessageBytes,
                MaxDeviceSyncMessageBytes,
                CreateGuardPipeSecurity());
        }

        // Nicht WriteHeartbeatResponse: das haengt an "OK" die Schutzmodi des
        // Herzschlags an, und die Antwort "OK" auf fail soll "OK" bleiben.
        private static void WriteDeviceSyncResponse(NamedPipeServerStream pipe, string response)
        {
            try
            {
                byte[] bytes = Encoding.ASCII.GetBytes(response + "\n");
                pipe.Write(bytes, 0, bytes.Length);
                pipe.Flush();
            }
            catch (Exception)
            {
            }
        }

        // Den Bildpfad des Clients liest TryReadPipeClientImagePath, dieselbe Stelle wie
        // beim Herzschlag; hier entscheidet nur, was als vertrauenswuerdig gilt.
        private static bool IsTrustedDeviceSyncClient(uint processId, out string rejectionReason)
        {
            string clientPath;
            if (!TryReadPipeClientImagePath(processId, out clientPath, out rejectionReason))
            {
                return false;
            }

            if (IsTrustedDeviceSyncClientProcess(clientPath, AppDomain.CurrentDomain.BaseDirectory))
            {
                return true;
            }

            rejectionReason = "client is not Purestate.exe of the install folder: " + clientPath;
            return false;
        }

        // Wie IsTrustedHeartbeatClientProcess, nur auf die Purestate.exe des
        // Installationsordners: geprueft wird der Bildpfad, sonst nichts. Der
        // Native Host ist hier kein Client.
        internal static bool IsTrustedDeviceSyncClientProcess(string clientPath, string baseDir)
        {
            if (string.IsNullOrWhiteSpace(clientPath))
            {
                return false;
            }

            try
            {
                return string.Equals(
                    Path.GetFullPath(clientPath),
                    Path.GetFullPath(Path.Combine(baseDir ?? string.Empty, "Purestate.exe")),
                    StringComparison.OrdinalIgnoreCase);
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
