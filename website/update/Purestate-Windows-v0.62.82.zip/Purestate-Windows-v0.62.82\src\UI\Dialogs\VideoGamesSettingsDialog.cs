using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // Video game protection, split into clear sections: Schutz / Zeitregeln /
    // Geschützte Spiele / Automatische Erkennung. The game list shows the name
    // prominently and the (shortened) path as a second column with a tooltip.
    // Config mapping unchanged: Aus = disabled, "Mit Zeitregeln" = gentle,
    // "Vollständig sperren" = strict.
    internal sealed partial class AdminForm
    {
        private void ShowVideoGamesSettings()
        {
            AppConfig config = Support.LoadConfig();
            List<VideoGameTarget> targets = Support.ReadVideoGameTargets();
            List<VideoGameTarget> originalTargets = CloneVideoGameTargets(targets);
            using (DialogShell shell = new DialogShell(theme, "Videospiel-Schutz",
                "Purestate begrenzt oder sperrt selbst ausgewählte Windows-Spiele. Gemessen wird, wie lange ein Spiel läuft.",
                "Stellt Zeitregeln und Sperren für Windows-Spiele ein.", true))
            {
                shell.Kicker = "Schutzbereich";
                shell.AddSection("Schutz");
                bool isOn = config.VideoGamesProtectionEnabled;
                bool isStrict = string.Equals(config.VideoGamesProtectionMode, "strict", StringComparison.OrdinalIgnoreCase);
                RadioButton off = Ui.Radio(theme, "Kein Videospiel-Schutz", !isOn,
                    "Spiele werden nicht eingeschränkt.");
                RadioButton gentle = Ui.Radio(theme, "Mit Zeitregeln: Spielzeit begrenzen", isOn && !isStrict,
                    "Spiele laufen, bis das Zeitlimit oder die Sperrzeit erreicht ist.");
                RadioButton strict = Ui.Radio(theme, "Vollständig sperren", isOn && isStrict,
                    "Die geschützten Spiele werden immer beendet, auch wenn Purestate geschlossen ist.");
                shell.Add(off);
                shell.Add(gentle);
                shell.Add(strict);

                shell.AddSection("Zeitregeln");
                shell.AddHint("Die Zeitregeln gelten nur bei „Mit Zeitregeln“.");
                CheckBox dailyLimit = Ui.Check(theme, "Tägliches Zeitlimit", config.VideoGamesDailyLimitEnabled,
                    "Begrenzt die gesamte Spielzeit pro Tag.");
                shell.Add(dailyLimit);
                ComboBox dailyLimitMinutes = Ui.MinutesCombo(5, 600,
                    Support.NormalizeVideoGamesDailyLimitMinutes(config.VideoGamesDailyLimitMinutes),
                    "Zeitlimit in Minuten", "Wert zwischen 5 und 600 Minuten pro Tag.");
                FlowLayoutPanel dailyRow = shell.Row(dailyLimitMinutes, Ui.WrapLabel(theme, "Minuten pro Tag", 200, true));
                dailyRow.Padding = new Padding(24, 0, 0, 0);
                shell.Add(dailyRow);
                Ui.BindVisibility(dailyLimit, dailyRow);

                CheckBox curfew = Ui.Check(theme, "Feste Spiel-Pause (Sperrzeit)", config.VideoGamesCurfewEnabled,
                    "In diesem Zeitfenster werden die geschützten Spiele beendet und gesperrt.");
                shell.Add(curfew);
                ComboBox curfewStart = Ui.TimeCombo(config.VideoGamesCurfewStart, "22:00", "Beginn der Spiel-Pause");
                ComboBox curfewEnd = Ui.TimeCombo(config.VideoGamesCurfewEnd, "06:00", "Ende der Spiel-Pause");
                FlowLayoutPanel curfewRow = shell.Row(Ui.WrapLabel(theme, "Von", 40, true), curfewStart, Ui.WrapLabel(theme, "bis", 40, true), curfewEnd, Ui.WrapLabel(theme, "Uhr (auch über Mitternacht möglich)", 260, true));
                curfewRow.Padding = new Padding(24, 0, 0, 0);
                shell.Add(curfewRow);
                Label curfewError = shell.AddErrorLine();
                Ui.BindVisibility(curfew, curfewRow);

                // Usage, in plain words.
                int usedMinutes = Support.ReadVideoGamesUsedMinutesToday();
                string usageText;
                if (usedMinutes < 0)
                {
                    // USG-001: Der Zaehler traegt keine gueltige Signatur. Der
                    // Waechter behandelt das als aufgebrauchtes Budget - die Anzeige
                    // darf dann nicht "noch soundso viel" behaupten.
                    usageText = "Der Laufzeitzähler wurde außerhalb von Purestate verändert. " +
                        "Das Tagesbudget gilt heute als aufgebraucht; morgen zählt Purestate normal weiter.";
                }
                else if (config.VideoGamesDailyLimitEnabled)
                {
                    int limitTotal = Support.NormalizeVideoGamesDailyLimitMinutes(config.VideoGamesDailyLimitMinutes);
                    int remaining = Math.Max(0, limitTotal - usedMinutes);
                    usageText = "Heute gespielt: " + usedMinutes + " von " + limitTotal + " Minuten. Noch verfügbar: " + remaining + " Minuten.";
                }
                else
                {
                    usageText = "Heute gespielt: " + usedMinutes + " Minuten.";
                }
                shell.AddHint(usageText);

                shell.AddSection("Geschützte Spiele");
                shell.AddHint("Diese Spiele überwacht Purestate. Der Haken vor einem Spiel bedeutet: die Regeln gelten für dieses Spiel.");

                ListView targetList = new ListView
                {
                    View = View.Details,
                    CheckBoxes = true,
                    FullRowSelect = true,
                    HeaderStyle = ColumnHeaderStyle.Nonclickable,
                    Width = shell.InnerWidth,
                    Height = 160,
                    Font = Ui.FontBody,
                    ShowItemToolTips = true,
                    BackColor = theme.CardBackground,
                    ForeColor = theme.TextPrimary
                };
                targetList.Columns.Add("Spiel", 240);
                targetList.Columns.Add("Speicherort", shell.InnerWidth - 260);
                Ui.SetAccessibility(targetList, "Liste geschützter Spiele", "Jede Zeile zeigt Name und Speicherort. Leertaste schaltet den Haken um.", AccessibleRole.List);
                Ui.StyleListView(theme, targetList);
                Button addTarget = Ui.SecondaryButton(theme, "Spiel hinzufügen", "Wählt die Programmdatei eines Spiels aus.");
                Button removeTarget = Ui.SecondaryButton(theme, "Spiel entfernen", "Entfernt das ausgewählte Spiel aus der Liste.");
                FlowLayoutPanel targetActions = shell.Row(addTarget, removeTarget);
                Button emptyAddTarget = Ui.SecondaryButton(theme, "Spiel hinzufügen", "Wählt die Programmdatei eines Spiels aus.");
                // UIX-001: Beide Knoepfe teilen sich unten denselben Handler.
                Control emptyTargets = Ui.EmptyState(theme, "Noch keine Spiele hinzugefügt",
                    "Füge eine Programmdatei hinzu oder aktiviere unten die automatische Erkennung.", emptyAddTarget);
                shell.Add(emptyTargets);
                shell.Add(targetList);
                shell.Add(targetActions);

                // DESK-07: Haken gehen sofort ins Modell. Vorher baute
                // Hinzufuegen/Entfernen die Liste aus targets neu, das die Haken
                // erst beim Speichern erfuhr - Aenderungen sprangen zurueck.
                Action rebuildTargetItems = Ui.BindCheckList(targetList, targets,
                    delegate (VideoGameTarget target) { return target.Enabled; },
                    delegate (VideoGameTarget target, bool value) { target.Enabled = value; },
                    delegate (VideoGameTarget target)
                    {
                        string name = target.Name;
                        if (target.Launcher)
                        {
                            name += " (Spieleplattform, sperrt breit)";
                        }
                        if (!System.IO.File.Exists(target.Path))
                        {
                            name += " (Datei fehlt)";
                        }
                        ListViewItem item = new ListViewItem(name) { ToolTipText = target.Path };
                        item.SubItems.Add(Ui.ShortenPath(target.Path, 58));
                        return item;
                    });
                Action refreshTargetList = delegate
                {
                    rebuildTargetItems();
                    targetList.Visible = targets.Count > 0;
                    emptyTargets.Visible = targets.Count == 0;
                    targetActions.Visible = targets.Count > 0;
                };
                refreshTargetList();

                Label listError = shell.AddErrorLine();

                // UIX-001: Hier stand `addTarget.Click += delegate` und der
                // Leerzustand-Knopf reichte per PerformClick() weiter. Bei leerer
                // Liste ist `targetActions` aber unsichtbar (siehe refreshTargetList),
                // und PerformClick() loest auf einem nicht auswaehlbaren Steuerelement
                // still gar nichts aus. Damit war der einzige sichtbare
                // "Spiel hinzufuegen"-Knopf fuer JEDEN neuen Nutzer tot - die Liste
                // ist ja anfangs leer, und ohne ersten Eintrag taucht der
                // funktionierende Knopf nie auf. Live gefunden am 2026-08-24.
                EventHandler addTargetClick = delegate
                {
                    using (OpenFileDialog picker = new OpenFileDialog())
                    {
                        picker.Title = "Spieldatei auswählen";
                        picker.Filter = "Programme (*.exe)|*.exe";
                        picker.CheckFileExists = true;
                        if (picker.ShowDialog(shell) != DialogResult.OK)
                        {
                            return;
                        }

                        string fullPath;
                        try
                        {
                            fullPath = System.IO.Path.GetFullPath(picker.FileName);
                        }
                        catch (Exception)
                        {
                            shell.ShowError(listError, "Die gewählte Datei kann nicht als Spiel geschützt werden.", addTarget);
                            return;
                        }

                        string validationError = Support.ValidateVideoGameTargetPath(fullPath);
                        if (validationError.Length != 0)
                        {
                            shell.ShowError(listError, validationError, addTarget);
                            return;
                        }

                        foreach (VideoGameTarget existing in targets)
                        {
                            if (string.Equals(existing.Path, fullPath, StringComparison.OrdinalIgnoreCase))
                            {
                                shell.ShowError(listError, "Dieses Spiel ist bereits in der Liste.", targetList);
                                return;
                            }
                        }

                        bool isLauncher = Support.IsKnownGameLauncherPath(fullPath);
                        if (isLauncher)
                        {
                            if (!Ui.Confirm(shell, theme, "Spieleplattform sperren",
                                "Das ist eine ganze Spieleplattform (Launcher). Eine Sperre wirkt breit: auch Updates, Downloads und nicht geschützte Spiele dieser Plattform sind betroffen." + Environment.NewLine +
                                "Soll die Plattform trotzdem in die Liste?", "Hinzufügen", "Abbrechen"))
                            {
                                return;
                            }
                        }

                        string displayName = System.IO.Path.GetFileNameWithoutExtension(fullPath);
                        try
                        {
                            string description = System.Diagnostics.FileVersionInfo.GetVersionInfo(fullPath).FileDescription;
                            if (!string.IsNullOrWhiteSpace(description))
                            {
                                displayName = description.Trim();
                            }
                        }
                        catch (Exception)
                        {
                        }

                        targets.Add(new VideoGameTarget
                        {
                            Enabled = true,
                            Launcher = isLauncher,
                            Name = Support.CleanVideoGameTargetName(displayName),
                            Path = fullPath
                        });
                        shell.ClearError(listError);
                        refreshTargetList();
                    }
                };
                addTarget.Click += addTargetClick;
                emptyAddTarget.Click += addTargetClick;

                removeTarget.Click += delegate
                {
                    int index = targetList.SelectedIndices.Count > 0 ? targetList.SelectedIndices[0] : -1;
                    if (index < 0 || index >= targets.Count)
                    {
                        shell.ShowError(listError, "Bitte wähle zuerst ein Spiel in der Liste aus.", targetList);
                        return;
                    }
                    shell.ClearError(listError);
                    targets.RemoveAt(index);
                    refreshTargetList();
                };

                shell.AddSection("Automatische Erkennung");
                bool areaUnconfigured = !config.VideoGamesProtectionEnabled &&
                    string.Equals(config.VideoGamesProtectionMode, "planned", StringComparison.OrdinalIgnoreCase);

                CheckBox autoDetect = Ui.Check(theme, "Installierte Spiele automatisch erkennen", areaUnconfigured || config.VideoGamesAutoDetectEnabled,
                    "Erkennt Spiele der großen Plattformen (Steam, Epic, GOG, EA, Battle.net, Xbox) automatisch.");
                shell.Add(autoDetect);

                CheckBox heuristic = Ui.Check(theme, "Auch unbekannte Spiele erkennen", (areaUnconfigured || config.VideoGamesHeuristicEnabled) && autoDetect.Checked,
                    "Purestate versucht, bisher unbekannte Spiele am Verhalten zu erkennen.");
                heuristic.Margin = new Padding(24, 0, 0, 4);
                heuristic.Enabled = autoDetect.Checked;
                shell.Add(heuristic);
                Label heuristicHint = Ui.WrapLabel(theme,
                    // WS-10: "immer eine 60-Sekunden-Warnung" stimmte nicht. Nur
                    // per Verhalten erkannte Programme bekommen einen Countdown
                    // (erster Treffer 5 Minuten, spaeter 60 Sekunden); eingetragene
                    // und von Plattformen erkannte Spiele werden direkt geschlossen.
                    "Purestate kann versuchen, bisher unbekannte Spiele automatisch zu erkennen. In seltenen Fällen kann dabei auch ein anderes 3D-Programm als Spiel eingestuft werden. Ein so erkanntes Programm wird beim ersten Treffer nach 5 Minuten beendet, später nach 60 Sekunden. Selbst eingetragene und von Spieleplattformen erkannte Spiele werden zur Sperrzeit, nach dem Zeitlimit oder bei „Vollständig sperren“ ohne garantierte Speicherfrist geschlossen - nicht gespeicherte Spielstände können verloren gehen.",
                    shell.InnerWidth - 24, true);
                heuristicHint.Margin = new Padding(24, 0, 0, Ui.GapSmall);
                shell.Add(heuristicHint);

                autoDetect.CheckedChanged += delegate
                {
                    heuristic.Enabled = autoDetect.Checked;
                    if (!autoDetect.Checked)
                    {
                        heuristic.Checked = false;
                    }
                };

                Button detectionButton = Ui.SecondaryButton(theme, "Erkannte Spiele und Ausnahmen verwalten",
                    "Zeigt automatisch erkannte Spiele und verwaltet Programme, die nie als Spiel gelten sollen.");
                detectionButton.Click += delegate { ShowVideoGameDetectionDialog(shell); };
                shell.Add(detectionButton);

                shell.AddHint("Technische Grenzen: Spiele im Browser oder über Cloud-Dienste werden nicht erkannt. Änderungen wirken innerhalb von etwa 30 Sekunden.");

                shell.SaveButton.Click += delegate
                {
                    if (curfew.Checked &&
                        (!Support.IsValidScheduleTimeText(curfewStart.Text) || !Support.IsValidScheduleTimeText(curfewEnd.Text)))
                    {
                        shell.ShowError(curfewError, "Bitte gib die Spiel-Pause im Format 22:00 ein.",
                            Support.IsValidScheduleTimeText(curfewStart.Text) ? curfewEnd : curfewStart);
                        return;
                    }
                    shell.ClearError(curfewError);

                    bool enabledValue = !off.Checked;
                    string modeValue = strict.Checked ? "strict" : "gentle";
                    bool dailyLimitValue = dailyLimit.Checked;
                    int dailyLimitMinutesValue = int.Parse(dailyLimitMinutes.Text);
                    bool curfewValue = curfew.Checked;
                    string curfewStartValue = curfewStart.Text;
                    string curfewEndValue = curfewEnd.Text;
                    bool autoDetectValue = autoDetect.Checked;
                    bool heuristicValue = heuristic.Checked;
                    List<VideoGameTarget> originalTargetsValue = originalTargets;
                    // Kopie: der Dialog bleibt offen, das Modell darf sich waehrend
                    // des Speicherns nicht unter der Hintergrundaktion aendern.
                    List<VideoGameTarget> targetsValue = CloneVideoGameTargets(targets);

                    if (!ConfirmPassword("Videospiel-Schutz speichern", shell))
                    {
                        return;
                    }

                    RunAction("Videospiel-Schutz speichern", shell, delegate
                    {
                        Support.ThrowIfVideoGameTargetsWeakeningNotAllowed(originalTargetsValue, targetsValue, Support.TrustedLocalNow(), false);
                        Support.SetVideoGamesSettingsGuarded(enabledValue, modeValue, dailyLimitValue, dailyLimitMinutesValue, curfewValue, curfewStartValue, curfewEndValue, autoDetectValue, heuristicValue, Support.TrustedLocalNow(), false);
                        Support.WriteVideoGameTargets(targetsValue);
                    }, "Videospiel-Schutz: Änderungen gespeichert. Wirkt in etwa 30 Sekunden.");
                };

                shell.FinishLayout();
                shell.Shown += delegate { (strict.Checked ? strict : (gentle.Checked ? gentle : off)).Focus(); };
                shell.ShowDialog(this);
            }
        }

        private static List<VideoGameTarget> CloneVideoGameTargets(IEnumerable<VideoGameTarget> targets)
        {
            List<VideoGameTarget> clones = new List<VideoGameTarget>();
            foreach (VideoGameTarget target in targets ?? new VideoGameTarget[0])
            {
                if (target == null)
                {
                    continue;
                }

                clones.Add(new VideoGameTarget
                {
                    Enabled = target.Enabled,
                    Launcher = target.Launcher,
                    Name = target.Name,
                    Path = target.Path
                });
            }
            return clones;
        }

        // Shows the auto-detected games (read-only) and manages the "kein
        // Spiel" exemptions. Adding an exemption weakens the heuristic, so it
        // requires the app password and only becomes effective after 15
        // minutes; removing one only strengthens protection and is free.
        private void ShowVideoGameDetectionDialog(Form owner)
        {
            using (DialogShell shell = new DialogShell(theme, "Erkannte Spiele und Ausnahmen",
                "Hier siehst du, welche Spiele Purestate automatisch erkannt hat, und kannst Programme ausnehmen, die nie als Spiel gelten sollen.",
                "Zeigt automatisch erkannte Spiele und verwaltet Nicht-Spiel-Ausnahmen.", false))
            {
                shell.AddSection("Automatisch erkannte Spiele");
                ListBox detectedList = new ListBox
                {
                    Width = shell.InnerWidth,
                    Height = 140,
                    Font = Ui.FontBody,
                    HorizontalScrollbar = true,
                    IntegralHeight = false,
                    BackColor = theme.CardBackground,
                    ForeColor = theme.TextPrimary
                };
                Ui.SetAccessibility(detectedList, "Liste erkannter Spiele", "Jeder Eintrag zeigt die Erkennungsquelle und den Speicherort.", AccessibleRole.List);
                foreach (KeyValuePair<string, string> entry in Support.ReadVideoGameDetectedForDisplay())
                {
                    detectedList.Items.Add(entry.Key + " - " + entry.Value);
                }
                if (detectedList.Items.Count == 0)
                {
                    detectedList.Items.Add("Noch keine Spiele erkannt. Die Erkennung läuft im Hintergrund.");
                }
                shell.Add(detectedList);

                shell.AddSection("Programme, die nie als Spiel gelten sollen");
                shell.AddHint("Diese Ausnahmen wirken nur auf die automatische Erkennung unbekannter Spiele. Selbst eingetragene Spiele sind nie ausnehmbar.");
                ListBox exemptionList = new ListBox
                {
                    Width = shell.InnerWidth,
                    Height = 120,
                    Font = Ui.FontBody,
                    HorizontalScrollbar = true,
                    IntegralHeight = false,
                    BackColor = theme.CardBackground,
                    ForeColor = theme.TextPrimary
                };
                Ui.SetAccessibility(exemptionList, "Liste der Ausnahmen", "Programme, die die Erkennung nie als Spiel einstufen darf.", AccessibleRole.List);
                shell.Add(exemptionList);

                List<VideoGameExemption> exemptions = Support.ReadVideoGameExemptions();
                Action refreshExemptionList = delegate
                {
                    exemptionList.Items.Clear();
                    foreach (VideoGameExemption exemption in exemptions)
                    {
                        string entry = exemption.Path;
                        if (exemption.ActivatesAtUtc > Support.TrustedUtcNow())
                        {
                            entry += " (wirksam ab " + exemption.ActivatesAtUtc.ToLocalTime().ToString("g") + ")";
                        }
                        exemptionList.Items.Add(entry);
                    }
                };
                refreshExemptionList();

                Label exemptionError = shell.AddErrorLine();
                Button addExemption = Ui.SecondaryButton(theme, "Ausnahme hinzufügen",
                    "Trägt eine Programmdatei als Nicht-Spiel ein. Braucht das Passwort und wird erst nach 15 Minuten wirksam.");
                Button removeExemption = Ui.SecondaryButton(theme, "Ausnahme entfernen",
                    "Entfernt die ausgewählte Ausnahme sofort. Kein Passwort nötig, der Schutz wird dadurch nur strenger.");
                shell.Add(shell.Row(addExemption, removeExemption));

                addExemption.Click += delegate
                {
                    using (OpenFileDialog picker = new OpenFileDialog())
                    {
                        picker.Title = "Programmdatei als Nicht-Spiel ausnehmen";
                        picker.Filter = "Programme (*.exe)|*.exe";
                        picker.CheckFileExists = true;
                        if (picker.ShowDialog(shell) != DialogResult.OK)
                        {
                            return;
                        }

                        string validationError = Support.ValidateVideoGameExemptionPath(picker.FileName);
                        if (validationError.Length != 0)
                        {
                            shell.ShowError(exemptionError, validationError, addExemption);
                            return;
                        }

                        if (!ConfirmPassword("Videospiel-Ausnahme hinzufügen", shell))
                        {
                            return;
                        }

                        string addError = string.Empty;
                        string exemptionPath = picker.FileName;
                        if (!TryListChange(shell, exemptionError, addExemption, delegate { addError = Support.AddVideoGameExemption(exemptionPath); }))
                        {
                            return;
                        }
                        if (addError.Length != 0)
                        {
                            shell.ShowError(exemptionError, addError, addExemption);
                            return;
                        }

                        shell.ClearError(exemptionError);
                        exemptions = Support.ReadVideoGameExemptions();
                        refreshExemptionList();
                        ShowSaveFeedback("Die Ausnahme wird in 15 Minuten wirksam.");
                    }
                };

                removeExemption.Click += delegate
                {
                    int index = exemptionList.SelectedIndex;
                    if (index < 0 || index >= exemptions.Count)
                    {
                        shell.ShowError(exemptionError, "Bitte wähle zuerst eine Ausnahme in der Liste aus.", exemptionList);
                        return;
                    }
                    string exemptionPath = exemptions[index].Path;
                    if (!TryListChange(shell, exemptionError, removeExemption, delegate { Support.RemoveVideoGameExemption(exemptionPath); }))
                    {
                        return;
                    }
                    shell.ClearError(exemptionError);
                    exemptions = Support.ReadVideoGameExemptions();
                    refreshExemptionList();
                };

                shell.FinishLayout();
                shell.ShowDialog(owner);
            }
        }
    }
}
