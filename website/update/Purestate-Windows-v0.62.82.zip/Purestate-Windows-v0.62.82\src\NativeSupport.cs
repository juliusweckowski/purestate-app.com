using System;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Purestate.Native
{
    public enum PasswordCheckResult
    {
        Success = 0,
        WrongPassword = 1,
        LockedOut = 2
    }

    internal sealed class PasswordRecord
    {
        public string Algorithm;
        public int Iterations;
        public string Salt;
        public string Hash;
    }

    internal sealed class AppConfig
    {
        public bool ProtectionEnabled = true;
        public bool HostsEnabled = true;
        public bool FamilyDnsEnabled = true;
        public string DnsProfile = "CloudflareFamily";
        public bool BrowserPoliciesEnabled = true;
        public bool BypassBlockingEnabled = true;
        public bool UnsupportedBrowserBlockingEnabled = true;
        public bool TamperProtectionEnabled = true;
        // YouTube-Modus "eingeschraenkt" (Chromium ForceYouTubeRestrict=1).
        // Bis Schema 12 fest verdrahtet und nicht abschaltbar, ab Schema 13 ein
        // Schalter. Vorgabe seit 2026-08-09 AUS: der Filter sperrt regelmaessig
        // harmlose Videos aus und schneidet YouTube breit zu, statt gegen die
        // Impulse zu wirken, fuer die die Schutzbereiche gebaut sind. Wer ihn
        // will, schaltet ihn in den Einstellungen ein. Bestehende
        // Installationen behalten ihren gespeicherten Wert - ein Update darf
        // Schutz nicht still abbauen (ReadBool-Vorgabe in
        // NativeSupportConfig.cs bleibt deshalb true).
        public bool YouTubeRestrictEnabled = false;
        // Steuert, woran die Erwachsenen-Sperrliste haengt. Vorgabe false =
        // bisheriges Modell: die Liste haengt an der allgemeinen Sperrliste und
        // wirkt unabhaengig vom Schutzbereich-Schalter - der Schutz bestehender
        // Installationen bleibt beim Sprung auf Schema 14 unveraendert. true =
        // neues Modell, die Liste haengt am Schutzbereich (fuer Neuinstallation
        // vorgesehen). Gelesen von Support.AdultDomainListActive (Befund #7;
        // Get-DomainList in Common.ps1 liest es serverseitig schon seit c184009).
        public bool AdultHostsFollowArea = false;
        public bool SiteRedditEnabled = true;
        public bool SiteXEnabled = true;
        public bool SiteBlueskyEnabled = true;
        public bool SiteTumblrEnabled = true;
        public bool SiteDeviantArtEnabled = true;
        public bool SitePixivEnabled = true;
        public bool SiteNewgroundsEnabled = true;
        public bool SiteImgurEnabled = true;
        public bool SiteInstagramEnabled = true;
        public bool SiteTikTokEnabled = true;
        public bool SitePinterestEnabled = true;
        public bool AdultContentProtectionEnabled = true;
        public string AdultContentProtectionMode = "strict";
        public bool GamblingProtectionEnabled = false;
        public string GamblingProtectionMode = "off";
        public bool ShoppingProtectionEnabled = false;
        public string ShoppingProtectionMode = "planned";
        public bool VideoGamesProtectionEnabled = false;
        public string VideoGamesProtectionMode = "planned";
        public bool VideoGamesDailyLimitEnabled = false;
        public int VideoGamesDailyLimitMinutes = 60;
        public bool VideoGamesCurfewEnabled = false;
        public string VideoGamesCurfewStart = "22:00";
        public string VideoGamesCurfewEnd = "06:00";
        public bool VideoGamesAutoDetectEnabled = false;
        public bool VideoGamesHeuristicEnabled = false;
        public bool SocialMediaProtectionEnabled = false;
        public string SocialMediaProtectionMode = "planned";
        public string ProtectionAreaRulePackVersion = "1";
        public bool GamblingSupportEnabled = false;
        public string GamblingSupportMode = "off";
        public int ShoppingDelayDefaultMinutes = 10;
        public bool ShoppingCheckoutDelayEnabled = true;
        public bool ShoppingStimulusDampingEnabled = true;
        public bool ShoppingDealSearchBlockEnabled = true;
        public bool ShoppingCurfewEnabled = true;
        public string ShoppingCurfewStart = "22:00";
        public string ShoppingCurfewEnd = "06:00";
        public bool ShoppingDailyLimitEnabled = true;
        public int ShoppingDailyLimitMinutes = 30;
        public bool ShoppingMonthlyOrderLimitEnabled = true;
        public int ShoppingMonthlyOrderLimit = 10;
        public bool ShoppingMonthlyBudgetEnabled = false;
        public int ShoppingMonthlyBudgetEuro = 200;
        public bool GamblingDailyLimitEnabled = true;
        public int GamblingDailyLimitMinutes = 15;
        public bool SocialMediaDailyBudgetEnabled = false;
        public int SocialMediaDailyBudgetMinutes = 60;
        public string SocialMediaPlatformLimits = string.Empty;
        public string SocialMediaBlockedPlatforms = string.Empty;
        public string SocialMediaFeedBlockedPlatforms = string.Empty;
        public bool SocialMediaCurfewEnabled = false;
        public string SocialMediaCurfewStart = "22:00";
        public string SocialMediaCurfewEnd = "06:00";
        public bool SocialMediaReflectionEnabled = true;
        public bool SocialMediaFeedDampingEnabled = true;
        public int SocialMediaFeedDampingScrolls = 50;
        public bool LockdownModeEnabled = true;
        public bool PauseCooldownEnabled = true;
        public bool ScheduleEnabled = false;
        public bool StrictModeEnabled = false;
        public string ScheduleStart = "22:00";
        public string ScheduleEnd = "06:00";
        public string PauseUntilUtc = string.Empty;
        public string PendingPauseUntilUtc = string.Empty;
        public string PendingUninstallUntilUtc = string.Empty;
        public string UninstallApprovalExpiresUtc = string.Empty;
        public string PasswordHint = string.Empty;
        public int PasswordFailedAttempts = 0;
        public string PasswordLockoutUntilUtc = string.Empty;
        // The Purestate version that last wrote this config. Signed from schema
        // 7 on and used by the installer as a monotonic downgrade floor: an
        // older package must not be installed over a newer one.
        public string InstalledVersion = string.Empty;
        // Manipulationsfeste Uhr fuer alle Gates. Wird ausschliesslich vom
        // Durchsetzungspfad fortgeschrieben (30-Sekunden-Tick) und ist ab
        // Schema 9 signiert: Zuruecksetzen oder Vorstellen per Editor trippt
        // die Integritaetspruefung. Leer = noch nie geschrieben.
        public string ClockAnchorUtc = string.Empty;
        // GetTickCount64-Stand beim letzten Ankerschreiben: Millisekunden seit
        // Systemstart, prozessuebergreifend vergleichbar und unabhaengig von
        // der Systemuhr. 0 = keine Historie (frische Installation oder
        // Neustart), dann wird ohne Sprungpruefung neu gesetzt.
        public long ClockTickAnchorMs = 0;
        // Startzeitpunkt der selbst angeforderten Abschwaechungsfrist. Leer =
        // keine Anfrage laeuft. Ab Schema 10 signiert, damit die Frist nicht
        // per Editor vorgezogen werden kann.
        public string WeakeningRequestedUtc = string.Empty;
        // "local" = Frist und Fenster werden lokal berechnet (Vorgabe).
        // "server" = Abschwaechen braucht eine signierte Serverfreigabe. Ein
        // abgelaufener Anspruch schaltet bewusst NICHT zurueck auf "local":
        // der Rueckfall auf lokale Autoritaet waere selbst eine Abschwaechung.
        public string AuthorityMode = "local";
        // Hoechste vom Server erteilte Freigabeversion, die dieses Geraet
        // kennt. Wird bei jeder Anfrage mitgeschickt; meldet das Geraet einen
        // kleineren Wert als der Server gespeichert hat, wurde die
        // Konfiguration zurueckgespielt und der Server verweigert.
        public long PolicyVersion = 0;
        // Die erteilte Freigabe als "pubkey|version|von|bis". Eine Zeile ohne
        // Zeilenvorschub, damit sie ohne JSON-Maskierung in config.json passt.
        public string WeakeningGrant = string.Empty;
        // Serversignatur ueber das Kanonisat der Freigabe, base64.
        public string GrantSignature = string.Empty;
        // Ablauf der Berechtigung, vom Server vergeben. Wirksam: ist der Termin
        // an der vertrauenswuerdigen Uhr verstrichen und die Serversignatur
        // gueltig, endet die Durchsetzung und der Rechner wird freigegeben
        // (Support.IsEntitlementExpiredAt). Das fruehere der beiden Enden gilt -
        // die eingebaute Fassungsgrenze BetaBuildEndUtc kappt einen spaeteren
        // Termin.
        public string EntitledUntilUtc = string.Empty;
        // Die Serversignatur ueber (Geraeteschluessel, Ablauf, Geraetezahl).
        // Ohne sie waere der Ablauftermin nur durch den lokalen HMAC gedeckt.
        public string EntitlementSignature = string.Empty;
        // Teil der signierten Kanonform des Servers und deshalb noetig, um die
        // Signatur spaeter erneut pruefen zu koennen.
        public int EntitlementMaxDevices = 0;
        // Uebergangsfrist nach einem App-Update als "version|bisUtc". Der
        // Chrome Web Store liefert die passende Companion-Version erst nach
        // seiner Pruefung aus; ohne diese Frist waeren alle gemischten Seiten
        // bis dahin voll gesperrt. Leer = keine Frist, es gilt nur die
        // aktuelle App-Version.
        public string CompanionGrace = string.Empty;
        public int IntegritySchemaVersion = 0;
        public PasswordRecord Password;
        public string Integrity = string.Empty;

        // Runtime-only (never serialized, never in the HMAC canonical): set by
        // LoadConfig when the stored integrity check fails. A compromised config
        // is fully untrusted - its password cannot authenticate and it must not
        // be written back (that would re-bless the tampered values).
        public bool IntegrityCompromised = false;

        public AppConfig Clone()
        {
            AppConfig clone = (AppConfig)MemberwiseClone();
            if (Password != null)
            {
                clone.Password = new PasswordRecord
                {
                    Algorithm = Password.Algorithm,
                    Iterations = Password.Iterations,
                    Salt = Password.Salt,
                    Hash = Password.Hash
                };
            }
            return clone;
        }
    }

    internal static partial class Support
    {
        public const string ServiceName = "PurestateGuard";
        public const string DisplayName = "Purestate Schutzdienst";
        public const string MarkerBegin = "# Purestate BEGIN";
        public const string MarkerEnd = "# Purestate END";
        public const string AppVersion = "0.62.82";
        public const string WatchdogTaskName = "\\Purestate\\Watchdog";
        public const string StartupTaskName = "\\Purestate\\Startup";
        // Angelegt wird sie vom Guard (PurestateGuardVideoGames.cs), der ohne
        // Support-Referenzen standalone kompiliert und den Namen deshalb ein
        // zweites Mal fuehrt. Aufgeraeumt wird sie hier, weil der Rueckbau hier
        // liegt: bleibt sie stehen, ist der Ordner "\Purestate" nicht leer und
        // DeleteFolder(..., 0) laesst ihn ebenfalls zurueck (live 2026-08-18).
        public const string BadgeTaskName = "\\Purestate\\Badge";
        // Startet das Infobereich-Symbol bei der Anmeldung (RegisterUserStartupEntry).
        public const string TrayTaskName = "\\Purestate\\Tray";
        // Oeffnet die Verwaltung erhoeht und ohne UAC-Dialog (Tester-Notiz
        // 2026-10-06: "jedes Mal wenn man Purestate oeffnet, kommt die
        // Admin-Meldung"). Ohne Ausloeser, wird nur auf Zuruf gestartet
        // (TryStartOpenTask); angelegt von RegisterUserStartupEntry.
        public const string OpenTaskName = "\\Purestate\\Open";
        // Argument, mit dem die Aufgabe die App startet: der erhoeht gestartete
        // Prozess darf die Aufgabe nicht noch einmal anstossen (Schleife bei
        // einem Standardnutzer, dessen "hoechste verfuegbare" Stufe keine
        // Administratorrechte sind).
        public const string OpenTaskLaunchArgument = "--from-task";
        // Argument, mit dem der Tray die Verwaltung nach einem Klick auf die
        // Update-Sprechblase oder den Menuepunkt startet. Als Argument statt als
        // Merkzeichen in der Nutzerdatei: bei einem Standardkonto laeuft das
        // Verwaltungsfenster unter einem anderen (Administrator-)Profil.
        public const string OpenUpdateLaunchArgument = "--update";
        // Die Deinstallation ist die groesste Abschwaechung ueberhaupt - sie
        // entfernt jeden Schutz auf einmal. Sie traegt deshalb dieselbe Frist
        // wie eine grosse Abschwaechung in den Einstellungen. Zehn Minuten
        // machten jede andere Frist wertlos: wer nicht sieben Tage auf ein
        // hoeheres Zeitlimit warten wollte, war in zehn Minuten die ganze App
        // los.
        public const int UninstallWaitDays = WeakeningWaitDays;
        // Abschwaechungen brauchen sieben Tage Vorlauf; danach steht ein Tag
        // lang ein Fenster offen, in dem beliebig viele Abschwaechungen
        // moeglich sind - wie zuvor der 1. des Monats, nur verdient statt
        // kalendarisch.
        public const int WeakeningWaitDays = 7;
        public const int WeakeningWindowHours = 24;
        // Kleine Abschwaechungen - ein Bereich bleibt an, nur ein Parameter
        // wird milder - warten 24 Stunden statt sieben Tage. Sieben Tage fuer
        // ein um zehn Minuten hoeheres Zeitlimit standen in keinem Verhaeltnis
        // und machten die Einstellung praktisch unbenutzbar; der Impuls, den
        // das Fenster abfangen soll, ueberlebt einen Tag nicht.
        //
        // Das kleine Fenster bleibt ab der 24. Stunde bis zum Ende des grossen
        // offen: sonst waere eine kleine Aenderung nach acht Tagen an einer
        // Frist gescheitert, die fuer die grosse laengst abgelaufen ist.
        public const int WeakeningMinorWaitHours = 24;
        // Nach sieben Tagen Wartezeit waeren 15 Minuten Freigabefenster eine
        // Falle: einmal verpasst, faengt die Woche von vorne an. Dasselbe
        // Fenster wie bei den Abschwaechungen.
        public const int UninstallApprovalWindowHours = WeakeningWindowHours;
        public const int CurrentIntegritySchemaVersion = 15;
        // Obergrenze fuer den Installationsmarker. Bricht eine Installation
        // mittendrin ab, bleibt der Marker liegen - nach dieser Zeit wird er
        // ignoriert, damit der Watchdog nicht dauerhaft stillsteht.
        public const int InstallWindowMinutes = 15;
        // Laenge der Companion-Uebergangsfrist. Deckt eine normale
        // Store-Pruefung mit Puffer ab; danach greift wieder die Vollsperre.
        public const int CompanionGraceDays = 14;
        private const long MaxLocalLogBytes = 262144;
        private const int MaxLocalLogMessageChars = 2048;

        public static readonly string InstallDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
            "Purestate"
        );

        public static readonly string DataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "Purestate"
        );

        public static readonly string ConfigPath = Path.Combine(DataDir, "config.json");
        public static readonly string IntegrityKeyPath = Path.Combine(DataDir, "integrity.key");
        // Der private Geraeteschluessel liegt wie integrity.key als eigene
        // Datei im ACL-geschuetzten Datenverzeichnis - NICHT in config.json,
        // die als companion-rule-state.json teilweise lesbar gespiegelt wird.
        public static readonly string DeviceKeyPath = Path.Combine(DataDir, "device.key");
        // Marker fuer die Dauer einer Installation. Der Watchdog laeuft als
        // eigene geplante Aufgabe und ruft Get-Config; feuert er waehrend des
        // Datei-Kopierens, liest altes Common.ps1 eine bereits migrierte
        // Konfiguration und meldet korrekt einen Integritaetsfehler. Zerstoert
        // nichts - beide Sprachen verweigern das Zurueckschreiben -, aber es
        // fuellt security.log mit Fehlalarmen, und genau diese Meldung ist das
        // Bestehenskriterium der Upgrade-Prueflisten.
        public static readonly string InstallInProgressPath = Path.Combine(DataDir, "install-in-progress.txt");
        public static readonly string ActivityLogPath = Path.Combine(DataDir, "activity.log");
        public static readonly string SecurityLogPath = Path.Combine(DataDir, "security.log");
        public static readonly string ServiceLogPath = Path.Combine(DataDir, "service.log");
        public static readonly string HostsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32", "drivers", "etc", "hosts");


        // Entwicklerbau: haengt Passwortabfrage, Abkuehlzeiten und das
        // 7-Tage-Fenster fuer Abschwaechungen aus, damit Aenderungen sofort
        // testbar sind - auch automatisiert, ohne dass ein Mensch ein Passwort
        // tippt.
        //
        // BEWUSST eine Compilerkonstante und KEINE Datei oder Registry-Wert:
        // bis 0.62.50 schaltete die blosse Anwesenheit von
        // dev-companion-id.txt das Gate ab, also eine Datei in Program Files -
        // erreichbar fuer genau den Angreifer, gegen den das Gate steht (der
        // Nutzer selbst mit Administratorrechten). Im ausgelieferten Bau ist
        // dieser Zweig nicht vorhanden, nicht nur ausgeschaltet.
        // tools\Build-Release.ps1 setzt die Konstante nur mit -Dev,
        // tools\Test-ReleasePreflight.ps1 bricht bei einem solchen Paket ab.
#if PURESTATE_DEV
        public const bool DevBuild = true;
#else
        public const bool DevBuild = false;
#endif

        // Im Entwicklerbau lassen sich die Fristen fuer einen Testlauf wieder
        // einschalten: PURESTATE_DEV_COOLDOWNS=1 setzen, dann verhaelt sich der
        // Bau wie der ausgelieferte. Ausserhalb des Entwicklerbaus ohne
        // Wirkung - DevBuild ist dort eine Konstante false, der Rest des
        // Ausdrucks wird nie ausgewertet.
        public static bool DevUnlockActive
        {
            get
            {
#if PURESTATE_DEV
                return !string.Equals(
                    Environment.GetEnvironmentVariable("PURESTATE_DEV_COOLDOWNS"),
                    "1",
                    StringComparison.Ordinal);
#else
                return false;
#endif
            }
        }

        internal static void EnsureDirectoryIsNotReparsePoint(string path)
        {
            FileAttributes attributes = File.GetAttributes(path);
            if ((attributes & FileAttributes.ReparsePoint) != 0)
            {
                throw new InvalidOperationException("Das Purestate-Datenverzeichnis darf kein Verknuepfungs- oder Reparse-Punkt sein.");
            }
        }

        public static void EnsureDataDir()
        {
            Directory.CreateDirectory(DataDir);
            EnsureDirectoryIsNotReparsePoint(DataDir);
        }

        public static bool VerifyPassword(string password)
        {
            if (DevUnlockActive)
            {
                return true;
            }

            AppConfig config = LoadConfig();
            if (config.IntegrityCompromised)
            {
                // The stored hash is untrusted once the config fails its
                // integrity check - a swapped hash must not authenticate.
                return false;
            }

            if (config.Password == null)
            {
                return false;
            }

            PasswordRecord record = config.Password;
            byte[] salt = Convert.FromBase64String(record.Salt);
            byte[] expected = Convert.FromBase64String(record.Hash);
            byte[] actual;

            if (string.Equals(record.Algorithm, "PBKDF2-SHA256", StringComparison.OrdinalIgnoreCase))
            {
                using (Rfc2898DeriveBytes derive = new Rfc2898DeriveBytes(password, salt, record.Iterations, HashAlgorithmName.SHA256))
                {
                    actual = derive.GetBytes(expected.Length);
                }
            }
            else if (string.Equals(record.Algorithm, "PBKDF2-SHA1", StringComparison.OrdinalIgnoreCase))
            {
                using (Rfc2898DeriveBytes derive = new Rfc2898DeriveBytes(password, salt, record.Iterations))
                {
                    actual = derive.GetBytes(expected.Length);
                }
            }
            else
            {
                return false;
            }

            if (actual.Length != expected.Length || actual.Length == 0)
            {
                return false;
            }

            int diff = 0;
            for (int i = 0; i < actual.Length; i++)
            {
                diff |= actual[i] ^ expected[i];
            }

            return diff == 0;
        }


        public static void WriteActivityLog(string message)
        {
            try
            {
                EnsureDataDir();
                AppendCappedLocalLogLine(ActivityLogPath, message);
            }
            catch
            {
            }
        }

        // Pur und damit pruefbar. Ein unlesbarer oder zu alter Marker gilt als
        // "keine Installation laeuft" - im Zweifel arbeitet der Watchdog
        // weiter, statt stillzustehen.
        internal static bool IsInstallWindowActive(string stamp, DateTime nowUtc)
        {
            DateTime started;
            if (!TryReadUtc(stamp, out started))
            {
                return false;
            }

            if (nowUtc < started)
            {
                // Marker aus der Zukunft: Uhr verstellt oder Datei manipuliert.
                return false;
            }

            return (nowUtc - started).TotalMinutes < InstallWindowMinutes;
        }

        // Bewusst die Wanduhr, nicht TrustedUtcNow: der Marker ist eine
        // Rennbremse, keine Schutzgrenze. Ein eingefrorener Uhr-Anker wuerde
        // ihn sofort als veraltet erscheinen lassen und die Fehlalarme
        // zurueckbringen.
        public static void BeginInstallWindow()
        {
            try
            {
                EnsureDataDir();
                File.WriteAllText(InstallInProgressPath, DateTime.UtcNow.ToString("o"), new UTF8Encoding(false));
            }
            catch
            {
            }
        }

        public static void EndInstallWindow()
        {
            try
            {
                File.Delete(InstallInProgressPath);
            }
            catch
            {
            }
        }

        // File.WriteAllText legt den Inhalt nur im Dateisystem-Cache ab. Nach
        // einem unsauberen Herunterfahren behaelt die Datei ihre Groesse und
        // verliert ihren Inhalt: live gesehen am 2026-08-04, integrity.key und
        // dns-backup.json bestanden danach aus 44 bzw. 838 NUL-Bytes. Die
        // signierte Config galt damit als kompromittiert, der Installer
        // verweigerte jede Aktualisierung, und alle Einstellungen waren
        // verloren. Flush(true) erzwingt FlushFileBuffers, also den Weg auf die
        // Platte statt in den Cache.
        //
        // Nur fuer Dateien, deren Verlust nicht reparabel ist: Schluessel,
        // Konfiguration, Sicherungen der Systemeinstellungen. Alles Ableitbare
        // (Protokolle, Sperrlisten, Zwischenstaende) schreibt weiter ungefsynct
        // - ein Flush pro Enforce-Takt waere reine Plattenlast.
        public static void WriteAllTextDurable(string path, string text)
        {
            byte[] bytes = new UTF8Encoding(false).GetBytes(text ?? string.Empty);
            using (FileStream stream = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                stream.Write(bytes, 0, bytes.Length);
                stream.Flush(true);
            }
        }

        public static void WriteSecurityLog(string message)
        {
            try
            {
                EnsureDataDir();
                AppendCappedLocalLogLine(SecurityLogPath, message);
            }
            catch
            {
            }

            MirrorSecurityEventToWindowsLog(message);
        }

        // 0 = not probed yet, 1 = source ready, 2 = unavailable (give up).
        private static int windowsEventSourceState;

        // Best-effort mirror of security events into the Windows Event Log so
        // they survive a user deleting the local text logs, and so a Windows
        // service failure is diagnosable via Event Viewer. Never throws; the
        // source probe is cached so a restricted (non-admin) context that
        // cannot register the source stops trying after the first attempt.
        private static void MirrorSecurityEventToWindowsLog(string message)
        {
            try
            {
                if (windowsEventSourceState == 2)
                {
                    return;
                }

                if (windowsEventSourceState == 0)
                {
                    try
                    {
                        if (!EventLog.SourceExists("Purestate"))
                        {
                            EventLog.CreateEventSource("Purestate", "Application");
                        }
                        windowsEventSourceState = 1;
                    }
                    catch
                    {
                        windowsEventSourceState = 2;
                        return;
                    }
                }

                EventLog.WriteEntry("Purestate", SanitizeLocalLogMessage(message), EventLogEntryType.Warning);
            }
            catch
            {
            }
        }

        // NMH-003: Beim Ueberlauf blieb frueher EINE Zeile uebrig - und viele
        // Zeilen hat genau die Datei, ueber die jemand ein Problem meldet. Eine
        // Generation bleibt deshalb als ".1" liegen. Dazu oeffnete
        // File.AppendAllText ohne FileShare.Write: mehrere Prozesse
        // (Browserprofile, Dienst und App) schreiben gleichzeitig, und die
        // verlorene Zeile verschwand im leeren catch der Aufrufer.
        internal static void AppendCappedLocalLogLine(string path, string message)
        {
            string line = DateTime.Now.ToString("s") + " " + SanitizeLocalLogMessage(message) + Environment.NewLine;
            FileInfo info = new FileInfo(path);
            if (info.Exists && info.Length > MaxLocalLogBytes)
            {
                RotateLocalLogFile(path);
            }
            AppendSharedLogLine(path, line);
        }

        private static void RotateLocalLogFile(string path)
        {
            try
            {
                string previous = path + ".1";
                if (File.Exists(previous))
                {
                    File.Delete(previous);
                }
                File.Move(path, previous);
            }
            catch
            {
                // Haelt ein anderer Prozess die Datei gerade offen, wird eben
                // weiter angehaengt. Eine zu grosse Datei ist besser als eine
                // verlorene Zeile - genau darum geht es hier.
            }
        }

        private static void AppendSharedLogLine(string path, string line)
        {
            byte[] bytes = new UTF8Encoding(false).GetBytes(line);
            for (int attempt = 0; attempt < 5; attempt++)
            {
                try
                {
                    using (FileStream stream = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                    {
                        stream.Write(bytes, 0, bytes.Length);
                    }
                    return;
                }
                catch (IOException)
                {
                    System.Threading.Thread.Sleep(20);
                }
            }
        }

        private static string SanitizeLocalLogMessage(string message)
        {
            string sanitized = (message ?? string.Empty)
                .Replace('\r', ' ')
                .Replace('\n', ' ')
                .Replace('\t', ' ')
                .Trim();
            if (sanitized.Length > MaxLocalLogMessageChars)
            {
                sanitized = sanitized.Substring(0, MaxLocalLogMessageChars);
            }
            return sanitized;
        }


        public static void RegisterAppEntry()
        {
            using (RegistryKey key = Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Purestate"))
            {
                if (key == null)
                {
                    return;
                }

                string appPath = Path.Combine(InstallDir, "Purestate.exe");
                string uninstallerPath = Path.Combine(InstallDir, "PurestateUninstaller.exe");

                key.SetValue("DisplayName", "Purestate");
                key.SetValue("DisplayVersion", AppVersion);
                key.SetValue("Publisher", "Lokale Purestate-App");
                key.SetValue("InstallLocation", InstallDir);
                key.SetValue("DisplayIcon", appPath + ",0");
                key.SetValue("UninstallString", "\"" + uninstallerPath + "\"");
                key.DeleteValue("ModifyPath", false);
                key.SetValue("NoRepair", 1, RegistryValueKind.DWord);
                key.SetValue("NoModify", 1, RegistryValueKind.DWord);
                key.SetValue("NoRemove", 0, RegistryValueKind.DWord);
                key.DeleteValue("QuietUninstallString", false);
                key.SetValue("EstimatedSize", EstimateInstallSizeKb(), RegistryValueKind.DWord);
            }
        }

        // Purestate.exe verlangt Administratorrechte, und Windows startet solche
        // Run-Eintraege bei der Anmeldung nicht: live 2026-09-28 Shell-Core
        // 9707/9708 mit PID 0 - das Infobereich-Symbol samt Ablaufhinweisen
        // erschien seit 0.62.42 nie. Eine Anmeldeaufgabe mit der hoechsten
        // verfuegbaren Berechtigung startet es ohne UAC-Dialog, derselbe Weg wie
        // das Restzeit-Abzeichen (V-7). Scheitert sie, bleibt die Installation
        // trotzdem gueltig; die Hinweise kommen dann nur in der Verwaltung.
        public static void RegisterUserStartupEntry()
        {
            UnregisterUserStartupEntry();
            string xmlPath = Path.Combine(DataDir, "tray-task.xml");
            try
            {
                EnsureDataDir();
                File.WriteAllText(xmlPath, BuildTrayTaskXml(Path.Combine(InstallDir, "Purestate.exe")), Encoding.Unicode);
                RunProcess(SystemToolPath("schtasks.exe"), "/Create /TN \"" + TrayTaskName + "\" /XML \"" + xmlPath + "\" /F", true);
            }
            catch (Exception ex)
            {
                WriteActivityLog("Tray autostart task could not be registered: " + ex.Message);
            }
            finally
            {
                try { File.Delete(xmlPath); } catch { }
            }

            RegisterOpenTask();
        }

        // Aufgabe, die die Verwaltung ohne UAC-Dialog erhoeht oeffnet. Scheitert
        // sie, bleibt die Installation gueltig: das Oeffnen fragt dann wie bisher
        // nach (Rueckfall in Program.Main).
        public static void RegisterOpenTask()
        {
            string xmlPath = Path.Combine(DataDir, "open-task.xml");
            try
            {
                EnsureDataDir();
                File.WriteAllText(xmlPath, BuildOpenTaskXml(Path.Combine(InstallDir, "Purestate.exe")), Encoding.Unicode);
                RunProcess(SystemToolPath("schtasks.exe"), "/Create /TN \"" + OpenTaskName + "\" /XML \"" + xmlPath + "\" /F", true);
            }
            catch (Exception ex)
            {
                WriteActivityLog("Open task could not be registered: " + ex.Message);
            }
            finally
            {
                try { File.Delete(xmlPath); } catch { }
            }
        }

        // Kein Ausloeser, Gruppe Benutzer, hoechste verfuegbare Berechtigung:
        // fuer einen Administrator das volle Token (derselbe Weg wie die
        // Tray-Aufgabe), fuer einen Standardnutzer das gewoehnliche - dort
        // gibt es keinen Gewinn und keinen Rechtezuwachs. Das Sicherheits-
        // beschreibungsformat erlaubt jedem angemeldeten Benutzer "Ausfuehren",
        // auch dem nicht erhoehten Prozess eines Administrators: dessen
        // gefiltertes Token traegt die Gruppe Administratoren nur noch als
        // "nur verweigern". Die Aufgabe startet ausschliesslich das installierte
        // Purestate.exe mit festem Argument.
        internal static string BuildOpenTaskXml(string appPath)
        {
            return "<?xml version=\"1.0\" encoding=\"UTF-16\"?>\r\n" +
                "<Task version=\"1.2\" xmlns=\"http://schemas.microsoft.com/windows/2004/02/mit/task\">\r\n" +
                "  <RegistrationInfo><Description>Oeffnet die Purestate-Verwaltung ohne Rueckfrage der Benutzerkontensteuerung.</Description>" +
                "<SecurityDescriptor>D:(A;;FA;;;SY)(A;;FA;;;BA)(A;;GRGX;;;AU)</SecurityDescriptor></RegistrationInfo>\r\n" +
                "  <Triggers />\r\n" +
                "  <Principals><Principal id=\"Author\"><GroupId>S-1-5-32-545</GroupId><RunLevel>HighestAvailable</RunLevel></Principal></Principals>\r\n" +
                "  <Settings>\r\n" +
                "    <MultipleInstancesPolicy>Parallel</MultipleInstancesPolicy>\r\n" +
                "    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>\r\n" +
                "    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>\r\n" +
                "    <AllowStartOnDemand>true</AllowStartOnDemand>\r\n" +
                "    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>\r\n" +
                "  </Settings>\r\n" +
                "  <Actions Context=\"Author\"><Exec><Command>" + System.Security.SecurityElement.Escape(appPath) +
                "</Command><Arguments>" + OpenTaskLaunchArgument + "</Arguments></Exec></Actions>\r\n" +
                "</Task>\r\n";
        }

        // Anmeldung jedes Nutzers, Gruppe Benutzer, hoechste verfuegbare
        // Berechtigung: fuer einen Administrator das volle Token. Ohne
        // ExecutionTimeLimit PT0S beendete die Aufgabenplanung das Symbol nach
        // 72 Stunden, und im Akkubetrieb startete es sonst gar nicht.
        internal static string BuildTrayTaskXml(string appPath)
        {
            return "<?xml version=\"1.0\" encoding=\"UTF-16\"?>\r\n" +
                "<Task version=\"1.2\" xmlns=\"http://schemas.microsoft.com/windows/2004/02/mit/task\">\r\n" +
                "  <Triggers><LogonTrigger><Enabled>true</Enabled></LogonTrigger></Triggers>\r\n" +
                "  <Principals><Principal id=\"Author\"><GroupId>S-1-5-32-545</GroupId><RunLevel>HighestAvailable</RunLevel></Principal></Principals>\r\n" +
                "  <Settings>\r\n" +
                "    <MultipleInstancesPolicy>Parallel</MultipleInstancesPolicy>\r\n" +
                "    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>\r\n" +
                "    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>\r\n" +
                "    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>\r\n" +
                "  </Settings>\r\n" +
                "  <Actions Context=\"Author\"><Exec><Command>" + System.Security.SecurityElement.Escape(appPath) +
                "</Command><Arguments>--tray</Arguments></Exec></Actions>\r\n" +
                "</Task>\r\n";
        }

        public static void UnregisterAppEntry()
        {
            try
            {
                Registry.LocalMachine.DeleteSubKeyTree(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Purestate", false);
            }
            catch
            {
            }
        }

        public static void UnregisterUserStartupEntry()
        {
            // Der Run-Eintrag frueherer Fassungen - er startete nie etwas.
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    if (key != null)
                    {
                        key.DeleteValue("Purestate", false);
                    }
                }
            }
            catch
            {
            }

            try
            {
                DeleteTaskIfPresent(SystemToolPath("schtasks.exe"), TrayTaskName);
                DeleteTaskIfPresent(SystemToolPath("schtasks.exe"), OpenTaskName);
            }
            catch
            {
            }
        }

        // Befund #5 / Spec 2.4: derselbe Schutzbereich-Filter wie Get-DomainList
        // in Common.ps1 - die Erwachsenen-Liste zaehlt nur mit, wenn sie auch
        // wirklich in der aktiven Sperre steckt, sonst zeigt "Adressen in
        // Listen" Schutz an, der gar nicht wirkt.
        internal static bool AdultDomainListActive(AppConfig config)
        {
            return config.AdultContentProtectionEnabled || !config.AdultHostsFollowArea;
        }

        public static int CountDomains()
        {
            AppConfig config = LoadConfig();
            System.Collections.Generic.List<string> files = new System.Collections.Generic.List<string>();
            if (AdultDomainListActive(config))
            {
                files.Add(Path.Combine(InstallDir, "rules", "adult-domains.txt"));
            }
            files.Add(Path.Combine(InstallDir, "rules", "custom-domains.txt"));
            return CountDomainsInFiles(files);
        }

        // PKG-002-Geschwister: die Paketpruefung (Blockliste geladen >= 250,
        // NativeSupportReports.cs) fragt, ob die Dateien auf der Platte
        // vollstaendig sind - unabhaengig vom Schutzbereich. CountDomains()
        // bildet dagegen ab, was gerade wirklich aktiv ist (Befund #5); ohne
        // diese Trennung wuerde eine ruhende Erwachsenen-Liste die
        // Paketpruefung faelschlich als "zu klein" melden.
        internal static int CountDomainFileEntries()
        {
            return CountDomainsInFiles(new string[]
            {
                Path.Combine(InstallDir, "rules", "adult-domains.txt"),
                Path.Combine(InstallDir, "rules", "custom-domains.txt")
            });
        }

        // Mirrors Get-DomainsFromRuleFiles in scripts\Common.ps1 - keep both in sync.
        internal static int CountDomainsInFiles(System.Collections.Generic.IEnumerable<string> files)
        {
            System.Collections.Generic.HashSet<string> domains = new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (string file in files)
            {
                if (!File.Exists(file))
                {
                    continue;
                }

                foreach (string raw in File.ReadAllLines(file))
                {
                    string trimmed = (raw ?? string.Empty).Trim();
                    if (trimmed.Length == 0 || trimmed.StartsWith("#"))
                    {
                        continue;
                    }

                    string normalized = NormalizeDomain(trimmed);
                    if (!IsValidDomain(normalized))
                    {
                        continue;
                    }

                    foreach (string candidate in DomainCandidates(normalized))
                    {
                        domains.Add(candidate);
                    }
                }
            }

            return domains.Count;
        }

        public static int CountAllowDomains()
        {
            return ReadAllowDomains().Length;
        }

        public static int CountMixedSiteUrlPatterns()
        {
            return CountEffectiveUrlPatterns(MixedSiteUrlPatternsPath(), AdultUrlKeywordsPath(), NsfwSubredditsPath());
        }

        // RGL-007: Wie viele davon in Chrome und Edge ueberhaupt ankommen. Alle
        // Stichwort- und Suchrouten tragen ein "*" IM PFAD und sind dort nicht
        // uebersetzbar; gemessen bleiben von 1000 Mustern 125 Filter. Die
        // Statuszeile nannte bisher die Rohzahl - fuer Firefox richtig, fuer
        // Chromium um den Faktor acht daneben.
        public static int CountChromiumMixedSiteUrlFilters()
        {
            return CountChromiumTranslatableUrlPatterns(
                MixedSiteUrlPatternsPath(), AdultUrlKeywordsPath(), NsfwSubredditsPath());
        }

        // PKG-002: Der Schutztest verlangte 700 Muster auf die SUMME von vier
        // Quellen. Die ersten beiden liegen zusammen bei 830, und eine davon
        // steht fest im Quelltext - der vollstaendige Verlust einer
        // Stichwortdatei konnte die Pruefung damit nicht bemerken. Jede Quelle
        // hat jetzt ihre eigene Schwelle, deutlich unter dem Ist-Stand, aber
        // weit ueber dem, was ein Totalverlust uebrig laesst.
        internal const int MinMixedSiteUrlPatternFileEntries = 100;
        internal const int MinAdultUrlKeywordEntries = 80;
        internal const int MinNsfwSubredditEntries = 60;

        public static int CountMixedSiteUrlPatternFileEntries()
        {
            return CountUrlPatternsInPackageFile(MixedSiteUrlPatternsPath());
        }

        public static int CountAdultUrlKeywords()
        {
            return CountAdultUrlKeywordsInPackageFile(AdultUrlKeywordsPath());
        }

        public static int CountNsfwSubreddits()
        {
            return CountNsfwSubredditsInPackageFile(NsfwSubredditsPath());
        }

        public static bool IsDomainInLists(string domain)
        {
            string normalized = NormalizeDomain(domain);
            if (!IsValidDomain(normalized))
            {
                return false;
            }

            foreach (string candidate in DomainCandidates(normalized))
            {
                if (DomainFileContains(candidate))
                {
                    return true;
                }
            }

            return false;
        }

        public static bool IsDomainAllowed(string domain)
        {
            string normalized = NormalizeDomain(domain);
            if (!IsValidDomain(normalized))
            {
                return false;
            }

            foreach (string candidate in DomainCandidates(normalized))
            {
                if (AllowDomainFileContains(candidate))
                {
                    return true;
                }
            }

            return false;
        }

        public static bool IsDomainInHostsBlock(string domain)
        {
            string normalized = NormalizeDomain(domain);
            if (!IsValidDomain(normalized) || !File.Exists(HostsPath))
            {
                return false;
            }

            try
            {
                string hosts = File.ReadAllText(HostsPath).ToLowerInvariant();
                foreach (string candidate in DomainCandidates(normalized))
                {
                    if (hosts.Contains(" " + candidate.ToLowerInvariant()) || hosts.Contains("\t" + candidate.ToLowerInvariant()))
                    {
                        return true;
                    }
                }
            }
            catch
            {
            }

            return false;
        }




        private static bool DomainFileContains(string domain)
        {
            string[] files =
            {
                Path.Combine(InstallDir, "rules", "adult-domains.txt"),
                Path.Combine(InstallDir, "rules", "custom-domains.txt")
            };

            foreach (string file in files)
            {
                if (!File.Exists(file))
                {
                    continue;
                }

                foreach (string raw in File.ReadAllLines(file))
                {
                    string line = NormalizeDomain(raw);
                    if (string.Equals(line, domain, StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private static bool AllowDomainFileContains(string domain)
        {
            string file = AllowDomainsPath();
            if (!File.Exists(file))
            {
                return false;
            }

            foreach (string raw in File.ReadAllLines(file))
            {
                string line = NormalizeDomain(raw);
                if (string.Equals(line, domain, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private static void AppendRecentLog(StringBuilder builder, string title, string path, int maxLines)
        {
            builder.AppendLine(title + ":");

            if (!File.Exists(path))
            {
                builder.AppendLine("Keine Eintraege.");
                return;
            }

            try
            {
                string[] lines = File.ReadAllLines(path);
                int start = Math.Max(0, lines.Length - Math.Max(1, maxLines));
                for (int i = start; i < lines.Length; i++)
                {
                    builder.AppendLine(lines[i]);
                }
            }
            catch (Exception ex)
            {
                builder.AppendLine("Konnte Log nicht lesen: " + ex.Message);
            }
        }


        private static bool IsRegisteredInWindows()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Purestate"))
                {
                    return key != null;
                }
            }
            catch
            {
                return false;
            }
        }


        private sealed class RuleFileAudit
        {
            public string Title;
            public string Path;
            public bool Exists;
            public int RawEntries;
            public int ValidEntries;
            public int DuplicateEntries;
            public System.Collections.Generic.List<string> InvalidLines = new System.Collections.Generic.List<string>();
            public System.Collections.Generic.List<string> DuplicateDomains = new System.Collections.Generic.List<string>();
            public System.Collections.Generic.List<string> ValidDomains = new System.Collections.Generic.List<string>();
        }

        private static RuleFileAudit AuditRuleFile(string path, string title)
        {
            RuleFileAudit audit = new RuleFileAudit();
            audit.Title = title;
            audit.Path = path;
            audit.Exists = SafeFileExists(path);

            if (!audit.Exists)
            {
                return audit;
            }

            System.Collections.Generic.HashSet<string> seen = new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                int lineNumber = 0;
                foreach (string raw in File.ReadAllLines(path))
                {
                    lineNumber++;
                    string trimmed = (raw ?? string.Empty).Trim();
                    if (trimmed.Length == 0 || trimmed.StartsWith("#"))
                    {
                        continue;
                    }

                    audit.RawEntries++;
                    string domain = NormalizeDomain(trimmed);
                    if (!IsValidDomain(domain))
                    {
                        audit.InvalidLines.Add("Zeile " + lineNumber + ": " + trimmed);
                        continue;
                    }

                    audit.ValidEntries++;
                    audit.ValidDomains.Add(domain);
                    if (seen.Contains(domain))
                    {
                        audit.DuplicateEntries++;
                        if (!audit.DuplicateDomains.Contains(domain))
                        {
                            audit.DuplicateDomains.Add(domain);
                        }
                    }
                    else
                    {
                        seen.Add(domain);
                    }
                }
            }
            catch (Exception ex)
            {
                audit.InvalidLines.Add("Konnte Datei nicht lesen: " + ex.Message);
            }

            audit.ValidDomains.Sort(StringComparer.OrdinalIgnoreCase);
            audit.DuplicateDomains.Sort(StringComparer.OrdinalIgnoreCase);
            return audit;
        }

    }
}
