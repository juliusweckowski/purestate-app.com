"use strict";

// Purestate Instagram companion.
//
// Instagram prohibits explicit pornography under its own Terms of Service, so
// unlike Tumblr/pixiv/DeviantArt this is not a "toggle to allow explicit adult
// content" site - the relevant control is the "Sensitive Content Control"
// preference, which limits suggestive/mature content Instagram itself
// recommends in Explore/Reels/search. Built from live DOM provided by the user
// (2026-07-01):
// https://www.instagram.com/accounts/settings/v2/content_preferences/ exposes
// three native <input type="radio"> elements sharing one `name` (the
// localized question text itself, so not language-portable) and an
// `aria-label` of "Weniger"/"Standard"/"Mehr" (German) - "Less"/"Standard"/
// "More" in English. The language-independent signal is the numeric `value`:
// "2" = Weniger/Less (most restrictive - our target), "1" = Standard
// (observed default), "0" = Mehr/More. We confirm group membership by
// checking that a sibling radio's aria-label matches the opposite end
// ("Mehr"/"More"), not by the fragile localized `name` string. Selecting a
// radio does not save by itself; a confirmation button appears (observed
// German text: "Bestätigen") which must also be clicked.
//
// Account-wide setting, same architecture risk already found and fixed on
// pixiv this session: this preference is account-wide/server-side, so it can
// be changed from any device logged into the same account (e.g. a phone),
// instantly affecting an already-"enforced" browser too. Built defensively
// from the start this time instead of as a follow-up fix: direct enforcement
// when the settings page itself is open, PLUS a periodic account-wide
// self-heal via a hidden same-origin iframe, ported from DeviantArt's
// enforceDaAccountWide / pixiv's enforcePixivAccountWide. No known per-item
// "sensitive content, show anyway" reveal cover to guard against - the user
// confirmed live they have never seen one on this account.
//
// Search: hashtag pages (/explore/tags/<tag>/) AND keyword-search result
// pages (/explore/search/keyword/?q=<term>, the page Instagram navigates to
// when a typed search is submitted) are blocked via the shared adult-search
// blocklist, the same mechanism as Tumblr/pixiv/Newgrounds tag pages. The
// keyword route was the documented gap of the first pass (0.61.30-0.61.42);
// search-as-you-type suggestions are covered without reading suggestions:
// when a real Instagram search input itself contains an adult term, the page
// is covered by the same local overlay before suggestion results are usable.

const INSTAGRAM_SETTINGS_URL = "https://www.instagram.com/accounts/settings/v2/content_preferences/";
const INSTAGRAM_ENFORCE_FRAME_ID = "purestate-instagram-enforce-frame";
const INSTAGRAM_ENFORCE_INTERVAL_MS = 60000;
const INSTAGRAM_INSTANT_STYLE_ID = "purestate-instagram-instant-style";
const INSTAGRAM_SEARCH_OVERLAY_ID = "purestate-instagram-search-overlay";
const INSTAGRAM_LESS_LABEL_PATTERN = /^(weniger|less)$/i;
const INSTAGRAM_MORE_LABEL_PATTERN = /^(mehr|more)$/i;
const INSTAGRAM_CONFIRM_TEXT_PATTERN = /^(best[äa]tigen|confirm|speichern|save)$/i;

let instagramObserver = null;
let instagramScanTimer = 0;
let lastInstagramLocation = "";
let instagramEnforceInFlight = false;
let instagramLastEnforce = 0;
const instagramControlLastClick = new WeakMap();

purestateRunWhenSiteProtectionEnabled("instagram", () => {
  installInstagramInstantHide();
  installInstagramSettingsGuard();
  installInstagramMonitoring();
});

// Runs synchronously at document_start: block a blocked hashtag from the
// first paint so it never flashes before the overlay is built.
function installInstagramInstantHide() {
  if (!document.documentElement) {
    return;
  }
  if (instagramAdultSearchTerm()) {
    purestateInstantHide(document, INSTAGRAM_INSTANT_STYLE_ID);
  }
}

function installInstagramMonitoring() {
  applyInstagramPageBlock();
  enforceInstagramSettings(document);
  enforceInstagramAccountWide();
  instagramObserver = new MutationObserver(() => scheduleInstagramScan());
  instagramObserver.observe(document.documentElement, { childList: true, subtree: true });
  installInstagramSearchInputGuard();
  setInterval(() => {
    const current = location.href;
    if (current !== lastInstagramLocation) {
      lastInstagramLocation = current;
    }
    applyInstagramPageBlock();
    enforceInstagramSettings(document);
    enforceInstagramAccountWide();
    observeInstagramCanary();
  }, 1000);
}

// Selector canary (diagnostics only, see purestateCanaryObserve): when this
// document IS the Sensitive-Content-Control settings page, the radio group
// must exist. 15 consecutive 1s-tick misses report a selector break.
function observeInstagramCanary() {
  purestateCanaryObserve(
    "instagram",
    "sensitive-radios",
    /^\/accounts\/settings\/v2\/content_preferences/i.test(location.pathname || ""),
    !!instagramTargetRadio(document)
  );
}

// Self-heal frame canary: the hidden iframe loaded INSTAGRAM_SETTINGS_URL, so
// the radio group must exist inside it by the end of the cycle. Three
// consecutive 60s cycles without it report a selector break.
function observeInstagramFrameCanary(frame) {
  try {
    const doc = purestateSettingsFrameDocument(frame, "/accounts/settings/v2/content_preferences");
    const found = !!(doc && instagramTargetRadio(doc));
    purestateCanaryObserve("instagram", "selfheal-frame", !!doc, found, 3);
  } catch {
  }
}

function scheduleInstagramScan() {
  clearTimeout(instagramScanTimer);
  instagramScanTimer = setTimeout(() => {
    applyInstagramPageBlock();
    enforceInstagramSettings(document);
  }, 80);
}

// --- Hashtag adult-search blocking ------------------------------------------

function instagramAdultSearchTerm() {
  try {
    const url = new URL(location.href);
    const tag = url.pathname.match(/\/explore\/tags\/([^/?#]+)/i);
    if (tag) {
      const term = decodeURIComponent(tag[1]).replace(/[-_+]/g, " ").trim();
      if (term && purestateIsAdultSearchText(term)) {
        return term;
      }
    }
    // Submitted keyword searches: /explore/search/keyword/?q=<term> (also
    // check q on any other /explore/search variant defensively).
    if (/^\/explore\/search(?:\/|$)/i.test(url.pathname)) {
      const adult = globalThis.purestateAdultSearchParam(url.href, ["q"]);
      if (adult) {
        return adult;
      }
    }
  } catch {
  }
  return "";
}

function instagramTypedSearchTerm(root) {
  const doc = root || document;
  if (!doc || typeof doc.querySelectorAll !== "function") {
    return "";
  }
  const selector = [
    "input",
    "textarea",
    "[role='searchbox']",
    "[contenteditable='true']"
  ].join(",");
  for (const el of doc.querySelectorAll(selector)) {
    if (!instagramLooksLikeSearchInput(el)) {
      continue;
    }
    const value = instagramSearchInputValue(el);
    if (value && purestateIsAdultSearchText(value)) {
      return value;
    }
  }
  return "";
}

function instagramSearchInputValue(el) {
  if (!el) {
    return "";
  }
  return purestateSettledSearchText(el, typeof el.value === "string" ? el.value : String(el.textContent || ""));
}

function instagramLooksLikeSearchInput(el) {
  if (!el || typeof el.getAttribute !== "function") {
    return false;
  }
  const tag = String(el.tagName || "").toLowerCase();
  const type = String(el.getAttribute("type") || "").toLowerCase();
  const role = String(el.getAttribute("role") || "").toLowerCase();
  if (tag === "input" && type && !["search", "text", "url"].includes(type)) {
    return false;
  }
  if (role === "searchbox" || type === "search") {
    return true;
  }
  if (el.closest && el.closest("[role='search'], form[role='search']")) {
    return true;
  }
  const descriptor = [
    el.getAttribute("aria-label"),
    el.getAttribute("placeholder"),
    el.getAttribute("name"),
    el.getAttribute("id"),
    el.getAttribute("autocomplete")
  ].join(" ").toLowerCase();
  return /(?:^|[^a-z])(?:search|suche|suchen)(?:[^a-z]|$)/i.test(descriptor);
}

// Block the page with the shared full-page overlay when it is a blocked
// hashtag/search, including an adult term currently typed into the search box.
// Returns true when the page was blocked.
function applyInstagramPageBlock() {
  if (instagramAdultSearchTerm() || instagramTypedSearchTerm(document)) {
    purestateInstantHide(document, INSTAGRAM_INSTANT_STYLE_ID);
    purestateShowSearchOverlay(
      document,
      INSTAGRAM_SEARCH_OVERLAY_ID,
      "Diese Instagram-Suche wurde durch Purestate blockiert."
    );
    return true;
  }
  purestateHideSearchOverlay(document, INSTAGRAM_SEARCH_OVERLAY_ID, INSTAGRAM_INSTANT_STYLE_ID);
  return false;
}

function installInstagramSearchInputGuard() {
  const schedule = () => scheduleInstagramScan();
  document.addEventListener("input", schedule, true);
  document.addEventListener("change", schedule, true);
  document.addEventListener("keyup", schedule, true);
}

// --- Sensitive Content Control enforcement ----------------------------------

// All radios sharing the given radio's `name`. Avoided a CSS attribute
// selector on `name` because Instagram's `name` here is the (localized,
// comma/colon-containing) question text itself, not a simple token.
function instagramGroupSiblings(radio) {
  const doc = radio.ownerDocument || document;
  const siblings = [];
  for (const el of doc.querySelectorAll('input[type="radio"]')) {
    if (el.name && el.name === radio.name) {
      siblings.push(el);
    }
  }
  return siblings;
}

// Confirms a radio belongs to the Sensitive Content Control group by content
// (a sibling with the opposite-end label exists), not by the fragile
// localized `name` string or by build-hashed classes.
function instagramIsSensitiveContentRadio(radio) {
  const siblings = instagramGroupSiblings(radio);
  if (siblings.length < 2) {
    return false;
  }
  let hasLess = false;
  let hasMore = false;
  for (const el of siblings) {
    const label = el.getAttribute("aria-label") || "";
    if (INSTAGRAM_LESS_LABEL_PATTERN.test(label)) {
      hasLess = true;
    }
    if (INSTAGRAM_MORE_LABEL_PATTERN.test(label)) {
      hasMore = true;
    }
  }
  return hasLess && hasMore;
}

// The "Weniger"/"Less" radio within the Sensitive Content Control group, or
// null if that group is not present in the given document.
function instagramTargetRadio(root) {
  if (!root || typeof root.querySelectorAll !== "function") {
    return null;
  }
  for (const el of root.querySelectorAll('input[type="radio"]')) {
    const label = el.getAttribute("aria-label") || "";
    if (INSTAGRAM_LESS_LABEL_PATTERN.test(label) && instagramIsSensitiveContentRadio(el)) {
      return el;
    }
  }
  return null;
}

function instagramControlChecked(control) {
  if (typeof control.checked === "boolean" && control.checked) {
    return true;
  }
  return String(control.getAttribute && control.getAttribute("aria-checked") || "").toLowerCase() === "true";
}

// Locates the confirmation button that must be clicked after selecting a
// radio for the change to persist. Scoped to the nearest dialog/form/body so
// an unrelated same-worded button elsewhere on the page is never hit.
function instagramFindConfirmButton(radio) {
  if (!radio || !radio.closest) {
    return null;
  }
  const container =
    radio.closest('[role="dialog"], form') ||
    (radio.ownerDocument ? radio.ownerDocument.body : null);
  if (!container || !container.querySelectorAll) {
    return null;
  }
  for (const button of container.querySelectorAll('button, [role="button"]')) {
    const text = (button.textContent || "").trim();
    if (INSTAGRAM_CONFIRM_TEXT_PATTERN.test(text)) {
      return button;
    }
  }
  return null;
}

// Selects the "Weniger"/"Less" radio if it is not already selected, then
// clicks the confirmation button. Throttled per control so the change can
// settle and we never fight our own click.
function enforceInstagramSettings(root) {
  const target = instagramTargetRadio(root || document);
  if (!target || instagramControlChecked(target)) {
    return;
  }
  const last = instagramControlLastClick.get(target) || 0;
  if (Date.now() - last < 1000) {
    return;
  }
  instagramControlLastClick.set(target, Date.now());
  const confirm = instagramFindConfirmButton(target);
  try {
    target.click();
  } catch {
  }
  setTimeout(() => {
    try {
      if (confirm) {
        confirm.click();
      }
    } catch {
    }
  }, 200);
}

// Account-wide self-heal: see the top-of-file note. From any Instagram page
// that does NOT itself have the Sensitive Content Control group in the DOM
// (direct enforcement above already covers that case), periodically load the
// settings page in a hidden same-origin iframe and enforce it there too.
function enforceInstagramAccountWide() {
  if (instagramTargetRadio(document)) {
    return;
  }
  const now = Date.now();
  if (instagramEnforceInFlight || now - instagramLastEnforce < INSTAGRAM_ENFORCE_INTERVAL_MS) {
    return;
  }
  instagramEnforceInFlight = true;
  instagramLastEnforce = now;
  const existing = document.getElementById(INSTAGRAM_ENFORCE_FRAME_ID);
  if (existing) {
    existing.remove();
  }
  const frame = document.createElement("iframe");
  frame.id = INSTAGRAM_ENFORCE_FRAME_ID;
  frame.setAttribute("aria-hidden", "true");
  frame.style.cssText = "position:absolute!important;width:1px;height:1px;left:-9999px;top:-9999px;border:0;opacity:0;pointer-events:none;";
  frame.src = INSTAGRAM_SETTINGS_URL;
  const finish = () => {
    instagramEnforceInFlight = false;
    try {
      frame.remove();
    } catch {
    }
  };
  frame.addEventListener("load", () => {
    setTimeout(() => {
      try {
        enforceInstagramSettings(frame.contentDocument);
      } catch {
      }
      setTimeout(() => {
        observeInstagramFrameCanary(frame);
        finish();
      }, 1800);
    }, 600);
  });
  // Safety net in case the frame never loads (e.g. blocked by a framing policy).
  setTimeout(() => {
    if (instagramEnforceInFlight) {
      finish();
    }
  }, 9000);
  (document.body || document.documentElement).appendChild(frame);
}

// --- Settings guard ----------------------------------------------------
// Block the user from selecting Standard/Mehr; allow Weniger. Our own
// synthetic clicks (isTrusted === false) are exempt so enforcement is not
// self-blocked.

function installInstagramSettingsGuard() {
  const guard = (event) => guardInstagramSettingsClick(event);
  document.addEventListener("pointerdown", guard, true);
  document.addEventListener("click", guard, true);
  document.addEventListener("change", guard, true);
  document.addEventListener("keydown", (event) => {
    if (!event || (event.key !== " " && event.key !== "Enter")) {
      return;
    }
    guard(event);
  }, true);
}

function instagramRadioFromEvent(target) {
  if (!target || typeof target.getAttribute !== "function") {
    return null;
  }
  if (target.matches && target.matches('input[type="radio"]')) {
    return target;
  }
  return null;
}

function guardInstagramSettingsClick(event) {
  // Skip our own synthetic clicks so enforcement can flip the radio back.
  if (event && event.isTrusted === false) {
    return;
  }
  const radio = instagramRadioFromEvent(event && event.target);
  if (!radio || !instagramIsSensitiveContentRadio(radio)) {
    return;
  }
  const label = radio.getAttribute("aria-label") || "";
  // Block only the unsafe direction: selecting Standard/Mehr. Selecting
  // Weniger itself is always allowed.
  if (INSTAGRAM_LESS_LABEL_PATTERN.test(label)) {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  if (event.stopImmediatePropagation) {
    event.stopImmediatePropagation();
  }
  setTimeout(() => enforceInstagramSettings(document), 50);
}
