"use strict";

// Purestate generic search companion.
//
// Chrome's managed URLBlocklist is kept as an extra defense, but live testing
// showed that query-string wildcard rules are not reliable enough for adult
// search terms. This module parses search/tag URLs directly and blocks the
// results page with the same deterministic shared adult-term list used by the
// site-specific companions.

const SEARCH_INSTANT_STYLE_ID = "purestate-search-instant-style";
const SEARCH_OVERLAY_ID = "purestate-search-overlay";
const SEARCH_BROWSER_RULES_GET = "purestate.getBrowserRules";

let lastSearchLocation = "";
let searchRulePack = emptySearchRulePack();
// Finding #1 (Abschlusspruefung 2026-09-21): wird erst wahr, wenn die erste
// echte Antwort auf requestSearchRulePack()/"purestate.rulesUpdated" verarbeitet
// wurde. Vorher ist searchRulePack nur der fail-closed-Vorgabewert - genug fuer
// den Vorhang, aber keine Erlaubnis fuer applySafeSearchRedirect() zu
// navigieren: location.replace laesst sich nicht zuruecknehmen, wenn die
// echte Antwort dann "Bereich aus" sagt.
let searchRulePackReceived = false;

installSearchInstantHide();
installSearchMonitoring();

function installSearchInstantHide() {
  const category = purestateSearchCategoryFromLocation();
  if (document.documentElement && ((category === "adult-content" && searchAdultAreaActive()) || (category === "gambling" && searchGamblingAreaEnabled()) || (category === "shopping" && searchShoppingDealBlockEnabled()))) {
    purestateInstantHide(document, SEARCH_INSTANT_STYLE_ID);
  }
}

function installSearchMonitoring() {
  requestSearchRulePack();
  try {
    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage && typeof chrome.runtime.onMessage.addListener === "function") {
      chrome.runtime.onMessage.addListener((message) => {
        if (message && message.type === "purestate.rulesUpdated") {
          applySearchRulePack(message);
          applySearchPageBlock();
        }
        return false;
      });
    }
  } catch {
  }
  applySearchPageBlock();
  setInterval(() => {
    const current = location.href;
    if (current !== lastSearchLocation) {
      lastSearchLocation = current;
      applySearchPageBlock();
    }
  }, 500);
  if (document.documentElement && typeof MutationObserver === "function") {
    // SRC-005: Der Rueckruf lief frueher direkt, ohne Entprellung. Eine
    // Ergebnisseite mit Endlos-Scrollen loeste die Auswertung damit viele Male
    // je Sekunde aus. Sie ist zwar billig - sie fasst nur die Adresse an, kein
    // DOM-Durchlauf -, aber die Adresse aendert sich nicht oefter als der
    // Nutzer navigiert. Derselbe Entpreller wie in den anderen Modulen.
    const observer = new MutationObserver(() => scheduleSearchPageBlock());
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
}

let searchBlockTimer = 0;

function scheduleSearchPageBlock() {
  if (searchBlockTimer) {
    return;
  }
  searchBlockTimer = setTimeout(() => {
    searchBlockTimer = 0;
    applySearchPageBlock();
  }, 80);
}

// SRC-004: Hier standen drei Funktionen ohne einen einzigen Aufrufer -
// purestateSearchAdultTermFromLocation, purestateSearchTermFromUrl und
// adultTermOrEmpty. Alle drei waren EINZELWERT-Fassungen der heute benutzten
// Listenfunktionen (...TermsFromUrl, ...CategoryFromUrl), also Ueberbleibsel
// der Umstellung von "ein Suchbegriff" auf "mehrere Parameter je Anbieter".
// Zur Laufzeit kostete das nichts; die Gefahr ist, dass jemand sie fuer die
// aktuelle Schnittstelle haelt und an der falschen Stelle anbaut.
function purestateSearchCategoryFromLocation() {
  const fromUrl = purestateSearchCategoryFromUrl(location.href);
  if (fromUrl) {
    return fromUrl;
  }
  // SRC-002, live gemessen am 2026-08-30: die Erkennung las ausschliesslich
  // url.searchParams. Eine POST-Suche traegt keine Parameter in der Adresse -
  // bei Startpage erschien die Trefferseite ohne Vorhang und mit "Sichere
  // Suche: Normal". Das ist kein konstruierter Fall: Startpages eigenes
  // Suchfeld sendet per POST, wer dort normal tippt, war ungeschuetzt.
  //
  // Nur als Rueckfall, wenn die Adresse NICHTS hergibt: eine saubere
  // Parametersuche soll weiterhin allein ueber die Adresse entschieden werden.
  return purestateSearchCategoryFromTerms(purestateSearchTermsFromControls(document));
}

// Vorlage: xAdultSearchFromVisibleControls (x-content.js) und
// bluesky-content.js. Hier liefert die Funktion die BEGRIFFE statt eines
// Ja/Nein, damit dieselbe Kategorielogik greift wie bei der Adresse -
// Erwachseneninhalte, Gluecksspiel und Shopping werden sonst
// unterschiedlich behandelt, je nachdem wie gesucht wurde.
function purestateSearchTermsFromControls(root) {
  const found = [];
  try {
    if (!root || !root.querySelectorAll) {
      return found;
    }
    const controls = root.querySelectorAll("input, textarea, [role='searchbox']");
    for (const control of controls) {
      // Passwortfelder werden nie gelesen. Auf einer Suchseite ist das
      // unwahrscheinlich, aber der Rueckfall liest breiter als der
      // Adresspfad, und diese Grenze gehoert ausdruecklich in den Code.
      const type = String(control.getAttribute && control.getAttribute("type") || "").toLowerCase();
      if (type === "password" || type === "hidden") {
        continue;
      }
      const label = String(
        (control.getAttribute && control.getAttribute("aria-label")) || ""
      ) + " " + String(
        (control.getAttribute && control.getAttribute("placeholder")) || ""
      ) + " " + String((control.getAttribute && control.getAttribute("name")) || "");
      if (label.trim() && !/\b(search|suche|suchen|query|q)\b/i.test(label)) {
        continue;
      }
      const value = decodeSearchTerm(purestateSettledSearchText(control, String(control.value || "")));
      if (value && !found.includes(value)) {
        found.push(value);
      }
    }
  } catch {
  }
  return found;
}

function purestateSearchTermsFromUrl(urlString) {
  try {
    const url = new URL(urlString);
    const host = normalizeSearchHost(url.hostname);
    const path = url.pathname || "/";

    if (isGoogleSearchHost(host) && /^\/search\/?$/i.test(path)) {
      return searchValues(url, ["q"]);
    }
    // Bing: web search plus the image/video/news verticals (same q param).
    if (isHost(host, "bing.com") && /^\/(?:(?:images|videos|news)\/)?search\/?$/i.test(path)) {
      return searchValues(url, ["q"]);
    }
    if (isHost(host, "duckduckgo.com")) {
      return searchValues(url, ["q"]);
    }
    if (host === "search.brave.com" && /^\/(?:images\/|videos\/|news\/)?search\/?$/i.test(path)) {
      return searchValues(url, ["q"]);
    }
    // Yahoo: subdomain-based verticals (de., images., video.) share the host
    // suffix and the p/q params; their paths are /search or /search/images etc.
    if (isHost(host, "search.yahoo.com") && /^\/search(?:\/|$)/i.test(path)) {
      return searchValues(url, ["p", "q"]);
    }
    if (isYandexSearchHost(host) && /^\/(?:(?:images|video)\/)?search\/?$/i.test(path)) {
      return searchValues(url, ["text", "q"]);
    }
    if (isHost(host, "ecosia.org") && /^\/(?:search|images|videos|news)\/?$/i.test(path)) {
      return searchValues(url, ["q"]);
    }
    if (isHost(host, "startpage.com") && /^\/(?:sp|do)\/d?search\/?$/i.test(path)) {
      return searchValues(url, ["query", "q"]);
    }
    // Qwant searches from "/" with a q param (like DuckDuckGo).
    if (isHost(host, "qwant.com")) {
      return searchValues(url, ["q"]);
    }
    if (isMetagerSearchHost(host) && /^\/meta\//i.test(path)) {
      return searchValues(url, ["eingabe", "q"]);
    }
    if (isHost(host, "youtube.com")) {
      if (/^\/results\/?$/i.test(path)) {
        return searchValues(url, ["search_query", "q"]);
      }
      const hashtag = firstPathTerm(path, /^\/hashtag\/([^/?#]+)/i);
      if (hashtag) {
        return [hashtag];
      }
    }
    // TikTok and Pinterest are handled by their own site modules since
    // 0.61.43 (tiktok-content.js / pinterest-content.js) so they participate
    // in the per-site protection switch and fail-closed.
    if (isHost(host, "giphy.com")) {
      const search = firstPathTerm(path, /^\/(?:search|explore)\/([^/?#]+)/i);
      if (search) {
        return [search];
      }
    }
  } catch {
  }
  return [];
}

function purestateSearchAdultTermFromUrl(urlString) {
  for (const term of purestateSearchTermsFromUrl(urlString)) {
    if (purestateIsAdultSearchText(term)) {
      return term;
    }
  }
  return "";
}

function purestateSearchCategoryFromUrl(urlString) {
  return purestateSearchCategoryFromTerms(purestateSearchTermsFromUrl(urlString));
}

function purestateSearchCategoryFromTerms(terms) {
  if (!terms || !terms.length) {
    return "";
  }
  for (const term of terms) {
    if (purestateIsAdultSearchText(term)) {
      return "adult-content";
    }
  }
  for (const term of terms) {
    if (purestateIsGamblingSearchText(term) || searchTextHasLocalGamblingTerm(term)) {
      return "gambling";
    }
  }
  for (const term of terms) {
    if (searchTextHasShoppingDealTerm(term)) {
      return "shopping";
    }
  }
  return "";
}

function searchAdultAreaActive() {
  const area = searchRulePack.areas["adult-content"];
  return !!(area && area.enabled && area.mode === "strict");
}

// Forces the documented safe-search params (Bing adlt=strict, DuckDuckGo kp=1,
// Yandex family=yes) while the adult area is enforced. The helper returns ""
// for already-safe URLs, so the replace can never loop.
function applySafeSearchRedirect() {
  if (!searchAdultAreaActive()) {
    return false;
  }
  // Ohne echte Antwort bleibt es bei der Instant-Hide/Vorhang-Sperre (fail-
  // closed); nur wenn nie eine Antwort kommen kann (keine Erweiterungslaufzeit),
  // gilt weiterhin die sofortige Weiterleitung wie bisher.
  if (!searchRulePackReceived && typeof chrome !== "undefined" && chrome.runtime && typeof chrome.runtime.sendMessage === "function") {
    return false;
  }
  let target = "";
  try {
    target = purestateSafeSearchRedirectUrl(location.href);
  } catch {
    target = "";
  }
  if (!target) {
    return false;
  }
  try {
    location.replace(target);
    return true;
  } catch {
    return false;
  }
}

function applySearchPageBlock() {
  if (applySafeSearchRedirect()) {
    return true;
  }
  const category = purestateSearchCategoryFromLocation();
  if ((category === "adult-content" && searchAdultAreaActive()) || (category === "gambling" && searchGamblingAreaEnabled()) || (category === "shopping" && searchShoppingDealBlockEnabled())) {
    purestateInstantHide(document, SEARCH_INSTANT_STYLE_ID);
    let message = "Diese Suche wurde durch Purestate blockiert.";
    if (category === "gambling") {
      message = "Diese Gl\u00fccksspiel-Suche wurde durch Purestate blockiert.";
    } else if (category === "shopping") {
      message = "Diese Suche ist pausiert. Deal- und Gutscheinsuchen sind in deinem Shopping-Schutz blockiert.";
    }
    purestateShowSearchOverlay(
      document,
      SEARCH_OVERLAY_ID,
      message
    );
    return true;
  }
  purestateHideSearchOverlay(document, SEARCH_OVERLAY_ID, SEARCH_INSTANT_STYLE_ID);
  return false;
}

function searchValues(url, paramNames) {
  const result = [];
  for (const name of paramNames) {
    const values = url.searchParams.getAll(name);
    for (const value of values) {
      const decoded = decodeSearchTerm(value);
      if (decoded && !result.includes(decoded)) {
        result.push(decoded);
      }
    }
  }
  return result;
}

function firstPathTerm(path, pattern) {
  const match = String(path || "").match(pattern);
  if (!match) {
    return "";
  }
  return decodeSearchTerm(match[1]);
}

function emptySearchRulePack() {
  return {
    areas: {
      "adult-content": { enabled: true, mode: "strict" },
      gambling: { enabled: false, mode: "off" },
      shopping: { enabled: false, mode: "off" }
    },
    gambling: {
      searchTerms: []
    },
    shopping: {
      searchTerms: [],
      dealSearchBlockEnabled: false
    },
    gamblingLimits: {
      dailyLimitEnabled: false,
      dailyLimitMinutes: 15
    }
  };
}

function applySearchRulePack(response) {
  const rules = response && response.rules && typeof response.rules === "object" ? response.rules : {};
  const next = emptySearchRulePack();
  const areas = rules.areas && typeof rules.areas === "object" ? rules.areas : {};
  // Adult area: default stays fail-closed (enabled+strict); only an explicit
  // area object can turn it off. The adult TERM block now follows this area
  // too (see searchAdultAreaActive()); without a rule pack it stays blocked
  // via this same fail-closed default from emptySearchRulePack().
  const adultArea = areas["adult-content"] && typeof areas["adult-content"] === "object" ? areas["adult-content"] : null;
  if (adultArea) {
    next.areas["adult-content"] = {
      enabled: adultArea.enabled === true,
      mode: adultArea.mode === "strict" ? "strict" : "off"
    };
  }
  const gamblingArea = areas.gambling && typeof areas.gambling === "object" ? areas.gambling : null;
  if (gamblingArea) {
    next.areas.gambling = {
      enabled: gamblingArea.enabled === true,
      mode: gamblingArea.mode === "strict" ? "strict" : "off"
    };
  }
  const gambling = rules.gambling && typeof rules.gambling === "object" ? rules.gambling : {};
  next.gambling.searchTerms = normalizeSearchRuleTerms(gambling.searchTerms);
  const shoppingArea = areas.shopping && typeof areas.shopping === "object" ? areas.shopping : null;
  if (shoppingArea) {
    next.areas.shopping = {
      enabled: shoppingArea.enabled === true,
      mode: shoppingArea.mode === "gentle" ? "gentle" : "off"
    };
  }
  const shopping = rules.shopping && typeof rules.shopping === "object" ? rules.shopping : {};
  next.shopping.searchTerms = normalizeSearchRuleTerms(shopping.searchTerms);
  next.shopping.dealSearchBlockEnabled = shopping.dealSearchBlockEnabled === true;
  searchRulePack = next;
  searchRulePackReceived = true;
}

function requestSearchRulePack() {
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") {
      return;
    }
    const maybePromise = chrome.runtime.sendMessage({ type: SEARCH_BROWSER_RULES_GET, site: "search" }, (response) => {
      applySearchRulePack(response);
      applySearchPageBlock();
    });
    if (maybePromise && typeof maybePromise.then === "function") {
      maybePromise
        .then((response) => {
          applySearchRulePack(response);
          applySearchPageBlock();
        })
        .catch(() => {});
    }
  } catch {
  }
}

function searchGamblingAreaEnabled() {
  const area = searchRulePack && searchRulePack.areas && searchRulePack.areas.gambling;
  return !!(area && area.enabled === true && area.mode === "strict");
}

function searchShoppingDealBlockEnabled() {
  const area = searchRulePack && searchRulePack.areas && searchRulePack.areas.shopping;
  const shopping = searchRulePack && searchRulePack.shopping;
  return !!(area && area.enabled === true && area.mode === "gentle" && shopping && shopping.dealSearchBlockEnabled === true);
}

function searchTextHasShoppingDealTerm(text) {
  if (typeof purestateIsShoppingDealSearchText === "function" && purestateIsShoppingDealSearchText(text)) {
    return true;
  }
  const normalized = normalizeSearchRuleText(text);
  if (!normalized) {
    return false;
  }
  const tokens = normalized.split(/\s+/);
  for (const term of searchRulePack.shopping.searchTerms) {
    if (term.includes(" ")) {
      if (normalized.includes(term)) {
        return true;
      }
    } else if (tokens.includes(term)) {
      return true;
    }
  }
  return false;
}

function normalizeSearchRuleText(value) {
  return decodeSearchTerm(value)
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function normalizeSearchRuleTerms(values) {
  const result = [];
  for (const value of Array.isArray(values) ? values : []) {
    const term = normalizeSearchRuleText(value);
    if (term && term.length <= 64 && !result.includes(term)) {
      result.push(term);
    }
    if (result.length >= 250) {
      break;
    }
  }
  return result;
}

function searchTextHasLocalGamblingTerm(text) {
  if (typeof purestateIsGamblingSafeSearchContext === "function" && purestateIsGamblingSafeSearchContext(text)) {
    return false;
  }
  const normalized = normalizeSearchRuleText(text);
  if (!normalized) {
    return false;
  }
  const tokens = normalized.split(/\s+/);
  for (const term of searchRulePack.gambling.searchTerms) {
    if (term.includes(" ")) {
      if (normalized.includes(term)) {
        return true;
      }
    } else if (tokens.includes(term)) {
      return true;
    }
  }
  return false;
}

function decodeSearchTerm(value) {
  try {
    return decodeURIComponent(String(value || "")).replace(/[-_+]+/g, " ").trim();
  } catch {
    return String(value || "").replace(/[-_+]+/g, " ").trim();
  }
}

function normalizeSearchHost(hostname) {
  return String(hostname || "").toLowerCase().replace(/^www\./, "");
}

function isHost(host, baseHost) {
  return host === baseHost || host.endsWith("." + baseHost);
}

// SRC-003: Hier stand /^google\.[a-z.]+$/i - die Zeichenklasse enthaelt den
// PUNKT, erlaubt im Rest also beliebig viele davon. Damit galt auch
// "google.com.beispiel.de" als Google-Suchhost. Heute folgenlos, weil das
// Manifest die Einspeisung auf feste Google-Hosts begrenzt und das Skript dort
// nie laeuft - aber eine geladene Waffe: sobald jemand die Muster erweitert
// (und genau das ist der SRC-001-Fix), wendet der Begleiter Google-Regeln auf
// fremde Domains an. In adult-detect.js steht der Kommentar, der genau diesen
// Fehler beschreibt: "Nie Teilzeichenkette, sonst waere bzga.de.beispiel.example
// eine Beratungsstelle."
function isGoogleSearchHost(host) {
  return /^google\.[a-z]{2,}(?:\.[a-z]{2,})?$/i.test(host);
}

function isYandexSearchHost(host) {
  return host === "yandex.com" || host === "yandex.ru";
}

function isMetagerSearchHost(host) {
  return host === "metager.org" || host === "metager.de";
}
