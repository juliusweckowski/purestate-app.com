using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.App
{
    // Start page: the status card above already answers "am I protected" and
    // offers the one main action. This page only adds a plain-language summary
    // of the five protection areas - no technical cards, no raw booleans.
    internal sealed partial class AdminForm
    {
        private readonly Dictionary<string, Label> startAreaStatusLabels = new Dictionary<string, Label>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, Label> areaPageStatusLabels = new Dictionary<string, Label>(StringComparer.OrdinalIgnoreCase);

        private void BuildStartPage()
        {
            TableLayoutPanel page = CreatePage("start");
            AddPageTitle(page, "Start");
            AddPageHint(page, "Hier siehst du auf einen Blick, was Purestate auf diesem Gerät gerade macht.");
            BuildUpdateBanner(page);

            AddSectionTitle(page, "Deine Schutzbereiche");

            string[] areaIds =
            {
                Support.AreaAdultContent,
                Support.AreaGambling,
                Support.AreaShopping,
                Support.AreaSocialMedia,
                Support.AreaVideoGames
            };
            foreach (string areaId in areaIds)
            {
                page.Controls.Add(BuildStartAreaRow(areaId));
            }

            Button openAreas = Ui.SecondaryButton(theme, "Schutzbereiche ansehen und einstellen", "Öffnet die Seite mit allen fünf Schutzbereichen.");
            openAreas.Margin = new Padding(0, Ui.GapGroup, 0, 0);
            openAreas.Click += delegate { NavigateTo("areas"); };
            page.Controls.Add(openAreas);
            actionButtons.Add(openAreas);
            themeAppliers.Add(delegate { Ui.StyleSecondary(theme, openAreas); });
        }

        private Control BuildStartAreaRow(string areaId)
        {
            TableLayoutPanel row = new TableLayoutPanel
            {
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 2,
                Margin = new Padding(0, 0, 0, 4),
                Padding = new Padding(8, 4, 8, 4),
                BackColor = Color.Transparent
            };
            Ui.FitToPageColumn(row, 44);
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200f));
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));

            Label name = new Label
            {
                Text = AreaDisplayName(areaId),
                Font = Ui.FontBodyBold,
                ForeColor = theme.TextPrimary,
                AutoSize = true,
                MinimumSize = new Size(0, 28),
                TextAlign = ContentAlignment.MiddleLeft,
                Margin = new Padding(0, 2, 0, 2)
            };
            Ui.SetAccessibility(name, AreaDisplayName(areaId), "Schutzbereich " + AreaDisplayName(areaId) + ".", AccessibleRole.StaticText);
            row.Controls.Add(name, 0, 0);

            Label status = new Label
            {
                Text = "wird ermittelt ...",
                Font = Ui.FontBody,
                ForeColor = theme.TextSecondary,
                AutoSize = true,
                MinimumSize = new Size(0, 28),
                TextAlign = ContentAlignment.MiddleLeft,
                Margin = new Padding(0, 2, 0, 2)
            };
            Ui.SetAccessibility(status, AreaDisplayName(areaId) + " Status", "Aktueller Zustand dieses Schutzbereichs in einfacher Sprache.", AccessibleRole.StaticText);
            row.Controls.Add(status, 1, 0);

            startAreaStatusLabels[areaId] = status;
            themeAppliers.Add(delegate
            {
                name.ForeColor = theme.TextPrimary;
                status.ForeColor = theme.TextSecondary;
            });
            return row;
        }

        // Called from ApplyStatusSnapshot with lines "id|name|statusText".
        private void ApplyAreaStatusLines(string[] lines)
        {
            if (lines == null)
            {
                return;
            }
            foreach (string line in lines)
            {
                string[] parts = line.Split(new[] { '|' }, 3);
                if (parts.Length < 3)
                {
                    continue;
                }
                Label startLabel;
                // DESK-05: Der Screenreader-Name traegt den aktuellen Zustand
                // ("Shopping Status: Zeitlimit 30 Minuten täglich").
                if (startAreaStatusLabels.TryGetValue(parts[0], out startLabel))
                {
                    Ui.SetDynamicText(startLabel, parts[2], parts[1] + " Status");
                }
                Label pageLabel;
                if (areaPageStatusLabels.TryGetValue(parts[0], out pageLabel))
                {
                    Ui.SetDynamicText(pageLabel, parts[2], parts[1] + " Status");
                }
            }
        }
    }
}
