using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Windows.Forms;
using Purestate.Native;

namespace Purestate.Uninstaller
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            if (!Support.IsAdministrator())
            {
                try
                {
                    Support.RelaunchElevated(string.Empty);
                }
                catch
                {
                    MessageBox.Show("Bitte starte die Deinstallation mit Administrator-Rechten.", "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new UninstallForm());
        }
    }

    internal sealed class UninstallForm : Form
    {
        // Same light-theme palette as Purestate.exe's main window / Installieren.exe
        // (see PurestateApp.cs ThemeColors.Light) - duplicated for the same reason
        // as in PurestateInstaller.cs: this compiles as its own executable with no
        // shared UI code.
        private static readonly Color WindowBackground = Color.FromArgb(247, 248, 250);
        private static readonly Color TextPrimary = Color.FromArgb(15, 23, 42);
        private static readonly Color TextSecondary = Color.FromArgb(85, 96, 107);
        private static readonly Color Border = Color.FromArgb(226, 229, 234);
        private static readonly Color ButtonBackground = Color.White;
        private static readonly Color DangerRed = Color.FromArgb(185, 28, 28);

        private static void ApplyRoundedCorners(Control control, int radius)
        {
            if (control.Width <= 0 || control.Height <= 0)
            {
                return;
            }
            var path = new System.Drawing.Drawing2D.GraphicsPath();
            Rectangle bounds = new Rectangle(0, 0, control.Width, control.Height);
            int d = radius * 2;
            path.AddArc(bounds.X, bounds.Y, d, d, 180, 90);
            path.AddArc(bounds.Right - d, bounds.Y, d, d, 270, 90);
            path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            control.Region = new Region(path);
        }

        private static Color MixColor(Color from, Color to, int percentTo)
        {
            int p = Math.Max(0, Math.Min(100, percentTo));
            return Color.FromArgb(
                from.R + ((to.R - from.R) * p / 100),
                from.G + ((to.G - from.G) * p / 100),
                from.B + ((to.B - from.B) * p / 100));
        }

        private static Color HoverBackground(Color normal)
        {
            if (!normal.Equals(ButtonBackground))
            {
                return MixColor(normal, Color.Black, 8);
            }
            return MixColor(normal, Color.FromArgb(231, 237, 243), 65);
        }

        private static Color PressedBackground(Color normal)
        {
            if (!normal.Equals(ButtonBackground))
            {
                return MixColor(normal, Color.Black, 16);
            }
            return MixColor(normal, Color.FromArgb(231, 237, 243), 90);
        }

        private static void WireButtonFeedback(Button button, int normalBorderSize, Color normalBack, Color normalFore, Color normalBorder)
        {
            button.FlatAppearance.MouseOverBackColor = HoverBackground(normalBack);
            button.FlatAppearance.MouseDownBackColor = PressedBackground(normalBack);
            button.MouseEnter += delegate
            {
                if (button.Enabled)
                {
                    button.BackColor = HoverBackground(normalBack);
                }
            };
            button.MouseLeave += delegate
            {
                if (!button.Focused)
                {
                    button.BackColor = normalBack;
                    button.ForeColor = normalFore;
                }
            };
            button.MouseDown += delegate
            {
                if (button.Enabled)
                {
                    button.BackColor = PressedBackground(normalBack);
                }
            };
            button.MouseUp += delegate
            {
                if (button.Enabled)
                {
                    button.BackColor = button.ClientRectangle.Contains(button.PointToClient(Cursor.Position))
                        ? HoverBackground(normalBack)
                        : normalBack;
                }
            };
            button.Enter += delegate
            {
                button.FlatAppearance.BorderSize = Math.Max(normalBorderSize, 2);
                button.FlatAppearance.BorderColor = Color.FromArgb(30, 58, 95);
                button.BackColor = HoverBackground(normalBack);
                button.ForeColor = normalFore;
            };
            button.Leave += delegate
            {
                button.FlatAppearance.BorderSize = normalBorderSize;
                button.FlatAppearance.BorderColor = normalBorder;
                button.BackColor = normalBack;
                button.ForeColor = normalFore;
            };
        }

        private static string CleanMnemonic(string text)
        {
            return (text ?? string.Empty).Replace("&", string.Empty).Trim();
        }

        private static void ConfigureFormAccessibility(Form form, string name, string description)
        {
            form.AutoScaleMode = AutoScaleMode.Dpi;
            form.AccessibleName = name;
            form.AccessibleDescription = description;
            form.AccessibleRole = AccessibleRole.Window;
        }

        private static void ConfigureControlAccessibility(Control control, string name, string description, AccessibleRole role)
        {
            control.AccessibleName = name;
            control.AccessibleDescription = description;
            control.AccessibleRole = role;
        }

        private static void ConfigureButtonAccessibility(Button button, string description)
        {
            ConfigureControlAccessibility(button, CleanMnemonic(button.Text), description, AccessibleRole.PushButton);
        }

        private readonly TextBox passwordBox;
        private readonly Label statusLabel;
        private readonly Button uninstallButton;
        private readonly Timer cooldownTimer;
        private readonly bool entitlementExpired;
        private bool uninstalling;

        public UninstallForm()
        {
            AppConfig startupConfig = Support.LoadConfig();
            string hint = startupConfig.PasswordHint;
            // Einmal beim Oeffnen statt in jedem Sekundentakt: der Text haengt
            // daran, das Gate selbst nicht - das rechnet UpdateCooldownUi
            // weiterhin bei jedem Tick neu.
            entitlementExpired = Support.IsEntitlementExpired(startupConfig);
            string productName = "Purestate " + Support.AppVersion;
            Text = productName + " deinstallieren";
            ConfigureFormAccessibility(this, productName + " deinstallieren", entitlementExpired
                ? "Entfernt Purestate nach Passwortbestätigung, ohne Wartezeit."
                : "Entfernt Purestate nach Passwortbestätigung und Wartezeit.");
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            ClientSize = new Size(500, 322);
            Font = new Font("Segoe UI", 10);
            BackColor = WindowBackground;

            Label title = new Label();
            title.Text = productName + " entfernen";
            // 17pt semibold instead of 21pt bold - see PurestateInstaller.cs for
            // why (a marketing-hero-sized title doesn't fit a security tool).
            title.Font = new Font("Segoe UI", 17, FontStyle.Bold);
            title.ForeColor = TextPrimary;
            title.Location = new Point(26, 22);
            title.Size = new Size(430, 38);
            Controls.Add(title);

            Label note = new Label();
            string waitText = entitlementExpired
                ? "Der Beta-Zeitraum ist abgelaufen. Zum Entfernen genügt jetzt das Purestate-Passwort, ohne Wartezeit."
                : "Zum Entfernen werden das Purestate-Passwort und eine Wartezeit von " + Support.UninstallWaitDays + " Tagen benötigt. Der Schutz bleibt in dieser Zeit aktiv.";
            note.Text = string.IsNullOrEmpty(hint)
                ? waitText
                : waitText + Environment.NewLine + "Hinweis: " + hint;
            note.ForeColor = TextSecondary;
            note.Location = new Point(30, 74);
            note.Size = new Size(430, 52);
            Controls.Add(note);

            Label passwordLabel = new Label();
            passwordLabel.Text = "Passwort";
            passwordLabel.ForeColor = TextPrimary;
            passwordLabel.Location = new Point(32, 144);
            passwordLabel.Size = new Size(130, 24);
            Controls.Add(passwordLabel);

            passwordBox = new TextBox();
            passwordBox.Location = new Point(165, 141);
            passwordBox.Size = new Size(285, 25);
            passwordBox.UseSystemPasswordChar = true;
            passwordBox.TabIndex = 0;
            ConfigureControlAccessibility(passwordBox, "Passwort", "Purestate Passwort für die geschützte Deinstallation eingeben.", AccessibleRole.Text);
            Controls.Add(passwordBox);

            statusLabel = new Label();
            statusLabel.Text = "Bereit.";
            statusLabel.Location = new Point(32, 182);
            statusLabel.Size = new Size(430, 50);
            statusLabel.ForeColor = TextSecondary;
            ConfigureControlAccessibility(statusLabel, "Deinstallationsstatus", "Zeigt Wartezeit und Deinstallationsstatus.", AccessibleRole.StatusBar);
            Controls.Add(statusLabel);

            // Deliberately the one button in this app that keeps a destructive-red
            // fill - uninstalling really is the destructive action here, unlike
            // e.g. "Pausieren" in the main app which was deliberately moved away
            // from red (see PurestateApp.cs ThemeColors / Handoff.md).
            uninstallButton = new Button();
            uninstallButton.Text = "Wartezeit starten";
            uninstallButton.Location = new Point(32, 258);
            uninstallButton.Size = new Size(145, 38);
            uninstallButton.BackColor = DangerRed;
            uninstallButton.ForeColor = Color.White;
            uninstallButton.FlatStyle = FlatStyle.Flat;
            uninstallButton.FlatAppearance.BorderSize = 0;
            uninstallButton.TabIndex = 1;
            ConfigureButtonAccessibility(uninstallButton, "Startet die Wartezeit oder entfernt Purestate nach deren Ablauf.");
            uninstallButton.Click += delegate { Uninstall(); };
            ApplyRoundedCorners(uninstallButton, 4);
            WireButtonFeedback(uninstallButton, 0, DangerRed, Color.White, DangerRed);
            Controls.Add(uninstallButton);

            Button cancelButton = new Button();
            cancelButton.Text = "Abbrechen";
            cancelButton.Location = new Point(305, 258);
            cancelButton.Size = new Size(145, 38);
            cancelButton.FlatStyle = FlatStyle.Flat;
            cancelButton.BackColor = ButtonBackground;
            cancelButton.ForeColor = TextPrimary;
            cancelButton.FlatAppearance.BorderSize = 1;
            cancelButton.FlatAppearance.BorderColor = Border;
            cancelButton.TabIndex = 2;
            cancelButton.DialogResult = DialogResult.Cancel;
            ConfigureButtonAccessibility(cancelButton, "Schließt die Deinstallation ohne Änderungen.");
            cancelButton.Click += delegate { Close(); };
            CancelButton = cancelButton;
            ApplyRoundedCorners(cancelButton, 4);
            WireButtonFeedback(cancelButton, 1, ButtonBackground, TextPrimary, Border);
            Controls.Add(cancelButton);

            cooldownTimer = new Timer();
            cooldownTimer.Interval = 1000;
            cooldownTimer.Tick += delegate { UpdateCooldownUi(); };
            cooldownTimer.Start();
            FormClosed += delegate { cooldownTimer.Stop(); };
            Shown += delegate { passwordBox.Focus(); };
            UpdateCooldownUi();
        }

        private void Uninstall()
        {
            // A compromised config refuses every password by design, so the
            // protected uninstall cannot proceed and the generic "wrong
            // password" message would mislead. Explain the state and the manual
            // recovery instead.
            AppConfig currentConfig = File.Exists(Support.ConfigPath) ? Support.LoadConfig() : null;
            if (currentConfig != null && currentConfig.IntegrityCompromised)
            {
                Support.WriteSecurityLog("Uninstall refused: config integrity compromised.");

                // Die geschuetzte Deinstallation bleibt verweigert - ohne
                // vertrauenswuerdige Konfiguration gibt es kein Passwort und
                // keine Frist, die etwas bedeuten wuerden. Aber der Nutzer muss
                // hier trotzdem herauskommen: der Zustand entsteht auch ohne
                // Angriff, etwa nach einem unsauberen Herunterfahren
                // (NativeSupport.cs:435). Ohne diesen Ausgang bleiben
                // hosts-Block, erzwungenes Familien-DNS, Proxy, Firewallregeln
                // und Browserrichtlinien fuer immer stehen, und die frueher hier
                // gezeigte Anleitung liess ausgerechnet die Ordner loeschen, in
                // denen die Werkzeuge fuer den Rueckbau liegen (INS-002).
                //
                // Das schwaecht nichts ab: wer die Konfiguration zerstoeren
                // kann, kann auch die Dateien loeschen. Der Unterschied ist nur,
                // ob Purestate den Rechner sauber verlaesst oder Truemmer
                // hinterlaesst.
                DialogResult emergencyChoice = MessageBox.Show(
                    "Die Purestate-Konfiguration ist beschädigt oder wurde außerhalb der App verändert und ist gesperrt. " +
                    "Die geschützte Deinstallation ist deshalb nicht möglich (auch das Passwort wird abgelehnt)." + Environment.NewLine + Environment.NewLine +
                    "Purestate kann sich stattdessen jetzt vollständig entfernen, ohne Passwort und ohne Wartezeit. " +
                    "Dabei werden auch alle Systemänderungen zurückgenommen: der Eintrag in der hosts-Datei, das erzwungene " +
                    "Familien-DNS, die Proxy-Einstellung, die Firewall-Regeln, die Browser-Richtlinien, die geplanten Aufgaben " +
                    "und der Dienst." + Environment.NewLine + Environment.NewLine +
                    "Alle Einstellungen und dein Passwort gehen dabei verloren." + Environment.NewLine + Environment.NewLine +
                    "Purestate jetzt vollständig entfernen?" + Environment.NewLine + Environment.NewLine +
                    "Wenn du \"Nein\" wählst, bleibt alles unverändert. Lösche in diesem Fall NICHT die Ordner " +
                    Support.InstallDir + " und " + Support.DataDir + " - darin liegen die Werkzeuge, die diese " +
                    "Systemänderungen zurücknehmen können.",
                    "Purestate", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

                if (emergencyChoice != DialogResult.Yes)
                {
                    Support.WriteSecurityLog("Emergency uninstall declined.");
                    return;
                }

                Support.WriteSecurityLog("Emergency uninstall started (compromised config, no password).");
                PerformRemoval(true);
                return;
            }

            int remainingSeconds;
            int cooldownState = Support.GetUninstallCooldownState(out remainingSeconds);
            if (cooldownState == 1)
            {
                UpdateCooldownUi();
                return;
            }

            int lockoutRemaining;
            PasswordCheckResult check = Support.VerifyPasswordThrottled(passwordBox.Text, out lockoutRemaining);
            if (check == PasswordCheckResult.LockedOut)
            {
                Support.WriteSecurityLog("Password locked out: Deinstallieren");
                MessageBox.Show("Zu viele Fehlversuche. Bitte warte etwa " + Math.Max(1, (lockoutRemaining + 59) / 60) + " Minute(n) und versuche es erneut.", "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (check != PasswordCheckResult.Success)
            {
                Support.WriteSecurityLog("Password rejected: Deinstallieren");
                MessageBox.Show("Das Passwort ist falsch.", "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Support.WriteSecurityLog("Password accepted: Deinstallieren");
            if (cooldownState == 0)
            {
                DateTime readyAt = Support.BeginUninstallCooldown();
                Support.WriteSecurityLog("Uninstall cooldown started.");
                passwordBox.Clear();
                UpdateCooldownUi();
                MessageBox.Show(
                    "Die Wartezeit läuft bis " + readyAt.ToLocalTime().ToString("g") + ". Der Schutz bleibt aktiv. Danach hast du " + Support.UninstallApprovalWindowHours + " Stunden Zeit, die Deinstallation mit dem Passwort abzuschließen.",
                    "Purestate",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show("Purestate wirklich entfernen?", "Purestate", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                Support.WriteSecurityLog("Uninstall cancelled after password accepted.");
                return;
            }

            PerformRemoval(false);
        }

        // Der gemeinsame Rueckbau fuer beide Wege: den regulaeren mit Passwort
        // und Frist, und den Notausstieg aus INS-002. Die Schrittfolge ist
        // dieselbe - nur das Schreiben in die Konfiguration entfaellt im
        // Notfall, weil genau die dort beschaedigt ist.
        private void PerformRemoval(bool emergency)
        {
            uninstalling = true;
            uninstallButton.Enabled = false;
            Cursor = Cursors.WaitCursor;

            bool guardRemoved = false;
            try
            {
                Support.WriteSecurityLog("Uninstall started.");
                statusLabel.Text = "Schutz wird gelöscht...";
                Application.DoEvents();
                if (!emergency)
                {
                    Support.SetProtectionEnabled(false);
                }
                Support.StopService();

                // Undo all system changes (hosts, DNS, proxy, firewall, browser
                // policies) FIRST, while the guard service and watchdog still
                // exist. If this fails, the guardian is still in place to finish
                // the repair instead of leaving stale enforcement behind with no
                // way to undo it.
                Support.ClearProtection();

                statusLabel.Text = "Schutzkomponenten werden entfernt...";
                Application.DoEvents();
                Support.UnregisterManagedCompanionPolicy();
                Support.UnregisterNativeMessagingHost();
                Support.UnregisterWatchdogTask();
                Support.DeleteServiceIfExists();
                guardRemoved = true;
                Support.RemoveShortcuts();
                Support.UnregisterUserStartupEntry();
                Support.UnregisterAppEntry();

                // Zweiter Durchgang, nachdem Dienst und Watchdog weg sind.
                // Der erste Aufruf oben laeuft bewusst noch mit intaktem
                // Guardian, damit ein Fehlschlag reparierbar bleibt - genau
                // dadurch kann in diesem Fenster aber noch einmal durchgesetzt
                // werden. Fehlt dann bereits config.json, halten die
                // Vorgabewerte den Schutz fuer aktiv (fail-closed, so gewollt)
                // und schreiben einen leeren Hosts-Block zurueck. Live
                // beobachtet: nach der Deinstallation blieben die Marker
                // "# Purestate BEGIN/END" stehen und verwiesen auf eine App,
                // die es nicht mehr gibt. Jetzt hat das Entfernen das letzte
                // Wort.
                Support.ClearProtection();

                // INS-006, live gemessen am 2026-08-30: fuer hosts, DNS und die
                // URL-Sperrlisten hatte das Entfernen mit dem zweiten
                // ClearProtection bereits das letzte Wort - fuer die
                // Companion-Richtlinie nicht. Ensure-ManagedCompanionPolicy
                // laeuft in JEDEM Takt des Dienstes, und der lebt waehrend des
                // ersten Durchgangs oben noch. Genau in diesem Fenster schrieb
                // er ExtensionInstallForcelist und ExtensionSettings zurueck.
                // Gemessen blieb danach dauerhaft - auch ueber einen Neustart -
                // eine erzwungene und angepinnte Erweiterung in Chrome stehen,
                // die der Nutzer nicht entfernen kann und die mit nichts mehr
                // sprechen konnte, weil ihr Native-Messaging-Manifest weg war.
                // Der Notausstiegsdialog sagt ausdruecklich zu, auch die
                // Browser-Richtlinien zurueckzunehmen.
                Support.UnregisterManagedCompanionPolicy();
                Support.UnregisterNativeMessagingHost();

                statusLabel.Text = "Dateien werden entfernt...";
                Application.DoEvents();
                Support.WriteSecurityLog("Uninstall completed.");

                MessageBox.Show("Purestate wurde entfernt. Der Installationsordner wird nach dem Schließen bereinigt.", "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Die begrenzte Bereinigung darf erst nach diesem Dialog
                // starten: solange er offen ist, haelt diese EXE sich selbst
                // gesperrt und verbraucht sonst alle Loeschversuche.
                ScheduleInstallFolderRemoval();
                Close();
            }
            catch (Exception ex)
            {
                Support.WriteSecurityLog("Uninstall failed: " + ex.GetType().Name + (guardRemoved ? " (after guard removal)" : " (guard intact)"));
                uninstalling = false;
                UpdateCooldownUi();
                string message = guardRemoved
                    ? ex.Message
                    : ex.Message + Environment.NewLine + Environment.NewLine +
                      "Die Schutzkomponenten wurden absichtlich NICHT entfernt, damit das System repariert werden kann. " +
                      (emergency
                        ? "Bitte starte die Deinstallation erneut. Lösche die Purestate-Ordner NICHT von Hand - " +
                          "dann bliebe der Eintrag in der hosts-Datei, das erzwungene DNS und die Browser-Richtlinie stehen, " +
                          "ohne ein Werkzeug, das sie zurücknehmen kann."
                        : "Bitte starte die Deinstallation erneut oder führe in der App \"Reparieren\" aus.");
                MessageBox.Show(message, "Purestate", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void UpdateCooldownUi()
        {
            if (uninstalling)
            {
                return;
            }

            int remainingSeconds;
            int state = Support.GetUninstallCooldownState(out remainingSeconds);
            if (state == 1)
            {
                // Tage und Stunden statt mm:ss - ein Sekundenzaehler ueber
                // sieben Tage laedt zum Danebensitzen ein.
                TimeSpan remaining = TimeSpan.FromSeconds(remainingSeconds);
                string remainingText = remaining.TotalDays >= 1
                    ? ((int)remaining.TotalDays) + " Tage, " + remaining.Hours + " Stunden"
                    : (remaining.TotalHours >= 1
                        ? remaining.Hours + " Stunden, " + remaining.Minutes + " Minuten"
                        : Math.Max(1, remaining.Minutes) + " Minuten");
                statusLabel.Text = "Wartezeit läuft: noch " + remainingText + "." + Environment.NewLine + "Der Schutz bleibt aktiv.";
                uninstallButton.Text = "Bitte warten";
                uninstallButton.Enabled = false;
                return;
            }

            if (state == 2)
            {
                // Im abgelaufenen Zustand gab es nie eine Wartezeit - genau
                // deshalb steht hier Zustand 2. Der Zustand-0-Text unten ist
                // dann unerreichbar und darf die Frist weiter nennen.
                statusLabel.Text = entitlementExpired
                    ? "Der Beta-Zeitraum ist abgelaufen. Passwort eingeben, um Purestate ohne Wartezeit zu entfernen."
                    : "Wartezeit beendet. Passwort erneut eingeben.";
                uninstallButton.Text = "Jetzt deinstallieren";
                uninstallButton.Enabled = true;
                return;
            }

            statusLabel.Text = "Passwort eingeben, um die Wartezeit von " + Support.UninstallWaitDays + " Tagen zu starten.";
            uninstallButton.Text = "Wartezeit starten";
            uninstallButton.Enabled = true;
        }

        private static void ScheduleInstallFolderRemoval()
        {
            string installDir = Path.GetFullPath(Support.InstallDir).TrimEnd(Path.DirectorySeparatorChar);
            string expected = Path.GetFullPath(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Purestate")).TrimEnd(Path.DirectorySeparatorChar);

            if (!string.Equals(installDir, expected, StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            string dataDir = Path.GetFullPath(Support.DataDir).TrimEnd(Path.DirectorySeparatorChar);
            string cleanupRoot = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "PurestateCleanup");
            Directory.CreateDirectory(cleanupRoot);
            ProtectCleanupFolderAcl(cleanupRoot);

            string cleanup = Path.Combine(cleanupRoot, "cleanup-" + Guid.NewGuid().ToString("N") + ".cmd");
            string content =
                "@echo off" + Environment.NewLine +
                "cd /d \"%SystemRoot%\\System32\"" + Environment.NewLine +
                "for /l %%i in (1,1,30) do (" + Environment.NewLine +
                "  rmdir /s /q \"" + installDir + "\" 2>nul" + Environment.NewLine +
                "  if not exist \"" + installDir + "\" goto data_cleanup" + Environment.NewLine +
                "  timeout /t 1 /nobreak >nul" + Environment.NewLine +
                ")" + Environment.NewLine +
                ":data_cleanup" + Environment.NewLine +
                "rmdir /s /q \"" + dataDir + "\" 2>nul" + Environment.NewLine +
                "for /l %%i in (1,1,10) do (" + Environment.NewLine +
                "  if not exist \"" + dataDir + "\" goto script_cleanup" + Environment.NewLine +
                "  timeout /t 1 /nobreak >nul" + Environment.NewLine +
                "  rmdir /s /q \"" + dataDir + "\" 2>nul" + Environment.NewLine +
                ")" + Environment.NewLine +
                ":script_cleanup" + Environment.NewLine +
                // Der eigene Ordner ueberlebte die Deinstallation als leere
                // Huelle (Befund L-4): "del %~f0" markiert die noch laufende
                // .cmd nur zum Loeschen, der Eintrag verschwindet erst, wenn
                // cmd.exe sie freigibt - das rmdir eine Zeile spaeter findet
                // das Verzeichnis also nicht leer. Ein abgesetzter zweiter
                // cmd wartet drei Sekunden und raeumt nach. Die Zeile bleibt
                // trotzdem stehen: greift sie doch, ist der Nachlauf ein
                // wirkungsloses rmdir auf ein bereits entferntes Verzeichnis.
                // "^" schuetzt & und > vor dem aufrufenden Parser, sonst
                // wuerde start die Kommandokette selbst ausfuehren.
                "start \"\" /b cmd /c ping -n 4 127.0.0.1 ^>nul ^& rmdir /s /q \"" + cleanupRoot + "\"" + Environment.NewLine +
                "del /f /q \"%~f0\" 2>nul" + Environment.NewLine +
                "rmdir /s /q \"" + cleanupRoot + "\" 2>nul" + Environment.NewLine;

            File.WriteAllText(cleanup, content, Encoding.ASCII);

            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "cmd.exe");
            info.Arguments = "/c \"" + cleanup + "\"";
            info.UseShellExecute = false;
            info.CreateNoWindow = true;
            Process.Start(info);
        }

        private static void ProtectCleanupFolderAcl(string folder)
        {
            DirectorySecurity security = new DirectorySecurity();
            InheritanceFlags inheritance = InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit;
            security.SetAccessRuleProtection(true, false);
            security.AddAccessRule(new FileSystemAccessRule(
                new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null),
                FileSystemRights.FullControl,
                inheritance,
                PropagationFlags.None,
                AccessControlType.Allow));
            security.AddAccessRule(new FileSystemAccessRule(
                new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null),
                FileSystemRights.FullControl,
                inheritance,
                PropagationFlags.None,
                AccessControlType.Allow));
            Directory.SetAccessControl(folder, security);
        }
    }
}
