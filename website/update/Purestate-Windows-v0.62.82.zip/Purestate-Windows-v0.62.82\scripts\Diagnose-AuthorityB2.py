"""Read-only B2 access diagnosis. Never print credentials or authorization tokens."""
import base64
import configparser
import json
import os
import urllib.error
import urllib.parse
import urllib.request


def request(url, token, payload=None):
    data = None if payload is None else json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(url, data=data, headers={
        'Authorization': token, 'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.load(response)
    except urllib.error.HTTPError as error:
        print('B2 request failed: HTTP', error.code)
        raise SystemExit(1)
    except (urllib.error.URLError, TimeoutError):
        raise SystemExit('B2 network connection failed.')


def main():
    if os.geteuid() != 0:
        raise SystemExit('Run with sudo python3.')
    config = configparser.ConfigParser(interpolation=None)
    config.read('/etc/purestate-b2/rclone.conf')
    if not config.has_section('b2'):
        raise SystemExit('B2 configuration missing.')
    pair = config['b2']['account'] + ':' + config['b2']['key']
    auth = request('https://api.backblazeb2.com/b2api/v2/b2_authorize_account',
                   'Basic ' + base64.b64encode(pair.encode('utf-8')).decode('ascii'))
    print('Authentication: OK')
    allowed = auth.get('allowed', {})
    caps = set(allowed.get('capabilities', []))
    for capability in ('listBuckets', 'listFiles', 'readFiles', 'writeFiles', 'deleteFiles'):
        print(capability + ': ' + ('yes' if capability in caps else 'no'))
    print('Expected bucket: ' + str(allowed.get('bucketName') == 'purestate-backups-julius-2026'))
    print('Filename prefix restricted: ' + str(bool(allowed.get('namePrefix'))))
    bucket_id = allowed.get('bucketId')
    if not bucket_id:
        raise SystemExit('Expected a key restricted to one bucket; listing skipped.')
    endpoint = auth['apiUrl']
    parsed = urllib.parse.urlparse(endpoint)
    if parsed.scheme != 'https' or not (parsed.hostname or '').endswith('.backblazeb2.com'):
        raise SystemExit('Unexpected B2 API endpoint.')
    request(endpoint + '/b2api/v2/b2_list_file_names', auth['authorizationToken'],
            {'bucketId': bucket_id, 'maxFileCount': 1, 'prefix': allowed.get('namePrefix') or ''})
    print('File listing: OK')


if __name__ == '__main__':
    main()
