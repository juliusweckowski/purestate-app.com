param(
    [switch]$RestoreDns,
    [switch]$Quiet,
    [switch]$SelfTest
)

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\Common.ps1"

if ($SelfTest) {
    $sample = "$script:MarkerBegin`r`n0.0.0.0 example.com`r`n$script:MarkerEnd`r`nkeep"
    $clean = Remove-ManagedHostsBlock -Content $sample
    if ($clean -ne "keep") {
        throw "Hosts cleanup self-test failed."
    }

    "Self-test OK."
    exit 0
}

Disable-Protection -RestoreDns:$RestoreDns

if (-not $Quiet) {
    "Protection removed."
}

